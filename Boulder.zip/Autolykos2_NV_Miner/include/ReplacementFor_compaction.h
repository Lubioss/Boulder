
#ifndef ReplacementFor_COMPACTION_H
#define ReplacementFor_COMPACTION_H
#include "ReplacementFor_definitions.h"
ReplacementFor___device__ uint32_t ReplacementFor_WarpInc(uint32_t*len);
ReplacementFor___global__ void ReplacementFor_Compactify(const uint32_t*in,const
 uint32_t ReplacementFor_inlen,uint32_t*out,uint32_t*ReplacementFor_outlen);
#endif 


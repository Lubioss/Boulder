
#ifndef ReplacementFor_DEFINITIONS_H
#define ReplacementFor_DEFINITIONS_H
#include "ReplacementFor_jsmn.h" 
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <time.h>
#include <atomic>
#include <mutex>
#include <string.h>
#define ReplacementFor_CONST_MES_SIZE_8   8192 
#define ReplacementFor_CONTINUE_POS       (0x554+1895-0xc97)
#define ReplacementFor_K_LEN              (0x18a3+2303-0x2182)
#define ReplacementFor_N_LEN              67108864 
#define ReplacementFor_MAX_SOLS (0x8f+3727-0xf0e)
#define ReplacementFor_NONCES_PER_THREAD  (0xd5d+5950-0x249a)
#define ReplacementFor_MIN_FREE_MEMORY    2200000000
#define ReplacementFor_MIN_FREE_MEMORY_PREHASH 7300000000
#define ReplacementFor_NUM_SIZE_8         (0xa45+2559-0x1424)
#define ReplacementFor_PK_SIZE_8          (0x521+5798-0x1ba6)
#define ReplacementFor_NONCE_SIZE_8       (0x49b+3396-0x11d7)
#define ReplacementFor_HEIGHT_SIZE       (0x4e8+6721-0x1f25)
#define ReplacementFor_INDEX_SIZE_8       (0x129f+1200-0x174b)
#define ReplacementFor_BUF_SIZE_8         (0x1aa6+153-0x1abf)
#define ReplacementFor_qhi_s              \
"\x30\x78\x46\x46\x46\x46\x46\x46\x46\x46"
#define ReplacementFor_q4_s               \
"\x30\x78\x46\x46\x46\x46\x46\x46\x46\x45"
#define ReplacementFor_q3_s               \
"\x30\x78\x42\x41\x41\x45\x44\x43\x45\x36"
#define ReplacementFor_q2_s               \
"\x30\x78\x41\x46\x34\x38\x41\x30\x33\x42"
#define ReplacementFor_q1_s               \
"\x30\x78\x42\x46\x44\x32\x35\x45\x38\x43"
#define ReplacementFor_q0_s               \
"\x30\x78\x44\x30\x33\x36\x34\x31\x34\x31"
#define ReplacementFor_Q3                 0xffffffffffffffff
#define ReplacementFor_Q2                 0xfffffffffffffffe
#define ReplacementFor_Q1                 0xbaaedce6af48a03b
#define ReplacementFor_Q0                 0xbfd25e8cd0364141
#define ReplacementFor_MAX_POST_RETRIES   (0x46a+5673-0x1a8e)
#define ReplacementFor_MAX_URL_SIZE       (0x20a6+1185-0x2147)
#define ReplacementFor_JSON_CAPACITY      (0x59a+5345-0x197b)
#define ReplacementFor_MAX_JSON_CAPACITY  8192
#define ReplacementFor_REQ_LEN           (0xec3+952-0x1270)
#define ReplacementFor_MES_POS            (0x335+556-0x55f)
#define ReplacementFor_BOUND_POS          (0x3e9+8722-0x25f7)
#define ReplacementFor_PK_POS             (0x585+4511-0x171e)
#define ReplacementFor_CONF_LEN           (0x1b34+2301-0x241c)
#define ReplacementFor_SEED_POS           (0x419+405-0x5ac)
#define ReplacementFor_NODE_POS           (0xc1f+1055-0x103a)
#define ReplacementFor_KEEP_POS           (0xe76+5140-0x2284)
#define ReplacementFor_ERROR_STAT         "\x73\x74\x61\x74"
#define ReplacementFor_ERROR_ALLOC        \
"\x48\x6f\x73\x74\x20\x6d\x65\x6d\x6f\x72\x79\x20\x61\x6c\x6c\x6f\x63\x61\x74\x69\x6f\x6e"
#define ReplacementFor_ERROR_IO           "\x49\x2f\x4f"
#define ReplacementFor_ERROR_CURL         "\x43\x75\x72\x6c"
#define ReplacementFor_ERROR_OPENSSL      "\x4f\x70\x65\x6e\x53\x53\x4c"
#define ReplacementFor_NUM_SIZE_4         (ReplacementFor_NUM_SIZE_8 << \
(0xfc+9670-0x26c1))
#define ReplacementFor_NUM_SIZE_32        (ReplacementFor_NUM_SIZE_8 >> \
(0x1076+1175-0x150b))
#define ReplacementFor_NUM_SIZE_64        (ReplacementFor_NUM_SIZE_8 >> \
(0xbef+917-0xf81))
#define ReplacementFor_NUM_SIZE_32_BLOCK  ((0x9f5+320-0xb34) + (\
ReplacementFor_NUM_SIZE_32 - (0x92+248-0x189)) / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_NUM_SIZE_8_BLOCK   (ReplacementFor_NUM_SIZE_32_BLOCK << \
(0xc3f+3565-0x1a2a))
#define ReplacementFor_ROUND_NUM_SIZE_32  (ReplacementFor_NUM_SIZE_32_BLOCK * \
ReplacementFor_BLOCK_DIM)
#define ReplacementFor_PK_SIZE_4          (ReplacementFor_PK_SIZE_8 << \
(0xbaa+294-0xccf))
#define ReplacementFor_PK_SIZE_32_BLOCK   ((0x878+794-0xb91) + \
ReplacementFor_NUM_SIZE_32 / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_PK_SIZE_8_BLOCK    (ReplacementFor_PK_SIZE_32_BLOCK << \
(0xb4c+593-0xd9b))
#define ReplacementFor_ROUND_PK_SIZE_32   (ReplacementFor_PK_SIZE_32_BLOCK * \
ReplacementFor_BLOCK_DIM)
#define ReplacementFor_COUPLED_PK_SIZE_32 (((ReplacementFor_PK_SIZE_8 << \
(0x198+4643-0x13ba)) + (0x2a3+8207-0x22af)) >> (0x1200+1555-0x1811))
#define ReplacementFor_NONCE_SIZE_4       (ReplacementFor_NONCE_SIZE_8 << \
(0x10dc+2674-0x1b4d))
#define ReplacementFor_NONCE_SIZE_32      (ReplacementFor_NONCE_SIZE_8 >> \
(0x3f9+2556-0xdf3))
struct ReplacementFor_ctx_t;
#define ReplacementFor_DATA_SIZE_8\
                                                            \
(                                                                              \
    ((0x896+4684-0x1ae1) + ((0x260+5333-0x1733) * ReplacementFor_PK_SIZE_8 + \
(0xb0f+2935-0x1684) + (0x10d6+2846-0x1bf1) * ReplacementFor_NUM_SIZE_8 + sizeof(\
ReplacementFor_ctx_t) - (0x19e1+2263-0x22b7)) / ReplacementFor_BLOCK_DIM) \
    * ReplacementFor_BLOCK_DIM\
                                                                \
)
#define ReplacementFor_WORKSPACE_SIZE_8\
                                                       \
(                                                                              \
    (                                                                          \
        (uint32_t)((ReplacementFor_N_LEN << (0x1df+482-0x3c0)) + \
(0xac8+1531-0x10c2)) * ReplacementFor_INDEX_SIZE_8                            \
        > ReplacementFor_NONCES_PER_ITER * (ReplacementFor_NUM_SIZE_8  + (\
ReplacementFor_INDEX_SIZE_8 << (0x13dd+1864-0x1b24))) + \
ReplacementFor_INDEX_SIZE_8 \
    )?                                                                         \
    (uint32_t)((ReplacementFor_N_LEN << (0xea0+5622-0x2495)) + (0x13a+882-0x4ab)\
) * ReplacementFor_INDEX_SIZE_8:                               \
    ReplacementFor_NONCES_PER_ITER * (ReplacementFor_NUM_SIZE_8  + (\
ReplacementFor_INDEX_SIZE_8 << (0x37c+8352-0x241b))) + \
ReplacementFor_INDEX_SIZE_8       \
)
#define ReplacementFor_NP_SIZE_32_BLOCK   ((0xc70+279-0xd86) + (\
ReplacementFor_NUM_SIZE_32 << (0x4ec+5944-0x1c23)) / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_NP_SIZE_8_BLOCK    (ReplacementFor_NP_SIZE_32_BLOCK << \
(0x16bf+2359-0x1ff4))
#define ReplacementFor_ROUND_NP_SIZE_32   (ReplacementFor_NP_SIZE_32_BLOCK * \
ReplacementFor_BLOCK_DIM)
#define ReplacementFor_PNP_SIZE_32_BLOCK\
                                                      \
((0xd46+1768-0x142d) + (ReplacementFor_COUPLED_PK_SIZE_32 + \
ReplacementFor_NUM_SIZE_32 - (0x1473+489-0x165b)) / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_PNP_SIZE_8_BLOCK   (ReplacementFor_PNP_SIZE_32_BLOCK << \
(0x1725+3650-0x2565))
#define ReplacementFor_ROUND_PNP_SIZE_32  (ReplacementFor_PNP_SIZE_32_BLOCK * \
ReplacementFor_BLOCK_DIM)
#define ReplacementFor_NC_SIZE_32_BLOCK\
                                                       \
((0x463+8701-0x265f) + (ReplacementFor_NUM_SIZE_32 + sizeof(ReplacementFor_ctx_t\
) - (0xd08+4339-0x1dfa)) / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_NC_SIZE_8_BLOCK    (ReplacementFor_NC_SIZE_32_BLOCK << \
(0x716+3618-0x1536))
#define ReplacementFor_ROUND_NC_SIZE_32   (ReplacementFor_NC_SIZE_32_BLOCK * \
ReplacementFor_BLOCK_DIM)
#define ReplacementFor_N_MASK             (ReplacementFor_N_LEN - \
(0xa50+7334-0x26f5))
#define ReplacementFor_THREADS_PER_ITER   (ReplacementFor_NONCES_PER_ITER / \
ReplacementFor_NONCES_PER_THREAD)
typedef unsigned int ReplacementFor_uint_t;typedef enum{
ReplacementFor_STATE_CONTINUE=(0x3c6+7748-0x220a),ReplacementFor_STATE_KEYGEN=
(0x72a+5359-0x1c18),ReplacementFor_STATE_REHASH=(0x12a+773-0x42d),
ReplacementFor_STATE_INTERRUPT=(0x865+6624-0x2242)}ReplacementFor_state_t;struct
 ReplacementFor_info_t{std::mutex ReplacementFor_info_mutex;uint8_t 
ReplacementFor_AlgVer;uint8_t ReplacementFor_bound[ReplacementFor_NUM_SIZE_8];
uint8_t ReplacementFor_mes[ReplacementFor_NUM_SIZE_8];uint8_t ReplacementFor_sk[
ReplacementFor_NUM_SIZE_8];uint8_t ReplacementFor_pk[ReplacementFor_PK_SIZE_8];
char ReplacementFor_skstr[ReplacementFor_NUM_SIZE_4];char ReplacementFor_pkstr[
ReplacementFor_PK_SIZE_4+(0x5d3+6479-0x1f21)];int ReplacementFor_keepPrehash;
char ReplacementFor_to[ReplacementFor_MAX_URL_SIZE];char ReplacementFor_endJob[
ReplacementFor_MAX_URL_SIZE];bool ReplacementFor_doJob;char ReplacementFor_pool[
ReplacementFor_MAX_URL_SIZE];uint8_t ReplacementFor_Hblock[
ReplacementFor_HEIGHT_SIZE];char ReplacementFor_stratumMode;uint8_t 
ReplacementFor_extraNonceStart[ReplacementFor_NONCE_SIZE_8];uint8_t 
ReplacementFor_extraNonceEnd[ReplacementFor_NONCE_SIZE_8];std::atomic<
ReplacementFor_uint_t>ReplacementFor_blockId;};struct ReplacementFor_json_t{
size_t ReplacementFor_cap;size_t len;char*ReplacementFor_ptr;
ReplacementFor_jsmntok_t*ReplacementFor_toks;ReplacementFor_json_t(const int 
strlen,const int ReplacementFor_toklen);ReplacementFor_json_t(const 
ReplacementFor_json_t&ReplacementFor_newjson);~ReplacementFor_json_t(void);void 
Reset(void){len=(0x1262+1721-0x191b);return;}int ReplacementFor_GetTokenStartPos
(const int pos){return ReplacementFor_toks[pos].ReplacementFor_start;}int 
ReplacementFor_GetTokenEndPos(const int pos){return ReplacementFor_toks[pos].end
;}int ReplacementFor_GetTokenLen(const int pos){return ReplacementFor_toks[pos].
end-ReplacementFor_toks[pos].ReplacementFor_start;}char*
ReplacementFor_GetTokenStart(const int pos){return ReplacementFor_ptr+
ReplacementFor_toks[pos].ReplacementFor_start;}char*ReplacementFor_GetTokenEnd(
const int pos){return ReplacementFor_ptr+ReplacementFor_toks[pos].end;}int 
ReplacementFor_jsoneq(const int pos,const char*str);};struct 
ReplacementFor_ctx_t{uint8_t b[ReplacementFor_BUF_SIZE_8];uint64_t 
ReplacementFor_h[(0x16a9+1046-0x1ab7)];uint64_t t[(0x1455+3867-0x236e)];uint32_t
 c;};struct ReplacementFor_uctx_t{uint64_t ReplacementFor_h[(0x12aa+4845-0x258f)
];uint64_t t[(0x14fa+1760-0x1bd8)];};
#define ReplacementFor_CTX_SIZE sizeof(ReplacementFor_ctx_t)
#define ReplacementFor_B2B_IV(ReplacementFor_v)\
                                                              \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_v))[(0x9e3+5228-0x1e4f)] = 0x6a09e667f3bcc908;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[(0x5d6+8352-0x2675)] = 0xbb67ae8584caa73b;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[(0x1043+201-0x110a)] = 0x3c6ef372fe94f82b;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[(0x41d+7340-0x20c6)] = 0xa54ff53a5f1d36f1;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[(0x415+296-0x539)] = 0x510e527fade682d1;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[(0x3b6+4309-0x1486)] = 0x9b05688c2b3e6c1f;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[(0x80a+49-0x835)] = 0x1f83d9abfb41bd6b;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[(0x136f+1794-0x1a6a)] = 0x5be0cd19137e2179;\
                                 \
}                                                                              \
while ((0x34d+8085-0x22e2))
#define ReplacementFor_ROTR64(x, y) (((x) >> (y)) ^ ((x) << ((0x80+3374-0xd6e) -\
 (y))))
#define ReplacementFor_B2B_G(ReplacementFor_v, a, b, c, ReplacementFor_d, x, y)\
                                             \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_v))[a] += ((uint64_t *)(ReplacementFor_v))[b] +\
 x;                          \
    ((uint64_t *)(ReplacementFor_v))[ReplacementFor_d]\
                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[\
ReplacementFor_d] ^ ((uint64_t *)(ReplacementFor_v))[a], (0x17d0+1418-0x1d3a));\
             \
    ((uint64_t *)(ReplacementFor_v))[c] += ((uint64_t *)(ReplacementFor_v))[\
ReplacementFor_d];                              \
    ((uint64_t *)(ReplacementFor_v))[b]\
                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[b] ^ ((uint64_t\
 *)(ReplacementFor_v))[c], (0x213+3013-0xdc0));             \
    ((uint64_t *)(ReplacementFor_v))[a] += ((uint64_t *)(ReplacementFor_v))[b] +\
 y;                          \
    ((uint64_t *)(ReplacementFor_v))[ReplacementFor_d]\
                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[\
ReplacementFor_d] ^ ((uint64_t *)(ReplacementFor_v))[a], (0xae3+6834-0x2585));\
             \
    ((uint64_t *)(ReplacementFor_v))[c] += ((uint64_t *)(ReplacementFor_v))[\
ReplacementFor_d];                              \
    ((uint64_t *)(ReplacementFor_v))[b]\
                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[b] ^ ((uint64_t\
 *)(ReplacementFor_v))[c], (0xaa6+3559-0x184e));             \
}                                                                              \
while ((0x647+1960-0xdef))
#define ReplacementFor_B2B_MIX(ReplacementFor_v, m)\
                                                          \
do                                                                             \
{                                                                              \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xcf7+6116-0x24db), \
(0x7d5+3559-0x15b8),  (0x1aa+8845-0x242f), (0x17b7+2882-0x22ed), ((uint64_t *)(m\
))[ (0x66d+4051-0x1640)], ((uint64_t *)(m))[ (0x2e8+2315-0xbf2)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x3ba+5795-0x1a5c), \
(0xf5a+767-0x1254),  (0x9e1+51-0xa0b), (0x1387+68-0x13be), ((uint64_t *)(m))[ \
(0x88b+5013-0x1c1e)], ((uint64_t *)(m))[ (0xe54+882-0x11c3)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x34d+1976-0xb03), \
(0x114+6357-0x19e3), (0x9e9+714-0xca9), (0xea2+4881-0x21a5), ((uint64_t *)(m))[ \
(0x192f+192-0x19eb)], ((uint64_t *)(m))[ (0x122a+2038-0x1a1b)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x5f4+6870-0x20c7), \
(0x3b9+859-0x70d), (0x916+2282-0x11f5), (0x1ee9+1371-0x2435), ((uint64_t *)(m))[\
 (0xaba+6333-0x2371)], ((uint64_t *)(m))[ (0x34+8539-0x2188)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1b9+60-0x1f5), (0xe57+5850-0x252c)\
, (0xd3c+1693-0x13cf), (0xbe5+3279-0x18a5), ((uint64_t *)(m))[ \
(0xe3+8177-0x20cc)], ((uint64_t *)(m))[ (0x9aa+685-0xc4e)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x85b+4963-0x1bbd), \
(0x811+4212-0x187f), (0xb4c+467-0xd14), (0x1ef+549-0x408), ((uint64_t *)(m))[\
(0x1b1+2539-0xb92)], ((uint64_t *)(m))[(0x4d6+4921-0x1804)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1192+3866-0x20aa), \
(0x938+802-0xc53),  (0x31a+1359-0x861), (0x22b4+86-0x22fd), ((uint64_t *)(m))[\
(0xa16+2317-0x1317)], ((uint64_t *)(m))[(0xa56+3363-0x176c)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xd68+4516-0x1f09), \
(0xa6c+3799-0x193f),  (0x74a+2924-0x12ad), (0x1ebd+171-0x1f5a), ((uint64_t *)(m)\
)[(0xd7b+6085-0x2532)], ((uint64_t *)(m))[(0x10a8+3950-0x2007)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x200+6702-0x1c2e), \
(0x11b0+430-0x135a),  (0x13a3+1850-0x1ad5), (0xd8c+2393-0x16d9), ((uint64_t *)(m\
))[(0x5eb+1678-0xc6b)], ((uint64_t *)(m))[(0x1701+2807-0x21ee)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xc2+2746-0xb7b), \
(0x9c7+4267-0x1a6d),  (0x7af+6473-0x20ef), (0x100+5011-0x1486), ((uint64_t *)(m)\
)[ (0xd43+2843-0x185a)], ((uint64_t *)(m))[ (0x8af+5905-0x1fb8)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x965+6094-0x2131), \
(0xa5c+7194-0x2670), (0x1f8f+110-0x1ff3), (0x168b+1645-0x1cea), ((uint64_t *)(m)\
)[ (0x25+2348-0x948)], ((uint64_t *)(m))[(0x3c3+3583-0x11b3)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x8c9+2325-0x11db), \
(0x23a1+220-0x2476), (0x1db+5949-0x190d), (0xaa1+5184-0x1ed2), ((uint64_t *)(m))\
[(0x1319+1453-0x18b9)], ((uint64_t *)(m))[ (0x1416+4031-0x23cf)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x64+755-0x357), \
(0x13b2+1800-0x1ab5), (0x926+4011-0x18c7), (0x206d+849-0x23af), ((uint64_t *)(m)\
)[ (0x165f+290-0x1780)], ((uint64_t *)(m))[(0xc51+4384-0x1d65)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x21e7+352-0x2346), \
(0xf1f+2350-0x1847), (0x619+4473-0x1787), (0x7e4+3383-0x150f), ((uint64_t *)(m))\
[ (0xbd4+5319-0x209b)], ((uint64_t *)(m))[ (0x1289+3382-0x1fbd)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x8+441-0x1bf), (0x4d0+8165-0x24ae),\
  (0x115c+1886-0x18b2), (0x10b5+4980-0x241c), ((uint64_t *)(m))[\
(0x145b+1213-0x190d)], ((uint64_t *)(m))[ (0x1c29+2483-0x25d5)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x318+2676-0xd89), \
(0xa9f+5102-0x1e89),  (0x17f6+2315-0x20f8), (0x207d+1643-0x26da), ((uint64_t *)(\
m))[ (0x550+1658-0xbc5)], ((uint64_t *)(m))[ (0x2ba+3063-0xeae)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x19e0+2386-0x2332), \
(0x214d+68-0x218d),  (0x157d+1023-0x1974), (0x21a+5381-0x1713), ((uint64_t *)(m)\
)[(0xae5+6456-0x2412)], ((uint64_t *)(m))[ (0x26f+7451-0x1f82)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xf2f+520-0x1136), \
(0x4b5+2063-0xcbf),  (0x418+5231-0x187e), (0x1257+1531-0x1845), ((uint64_t *)(m)\
)[(0x138d+3842-0x2283)], ((uint64_t *)(m))[ (0x891+2635-0x12dc)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x6bc+1146-0xb34), \
(0x117+1282-0x613), (0x1a9b+660-0x1d25), (0x997+2049-0x118a), ((uint64_t *)(m))[\
 (0x18d2+1923-0x2050)], ((uint64_t *)(m))[ (0x110c+2169-0x1983)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x313+5107-0x1703), \
(0x1925+2600-0x2346), (0x54+9762-0x266b), (0x3f1+7829-0x2277), ((uint64_t *)(m))\
[(0xd9+857-0x423)], ((uint64_t *)(m))[(0x46f+2666-0xecc)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x168c+4183-0x26e3), \
(0xf74+5975-0x26c6), (0x140+6036-0x18ca), (0x809+867-0xb5d), ((uint64_t *)(m))[\
(0x1583+2144-0x1dd9)], ((uint64_t *)(m))[(0x7ef+3010-0x13a3)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1170+346-0x12c9), \
(0xbdc+4143-0x1c05), (0x5eb+7438-0x22ee), (0x51+5209-0x149e), ((uint64_t *)(m))[\
 (0x850+2323-0x1160)], ((uint64_t *)(m))[ (0xbd4+240-0xcbe)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x53b+546-0x75b), (0x7e8+844-0xb2d),\
  (0x1986+109-0x19eb), (0x8f8+5525-0x1e80), ((uint64_t *)(m))[ \
(0x14e1+2079-0x1cf9)], ((uint64_t *)(m))[ (0x198+9457-0x2688)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x31c+6457-0x1c52), \
(0x12c9+1413-0x184a),  (0x18d+6431-0x1aa3), (0x3d2+413-0x561), ((uint64_t *)(m))\
[ (0xba2+5057-0x1f5a)], ((uint64_t *)(m))[ (0x1c1+4068-0x11a1)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x178+325-0x2bd), \
(0x1189+4030-0x2143),  (0x18d+5891-0x1888), (0x207f+1645-0x26e0), ((uint64_t *)(\
m))[ (0x1062+4783-0x230a)], ((uint64_t *)(m))[ (0xf69+4813-0x222d)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x538+6897-0x2028), \
(0x940+5967-0x208a),  (0x1823+1947-0x1fb5), (0x926+985-0xcf2), ((uint64_t *)(m))\
[ (0x9d0+3387-0x1708)], ((uint64_t *)(m))[ (0x19d7+1650-0x2048)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x9db+993-0xdba), \
(0xbdc+1633-0x1237), (0x1330+1215-0x17e5), (0xe9d+3142-0x1ad5), ((uint64_t *)(m)\
)[(0xfe4+1255-0x14be)], ((uint64_t *)(m))[(0x1a1b+928-0x1daf)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x2028+342-0x217b), \
(0xc2b+358-0xd8a), (0x372+9081-0x26e0), (0x9b2+1041-0xdb4), ((uint64_t *)(m))[\
(0x4ed+4113-0x14f3)], ((uint64_t *)(m))[(0xe18+2604-0x1836)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1e62+638-0x20e0), \
(0xbaf+5644-0x21b6), (0xbcc+4191-0x1c21), (0x17a2+209-0x1864), ((uint64_t *)(m))\
[ (0x15d7+509-0x17d2)], ((uint64_t *)(m))[ (0x1070+358-0x11d0)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xebf+3620-0x1ce2), \
(0x564+2654-0xfbc), (0xa6f+7274-0x26ce), (0x7eb+7752-0x2627), ((uint64_t *)(m))[\
 (0x1e5+8333-0x226d)], ((uint64_t *)(m))[(0x129d+2162-0x1b05)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1a0+8643-0x2361), \
(0x743+3697-0x15ad),  (0x84a+6329-0x20fb), (0x17e6+1825-0x1efa), ((uint64_t *)(m\
))[ (0x876+7483-0x25ad)], ((uint64_t *)(m))[ (0x226d+110-0x22db)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xc7+4119-0x10db), \
(0x176b+690-0x1a19),  (0xd04+2553-0x16f4), (0x8e8+6324-0x218e), ((uint64_t *)(m)\
)[(0x7af+5306-0x1c5a)], ((uint64_t *)(m))[ (0xeab+1801-0x15ac)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x102f+1727-0x16ee), \
(0x5c2+5874-0x1cb0),  (0x1007+5442-0x2541), (0x5b+8783-0x229e), ((uint64_t *)(m)\
)[ (0x94a+2835-0x1454)], ((uint64_t *)(m))[ (0x21+3143-0xc68)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xb93+1684-0x1226), \
(0xf22+1537-0x151e),  (0x1a40+394-0x1bc1), (0xd13+1550-0x1314), ((uint64_t *)(m)\
)[ (0x856+4972-0x1bbd)], ((uint64_t *)(m))[ (0xad+7050-0x1c30)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x116d+1559-0x1782), \
(0x1574+185-0x1627), (0xd2d+3063-0x191a), (0x4bc+1669-0xb33), ((uint64_t *)(m))[\
 (0x51c+5141-0x192f)], ((uint64_t *)(m))[ (0x8db+5991-0x203e)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xa98+764-0xd91), (0x78b+1793-0xe85)\
, (0x1136+1685-0x17c0), (0x542+8182-0x2529), ((uint64_t *)(m))[(0x5d9+268-0x6db)\
], ((uint64_t *)(m))[(0x2d4+369-0x436)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x45+9011-0x2378), \
(0xdf+8732-0x22f6), (0x54f+6908-0x2041), (0x225+3241-0xebf), ((uint64_t *)(m))[\
(0x65a+5500-0x1bc8)], ((uint64_t *)(m))[ (0x39d+2574-0xdaa)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1474+2909-0x1fd0), \
(0x3e2+6838-0x1e92), (0x11a5+4904-0x24c2), (0x134d+319-0x1480), ((uint64_t *)(m)\
)[(0xae9+5344-0x1fbe)], ((uint64_t *)(m))[(0x66a+7139-0x2241)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1115+1481-0x16dc), \
(0x16a9+3951-0x2611),  (0x312+603-0x565), (0x83f+4298-0x18fc), ((uint64_t *)(m))\
[ (0x789+2153-0xfec)], ((uint64_t *)(m))[ (0x156b+3466-0x22ed)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x124+5773-0x17ae), \
(0x832+7317-0x24c3),  (0xc02+6649-0x25f2), (0x1861+620-0x1abf), ((uint64_t *)(m)\
)[ (0x426+3613-0x1240)], ((uint64_t *)(m))[(0x891+1391-0xdf3)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x29b+5109-0x1690), \
(0xb7c+1625-0x11d1),  (0x1501+1839-0x1c28), (0xeed+30-0xeff), ((uint64_t *)(m))[\
 (0x194+7444-0x1ea6)], ((uint64_t *)(m))[(0x1d20+1201-0x21c5)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xbe3+2681-0x165b), \
(0xf24+1396-0x1493),  (0xeaa+3764-0x1d55), (0x19c8+3130-0x25f5), ((uint64_t *)(m\
))[ (0x4a5+7318-0x2135)], ((uint64_t *)(m))[(0x961+2508-0x1323)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x495+7489-0x21d4), \
(0x1345+3204-0x1fc3), (0x13f4+4380-0x2506), (0x15b+116-0x1c1), ((uint64_t *)(m))\
[ (0x770+7802-0x25ea)], ((uint64_t *)(m))[(0x1454+2534-0x1e2f)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x454+8034-0x23b3), \
(0x5aa+768-0x8a3), (0xda8+4446-0x1efb), (0x51+1948-0x7de), ((uint64_t *)(m))[ \
(0x145a+3306-0x213c)], ((uint64_t *)(m))[ (0x11f7+1775-0x18e3)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x422+1268-0x916), \
(0x5a4+2208-0xe3f), (0x106d+4299-0x212e), (0x1cdb+1596-0x2308), ((uint64_t *)(m)\
)[ (0x1e14+2196-0x26a4)], ((uint64_t *)(m))[(0xca7+1196-0x1146)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x445+5614-0x1a32), \
(0xb9f+1966-0x1347), (0xc23+397-0xda5), (0x269+4005-0x1202), ((uint64_t *)(m))[ \
(0x613+1676-0xc98)], ((uint64_t *)(m))[ (0x3b+7618-0x1df8)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1370+3287-0x2045), \
(0xe3c+4186-0x1e8f),  (0x14+8389-0x20d1), (0x16a6+2936-0x2211), ((uint64_t *)(m)\
)[(0x588+2244-0xe3d)], ((uint64_t *)(m))[(0x87+6722-0x1abb)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x7c4+6671-0x21d0), \
(0x1ef3+157-0x1f8c),  (0x12+5962-0x1753), (0xff+4896-0x1411), ((uint64_t *)(m))[\
 (0x346+4368-0x1455)], ((uint64_t *)(m))[ (0x793+5054-0x1b48)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1923+2884-0x2467), \
(0xc71+736-0xf4d),  (0xb6+4561-0x127f), (0x1971+3376-0x2695), ((uint64_t *)(m))[\
(0x1a67+3136-0x269b)], ((uint64_t *)(m))[ (0x27d+9175-0x264f)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x120+3219-0xdb2), \
(0x185a+362-0x19bf),  (0xd86+805-0x10a2), (0x66b+7046-0x21e4), ((uint64_t *)(m))\
[ (0x300+2015-0xade)], ((uint64_t *)(m))[(0xc89+21-0xc8f)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x8df+2203-0x1178), \
(0x1451+3973-0x23d0), (0x1571+3926-0x24bd), (0x867+4699-0x1ab4), ((uint64_t *)(m\
))[(0xe31+2163-0x1696)], ((uint64_t *)(m))[(0x1b87+2641-0x25cb)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x2a1+64-0x2de), \
(0x13f1+3228-0x2086), (0x981+1261-0xe63), (0x904+4463-0x1a64), ((uint64_t *)(m))\
[ (0x1b2+9297-0x25ff)], ((uint64_t *)(m))[(0x760+4920-0x1a8e)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1ec4+547-0x20e7), \
(0x429+7242-0x206e), (0xac9+4183-0x1b16), (0x14a6+1525-0x1a8c), ((uint64_t *)(m)\
)[ (0x9df+5204-0x1e33)], ((uint64_t *)(m))[ (0x230d+143-0x2395)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1d6a+509-0x1f66), \
(0xcb5+2792-0x1797), (0x40c+6329-0x1cba), (0x10a3+3247-0x1d46), ((uint64_t *)(m)\
)[ (0x124d+4112-0x2257)], ((uint64_t *)(m))[ (0xaf9+6174-0x2314)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x2305+53-0x2338), \
(0x1b0f+361-0x1c71),  (0x261+8488-0x2381), (0xe48+4430-0x1f89), ((uint64_t *)(m)\
)[ (0x35d+5897-0x1a5d)], ((uint64_t *)(m))[ (0x247+4099-0x1248)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x368+7466-0x208f), \
(0x1127+5559-0x26da),  (0x5f5+5761-0x1c6d), (0x1f24+946-0x22c8), ((uint64_t *)(m\
))[ (0x59b+8360-0x263b)], ((uint64_t *)(m))[(0x7fb+3869-0x170d)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x25c+5551-0x180b), \
(0x123f+1932-0x19c7),  (0xedc+2865-0x1a05), (0x2ef+8200-0x22eb), ((uint64_t *)(m\
))[(0x21+6409-0x191d)], ((uint64_t *)(m))[(0xc6c+2122-0x14ab)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1024+2021-0x1808), \
(0x1a87+2433-0x2403),  (0x145f+3718-0x22dc), (0xb00+873-0xe5c), ((uint64_t *)(m)\
)[ (0x217c+815-0x24a4)], ((uint64_t *)(m))[(0xd09+173-0xda8)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1f1+8882-0x24a1), \
(0x313+3567-0x10fc), (0xe5d+5866-0x253d), (0x6c3+5104-0x1aa5), ((uint64_t *)(m))\
[(0x1a52+155-0x1ae1)], ((uint64_t *)(m))[ (0xbeb+41-0xc13)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x15d2+1135-0x1a3e), \
(0x1c72+337-0x1dbc), (0x4b0+4097-0x14a6), (0x600+5325-0x1abe), ((uint64_t *)(m))\
[ (0x69c+5136-0x1aa9)], ((uint64_t *)(m))[ (0x1193+350-0x12e8)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1d98+268-0x1ea4), \
(0xa9b+3831-0x198d), (0xa5+6625-0x1a7c), (0x11ff+4798-0x24ae), ((uint64_t *)(m))\
[ (0x566+6630-0x1f47)], ((uint64_t *)(m))[ (0x97+3062-0xc8d)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xd50+337-0xea0), \
(0x1159+509-0x1350), (0x1153+2273-0x1a29), (0x210c+352-0x2260), ((uint64_t *)(m)\
)[(0xe67+6164-0x266c)], ((uint64_t *)(m))[ (0x181d+1492-0x1ded)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xa1+8101-0x2044), \
(0x658+4455-0x17b8),  (0x167+6826-0x1c09), (0x137+4633-0x1343), ((uint64_t *)(m)\
)[ (0xcf8+3636-0x1b24)], ((uint64_t *)(m))[ (0xb95+1338-0x10c9)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x41a+5729-0x1a78), \
(0x11c6+1246-0x16a0),  (0x2d0+9075-0x263a), (0x5c6+4428-0x1704), ((uint64_t *)(m\
))[ (0x5c3+4585-0x17aa)], ((uint64_t *)(m))[(0x9af+6657-0x23a6)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x2d7+7576-0x206f), \
(0x781+4947-0x1ad0),  (0xfbf+1180-0x1453), (0x1ea+451-0x3a1), ((uint64_t *)(m))[\
 (0x1350+592-0x159a)], ((uint64_t *)(m))[(0xb05+4137-0x1b1f)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x39c+5503-0x191a), \
(0x1166+5040-0x2511),  (0xf51+2485-0x18fd), (0xdca+4419-0x1f00), ((uint64_t *)(m\
))[(0xefb+480-0x10cd)], ((uint64_t *)(m))[ (0x1a82+870-0x1ddf)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xe2c+1356-0x1376), \
(0x71d+7484-0x2453), (0x1dc2+1760-0x2498), (0x6e8+2448-0x106a), ((uint64_t *)(m)\
)[(0x1a1+340-0x2ea)], ((uint64_t *)(m))[ (0x2da+1065-0x700)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1911+642-0x1b90), \
(0x13c7+3666-0x2212), (0xd57+1317-0x1271), (0x12a7+4550-0x245e), ((uint64_t *)(m\
))[ (0x1a82+141-0x1b0f)], ((uint64_t *)(m))[ (0x2056+552-0x2276)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xcc3+3757-0x1b70), \
(0x17f0+2094-0x2019), (0xf93+2332-0x18a5), (0x5db+5378-0x1ace), ((uint64_t *)(m)\
)[(0xeaa+5171-0x22d1)], ((uint64_t *)(m))[ (0x18f8+2321-0x2207)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x522+7038-0x209f), \
(0xb63+4215-0x1bd4), (0x1a4a+2205-0x22dc), (0xb9b+5978-0x22e9), ((uint64_t *)(m)\
)[(0xc99+2569-0x1695)], ((uint64_t *)(m))[ (0x17d9+1571-0x1df5)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x10b0+3519-0x1e6d), \
(0x297+6892-0x1d7c),  (0x72c+8146-0x26f6), (0x104d+1964-0x17ec), ((uint64_t *)(m\
))[ (0x33c+1993-0xb04)], ((uint64_t *)(m))[ (0xb72+230-0xc54)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x2359+363-0x24c1), \
(0x8cb+7166-0x24c5),  (0xcf8+20-0xd03), (0xf1f+5561-0x24ca), ((uint64_t *)(m))[\
(0xde3+451-0xf9c)], ((uint64_t *)(m))[ (0xc8b+5807-0x2335)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xa09+1826-0x112b), \
(0x19b+5834-0x1861),  (0x234+5877-0x1921), (0x1064+4289-0x2119), ((uint64_t *)(m\
))[(0x19db+95-0x1a30)], ((uint64_t *)(m))[ (0xa8+5200-0x14f6)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1591+3369-0x22b9), \
(0xfe2+5364-0x24d1),  (0x769+4922-0x1a9a), (0x3ff+2980-0xf96), ((uint64_t *)(m))\
[ (0x170a+4054-0x26d8)], ((uint64_t *)(m))[ (0x14f+6343-0x1a12)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x4ea+6241-0x1d49), \
(0xa3d+5441-0x1f78), (0xce7+4096-0x1cdd), (0xcaf+3019-0x186c), ((uint64_t *)(m))\
[ (0x17ed+658-0x1a78)], ((uint64_t *)(m))[ (0x11c0+4934-0x2500)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xd3b+5803-0x23e3), \
(0x55d+4981-0x18cb), (0xc48+1937-0x13ce), (0x71+5459-0x15b5), ((uint64_t *)(m))[\
 (0xd29+1553-0x1339)], ((uint64_t *)(m))[ (0x14bd+2342-0x1dde)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x14cd+560-0x16fd), \
(0xb5b+6239-0x23b5), (0x1701+2662-0x215d), (0xa12+2939-0x157e), ((uint64_t *)(m)\
)[(0x349+4658-0x156c)], ((uint64_t *)(m))[(0x1ecb+980-0x2294)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x302+8684-0x24ed), \
(0x3c2+3598-0x11ca), (0xfc4+2102-0x17ef), (0x11a6+975-0x1569), ((uint64_t *)(m))\
[ (0x1663+1064-0x1a82)], ((uint64_t *)(m))[(0x1654+3197-0x22c3)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xa3b+3059-0x162c), \
(0x5eb+4325-0x16c9),  (0x4bb+7690-0x22bd), (0x23a6+29-0x23b6), ((uint64_t *)(m))\
[ (0x1c14+2572-0x261d)], ((uint64_t *)(m))[(0x753+6871-0x221e)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x12c2+1536-0x18bf), \
(0x683+6743-0x20d6),  (0x5ad+1624-0xbfc), (0x59d+1871-0xcde), ((uint64_t *)(m))[\
(0x7f6+323-0x92c)], ((uint64_t *)(m))[ (0x17e6+2076-0x2002)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x9ef+672-0xc8f), (0x4+8052-0x1f74),\
  (0x2080+1048-0x2490), (0xd7a+3508-0x1b22), ((uint64_t *)(m))[ \
(0x1e00+753-0x20f1)], ((uint64_t *)(m))[ (0x841+1754-0xf1a)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xd6a+2216-0x1611), \
(0x13a9+2424-0x1d1c),  (0xb82+4621-0x1d86), (0x4d7+2303-0xdc9), ((uint64_t *)(m)\
)[ (0x218+8246-0x224c)], ((uint64_t *)(m))[ (0x1219+1128-0x167e)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x2e0+5804-0x198a), \
(0x1d71+1809-0x247c), (0xc53+941-0xff6), (0x5fc+6390-0x1ee4), ((uint64_t *)(m))[\
 (0x1240+749-0x1529)], ((uint64_t *)(m))[ (0xa00+1121-0xe5c)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x122a+3215-0x1eb6), \
(0x343+6876-0x1e18), (0x390+4284-0x1441), (0x59d+1043-0x9a1), ((uint64_t *)(m))[\
 (0x2434+371-0x25a1)], ((uint64_t *)(m))[ (0x1e67+6-0x1e66)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x897+652-0xb23), \
(0x179d+1193-0x1c41), (0x488+4226-0x1500), (0x264+485-0x43a), ((uint64_t *)(m))[\
 (0x1ffb+833-0x2334)], ((uint64_t *)(m))[ (0x130f+5066-0x26d0)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x21f4+1259-0x26de), \
(0x1b6+289-0x2d1), (0x639+4558-0x17fc), (0xd97+4768-0x202b), ((uint64_t *)(m))[\
(0x9cf+6968-0x24fd)], ((uint64_t *)(m))[(0x110b+3467-0x1e8b)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1a2f+253-0x1b2a), \
(0xc8a+4133-0x1ca8),  (0x13f0+2414-0x1d56), (0x4f4+5002-0x1871), ((uint64_t *)(m\
))[(0x1552+4517-0x26eb)], ((uint64_t *)(m))[(0x1746+2408-0x20a1)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x9f+37-0xc1), (0x32f+438-0x4e1),  \
(0x73d+3766-0x15ea), (0x495+5094-0x186d), ((uint64_t *)(m))[(0x15e6+1879-0x1d2f)\
], ((uint64_t *)(m))[(0x9dd+3347-0x16e1)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1da+7279-0x1e49), \
(0x9ad+120-0xa21),  (0x54f+7667-0x233a), (0x49b+7365-0x2154), ((uint64_t *)(m))[\
(0x2181+437-0x2328)], ((uint64_t *)(m))[(0x26c+3580-0x105e)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xacb+6092-0x2296), \
(0x911+5846-0x1fe2),  (0x419+2736-0xec0), (0x183d+2886-0x2376), ((uint64_t *)(m)\
)[ (0xfab+5547-0x2552)], ((uint64_t *)(m))[ (0x622+6163-0x1e2d)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1684+552-0x18aa), \
(0xaef+5993-0x2252), (0x6a+4353-0x1161), (0x45c+3801-0x1327), ((uint64_t *)(m))[\
 (0x20f+627-0x479)], ((uint64_t *)(m))[(0xad9+6159-0x22d9)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x16fd+408-0x1892), \
(0x15df+3359-0x22f7), (0x82f+494-0xa12), (0xb70+2963-0x16f4), ((uint64_t *)(m))[\
(0x1080+948-0x1427)], ((uint64_t *)(m))[ (0x476+5953-0x1bb1)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x1d75+48-0x1da5), \
(0x104c+5303-0x24fe), (0x1247+1447-0x17e4), (0xcd2+4067-0x1ca6), ((uint64_t *)(m\
))[ (0xa5d+5172-0x1e90)], ((uint64_t *)(m))[(0xb41+6358-0x240b)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x416+96-0x475), (0xdff+3151-0x1a48)\
, (0x502+6332-0x1db3), (0x11cf+2860-0x1cef), ((uint64_t *)(m))[ \
(0x989+6750-0x23e7)], ((uint64_t *)(m))[ (0xadf+6040-0x2275)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0x65c+936-0xa02), \
(0x3c4+5302-0x1873),  (0x50b+5586-0x1ad5), (0x1596+1411-0x1b0c), ((uint64_t *)(m\
))[(0x6bd+4968-0x1a1a)], ((uint64_t *)(m))[ (0x8c0+5437-0x1df6)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (0xa11+2756-0x14d2), \
(0x1145+1151-0x15c0),  (0xd22+4803-0x1fdc), (0x25a3+107-0x2600), ((uint64_t *)(m\
))[ (0xd83+951-0x1135)], ((uint64_t *)(m))[ (0x105+3171-0xd65)]);      \
}                                                                              \
while ((0xb0c+3344-0x181c))
#define ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux)\
                                                     \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_aux))[(0x2f5+7484-0x2031)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x1c55+2459-0x25f0)];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[(0x1999+2704-0x2428)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x706+3121-0x1336)];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[(0xcac+4211-0x1d1d)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x15a7+3743-0x2444)];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[(0x3c6+7555-0x2146)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0xdff+6141-0x25f9)];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[(0xae8+917-0xe79)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x738+4177-0x1785)];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[(0x14da+3582-0x22d3)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x66a+6856-0x212d)];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[(0x207c+1321-0x259f)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x1bf+2123-0xa04)];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[(0x24c0+313-0x25f2)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x102f+443-0x11e3)];\
                           \
                                                                               \
    ReplacementFor_B2B_IV(ReplacementFor_aux + (0x1852+451-0x1a0d));\
                                                           \
                                                                               \
    ((uint64_t *)(ReplacementFor_aux))[(0x57f+6040-0x1d0b)] ^= ((\
ReplacementFor_ctx_t *)(ctx))->t[(0x12b8+3512-0x2070)];                         \
    ((uint64_t *)(ReplacementFor_aux))[(0x32c+4039-0x12e6)] ^= ((\
ReplacementFor_ctx_t *)(ctx))->t[(0xfb6+1727-0x1674)];                         \
}                                                                              \
while ((0x10bc+5702-0x2702))
#define ReplacementFor_CAST(x) (((union { ReplacementFor___typeof__(x) a; \
uint64_t b; })x).b)
#define ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux)\
                                                    \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_aux))[(0x182a+914-0x1bac)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ (0x1ae4+1193-0x1f8d)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0xc0d+3282-0x18ce)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ (0x12fb+5049-0x26b3)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x477+8011-0x23b0)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ (0xb18+2493-0x14d3)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x66d+1100-0xaa6)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ (0x236+4811-0x14fe)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x1628+125-0x1691)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ (0x25b+371-0x3ca)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x1ab5+1937-0x2231)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ (0x1622+3437-0x238a)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x8f3+6732-0x2329)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ (0xd63+4378-0x1e77)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x20a9+178-0x2144)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ (0xa6c+2917-0x15ca)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0xcc3+3051-0x1896)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ (0x1aea+1599-0x2121)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x34b+4929-0x1673)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ (0x94+9299-0x24de)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x1e2a+1376-0x2370)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[(0x1eb+3373-0xf0e)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0xd7+6559-0x1a5b)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[(0x1678+364-0x17d9)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x558+4663-0x1773)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[(0xc5+500-0x2ad)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x1158+342-0x1291)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[(0xa0d+4896-0x1d20)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x8ea+6107-0x20a7)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[(0x25f+5057-0x1612)];         \
    ((uint64_t *)(ReplacementFor_aux))[(0x472+3145-0x109c)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[(0x198+2584-0xba1)];         \
                                                                               \
    ReplacementFor_B2B_MIX(ReplacementFor_aux, ReplacementFor_aux + \
(0x976+2880-0x14a6));                                                    \
                                                                               \
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0xa+127-0x89)] ^= ((\
uint64_t *)(ReplacementFor_aux))[(0x163c+3007-0x21fb)] ^ ((uint64_t *)(\
ReplacementFor_aux))[ (0x45f+3699-0x12ca)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x113b+3980-0x20c6)] ^= (\
(uint64_t *)(ReplacementFor_aux))[(0x1baf+1271-0x20a5)] ^ ((uint64_t *)(\
ReplacementFor_aux))[ (0x1b3a+1342-0x206f)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x15c5+3342-0x22d1)] ^= (\
(uint64_t *)(ReplacementFor_aux))[(0x4dc+8406-0x25b0)] ^ ((uint64_t *)(\
ReplacementFor_aux))[(0x81d+3692-0x167f)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x14c7+3469-0x2251)] ^= (\
(uint64_t *)(ReplacementFor_aux))[(0x113a+3291-0x1e12)] ^ ((uint64_t *)(\
ReplacementFor_aux))[(0x16b0+3122-0x22d7)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x1820+2094-0x204a)] ^= (\
(uint64_t *)(ReplacementFor_aux))[(0xd27+4468-0x1e97)] ^ ((uint64_t *)(\
ReplacementFor_aux))[(0x275+4391-0x1390)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0x3f9+1389-0x961)] ^= ((\
uint64_t *)(ReplacementFor_aux))[(0x1e8+6773-0x1c58)] ^ ((uint64_t *)(\
ReplacementFor_aux))[(0x1eb4+502-0x209d)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0xb48+1819-0x125d)] ^= ((\
uint64_t *)(ReplacementFor_aux))[(0x19bf+818-0x1ceb)] ^ ((uint64_t *)(\
ReplacementFor_aux))[(0x1ad4+1701-0x216b)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(0xc03+1189-0x10a1)] ^= ((\
uint64_t *)(ReplacementFor_aux))[(0x328+2158-0xb8f)] ^ ((uint64_t *)(\
ReplacementFor_aux))[(0x2227+1016-0x2610)];\
}                                                                              \
while ((0x57d+5128-0x1985))
#define ReplacementFor_HOST_B2B_H(ctx, ReplacementFor_aux)\
                                                   \
do                                                                             \
{                                                                              \
    ((ReplacementFor_ctx_t *)(ctx))->t[(0x217+8248-0x224f)] += \
ReplacementFor_BUF_SIZE_8;                                      \
    ((ReplacementFor_ctx_t *)(ctx))->t[(0xbe1+5938-0x2312)] += \
(0x1612+3020-0x21dd) - !(((ReplacementFor_ctx_t *)(ctx))->t[(0xdf2+4624-0x2002)]\
 < ReplacementFor_BUF_SIZE_8);      \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);\
                                                        \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);\
                                                       \
                                                                               \
    ((ReplacementFor_ctx_t *)(ctx))->c = (0x1205+4165-0x224a);\
                                                   \
}                                                                              \
while ((0xbaa+6504-0x2512))
#define ReplacementFor_HOST_B2B_H_LAST(ctx, ReplacementFor_aux)\
                                              \
do                                                                             \
{                                                                              \
    ((ReplacementFor_ctx_t *)(ctx))->t[(0x801+7841-0x26a2)] += ((\
ReplacementFor_ctx_t *)(ctx))->c;                             \
    ((ReplacementFor_ctx_t *)(ctx))->t[(0x885+4468-0x19f8)]\
                                                     \
        += (0x131a+666-0x15b3) - !(((ReplacementFor_ctx_t *)(ctx))->t[\
(0x586+1799-0xc8d)] < ((ReplacementFor_ctx_t *)(ctx))->c);                \
                                                                               \
    while (((ReplacementFor_ctx_t *)(ctx))->c < ReplacementFor_BUF_SIZE_8)\
                                   \
    {                                                                          \
        ((ReplacementFor_ctx_t *)(ctx))->b[((ReplacementFor_ctx_t *)(ctx))->c++]\
 = (0x149+5523-0x16dc);                        \
    }                                                                          \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);\
                                                        \
                                                                               \
    ((uint64_t *)(ReplacementFor_aux))[(0x19b6+1893-0x210d)] = ~((uint64_t *)(\
ReplacementFor_aux))[(0xa9+586-0x2e5)];                        \
                                                                               \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);\
                                                       \
}                                                                              \
while ((0x12ea+1016-0x16e2))
#define ReplacementFor_DEVICE_B2B_H(ctx, ReplacementFor_aux)\
                                                 \
do                                                                             \
{                                                                              \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x31\x32\x38\x3b"\
: "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
(0x22b1+228-0x2395)])  \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
: "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
(0xbaf+2296-0x14a6)])   \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
: "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
(0x18a0+2385-0x21ef)])   \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b": \
"\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[(0xad9+6163-0x22e9)]\
)      \
    );                                                                         \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);\
                                                        \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);\
                                                       \
                                                                               \
    ((ReplacementFor_ctx_t *)(ctx))->c = (0xc80+3304-0x1968);\
                                                   \
}                                                                              \
while ((0xcb9+374-0xe2f))
#define ReplacementFor_DEVICE_B2B_H_LAST(ctx, ReplacementFor_aux)\
                                            \
do                                                                             \
{                                                                              \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x25\x31\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
(0x23eb+14-0x23f9)]):                            \
        "\x72"(((ReplacementFor_ctx_t *)(ctx))->c)\
                                               \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
(0xef9+2665-0x1961)])                             \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
(0x925+5662-0x1f41)])                             \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b":\
                                                 \
        "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
(0x12ea+53-0x131c)])                             \
    );                                                                         \
                                                                               \
    while (((ReplacementFor_ctx_t *)(ctx))->c < ReplacementFor_BUF_SIZE_8)\
                                   \
    {                                                                          \
        ((ReplacementFor_ctx_t *)(ctx))->b[((ReplacementFor_ctx_t *)(ctx))->c++]\
 = (0x841+4068-0x1825);                        \
    }                                                                          \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);\
                                                        \
                                                                               \
    ((uint64_t *)(ReplacementFor_aux))[(0x3c+1895-0x795)] = ~((uint64_t *)(\
ReplacementFor_aux))[(0x27f+8053-0x21e6)];                        \
                                                                               \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);\
                                                       \
}                                                                              \
while ((0x17f0+605-0x1a4d))
#define ReplacementFor_REVERSE_ENDIAN(p)\
                                                      \
    ((((uint64_t)((uint8_t *)(p))[(0x666+4281-0x171f)]) << (0x1025+5904-0x26fd))\
 ^                                 \
    (((uint64_t)((uint8_t *)(p))[(0x17c0+838-0x1b05)]) << (0x588+3365-0x127d)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x243f+431-0x25ec)]) << (0x1c91+2582-0x267f)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[(0xf47+1820-0x1660)]) << (0x1266+2331-0x1b61)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[(0x17b1+1759-0x1e8c)]) << (0xa32+7271-0x2681)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[(0xa7a+577-0xcb6)]) << (0x112c+444-0x12d8)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x1cf+541-0x3e6)]) << (0xe37+2356-0x1763)) ^\
                                   \
    ((uint64_t)((uint8_t *)(p))[(0xe4+8447-0x21dc)]))
#define ReplacementFor_INPLACE_REVERSE_ENDIAN(p)\
                                              \
do                                                                             \
{                                                                              \
    *((uint64_t *)(p))                                                         \
    = ((((uint64_t)((uint8_t *)(p))[(0x2ad+4565-0x1482)]) << \
(0x10fa+3603-0x1ed5)) ^                               \
    (((uint64_t)((uint8_t *)(p))[(0x19b7+2573-0x23c3)]) << (0xb2c+542-0xd1a)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x1d05+1909-0x2478)]) << (0xa16+5543-0x1f95)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[(0x97+1058-0x4b6)]) << (0x1cb+7124-0x1d7f)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x1c57+2226-0x2505)]) << (0x13bf+2884-0x1eeb))\
 ^                                  \
    (((uint64_t)((uint8_t *)(p))[(0x13a5+3125-0x1fd5)]) << (0x73d+3869-0x164a)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[(0x18b9+1022-0x1cb1)]) << (0x2a6+1354-0x7e8)) ^\
                                   \
    ((uint64_t)((uint8_t *)(p))[(0xf75+5726-0x25cc)]));\
                                          \
}                                                                              \
while ((0x471+8655-0x2640))
#define FREE(x)                                                                \
do                                                                             \
{                                                                              \
    if (x)                                                                     \
    {                                                                          \
        free(x);                                                               \
        (x) = NULL;                                                            \
    }                                                                          \
}                                                                              \
while ((0xb17+4454-0x1c7d))
#define ReplacementFor_CUDA_CALL(x)\
                                                           \
do                                                                             \
{                                                                              \
    if ((x) != ReplacementFor_cudaSuccess)\
                                                    \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x1854+2061-0x2061))
#define ReplacementFor_CALL(ReplacementFor_func, name)\
                                                       \
do                                                                             \
{                                                                              \
    if (!(ReplacementFor_func))\
                                                               \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0xca5+3574-0x1a9b))
#define ReplacementFor_FUNCTION_CALL(ReplacementFor_res, ReplacementFor_func, \
name)                                         \
do                                                                             \
{                                                                              \
    if (!((ReplacementFor_res) = (ReplacementFor_func)))\
                                                     \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x196+2574-0xba4))
#define ReplacementFor_CALL_STATUS(ReplacementFor_func, name, status)\
                                        \
do                                                                             \
{                                                                              \
    if ((ReplacementFor_func) != (status))\
                                                    \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x4f9+3807-0x13d8))
#define ReplacementFor_FUNCTION_CALL_STATUS(ReplacementFor_res, \
ReplacementFor_func, name, status)                          \
do                                                                             \
{                                                                              \
    if ((ReplacementFor_res = ReplacementFor_func) != (status))\
                                              \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x95f+2424-0x12d7))
#define ReplacementFor_PERSISTENT_CALL(ReplacementFor_func)\
                                                  \
do {} while (!(ReplacementFor_func))
#define ReplacementFor_PERSISTENT_FUNCTION_CALL(ReplacementFor_res, \
ReplacementFor_func)                                    \
do {} while (!((ReplacementFor_res) = (ReplacementFor_func)))
#define ReplacementFor_PERSISTENT_CALL_STATUS(ReplacementFor_func, status)\
                                   \
do {} while ((ReplacementFor_func) != (status))
#define ReplacementFor_PERSISTENT_FUNCTION_CALL_STATUS(ReplacementFor_func, \
status)                          \
do {} while (((ReplacementFor_res) = (ReplacementFor_func)) != (status))
#endif 



#ifndef ReplacementFor_PREHAZH_H
#define ReplacementFor_PREHAZH_H
#include "ReplacementFor_definitions.h"
ReplacementFor___global__ void ReplacementFor_InitPrehazh(const uint32_t 
ReplacementFor_height,uint32_t*ReplacementFor_hashes);int ReplacementFor_Prehazh
(uint32_t*ReplacementFor_hashes,uint32_t ReplacementFor_height);
#endif 



#ifndef ReplacementFor_REDUCTION_H
#define ReplacementFor_REDUCTION_H
#include "ReplacementFor_definitions.h"
uint32_t ReplacementFor_CeilToPower(uint32_t x);template<uint32_t 
ReplacementFor_blockSize>ReplacementFor___global__ void 
ReplacementFor_BlockNonZero(uint32_t*in,uint32_t ReplacementFor_inlen,uint32_t*
out);template<uint32_t ReplacementFor_blockSize>ReplacementFor___global__ void 
ReplacementFor_BlockSum(uint32_t*in,uint32_t ReplacementFor_inlen,uint32_t*out);
void ReplacementFor_ReduceNonZero(uint32_t*in,uint32_t ReplacementFor_inlen,
uint32_t*out,uint32_t ReplacementFor_gridSize,uint32_t ReplacementFor_blockSize)
;void ReplacementFor_ReduceSum(uint32_t*in,uint32_t ReplacementFor_inlen,
uint32_t*out,uint32_t ReplacementFor_gridSize,uint32_t ReplacementFor_blockSize)
;uint32_t ReplacementFor_FindNonZero(uint32_t*data,uint32_t*ReplacementFor_aux,
uint32_t ReplacementFor_inlen);uint32_t ReplacementFor_FindSum(uint32_t*data,
uint32_t*ReplacementFor_aux,uint32_t ReplacementFor_inlen);
#endif 


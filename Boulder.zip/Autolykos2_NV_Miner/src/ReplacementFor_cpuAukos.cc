
#include "../include/ReplacementFor_cpuAukos.h"
ReplacementFor_AukosAlg::ReplacementFor_AukosAlg(){ReplacementFor_m_str=new char
[(0x856+53-0x84b)];ReplacementFor_bound_str=new char[(0x28d+9208-0x2621)];
ReplacementFor_m_n=new uint8_t[ReplacementFor_NUM_SIZE_8+
ReplacementFor_NONCE_SIZE_8];ReplacementFor_p_w_m_n=new uint8_t[
ReplacementFor_PK_SIZE_8+ReplacementFor_PK_SIZE_8+ReplacementFor_NUM_SIZE_8+
ReplacementFor_NONCE_SIZE_8];ReplacementFor_Hinput=new uint8_t[sizeof(uint32_t)+
ReplacementFor_CONST_MES_SIZE_8+ReplacementFor_PK_SIZE_8+
ReplacementFor_NUM_SIZE_8+ReplacementFor_PK_SIZE_8];ReplacementFor_n_str=new 
char[ReplacementFor_NONCE_SIZE_4];ReplacementFor_h_str=new char[
ReplacementFor_HEIGHT_SIZE];int ReplacementFor_tr=sizeof(unsigned long long);for
(size_t i=(0x367+3415-0x10be);i<ReplacementFor_CONST_MES_SIZE_8/
ReplacementFor_tr;i++){unsigned long long ReplacementFor_tmp=i;uint8_t 
ReplacementFor_tmp2[(0x16aa+749-0x198f)];uint8_t ReplacementFor_tmp1[
(0x100c+3829-0x1ef9)];memcpy(ReplacementFor_tmp1,&ReplacementFor_tmp,
ReplacementFor_tr);ReplacementFor_tmp2[(0x106a+1116-0x14c6)]=ReplacementFor_tmp1
[(0xcb6+4268-0x1d5b)];ReplacementFor_tmp2[(0x9c9+4703-0x1c27)]=
ReplacementFor_tmp1[(0x914+5840-0x1fde)];ReplacementFor_tmp2[
(0x106d+3061-0x1c60)]=ReplacementFor_tmp1[(0x5d5+3413-0x1325)];
ReplacementFor_tmp2[(0x9ca+404-0xb5b)]=ReplacementFor_tmp1[(0x3a+6816-0x1ad6)];
ReplacementFor_tmp2[(0x125a+3782-0x211c)]=ReplacementFor_tmp1[
(0x177+8624-0x2324)];ReplacementFor_tmp2[(0x1459+2953-0x1fdd)]=
ReplacementFor_tmp1[(0x94b+3710-0x17c7)];ReplacementFor_tmp2[(0x1b21+14-0x1b29)]
=ReplacementFor_tmp1[(0xda3+5328-0x2272)];ReplacementFor_tmp2[
(0x10f1+1367-0x1641)]=ReplacementFor_tmp1[(0x128+6982-0x1c6e)];memcpy(&
ReplacementFor_CONST_MESS[i],ReplacementFor_tmp2,ReplacementFor_tr);}}
ReplacementFor_AukosAlg::~ReplacementFor_AukosAlg(){}void 
ReplacementFor_AukosAlg::ReplacementFor_Blake2b256(const char*in,const int len,
uint8_t*ReplacementFor_output,char*ReplacementFor_outstr){ReplacementFor_ctx_t 
ctx;uint64_t ReplacementFor_aux[(0x44b+2764-0xef7)];memset(ctx.b,
(0xc45+4275-0x1cf8),(0x659+6434-0x1efb));ReplacementFor_B2B_IV(ctx.
ReplacementFor_h);ctx.ReplacementFor_h[(0x13d8+2595-0x1dfb)]^=16842752^
ReplacementFor_NUM_SIZE_8;memset(ctx.t,(0xe35+5208-0x228d),(0xac2+5947-0x21ed));
ctx.c=(0x1349+118-0x13bf);for(int i=(0xd4+6019-0x1857);i<len;++i){if(ctx.c==
(0x937+2407-0x121e)){ReplacementFor_HOST_B2B_H(&ctx,ReplacementFor_aux);}ctx.b[
ctx.c++]=(uint8_t)(in[i]);}ReplacementFor_HOST_B2B_H_LAST(&ctx,
ReplacementFor_aux);for(int i=(0x1ea8+1555-0x24bb);i<ReplacementFor_NUM_SIZE_8;
++i){ReplacementFor_output[ReplacementFor_NUM_SIZE_8-i-(0x1feb+443-0x21a5)]=(ctx
.ReplacementFor_h[i>>(0xb76+5471-0x20d2)]>>((i&(0x56f+4232-0x15f0))<<
(0x4b9+765-0x7b3)))&(0x6f3+6941-0x2111);}ReplacementFor_LittleEndianToHexStr(
ReplacementFor_output,ReplacementFor_NUM_SIZE_8,ReplacementFor_outstr);}void 
ReplacementFor_AukosAlg::ReplacementFor_GenIdex(const char*in,const int len,
uint32_t*index){int a=ReplacementFor_INDEX_SIZE_8;int b=ReplacementFor_K_LEN;int
 c=ReplacementFor_NUM_SIZE_8;int ReplacementFor_d=ReplacementFor_NUM_SIZE_4;
uint8_t ReplacementFor_sk[ReplacementFor_NUM_SIZE_8*(0x318+2257-0xbe7)];char 
ReplacementFor_skstr[ReplacementFor_NUM_SIZE_4+(0x137a+4593-0x2561)];memset(
ReplacementFor_sk,(0x488+3620-0x12ac),ReplacementFor_NUM_SIZE_8*
(0xe5+5303-0x159a));memset(ReplacementFor_skstr,(0x1dd+7527-0x1f44),
ReplacementFor_NUM_SIZE_4);ReplacementFor_Blake2b256(in,len,ReplacementFor_sk,
ReplacementFor_skstr);uint8_t ReplacementFor_beH[ReplacementFor_PK_SIZE_8];
ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr,ReplacementFor_NUM_SIZE_4,
ReplacementFor_beH,ReplacementFor_NUM_SIZE_8);uint32_t*ReplacementFor_ind=index;
memcpy(ReplacementFor_sk,ReplacementFor_beH,ReplacementFor_NUM_SIZE_8);memcpy(
ReplacementFor_sk+ReplacementFor_NUM_SIZE_8,ReplacementFor_beH,
ReplacementFor_NUM_SIZE_8);uint32_t ReplacementFor_tmpInd[(0x31+3199-0xc90)];int
 ReplacementFor_sliceIndex=(0xa8a+411-0xc25);for(int k=(0xa63+1618-0x10b5);k<
ReplacementFor_K_LEN;k++){uint8_t ReplacementFor_tmp[(0x2b7+3772-0x116f)];memcpy
(ReplacementFor_tmp,ReplacementFor_sk+ReplacementFor_sliceIndex,
(0x32+7021-0x1b9b));memcpy(&ReplacementFor_tmpInd[k],ReplacementFor_sk+
ReplacementFor_sliceIndex,(0x3df+6034-0x1b6d));uint8_t ReplacementFor_tmp2[
(0x459+1182-0x8f3)];ReplacementFor_tmp2[(0x4ef+3782-0x13b5)]=ReplacementFor_tmp[
(0xe9d+28-0xeb6)];ReplacementFor_tmp2[(0x8f8+6804-0x238b)]=ReplacementFor_tmp[
(0x2fd+6401-0x1bfc)];ReplacementFor_tmp2[(0x17+9298-0x2467)]=ReplacementFor_tmp[
(0x209+558-0x436)];ReplacementFor_tmp2[(0x1ae2+1778-0x21d1)]=ReplacementFor_tmp[
(0x1398+3142-0x1fde)];memcpy(&ReplacementFor_ind[k],ReplacementFor_tmp2,
(0x6ed+4535-0x18a0));ReplacementFor_ind[k]=ReplacementFor_ind[k]%
ReplacementFor_N_LEN;ReplacementFor_sliceIndex++;}}void ReplacementFor_AukosAlg
::ReplacementFor_hashFn(const char*in,const int len,uint8_t*
ReplacementFor_output){char*ReplacementFor_skstr=new char[len*(0xb9a+32-0xbb7)];
ReplacementFor_Blake2b256(in,len,ReplacementFor_output,ReplacementFor_skstr);
uint8_t ReplacementFor_beHash[ReplacementFor_PK_SIZE_8];
ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr,ReplacementFor_NUM_SIZE_4,
ReplacementFor_beHash,ReplacementFor_NUM_SIZE_8);memcpy(ReplacementFor_output,
ReplacementFor_beHash,ReplacementFor_NUM_SIZE_8);delete ReplacementFor_skstr;}
bool ReplacementFor_AukosAlg::ReplacementFor_RunAlg(uint8_t*message,uint8_t*
ReplacementFor_nonce,uint8_t*ReplacementFor_bPool,uint8_t*ReplacementFor_height)
{ReplacementFor_BigEndianToHexStr(message,ReplacementFor_NUM_SIZE_8,
ReplacementFor_m_str);uint32_t ReplacementFor_ilen=(0x59a+3611-0x13b5);
ReplacementFor_LittleEndianOf256ToDecStr((uint8_t*)ReplacementFor_bPool,
ReplacementFor_bound_str,&ReplacementFor_ilen);uint32_t index[
ReplacementFor_K_LEN];ReplacementFor_LittleEndianToHexStr(ReplacementFor_nonce,
ReplacementFor_NONCE_SIZE_8,ReplacementFor_n_str);
ReplacementFor_BigEndianToHexStr(ReplacementFor_height,
ReplacementFor_HEIGHT_SIZE,ReplacementFor_h_str);uint8_t ReplacementFor_beN[
ReplacementFor_NONCE_SIZE_8];ReplacementFor_HexStrToBigEndian(
ReplacementFor_n_str,ReplacementFor_NONCE_SIZE_8*(0xe6f+6072-0x2625),
ReplacementFor_beN,ReplacementFor_NONCE_SIZE_8);uint8_t ReplacementFor_beH[
ReplacementFor_HEIGHT_SIZE];ReplacementFor_HexStrToBigEndian(
ReplacementFor_h_str,ReplacementFor_HEIGHT_SIZE*(0x133b+1705-0x19e2),
ReplacementFor_beH,ReplacementFor_HEIGHT_SIZE);uint8_t ReplacementFor_h1[
ReplacementFor_NUM_SIZE_8];memcpy(ReplacementFor_m_n,message,
ReplacementFor_NUM_SIZE_8);memcpy(ReplacementFor_m_n+ReplacementFor_NUM_SIZE_8,
ReplacementFor_beN,ReplacementFor_NONCE_SIZE_8);ReplacementFor_hashFn((const 
char*)ReplacementFor_m_n,ReplacementFor_NUM_SIZE_8+ReplacementFor_NONCE_SIZE_8,(
uint8_t*)ReplacementFor_h1);uint64_t ReplacementFor_h2;char ReplacementFor_tmpL1
[(0x663+4432-0x17ab)];ReplacementFor_tmpL1[(0x72d+2047-0xf2c)]=ReplacementFor_h1
[(0xcdd+1206-0x1174)];ReplacementFor_tmpL1[(0x1934+1635-0x1f96)]=
ReplacementFor_h1[(0x212f+772-0x2415)];ReplacementFor_tmpL1[(0x192b+617-0x1b92)]
=ReplacementFor_h1[(0x1390+3641-0x21ac)];ReplacementFor_tmpL1[
(0x1b5a+757-0x1e4c)]=ReplacementFor_h1[(0x58b+5614-0x1b5d)];ReplacementFor_tmpL1
[(0xb64+2129-0x13b1)]=ReplacementFor_h1[(0x1373+4854-0x264e)];
ReplacementFor_tmpL1[(0x884+5299-0x1d32)]=ReplacementFor_h1[(0x1b22+910-0x1e96)]
;ReplacementFor_tmpL1[(0x1fa+4660-0x1428)]=ReplacementFor_h1[
(0x1822+3597-0x2616)];ReplacementFor_tmpL1[(0x3cc+8765-0x2602)]=
ReplacementFor_h1[(0x12b1+3507-0x204c)];memcpy(&ReplacementFor_h2,
ReplacementFor_tmpL1,(0x32f+8079-0x22b6));unsigned int ReplacementFor_h3=
ReplacementFor_h2%ReplacementFor_N_LEN;uint8_t ReplacementFor_iii[
(0x9dc+114-0xa4a)];ReplacementFor_iii[(0x176f+3197-0x23ec)]=((char*)(&
ReplacementFor_h3))[(0x784+1322-0xcab)];ReplacementFor_iii[(0x74b+1851-0xe85)]=(
(char*)(&ReplacementFor_h3))[(0xc0d+5150-0x2029)];ReplacementFor_iii[
(0x9d5+7238-0x2619)]=((char*)(&ReplacementFor_h3))[(0x139+5583-0x1707)];
ReplacementFor_iii[(0x622+3702-0x1495)]=((char*)(&ReplacementFor_h3))[
(0x1447+4605-0x2644)];uint8_t ReplacementFor_i_h_M[ReplacementFor_HEIGHT_SIZE+
ReplacementFor_HEIGHT_SIZE+ReplacementFor_CONST_MES_SIZE_8];memcpy(
ReplacementFor_i_h_M,ReplacementFor_iii,ReplacementFor_HEIGHT_SIZE);memcpy(
ReplacementFor_i_h_M+ReplacementFor_HEIGHT_SIZE,ReplacementFor_beH,
ReplacementFor_HEIGHT_SIZE);memcpy(ReplacementFor_i_h_M+
ReplacementFor_HEIGHT_SIZE+ReplacementFor_HEIGHT_SIZE,ReplacementFor_CONST_MESS,
ReplacementFor_CONST_MES_SIZE_8);ReplacementFor_hashFn((const char*)
ReplacementFor_i_h_M,ReplacementFor_HEIGHT_SIZE+ReplacementFor_HEIGHT_SIZE+
ReplacementFor_CONST_MES_SIZE_8,(uint8_t*)ReplacementFor_h1);uint8_t 
ReplacementFor_ff[ReplacementFor_NUM_SIZE_8-(0x1ff2+1279-0x24f0)];memcpy(
ReplacementFor_ff,ReplacementFor_h1+(0xf17+3194-0x1b90),
ReplacementFor_NUM_SIZE_8-(0xfbf+314-0x10f8));uint8_t seed[
ReplacementFor_NUM_SIZE_8-(0x902+6529-0x2282)+ReplacementFor_NUM_SIZE_8+
ReplacementFor_NONCE_SIZE_8];memcpy(seed,ReplacementFor_ff,
ReplacementFor_NUM_SIZE_8-(0xe1c+1229-0x12e8));memcpy(seed+
ReplacementFor_NUM_SIZE_8-(0x3e3+3630-0x1210),message,ReplacementFor_NUM_SIZE_8)
;memcpy(seed+ReplacementFor_NUM_SIZE_8-(0x1cdd+2369-0x261d)+
ReplacementFor_NUM_SIZE_8,ReplacementFor_beN,ReplacementFor_NONCE_SIZE_8);
ReplacementFor_GenIdex((const char*)seed,ReplacementFor_NUM_SIZE_8-
(0x1673+3058-0x2264)+ReplacementFor_NUM_SIZE_8+ReplacementFor_NONCE_SIZE_8,index
);uint8_t ReplacementFor_ret[(0x30+4894-0x132e)][ReplacementFor_NUM_SIZE_8];int 
ReplacementFor_ll=sizeof(uint32_t)+ReplacementFor_CONST_MES_SIZE_8+
ReplacementFor_PK_SIZE_8+ReplacementFor_NUM_SIZE_8+ReplacementFor_PK_SIZE_8;
ReplacementFor_BIGNUM*ReplacementFor_bigsum=ReplacementFor_BN_new();
ReplacementFor_CALL(ReplacementFor_BN_dec2bn(&ReplacementFor_bigsum,"\x30"),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_BIGNUM*ReplacementFor_bigres=
ReplacementFor_BN_new();ReplacementFor_CALL(ReplacementFor_BN_dec2bn(&
ReplacementFor_bigres,"\x30"),ReplacementFor_ERROR_OPENSSL);int rep=
(0xc64+3229-0x1901);int ReplacementFor_off=(0x152f+1692-0x1bcb);uint8_t 
ReplacementFor_tmp[ReplacementFor_NUM_SIZE_8-(0x1a69+2420-0x23dc)];char 
ReplacementFor_hesStr[(0x1dcd+207-0x1e5c)+(0x63f+871-0x9a5)];uint8_t 
ReplacementFor_tmp2[(0x1dc1+2001-0x258e)];uint8_t ReplacementFor_tmp1[
(0xcf4+4408-0x1e28)];unsigned char f[(0x10cb+823-0x13e2)];memset(f,
(0x17d8+1584-0x1e08),(0x1471+3521-0x2212));char*ReplacementFor_LSUMM;char*LB;for
(rep=(0x23ed+40-0x2415);rep<(0x176c+542-0x196a);rep++){memset(
ReplacementFor_Hinput,(0xf51+2016-0x1731),ReplacementFor_ll);memcpy(
ReplacementFor_tmp1,&index[rep],(0x62+7869-0x1f1b));ReplacementFor_tmp2[
(0x1a6b+2737-0x251c)]=ReplacementFor_tmp1[(0xc6d+6474-0x25b4)];
ReplacementFor_tmp2[(0x1b80+1130-0x1fe9)]=ReplacementFor_tmp1[
(0xddd+1835-0x1506)];ReplacementFor_tmp2[(0xd61+4737-0x1fe0)]=
ReplacementFor_tmp1[(0x195a+305-0x1a8a)];ReplacementFor_tmp2[(0x749+2294-0x103c)
]=ReplacementFor_tmp1[(0x1f6+427-0x3a1)];ReplacementFor_off=(0x2fb+1696-0x99b);
memcpy(ReplacementFor_Hinput+ReplacementFor_off,ReplacementFor_tmp2,sizeof(
uint32_t));ReplacementFor_off+=sizeof(uint32_t);memcpy(ReplacementFor_Hinput+
ReplacementFor_off,ReplacementFor_beH,ReplacementFor_HEIGHT_SIZE);
ReplacementFor_off+=ReplacementFor_HEIGHT_SIZE;memcpy(ReplacementFor_Hinput+
ReplacementFor_off,ReplacementFor_CONST_MESS,ReplacementFor_CONST_MES_SIZE_8);
ReplacementFor_off+=ReplacementFor_CONST_MES_SIZE_8;ReplacementFor_hashFn((const
 char*)ReplacementFor_Hinput,ReplacementFor_off,(uint8_t*)ReplacementFor_ret[rep
]);memcpy(ReplacementFor_tmp,&(ReplacementFor_ret[rep][(0x1268+426-0x1411)]),
(0xc96+2235-0x1532));ReplacementFor_CALL(ReplacementFor_BN_bin2bn((const 
unsigned char*)ReplacementFor_tmp,(0x222+132-0x287),ReplacementFor_bigres),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_CALL(ReplacementFor_BN_add(
ReplacementFor_bigsum,ReplacementFor_bigsum,ReplacementFor_bigres),
ReplacementFor_ERROR_OPENSSL);LB=ReplacementFor_BN_bn2dec(ReplacementFor_bigres)
;ReplacementFor_BN_bn2bin(ReplacementFor_bigsum,f);}const char*
ReplacementFor_SUMMbigEndian=ReplacementFor_BN_bn2dec(ReplacementFor_bigsum);
ReplacementFor_BN_bn2bin(ReplacementFor_bigsum,f);char 
ReplacementFor_bigendian2littl[(0xbeb+4042-0x1b95)];for(size_t i=
(0x1bd8+497-0x1dc9);i<(0x583+5787-0x1bfe);i++){ReplacementFor_bigendian2littl[i]
=f[(0x2121+303-0x2230)-i-(0x1ba8+2685-0x2624)];}ReplacementFor_BIGNUM*
ReplacementFor_littleF=ReplacementFor_BN_new();ReplacementFor_CALL(
ReplacementFor_BN_bin2bn((const unsigned char*)ReplacementFor_bigendian2littl,
(0x466+4691-0x1699),ReplacementFor_littleF),ReplacementFor_ERROR_OPENSSL);const 
char*ReplacementFor_SUMMLittleEndian=ReplacementFor_BN_bn2dec(
ReplacementFor_littleF);char ReplacementFor_hf[(0xb87+336-0xcb7)];
ReplacementFor_hashFn((const char*)f,(0x1ec8+1418-0x2432),(uint8_t*)
ReplacementFor_hf);ReplacementFor_BIGNUM*ReplacementFor_bigHF=
ReplacementFor_BN_new();ReplacementFor_CALL(ReplacementFor_BN_bin2bn((const 
unsigned char*)ReplacementFor_hf,(0xcf3+2984-0x187b),ReplacementFor_bigHF),
ReplacementFor_ERROR_OPENSSL);char ReplacementFor_littl2big[(0x1775+348-0x18b1)]
;for(size_t i=(0x15a6+544-0x17c6);i<(0xd6d+4436-0x1ea1);i++){
ReplacementFor_littl2big[i]=ReplacementFor_bPool[(0x188d+1760-0x1f4d)-i-
(0x37+2212-0x8da)];}ReplacementFor_BIGNUM*ReplacementFor_bigB=
ReplacementFor_BN_new();ReplacementFor_CALL(ReplacementFor_BN_bin2bn((const 
unsigned char*)ReplacementFor_littl2big,(0x9aa+2324-0x129e),ReplacementFor_bigB)
,ReplacementFor_ERROR_OPENSSL);int ReplacementFor_cmp=ReplacementFor_BN_cmp(
ReplacementFor_bigHF,ReplacementFor_bigB);const char*ReplacementFor_chD=
ReplacementFor_BN_bn2dec(ReplacementFor_bigHF);const char*ReplacementFor_chB=
ReplacementFor_BN_bn2dec(ReplacementFor_bigB);ReplacementFor_BN_free(
ReplacementFor_bigsum);ReplacementFor_BN_free(ReplacementFor_bigres);
ReplacementFor_BN_free(ReplacementFor_littleF);ReplacementFor_BN_free(
ReplacementFor_bigHF);ReplacementFor_BN_free(ReplacementFor_bigB);if(
ReplacementFor_cmp<(0x44a+2319-0xd59)){return true;}else{return false;}}

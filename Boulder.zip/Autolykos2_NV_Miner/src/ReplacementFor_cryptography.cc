
#include "../include/ReplacementFor_cryptography.h"
#include "../include/ReplacementFor_conversion.h"
#include "../include/ReplacementFor_definitions.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/bn.h>
#include <openssl/ec.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/opensslv.h>
#include <random>
int ReplacementFor_GenerateSecKey(const char*in,const int len,uint8_t*
ReplacementFor_sk,char*ReplacementFor_skstr){ReplacementFor_ctx_t ctx;uint64_t 
ReplacementFor_aux[(0x309+7055-0x1e78)];memset(ctx.b,(0x960+5912-0x2078),
(0x1b07+790-0x1d9d));ReplacementFor_B2B_IV(ctx.ReplacementFor_h);ctx.
ReplacementFor_h[(0x36c+5681-0x199d)]^=16842752^ReplacementFor_NUM_SIZE_8;memset
(ctx.t,(0x1d1+2626-0xc13),(0x1416+680-0x16ae));ctx.c=(0x146c+4496-0x25fc);for(
int i=(0x148b+1293-0x1998);i<len;++i){if(ctx.c==(0x52a+6342-0x1d70)){
ReplacementFor_HOST_B2B_H(&ctx,ReplacementFor_aux);}ctx.b[ctx.c++]=(uint8_t)(in[
i]);}ReplacementFor_HOST_B2B_H_LAST(&ctx,ReplacementFor_aux);for(int i=
(0x6df+4959-0x1a3e);i<ReplacementFor_NUM_SIZE_8;++i){ReplacementFor_sk[
ReplacementFor_NUM_SIZE_8-i-(0xd92+4328-0x1e79)]=(ctx.ReplacementFor_h[i>>
(0x100+1223-0x5c4)]>>((i&(0xb8+9491-0x25c4))<<(0xc2d+1219-0x10ed)))&
(0x1593+1574-0x1aba);}uint8_t ReplacementFor_borrow[(0x290+6045-0x1a2b)];
ReplacementFor_borrow[(0xf5a+117-0xfcf)]=((uint64_t*)ReplacementFor_sk)[
(0xac4+4991-0x1e43)]<ReplacementFor_Q0;ReplacementFor_aux[(0x217b+960-0x253b)]=(
(uint64_t*)ReplacementFor_sk)[(0x1607+3640-0x243f)]-ReplacementFor_Q0;
ReplacementFor_borrow[(0xd2+3050-0xcbb)]=((uint64_t*)ReplacementFor_sk)[
(0xbaa+2717-0x1646)]<ReplacementFor_Q1+ReplacementFor_borrow[(0x1295+433-0x1446)
];ReplacementFor_aux[(0x1741+3316-0x2434)]=((uint64_t*)ReplacementFor_sk)[
(0x17e7+2866-0x2318)]-ReplacementFor_Q1-ReplacementFor_borrow[
(0x11e1+4391-0x2308)];ReplacementFor_borrow[(0x4c6+2222-0xd74)]=((uint64_t*)
ReplacementFor_sk)[(0x2b5+6117-0x1a98)]<ReplacementFor_Q2+ReplacementFor_borrow[
(0x180f+3765-0x26c3)];ReplacementFor_aux[(0x39d+4498-0x152d)]=((uint64_t*)
ReplacementFor_sk)[(0xb97+7000-0x26ed)]-ReplacementFor_Q2-ReplacementFor_borrow[
(0x1aab+567-0x1ce1)];ReplacementFor_borrow[(0xbca+3824-0x1ab9)]=((uint64_t*)
ReplacementFor_sk)[(0x111+9051-0x2469)]<ReplacementFor_Q3+ReplacementFor_borrow[
(0x15e4+1436-0x1b80)];ReplacementFor_aux[(0x27+684-0x2d0)]=((uint64_t*)
ReplacementFor_sk)[(0x37f+958-0x73a)]-ReplacementFor_Q3-ReplacementFor_borrow[
(0xfb2+3740-0x1e4e)];if(!(ReplacementFor_borrow[(0x217+4622-0x1424)]||
ReplacementFor_borrow[(0x24f+2045-0xa4c)])){memcpy(ReplacementFor_sk,
ReplacementFor_aux,ReplacementFor_NUM_SIZE_8);}
ReplacementFor_LittleEndianToHexStr(ReplacementFor_sk,ReplacementFor_NUM_SIZE_8,
ReplacementFor_skstr);return EXIT_SUCCESS;}int ReplacementFor_GenerateSecKeyNew(
const char*in,const int len,uint8_t*ReplacementFor_sk,char*ReplacementFor_skstr,
char*ReplacementFor_passphrase){unsigned char ReplacementFor_digest[
ReplacementFor_NUM_SIZE_4];char ReplacementFor_salt[(0x1997+1729-0x1c58)]=
"\x6d\x6e\x65\x6d\x6f\x6e\x69\x63";strcat(ReplacementFor_salt,
ReplacementFor_passphrase);ReplacementFor_PKCS5_PBKDF2_HMAC(in,len,(unsigned 
char*)ReplacementFor_salt,strlen(ReplacementFor_salt),(0xafc+574-0x53a),
ReplacementFor_EVP_sha512(),ReplacementFor_NUM_SIZE_4,ReplacementFor_digest);
ReplacementFor_uint_t ReplacementFor_hmaclen=ReplacementFor_NUM_SIZE_4;char key[
]="\x42\x69\x74\x63\x6f\x69\x6e\x20\x73\x65\x65\x64";unsigned char result[
ReplacementFor_NUM_SIZE_4];
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x10100000L
ReplacementFor_HMAC_CTX ctx;ReplacementFor_HMAC_CTX_init(&ctx);
ReplacementFor_HMAC_Init_ex(&ctx,key,strlen(key),ReplacementFor_EVP_sha512(),
NULL);ReplacementFor_HMAC_Update(&ctx,ReplacementFor_digest,
ReplacementFor_NUM_SIZE_4);ReplacementFor_HMAC_Final(&ctx,result,&
ReplacementFor_hmaclen);ReplacementFor_HMAC_CTX_cleanup(&ctx);memcpy(
ReplacementFor_sk,result,sizeof(uint8_t)*ReplacementFor_NUM_SIZE_8);
ReplacementFor_LittleEndianToHexStr(ReplacementFor_sk,ReplacementFor_NUM_SIZE_8,
ReplacementFor_skstr);ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr,
ReplacementFor_NUM_SIZE_4,ReplacementFor_sk,ReplacementFor_NUM_SIZE_8);
ReplacementFor_LittleEndianToHexStr(ReplacementFor_sk,ReplacementFor_NUM_SIZE_8,
ReplacementFor_skstr);
#else 
ReplacementFor_HMAC_CTX*ctx=ReplacementFor_HMAC_CTX_new();
ReplacementFor_HMAC_Init_ex(ctx,key,strlen(key),ReplacementFor_EVP_sha512(),NULL
);ReplacementFor_HMAC_Update(ctx,ReplacementFor_digest,ReplacementFor_NUM_SIZE_4
);ReplacementFor_HMAC_Final(ctx,result,&ReplacementFor_hmaclen);memcpy(
ReplacementFor_sk,result,sizeof(uint8_t)*ReplacementFor_NUM_SIZE_8);
ReplacementFor_HMAC_CTX_free(ctx);ReplacementFor_LittleEndianToHexStr(
ReplacementFor_sk,ReplacementFor_NUM_SIZE_8,ReplacementFor_skstr);
ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr,ReplacementFor_NUM_SIZE_4,
ReplacementFor_sk,ReplacementFor_NUM_SIZE_8);ReplacementFor_LittleEndianToHexStr
(ReplacementFor_sk,ReplacementFor_NUM_SIZE_8,ReplacementFor_skstr);
#endif
return EXIT_SUCCESS;}int ReplacementFor_GenerateKeyPair(uint8_t*
ReplacementFor_sk,uint8_t*ReplacementFor_pk){ReplacementFor_EC_KEY*
ReplacementFor_eck=NULL;ReplacementFor_EVP_PKEY*ReplacementFor_evpk=NULL;
ReplacementFor_FUNCTION_CALL(ReplacementFor_eck,
ReplacementFor_EC_KEY_new_by_curve_name(ReplacementFor_NID_secp256k1),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_EC_KEY_set_asn1_flag(
ReplacementFor_eck,ReplacementFor_OPENSSL_EC_NAMED_CURVE);ReplacementFor_CALL(
ReplacementFor_EC_KEY_generate_key(ReplacementFor_eck),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_evpk=ReplacementFor_EVP_PKEY_new();
ReplacementFor_CALL(ReplacementFor_EVP_PKEY_assign_EC_KEY(ReplacementFor_evpk,
ReplacementFor_eck),ReplacementFor_ERROR_OPENSSL);ReplacementFor_FUNCTION_CALL(
ReplacementFor_eck,ReplacementFor_EVP_PKEY_get1_EC_KEY(ReplacementFor_evpk),
ReplacementFor_ERROR_OPENSSL);const ReplacementFor_EC_GROUP*ReplacementFor_group
=ReplacementFor_EC_KEY_get0_group(ReplacementFor_eck);const 
ReplacementFor_EC_POINT*ReplacementFor_ecp=ReplacementFor_EC_KEY_get0_public_key
(ReplacementFor_eck);ReplacementFor_CALL(ReplacementFor_group,
ReplacementFor_ERROR_OPENSSL);ReplacementFor_CALL(ReplacementFor_ecp,
ReplacementFor_ERROR_OPENSSL);char*str;ReplacementFor_FUNCTION_CALL(str,
ReplacementFor_EC_POINT_point2hex(ReplacementFor_group,ReplacementFor_ecp,
ReplacementFor_POINT_CONVERSION_COMPRESSED,NULL),ReplacementFor_ERROR_OPENSSL);
int len=(0x2df+3866-0x11f9);for(;str[len]!='\0';++len){}
ReplacementFor_HexStrToBigEndian(str,len,ReplacementFor_pk,
ReplacementFor_PK_SIZE_8);ReplacementFor_OPENSSL_free(str);str=NULL;const 
ReplacementFor_BIGNUM*ReplacementFor_bn=ReplacementFor_EC_KEY_get0_private_key(
ReplacementFor_eck);ReplacementFor_CALL(ReplacementFor_bn,
ReplacementFor_ERROR_OPENSSL);ReplacementFor_FUNCTION_CALL(str,
ReplacementFor_BN_bn2hex(ReplacementFor_bn),ReplacementFor_ERROR_OPENSSL);len=
(0x430+3155-0x1083);for(;str[len]!='\0';++len){}
ReplacementFor_HexStrToLittleEndian(str,len,ReplacementFor_sk,
ReplacementFor_NUM_SIZE_8);ReplacementFor_OPENSSL_free(str);
ReplacementFor_EVP_PKEY_free(ReplacementFor_evpk);ReplacementFor_EC_KEY_free(
ReplacementFor_eck);return EXIT_SUCCESS;}int ReplacementFor_GeneratePublicKey(
const char*ReplacementFor_skstr,char*ReplacementFor_pkstr,uint8_t*
ReplacementFor_pk){ReplacementFor_EC_KEY*ReplacementFor_eck=NULL;
ReplacementFor_EC_POINT*sec=NULL;ReplacementFor_BIGNUM*ReplacementFor_res;
ReplacementFor_BN_CTX*ctx;ReplacementFor_FUNCTION_CALL(ctx,
ReplacementFor_BN_CTX_new(),ReplacementFor_ERROR_OPENSSL);ReplacementFor_res=
ReplacementFor_BN_new();ReplacementFor_CALL(ReplacementFor_BN_hex2bn(&
ReplacementFor_res,ReplacementFor_skstr),ReplacementFor_ERROR_OPENSSL);
ReplacementFor_FUNCTION_CALL(ReplacementFor_eck,
ReplacementFor_EC_KEY_new_by_curve_name(ReplacementFor_NID_secp256k1),
ReplacementFor_ERROR_OPENSSL);const ReplacementFor_EC_GROUP*ReplacementFor_group
=ReplacementFor_EC_KEY_get0_group(ReplacementFor_eck);ReplacementFor_CALL(
ReplacementFor_group,ReplacementFor_ERROR_OPENSSL);ReplacementFor_FUNCTION_CALL(
sec,ReplacementFor_EC_POINT_new(ReplacementFor_group),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_CALL(
ReplacementFor_EC_KEY_set_private_key(ReplacementFor_eck,ReplacementFor_res),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_CALL(ReplacementFor_EC_POINT_mul(
ReplacementFor_group,sec,ReplacementFor_res,NULL,NULL,ctx),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_CALL(
ReplacementFor_EC_KEY_set_public_key(ReplacementFor_eck,sec),
ReplacementFor_ERROR_OPENSSL);const ReplacementFor_EC_POINT*ReplacementFor_pub=
ReplacementFor_EC_KEY_get0_public_key(ReplacementFor_eck);ReplacementFor_CALL(
ReplacementFor_pub,ReplacementFor_ERROR_OPENSSL);char*str;
ReplacementFor_FUNCTION_CALL(str,ReplacementFor_EC_POINT_point2hex(
ReplacementFor_group,ReplacementFor_pub,
ReplacementFor_POINT_CONVERSION_COMPRESSED,NULL),ReplacementFor_ERROR_OPENSSL);
strcpy(ReplacementFor_pkstr,str);int len=(0x6cd+7473-0x23fe);for(;str[len]!='\0'
;++len){}ReplacementFor_HexStrToBigEndian(str,len,ReplacementFor_pk,
ReplacementFor_PK_SIZE_8);ReplacementFor_OPENSSL_free(str);
ReplacementFor_BN_CTX_free(ctx);ReplacementFor_BN_free(ReplacementFor_res);
ReplacementFor_EC_KEY_free(ReplacementFor_eck);return EXIT_SUCCESS;}int 
ReplacementFor_checkRandomDevice(){std::random_device ReplacementFor_rd1;std::
random_device ReplacementFor_rd2;if(ReplacementFor_rd1()==ReplacementFor_rd2())
return EXIT_FAILURE;if(ReplacementFor_rd1()==ReplacementFor_rd2())return 
EXIT_FAILURE;return EXIT_SUCCESS;}

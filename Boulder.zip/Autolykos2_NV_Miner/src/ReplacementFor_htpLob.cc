
#include "../include/ReplacementFor_htpLob.h"
namespace ReplacementFor_htpLob{namespace ReplacementFor_detail{bool 
ReplacementFor_is_hex(char c,int&ReplacementFor_v){if((0x11b6+5478-0x26fc)<=c&&
isdigit(c)){ReplacementFor_v=c-((char)(0x21c7+910-0x2525));return true;}else if(
((char)(0x1679+2102-0x1e6e))<=c&&c<=((char)(0x671+914-0x9bd))){ReplacementFor_v=
c-((char)(0x46b+7338-0x20d4))+(0x1716+3249-0x23bd);return true;}else if(
((char)(0x942+2094-0x110f))<=c&&c<=((char)(0x3f6+6617-0x1d69))){ReplacementFor_v
=c-((char)(0xc0+9077-0x23d4))+(0x1697+2312-0x1f95);return true;}return false;}
bool ReplacementFor_from_hex_to_i(const std::string&s,size_t i,size_t 
ReplacementFor_cnt,int&val){if(i>=s.size()){return false;}val=
(0x2482+287-0x25a1);for(;ReplacementFor_cnt;i++,ReplacementFor_cnt--){if(!s[i]){
return false;}int ReplacementFor_v=(0xd2a+4642-0x1f4c);if(ReplacementFor_is_hex(
s[i],ReplacementFor_v)){val=val*(0x143d+995-0x1810)+ReplacementFor_v;}else{
return false;}}return true;}std::string ReplacementFor_from_i_to_hex(size_t n){
const char*ReplacementFor_charset=
"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x61\x62\x63\x64\x65\x66";std::string 
ReplacementFor_ret;do{ReplacementFor_ret=ReplacementFor_charset[n&
(0x23c6+726-0x268d)]+ReplacementFor_ret;n>>=(0xaf1+286-0xc0b);}while(n>
(0xb3b+412-0xcd7));return ReplacementFor_ret;}size_t ReplacementFor_to_utf8(int 
code,char*ReplacementFor_buff){if(code<(0xa3f+6643-0x23b2)){ReplacementFor_buff[
(0x998+2141-0x11f5)]=(code&(0x1f22+2119-0x26ea));return(0xe4b+3401-0x1b93);}else
 if(code<(0x25d7+2171-0x2652)){ReplacementFor_buff[(0xef+9377-0x2590)]=
static_cast<char>((0x2d4+7059-0x1da7)|((code>>(0xcba+4307-0x1d87))&
(0x46b+5015-0x17e3)));ReplacementFor_buff[(0x186+9241-0x259e)]=static_cast<char>
((0x5c9+988-0x925)|(code&(0xc0+6911-0x1b80)));return(0x20a6+1202-0x2556);}else 
if(code<55296){ReplacementFor_buff[(0x15b2+685-0x185f)]=static_cast<char>(
(0x1b3c+2024-0x2244)|((code>>(0x722+737-0x9f7))&(0x152a+2037-0x1d10)));
ReplacementFor_buff[(0xb+1063-0x431)]=static_cast<char>((0x1214+2633-0x1bdd)|((
code>>(0x36b+5149-0x1782))&(0xf2d+3794-0x1dc0)));ReplacementFor_buff[
(0x2d5+7984-0x2203)]=static_cast<char>((0x917+3479-0x162e)|(code&
(0x175+2159-0x9a5)));return(0xbb7+2967-0x174b);}else if(code<57344){return
(0x3bd+8892-0x2679);}else if(code<65536){ReplacementFor_buff[(0x95f+6193-0x2190)
]=static_cast<char>((0x1314+4575-0x2413)|((code>>(0x2420+390-0x259a))&
(0x2e3+6820-0x1d78)));ReplacementFor_buff[(0xaf8+6635-0x24e2)]=static_cast<char>
((0xac5+905-0xdce)|((code>>(0x1251+526-0x1459))&(0x12cc+3371-0x1fb8)));
ReplacementFor_buff[(0xeec+1364-0x143e)]=static_cast<char>((0x141+9221-0x24c6)|(
code&(0xd8d+497-0xf3f)));return(0x6b0+3536-0x147d);}else if(code<1114112){
ReplacementFor_buff[(0x121+2509-0xaee)]=static_cast<char>((0x142d+3925-0x2292)|(
(code>>(0x74b+7507-0x248c))&(0xbc0+2818-0x16bb)));ReplacementFor_buff[
(0x10f7+1818-0x1810)]=static_cast<char>((0x1773+624-0x1963)|((code>>
(0x1cbb+380-0x1e2b))&(0x9d0+4070-0x1977)));ReplacementFor_buff[
(0x18c2+2424-0x2238)]=static_cast<char>((0x1b5f+1516-0x20cb)|((code>>
(0x13e7+4605-0x25de))&(0xe14+4174-0x1e23)));ReplacementFor_buff[
(0x204+8882-0x24b3)]=static_cast<char>((0x96+8909-0x22e3)|(code&
(0x1490+2685-0x1ece)));return(0x4bc+1386-0xa22);}return(0x422+522-0x62c);}std::
string ReplacementFor_base64_encode(const std::string&in){static const auto 
ReplacementFor_lookup=
"\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x2b\x2f"
;std::string out;out.reserve(in.size());int val=(0xd65+4714-0x1fcf);int 
ReplacementFor_valb=-(0xa84+959-0xe3d);for(auto c:in){val=(val<<
(0x1b6d+763-0x1e60))+static_cast<uint8_t>(c);ReplacementFor_valb+=
(0xa2d+4738-0x1ca7);while(ReplacementFor_valb>=(0x1af+1717-0x864)){out.push_back
(ReplacementFor_lookup[(val>>ReplacementFor_valb)&(0x3ef+8880-0x2660)]);
ReplacementFor_valb-=(0x182+7046-0x1d02);}}if(ReplacementFor_valb>-
(0xccb+500-0xeb9)){out.push_back(ReplacementFor_lookup[((val<<
(0x5e4+2905-0x1135))>>(ReplacementFor_valb+(0x11ba+3193-0x1e2b)))&
(0x8b7+5427-0x1dab)]);}while(out.size()%(0x19e7+895-0x1d62)){out.push_back(
((char)(0x1430+4808-0x26bb)));}return out;}bool ReplacementFor_is_file(const std
::string&ReplacementFor_path){struct stat st;return stat(ReplacementFor_path.
c_str(),&st)>=(0x27b+6219-0x1ac6)&&S_ISREG(st.st_mode);}bool 
ReplacementFor_is_dir(const std::string&ReplacementFor_path){struct stat st;
return stat(ReplacementFor_path.c_str(),&st)>=(0x1158+1321-0x1681)&&S_ISDIR(st.
st_mode);}bool ReplacementFor_is_valid_path(const std::string&
ReplacementFor_path){size_t ReplacementFor_level=(0xfd3+1981-0x1790);size_t i=
(0x8e2+1439-0xe81);while(i<ReplacementFor_path.size()&&ReplacementFor_path[i]==
((char)(0x85a+7265-0x248c))){i++;}while(i<ReplacementFor_path.size()){auto beg=i
;while(i<ReplacementFor_path.size()&&ReplacementFor_path[i]!=
((char)(0x36+2277-0x8ec))){i++;}auto len=i-beg;assert(len>(0x186a+3578-0x2664));
if(!ReplacementFor_path.compare(beg,len,"\x2e")){;}else if(!ReplacementFor_path.
compare(beg,len,"\x2e\x2e")){if(ReplacementFor_level==(0xfe0+3180-0x1c4c)){
return false;}ReplacementFor_level--;}else{ReplacementFor_level++;}while(i<
ReplacementFor_path.size()&&ReplacementFor_path[i]==((char)(0x1a5b+393-0x1bb5)))
{i++;}}return true;}std::string ReplacementFor_encode_query_param(const std::
string&value){std::ostringstream ReplacementFor_escaped;ReplacementFor_escaped.
fill(((char)(0x153f+1606-0x1b55)));ReplacementFor_escaped<<std::hex;for(auto c:
value){if(std::isalnum(static_cast<uint8_t>(c))||c==((char)(0x77c+1638-0xdb5))||
c==((char)(0x3b7+1568-0x978))||c==((char)(0x17a1+3258-0x242d))||c==
((char)(0x10e6+1429-0x165a))||c==((char)(0x1eb0+216-0x1f0a))||c==
((char)(0xee9+2987-0x1a6a))||c=='\''||c==((char)(0x735+5361-0x1bfe))||c==
((char)(0x16d6+1963-0x1e58))){ReplacementFor_escaped<<c;}else{
ReplacementFor_escaped<<std::uppercase;ReplacementFor_escaped<<
((char)(0x10aa+3239-0x1d2c))<<std::setw((0xf23+2597-0x1946))<<static_cast<int>(
static_cast<unsigned char>(c));ReplacementFor_escaped<<std::nouppercase;}}return
 ReplacementFor_escaped.str();}std::string ReplacementFor_encode_url(const std::
string&s){std::string result;for(size_t i=(0x16e0+3345-0x23f1);s[i];i++){switch(
s[i]){case((char)(0x18f5+869-0x1c3a)):result+="\x25\x32\x30";break;case
((char)(0x9fa+6065-0x2180)):result+="\x25\x32\x42";break;case'\r':result+=
"\x25\x30\x44";break;case'\n':result+="\x25\x30\x41";break;case'\'':result+=
"\x25\x32\x37";break;case((char)(0x7d3+4332-0x1893)):result+="\x25\x32\x43";
break;case((char)(0x7b+3840-0xf40)):result+="\x25\x33\x42";break;default:auto c=
static_cast<uint8_t>(s[i]);if(c>=(0x1063+133-0x1068)){result+=
((char)(0x8c5+1404-0xe1c));char hex[(0x637+549-0x858)];auto len=snprintf(hex,
sizeof(hex)-(0x567+3607-0x137d),"\x25\x30\x32\x58",c);assert(len==
(0x1363+2926-0x1ecf));result.append(hex,static_cast<size_t>(len));}else{result+=
s[i];}break;}}return result;}std::string ReplacementFor_decode_url(const std::
string&s,bool ReplacementFor_convert_plus_to_space){std::string result;for(
size_t i=(0x289+4563-0x145c);i<s.size();i++){if(s[i]==
((char)(0x11f6+4069-0x21b6))&&i+(0x57c+7769-0x23d4)<s.size()){if(s[i+
(0x1ab2+2675-0x2524)]==((char)(0xd5d+3740-0x1b84))){int val=(0x758+3699-0x15cb);
if(ReplacementFor_from_hex_to_i(s,i+(0x1b78+1802-0x2280),(0x1ac+5407-0x16c7),val
)){char ReplacementFor_buff[(0x1834+3016-0x23f8)];size_t len=
ReplacementFor_to_utf8(val,ReplacementFor_buff);if(len>(0x485+575-0x6c4)){result
.append(ReplacementFor_buff,len);}i+=(0x22f1+530-0x24fe);}else{result+=s[i];}}
else{int val=(0x13a9+4498-0x253b);if(ReplacementFor_from_hex_to_i(s,i+
(0xe50+893-0x11cc),(0x419+5542-0x19bd),val)){result+=static_cast<char>(val);i+=
(0xe96+2713-0x192d);}else{result+=s[i];}}}else if(
ReplacementFor_convert_plus_to_space&&s[i]==((char)(0x19c2+847-0x1ce6))){result
+=((char)(0x17a+3091-0xd6d));}else{result+=s[i];}}return result;}void 
ReplacementFor_read_file(const std::string&ReplacementFor_path,std::string&out){
std::ifstream fs(ReplacementFor_path,std::ios_base::binary);fs.seekg(
(0x7c+4562-0x124e),std::ios_base::end);auto size=fs.tellg();fs.seekg(
(0x1479+2851-0x1f9c));out.resize(static_cast<size_t>(size));fs.read(&out[
(0x213+461-0x3e0)],static_cast<std::streamsize>(size));}std::string 
ReplacementFor_file_extension(const std::string&ReplacementFor_path){std::smatch
 m;static auto ReplacementFor_re=std::regex(
"\\" "\x2e\x28\x5b\x61\x2d\x7a\x41\x2d\x5a\x30\x2d\x39\x5d\x2b\x29\x24");if(std
::regex_search(ReplacementFor_path,m,ReplacementFor_re)){return m[
(0x1b63+747-0x1e4d)].str();}return std::string();}bool 
ReplacementFor_is_space_or_tab(char c){return c==((char)(0xe3b+3110-0x1a41))||c
=='\t';}std::pair<size_t,size_t>ReplacementFor_trim(const char*b,const char*
ReplacementFor_e,size_t left,size_t right){while(b+left<ReplacementFor_e&&
ReplacementFor_is_space_or_tab(b[left])){left++;}while(right>
(0x1629+2215-0x1ed0)&&ReplacementFor_is_space_or_tab(b[right-(0x18c9+923-0x1c63)
])){right--;}return std::make_pair(left,right);}std::string 
ReplacementFor_trim_copy(const std::string&s){auto ReplacementFor_r=
ReplacementFor_trim(s.data(),s.data()+s.size(),(0x3a9+5669-0x19ce),s.size());
return s.substr(ReplacementFor_r.first,ReplacementFor_r.second-ReplacementFor_r.
first);}template<class ReplacementFor_Fn>void ReplacementFor_split(const char*b,
const char*ReplacementFor_e,char ReplacementFor_d,ReplacementFor_Fn 
ReplacementFor_fn){size_t i=(0x378+3931-0x12d3);size_t beg=(0x1f77+1478-0x253d);
while(ReplacementFor_e?(b+i<ReplacementFor_e):(b[i]!='\0')){if(b[i]==
ReplacementFor_d){auto ReplacementFor_r=ReplacementFor_trim(b,ReplacementFor_e,
beg,i);if(ReplacementFor_r.first<ReplacementFor_r.second){ReplacementFor_fn(&b[
ReplacementFor_r.first],&b[ReplacementFor_r.second]);}beg=i+(0x13fc+2541-0x1de8)
;}i++;}if(i){auto ReplacementFor_r=ReplacementFor_trim(b,ReplacementFor_e,beg,i)
;if(ReplacementFor_r.first<ReplacementFor_r.second){ReplacementFor_fn(&b[
ReplacementFor_r.first],&b[ReplacementFor_r.second]);}}}class 
ReplacementFor_stream_line_reader{public:ReplacementFor_stream_line_reader(
ReplacementFor_Stream&ReplacementFor_strm,char*ReplacementFor_fixed_buffer,
size_t ReplacementFor_fixed_buffer_size):ReplacementFor_strm_(
ReplacementFor_strm),ReplacementFor_fixed_buffer_(ReplacementFor_fixed_buffer),
ReplacementFor_fixed_buffer_size_(ReplacementFor_fixed_buffer_size){}const char*
ReplacementFor_ptr()const{if(ReplacementFor_glowable_buffer_.empty()){return 
ReplacementFor_fixed_buffer_;}else{return ReplacementFor_glowable_buffer_.data()
;}}size_t size()const{if(ReplacementFor_glowable_buffer_.empty()){return 
ReplacementFor_fixed_buffer_used_size_;}else{return 
ReplacementFor_glowable_buffer_.size();}}bool ReplacementFor_end_with_crlf()
const{auto end=ReplacementFor_ptr()+size();return size()>=(0x3cc+3421-0x1127)&&
end[-(0x3eb+8132-0x23ad)]=='\r'&&end[-(0x147c+3543-0x2252)]=='\n';}bool getline(
){ReplacementFor_fixed_buffer_used_size_=(0x5e3+4086-0x15d9);
ReplacementFor_glowable_buffer_.clear();for(size_t i=(0x166+2656-0xbc6);;i++){
char byte;auto n=ReplacementFor_strm_.read(&byte,(0x2da+4401-0x140a));if(n<
(0xc8b+2702-0x1719)){return false;}else if(n==(0x1fb7+46-0x1fe5)){if(i==
(0xa8a+1243-0xf65)){return false;}else{break;}}append(byte);if(byte=='\n'){break
;}}return true;}private:void append(char c){if(
ReplacementFor_fixed_buffer_used_size_<ReplacementFor_fixed_buffer_size_-
(0x92+5249-0x1512)){ReplacementFor_fixed_buffer_[
ReplacementFor_fixed_buffer_used_size_++]=c;ReplacementFor_fixed_buffer_[
ReplacementFor_fixed_buffer_used_size_]='\0';}else{if(
ReplacementFor_glowable_buffer_.empty()){assert(ReplacementFor_fixed_buffer_[
ReplacementFor_fixed_buffer_used_size_]=='\0');ReplacementFor_glowable_buffer_.
assign(ReplacementFor_fixed_buffer_,ReplacementFor_fixed_buffer_used_size_);}
ReplacementFor_glowable_buffer_+=c;}}ReplacementFor_Stream&ReplacementFor_strm_;
char*ReplacementFor_fixed_buffer_;const size_t ReplacementFor_fixed_buffer_size_
;size_t ReplacementFor_fixed_buffer_used_size_=(0x23c+3769-0x10f5);std::string 
ReplacementFor_glowable_buffer_;};int ReplacementFor_close_socket(
ReplacementFor_socket_t ReplacementFor_sock){
#ifdef _WIN32
return closesocket(ReplacementFor_sock);
#else
return close(ReplacementFor_sock);
#endif
}template<typename T>ssize_t ReplacementFor_handle_EINTR(T ReplacementFor_fn){
ssize_t ReplacementFor_res=false;while(true){ReplacementFor_res=
ReplacementFor_fn();if(ReplacementFor_res<(0x20fb+851-0x244e)&&errno==EINTR){
continue;}break;}return ReplacementFor_res;}ssize_t ReplacementFor_select_read(
ReplacementFor_socket_t ReplacementFor_sock,time_t sec,time_t 
ReplacementFor_usec){
#ifdef ReplacementFor_CPPHTTPLIB_USE_POLL
struct pollfd ReplacementFor_pfd_read;ReplacementFor_pfd_read.fd=
ReplacementFor_sock;ReplacementFor_pfd_read.events=ReplacementFor_POLLIN;auto 
timeout=static_cast<int>(sec*(0xc3f+1961-0x1000)+ReplacementFor_usec/
(0x4a2+1982-0x878));return ReplacementFor_handle_EINTR([&](){return poll(&
ReplacementFor_pfd_read,(0x13e9+3433-0x2151),timeout);});
#else
#ifndef _WIN32
if(ReplacementFor_sock>=FD_SETSIZE){return(0xdf4+4336-0x1ee3);}
#endif
fd_set ReplacementFor_fds;FD_ZERO(&ReplacementFor_fds);FD_SET(
ReplacementFor_sock,&ReplacementFor_fds);timeval ReplacementFor_tv;
ReplacementFor_tv.tv_sec=static_cast<long>(sec);ReplacementFor_tv.tv_usec=
static_cast<decltype(ReplacementFor_tv.tv_usec)>(ReplacementFor_usec);return 
ReplacementFor_handle_EINTR([&](){return select(static_cast<int>(
ReplacementFor_sock+(0x998+2607-0x13c6)),&ReplacementFor_fds,nullptr,nullptr,&
ReplacementFor_tv);});
#endif
}ssize_t ReplacementFor_select_write(ReplacementFor_socket_t ReplacementFor_sock
,time_t sec,time_t ReplacementFor_usec){
#ifdef ReplacementFor_CPPHTTPLIB_USE_POLL
struct pollfd ReplacementFor_pfd_read;ReplacementFor_pfd_read.fd=
ReplacementFor_sock;ReplacementFor_pfd_read.events=ReplacementFor_POLLOUT;auto 
timeout=static_cast<int>(sec*(0x674+8442-0x2386)+ReplacementFor_usec/
(0x200d+2744-0x26dd));return ReplacementFor_handle_EINTR([&](){return poll(&
ReplacementFor_pfd_read,(0xcdd+1826-0x13fe),timeout);});
#else
#ifndef _WIN32
if(ReplacementFor_sock>=FD_SETSIZE){return(0x1a4a+2618-0x2483);}
#endif
fd_set ReplacementFor_fds;FD_ZERO(&ReplacementFor_fds);FD_SET(
ReplacementFor_sock,&ReplacementFor_fds);timeval ReplacementFor_tv;
ReplacementFor_tv.tv_sec=static_cast<long>(sec);ReplacementFor_tv.tv_usec=
static_cast<decltype(ReplacementFor_tv.tv_usec)>(ReplacementFor_usec);return 
ReplacementFor_handle_EINTR([&](){return select(static_cast<int>(
ReplacementFor_sock+(0x6fc+5972-0x1e4f)),nullptr,&ReplacementFor_fds,nullptr,&
ReplacementFor_tv);});
#endif
}bool ReplacementFor_wait_until_socket_is_ready(ReplacementFor_socket_t 
ReplacementFor_sock,time_t sec,time_t ReplacementFor_usec){
#ifdef ReplacementFor_CPPHTTPLIB_USE_POLL
struct pollfd ReplacementFor_pfd_read;ReplacementFor_pfd_read.fd=
ReplacementFor_sock;ReplacementFor_pfd_read.events=ReplacementFor_POLLIN|
ReplacementFor_POLLOUT;auto timeout=static_cast<int>(sec*(0xaa6+1437-0xc5b)+
ReplacementFor_usec/(0xda6+998-0xda4));auto ReplacementFor_poll_res=
ReplacementFor_handle_EINTR([&](){return poll(&ReplacementFor_pfd_read,
(0x1d98+555-0x1fc2),timeout);});if(ReplacementFor_poll_res>(0x3a9+4504-0x1541)&&
ReplacementFor_pfd_read.revents&(ReplacementFor_POLLIN|ReplacementFor_POLLOUT)){
int error=(0xdcf+5596-0x23ab);socklen_t len=sizeof(error);auto 
ReplacementFor_res=getsockopt(ReplacementFor_sock,SOL_SOCKET,SO_ERROR,
reinterpret_cast<char*>(&error),&len);return ReplacementFor_res>=
(0x1baa+569-0x1de3)&&!error;}return false;
#else
#ifndef _WIN32
if(ReplacementFor_sock>=FD_SETSIZE){return false;}
#endif
fd_set ReplacementFor_fdsr;FD_ZERO(&ReplacementFor_fdsr);FD_SET(
ReplacementFor_sock,&ReplacementFor_fdsr);auto ReplacementFor_fdsw=
ReplacementFor_fdsr;auto ReplacementFor_fdse=ReplacementFor_fdsr;timeval 
ReplacementFor_tv;ReplacementFor_tv.tv_sec=static_cast<long>(sec);
ReplacementFor_tv.tv_usec=static_cast<decltype(ReplacementFor_tv.tv_usec)>(
ReplacementFor_usec);auto ReplacementFor_ret=ReplacementFor_handle_EINTR([&](){
return select(static_cast<int>(ReplacementFor_sock+(0x1647+1457-0x1bf7)),&
ReplacementFor_fdsr,&ReplacementFor_fdsw,&ReplacementFor_fdse,&ReplacementFor_tv
);});if(ReplacementFor_ret>(0x1a4f+370-0x1bc1)&&(FD_ISSET(ReplacementFor_sock,&
ReplacementFor_fdsr)||FD_ISSET(ReplacementFor_sock,&ReplacementFor_fdsw))){int 
error=(0x15b3+967-0x197a);socklen_t len=sizeof(error);return getsockopt(
ReplacementFor_sock,SOL_SOCKET,SO_ERROR,reinterpret_cast<char*>(&error),&len)>=
(0x137f+1941-0x1b14)&&!error;}return false;
#endif
}class ReplacementFor_SocketStream:public ReplacementFor_Stream{public:
ReplacementFor_SocketStream(ReplacementFor_socket_t ReplacementFor_sock,time_t 
ReplacementFor_read_timeout_sec,time_t ReplacementFor_read_timeout_usec,time_t 
ReplacementFor_write_timeout_sec,time_t ReplacementFor_write_timeout_usec);~
ReplacementFor_SocketStream()override;bool ReplacementFor_is_readable()const 
override;bool ReplacementFor_is_writable()const override;ssize_t read(char*
ReplacementFor_ptr,size_t size)override;ssize_t write(const char*
ReplacementFor_ptr,size_t size)override;void 
ReplacementFor_get_remote_ip_and_port(std::string&ReplacementFor_ip,int&
ReplacementFor_port)const override;ReplacementFor_socket_t socket()const 
override;private:ReplacementFor_socket_t ReplacementFor_sock_;time_t 
ReplacementFor_read_timeout_sec_;time_t ReplacementFor_read_timeout_usec_;time_t
 ReplacementFor_write_timeout_sec_;time_t ReplacementFor_write_timeout_usec_;};
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
class ReplacementFor_SSLSocketStream:public ReplacementFor_Stream{public:
ReplacementFor_SSLSocketStream(ReplacementFor_socket_t ReplacementFor_sock,
ReplacementFor_SSL*ReplacementFor_ssl,time_t ReplacementFor_read_timeout_sec,
time_t ReplacementFor_read_timeout_usec,time_t ReplacementFor_write_timeout_sec,
time_t ReplacementFor_write_timeout_usec);~ReplacementFor_SSLSocketStream()
override;bool ReplacementFor_is_readable()const override;bool 
ReplacementFor_is_writable()const override;ssize_t read(char*ReplacementFor_ptr,
size_t size)override;ssize_t write(const char*ReplacementFor_ptr,size_t size)
override;void ReplacementFor_get_remote_ip_and_port(std::string&
ReplacementFor_ip,int&ReplacementFor_port)const override;ReplacementFor_socket_t
 socket()const override;private:ReplacementFor_socket_t ReplacementFor_sock_;
ReplacementFor_SSL*ReplacementFor_ssl_;time_t ReplacementFor_read_timeout_sec_;
time_t ReplacementFor_read_timeout_usec_;time_t 
ReplacementFor_write_timeout_sec_;time_t ReplacementFor_write_timeout_usec_;};
#endif
class ReplacementFor_BufferStream:public ReplacementFor_Stream{public:
ReplacementFor_BufferStream()=default;~ReplacementFor_BufferStream()override=
default;bool ReplacementFor_is_readable()const override;bool 
ReplacementFor_is_writable()const override;ssize_t read(char*ReplacementFor_ptr,
size_t size)override;ssize_t write(const char*ReplacementFor_ptr,size_t size)
override;void ReplacementFor_get_remote_ip_and_port(std::string&
ReplacementFor_ip,int&ReplacementFor_port)const override;ReplacementFor_socket_t
 socket()const override;const std::string&ReplacementFor_get_buffer()const;
private:std::string ReplacementFor_buffer;size_t position=(0xf59+1855-0x1698);};
bool ReplacementFor_keep_alive(ReplacementFor_socket_t ReplacementFor_sock,
time_t ReplacementFor_keep_alive_timeout_sec){using namespace std::chrono;auto 
ReplacementFor_start=steady_clock::now();while(true){auto val=
ReplacementFor_select_read(ReplacementFor_sock,(0x107d+3479-0x1e14),10000);if(
val<(0x132b+2933-0x1ea0)){return false;}else if(val==(0x46d+2421-0xde2)){auto 
current=steady_clock::now();auto duration=duration_cast<milliseconds>(current-
ReplacementFor_start);auto timeout=ReplacementFor_keep_alive_timeout_sec*
(0x1097+5434-0x21e9);if(duration.count()>timeout){return false;}std::this_thread
::sleep_for(std::chrono::milliseconds((0xd05+2520-0x16dc)));}else{return true;}}
}template<typename T>bool ReplacementFor_process_server_socket_core(
ReplacementFor_socket_t ReplacementFor_sock,size_t 
ReplacementFor_keep_alive_max_count,time_t ReplacementFor_keep_alive_timeout_sec
,T ReplacementFor_callback){assert(ReplacementFor_keep_alive_max_count>
(0xa40+3735-0x18d7));auto ReplacementFor_ret=false;auto count=
ReplacementFor_keep_alive_max_count;while(count>(0xe48+3202-0x1aca)&&
ReplacementFor_keep_alive(ReplacementFor_sock,
ReplacementFor_keep_alive_timeout_sec)){auto ReplacementFor_close_connection=
count==(0xc47+2624-0x1686);auto ReplacementFor_connection_closed=false;
ReplacementFor_ret=ReplacementFor_callback(ReplacementFor_close_connection,
ReplacementFor_connection_closed);if(!ReplacementFor_ret||
ReplacementFor_connection_closed){break;}count--;}return ReplacementFor_ret;}
template<typename T>bool ReplacementFor_process_server_socket(
ReplacementFor_socket_t ReplacementFor_sock,size_t 
ReplacementFor_keep_alive_max_count,time_t ReplacementFor_keep_alive_timeout_sec
,time_t ReplacementFor_read_timeout_sec,time_t ReplacementFor_read_timeout_usec,
time_t ReplacementFor_write_timeout_sec,time_t ReplacementFor_write_timeout_usec
,T ReplacementFor_callback){return ReplacementFor_process_server_socket_core(
ReplacementFor_sock,ReplacementFor_keep_alive_max_count,
ReplacementFor_keep_alive_timeout_sec,[&](bool ReplacementFor_close_connection,
bool&ReplacementFor_connection_closed){ReplacementFor_SocketStream 
ReplacementFor_strm(ReplacementFor_sock,ReplacementFor_read_timeout_sec,
ReplacementFor_read_timeout_usec,ReplacementFor_write_timeout_sec,
ReplacementFor_write_timeout_usec);return ReplacementFor_callback(
ReplacementFor_strm,ReplacementFor_close_connection,
ReplacementFor_connection_closed);});}template<typename T>bool 
ReplacementFor_process_client_socket(ReplacementFor_socket_t ReplacementFor_sock
,time_t ReplacementFor_read_timeout_sec,time_t ReplacementFor_read_timeout_usec,
time_t ReplacementFor_write_timeout_sec,time_t ReplacementFor_write_timeout_usec
,T ReplacementFor_callback){ReplacementFor_SocketStream ReplacementFor_strm(
ReplacementFor_sock,ReplacementFor_read_timeout_sec,
ReplacementFor_read_timeout_usec,ReplacementFor_write_timeout_sec,
ReplacementFor_write_timeout_usec);return ReplacementFor_callback(
ReplacementFor_strm);}int ReplacementFor_shutdown_socket(ReplacementFor_socket_t
 ReplacementFor_sock){
#ifdef _WIN32
return shutdown(ReplacementFor_sock,SD_BOTH);
#else
return shutdown(ReplacementFor_sock,SHUT_RDWR);
#endif
}template<typename ReplacementFor_BindOrConnect>ReplacementFor_socket_t 
ReplacementFor_create_socket(const char*ReplacementFor_host,int 
ReplacementFor_port,int ReplacementFor_socket_flags,bool 
ReplacementFor_tcp_nodelay,ReplacementFor_SocketOptions 
ReplacementFor_socket_options,ReplacementFor_BindOrConnect 
ReplacementFor_bind_or_connect){struct addrinfo ReplacementFor_hints;struct 
addrinfo*result;memset(&ReplacementFor_hints,(0x1d43+2495-0x2702),sizeof(struct 
addrinfo));ReplacementFor_hints.ai_family=AF_UNSPEC;ReplacementFor_hints.
ai_socktype=SOCK_STREAM;ReplacementFor_hints.ai_flags=
ReplacementFor_socket_flags;ReplacementFor_hints.ai_protocol=(0x40+5044-0x13f4);
auto ReplacementFor_service=std::to_string(ReplacementFor_port);if(getaddrinfo(
ReplacementFor_host,ReplacementFor_service.c_str(),&ReplacementFor_hints,&result
)){
#ifdef ReplacementFor___linux__
ReplacementFor_res_init();
#endif
return INVALID_SOCKET;}for(auto ReplacementFor_rp=result;ReplacementFor_rp;
ReplacementFor_rp=ReplacementFor_rp->ai_next){
#ifdef _WIN32
auto ReplacementFor_sock=WSASocketW(ReplacementFor_rp->ai_family,
ReplacementFor_rp->ai_socktype,ReplacementFor_rp->ai_protocol,nullptr,
(0x12cf+146-0x1361),ReplacementFor_WSA_FLAG_NO_HANDLE_INHERIT);if(
ReplacementFor_sock==INVALID_SOCKET){ReplacementFor_sock=socket(
ReplacementFor_rp->ai_family,ReplacementFor_rp->ai_socktype,ReplacementFor_rp->
ai_protocol);}
#else
auto ReplacementFor_sock=socket(ReplacementFor_rp->ai_family,ReplacementFor_rp->
ai_socktype,ReplacementFor_rp->ai_protocol);
#endif
if(ReplacementFor_sock==INVALID_SOCKET){continue;}
#ifndef _WIN32
if(fcntl(ReplacementFor_sock,F_SETFD,FD_CLOEXEC)==-(0x1395+1538-0x1996)){
continue;}
#endif
if(ReplacementFor_tcp_nodelay){int ReplacementFor_yes=(0xa81+4319-0x1b5f);
setsockopt(ReplacementFor_sock,IPPROTO_TCP,TCP_NODELAY,reinterpret_cast<char*>(&
ReplacementFor_yes),sizeof(ReplacementFor_yes));}if(
ReplacementFor_socket_options){ReplacementFor_socket_options(ReplacementFor_sock
);}if(ReplacementFor_rp->ai_family==AF_INET6){int ReplacementFor_no=
(0x108d+3812-0x1f71);setsockopt(ReplacementFor_sock,IPPROTO_IPV6,
ReplacementFor_IPV6_V6ONLY,reinterpret_cast<char*>(&ReplacementFor_no),sizeof(
ReplacementFor_no));}if(ReplacementFor_bind_or_connect(ReplacementFor_sock,*
ReplacementFor_rp)){freeaddrinfo(result);return ReplacementFor_sock;}
ReplacementFor_close_socket(ReplacementFor_sock);}freeaddrinfo(result);return 
INVALID_SOCKET;}void ReplacementFor_set_nonblocking(ReplacementFor_socket_t 
ReplacementFor_sock,bool ReplacementFor_nonblocking){
#ifdef _WIN32
auto flags=ReplacementFor_nonblocking?1UL:0UL;ioctlsocket(ReplacementFor_sock,
FIONBIO,&flags);
#else
auto flags=fcntl(ReplacementFor_sock,F_GETFL,(0xdcc+889-0x1145));fcntl(
ReplacementFor_sock,F_SETFL,ReplacementFor_nonblocking?(flags|O_NONBLOCK):(flags
&(~O_NONBLOCK)));
#endif
}bool ReplacementFor_is_connection_error(){
#ifdef _WIN32
return WSAGetLastError()!=WSAEWOULDBLOCK;
#else
return errno!=ReplacementFor_EINPROGRESS;
#endif
}bool ReplacementFor_bind_ip_address(ReplacementFor_socket_t ReplacementFor_sock
,const char*ReplacementFor_host){struct addrinfo ReplacementFor_hints;struct 
addrinfo*result;memset(&ReplacementFor_hints,(0x1b8+8797-0x2415),sizeof(struct 
addrinfo));ReplacementFor_hints.ai_family=AF_UNSPEC;ReplacementFor_hints.
ai_socktype=SOCK_STREAM;ReplacementFor_hints.ai_protocol=(0x2175+993-0x2556);if(
getaddrinfo(ReplacementFor_host,"\x30",&ReplacementFor_hints,&result)){return 
false;}auto ReplacementFor_ret=false;for(auto ReplacementFor_rp=result;
ReplacementFor_rp;ReplacementFor_rp=ReplacementFor_rp->ai_next){const auto&
ReplacementFor_ai=*ReplacementFor_rp;if(!::bind(ReplacementFor_sock,
ReplacementFor_ai.ai_addr,static_cast<socklen_t>(ReplacementFor_ai.ai_addrlen)))
{ReplacementFor_ret=true;break;}}freeaddrinfo(result);return ReplacementFor_ret;
}
#if !defined _WIN32 && !defined ReplacementFor_ANDROID
#define ReplacementFor_USE_IF2IP
#endif
#ifdef ReplacementFor_USE_IF2IP
std::string ReplacementFor_if2ip(const std::string&ReplacementFor_ifn){struct 
ifaddrs*ReplacementFor_ifap;getifaddrs(&ReplacementFor_ifap);for(auto 
ReplacementFor_ifa=ReplacementFor_ifap;ReplacementFor_ifa;ReplacementFor_ifa=
ReplacementFor_ifa->ifa_next){if(ReplacementFor_ifa->ifa_addr&&
ReplacementFor_ifn==ReplacementFor_ifa->ifa_name){if(ReplacementFor_ifa->
ifa_addr->sa_family==AF_INET){auto ReplacementFor_sa=reinterpret_cast<struct 
sockaddr_in*>(ReplacementFor_ifa->ifa_addr);char buf[INET_ADDRSTRLEN];if(
ReplacementFor_inet_ntop(AF_INET,&ReplacementFor_sa->sin_addr,buf,
INET_ADDRSTRLEN)){freeifaddrs(ReplacementFor_ifap);return std::string(buf,
INET_ADDRSTRLEN);}}}}freeifaddrs(ReplacementFor_ifap);return std::string();}
#endif
ReplacementFor_socket_t ReplacementFor_create_client_socket(const char*
ReplacementFor_host,int ReplacementFor_port,bool ReplacementFor_tcp_nodelay,
ReplacementFor_SocketOptions ReplacementFor_socket_options,time_t 
ReplacementFor_timeout_sec,time_t ReplacementFor_timeout_usec,const std::string&
intf,Error&error){auto ReplacementFor_sock=ReplacementFor_create_socket(
ReplacementFor_host,ReplacementFor_port,(0xa88+3513-0x1841),
ReplacementFor_tcp_nodelay,std::move(ReplacementFor_socket_options),[&](
ReplacementFor_socket_t ReplacementFor_sock,struct addrinfo&ReplacementFor_ai)->
bool{if(!intf.empty()){
#ifdef ReplacementFor_USE_IF2IP
auto ReplacementFor_ip=ReplacementFor_if2ip(intf);if(ReplacementFor_ip.empty()){
ReplacementFor_ip=intf;}if(!ReplacementFor_bind_ip_address(ReplacementFor_sock,
ReplacementFor_ip.c_str())){error=Error::ReplacementFor_BindIPAddress;return 
false;}
#endif
}ReplacementFor_set_nonblocking(ReplacementFor_sock,true);auto 
ReplacementFor_ret=::connect(ReplacementFor_sock,ReplacementFor_ai.ai_addr,
static_cast<socklen_t>(ReplacementFor_ai.ai_addrlen));if(ReplacementFor_ret<
(0x403+1916-0xb7f)){if(ReplacementFor_is_connection_error()||!
ReplacementFor_wait_until_socket_is_ready(ReplacementFor_sock,
ReplacementFor_timeout_sec,ReplacementFor_timeout_usec)){
ReplacementFor_close_socket(ReplacementFor_sock);error=Error::
ReplacementFor_Connection;return false;}}ReplacementFor_set_nonblocking(
ReplacementFor_sock,false);error=Error::ReplacementFor_Success;return true;});if
(ReplacementFor_sock!=INVALID_SOCKET){error=Error::ReplacementFor_Success;}else{
if(error==Error::ReplacementFor_Success){error=Error::ReplacementFor_Connection;
}}return ReplacementFor_sock;}void ReplacementFor_get_remote_ip_and_port(const 
struct sockaddr_storage&addr,socklen_t ReplacementFor_addr_len,std::string&
ReplacementFor_ip,int&ReplacementFor_port){if(addr.ss_family==AF_INET){
ReplacementFor_port=ntohs(reinterpret_cast<const struct sockaddr_in*>(&addr)->
sin_port);}else if(addr.ss_family==AF_INET6){ReplacementFor_port=ntohs(
reinterpret_cast<const struct sockaddr_in6*>(&addr)->sin6_port);}std::array<char
,NI_MAXHOST>ReplacementFor_ipstr{};if(!getnameinfo(reinterpret_cast<const struct
 sockaddr*>(&addr),ReplacementFor_addr_len,ReplacementFor_ipstr.data(),
static_cast<socklen_t>(ReplacementFor_ipstr.size()),nullptr,(0x5b9+6112-0x1d99),
NI_NUMERICHOST)){ReplacementFor_ip=ReplacementFor_ipstr.data();}}void 
ReplacementFor_get_remote_ip_and_port(ReplacementFor_socket_t 
ReplacementFor_sock,std::string&ReplacementFor_ip,int&ReplacementFor_port){
struct sockaddr_storage addr;socklen_t ReplacementFor_addr_len=sizeof(addr);if(!
getpeername(ReplacementFor_sock,reinterpret_cast<struct sockaddr*>(&addr),&
ReplacementFor_addr_len)){ReplacementFor_get_remote_ip_and_port(addr,
ReplacementFor_addr_len,ReplacementFor_ip,ReplacementFor_port);}}constexpr 
unsigned int ReplacementFor_str2tag_core(const char*s,size_t ReplacementFor_l,
unsigned int ReplacementFor_h){return(ReplacementFor_l==(0x19df+841-0x1d28))?
ReplacementFor_h:ReplacementFor_str2tag_core(s+(0xa71+4538-0x1c2a),
ReplacementFor_l-(0xb45+2473-0x14ed),(ReplacementFor_h*(0xe5+3479-0xe5b))^
static_cast<unsigned char>(*s));}unsigned int ReplacementFor_str2tag(const std::
string&s){return ReplacementFor_str2tag_core(s.data(),s.size(),
(0xbcf+3687-0x1a36));}namespace ReplacementFor_udl{constexpr unsigned int 
operator"" ReplacementFor__(const char*s,size_t ReplacementFor_l){return 
ReplacementFor_str2tag_core(s,ReplacementFor_l,(0x14d0+1868-0x1c1c));}}const 
char*ReplacementFor_find_content_type(const std::string&ReplacementFor_path,
const std::map<std::string,std::string>&ReplacementFor_user_data){auto 
ReplacementFor_ext=ReplacementFor_file_extension(ReplacementFor_path);auto 
ReplacementFor_it=ReplacementFor_user_data.find(ReplacementFor_ext);if(
ReplacementFor_it!=ReplacementFor_user_data.end()){return ReplacementFor_it->
second.c_str();}using ReplacementFor_udl::operator""ReplacementFor__;switch(
ReplacementFor_str2tag(ReplacementFor_ext)){default:return nullptr;case
"\x63\x73\x73"ReplacementFor__:return"\x74\x65\x78\x74\x2f\x63\x73\x73";case
"\x63\x73\x76"ReplacementFor__:return"\x74\x65\x78\x74\x2f\x63\x73\x76";case
"\x74\x78\x74"ReplacementFor__:return"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e";
case"\x76\x74\x74"ReplacementFor__:return"\x74\x65\x78\x74\x2f\x76\x74\x74";case
"\x68\x74\x6d"ReplacementFor__:case"\x68\x74\x6d\x6c"ReplacementFor__:return
"\x74\x65\x78\x74\x2f\x68\x74\x6d\x6c";case"\x61\x70\x6e\x67"ReplacementFor__:
return"\x69\x6d\x61\x67\x65\x2f\x61\x70\x6e\x67";case"\x61\x76\x69\x66"
ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x61\x76\x69\x66";case
"\x62\x6d\x70"ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x62\x6d\x70";case
"\x67\x69\x66"ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x67\x69\x66";case
"\x70\x6e\x67"ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x70\x6e\x67";case
"\x73\x76\x67"ReplacementFor__:return
"\x69\x6d\x61\x67\x65\x2f\x73\x76\x67\x2b\x78\x6d\x6c";case"\x77\x65\x62\x70"
ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x77\x65\x62\x70";case
"\x69\x63\x6f"ReplacementFor__:return
"\x69\x6d\x61\x67\x65\x2f\x78\x2d\x69\x63\x6f\x6e";case"\x74\x69\x66"
ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x74\x69\x66\x66";case
"\x74\x69\x66\x66"ReplacementFor__:return
"\x69\x6d\x61\x67\x65\x2f\x74\x69\x66\x66";case"\x6a\x70\x67"ReplacementFor__:
case"\x6a\x70\x65\x67"ReplacementFor__:return
"\x69\x6d\x61\x67\x65\x2f\x6a\x70\x65\x67";case"\x6d\x70\x34"ReplacementFor__:
return"\x76\x69\x64\x65\x6f\x2f\x6d\x70\x34";case"\x6d\x70\x65\x67"
ReplacementFor__:return"\x76\x69\x64\x65\x6f\x2f\x6d\x70\x65\x67";case
"\x77\x65\x62\x6d"ReplacementFor__:return
"\x76\x69\x64\x65\x6f\x2f\x77\x65\x62\x6d";case"\x6d\x70\x33"ReplacementFor__:
return"\x61\x75\x64\x69\x6f\x2f\x6d\x70\x33";case"\x6d\x70\x67\x61"
ReplacementFor__:return"\x61\x75\x64\x69\x6f\x2f\x6d\x70\x65\x67";case
"\x77\x65\x62\x61"ReplacementFor__:return
"\x61\x75\x64\x69\x6f\x2f\x77\x65\x62\x6d";case"\x77\x61\x76"ReplacementFor__:
return"\x61\x75\x64\x69\x6f\x2f\x77\x61\x76\x65";case"\x6f\x74\x66"
ReplacementFor__:return"\x66\x6f\x6e\x74\x2f\x6f\x74\x66";case"\x74\x74\x66"
ReplacementFor__:return"\x66\x6f\x6e\x74\x2f\x74\x74\x66";case"\x77\x6f\x66\x66"
ReplacementFor__:return"\x66\x6f\x6e\x74\x2f\x77\x6f\x66\x66";case
"\x77\x6f\x66\x66\x32"ReplacementFor__:return
"\x66\x6f\x6e\x74\x2f\x77\x6f\x66\x66\x32";case"\x37\x7a"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x37\x7a\x2d\x63\x6f\x6d\x70\x72\x65\x73\x73\x65\x64"
;case"\x61\x74\x6f\x6d"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x61\x74\x6f\x6d\x2b\x78\x6d\x6c"
;case"\x70\x64\x66"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x70\x64\x66";case"\x6a\x73"
ReplacementFor__:case"\x6d\x6a\x73"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x61\x76\x61\x73\x63\x72\x69\x70\x74"
;case"\x6a\x73\x6f\x6e"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e";case
"\x72\x73\x73"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x72\x73\x73\x2b\x78\x6d\x6c";
case"\x74\x61\x72"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x74\x61\x72";case
"\x78\x68\x74"ReplacementFor__:case"\x78\x68\x74\x6d\x6c"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x68\x74\x6d\x6c\x2b\x78\x6d\x6c"
;case"\x78\x73\x6c\x74"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x73\x6c\x74\x2b\x78\x6d\x6c"
;case"\x78\x6d\x6c"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x6d\x6c";case"\x67\x7a"
ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x67\x7a\x69\x70";case
"\x7a\x69\x70"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x7a\x69\x70";case
"\x77\x61\x73\x6d"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x77\x61\x73\x6d";}}const char*
ReplacementFor_status_message(int status){switch(status){case(0xae9+2836-0x1599)
:return"\x43";case(0x2a3+5578-0x1808):return"\x53\x20\x50";case
(0x9ac+2584-0x135e):return"\x50";case(0x66f+7167-0x2207):return"\x45\x20\x48";
case(0x6a8+8445-0x26dd):return"\x4f\x4b";case(0x1b83+2252-0x2386):return"\x43";
case(0x445+4301-0x1448):return"\x41";case(0xfa2+6192-0x2707):return
"\x4e\x41\x20\x49\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e";case
(0x560+3764-0x1348):return"\x4e\x20\x43";case(0x1049+2599-0x19a3):return
"\x52\x20\x43";case(0x1ff9+434-0x20dd):return"\x50\x20\x43";case
(0xc07+4069-0x1b1d):return"\x4d\x2d\x53";case(0x1165+547-0x12b8):return
"\x41\x20\x52";case(0x1445+2703-0x1df2):return"\x49\x4d\x20\x55\x73\x65\x64";
case(0x89f+7878-0x2639):return"\x4d\x20\x43";case(0x1f74+1637-0x24ac):return
"\x4d\x20\x50";case(0x1698+353-0x16cb):return"\x46";case(0xd5f+1172-0x10c4):
return"\x53\x20\x4f";case(0xafd+2703-0x145c):return"\x4e\x20\x4d";case
(0xa81+5628-0x1f4c):return"\x55\x20\x50";case(0x16e9+183-0x166e):return"\x75";
case(0x735+7426-0x2304):return"\x54\x20\x52";case(0x3a9+8069-0x21fa):return
"\x50\x20\x52";case(0x1757+39-0x15ee):return"\x42\x20\x52";case
(0x539+1032-0x7b0):return"\x55";case(0x818+1426-0xc18):return"\x50\x20\x52";case
(0x1fb4+1349-0x2366):return"\x46";case(0x625+2589-0xeae):return"\x4e\x20\x46";
case(0x475+1949-0xa7d):return"\x4d\x20\x4e\x20\x41";case(0xa6d+2966-0x146d):
return"\x4e\x20\x41";case(0x6b5+3617-0x133f):return"\x50\x20\x41\x20\x52";case
(0xac8+3873-0x1851):return"\x52\x20\x54\x20\x4f";case(0x6e9+2744-0x1008):return
"\x43";case(0x1831+2584-0x20af):return"\x47";case(0x440+9106-0x2637):return
"\x4c\x20\x52";case(0x445+8685-0x2496):return"\x50\x20\x46";case
(0x8d0+4248-0x17cb):return"\x50\x20\x54\x6f\x6f\x20\x4c";case(0xc6b+6230-0x2323)
:return"\x55\x52\x49\x20\x54\x6f\x6f\x20\x4c";case(0x803+3784-0x152c):return
"\x55\x20\x4d\x20\x54";case(0xabd+4899-0x1c40):return"\x52\x20\x4e\x20\x53";case
(0xb5c+4765-0x1c58):return"\x45\x20\x46";case(0x1e7c+877-0x2047):return
"\x49\x27\x6d\x20\x61\x20\x74";case(0xe22+3421-0x19da):return"\x4d\x20\x52";case
(0x110f+3465-0x1cf2):return"\x55\x20\x45";case(0x5a7+1094-0x846):return"\x4c";
case(0x19ab+1620-0x1e57):return"\x46\x20\x44";case(0xf20+6418-0x2689):return
"\x54\x6f\x6f\x20\x45";case(0x1855+446-0x1869):return"\x55\x20\x52";case
(0x216+6829-0x1b17):return"\x50\x20\x52";case(0x10a5+2168-0x1770):return
"\x54\x6f\x6f\x20\x4d\x20\x52";case(0x26a+3398-0xe01):return
"\x52\x20\x48\x20\x46\x20\x54\x6f\x6f\x20\x4c";case(0x5a9+6124-0x1bd2):return
"\x55\x20\x46\x6f\x72\x20\x4c\x20\x52";case(0x1cba+143-0x1b54):return
"\x4e\x6f\x74\x20\x49";case(0x398+2202-0xa3c):return"\x42\x20\x47";case
(0x239+9474-0x2544):return"\x53\x20\x55";case(0xf88+3835-0x1c8b):return
"\x47\x20\x54";case(0x862+476-0x845):return
"\x48\x20\x56\x20\x4e\x6f\x74\x20\x53";case(0xae9+3614-0x170d):return
"\x56\x20\x41\x20\x4e";case(0x596+7630-0x2169):return"\x49\x20\x53";case
(0x8a5+5013-0x1a3e):return"\x4c\x20\x44";case(0x607+4464-0x1579):return
"\x4e\x20\x45";case(0x10e3+3519-0x1ca3):return"\x4e\x20\x41\x20\x52";default:
case(0x880+4477-0x1809):return"\x49\x20\x53\x20\x45\x72\x72\x6f\x72";}}bool 
ReplacementFor_can_compress_content_type(const std::string&
ReplacementFor_content_type){return(!ReplacementFor_content_type.find(
"\x74\x65\x78\x74\x2f")&&ReplacementFor_content_type!=
"\x74\x65\x78\x74\x2f\x65\x76\x65\x6e\x74\x2d\x73\x74\x72\x65\x61\x6d")||
ReplacementFor_content_type==
"\x69\x6d\x61\x67\x65\x2f\x73\x76\x67\x2b\x78\x6d\x6c"||
ReplacementFor_content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x61\x76\x61\x73\x63\x72\x69\x70\x74"
||ReplacementFor_content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"||
ReplacementFor_content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x6d\x6c"||
ReplacementFor_content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x68\x74\x6d\x6c\x2b\x78\x6d\x6c"
;}enum class ReplacementFor_EncodingType{None=(0xae9+956-0xea5),
ReplacementFor_Gzip,ReplacementFor_Brotli};ReplacementFor_EncodingType 
ReplacementFor_encoding_type(const ReplacementFor_Request&ReplacementFor_req,
const ReplacementFor_Response&ReplacementFor_res){auto ReplacementFor_ret=
ReplacementFor_detail::ReplacementFor_can_compress_content_type(
ReplacementFor_res.ReplacementFor_get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65"));if(!ReplacementFor_ret){
return ReplacementFor_EncodingType::None;}const auto&s=ReplacementFor_req.
ReplacementFor_get_header_value(
"\x41\x63\x63\x65\x70\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67");(void)(s);
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
ReplacementFor_ret=s.find("\x62\x72")!=std::string::npos;if(ReplacementFor_ret){
return ReplacementFor_EncodingType::ReplacementFor_Brotli;}
#endif
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
ReplacementFor_ret=s.find("\x67\x7a\x69\x70")!=std::string::npos;if(
ReplacementFor_ret){return ReplacementFor_EncodingType::ReplacementFor_Gzip;}
#endif
return ReplacementFor_EncodingType::None;}class ReplacementFor_compressor{public
:virtual~ReplacementFor_compressor(){};typedef std::function<bool(const char*
data,size_t ReplacementFor_data_len)>ReplacementFor_Callback;virtual bool 
compress(const char*data,size_t ReplacementFor_data_length,bool 
ReplacementFor_last,ReplacementFor_Callback ReplacementFor_callback)=0;};class 
ReplacementFor_decompressor{public:virtual~ReplacementFor_decompressor(){}
virtual bool ReplacementFor_is_valid()const=0;typedef std::function<bool(const 
char*data,size_t ReplacementFor_data_len)>ReplacementFor_Callback;virtual bool 
ReplacementFor_decompress(const char*data,size_t ReplacementFor_data_length,
ReplacementFor_Callback ReplacementFor_callback)=0;};class 
ReplacementFor_nocompressor:public ReplacementFor_compressor{public:~
ReplacementFor_nocompressor(){};bool compress(const char*data,size_t 
ReplacementFor_data_length,bool,ReplacementFor_Callback ReplacementFor_callback)
override{if(!ReplacementFor_data_length){return true;}return 
ReplacementFor_callback(data,ReplacementFor_data_length);}};
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
class ReplacementFor_gzip_compressor:public ReplacementFor_compressor{public:
ReplacementFor_gzip_compressor(){std::memset(&ReplacementFor_strm_,
(0x1735+752-0x1a25),sizeof(ReplacementFor_strm_));ReplacementFor_strm_.zalloc=
ReplacementFor_Z_NULL;ReplacementFor_strm_.zfree=ReplacementFor_Z_NULL;
ReplacementFor_strm_.opaque=ReplacementFor_Z_NULL;ReplacementFor_is_valid_=
ReplacementFor_deflateInit2(&ReplacementFor_strm_,
ReplacementFor_Z_DEFAULT_COMPRESSION,ReplacementFor_Z_DEFLATED,
(0x957+3226-0x15d2),(0x19e4+1908-0x2150),ReplacementFor_Z_DEFAULT_STRATEGY)==
ReplacementFor_Z_OK;}~ReplacementFor_gzip_compressor(){deflateEnd(&
ReplacementFor_strm_);}bool compress(const char*data,size_t 
ReplacementFor_data_length,bool ReplacementFor_last,ReplacementFor_Callback 
ReplacementFor_callback)override{assert(ReplacementFor_is_valid_);auto flush=
ReplacementFor_last?ReplacementFor_Z_FINISH:ReplacementFor_Z_NO_FLUSH;
ReplacementFor_strm_.avail_in=static_cast<decltype(ReplacementFor_strm_.avail_in
)>(ReplacementFor_data_length);ReplacementFor_strm_.next_in=const_cast<Bytef*>(
reinterpret_cast<const Bytef*>(data));int ReplacementFor_ret=ReplacementFor_Z_OK
;std::array<char,ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ>
ReplacementFor_buff{};do{ReplacementFor_strm_.avail_out=ReplacementFor_buff.size
();ReplacementFor_strm_.next_out=reinterpret_cast<Bytef*>(ReplacementFor_buff.
data());ReplacementFor_ret=deflate(&ReplacementFor_strm_,flush);if(
ReplacementFor_ret==ReplacementFor_Z_STREAM_ERROR){return false;}if(!
ReplacementFor_callback(ReplacementFor_buff.data(),ReplacementFor_buff.size()-
ReplacementFor_strm_.avail_out)){return false;}}while(ReplacementFor_strm_.
avail_out==(0xf3a+1634-0x159c));assert((ReplacementFor_last&&ReplacementFor_ret
==ReplacementFor_Z_STREAM_END)||(!ReplacementFor_last&&ReplacementFor_ret==
ReplacementFor_Z_OK));assert(ReplacementFor_strm_.avail_in==(0x13f1+2283-0x1cdc)
);return true;}private:bool ReplacementFor_is_valid_=false;z_stream 
ReplacementFor_strm_;};class ReplacementFor_gzip_decompressor:public 
ReplacementFor_decompressor{public:ReplacementFor_gzip_decompressor(){std::
memset(&ReplacementFor_strm_,(0x146+3040-0xd26),sizeof(ReplacementFor_strm_));
ReplacementFor_strm_.zalloc=ReplacementFor_Z_NULL;ReplacementFor_strm_.zfree=
ReplacementFor_Z_NULL;ReplacementFor_strm_.opaque=ReplacementFor_Z_NULL;
ReplacementFor_is_valid_=ReplacementFor_inflateInit2(&ReplacementFor_strm_,
(0x2dc+1618-0x90e)+(0x1118+2841-0x1c22))==ReplacementFor_Z_OK;}~
ReplacementFor_gzip_decompressor(){inflateEnd(&ReplacementFor_strm_);}bool 
ReplacementFor_is_valid()const override{return ReplacementFor_is_valid_;}bool 
ReplacementFor_decompress(const char*data,size_t ReplacementFor_data_length,
ReplacementFor_Callback ReplacementFor_callback)override{assert(
ReplacementFor_is_valid_);int ReplacementFor_ret=ReplacementFor_Z_OK;
ReplacementFor_strm_.avail_in=static_cast<decltype(ReplacementFor_strm_.avail_in
)>(ReplacementFor_data_length);ReplacementFor_strm_.next_in=const_cast<Bytef*>(
reinterpret_cast<const Bytef*>(data));std::array<char,
ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ>ReplacementFor_buff{};while(
ReplacementFor_strm_.avail_in>(0x1649+2075-0x1e64)){ReplacementFor_strm_.
avail_out=ReplacementFor_buff.size();ReplacementFor_strm_.next_out=
reinterpret_cast<Bytef*>(ReplacementFor_buff.data());ReplacementFor_ret=inflate(
&ReplacementFor_strm_,ReplacementFor_Z_NO_FLUSH);assert(ReplacementFor_ret!=
ReplacementFor_Z_STREAM_ERROR);switch(ReplacementFor_ret){case 
ReplacementFor_Z_NEED_DICT:case ReplacementFor_Z_DATA_ERROR:case 
ReplacementFor_Z_MEM_ERROR:inflateEnd(&ReplacementFor_strm_);return false;}if(!
ReplacementFor_callback(ReplacementFor_buff.data(),ReplacementFor_buff.size()-
ReplacementFor_strm_.avail_out)){return false;}}return ReplacementFor_ret==
ReplacementFor_Z_OK||ReplacementFor_ret==ReplacementFor_Z_STREAM_END;}private:
bool ReplacementFor_is_valid_=false;z_stream ReplacementFor_strm_;};
#endif
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
class ReplacementFor_brotli_compressor:public ReplacementFor_compressor{public:
ReplacementFor_brotli_compressor(){ReplacementFor_state_=
ReplacementFor_BrotliEncoderCreateInstance(nullptr,nullptr,nullptr);}~
ReplacementFor_brotli_compressor(){ReplacementFor_BrotliEncoderDestroyInstance(
ReplacementFor_state_);}bool compress(const char*data,size_t 
ReplacementFor_data_length,bool ReplacementFor_last,ReplacementFor_Callback 
ReplacementFor_callback)override{std::array<uint8_t,
ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ>ReplacementFor_buff{};auto 
ReplacementFor_operation=ReplacementFor_last?
ReplacementFor_BROTLI_OPERATION_FINISH:ReplacementFor_BROTLI_OPERATION_PROCESS;
auto ReplacementFor_available_in=ReplacementFor_data_length;auto next_in=
reinterpret_cast<const uint8_t*>(data);for(;;){if(ReplacementFor_last){if(
ReplacementFor_BrotliEncoderIsFinished(ReplacementFor_state_)){break;}}else{if(!
ReplacementFor_available_in){break;}}auto ReplacementFor_available_out=
ReplacementFor_buff.size();auto next_out=ReplacementFor_buff.data();if(!
ReplacementFor_BrotliEncoderCompressStream(ReplacementFor_state_,
ReplacementFor_operation,&ReplacementFor_available_in,&next_in,&
ReplacementFor_available_out,&next_out,nullptr)){return false;}auto 
ReplacementFor_output_bytes=ReplacementFor_buff.size()-
ReplacementFor_available_out;if(ReplacementFor_output_bytes){
ReplacementFor_callback(reinterpret_cast<const char*>(ReplacementFor_buff.data()
),ReplacementFor_output_bytes);}}return true;}private:
ReplacementFor_BrotliEncoderState*ReplacementFor_state_=nullptr;};class 
ReplacementFor_brotli_decompressor:public ReplacementFor_decompressor{public:
ReplacementFor_brotli_decompressor(){ReplacementFor_decoder_s=
ReplacementFor_BrotliDecoderCreateInstance((0x16b+6688-0x1b8b),
(0x20b+4725-0x1480),(0x5d2+5247-0x1a51));ReplacementFor_decoder_r=
ReplacementFor_decoder_s?ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT:
ReplacementFor_BROTLI_DECODER_RESULT_ERROR;}~ReplacementFor_brotli_decompressor(
){if(ReplacementFor_decoder_s){ReplacementFor_BrotliDecoderDestroyInstance(
ReplacementFor_decoder_s);}}bool ReplacementFor_is_valid()const override{return 
ReplacementFor_decoder_s;}bool ReplacementFor_decompress(const char*data,size_t 
ReplacementFor_data_length,ReplacementFor_Callback ReplacementFor_callback)
override{if(ReplacementFor_decoder_r==
ReplacementFor_BROTLI_DECODER_RESULT_SUCCESS||ReplacementFor_decoder_r==
ReplacementFor_BROTLI_DECODER_RESULT_ERROR){return(0xdc5+581-0x100a);}const 
uint8_t*next_in=(const uint8_t*)data;size_t avail_in=ReplacementFor_data_length;
size_t total_out;ReplacementFor_decoder_r=
ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT;std::array<char,
ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ>ReplacementFor_buff{};while(
ReplacementFor_decoder_r==ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT
){char*next_out=ReplacementFor_buff.data();size_t avail_out=ReplacementFor_buff.
size();ReplacementFor_decoder_r=ReplacementFor_BrotliDecoderDecompressStream(
ReplacementFor_decoder_s,&avail_in,&next_in,&avail_out,reinterpret_cast<uint8_t*
*>(&next_out),&total_out);if(ReplacementFor_decoder_r==
ReplacementFor_BROTLI_DECODER_RESULT_ERROR){return false;}if(!
ReplacementFor_callback(ReplacementFor_buff.data(),ReplacementFor_buff.size()-
avail_out)){return false;}}return ReplacementFor_decoder_r==
ReplacementFor_BROTLI_DECODER_RESULT_SUCCESS||ReplacementFor_decoder_r==
ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT;}private:
ReplacementFor_BrotliDecoderResult ReplacementFor_decoder_r;
ReplacementFor_BrotliDecoderState*ReplacementFor_decoder_s=nullptr;};
#endif
bool ReplacementFor_has_header(const ReplacementFor_Headers&
ReplacementFor_headers,const char*key){return ReplacementFor_headers.find(key)!=
ReplacementFor_headers.end();}const char*ReplacementFor_get_header_value(const 
ReplacementFor_Headers&ReplacementFor_headers,const char*key,size_t id=
(0x269+5755-0x18e4),const char*ReplacementFor_def=nullptr){auto 
ReplacementFor_rng=ReplacementFor_headers.equal_range(key);auto 
ReplacementFor_it=ReplacementFor_rng.first;std::advance(ReplacementFor_it,
static_cast<ssize_t>(id));if(ReplacementFor_it!=ReplacementFor_rng.second){
return ReplacementFor_it->second.c_str();}return ReplacementFor_def;}template<
typename T>T ReplacementFor_get_header_value(const ReplacementFor_Headers&,const
 char*,size_t=(0x198f+1532-0x1f8b),uint64_t=(0xf75+3661-0x1dc2)){}template<>
uint64_t ReplacementFor_get_header_value<uint64_t>(const ReplacementFor_Headers&
ReplacementFor_headers,const char*key,size_t id,uint64_t ReplacementFor_def){
auto ReplacementFor_rng=ReplacementFor_headers.equal_range(key);auto 
ReplacementFor_it=ReplacementFor_rng.first;std::advance(ReplacementFor_it,
static_cast<ssize_t>(id));if(ReplacementFor_it!=ReplacementFor_rng.second){
return std::strtoull(ReplacementFor_it->second.data(),nullptr,
(0x371+6688-0x1d87));}return ReplacementFor_def;}template<typename T>bool 
ReplacementFor_parse_header(const char*beg,const char*end,T ReplacementFor_fn){
while(beg<end&&ReplacementFor_is_space_or_tab(end[-(0x1640+3387-0x237a)])){end--
;}auto p=beg;while(p<end&&*p!=((char)(0xd46+5541-0x22b1))){p++;}if(p==end){
return false;}auto ReplacementFor_key_end=p;if(*p++!=
((char)(0x1dd9+2107-0x25da))){return false;}while(p<end&&
ReplacementFor_is_space_or_tab(*p)){p++;}if(p<end){ReplacementFor_fn(std::string
(beg,ReplacementFor_key_end),ReplacementFor_decode_url(std::string(p,end),false)
);return true;}return false;}bool ReplacementFor_read_headers(
ReplacementFor_Stream&ReplacementFor_strm,ReplacementFor_Headers&
ReplacementFor_headers){const auto ReplacementFor_bufsiz=(0xc81+12-0x48d);char 
buf[ReplacementFor_bufsiz];ReplacementFor_stream_line_reader 
ReplacementFor_line_reader(ReplacementFor_strm,buf,ReplacementFor_bufsiz);for(;;
){if(!ReplacementFor_line_reader.getline()){return false;}if(
ReplacementFor_line_reader.ReplacementFor_end_with_crlf()){if(
ReplacementFor_line_reader.size()==(0x17ed+3396-0x252f)){break;}}else{continue;}
auto end=ReplacementFor_line_reader.ReplacementFor_ptr()+
ReplacementFor_line_reader.size()-(0x15e6+4392-0x270c);
ReplacementFor_parse_header(ReplacementFor_line_reader.ReplacementFor_ptr(),end,
[&](std::string&&key,std::string&&val){ReplacementFor_headers.emplace(std::move(
key),std::move(val));});}return true;}bool 
ReplacementFor_read_content_with_length(ReplacementFor_Stream&
ReplacementFor_strm,uint64_t len,ReplacementFor_Progress ReplacementFor_progress
,ReplacementFor_ContentReceiverWithProgress out){char buf[
ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ];uint64_t ReplacementFor_r=
(0x15b3+1169-0x1a44);while(ReplacementFor_r<len){auto ReplacementFor_read_len=
static_cast<size_t>(len-ReplacementFor_r);auto n=ReplacementFor_strm.read(buf,(
std::min)(ReplacementFor_read_len,ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ));if(n<=
(0x45f+5193-0x18a8)){return false;}if(!out(buf,static_cast<size_t>(n),
ReplacementFor_r,len)){return false;}ReplacementFor_r+=static_cast<uint64_t>(n);
if(ReplacementFor_progress){if(!ReplacementFor_progress(ReplacementFor_r,len)){
return false;}}}return true;}void ReplacementFor_skip_content_with_length(
ReplacementFor_Stream&ReplacementFor_strm,uint64_t len){char buf[
ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ];uint64_t ReplacementFor_r=
(0x10fa+3826-0x1fec);while(ReplacementFor_r<len){auto ReplacementFor_read_len=
static_cast<size_t>(len-ReplacementFor_r);auto n=ReplacementFor_strm.read(buf,(
std::min)(ReplacementFor_read_len,ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ));if(n<=
(0x654+3760-0x1504)){return;}ReplacementFor_r+=static_cast<uint64_t>(n);}}bool 
ReplacementFor_read_content_without_length(ReplacementFor_Stream&
ReplacementFor_strm,ReplacementFor_ContentReceiverWithProgress out){char buf[
ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ];uint64_t ReplacementFor_r=
(0x97+7469-0x1dc4);for(;;){auto n=ReplacementFor_strm.read(buf,
ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ);if(n<(0xa4f+2417-0x13c0)){return false;}
else if(n==(0x1b11+869-0x1e76)){return true;}if(!out(buf,static_cast<size_t>(n),
ReplacementFor_r,(0x2d8+3666-0x112a))){return false;}ReplacementFor_r+=
static_cast<uint64_t>(n);}return true;}bool ReplacementFor_read_content_chunked(
ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_ContentReceiverWithProgress out){const auto ReplacementFor_bufsiz
=(0x1367+2237-0x1c14);char buf[ReplacementFor_bufsiz];
ReplacementFor_stream_line_reader ReplacementFor_line_reader(ReplacementFor_strm
,buf,ReplacementFor_bufsiz);if(!ReplacementFor_line_reader.getline()){return 
false;}unsigned long ReplacementFor_chunk_len;while(true){char*end_ptr;
ReplacementFor_chunk_len=std::strtoul(ReplacementFor_line_reader.
ReplacementFor_ptr(),&end_ptr,(0x55f+6855-0x2016));if(end_ptr==
ReplacementFor_line_reader.ReplacementFor_ptr()){return false;}if(
ReplacementFor_chunk_len==ULONG_MAX){return false;}if(ReplacementFor_chunk_len==
(0x5e7+4359-0x16ee)){break;}if(!ReplacementFor_read_content_with_length(
ReplacementFor_strm,ReplacementFor_chunk_len,nullptr,out)){return false;}if(!
ReplacementFor_line_reader.getline()){return false;}if(strcmp(
ReplacementFor_line_reader.ReplacementFor_ptr(),"\r\n")){break;}if(!
ReplacementFor_line_reader.getline()){return false;}}if(ReplacementFor_chunk_len
==(0xccc+5690-0x2306)){if(!ReplacementFor_line_reader.getline()||strcmp(
ReplacementFor_line_reader.ReplacementFor_ptr(),"\r\n"))return false;}return 
true;}bool ReplacementFor_is_chunked_transfer_encoding(const 
ReplacementFor_Headers&ReplacementFor_headers){return!strcasecmp(
ReplacementFor_get_header_value(ReplacementFor_headers,
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
(0x21aa+1204-0x265e),""),"\x63\x68\x75\x6e\x6b\x65\x64");}template<typename T,
typename U>bool ReplacementFor_prepare_content_receiver(T&x,int&status,
ReplacementFor_ContentReceiverWithProgress ReplacementFor_receiver,bool 
ReplacementFor_decompress,U ReplacementFor_callback){if(
ReplacementFor_decompress){std::string encoding=x.
ReplacementFor_get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67");std::
unique_ptr<ReplacementFor_decompressor>ReplacementFor_decompressor;if(encoding.
find("\x67\x7a\x69\x70")!=std::string::npos||encoding.find(
"\x64\x65\x66\x6c\x61\x74\x65")!=std::string::npos){
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
ReplacementFor_decompressor=ReplacementFor_detail::make_unique<
ReplacementFor_gzip_decompressor>();
#else
status=(0xed3+6230-0x258a);return false;
#endif
}else if(encoding.find("\x62\x72")!=std::string::npos){
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
ReplacementFor_decompressor=ReplacementFor_detail::make_unique<
ReplacementFor_brotli_decompressor>();
#else
status=(0x1eb4+2527-0x26f4);return false;
#endif
}if(ReplacementFor_decompressor){if(ReplacementFor_decompressor->
ReplacementFor_is_valid()){ReplacementFor_ContentReceiverWithProgress out=[&](
const char*buf,size_t n,uint64_t ReplacementFor_off,uint64_t len){return 
ReplacementFor_decompressor->ReplacementFor_decompress(buf,n,[&](const char*buf,
size_t n){return ReplacementFor_receiver(buf,n,ReplacementFor_off,len);});};
return ReplacementFor_callback(std::move(out));}else{status=(0xd46+4297-0x1c1b);
return false;}}}ReplacementFor_ContentReceiverWithProgress out=[&](const char*
buf,size_t n,uint64_t ReplacementFor_off,uint64_t len){return 
ReplacementFor_receiver(buf,n,ReplacementFor_off,len);};return 
ReplacementFor_callback(std::move(out));}template<typename T>bool 
ReplacementFor_read_content(ReplacementFor_Stream&ReplacementFor_strm,T&x,size_t
 ReplacementFor_payload_max_length,int&status,ReplacementFor_Progress 
ReplacementFor_progress,ReplacementFor_ContentReceiverWithProgress 
ReplacementFor_receiver,bool ReplacementFor_decompress){return 
ReplacementFor_prepare_content_receiver(x,status,std::move(
ReplacementFor_receiver),ReplacementFor_decompress,[&](const 
ReplacementFor_ContentReceiverWithProgress&out){auto ReplacementFor_ret=true;
auto ReplacementFor_exceed_payload_max_length=false;if(
ReplacementFor_is_chunked_transfer_encoding(x.ReplacementFor_headers)){
ReplacementFor_ret=ReplacementFor_read_content_chunked(ReplacementFor_strm,out);
}else if(!ReplacementFor_has_header(x.ReplacementFor_headers,
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){ReplacementFor_ret=
ReplacementFor_read_content_without_length(ReplacementFor_strm,out);}else{auto 
len=ReplacementFor_get_header_value<uint64_t>(x.ReplacementFor_headers,
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68");if(len>
ReplacementFor_payload_max_length){ReplacementFor_exceed_payload_max_length=true
;ReplacementFor_skip_content_with_length(ReplacementFor_strm,len);
ReplacementFor_ret=false;}else if(len>(0x592+129-0x613)){ReplacementFor_ret=
ReplacementFor_read_content_with_length(ReplacementFor_strm,len,std::move(
ReplacementFor_progress),out);}}if(!ReplacementFor_ret){status=
ReplacementFor_exceed_payload_max_length?(0x2369+1212-0x2688):
(0x263+5872-0x17c3);}return ReplacementFor_ret;});}ssize_t 
ReplacementFor_write_headers(ReplacementFor_Stream&ReplacementFor_strm,const 
ReplacementFor_Headers&ReplacementFor_headers){ssize_t ReplacementFor_write_len=
(0x1f50+870-0x22b6);for(const auto&x:ReplacementFor_headers){auto len=
ReplacementFor_strm.ReplacementFor_write_format(
"\x25\x73\x3a\x20\x25\x73" "\r\n",x.first.c_str(),x.second.c_str());if(len<
(0x885+4416-0x19c5)){return len;}ReplacementFor_write_len+=len;}auto len=
ReplacementFor_strm.write("\r\n");if(len<(0x87d+6578-0x222f)){return len;}
ReplacementFor_write_len+=len;return ReplacementFor_write_len;}bool 
ReplacementFor_write_data(ReplacementFor_Stream&ReplacementFor_strm,const char*
ReplacementFor_d,size_t ReplacementFor_l){size_t offset=(0x263+3975-0x11ea);
while(offset<ReplacementFor_l){auto length=ReplacementFor_strm.write(
ReplacementFor_d+offset,ReplacementFor_l-offset);if(length<(0x1dcd+1258-0x22b7))
{return false;}offset+=static_cast<size_t>(length);}return true;}template<
typename T>bool ReplacementFor_write_content(ReplacementFor_Stream&
ReplacementFor_strm,const ReplacementFor_ContentProvider&
ReplacementFor_content_provider,size_t offset,size_t length,T 
ReplacementFor_is_shutting_down,Error&error){size_t ReplacementFor_end_offset=
offset+length;auto ok=true;ReplacementFor_DataSink ReplacementFor_data_sink;
ReplacementFor_data_sink.write=[&](const char*ReplacementFor_d,size_t 
ReplacementFor_l){if(ok){if(ReplacementFor_write_data(ReplacementFor_strm,
ReplacementFor_d,ReplacementFor_l)){offset+=ReplacementFor_l;}else{ok=false;}}};
ReplacementFor_data_sink.ReplacementFor_is_writable=[&](void){return ok&&
ReplacementFor_strm.ReplacementFor_is_writable();};while(offset<
ReplacementFor_end_offset&&!ReplacementFor_is_shutting_down()){if(!
ReplacementFor_content_provider(offset,ReplacementFor_end_offset-offset,
ReplacementFor_data_sink)){error=Error::ReplacementFor_Canceled;return false;}if
(!ok){error=Error::Write;return false;}}error=Error::ReplacementFor_Success;
return true;}template<typename T>bool ReplacementFor_write_content(
ReplacementFor_Stream&ReplacementFor_strm,const ReplacementFor_ContentProvider&
ReplacementFor_content_provider,size_t offset,size_t length,const T&
ReplacementFor_is_shutting_down){auto error=Error::ReplacementFor_Success;return
 ReplacementFor_write_content(ReplacementFor_strm,
ReplacementFor_content_provider,offset,length,ReplacementFor_is_shutting_down,
error);}template<typename T>bool ReplacementFor_write_content_without_length(
ReplacementFor_Stream&ReplacementFor_strm,const ReplacementFor_ContentProvider&
ReplacementFor_content_provider,const T&ReplacementFor_is_shutting_down){size_t 
offset=(0x1e2+7158-0x1dd8);auto ReplacementFor_data_available=true;auto ok=true;
ReplacementFor_DataSink ReplacementFor_data_sink;ReplacementFor_data_sink.write=
[&](const char*ReplacementFor_d,size_t ReplacementFor_l){if(ok){offset+=
ReplacementFor_l;if(!ReplacementFor_write_data(ReplacementFor_strm,
ReplacementFor_d,ReplacementFor_l)){ok=false;}}};ReplacementFor_data_sink.done=[
&](void){ReplacementFor_data_available=false;};ReplacementFor_data_sink.
ReplacementFor_is_writable=[&](void){return ok&&ReplacementFor_strm.
ReplacementFor_is_writable();};while(ReplacementFor_data_available&&!
ReplacementFor_is_shutting_down()){if(!ReplacementFor_content_provider(offset,
(0x1470+3565-0x225d),ReplacementFor_data_sink)){return false;}if(!ok){return 
false;}}return true;}template<typename T,typename U>bool 
ReplacementFor_write_content_chunked(ReplacementFor_Stream&ReplacementFor_strm,
const ReplacementFor_ContentProvider&ReplacementFor_content_provider,const T&
ReplacementFor_is_shutting_down,U&ReplacementFor_compressor,Error&error){size_t 
offset=(0x12c9+1047-0x16e0);auto ReplacementFor_data_available=true;auto ok=true
;ReplacementFor_DataSink ReplacementFor_data_sink;ReplacementFor_data_sink.write
=[&](const char*ReplacementFor_d,size_t ReplacementFor_l){if(!ok){return;}
ReplacementFor_data_available=ReplacementFor_l>(0x352+6688-0x1d72);offset+=
ReplacementFor_l;std::string ReplacementFor_payload;if(!
ReplacementFor_compressor.compress(ReplacementFor_d,ReplacementFor_l,false,[&](
const char*data,size_t ReplacementFor_data_len){ReplacementFor_payload.append(
data,ReplacementFor_data_len);return true;})){ok=false;return;}if(!
ReplacementFor_payload.empty()){auto ReplacementFor_chunk=
ReplacementFor_from_i_to_hex(ReplacementFor_payload.size())+"\r\n"+
ReplacementFor_payload+"\r\n";if(!ReplacementFor_write_data(ReplacementFor_strm,
ReplacementFor_chunk.data(),ReplacementFor_chunk.size())){ok=false;return;}}};
ReplacementFor_data_sink.done=[&](void){if(!ok){return;}
ReplacementFor_data_available=false;std::string ReplacementFor_payload;if(!
ReplacementFor_compressor.compress(nullptr,(0x79c+6888-0x2284),true,[&](const 
char*data,size_t ReplacementFor_data_len){ReplacementFor_payload.append(data,
ReplacementFor_data_len);return true;})){ok=false;return;}if(!
ReplacementFor_payload.empty()){auto ReplacementFor_chunk=
ReplacementFor_from_i_to_hex(ReplacementFor_payload.size())+"\r\n"+
ReplacementFor_payload+"\r\n";if(!ReplacementFor_write_data(ReplacementFor_strm,
ReplacementFor_chunk.data(),ReplacementFor_chunk.size())){ok=false;return;}}
static const std::string ReplacementFor_done_marker("\x30" "\r\n\r\n");if(!
ReplacementFor_write_data(ReplacementFor_strm,ReplacementFor_done_marker.data(),
ReplacementFor_done_marker.size())){ok=false;}};ReplacementFor_data_sink.
ReplacementFor_is_writable=[&](void){return ok&&ReplacementFor_strm.
ReplacementFor_is_writable();};while(ReplacementFor_data_available&&!
ReplacementFor_is_shutting_down()){if(!ReplacementFor_content_provider(offset,
(0x24d1+176-0x2581),ReplacementFor_data_sink)){error=Error::
ReplacementFor_Canceled;return false;}if(!ok){error=Error::Write;return false;}}
error=Error::ReplacementFor_Success;return true;}template<typename T,typename U>
bool ReplacementFor_write_content_chunked(ReplacementFor_Stream&
ReplacementFor_strm,const ReplacementFor_ContentProvider&
ReplacementFor_content_provider,const T&ReplacementFor_is_shutting_down,U&
ReplacementFor_compressor){auto error=Error::ReplacementFor_Success;return 
ReplacementFor_write_content_chunked(ReplacementFor_strm,
ReplacementFor_content_provider,ReplacementFor_is_shutting_down,
ReplacementFor_compressor,error);}template<typename T>bool 
ReplacementFor_redirect(T&ReplacementFor_cli,ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res,const std::string&
ReplacementFor_path,const std::string&ReplacementFor_location,Error&error){
ReplacementFor_Request ReplacementFor_new_req=ReplacementFor_req;
ReplacementFor_new_req.ReplacementFor_path=ReplacementFor_path;
ReplacementFor_new_req.ReplacementFor_redirect_count_-=(0x73f+5700-0x1d82);if(
ReplacementFor_res.status==(0x153+396-0x1b0)&&(ReplacementFor_req.
ReplacementFor_method!="\x47\x45\x54"&&ReplacementFor_req.ReplacementFor_method
!="\x48\x45\x41\x44")){ReplacementFor_new_req.ReplacementFor_method=
"\x47\x45\x54";ReplacementFor_new_req.ReplacementFor_body.clear();
ReplacementFor_new_req.ReplacementFor_headers.clear();}ReplacementFor_Response 
ReplacementFor_new_res;auto ReplacementFor_ret=ReplacementFor_cli.send(
ReplacementFor_new_req,ReplacementFor_new_res,error);if(ReplacementFor_ret){
ReplacementFor_req=ReplacementFor_new_req;ReplacementFor_res=
ReplacementFor_new_res;ReplacementFor_res.ReplacementFor_location=
ReplacementFor_location;}return ReplacementFor_ret;}std::string 
ReplacementFor_params_to_query_str(const ReplacementFor_Params&
ReplacementFor_params){std::string ReplacementFor_query;for(auto 
ReplacementFor_it=ReplacementFor_params.begin();ReplacementFor_it!=
ReplacementFor_params.end();++ReplacementFor_it){if(ReplacementFor_it!=
ReplacementFor_params.begin()){ReplacementFor_query+="\x26";}
ReplacementFor_query+=ReplacementFor_it->first;ReplacementFor_query+="\x3d";
ReplacementFor_query+=ReplacementFor_encode_query_param(ReplacementFor_it->
second);}return ReplacementFor_query;}std::string 
ReplacementFor_append_query_params(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params){std::string 
ReplacementFor_path_with_query=ReplacementFor_path;const static std::regex 
ReplacementFor_re("\x5b\x5e\x3f\x5d\x2b" "\\" "\x3f\x2e\x2a");auto 
ReplacementFor_delm=std::regex_match(ReplacementFor_path,ReplacementFor_re)?
((char)(0x9d1+4507-0x1b46)):((char)(0x4d4+851-0x7e8));
ReplacementFor_path_with_query+=ReplacementFor_delm+
ReplacementFor_params_to_query_str(ReplacementFor_params);return 
ReplacementFor_path_with_query;}void ReplacementFor_parse_query_text(const std::
string&s,ReplacementFor_Params&ReplacementFor_params){ReplacementFor_split(s.
data(),s.data()+s.size(),((char)(0x1671+505-0x1844)),[&](const char*b,const char
*ReplacementFor_e){std::string key;std::string val;ReplacementFor_split(b,
ReplacementFor_e,((char)(0xd29+5892-0x23f0)),[&](const char*ReplacementFor_b2,
const char*ReplacementFor_e2){if(key.empty()){key.assign(ReplacementFor_b2,
ReplacementFor_e2);}else{val.assign(ReplacementFor_b2,ReplacementFor_e2);}});if(
!key.empty()){ReplacementFor_params.emplace(ReplacementFor_decode_url(key,true),
ReplacementFor_decode_url(val,true));}});}bool 
ReplacementFor_parse_multipart_boundary(const std::string&
ReplacementFor_content_type,std::string&ReplacementFor_boundary){auto pos=
ReplacementFor_content_type.find("\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d");if(pos
==std::string::npos){return false;}ReplacementFor_boundary=
ReplacementFor_content_type.substr(pos+(0x299+3651-0x10d3));if(
ReplacementFor_boundary.length()>=(0x1bf5+2368-0x2533)&&ReplacementFor_boundary.
front()==((char)(0x1e4f+351-0x1f8c))&&ReplacementFor_boundary.back()==
((char)(0x230+4002-0x11b0))){ReplacementFor_boundary=ReplacementFor_boundary.
substr((0x233+7318-0x1ec8),ReplacementFor_boundary.size()-(0x386+1009-0x775));}
return!ReplacementFor_boundary.empty();}bool ReplacementFor_parse_range_header(
const std::string&s,Ranges&ranges)try{static auto ReplacementFor_re_first_range=
std::regex(R"(bytes=(\d*-\d*(?:,\s*\d*-\d*)*))");std::smatch m;if(std::
regex_match(s,m,ReplacementFor_re_first_range)){auto pos=static_cast<size_t>(m.
position((0xc20+559-0xe4e)));auto len=static_cast<size_t>(m.length(
(0x37a+4042-0x1343)));bool ReplacementFor_all_valid_ranges=true;
ReplacementFor_split(&s[pos],&s[pos+len],((char)(0x12df+618-0x151d)),[&](const 
char*b,const char*ReplacementFor_e){if(!ReplacementFor_all_valid_ranges)return;
static auto ReplacementFor_re_another_range=std::regex(R"(\s*(\d*)-(\d*))");std
::cmatch ReplacementFor_cm;if(std::regex_match(b,ReplacementFor_e,
ReplacementFor_cm,ReplacementFor_re_another_range)){ssize_t first=-
(0x81d+1965-0xfc9);if(!ReplacementFor_cm.str((0x6f6+2772-0x11c9)).empty()){first
=static_cast<ssize_t>(std::stoll(ReplacementFor_cm.str((0x13c1+602-0x161a))));}
ssize_t ReplacementFor_last=-(0x3c+8075-0x1fc6);if(!ReplacementFor_cm.str(
(0x1502+2943-0x207f)).empty()){ReplacementFor_last=static_cast<ssize_t>(std::
stoll(ReplacementFor_cm.str((0xcb8+5602-0x2298))));}if(first!=-
(0x2ec+3483-0x1086)&&ReplacementFor_last!=-(0xd51+2165-0x15c5)&&first>
ReplacementFor_last){ReplacementFor_all_valid_ranges=false;return;}ranges.
emplace_back(std::make_pair(first,ReplacementFor_last));}});return 
ReplacementFor_all_valid_ranges;}return false;}catch(...){return false;}class 
ReplacementFor_MultipartFormDataParser{public:
ReplacementFor_MultipartFormDataParser()=default;void 
ReplacementFor_set_boundary(std::string&&ReplacementFor_boundary){
ReplacementFor_boundary_=ReplacementFor_boundary;}bool ReplacementFor_is_valid()
const{return ReplacementFor_is_valid_;}bool ReplacementFor_parse(const char*buf,
size_t n,const ReplacementFor_ContentReceiver&ReplacementFor_content_callback,
const ReplacementFor_MultipartContentHeader&ReplacementFor_header_callback){
static const std::regex ReplacementFor_re_content_disposition(
"\x5e\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x44\x69\x73\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a" "\\" "\x73\x2a\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b" "\\" "\x73\x2a\x6e\x61\x6d\x65\x3d" "\"" "\x28\x2e\x2a\x3f\x29" "\"" "\x28\x3f\x3a\x3b" "\\" "\x73\x2a\x66\x69\x6c\x65\x6e\x61\x6d\x65\x3d"
"\"" "\x28\x2e\x2a\x3f\x29" "\"" "\x29\x3f" "\\" "\x73\x2a\x24",std::
regex_constants::icase);static const std::string ReplacementFor_dash_="\x2d\x2d"
;static const std::string ReplacementFor_crlf_="\r\n";ReplacementFor_buf_.append
(buf,n);while(!ReplacementFor_buf_.empty()){switch(ReplacementFor_state_){case
(0x1c19+389-0x1d9e):{auto pattern=ReplacementFor_dash_+ReplacementFor_boundary_+
ReplacementFor_crlf_;if(pattern.size()>ReplacementFor_buf_.size()){return true;}
auto pos=ReplacementFor_buf_.find(pattern);if(pos!=(0x5a7+4520-0x174f)){return 
false;}ReplacementFor_buf_.erase((0x105f+1762-0x1741),pattern.size());
ReplacementFor_off_+=pattern.size();ReplacementFor_state_=(0xd1d+461-0xee9);
break;}case(0x3b8+3862-0x12cd):{ReplacementFor_clear_file_info();
ReplacementFor_state_=(0x6+1365-0x559);break;}case(0x11f+8035-0x2080):{auto pos=
ReplacementFor_buf_.find(ReplacementFor_crlf_);while(pos!=std::string::npos){if(
pos==(0x10c+2923-0xc77)){if(!ReplacementFor_header_callback(ReplacementFor_file_
)){ReplacementFor_is_valid_=false;return false;}ReplacementFor_buf_.erase(
(0x923+1168-0xdb3),ReplacementFor_crlf_.size());ReplacementFor_off_+=
ReplacementFor_crlf_.size();ReplacementFor_state_=(0x9a+5084-0x1473);break;}
static const std::string ReplacementFor_header_name=
"\x63\x6f\x6e\x74\x65\x6e\x74\x2d\x74\x79\x70\x65\x3a";const auto header=
ReplacementFor_buf_.substr((0x1ac+6470-0x1af2),pos);if(
ReplacementFor_start_with_case_ignore(header,ReplacementFor_header_name)){
ReplacementFor_file_.ReplacementFor_content_type=ReplacementFor_trim_copy(header
.substr(ReplacementFor_header_name.size()));}else{std::smatch m;if(std::
regex_match(header,m,ReplacementFor_re_content_disposition)){
ReplacementFor_file_.name=m[(0x5c0+5433-0x1af8)];ReplacementFor_file_.
ReplacementFor_filename=m[(0x18a1+477-0x1a7c)];}}ReplacementFor_buf_.erase(
(0x1526+527-0x1735),pos+ReplacementFor_crlf_.size());ReplacementFor_off_+=pos+
ReplacementFor_crlf_.size();pos=ReplacementFor_buf_.find(ReplacementFor_crlf_);}
if(ReplacementFor_state_!=(0xe4+9094-0x2467)){return true;}break;}case
(0xa07+4599-0x1bfb):{{auto pattern=ReplacementFor_crlf_+ReplacementFor_dash_;if(
pattern.size()>ReplacementFor_buf_.size()){return true;}auto pos=
ReplacementFor_find_string(ReplacementFor_buf_,pattern);if(!
ReplacementFor_content_callback(ReplacementFor_buf_.data(),pos)){
ReplacementFor_is_valid_=false;return false;}ReplacementFor_off_+=pos;
ReplacementFor_buf_.erase((0x19fd+976-0x1dcd),pos);}{auto pattern=
ReplacementFor_crlf_+ReplacementFor_dash_+ReplacementFor_boundary_;if(pattern.
size()>ReplacementFor_buf_.size()){return true;}auto pos=ReplacementFor_buf_.
find(pattern);if(pos!=std::string::npos){if(!ReplacementFor_content_callback(
ReplacementFor_buf_.data(),pos)){ReplacementFor_is_valid_=false;return false;}
ReplacementFor_off_+=pos+pattern.size();ReplacementFor_buf_.erase(
(0xe4d+5695-0x248c),pos+pattern.size());ReplacementFor_state_=(0xf3+4082-0x10e1)
;}else{if(!ReplacementFor_content_callback(ReplacementFor_buf_.data(),pattern.
size())){ReplacementFor_is_valid_=false;return false;}ReplacementFor_off_+=
pattern.size();ReplacementFor_buf_.erase((0x6c+4859-0x1367),pattern.size());}}
break;}case(0x12b+885-0x49c):{if(ReplacementFor_crlf_.size()>ReplacementFor_buf_
.size()){return true;}if(ReplacementFor_buf_.compare((0x158d+2934-0x2103),
ReplacementFor_crlf_.size(),ReplacementFor_crlf_)==(0x561+8554-0x26cb)){
ReplacementFor_buf_.erase((0x105c+723-0x132f),ReplacementFor_crlf_.size());
ReplacementFor_off_+=ReplacementFor_crlf_.size();ReplacementFor_state_=
(0x1780+2455-0x2116);}else{auto pattern=ReplacementFor_dash_+
ReplacementFor_crlf_;if(pattern.size()>ReplacementFor_buf_.size()){return true;}
if(ReplacementFor_buf_.compare((0x1d47+1863-0x248e),pattern.size(),pattern)==
(0xf50+3692-0x1dbc)){ReplacementFor_buf_.erase((0xcd1+2639-0x1720),pattern.size(
));ReplacementFor_off_+=pattern.size();ReplacementFor_is_valid_=true;
ReplacementFor_state_=(0x1cda+630-0x1f4b);}else{return true;}}break;}case
(0x63c+6410-0x1f41):{ReplacementFor_is_valid_=false;return false;}}}return true;
}private:void ReplacementFor_clear_file_info(){ReplacementFor_file_.name.clear()
;ReplacementFor_file_.ReplacementFor_filename.clear();ReplacementFor_file_.
ReplacementFor_content_type.clear();}bool ReplacementFor_start_with_case_ignore(
const std::string&a,const std::string&b)const{if(a.size()<b.size()){return false
;}for(size_t i=(0x333+7863-0x21ea);i<b.size();i++){if(::tolower(a[i])!=::tolower
(b[i])){return false;}}return true;}bool ReplacementFor_start_with(const std::
string&a,size_t ReplacementFor_off,const std::string&b)const{if(a.size()-
ReplacementFor_off<b.size()){return false;}for(size_t i=(0x13f8+300-0x1524);i<b.
size();i++){if(a[i+ReplacementFor_off]!=b[i]){return false;}}return true;}size_t
 ReplacementFor_find_string(const std::string&s,const std::string&pattern)const{
auto c=pattern.front();size_t ReplacementFor_off=(0x1007+2745-0x1ac0);while(
ReplacementFor_off<s.size()){auto pos=s.find(c,ReplacementFor_off);if(pos==std::
string::npos){return s.size();}auto rem=s.size()-pos;if(pattern.size()>rem){
return pos;}if(ReplacementFor_start_with(s,pos,pattern)){return pos;}
ReplacementFor_off=pos+(0xaf1+1584-0x1120);}return s.size();}std::string 
ReplacementFor_boundary_;std::string ReplacementFor_buf_;size_t 
ReplacementFor_state_=(0xe7d+764-0x1179);bool ReplacementFor_is_valid_=false;
size_t ReplacementFor_off_=(0xc78+5114-0x2072);ReplacementFor_MultipartFormData 
ReplacementFor_file_;};std::string ReplacementFor_to_lower(const char*beg,const 
char*end){std::string out;auto ReplacementFor_it=beg;while(ReplacementFor_it!=
end){out+=static_cast<char>(::tolower(*ReplacementFor_it));ReplacementFor_it++;}
return out;}std::string ReplacementFor_make_multipart_data_boundary(){static 
const char data[]=
"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a"
;std::random_device ReplacementFor_seed_gen;std::seed_seq 
ReplacementFor_seed_sequence{ReplacementFor_seed_gen(),ReplacementFor_seed_gen()
,ReplacementFor_seed_gen(),ReplacementFor_seed_gen()};std::mt19937 
ReplacementFor_engine(ReplacementFor_seed_sequence);std::string result=
"\x2d\x2d\x63\x70\x70\x2d\x68\x74\x74\x70\x6c\x69\x62\x2d\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2d\x64\x61\x74\x61\x2d"
;for(auto i=(0x27f+1231-0x74e);i<(0x96d+6210-0x219f);i++){result+=data[
ReplacementFor_engine()%(sizeof(data)-(0xda0+5940-0x24d3))];}return result;}std
::pair<size_t,size_t>ReplacementFor_get_range_offset_and_length(const 
ReplacementFor_Request&ReplacementFor_req,size_t ReplacementFor_content_length,
size_t index){auto ReplacementFor_r=ReplacementFor_req.ranges[index];if(
ReplacementFor_r.first==-(0x60b+3800-0x14e2)&&ReplacementFor_r.second==-
(0x1315+3669-0x2169)){return std::make_pair((0x778+1776-0xe68),
ReplacementFor_content_length);}auto ReplacementFor_slen=static_cast<ssize_t>(
ReplacementFor_content_length);if(ReplacementFor_r.first==-(0x10af+4038-0x2074))
{ReplacementFor_r.first=(std::max)(static_cast<ssize_t>((0x4dc+5864-0x1bc4)),
ReplacementFor_slen-ReplacementFor_r.second);ReplacementFor_r.second=
ReplacementFor_slen-(0x41b+1949-0xbb7);}if(ReplacementFor_r.second==-
(0x164c+1569-0x1c6c)){ReplacementFor_r.second=ReplacementFor_slen-
(0x957+3492-0x16fa);}return std::make_pair(ReplacementFor_r.first,static_cast<
size_t>(ReplacementFor_r.second-ReplacementFor_r.first)+(0xd72+5575-0x2338));}
std::string ReplacementFor_make_content_range_header_field(size_t offset,size_t 
length,size_t ReplacementFor_content_length){std::string field=
"\x62\x79\x74\x65\x73\x20";field+=std::to_string(offset);field+="\x2d";field+=
std::to_string(offset+length-(0x13af+4358-0x24b4));field+="\x2f";field+=std::
to_string(ReplacementFor_content_length);return field;}template<typename 
ReplacementFor_SToken,typename ReplacementFor_CToken,typename Content>bool 
ReplacementFor_process_multipart_ranges_data(const ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res,const std::string&
ReplacementFor_boundary,const std::string&ReplacementFor_content_type,
ReplacementFor_SToken ReplacementFor_stoken,ReplacementFor_CToken 
ReplacementFor_ctoken,Content ReplacementFor_content){for(size_t i=
(0x855+5209-0x1cae);i<ReplacementFor_req.ranges.size();i++){
ReplacementFor_ctoken("\x2d\x2d");ReplacementFor_stoken(ReplacementFor_boundary)
;ReplacementFor_ctoken("\r\n");if(!ReplacementFor_content_type.empty()){
ReplacementFor_ctoken("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20"
);ReplacementFor_stoken(ReplacementFor_content_type);ReplacementFor_ctoken(
"\r\n");}auto ReplacementFor_offsets=ReplacementFor_get_range_offset_and_length(
ReplacementFor_req,ReplacementFor_res.ReplacementFor_body.size(),i);auto offset=
ReplacementFor_offsets.first;auto length=ReplacementFor_offsets.second;
ReplacementFor_ctoken(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65\x3a\x20");
ReplacementFor_stoken(ReplacementFor_make_content_range_header_field(offset,
length,ReplacementFor_res.ReplacementFor_body.size()));ReplacementFor_ctoken(
"\r\n");ReplacementFor_ctoken("\r\n");if(!ReplacementFor_content(offset,length))
{return false;}ReplacementFor_ctoken("\r\n");}ReplacementFor_ctoken("\x2d\x2d");
ReplacementFor_stoken(ReplacementFor_boundary);ReplacementFor_ctoken(
"\x2d\x2d" "\r\n");return true;}bool ReplacementFor_make_multipart_ranges_data(
const ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,const std::string&ReplacementFor_boundary,const std::string&
ReplacementFor_content_type,std::string&data){return 
ReplacementFor_process_multipart_ranges_data(ReplacementFor_req,
ReplacementFor_res,ReplacementFor_boundary,ReplacementFor_content_type,[&](const
 std::string&ReplacementFor_token){data+=ReplacementFor_token;},[&](const char*
ReplacementFor_token){data+=ReplacementFor_token;},[&](size_t offset,size_t 
length){if(offset<ReplacementFor_res.ReplacementFor_body.size()){data+=
ReplacementFor_res.ReplacementFor_body.substr(offset,length);return true;}return
 false;});}size_t ReplacementFor_get_multipart_ranges_data_length(const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,const std::string&ReplacementFor_boundary,const std::string&
ReplacementFor_content_type){size_t ReplacementFor_data_length=
(0xf86+4340-0x207a);ReplacementFor_process_multipart_ranges_data(
ReplacementFor_req,ReplacementFor_res,ReplacementFor_boundary,
ReplacementFor_content_type,[&](const std::string&ReplacementFor_token){
ReplacementFor_data_length+=ReplacementFor_token.size();},[&](const char*
ReplacementFor_token){ReplacementFor_data_length+=strlen(ReplacementFor_token);}
,[&](size_t,size_t length){ReplacementFor_data_length+=length;return true;});
return ReplacementFor_data_length;}template<typename T>bool 
ReplacementFor_write_multipart_ranges_data(ReplacementFor_Stream&
ReplacementFor_strm,const ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,const std::string&
ReplacementFor_boundary,const std::string&ReplacementFor_content_type,const T&
ReplacementFor_is_shutting_down){return 
ReplacementFor_process_multipart_ranges_data(ReplacementFor_req,
ReplacementFor_res,ReplacementFor_boundary,ReplacementFor_content_type,[&](const
 std::string&ReplacementFor_token){ReplacementFor_strm.write(
ReplacementFor_token);},[&](const char*ReplacementFor_token){ReplacementFor_strm
.write(ReplacementFor_token);},[&](size_t offset,size_t length){return 
ReplacementFor_write_content(ReplacementFor_strm,ReplacementFor_res.
ReplacementFor_content_provider_,offset,length,ReplacementFor_is_shutting_down);
});}std::pair<size_t,size_t>ReplacementFor_get_range_offset_and_length(const 
ReplacementFor_Request&ReplacementFor_req,const ReplacementFor_Response&
ReplacementFor_res,size_t index){auto ReplacementFor_r=ReplacementFor_req.ranges
[index];if(ReplacementFor_r.second==-(0xfd+9290-0x2546)){ReplacementFor_r.second
=static_cast<ssize_t>(ReplacementFor_res.ReplacementFor_content_length_)-
(0x7d7+3715-0x1659);}return std::make_pair(ReplacementFor_r.first,
ReplacementFor_r.second-ReplacementFor_r.first+(0xe24+3109-0x1a48));}bool 
ReplacementFor_expect_content(const ReplacementFor_Request&ReplacementFor_req){
if(ReplacementFor_req.ReplacementFor_method=="\x50\x4f\x53\x54"||
ReplacementFor_req.ReplacementFor_method=="\x50\x55\x54"||ReplacementFor_req.
ReplacementFor_method=="\x50\x41\x54\x43\x48"||ReplacementFor_req.
ReplacementFor_method=="\x50\x52\x49"||ReplacementFor_req.ReplacementFor_method
=="\x44\x45\x4c\x45\x54\x45"){return true;}return false;}bool 
ReplacementFor_has_crlf(const char*s){auto p=s;while(*p){if(*p=='\r'||*p=='\n'){
return true;}p++;}return false;}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
template<typename CTX,typename Init,typename Update,typename Final>std::string 
ReplacementFor_message_digest(const std::string&s,Init init,Update 
ReplacementFor_update,Final final,size_t ReplacementFor_digest_length){using 
namespace std;std::vector<unsigned char>ReplacementFor_md(
ReplacementFor_digest_length,(0x1f5+3541-0xfca));CTX ctx;init(&ctx);
ReplacementFor_update(&ctx,s.data(),s.size());final(ReplacementFor_md.data(),&
ctx);stringstream ReplacementFor_ss;for(auto c:ReplacementFor_md){
ReplacementFor_ss<<setfill(((char)(0x592+1507-0xb45)))<<setw((0x279+6537-0x1c00)
)<<hex<<(unsigned int)c;}return ReplacementFor_ss.str();}std::string 
ReplacementFor_MD5(const std::string&s){return ReplacementFor_message_digest<
ReplacementFor_MD5_CTX>(s,ReplacementFor_MD5_Init,ReplacementFor_MD5_Update,
ReplacementFor_MD5_Final,ReplacementFor_MD5_DIGEST_LENGTH);}std::string 
ReplacementFor_SHA_256(const std::string&s){return ReplacementFor_message_digest
<ReplacementFor_SHA256_CTX>(s,ReplacementFor_SHA256_Init,
ReplacementFor_SHA256_Update,ReplacementFor_SHA256_Final,
ReplacementFor_SHA256_DIGEST_LENGTH);}std::string ReplacementFor_SHA_512(const 
std::string&s){return ReplacementFor_message_digest<ReplacementFor_SHA512_CTX>(s
,ReplacementFor_SHA512_Init,ReplacementFor_SHA512_Update,
ReplacementFor_SHA512_Final,ReplacementFor_SHA512_DIGEST_LENGTH);}
#endif
#ifdef _WIN32
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
bool ReplacementFor_load_system_certs_on_windows(ReplacementFor_X509_STORE*store
){auto ReplacementFor_hStore=CertOpenSystemStoreW((
ReplacementFor_HCRYPTPROV_LEGACY)NULL,L"ROOT");if(!ReplacementFor_hStore){return
 false;}PCCERT_CONTEXT pContext=NULL;while((pContext=CertEnumCertificatesInStore
(ReplacementFor_hStore,pContext))!=nullptr){auto ReplacementFor_encoded_cert=
static_cast<const unsigned char*>(pContext->pbCertEncoded);auto 
ReplacementFor_x509=ReplacementFor_d2i_X509(NULL,&ReplacementFor_encoded_cert,
pContext->cbCertEncoded);if(ReplacementFor_x509){
ReplacementFor_X509_STORE_add_cert(store,ReplacementFor_x509);
ReplacementFor_X509_free(ReplacementFor_x509);}}CertFreeCertificateContext(
pContext);CertCloseStore(ReplacementFor_hStore,(0xdad+2354-0x16df));return true;
}
#endif
class ReplacementFor_WSInit{public:ReplacementFor_WSInit(){WSADATA 
ReplacementFor_wsaData;WSAStartup((0x86f+3753-0x1716),&ReplacementFor_wsaData);}
~ReplacementFor_WSInit(){WSACleanup();}};static ReplacementFor_WSInit 
ReplacementFor_wsinit_;
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
std::pair<std::string,std::string>
ReplacementFor_make_digest_authentication_header(const ReplacementFor_Request&
ReplacementFor_req,const std::map<std::string,std::string>&ReplacementFor_auth,
size_t ReplacementFor_cnonce_count,const std::string&ReplacementFor_cnonce,const
 std::string&ReplacementFor_username,const std::string&ReplacementFor_password,
bool ReplacementFor_is_proxy=false){using namespace std;string ReplacementFor_nc
;{stringstream ReplacementFor_ss;ReplacementFor_ss<<setfill(
((char)(0xd97+5834-0x2431)))<<setw((0x1cba+1669-0x2337))<<hex<<
ReplacementFor_cnonce_count;ReplacementFor_nc=ReplacementFor_ss.str();}auto 
ReplacementFor_qop=ReplacementFor_auth.at("\x71\x6f\x70");if(ReplacementFor_qop.
find("\x61\x75\x74\x68\x2d\x69\x6e\x74")!=std::string::npos){ReplacementFor_qop=
"\x61\x75\x74\x68\x2d\x69\x6e\x74";}else{ReplacementFor_qop="\x61\x75\x74\x68";}
std::string ReplacementFor_algo="\x4d\x44\x35";if(ReplacementFor_auth.find(
"\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d")!=ReplacementFor_auth.end()){
ReplacementFor_algo=ReplacementFor_auth.at(
"\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d");}string ReplacementFor_response;{auto 
ReplacementFor_H=ReplacementFor_algo=="\x53\x48\x41\x2d\x32\x35\x36"?
ReplacementFor_detail::ReplacementFor_SHA_256:ReplacementFor_algo==
"\x53\x48\x41\x2d\x35\x31\x32"?ReplacementFor_detail::ReplacementFor_SHA_512:
ReplacementFor_detail::ReplacementFor_MD5;auto ReplacementFor_A1=
ReplacementFor_username+"\x3a"+ReplacementFor_auth.at("\x72\x65\x61\x6c\x6d")+
"\x3a"+ReplacementFor_password;auto ReplacementFor_A2=ReplacementFor_req.
ReplacementFor_method+"\x3a"+ReplacementFor_req.ReplacementFor_path;if(
ReplacementFor_qop=="\x61\x75\x74\x68\x2d\x69\x6e\x74"){ReplacementFor_A2+=
"\x3a"+ReplacementFor_H(ReplacementFor_req.ReplacementFor_body);}
ReplacementFor_response=ReplacementFor_H(ReplacementFor_H(ReplacementFor_A1)+
"\x3a"+ReplacementFor_auth.at("\x6e\x6f\x6e\x63\x65")+"\x3a"+ReplacementFor_nc+
"\x3a"+ReplacementFor_cnonce+"\x3a"+ReplacementFor_qop+"\x3a"+ReplacementFor_H(
ReplacementFor_A2));}auto field=
"\x44\x69\x67\x65\x73\x74\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3d" "\""+
ReplacementFor_username+"\"" "\x2c\x20\x72\x65\x61\x6c\x6d\x3d" "\""+
ReplacementFor_auth.at("\x72\x65\x61\x6c\x6d")+
"\"" "\x2c\x20\x6e\x6f\x6e\x63\x65\x3d" "\""+ReplacementFor_auth.at(
"\x6e\x6f\x6e\x63\x65")+"\"" "\x2c\x20\x75\x72\x69\x3d" "\""+ReplacementFor_req.
ReplacementFor_path+"\"" "\x2c\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x3d"+
ReplacementFor_algo+"\x2c\x20\x71\x6f\x70\x3d"+ReplacementFor_qop+
"\x2c\x20\x6e\x63\x3d" "\""+ReplacementFor_nc+
"\"" "\x2c\x20\x63\x6e\x6f\x6e\x63\x65\x3d" "\""+ReplacementFor_cnonce+
"\"" "\x2c\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x3d" "\""+ReplacementFor_response
+"\"";auto key=ReplacementFor_is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,field);}
#endif
bool ReplacementFor_parse_www_authenticate(const ReplacementFor_Response&
ReplacementFor_res,std::map<std::string,std::string>&ReplacementFor_auth,bool 
ReplacementFor_is_proxy){auto ReplacementFor_auth_key=ReplacementFor_is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x65":
"\x57\x57\x57\x2d\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x65";if(
ReplacementFor_res.ReplacementFor_has_header(ReplacementFor_auth_key)){static 
auto ReplacementFor_re=std::regex(ReplacementFor_R"~((?:(?:,\s*)?(.+?)=(?:"(.*?)
"\x7c\x28\x5b\x5e\x2c\x5d\x2a\x29\x29\x29\x29\x7e");auto s=ReplacementFor_res.
ReplacementFor_get_header_value(ReplacementFor_auth_key);auto pos=s.find(
((char)(0xce0+3525-0x1a85)));if(pos!=std::string::npos){auto type=s.substr(
(0x120+3629-0xf4d),pos);if(type=="\x42\x61\x73\x69\x63"){return false;}else if(
type=="\x44\x69\x67\x65\x73\x74"){s=s.substr(pos+(0x12a7+1855-0x19e5));auto beg=
std::sregex_iterator(s.begin(),s.end(),ReplacementFor_re);for(auto i=beg;i!=std
::sregex_iterator();++i){auto m=*i;auto key=s.substr(static_cast<size_t>(m.
position((0xb6f+2309-0x1473))),static_cast<size_t>(m.length((0x210+5812-0x18c3))
));auto val=m.length((0xec+7801-0x1f63))>(0xebd+2142-0x171b)?s.substr(
static_cast<size_t>(m.position((0x1776+2923-0x22df))),static_cast<size_t>(m.
length((0x3ec+4971-0x1755)))):s.substr(static_cast<size_t>(m.position(
(0x212+4362-0x1319))),static_cast<size_t>(m.length((0xa7d+4987-0x1df5))));
ReplacementFor_auth[key]=val;}return true;}}}return false;}std::string 
ReplacementFor_random_string(size_t length){auto ReplacementFor_randchar=[]()->
char{const char ReplacementFor_charset[]=
"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39"
"\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a"
"\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a"
;const size_t ReplacementFor_max_index=(sizeof(ReplacementFor_charset)-
(0x39c+8802-0x25fd));return ReplacementFor_charset[static_cast<size_t>(rand())%
ReplacementFor_max_index];};std::string str(length,(0xe79+5931-0x25a4));std::
generate_n(str.begin(),length,ReplacementFor_randchar);return str;}class 
ReplacementFor_ContentProviderAdapter{public:explicit 
ReplacementFor_ContentProviderAdapter(
ReplacementFor_ContentProviderWithoutLength&&ReplacementFor_content_provider):
ReplacementFor_content_provider_(ReplacementFor_content_provider){}bool operator
()(size_t offset,size_t,ReplacementFor_DataSink&ReplacementFor_sink){return 
ReplacementFor_content_provider_(offset,ReplacementFor_sink);}private:
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider_;};}
std::pair<std::string,std::string>ReplacementFor_make_range_header(Ranges ranges
){std::string field="\x62\x79\x74\x65\x73\x3d";auto i=(0x1189+2795-0x1c74);for(
auto ReplacementFor_r:ranges){if(i!=(0x13ab+1078-0x17e1)){field+="\x2c\x20";}if(
ReplacementFor_r.first!=-(0xee1+2095-0x170f)){field+=std::to_string(
ReplacementFor_r.first);}field+=((char)(0xd27+2494-0x16b8));if(ReplacementFor_r.
second!=-(0x1f8d+449-0x214d)){field+=std::to_string(ReplacementFor_r.second);}i
++;}return std::make_pair("\x52\x61\x6e\x67\x65",std::move(field));}std::pair<
std::string,std::string>ReplacementFor_make_basic_authentication_header(const 
std::string&ReplacementFor_username,const std::string&ReplacementFor_password,
bool ReplacementFor_is_proxy=false){auto field="\x42\x61\x73\x69\x63\x20"+
ReplacementFor_detail::ReplacementFor_base64_encode(ReplacementFor_username+
"\x3a"+ReplacementFor_password);auto key=ReplacementFor_is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,std::move(field));}std::pair<std::string,std::string>
ReplacementFor_make_bearer_token_authentication_header(const std::string&
ReplacementFor_token,bool ReplacementFor_is_proxy=false){auto field=
"\x42\x65\x61\x72\x65\x72\x20"+ReplacementFor_token;auto key=
ReplacementFor_is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,std::move(field));}bool ReplacementFor_Request::ReplacementFor_has_header(const
 char*key)const{return ReplacementFor_detail::ReplacementFor_has_header(
ReplacementFor_headers,key);}std::string ReplacementFor_Request::
ReplacementFor_get_header_value(const char*key,size_t id)const{return 
ReplacementFor_detail::ReplacementFor_get_header_value(ReplacementFor_headers,
key,id,"");}template<typename T>T ReplacementFor_Request::
ReplacementFor_get_header_value(const char*key,size_t id)const{return 
ReplacementFor_detail::ReplacementFor_get_header_value<T>(ReplacementFor_headers
,key,id,(0x451+8628-0x2605));}size_t ReplacementFor_Request::
ReplacementFor_get_header_value_count(const char*key)const{auto ReplacementFor_r
=ReplacementFor_headers.equal_range(key);return static_cast<size_t>(std::
distance(ReplacementFor_r.first,ReplacementFor_r.second));}void 
ReplacementFor_Request::ReplacementFor_set_header(const char*key,const char*val)
{if(!ReplacementFor_detail::ReplacementFor_has_crlf(key)&&!ReplacementFor_detail
::ReplacementFor_has_crlf(val)){ReplacementFor_headers.emplace(key,val);}}void 
ReplacementFor_Request::ReplacementFor_set_header(const char*key,const std::
string&val){if(!ReplacementFor_detail::ReplacementFor_has_crlf(key)&&!
ReplacementFor_detail::ReplacementFor_has_crlf(val.c_str())){
ReplacementFor_headers.emplace(key,val);}}bool ReplacementFor_Request::
ReplacementFor_has_param(const char*key)const{return ReplacementFor_params.find(
key)!=ReplacementFor_params.end();}std::string ReplacementFor_Request::
ReplacementFor_get_param_value(const char*key,size_t id)const{auto 
ReplacementFor_rng=ReplacementFor_params.equal_range(key);auto ReplacementFor_it
=ReplacementFor_rng.first;std::advance(ReplacementFor_it,static_cast<ssize_t>(id
));if(ReplacementFor_it!=ReplacementFor_rng.second){return ReplacementFor_it->
second;}return std::string();}size_t ReplacementFor_Request::
ReplacementFor_get_param_value_count(const char*key)const{auto ReplacementFor_r=
ReplacementFor_params.equal_range(key);return static_cast<size_t>(std::distance(
ReplacementFor_r.first,ReplacementFor_r.second));}bool ReplacementFor_Request::
ReplacementFor_is_multipart_form_data()const{const auto&
ReplacementFor_content_type=ReplacementFor_get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");return!
ReplacementFor_content_type.find(
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61");
}bool ReplacementFor_Request::ReplacementFor_has_file(const char*key)const{
return ReplacementFor_files.find(key)!=ReplacementFor_files.end();}
ReplacementFor_MultipartFormData ReplacementFor_Request::
ReplacementFor_get_file_value(const char*key)const{auto ReplacementFor_it=
ReplacementFor_files.find(key);if(ReplacementFor_it!=ReplacementFor_files.end())
{return ReplacementFor_it->second;}return ReplacementFor_MultipartFormData();}
bool ReplacementFor_Response::ReplacementFor_has_header(const char*key)const{
return ReplacementFor_headers.find(key)!=ReplacementFor_headers.end();}std::
string ReplacementFor_Response::ReplacementFor_get_header_value(const char*key,
size_t id)const{return ReplacementFor_detail::ReplacementFor_get_header_value(
ReplacementFor_headers,key,id,"");}template<typename T>T ReplacementFor_Response
::ReplacementFor_get_header_value(const char*key,size_t id)const{return 
ReplacementFor_detail::ReplacementFor_get_header_value<T>(ReplacementFor_headers
,key,id,(0x14d2+2014-0x1cb0));}size_t ReplacementFor_Response::
ReplacementFor_get_header_value_count(const char*key)const{auto ReplacementFor_r
=ReplacementFor_headers.equal_range(key);return static_cast<size_t>(std::
distance(ReplacementFor_r.first,ReplacementFor_r.second));}void 
ReplacementFor_Response::ReplacementFor_set_header(const char*key,const char*val
){if(!ReplacementFor_detail::ReplacementFor_has_crlf(key)&&!
ReplacementFor_detail::ReplacementFor_has_crlf(val)){ReplacementFor_headers.
emplace(key,val);}}void ReplacementFor_Response::ReplacementFor_set_header(const
 char*key,const std::string&val){if(!ReplacementFor_detail::
ReplacementFor_has_crlf(key)&&!ReplacementFor_detail::ReplacementFor_has_crlf(
val.c_str())){ReplacementFor_headers.emplace(key,val);}}void 
ReplacementFor_Response::ReplacementFor_set_redirect(const char*
ReplacementFor_url,int stat){if(!ReplacementFor_detail::ReplacementFor_has_crlf(
ReplacementFor_url)){ReplacementFor_set_header(
"\x4c\x6f\x63\x61\x74\x69\x6f\x6e",ReplacementFor_url);if((0x1a2+4547-0x1239)<=
stat&&stat<(0xf04+6039-0x250b)){this->status=stat;}else{this->status=302;}}}void
 ReplacementFor_Response::ReplacementFor_set_redirect(const std::string&
ReplacementFor_url,int stat){ReplacementFor_set_redirect(ReplacementFor_url.
c_str(),stat);}void ReplacementFor_Response::ReplacementFor_set_content(const 
char*s,size_t n,const char*ReplacementFor_content_type){ReplacementFor_body.
assign(s,n);auto ReplacementFor_rng=ReplacementFor_headers.equal_range(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");ReplacementFor_headers.erase
(ReplacementFor_rng.first,ReplacementFor_rng.second);ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
}void ReplacementFor_Response::ReplacementFor_set_content(const std::string&s,
const char*ReplacementFor_content_type){ReplacementFor_set_content(s.data(),s.
size(),ReplacementFor_content_type);}void ReplacementFor_Response::
ReplacementFor_set_content_provider(size_t ReplacementFor_in_length,const char*
ReplacementFor_content_type,ReplacementFor_ContentProvider 
ReplacementFor_provider,const std::function<void()>&
ReplacementFor_resource_releaser){assert(ReplacementFor_in_length>
(0xb75+2118-0x13bb));ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
ReplacementFor_content_length_=ReplacementFor_in_length;
ReplacementFor_content_provider_=std::move(ReplacementFor_provider);
ReplacementFor_content_provider_resource_releaser_=
ReplacementFor_resource_releaser;ReplacementFor_is_chunked_content_provider_=
false;}void ReplacementFor_Response::ReplacementFor_set_content_provider(const 
char*ReplacementFor_content_type,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_provider,const std::function<void()>&
ReplacementFor_resource_releaser){ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
ReplacementFor_content_length_=(0x2004+390-0x218a);
ReplacementFor_content_provider_=ReplacementFor_detail::
ReplacementFor_ContentProviderAdapter(std::move(ReplacementFor_provider));
ReplacementFor_content_provider_resource_releaser_=
ReplacementFor_resource_releaser;ReplacementFor_is_chunked_content_provider_=
false;}void ReplacementFor_Response::ReplacementFor_set_chunked_content_provider
(const char*ReplacementFor_content_type,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_provider,const std::
function<void()>&ReplacementFor_resource_releaser){ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
ReplacementFor_content_length_=(0x142a+3182-0x2098);
ReplacementFor_content_provider_=ReplacementFor_detail::
ReplacementFor_ContentProviderAdapter(std::move(ReplacementFor_provider));
ReplacementFor_content_provider_resource_releaser_=
ReplacementFor_resource_releaser;ReplacementFor_is_chunked_content_provider_=
true;}bool Result::ReplacementFor_has_request_header(const char*key)const{return
 ReplacementFor_request_headers_.find(key)!=ReplacementFor_request_headers_.end(
);}std::string Result::ReplacementFor_get_request_header_value(const char*key,
size_t id)const{return ReplacementFor_detail::ReplacementFor_get_header_value(
ReplacementFor_request_headers_,key,id,"");}template<typename T>T Result::
ReplacementFor_get_request_header_value(const char*key,size_t id)const{return 
ReplacementFor_detail::ReplacementFor_get_header_value<T>(
ReplacementFor_request_headers_,key,id,(0xe40+2973-0x19dd));}size_t Result::
ReplacementFor_get_request_header_value_count(const char*key)const{auto 
ReplacementFor_r=ReplacementFor_request_headers_.equal_range(key);return 
static_cast<size_t>(std::distance(ReplacementFor_r.first,ReplacementFor_r.second
));}ssize_t ReplacementFor_Stream::write(const char*ReplacementFor_ptr){return 
write(ReplacementFor_ptr,strlen(ReplacementFor_ptr));}ssize_t 
ReplacementFor_Stream::write(const std::string&s){return write(s.data(),s.size()
);}template<typename...ReplacementFor_Args>ssize_t ReplacementFor_Stream::
ReplacementFor_write_format(const char*ReplacementFor_fmt,const 
ReplacementFor_Args&...ReplacementFor_args){const auto ReplacementFor_bufsiz=
(0x1f7f+505-0x1978);std::array<char,ReplacementFor_bufsiz>buf;
#if defined(_MSC_VER) && _MSC_VER < (0x1488+5932-0x2448)
auto ReplacementFor_sn=ReplacementFor__snprintf_s(buf.data(),
ReplacementFor_bufsiz-(0x999+220-0xa74),buf.size()-(0x1e86+1256-0x236d),
ReplacementFor_fmt,ReplacementFor_args...);
#else
auto ReplacementFor_sn=snprintf(buf.data(),buf.size()-(0xfd0+1616-0x161f),
ReplacementFor_fmt,ReplacementFor_args...);
#endif
if(ReplacementFor_sn<=(0x1577+2311-0x1e7e)){return ReplacementFor_sn;}auto n=
static_cast<size_t>(ReplacementFor_sn);if(n>=buf.size()-(0x26d+9176-0x2644)){std
::vector<char>ReplacementFor_glowable_buf(buf.size());while(n>=
ReplacementFor_glowable_buf.size()-(0x1170+2050-0x1971)){
ReplacementFor_glowable_buf.resize(ReplacementFor_glowable_buf.size()*
(0x1bab+772-0x1ead));
#if defined(_MSC_VER) && _MSC_VER < (0x1bc2+2621-0x1e93)
n=static_cast<size_t>(ReplacementFor__snprintf_s(&ReplacementFor_glowable_buf[
(0x1c4b+2619-0x2686)],ReplacementFor_glowable_buf.size(),
ReplacementFor_glowable_buf.size()-(0x72+4965-0x13d6),ReplacementFor_fmt,
ReplacementFor_args...));
#else
n=static_cast<size_t>(snprintf(&ReplacementFor_glowable_buf[(0x55+8548-0x21b9)],
ReplacementFor_glowable_buf.size()-(0x7a8+2975-0x1346),ReplacementFor_fmt,
ReplacementFor_args...));
#endif
}return write(&ReplacementFor_glowable_buf[(0x5d0+1884-0xd2c)],n);}else{return 
write(buf.data(),n);}}namespace ReplacementFor_detail{
ReplacementFor_SocketStream::ReplacementFor_SocketStream(ReplacementFor_socket_t
 ReplacementFor_sock,time_t ReplacementFor_read_timeout_sec,time_t 
ReplacementFor_read_timeout_usec,time_t ReplacementFor_write_timeout_sec,time_t 
ReplacementFor_write_timeout_usec):ReplacementFor_sock_(ReplacementFor_sock),
ReplacementFor_read_timeout_sec_(ReplacementFor_read_timeout_sec),
ReplacementFor_read_timeout_usec_(ReplacementFor_read_timeout_usec),
ReplacementFor_write_timeout_sec_(ReplacementFor_write_timeout_sec),
ReplacementFor_write_timeout_usec_(ReplacementFor_write_timeout_usec){}
ReplacementFor_SocketStream::~ReplacementFor_SocketStream(){}bool 
ReplacementFor_SocketStream::ReplacementFor_is_readable()const{return 
ReplacementFor_select_read(ReplacementFor_sock_,ReplacementFor_read_timeout_sec_
,ReplacementFor_read_timeout_usec_)>(0x14a1+3901-0x23de);}bool 
ReplacementFor_SocketStream::ReplacementFor_is_writable()const{return 
ReplacementFor_select_write(ReplacementFor_sock_,
ReplacementFor_write_timeout_sec_,ReplacementFor_write_timeout_usec_)>
(0x1d66+2147-0x25c9);}ssize_t ReplacementFor_SocketStream::read(char*
ReplacementFor_ptr,size_t size){if(!ReplacementFor_is_readable()){return-
(0x36a+3870-0x1287);}
#ifdef _WIN32
if(size>static_cast<size_t>((std::numeric_limits<int>::max)())){return-
(0xe88+2124-0x16d3);}return recv(ReplacementFor_sock_,ReplacementFor_ptr,
static_cast<int>(size),ReplacementFor_CPPHTTPLIB_RECV_FLAGS);
#else
return ReplacementFor_handle_EINTR([&](){return recv(ReplacementFor_sock_,
ReplacementFor_ptr,size,ReplacementFor_CPPHTTPLIB_RECV_FLAGS);});
#endif
}ssize_t ReplacementFor_SocketStream::write(const char*ReplacementFor_ptr,size_t
 size){if(!ReplacementFor_is_writable()){return-(0x19a3+1571-0x1fc5);}
#ifdef _WIN32
if(size>static_cast<size_t>((std::numeric_limits<int>::max)())){return-
(0xea6+560-0x10d5);}return send(ReplacementFor_sock_,ReplacementFor_ptr,
static_cast<int>(size),ReplacementFor_CPPHTTPLIB_SEND_FLAGS);
#else
return ReplacementFor_handle_EINTR([&](){return send(ReplacementFor_sock_,
ReplacementFor_ptr,size,ReplacementFor_CPPHTTPLIB_SEND_FLAGS);});
#endif
}void ReplacementFor_SocketStream::ReplacementFor_get_remote_ip_and_port(std::
string&ReplacementFor_ip,int&ReplacementFor_port)const{return 
ReplacementFor_detail::ReplacementFor_get_remote_ip_and_port(
ReplacementFor_sock_,ReplacementFor_ip,ReplacementFor_port);}
ReplacementFor_socket_t ReplacementFor_SocketStream::socket()const{return 
ReplacementFor_sock_;}bool ReplacementFor_BufferStream::
ReplacementFor_is_readable()const{return true;}bool ReplacementFor_BufferStream
::ReplacementFor_is_writable()const{return true;}ssize_t 
ReplacementFor_BufferStream::read(char*ReplacementFor_ptr,size_t size){
#if defined(_MSC_VER) && _MSC_VER <= (0xee1+1290-0xc7f)
auto ReplacementFor_len_read=ReplacementFor_buffer._Copy_s(ReplacementFor_ptr,
size,size,position);
#else
auto ReplacementFor_len_read=ReplacementFor_buffer.copy(ReplacementFor_ptr,size,
position);
#endif
position+=static_cast<size_t>(ReplacementFor_len_read);return static_cast<
ssize_t>(ReplacementFor_len_read);}ssize_t ReplacementFor_BufferStream::write(
const char*ReplacementFor_ptr,size_t size){ReplacementFor_buffer.append(
ReplacementFor_ptr,size);return static_cast<ssize_t>(size);}void 
ReplacementFor_BufferStream::ReplacementFor_get_remote_ip_and_port(std::string&,
int&)const{}ReplacementFor_socket_t ReplacementFor_BufferStream::socket()const{
return(0x56d+6145-0x1d6e);}const std::string&ReplacementFor_BufferStream::
ReplacementFor_get_buffer()const{return ReplacementFor_buffer;}}
ReplacementFor_Server::ReplacementFor_Server():ReplacementFor_new_task_queue([]{
return new ReplacementFor_ThreadPool(ReplacementFor_CPPHTTPLIB_THREAD_POOL_COUNT
);}),ReplacementFor_svr_sock_(INVALID_SOCKET),ReplacementFor_is_running_(false){
#ifndef _WIN32
signal(SIGPIPE,SIG_IGN);
#endif
}ReplacementFor_Server::~ReplacementFor_Server(){}ReplacementFor_Server&
ReplacementFor_Server::Get(const char*pattern,ReplacementFor_Handler 
ReplacementFor_handler){return Get(pattern,strlen(pattern),
ReplacementFor_handler);}ReplacementFor_Server&ReplacementFor_Server::Get(const 
char*pattern,size_t ReplacementFor_pattern_len,ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_get_handlers_.push_back(std::make_pair(
std::regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)
));return*this;}ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_Post
(const char*pattern,ReplacementFor_Handler ReplacementFor_handler){return 
ReplacementFor_Post(pattern,strlen(pattern),ReplacementFor_handler);}
ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_Post(const char*
pattern,size_t ReplacementFor_pattern_len,ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_post_handlers_.push_back(std::make_pair(
std::regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)
));return*this;}ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_Post
(const char*pattern,ReplacementFor_HandlerWithContentReader 
ReplacementFor_handler){return ReplacementFor_Post(pattern,strlen(pattern),
ReplacementFor_handler);}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_Post(const char*pattern,size_t ReplacementFor_pattern_len,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler){
ReplacementFor_post_handlers_for_content_reader_.push_back(std::make_pair(std::
regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)));
return*this;}ReplacementFor_Server&ReplacementFor_Server::Put(const char*pattern
,ReplacementFor_Handler ReplacementFor_handler){return Put(pattern,strlen(
pattern),ReplacementFor_handler);}ReplacementFor_Server&ReplacementFor_Server::
Put(const char*pattern,size_t ReplacementFor_pattern_len,ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_put_handlers_.push_back(std::make_pair(
std::regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)
));return*this;}ReplacementFor_Server&ReplacementFor_Server::Put(const char*
pattern,ReplacementFor_HandlerWithContentReader ReplacementFor_handler){return 
Put(pattern,strlen(pattern),ReplacementFor_handler);}ReplacementFor_Server&
ReplacementFor_Server::Put(const char*pattern,size_t ReplacementFor_pattern_len,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler){
ReplacementFor_put_handlers_for_content_reader_.push_back(std::make_pair(std::
regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)));
return*this;}ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_Patch(
const char*pattern,ReplacementFor_Handler ReplacementFor_handler){return 
ReplacementFor_Patch(pattern,strlen(pattern),ReplacementFor_handler);}
ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_Patch(const char*
pattern,size_t ReplacementFor_pattern_len,ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_patch_handlers_.push_back(std::make_pair(
std::regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)
));return*this;}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_Patch(const char*pattern,ReplacementFor_HandlerWithContentReader 
ReplacementFor_handler){return ReplacementFor_Patch(pattern,strlen(pattern),
ReplacementFor_handler);}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_Patch(const char*pattern,size_t ReplacementFor_pattern_len,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler){
ReplacementFor_patch_handlers_for_content_reader_.push_back(std::make_pair(std::
regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)));
return*this;}ReplacementFor_Server&ReplacementFor_Server::Delete(const char*
pattern,ReplacementFor_Handler ReplacementFor_handler){return Delete(pattern,
strlen(pattern),ReplacementFor_handler);}ReplacementFor_Server&
ReplacementFor_Server::Delete(const char*pattern,size_t 
ReplacementFor_pattern_len,ReplacementFor_Handler ReplacementFor_handler){
ReplacementFor_delete_handlers_.push_back(std::make_pair(std::regex(pattern,
ReplacementFor_pattern_len),std::move(ReplacementFor_handler)));return*this;}
ReplacementFor_Server&ReplacementFor_Server::Delete(const char*pattern,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler){return Delete(
pattern,strlen(pattern),ReplacementFor_handler);}ReplacementFor_Server&
ReplacementFor_Server::Delete(const char*pattern,size_t 
ReplacementFor_pattern_len,ReplacementFor_HandlerWithContentReader 
ReplacementFor_handler){ReplacementFor_delete_handlers_for_content_reader_.
push_back(std::make_pair(std::regex(pattern,ReplacementFor_pattern_len),std::
move(ReplacementFor_handler)));return*this;}ReplacementFor_Server&
ReplacementFor_Server::Options(const char*pattern,ReplacementFor_Handler 
ReplacementFor_handler){return Options(pattern,strlen(pattern),
ReplacementFor_handler);}ReplacementFor_Server&ReplacementFor_Server::Options(
const char*pattern,size_t ReplacementFor_pattern_len,ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_options_handlers_.push_back(std::
make_pair(std::regex(pattern,ReplacementFor_pattern_len),std::move(
ReplacementFor_handler)));return*this;}bool ReplacementFor_Server::
ReplacementFor_set_base_dir(const char*ReplacementFor_dir,const char*
ReplacementFor_mount_point){return ReplacementFor_set_mount_point(
ReplacementFor_mount_point,ReplacementFor_dir);}bool ReplacementFor_Server::
ReplacementFor_set_mount_point(const char*ReplacementFor_mount_point,const char*
ReplacementFor_dir,ReplacementFor_Headers ReplacementFor_headers){if(
ReplacementFor_detail::ReplacementFor_is_dir(ReplacementFor_dir)){std::string 
ReplacementFor_mnt=ReplacementFor_mount_point?ReplacementFor_mount_point:"\x2f";
if(!ReplacementFor_mnt.empty()&&ReplacementFor_mnt[(0x504+4200-0x156c)]==
((char)(0x15b8+79-0x15d8))){ReplacementFor_base_dirs_.push_back({
ReplacementFor_mnt,ReplacementFor_dir,std::move(ReplacementFor_headers)});return
 true;}}return false;}bool ReplacementFor_Server::
ReplacementFor_remove_mount_point(const char*ReplacementFor_mount_point){for(
auto ReplacementFor_it=ReplacementFor_base_dirs_.begin();ReplacementFor_it!=
ReplacementFor_base_dirs_.end();++ReplacementFor_it){if(ReplacementFor_it->
ReplacementFor_mount_point==ReplacementFor_mount_point){
ReplacementFor_base_dirs_.erase(ReplacementFor_it);return true;}}return false;}
ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_file_extension_and_mimetype_mapping(const char*
ReplacementFor_ext,const char*ReplacementFor_mime){
ReplacementFor_file_extension_and_mimetype_map_[ReplacementFor_ext]=
ReplacementFor_mime;return*this;}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_file_request_handler(ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_file_request_handler_=std::move(
ReplacementFor_handler);return*this;}ReplacementFor_Server&ReplacementFor_Server
::ReplacementFor_set_error_handler(ReplacementFor_HandlerWithResponse 
ReplacementFor_handler){ReplacementFor_error_handler_=std::move(
ReplacementFor_handler);return*this;}ReplacementFor_Server&ReplacementFor_Server
::ReplacementFor_set_error_handler(ReplacementFor_Handler ReplacementFor_handler
){ReplacementFor_error_handler_=[ReplacementFor_handler](const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res){ReplacementFor_handler(ReplacementFor_req,ReplacementFor_res
);return ReplacementFor_HandlerResponse::ReplacementFor_Handled;};return*this;}
ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_exception_handler(ExceptionHandler ReplacementFor_handler){
ReplacementFor_exception_handler_=std::move(ReplacementFor_handler);return*this;
}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_pre_routing_handler(ReplacementFor_HandlerWithResponse 
ReplacementFor_handler){ReplacementFor_pre_routing_handler_=std::move(
ReplacementFor_handler);return*this;}ReplacementFor_Server&ReplacementFor_Server
::ReplacementFor_set_post_routing_handler(ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_post_routing_handler_=std::move(
ReplacementFor_handler);return*this;}ReplacementFor_Server&ReplacementFor_Server
::ReplacementFor_set_logger(ReplacementFor_Logger ReplacementFor_logger){
ReplacementFor_logger_=std::move(ReplacementFor_logger);return*this;}
ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_expect_100_continue_handler(
ReplacementFor_Expect100ContinueHandler ReplacementFor_handler){
ReplacementFor_expect_100_continue_handler_=std::move(ReplacementFor_handler);
return*this;}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_tcp_nodelay(bool ReplacementFor_on){
ReplacementFor_tcp_nodelay_=ReplacementFor_on;return*this;}ReplacementFor_Server
&ReplacementFor_Server::ReplacementFor_set_socket_options(
ReplacementFor_SocketOptions ReplacementFor_socket_options){
ReplacementFor_socket_options_=std::move(ReplacementFor_socket_options);return*
this;}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_keep_alive_max_count(size_t count){
ReplacementFor_keep_alive_max_count_=count;return*this;}ReplacementFor_Server&
ReplacementFor_Server::ReplacementFor_set_keep_alive_timeout(time_t sec){
ReplacementFor_keep_alive_timeout_sec_=sec;return*this;}ReplacementFor_Server&
ReplacementFor_Server::ReplacementFor_set_read_timeout(time_t sec,time_t 
ReplacementFor_usec){ReplacementFor_read_timeout_sec_=sec;
ReplacementFor_read_timeout_usec_=ReplacementFor_usec;return*this;}
ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_set_write_timeout(
time_t sec,time_t ReplacementFor_usec){ReplacementFor_write_timeout_sec_=sec;
ReplacementFor_write_timeout_usec_=ReplacementFor_usec;return*this;}
ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_set_idle_interval(
time_t sec,time_t ReplacementFor_usec){ReplacementFor_idle_interval_sec_=sec;
ReplacementFor_idle_interval_usec_=ReplacementFor_usec;return*this;}
ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_payload_max_length(size_t length){
ReplacementFor_payload_max_length_=length;return*this;}bool 
ReplacementFor_Server::ReplacementFor_bind_to_port(const char*
ReplacementFor_host,int ReplacementFor_port,int ReplacementFor_socket_flags){if(
ReplacementFor_bind_internal(ReplacementFor_host,ReplacementFor_port,
ReplacementFor_socket_flags)<(0x1628+1360-0x1b78))return false;return true;}int 
ReplacementFor_Server::ReplacementFor_bind_to_any_port(const char*
ReplacementFor_host,int ReplacementFor_socket_flags){return 
ReplacementFor_bind_internal(ReplacementFor_host,(0x1570+12-0x157c),
ReplacementFor_socket_flags);}bool ReplacementFor_Server::
ReplacementFor_listen_after_bind(){return ReplacementFor_listen_internal();}bool
 ReplacementFor_Server::listen(const char*ReplacementFor_host,int 
ReplacementFor_port,int ReplacementFor_socket_flags){return 
ReplacementFor_bind_to_port(ReplacementFor_host,ReplacementFor_port,
ReplacementFor_socket_flags)&&ReplacementFor_listen_internal();}bool 
ReplacementFor_Server::ReplacementFor_is_running()const{return 
ReplacementFor_is_running_;}void ReplacementFor_Server::ReplacementFor_stop(){if
(ReplacementFor_is_running_){assert(ReplacementFor_svr_sock_!=INVALID_SOCKET);
std::atomic<ReplacementFor_socket_t>ReplacementFor_sock(ReplacementFor_svr_sock_
.exchange(INVALID_SOCKET));ReplacementFor_detail::ReplacementFor_shutdown_socket
(ReplacementFor_sock);ReplacementFor_detail::ReplacementFor_close_socket(
ReplacementFor_sock);}}bool ReplacementFor_Server::
ReplacementFor_parse_request_line(const char*s,ReplacementFor_Request&
ReplacementFor_req){const static std::regex ReplacementFor_re(
"\x28\x47\x45\x54\x7c\x48\x45\x41\x44\x7c\x50\x4f\x53\x54\x7c\x50\x55\x54\x7c\x44\x45\x4c\x45\x54\x45\x7c\x43\x4f\x4e\x4e\x45\x43\x54\x7c\x4f\x50\x54\x49\x4f\x4e\x53\x7c\x54\x52\x41\x43\x45\x7c\x50\x41\x54\x43\x48\x7c\x50\x52\x49\x29\x20"
"\x28\x28\x5b\x5e\x3f\x20\x5d\x2b\x29\x28\x3f\x3a" "\\" "\x3f\x28\x5b\x5e\x20\x5d\x2a\x3f\x29\x29\x3f\x29\x20\x28\x48\x54\x54\x50\x2f\x31" "\\" "\x2e\x5b\x30\x31\x5d\x29" "\r\n"
);std::cmatch m;if(std::regex_match(s,m,ReplacementFor_re)){ReplacementFor_req.
ReplacementFor_version=std::string(m[(0xb1f+2537-0x1503)]);ReplacementFor_req.
ReplacementFor_method=std::string(m[(0xda7+116-0xe1a)]);ReplacementFor_req.
target=std::string(m[(0x170+6941-0x1c8b)]);ReplacementFor_req.
ReplacementFor_path=ReplacementFor_detail::ReplacementFor_decode_url(m[
(0x1f4a+704-0x2207)],false);auto len=std::distance(m[(0x7c8+4799-0x1a83)].first,
m[(0x1718+1916-0x1e90)].second);if(len>(0xcc3+6054-0x2469)){
ReplacementFor_detail::ReplacementFor_parse_query_text(m[(0x262+1996-0xa2a)],
ReplacementFor_req.ReplacementFor_params);}return true;}return false;}bool 
ReplacementFor_Server::ReplacementFor_write_response(ReplacementFor_Stream&
ReplacementFor_strm,bool ReplacementFor_close_connection,const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res){return ReplacementFor_write_response_core(
ReplacementFor_strm,ReplacementFor_close_connection,ReplacementFor_req,
ReplacementFor_res,false);}bool ReplacementFor_Server::
ReplacementFor_write_response_with_content(ReplacementFor_Stream&
ReplacementFor_strm,bool ReplacementFor_close_connection,const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res){return ReplacementFor_write_response_core(
ReplacementFor_strm,ReplacementFor_close_connection,ReplacementFor_req,
ReplacementFor_res,true);}bool ReplacementFor_Server::
ReplacementFor_write_response_core(ReplacementFor_Stream&ReplacementFor_strm,
bool ReplacementFor_close_connection,const ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res,bool 
ReplacementFor_need_apply_ranges){assert(ReplacementFor_res.status!=-
(0x1362+1721-0x1a1a));if((0x19d7+2380-0x2193)<=ReplacementFor_res.status&&
ReplacementFor_error_handler_&&ReplacementFor_error_handler_(ReplacementFor_req,
ReplacementFor_res)==ReplacementFor_HandlerResponse::ReplacementFor_Handled){
ReplacementFor_need_apply_ranges=true;}std::string ReplacementFor_content_type;
std::string ReplacementFor_boundary;if(ReplacementFor_need_apply_ranges){
ReplacementFor_apply_ranges(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_content_type,ReplacementFor_boundary);}if(
ReplacementFor_close_connection||ReplacementFor_req.
ReplacementFor_get_header_value("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")==
"\x63\x6c\x6f\x73\x65"){ReplacementFor_res.ReplacementFor_set_header(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e","\x63\x6c\x6f\x73\x65");}else{std::
stringstream ReplacementFor_ss;ReplacementFor_ss<<
"\x74\x69\x6d\x65\x6f\x75\x74\x3d"<<ReplacementFor_keep_alive_timeout_sec_<<
"\x2c\x20\x6d\x61\x78\x3d"<<ReplacementFor_keep_alive_max_count_;
ReplacementFor_res.ReplacementFor_set_header(
"\x4b\x65\x65\x70\x2d\x41\x6c\x69\x76\x65",ReplacementFor_ss.str());}if(!
ReplacementFor_res.ReplacementFor_has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65")&&(!ReplacementFor_res.
ReplacementFor_body.empty()||ReplacementFor_res.ReplacementFor_content_length_>
(0x11a7+2860-0x1cd3)||ReplacementFor_res.ReplacementFor_content_provider_)){
ReplacementFor_res.ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e");}if(!ReplacementFor_res.
ReplacementFor_has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")&&ReplacementFor_res.
ReplacementFor_body.empty()&&!ReplacementFor_res.ReplacementFor_content_length_
&&!ReplacementFor_res.ReplacementFor_content_provider_){ReplacementFor_res.
ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68","\x30");}if(!
ReplacementFor_res.ReplacementFor_has_header(
"\x41\x63\x63\x65\x70\x74\x2d\x52\x61\x6e\x67\x65\x73")&&ReplacementFor_req.
ReplacementFor_method=="\x48\x45\x41\x44"){ReplacementFor_res.
ReplacementFor_set_header("\x41\x63\x63\x65\x70\x74\x2d\x52\x61\x6e\x67\x65\x73"
,"\x62\x79\x74\x65\x73");}if(ReplacementFor_post_routing_handler_){
ReplacementFor_post_routing_handler_(ReplacementFor_req,ReplacementFor_res);}{
ReplacementFor_detail::ReplacementFor_BufferStream ReplacementFor_bstrm;if(!
ReplacementFor_bstrm.ReplacementFor_write_format(
"\x48\x54\x54\x50\x2f\x31\x2e\x31\x20\x25\x64\x20\x25\x73" "\r\n",
ReplacementFor_res.status,ReplacementFor_detail::ReplacementFor_status_message(
ReplacementFor_res.status))){return false;}if(!ReplacementFor_detail::
ReplacementFor_write_headers(ReplacementFor_bstrm,ReplacementFor_res.
ReplacementFor_headers)){return false;}auto&data=ReplacementFor_bstrm.
ReplacementFor_get_buffer();ReplacementFor_strm.write(data.data(),data.size());}
auto ReplacementFor_ret=true;if(ReplacementFor_req.ReplacementFor_method!=
"\x48\x45\x41\x44"){if(!ReplacementFor_res.ReplacementFor_body.empty()){if(!
ReplacementFor_strm.write(ReplacementFor_res.ReplacementFor_body)){
ReplacementFor_ret=false;}}else if(ReplacementFor_res.
ReplacementFor_content_provider_){if(!ReplacementFor_write_content_with_provider
(ReplacementFor_strm,ReplacementFor_req,ReplacementFor_res,
ReplacementFor_boundary,ReplacementFor_content_type)){ReplacementFor_ret=false;}
}}if(ReplacementFor_logger_){ReplacementFor_logger_(ReplacementFor_req,
ReplacementFor_res);}return ReplacementFor_ret;}bool ReplacementFor_Server::
ReplacementFor_write_content_with_provider(ReplacementFor_Stream&
ReplacementFor_strm,const ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,const std::string&
ReplacementFor_boundary,const std::string&ReplacementFor_content_type){auto 
ReplacementFor_is_shutting_down=[this](){return this->ReplacementFor_svr_sock_==
INVALID_SOCKET;};if(ReplacementFor_res.ReplacementFor_content_length_>
(0x194f+208-0x1a1f)){if(ReplacementFor_req.ranges.empty()){return 
ReplacementFor_detail::ReplacementFor_write_content(ReplacementFor_strm,
ReplacementFor_res.ReplacementFor_content_provider_,(0x12c9+4334-0x23b7),
ReplacementFor_res.ReplacementFor_content_length_,
ReplacementFor_is_shutting_down);}else if(ReplacementFor_req.ranges.size()==
(0x16e7+2607-0x2115)){auto ReplacementFor_offsets=ReplacementFor_detail::
ReplacementFor_get_range_offset_and_length(ReplacementFor_req,ReplacementFor_res
.ReplacementFor_content_length_,(0x39+9343-0x24b8));auto offset=
ReplacementFor_offsets.first;auto length=ReplacementFor_offsets.second;return 
ReplacementFor_detail::ReplacementFor_write_content(ReplacementFor_strm,
ReplacementFor_res.ReplacementFor_content_provider_,offset,length,
ReplacementFor_is_shutting_down);}else{return ReplacementFor_detail::
ReplacementFor_write_multipart_ranges_data(ReplacementFor_strm,
ReplacementFor_req,ReplacementFor_res,ReplacementFor_boundary,
ReplacementFor_content_type,ReplacementFor_is_shutting_down);}}else{if(
ReplacementFor_res.ReplacementFor_is_chunked_content_provider_){auto type=
ReplacementFor_detail::ReplacementFor_encoding_type(ReplacementFor_req,
ReplacementFor_res);std::unique_ptr<ReplacementFor_detail::
ReplacementFor_compressor>ReplacementFor_compressor;if(type==
ReplacementFor_detail::ReplacementFor_EncodingType::ReplacementFor_Gzip){
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_gzip_compressor>();
#endif
}else if(type==ReplacementFor_detail::ReplacementFor_EncodingType::
ReplacementFor_Brotli){
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_brotli_compressor>();
#endif
}else{ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_nocompressor>();}assert(
ReplacementFor_compressor!=nullptr);return ReplacementFor_detail::
ReplacementFor_write_content_chunked(ReplacementFor_strm,ReplacementFor_res.
ReplacementFor_content_provider_,ReplacementFor_is_shutting_down,*
ReplacementFor_compressor);}else{return ReplacementFor_detail::
ReplacementFor_write_content_without_length(ReplacementFor_strm,
ReplacementFor_res.ReplacementFor_content_provider_,
ReplacementFor_is_shutting_down);}}}bool ReplacementFor_Server::
ReplacementFor_read_content(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res){ReplacementFor_MultipartFormDataMap::iterator cur;if(
ReplacementFor_read_content_core(ReplacementFor_strm,ReplacementFor_req,
ReplacementFor_res,[&](const char*buf,size_t n){if(ReplacementFor_req.
ReplacementFor_body.size()+n>ReplacementFor_req.ReplacementFor_body.max_size()){
return false;}ReplacementFor_req.ReplacementFor_body.append(buf,n);return true;}
,[&](const ReplacementFor_MultipartFormData&ReplacementFor_file){cur=
ReplacementFor_req.ReplacementFor_files.emplace(ReplacementFor_file.name,
ReplacementFor_file);return true;},[&](const char*buf,size_t n){auto&
ReplacementFor_content=cur->second.ReplacementFor_content;if(
ReplacementFor_content.size()+n>ReplacementFor_content.max_size()){return false;
}ReplacementFor_content.append(buf,n);return true;})){const auto&
ReplacementFor_content_type=ReplacementFor_req.ReplacementFor_get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");if(!
ReplacementFor_content_type.find(
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
)){ReplacementFor_detail::ReplacementFor_parse_query_text(ReplacementFor_req.
ReplacementFor_body,ReplacementFor_req.ReplacementFor_params);}return true;}
return false;}bool ReplacementFor_Server::
ReplacementFor_read_content_with_content_receiver(ReplacementFor_Stream&
ReplacementFor_strm,ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,ReplacementFor_ContentReceiver 
ReplacementFor_receiver,ReplacementFor_MultipartContentHeader 
ReplacementFor_multipart_header,ReplacementFor_ContentReceiver 
ReplacementFor_multipart_receiver){return ReplacementFor_read_content_core(
ReplacementFor_strm,ReplacementFor_req,ReplacementFor_res,std::move(
ReplacementFor_receiver),std::move(ReplacementFor_multipart_header),std::move(
ReplacementFor_multipart_receiver));}bool ReplacementFor_Server::
ReplacementFor_read_content_core(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,ReplacementFor_ContentReceiver ReplacementFor_receiver,
ReplacementFor_MultipartContentHeader ReplacementFor_mulitpart_header,
ReplacementFor_ContentReceiver ReplacementFor_multipart_receiver){
ReplacementFor_detail::ReplacementFor_MultipartFormDataParser 
ReplacementFor_multipart_form_data_parser;
ReplacementFor_ContentReceiverWithProgress out;if(ReplacementFor_req.
ReplacementFor_is_multipart_form_data()){const auto&ReplacementFor_content_type=
ReplacementFor_req.ReplacementFor_get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");std::string 
ReplacementFor_boundary;if(!ReplacementFor_detail::
ReplacementFor_parse_multipart_boundary(ReplacementFor_content_type,
ReplacementFor_boundary)){ReplacementFor_res.status=(0x5b6+1968-0xbd6);return 
false;}ReplacementFor_multipart_form_data_parser.ReplacementFor_set_boundary(std
::move(ReplacementFor_boundary));out=[&](const char*buf,size_t n,uint64_t,
uint64_t){return ReplacementFor_multipart_form_data_parser.ReplacementFor_parse(
buf,n,ReplacementFor_multipart_receiver,ReplacementFor_mulitpart_header);};}else
{out=[ReplacementFor_receiver](const char*buf,size_t n,uint64_t,uint64_t){return
 ReplacementFor_receiver(buf,n);};}if(ReplacementFor_req.ReplacementFor_method==
"\x44\x45\x4c\x45\x54\x45"&&!ReplacementFor_req.ReplacementFor_has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){return true;}if(!
ReplacementFor_detail::ReplacementFor_read_content(ReplacementFor_strm,
ReplacementFor_req,ReplacementFor_payload_max_length_,ReplacementFor_res.status,
nullptr,out,true)){return false;}if(ReplacementFor_req.
ReplacementFor_is_multipart_form_data()){if(!
ReplacementFor_multipart_form_data_parser.ReplacementFor_is_valid()){
ReplacementFor_res.status=(0xdfd+5656-0x2285);return false;}}return true;}bool 
ReplacementFor_Server::ReplacementFor_handle_file_request(const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,bool ReplacementFor_head){for(const auto&entry:
ReplacementFor_base_dirs_){if(!ReplacementFor_req.ReplacementFor_path.compare(
(0x7b5+3746-0x1657),entry.ReplacementFor_mount_point.size(),entry.
ReplacementFor_mount_point)){std::string ReplacementFor_sub_path="\x2f"+
ReplacementFor_req.ReplacementFor_path.substr(entry.ReplacementFor_mount_point.
size());if(ReplacementFor_detail::ReplacementFor_is_valid_path(
ReplacementFor_sub_path)){auto ReplacementFor_path=entry.ReplacementFor_base_dir
+ReplacementFor_sub_path;if(ReplacementFor_path.back()==
((char)(0x351+1362-0x874))){ReplacementFor_path+=
"\x69\x6e\x64\x65\x78\x2e\x68\x74\x6d\x6c";}if(ReplacementFor_detail::
ReplacementFor_is_file(ReplacementFor_path)){ReplacementFor_detail::
ReplacementFor_read_file(ReplacementFor_path,ReplacementFor_res.
ReplacementFor_body);auto type=ReplacementFor_detail::
ReplacementFor_find_content_type(ReplacementFor_path,
ReplacementFor_file_extension_and_mimetype_map_);if(type){ReplacementFor_res.
ReplacementFor_set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
type);}for(const auto&ReplacementFor_kv:entry.ReplacementFor_headers){
ReplacementFor_res.ReplacementFor_set_header(ReplacementFor_kv.first.c_str(),
ReplacementFor_kv.second);}ReplacementFor_res.status=ReplacementFor_req.
ReplacementFor_has_header("\x52\x61\x6e\x67\x65")?(0x690+2569-0xfcb):
(0x235a+484-0x2476);if(!ReplacementFor_head&&
ReplacementFor_file_request_handler_){ReplacementFor_file_request_handler_(
ReplacementFor_req,ReplacementFor_res);}return true;}}}}return false;}
ReplacementFor_socket_t ReplacementFor_Server::
ReplacementFor_create_server_socket(const char*ReplacementFor_host,int 
ReplacementFor_port,int ReplacementFor_socket_flags,ReplacementFor_SocketOptions
 ReplacementFor_socket_options)const{return ReplacementFor_detail::
ReplacementFor_create_socket(ReplacementFor_host,ReplacementFor_port,
ReplacementFor_socket_flags,ReplacementFor_tcp_nodelay_,std::move(
ReplacementFor_socket_options),[](ReplacementFor_socket_t ReplacementFor_sock,
struct addrinfo&ReplacementFor_ai)->bool{if(::bind(ReplacementFor_sock,
ReplacementFor_ai.ai_addr,static_cast<socklen_t>(ReplacementFor_ai.ai_addrlen)))
{return false;}if(::listen(ReplacementFor_sock,(0xc2+5061-0x1482))){return false
;}return true;});}int ReplacementFor_Server::ReplacementFor_bind_internal(const 
char*ReplacementFor_host,int ReplacementFor_port,int ReplacementFor_socket_flags
){if(!ReplacementFor_is_valid()){return-(0xd82+2256-0x1651);}
ReplacementFor_svr_sock_=ReplacementFor_create_server_socket(ReplacementFor_host
,ReplacementFor_port,ReplacementFor_socket_flags,ReplacementFor_socket_options_)
;if(ReplacementFor_svr_sock_==INVALID_SOCKET){return-(0x1d0d+664-0x1fa4);}if(
ReplacementFor_port==(0x3b1+2113-0xbf2)){struct sockaddr_storage addr;socklen_t 
ReplacementFor_addr_len=sizeof(addr);if(getsockname(ReplacementFor_svr_sock_,
reinterpret_cast<struct sockaddr*>(&addr),&ReplacementFor_addr_len)==-
(0x457+8783-0x26a5)){return-(0x1371+3452-0x20ec);}if(addr.ss_family==AF_INET){
return ntohs(reinterpret_cast<struct sockaddr_in*>(&addr)->sin_port);}else if(
addr.ss_family==AF_INET6){return ntohs(reinterpret_cast<struct sockaddr_in6*>(&
addr)->sin6_port);}else{return-(0xd73+1580-0x139e);}}else{return 
ReplacementFor_port;}}bool ReplacementFor_Server::ReplacementFor_listen_internal
(){auto ReplacementFor_ret=true;ReplacementFor_is_running_=true;{std::unique_ptr
<ReplacementFor_TaskQueue>ReplacementFor_task_queue(
ReplacementFor_new_task_queue());while(ReplacementFor_svr_sock_!=INVALID_SOCKET)
{
#ifndef _WIN32
if(ReplacementFor_idle_interval_sec_>(0x1b9+4996-0x153d)||
ReplacementFor_idle_interval_usec_>(0x302+5727-0x1961)){
#endif
auto val=ReplacementFor_detail::ReplacementFor_select_read(
ReplacementFor_svr_sock_,ReplacementFor_idle_interval_sec_,
ReplacementFor_idle_interval_usec_);if(val==(0xecf+3823-0x1dbe)){
ReplacementFor_task_queue->ReplacementFor_on_idle();continue;}
#ifndef _WIN32
}
#endif
ReplacementFor_socket_t ReplacementFor_sock=accept(ReplacementFor_svr_sock_,
nullptr,nullptr);if(ReplacementFor_sock==INVALID_SOCKET){if(errno==EMFILE){std::
this_thread::sleep_for(std::chrono::milliseconds((0x4f6+7307-0x2180)));continue;
}if(ReplacementFor_svr_sock_!=INVALID_SOCKET){ReplacementFor_detail::
ReplacementFor_close_socket(ReplacementFor_svr_sock_);ReplacementFor_ret=false;}
else{;}break;}
#if __cplusplus > 201703L
ReplacementFor_task_queue->ReplacementFor_enqueue([=,this](){
ReplacementFor_process_and_close_socket(ReplacementFor_sock);});
#else
ReplacementFor_task_queue->ReplacementFor_enqueue([=](){
ReplacementFor_process_and_close_socket(ReplacementFor_sock);});
#endif
}ReplacementFor_task_queue->shutdown();}ReplacementFor_is_running_=false;return 
ReplacementFor_ret;}bool ReplacementFor_Server::ReplacementFor_routing(
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,ReplacementFor_Stream&ReplacementFor_strm){if(
ReplacementFor_pre_routing_handler_&&ReplacementFor_pre_routing_handler_(
ReplacementFor_req,ReplacementFor_res)==ReplacementFor_HandlerResponse::
ReplacementFor_Handled){return true;}bool ReplacementFor_is_head_request=
ReplacementFor_req.ReplacementFor_method=="\x48\x45\x41\x44";if((
ReplacementFor_req.ReplacementFor_method=="\x47\x45\x54"||
ReplacementFor_is_head_request)&&ReplacementFor_handle_file_request(
ReplacementFor_req,ReplacementFor_res,ReplacementFor_is_head_request)){return 
true;}if(ReplacementFor_detail::ReplacementFor_expect_content(ReplacementFor_req
)){{ReplacementFor_ContentReader ReplacementFor_reader([&](
ReplacementFor_ContentReceiver ReplacementFor_receiver){return 
ReplacementFor_read_content_with_content_receiver(ReplacementFor_strm,
ReplacementFor_req,ReplacementFor_res,std::move(ReplacementFor_receiver),nullptr
,nullptr);},[&](ReplacementFor_MultipartContentHeader header,
ReplacementFor_ContentReceiver ReplacementFor_receiver){return 
ReplacementFor_read_content_with_content_receiver(ReplacementFor_strm,
ReplacementFor_req,ReplacementFor_res,nullptr,std::move(header),std::move(
ReplacementFor_receiver));});if(ReplacementFor_req.ReplacementFor_method==
"\x50\x4f\x53\x54"){if(ReplacementFor_dispatch_request_for_content_reader(
ReplacementFor_req,ReplacementFor_res,std::move(ReplacementFor_reader),
ReplacementFor_post_handlers_for_content_reader_)){return true;}}else if(
ReplacementFor_req.ReplacementFor_method=="\x50\x55\x54"){if(
ReplacementFor_dispatch_request_for_content_reader(ReplacementFor_req,
ReplacementFor_res,std::move(ReplacementFor_reader),
ReplacementFor_put_handlers_for_content_reader_)){return true;}}else if(
ReplacementFor_req.ReplacementFor_method=="\x50\x41\x54\x43\x48"){if(
ReplacementFor_dispatch_request_for_content_reader(ReplacementFor_req,
ReplacementFor_res,std::move(ReplacementFor_reader),
ReplacementFor_patch_handlers_for_content_reader_)){return true;}}else if(
ReplacementFor_req.ReplacementFor_method=="\x44\x45\x4c\x45\x54\x45"){if(
ReplacementFor_dispatch_request_for_content_reader(ReplacementFor_req,
ReplacementFor_res,std::move(ReplacementFor_reader),
ReplacementFor_delete_handlers_for_content_reader_)){return true;}}}if(!
ReplacementFor_read_content(ReplacementFor_strm,ReplacementFor_req,
ReplacementFor_res)){return false;}}if(ReplacementFor_req.ReplacementFor_method
=="\x47\x45\x54"||ReplacementFor_req.ReplacementFor_method=="\x48\x45\x41\x44"){
return ReplacementFor_dispatch_request(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_get_handlers_);}else if(ReplacementFor_req.ReplacementFor_method
=="\x50\x4f\x53\x54"){return ReplacementFor_dispatch_request(ReplacementFor_req,
ReplacementFor_res,ReplacementFor_post_handlers_);}else if(ReplacementFor_req.
ReplacementFor_method=="\x50\x55\x54"){return ReplacementFor_dispatch_request(
ReplacementFor_req,ReplacementFor_res,ReplacementFor_put_handlers_);}else if(
ReplacementFor_req.ReplacementFor_method=="\x44\x45\x4c\x45\x54\x45"){return 
ReplacementFor_dispatch_request(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_delete_handlers_);}else if(ReplacementFor_req.
ReplacementFor_method=="\x4f\x50\x54\x49\x4f\x4e\x53"){return 
ReplacementFor_dispatch_request(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_options_handlers_);}else if(ReplacementFor_req.
ReplacementFor_method=="\x50\x41\x54\x43\x48"){return 
ReplacementFor_dispatch_request(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_patch_handlers_);}ReplacementFor_res.status=(0x189b+3118-0x2339);
return false;}bool ReplacementFor_Server::ReplacementFor_dispatch_request(
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,const ReplacementFor_Handlers&ReplacementFor_handlers){for(
const auto&x:ReplacementFor_handlers){const auto&pattern=x.first;const auto&
ReplacementFor_handler=x.second;if(std::regex_match(ReplacementFor_req.
ReplacementFor_path,ReplacementFor_req.ReplacementFor_matches,pattern)){
ReplacementFor_handler(ReplacementFor_req,ReplacementFor_res);return true;}}
return false;}void ReplacementFor_Server::ReplacementFor_apply_ranges(const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,std::string&ReplacementFor_content_type,std::string&
ReplacementFor_boundary){if(ReplacementFor_req.ranges.size()>(0x399+5968-0x1ae8)
){ReplacementFor_boundary=ReplacementFor_detail::
ReplacementFor_make_multipart_data_boundary();auto ReplacementFor_it=
ReplacementFor_res.ReplacementFor_headers.find(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");if(ReplacementFor_it!=
ReplacementFor_res.ReplacementFor_headers.end()){ReplacementFor_content_type=
ReplacementFor_it->second;ReplacementFor_res.ReplacementFor_headers.erase(
ReplacementFor_it);}ReplacementFor_res.ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x62\x79\x74\x65\x72\x61\x6e\x67\x65\x73\x3b\x20\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d"
+ReplacementFor_boundary);}auto type=ReplacementFor_detail::
ReplacementFor_encoding_type(ReplacementFor_req,ReplacementFor_res);if(
ReplacementFor_res.ReplacementFor_body.empty()){if(ReplacementFor_res.
ReplacementFor_content_length_>(0xa42+856-0xd9a)){size_t length=
(0x272+4084-0x1266);if(ReplacementFor_req.ranges.empty()){length=
ReplacementFor_res.ReplacementFor_content_length_;}else if(ReplacementFor_req.
ranges.size()==(0x988+292-0xaab)){auto ReplacementFor_offsets=
ReplacementFor_detail::ReplacementFor_get_range_offset_and_length(
ReplacementFor_req,ReplacementFor_res.ReplacementFor_content_length_,
(0xad0+668-0xd6c));auto offset=ReplacementFor_offsets.first;length=
ReplacementFor_offsets.second;auto ReplacementFor_content_range=
ReplacementFor_detail::ReplacementFor_make_content_range_header_field(offset,
length,ReplacementFor_res.ReplacementFor_content_length_);ReplacementFor_res.
ReplacementFor_set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65"
,ReplacementFor_content_range);}else{length=ReplacementFor_detail::
ReplacementFor_get_multipart_ranges_data_length(ReplacementFor_req,
ReplacementFor_res,ReplacementFor_boundary,ReplacementFor_content_type);}
ReplacementFor_res.ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",std::to_string(length
));}else{if(ReplacementFor_res.ReplacementFor_content_provider_){if(
ReplacementFor_res.ReplacementFor_is_chunked_content_provider_){
ReplacementFor_res.ReplacementFor_set_header(
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x63\x68\x75\x6e\x6b\x65\x64");if(type==ReplacementFor_detail::
ReplacementFor_EncodingType::ReplacementFor_Gzip){ReplacementFor_res.
ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x67\x7a\x69\x70");}else if(type==ReplacementFor_detail::
ReplacementFor_EncodingType::ReplacementFor_Brotli){ReplacementFor_res.
ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67","\x62\x72");}
}}}}else{if(ReplacementFor_req.ranges.empty()){;}else if(ReplacementFor_req.
ranges.size()==(0x595+6167-0x1dab)){auto ReplacementFor_offsets=
ReplacementFor_detail::ReplacementFor_get_range_offset_and_length(
ReplacementFor_req,ReplacementFor_res.ReplacementFor_body.size(),
(0xcc5+1633-0x1326));auto offset=ReplacementFor_offsets.first;auto length=
ReplacementFor_offsets.second;auto ReplacementFor_content_range=
ReplacementFor_detail::ReplacementFor_make_content_range_header_field(offset,
length,ReplacementFor_res.ReplacementFor_body.size());ReplacementFor_res.
ReplacementFor_set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65"
,ReplacementFor_content_range);if(offset<ReplacementFor_res.ReplacementFor_body.
size()){ReplacementFor_res.ReplacementFor_body=ReplacementFor_res.
ReplacementFor_body.substr(offset,length);}else{ReplacementFor_res.
ReplacementFor_body.clear();ReplacementFor_res.status=(0x170b+2490-0x1f25);}}
else{std::string data;if(ReplacementFor_detail::
ReplacementFor_make_multipart_ranges_data(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_boundary,ReplacementFor_content_type,data)){ReplacementFor_res.
ReplacementFor_body.swap(data);}else{ReplacementFor_res.ReplacementFor_body.
clear();ReplacementFor_res.status=(0x4a3+6821-0x1da8);}}if(type!=
ReplacementFor_detail::ReplacementFor_EncodingType::None){std::unique_ptr<
ReplacementFor_detail::ReplacementFor_compressor>ReplacementFor_compressor;std::
string ReplacementFor_content_encoding;if(type==ReplacementFor_detail::
ReplacementFor_EncodingType::ReplacementFor_Gzip){
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_gzip_compressor>();
ReplacementFor_content_encoding="\x67\x7a\x69\x70";
#endif
}else if(type==ReplacementFor_detail::ReplacementFor_EncodingType::
ReplacementFor_Brotli){
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_brotli_compressor>();
ReplacementFor_content_encoding="\x62\x72";
#endif
}if(ReplacementFor_compressor){std::string ReplacementFor_compressed;if(
ReplacementFor_compressor->compress(ReplacementFor_res.ReplacementFor_body.data(
),ReplacementFor_res.ReplacementFor_body.size(),true,[&](const char*data,size_t 
ReplacementFor_data_len){ReplacementFor_compressed.append(data,
ReplacementFor_data_len);return true;})){ReplacementFor_res.ReplacementFor_body.
swap(ReplacementFor_compressed);ReplacementFor_res.ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
ReplacementFor_content_encoding);}}}auto length=std::to_string(
ReplacementFor_res.ReplacementFor_body.size());ReplacementFor_res.
ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}bool 
ReplacementFor_Server::ReplacementFor_dispatch_request_for_content_reader(
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,ReplacementFor_ContentReader ReplacementFor_content_reader,
const ReplacementFor_HandlersForContentReader&ReplacementFor_handlers){for(const
 auto&x:ReplacementFor_handlers){const auto&pattern=x.first;const auto&
ReplacementFor_handler=x.second;if(std::regex_match(ReplacementFor_req.
ReplacementFor_path,ReplacementFor_req.ReplacementFor_matches,pattern)){
ReplacementFor_handler(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_content_reader);return true;}}return false;}bool 
ReplacementFor_Server::ReplacementFor_process_request(ReplacementFor_Stream&
ReplacementFor_strm,bool ReplacementFor_close_connection,bool&
ReplacementFor_connection_closed,const std::function<void(ReplacementFor_Request
&)>&ReplacementFor_setup_request){std::array<char,(0x1312+3802-0x19ec)>buf{};
ReplacementFor_detail::ReplacementFor_stream_line_reader 
ReplacementFor_line_reader(ReplacementFor_strm,buf.data(),buf.size());if(!
ReplacementFor_line_reader.getline()){return false;}ReplacementFor_Request 
ReplacementFor_req;ReplacementFor_Response ReplacementFor_res;ReplacementFor_res
.ReplacementFor_version="\x48\x54\x54\x50\x2f\x31\x2e\x31";
#ifdef _WIN32
#else
#ifndef ReplacementFor_CPPHTTPLIB_USE_POLL
if(ReplacementFor_strm.socket()>=FD_SETSIZE){ReplacementFor_Headers dummy;
ReplacementFor_detail::ReplacementFor_read_headers(ReplacementFor_strm,dummy);
ReplacementFor_res.status=(0x1909+3158-0x236b);return 
ReplacementFor_write_response(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}
#endif
#endif
if(ReplacementFor_line_reader.size()>
ReplacementFor_CPPHTTPLIB_REQUEST_URI_MAX_LENGTH){ReplacementFor_Headers dummy;
ReplacementFor_detail::ReplacementFor_read_headers(ReplacementFor_strm,dummy);
ReplacementFor_res.status=(0x271+2384-0xa23);return 
ReplacementFor_write_response(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}if(!
ReplacementFor_parse_request_line(ReplacementFor_line_reader.ReplacementFor_ptr(
),ReplacementFor_req)||!ReplacementFor_detail::ReplacementFor_read_headers(
ReplacementFor_strm,ReplacementFor_req.ReplacementFor_headers)){
ReplacementFor_res.status=(0x266+7266-0x1d38);return 
ReplacementFor_write_response(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}if(
ReplacementFor_req.ReplacementFor_get_header_value(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")=="\x63\x6c\x6f\x73\x65"){
ReplacementFor_connection_closed=true;}if(ReplacementFor_req.
ReplacementFor_version=="\x48\x54\x54\x50\x2f\x31\x2e\x30"&&ReplacementFor_req.
ReplacementFor_get_header_value("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")!=
"\x4b\x65\x65\x70\x2d\x41\x6c\x69\x76\x65"){ReplacementFor_connection_closed=
true;}ReplacementFor_strm.ReplacementFor_get_remote_ip_and_port(
ReplacementFor_req.ReplacementFor_remote_addr,ReplacementFor_req.
ReplacementFor_remote_port);ReplacementFor_req.ReplacementFor_set_header(
"\x52\x45\x4d\x4f\x54\x45\x5f\x41\x44\x44\x52",ReplacementFor_req.
ReplacementFor_remote_addr);ReplacementFor_req.ReplacementFor_set_header(
"\x52\x45\x4d\x4f\x54\x45\x5f\x50\x4f\x52\x54",std::to_string(ReplacementFor_req
.ReplacementFor_remote_port));if(ReplacementFor_req.ReplacementFor_has_header(
"\x52\x61\x6e\x67\x65")){const auto&ReplacementFor_range_header_value=
ReplacementFor_req.ReplacementFor_get_header_value("\x52\x61\x6e\x67\x65");if(!
ReplacementFor_detail::ReplacementFor_parse_range_header(
ReplacementFor_range_header_value,ReplacementFor_req.ranges)){ReplacementFor_res
.status=(0x513+8134-0x2339);return ReplacementFor_write_response(
ReplacementFor_strm,ReplacementFor_close_connection,ReplacementFor_req,
ReplacementFor_res);}}if(ReplacementFor_setup_request){
ReplacementFor_setup_request(ReplacementFor_req);}if(ReplacementFor_req.
ReplacementFor_get_header_value("\x45\x78\x70\x65\x63\x74")==
"\x31\x30\x30\x2d\x63\x6f\x6e\x74\x69\x6e\x75\x65"){auto status=
(0x2c9+4498-0x13f7);if(ReplacementFor_expect_100_continue_handler_){status=
ReplacementFor_expect_100_continue_handler_(ReplacementFor_req,
ReplacementFor_res);}switch(status){case(0x1136+2261-0x19a7):case
(0x13a9+4240-0x2298):ReplacementFor_strm.ReplacementFor_write_format(
"\x48\x54\x54\x50\x2f\x31\x2e\x31\x20\x25\x64\x20\x25\x73" "\r\n\r\n",status,
ReplacementFor_detail::ReplacementFor_status_message(status));break;default:
return ReplacementFor_write_response(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}}bool 
ReplacementFor_routed=false;try{ReplacementFor_routed=ReplacementFor_routing(
ReplacementFor_req,ReplacementFor_res,ReplacementFor_strm);}catch(std::exception
&ReplacementFor_e){if(ReplacementFor_exception_handler_){
ReplacementFor_exception_handler_(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_e);ReplacementFor_routed=true;}else{ReplacementFor_res.status=
(0x36b+5600-0x1757);ReplacementFor_res.ReplacementFor_set_header(
"\x45\x58\x43\x45\x50\x54\x49\x4f\x4e\x5f\x57\x48\x41\x54",ReplacementFor_e.what
());}}catch(...){ReplacementFor_res.status=(0xff0+685-0x10a9);ReplacementFor_res
.ReplacementFor_set_header(
"\x45\x58\x43\x45\x50\x54\x49\x4f\x4e\x5f\x57\x48\x41\x54",
"\x55\x4e\x4b\x4e\x4f\x57\x4e");}if(ReplacementFor_routed){if(ReplacementFor_res
.status==-(0x179a+1748-0x1e6d)){ReplacementFor_res.status=ReplacementFor_req.
ranges.empty()?(0xcfb+3294-0x1911):(0x2f0+7212-0x1e4e);}return 
ReplacementFor_write_response_with_content(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}else{if(
ReplacementFor_res.status==-(0x14b4+736-0x1793)){ReplacementFor_res.status=
(0x4ab+4004-0x12bb);}return ReplacementFor_write_response(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}}bool 
ReplacementFor_Server::ReplacementFor_is_valid()const{return true;}bool 
ReplacementFor_Server::ReplacementFor_process_and_close_socket(
ReplacementFor_socket_t ReplacementFor_sock){auto ReplacementFor_ret=
ReplacementFor_detail::ReplacementFor_process_server_socket(ReplacementFor_sock,
ReplacementFor_keep_alive_max_count_,ReplacementFor_keep_alive_timeout_sec_,
ReplacementFor_read_timeout_sec_,ReplacementFor_read_timeout_usec_,
ReplacementFor_write_timeout_sec_,ReplacementFor_write_timeout_usec_,[this](
ReplacementFor_Stream&ReplacementFor_strm,bool ReplacementFor_close_connection,
bool&ReplacementFor_connection_closed){return ReplacementFor_process_request(
ReplacementFor_strm,ReplacementFor_close_connection,
ReplacementFor_connection_closed,nullptr);});ReplacementFor_detail::
ReplacementFor_shutdown_socket(ReplacementFor_sock);ReplacementFor_detail::
ReplacementFor_close_socket(ReplacementFor_sock);return ReplacementFor_ret;}
ReplacementFor_ClientImpl::ReplacementFor_ClientImpl(const std::string&
ReplacementFor_host):ReplacementFor_ClientImpl(ReplacementFor_host,
(0x15d0+2102-0x1db6),std::string(),std::string()){}ReplacementFor_ClientImpl::
ReplacementFor_ClientImpl(const std::string&ReplacementFor_host,int 
ReplacementFor_port):ReplacementFor_ClientImpl(ReplacementFor_host,
ReplacementFor_port,std::string(),std::string()){}ReplacementFor_ClientImpl::
ReplacementFor_ClientImpl(const std::string&ReplacementFor_host,int 
ReplacementFor_port,const std::string&ReplacementFor_client_cert_path,const std
::string&ReplacementFor_client_key_path):ReplacementFor_host_(
ReplacementFor_host),ReplacementFor_port_(ReplacementFor_port),
ReplacementFor_host_and_port_(ReplacementFor_host_+"\x3a"+std::to_string(
ReplacementFor_port_)),ReplacementFor_client_cert_path_(
ReplacementFor_client_cert_path),ReplacementFor_client_key_path_(
ReplacementFor_client_key_path){}ReplacementFor_ClientImpl::~
ReplacementFor_ClientImpl(){ReplacementFor_lock_socket_and_shutdown_and_close();
}bool ReplacementFor_ClientImpl::ReplacementFor_is_valid()const{return true;}
void ReplacementFor_ClientImpl::ReplacementFor_copy_settings(const 
ReplacementFor_ClientImpl&ReplacementFor_rhs){ReplacementFor_client_cert_path_=
ReplacementFor_rhs.ReplacementFor_client_cert_path_;
ReplacementFor_client_key_path_=ReplacementFor_rhs.
ReplacementFor_client_key_path_;ReplacementFor_connection_timeout_sec_=
ReplacementFor_rhs.ReplacementFor_connection_timeout_sec_;
ReplacementFor_read_timeout_sec_=ReplacementFor_rhs.
ReplacementFor_read_timeout_sec_;ReplacementFor_read_timeout_usec_=
ReplacementFor_rhs.ReplacementFor_read_timeout_usec_;
ReplacementFor_write_timeout_sec_=ReplacementFor_rhs.
ReplacementFor_write_timeout_sec_;ReplacementFor_write_timeout_usec_=
ReplacementFor_rhs.ReplacementFor_write_timeout_usec_;
ReplacementFor_basic_auth_username_=ReplacementFor_rhs.
ReplacementFor_basic_auth_username_;ReplacementFor_basic_auth_password_=
ReplacementFor_rhs.ReplacementFor_basic_auth_password_;
ReplacementFor_bearer_token_auth_token_=ReplacementFor_rhs.
ReplacementFor_bearer_token_auth_token_;
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
ReplacementFor_digest_auth_username_=ReplacementFor_rhs.
ReplacementFor_digest_auth_username_;ReplacementFor_digest_auth_password_=
ReplacementFor_rhs.ReplacementFor_digest_auth_password_;
#endif
ReplacementFor_keep_alive_=ReplacementFor_rhs.ReplacementFor_keep_alive_;
ReplacementFor_follow_location_=ReplacementFor_rhs.
ReplacementFor_follow_location_;ReplacementFor_tcp_nodelay_=ReplacementFor_rhs.
ReplacementFor_tcp_nodelay_;ReplacementFor_socket_options_=ReplacementFor_rhs.
ReplacementFor_socket_options_;ReplacementFor_compress_=ReplacementFor_rhs.
ReplacementFor_compress_;ReplacementFor_decompress_=ReplacementFor_rhs.
ReplacementFor_decompress_;ReplacementFor_interface_=ReplacementFor_rhs.
ReplacementFor_interface_;ReplacementFor_proxy_host_=ReplacementFor_rhs.
ReplacementFor_proxy_host_;ReplacementFor_proxy_port_=ReplacementFor_rhs.
ReplacementFor_proxy_port_;ReplacementFor_proxy_basic_auth_username_=
ReplacementFor_rhs.ReplacementFor_proxy_basic_auth_username_;
ReplacementFor_proxy_basic_auth_password_=ReplacementFor_rhs.
ReplacementFor_proxy_basic_auth_password_;
ReplacementFor_proxy_bearer_token_auth_token_=ReplacementFor_rhs.
ReplacementFor_proxy_bearer_token_auth_token_;
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
ReplacementFor_proxy_digest_auth_username_=ReplacementFor_rhs.
ReplacementFor_proxy_digest_auth_username_;
ReplacementFor_proxy_digest_auth_password_=ReplacementFor_rhs.
ReplacementFor_proxy_digest_auth_password_;
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
ReplacementFor_server_certificate_verification_=ReplacementFor_rhs.
ReplacementFor_server_certificate_verification_;
#endif
ReplacementFor_logger_=ReplacementFor_rhs.ReplacementFor_logger_;}
ReplacementFor_socket_t ReplacementFor_ClientImpl::
ReplacementFor_create_client_socket(Error&error)const{if(!
ReplacementFor_proxy_host_.empty()&&ReplacementFor_proxy_port_!=-
(0x1855+185-0x190d)){return ReplacementFor_detail::
ReplacementFor_create_client_socket(ReplacementFor_proxy_host_.c_str(),
ReplacementFor_proxy_port_,ReplacementFor_tcp_nodelay_,
ReplacementFor_socket_options_,ReplacementFor_connection_timeout_sec_,
ReplacementFor_connection_timeout_usec_,ReplacementFor_interface_,error);}return
 ReplacementFor_detail::ReplacementFor_create_client_socket(ReplacementFor_host_
.c_str(),ReplacementFor_port_,ReplacementFor_tcp_nodelay_,
ReplacementFor_socket_options_,ReplacementFor_connection_timeout_sec_,
ReplacementFor_connection_timeout_usec_,ReplacementFor_interface_,error);}bool 
ReplacementFor_ClientImpl::ReplacementFor_create_and_connect_socket(Socket&
socket,Error&error){auto ReplacementFor_sock=ReplacementFor_create_client_socket
(error);if(ReplacementFor_sock==INVALID_SOCKET){return false;}socket.
ReplacementFor_sock=ReplacementFor_sock;return true;}void 
ReplacementFor_ClientImpl::ReplacementFor_shutdown_ssl(Socket&,bool){assert(
ReplacementFor_socket_requests_in_flight_==(0x5c3+6875-0x209e)||
ReplacementFor_socket_requests_are_from_thread_==std::this_thread::get_id());}
void ReplacementFor_ClientImpl::ReplacementFor_shutdown_socket(Socket&socket){if
(socket.ReplacementFor_sock==INVALID_SOCKET){return;}ReplacementFor_detail::
ReplacementFor_shutdown_socket(socket.ReplacementFor_sock);}void 
ReplacementFor_ClientImpl::ReplacementFor_close_socket(Socket&socket){assert(
ReplacementFor_socket_requests_in_flight_==(0x179f+2197-0x2034)||
ReplacementFor_socket_requests_are_from_thread_==std::this_thread::get_id());
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
assert(socket.ReplacementFor_ssl==nullptr);
#endif
if(socket.ReplacementFor_sock==INVALID_SOCKET){return;}ReplacementFor_detail::
ReplacementFor_close_socket(socket.ReplacementFor_sock);socket.
ReplacementFor_sock=INVALID_SOCKET;}void ReplacementFor_ClientImpl::
ReplacementFor_lock_socket_and_shutdown_and_close(){std::lock_guard<std::mutex>
ReplacementFor_guard(ReplacementFor_socket_mutex_);ReplacementFor_shutdown_ssl(
ReplacementFor_socket_,true);ReplacementFor_shutdown_socket(
ReplacementFor_socket_);ReplacementFor_close_socket(ReplacementFor_socket_);}
bool ReplacementFor_ClientImpl::ReplacementFor_read_response_line(
ReplacementFor_Stream&ReplacementFor_strm,const ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res){std::array<char,
(0xc5a+4549-0x161f)>buf;ReplacementFor_detail::ReplacementFor_stream_line_reader
 ReplacementFor_line_reader(ReplacementFor_strm,buf.data(),buf.size());if(!
ReplacementFor_line_reader.getline()){return false;}const static std::regex 
ReplacementFor_re(
"\x28\x48\x54\x54\x50\x2f\x31" "\\" "\x2e\x5b\x30\x31\x5d\x29\x20\x28" "\\" "\x64\x7b\x33\x7d\x29\x20\x28\x2e\x2a\x3f\x29" "\r\n"
);std::cmatch m;if(!std::regex_match(ReplacementFor_line_reader.
ReplacementFor_ptr(),m,ReplacementFor_re)){return ReplacementFor_req.
ReplacementFor_method=="\x43\x4f\x4e\x4e\x45\x43\x54";}ReplacementFor_res.
ReplacementFor_version=std::string(m[(0x1cf6+816-0x2025)]);ReplacementFor_res.
status=std::stoi(std::string(m[(0x1f02+691-0x21b3)]));ReplacementFor_res.
ReplacementFor_reason=std::string(m[(0xcc7+3114-0x18ee)]);while(
ReplacementFor_res.status==(0x1497+1739-0x1afe)){if(!ReplacementFor_line_reader.
getline()){return false;}if(!ReplacementFor_line_reader.getline()){return false;
}if(!std::regex_match(ReplacementFor_line_reader.ReplacementFor_ptr(),m,
ReplacementFor_re)){return false;}ReplacementFor_res.ReplacementFor_version=std
::string(m[(0x624+6021-0x1da8)]);ReplacementFor_res.status=std::stoi(std::string
(m[(0xa0c+4823-0x1ce1)]));ReplacementFor_res.ReplacementFor_reason=std::string(m
[(0x33f+1183-0x7db)]);}return true;}bool ReplacementFor_ClientImpl::send(
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,Error&error){std::lock_guard<std::recursive_mutex>
ReplacementFor_request_mutex_guard(ReplacementFor_request_mutex_);{std::
lock_guard<std::mutex>ReplacementFor_guard(ReplacementFor_socket_mutex_);
ReplacementFor_socket_should_be_closed_when_request_is_done_=false;auto 
ReplacementFor_is_alive=false;if(ReplacementFor_socket_.is_open()){
ReplacementFor_is_alive=ReplacementFor_detail::ReplacementFor_select_write(
ReplacementFor_socket_.ReplacementFor_sock,(0x616+5701-0x1c5b),
(0x453+2091-0xc7e))>(0x27c+5373-0x1779);if(!ReplacementFor_is_alive){const bool 
ReplacementFor_shutdown_gracefully=false;ReplacementFor_shutdown_ssl(
ReplacementFor_socket_,ReplacementFor_shutdown_gracefully);
ReplacementFor_shutdown_socket(ReplacementFor_socket_);
ReplacementFor_close_socket(ReplacementFor_socket_);}}if(!
ReplacementFor_is_alive){if(!ReplacementFor_create_and_connect_socket(
ReplacementFor_socket_,error)){return false;}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
if(ReplacementFor_is_ssl()){auto&ReplacementFor_scli=static_cast<
ReplacementFor_SSLClient&>(*this);if(!ReplacementFor_proxy_host_.empty()&&
ReplacementFor_proxy_port_!=-(0x721+278-0x836)){bool ReplacementFor_success=
false;if(!ReplacementFor_scli.ReplacementFor_connect_with_proxy(
ReplacementFor_socket_,ReplacementFor_res,ReplacementFor_success,error)){return 
ReplacementFor_success;}}if(!ReplacementFor_scli.ReplacementFor_initialize_ssl(
ReplacementFor_socket_,error)){return false;}}
#endif
}if(ReplacementFor_socket_requests_in_flight_>(0x9d5+6789-0x2459)){assert(
ReplacementFor_socket_requests_are_from_thread_==std::this_thread::get_id());}
ReplacementFor_socket_requests_in_flight_+=(0x11ad+3534-0x1f7a);
ReplacementFor_socket_requests_are_from_thread_=std::this_thread::get_id();}for(
const auto&header:ReplacementFor_default_headers_){if(ReplacementFor_req.
ReplacementFor_headers.find(header.first)==ReplacementFor_req.
ReplacementFor_headers.end()){ReplacementFor_req.ReplacementFor_headers.insert(
header);}}auto ReplacementFor_close_connection=!ReplacementFor_keep_alive_;auto 
ReplacementFor_ret=ReplacementFor_process_socket(ReplacementFor_socket_,[&](
ReplacementFor_Stream&ReplacementFor_strm){return ReplacementFor_handle_request(
ReplacementFor_strm,ReplacementFor_req,ReplacementFor_res,
ReplacementFor_close_connection,error);});{std::lock_guard<std::mutex>
ReplacementFor_guard(ReplacementFor_socket_mutex_);
ReplacementFor_socket_requests_in_flight_-=(0x1361+2069-0x1b75);if(
ReplacementFor_socket_requests_in_flight_<=(0x3a2+4935-0x16e9)){assert(
ReplacementFor_socket_requests_in_flight_==(0x480+2973-0x101d));
ReplacementFor_socket_requests_are_from_thread_=std::thread::id();}if(
ReplacementFor_socket_should_be_closed_when_request_is_done_||
ReplacementFor_close_connection||!ReplacementFor_ret){
ReplacementFor_shutdown_ssl(ReplacementFor_socket_,true);
ReplacementFor_shutdown_socket(ReplacementFor_socket_);
ReplacementFor_close_socket(ReplacementFor_socket_);}}if(!ReplacementFor_ret){if
(error==Error::ReplacementFor_Success){error=Error::Unknown;}}return 
ReplacementFor_ret;}Result ReplacementFor_ClientImpl::send(const 
ReplacementFor_Request&ReplacementFor_req){auto ReplacementFor_req2=
ReplacementFor_req;return ReplacementFor_send_(std::move(ReplacementFor_req2));}
Result ReplacementFor_ClientImpl::ReplacementFor_send_(ReplacementFor_Request&&
ReplacementFor_req){auto ReplacementFor_res=ReplacementFor_detail::make_unique<
ReplacementFor_Response>();auto error=Error::ReplacementFor_Success;auto 
ReplacementFor_ret=send(ReplacementFor_req,*ReplacementFor_res,error);return 
Result{ReplacementFor_ret?std::move(ReplacementFor_res):nullptr,error,std::move(
ReplacementFor_req.ReplacementFor_headers)};}bool ReplacementFor_ClientImpl::
ReplacementFor_handle_request(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,bool ReplacementFor_close_connection,Error&error){if(
ReplacementFor_req.ReplacementFor_path.empty()){error=Error::
ReplacementFor_Connection;return false;}auto ReplacementFor_req_save=
ReplacementFor_req;bool ReplacementFor_ret;if(!ReplacementFor_is_ssl()&&!
ReplacementFor_proxy_host_.empty()&&ReplacementFor_proxy_port_!=-
(0x18d7+1888-0x2036)){auto ReplacementFor_req2=ReplacementFor_req;
ReplacementFor_req2.ReplacementFor_path="\x68\x74\x74\x70\x3a\x2f\x2f"+
ReplacementFor_host_and_port_+ReplacementFor_req.ReplacementFor_path;
ReplacementFor_ret=ReplacementFor_process_request(ReplacementFor_strm,
ReplacementFor_req2,ReplacementFor_res,ReplacementFor_close_connection,error);
ReplacementFor_req=ReplacementFor_req2;ReplacementFor_req.ReplacementFor_path=
ReplacementFor_req_save.ReplacementFor_path;}else{ReplacementFor_ret=
ReplacementFor_process_request(ReplacementFor_strm,ReplacementFor_req,
ReplacementFor_res,ReplacementFor_close_connection,error);}if(!
ReplacementFor_ret){return false;}if((0xaf0+3179-0x162f)<ReplacementFor_res.
status&&ReplacementFor_res.status<(0x12e9+2685-0x1bd6)&&
ReplacementFor_follow_location_){ReplacementFor_req=ReplacementFor_req_save;
ReplacementFor_ret=ReplacementFor_redirect(ReplacementFor_req,ReplacementFor_res
,error);}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
if((ReplacementFor_res.status==(0x6fc+1732-0xc2f)||ReplacementFor_res.status==
(0x66a+3770-0x138d))&&ReplacementFor_req.ReplacementFor_authorization_count_<
(0x9a3+4825-0x1c77)){auto ReplacementFor_is_proxy=ReplacementFor_res.status==
(0x1cf8+511-0x1d60);const auto&ReplacementFor_username=ReplacementFor_is_proxy?
ReplacementFor_proxy_digest_auth_username_:ReplacementFor_digest_auth_username_;
const auto&ReplacementFor_password=ReplacementFor_is_proxy?
ReplacementFor_proxy_digest_auth_password_:ReplacementFor_digest_auth_password_;
if(!ReplacementFor_username.empty()&&!ReplacementFor_password.empty()){std::map<
std::string,std::string>ReplacementFor_auth;if(ReplacementFor_detail::
ReplacementFor_parse_www_authenticate(ReplacementFor_res,ReplacementFor_auth,
ReplacementFor_is_proxy)){ReplacementFor_Request ReplacementFor_new_req=
ReplacementFor_req;ReplacementFor_new_req.ReplacementFor_authorization_count_+=
(0x31+5172-0x1464);auto key=ReplacementFor_is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";ReplacementFor_new_req.
ReplacementFor_headers.erase(key);ReplacementFor_new_req.ReplacementFor_headers.
insert(ReplacementFor_detail::ReplacementFor_make_digest_authentication_header(
ReplacementFor_req,ReplacementFor_auth,ReplacementFor_new_req.
ReplacementFor_authorization_count_,ReplacementFor_detail::
ReplacementFor_random_string((0x153d+1436-0x1acf)),ReplacementFor_username,
ReplacementFor_password,ReplacementFor_is_proxy));ReplacementFor_Response 
ReplacementFor_new_res;ReplacementFor_ret=send(ReplacementFor_new_req,
ReplacementFor_new_res,error);if(ReplacementFor_ret){ReplacementFor_res=
ReplacementFor_new_res;}}}}
#endif
return ReplacementFor_ret;}bool ReplacementFor_ClientImpl::
ReplacementFor_redirect(ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,Error&error){if(ReplacementFor_req.
ReplacementFor_redirect_count_==(0xb89+728-0xe61)){error=Error::
ReplacementFor_ExceedRedirectCount;return false;}auto ReplacementFor_location=
ReplacementFor_detail::ReplacementFor_decode_url(ReplacementFor_res.
ReplacementFor_get_header_value("\x6c\x6f\x63\x61\x74\x69\x6f\x6e"),true);if(
ReplacementFor_location.empty()){return false;}const static std::regex 
ReplacementFor_re(
R"(^(?:(https?):)?(?://([^:/?#]*)(?::(\d+))?)?([^?#]*(?:\?[^#]*)?)(?:#.*)?)");
std::smatch m;if(!std::regex_match(ReplacementFor_location,m,ReplacementFor_re))
{return false;}auto ReplacementFor_scheme=ReplacementFor_is_ssl()?
"\x68\x74\x74\x70\x73":"\x68\x74\x74\x70";auto ReplacementFor_next_scheme=m[
(0x67c+2223-0xf2a)].str();auto ReplacementFor_next_host=m[(0xd90+3615-0x1bad)].
str();auto ReplacementFor_port_str=m[(0x297+6342-0x1b5a)].str();auto 
ReplacementFor_next_path=m[(0x31d+3124-0xf4d)].str();auto 
ReplacementFor_next_port=ReplacementFor_port_;if(!ReplacementFor_port_str.empty(
)){ReplacementFor_next_port=std::stoi(ReplacementFor_port_str);}else if(!
ReplacementFor_next_scheme.empty()){ReplacementFor_next_port=
ReplacementFor_next_scheme=="\x68\x74\x74\x70\x73"?(0x182d+1480-0x1c3a):
(0x1d82+1090-0x2174);}if(ReplacementFor_next_scheme.empty()){
ReplacementFor_next_scheme=ReplacementFor_scheme;}if(ReplacementFor_next_host.
empty()){ReplacementFor_next_host=ReplacementFor_host_;}if(
ReplacementFor_next_path.empty()){ReplacementFor_next_path="\x2f";}if(
ReplacementFor_next_scheme==ReplacementFor_scheme&&ReplacementFor_next_host==
ReplacementFor_host_&&ReplacementFor_next_port==ReplacementFor_port_){return 
ReplacementFor_detail::ReplacementFor_redirect(*this,ReplacementFor_req,
ReplacementFor_res,ReplacementFor_next_path,ReplacementFor_location,error);}else
{if(ReplacementFor_next_scheme=="\x68\x74\x74\x70\x73"){
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
ReplacementFor_SSLClient ReplacementFor_cli(ReplacementFor_next_host.c_str(),
ReplacementFor_next_port);ReplacementFor_cli.ReplacementFor_copy_settings(*this)
;return ReplacementFor_detail::ReplacementFor_redirect(ReplacementFor_cli,
ReplacementFor_req,ReplacementFor_res,ReplacementFor_next_path,
ReplacementFor_location,error);
#else
return false;
#endif
}else{ReplacementFor_ClientImpl ReplacementFor_cli(ReplacementFor_next_host.
c_str(),ReplacementFor_next_port);ReplacementFor_cli.
ReplacementFor_copy_settings(*this);return ReplacementFor_detail::
ReplacementFor_redirect(ReplacementFor_cli,ReplacementFor_req,ReplacementFor_res
,ReplacementFor_next_path,ReplacementFor_location,error);}}}bool 
ReplacementFor_ClientImpl::ReplacementFor_write_content_with_provider(
ReplacementFor_Stream&ReplacementFor_strm,const ReplacementFor_Request&
ReplacementFor_req,Error&error){auto ReplacementFor_is_shutting_down=[](){return
 false;};if(ReplacementFor_req.ReplacementFor_is_chunked_content_provider_){std
::unique_ptr<ReplacementFor_detail::ReplacementFor_compressor>
ReplacementFor_compressor;
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
if(ReplacementFor_compress_){ReplacementFor_compressor=ReplacementFor_detail::
make_unique<ReplacementFor_detail::ReplacementFor_gzip_compressor>();}else
#endif
{ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_nocompressor>();}return 
ReplacementFor_detail::ReplacementFor_write_content_chunked(ReplacementFor_strm,
ReplacementFor_req.ReplacementFor_content_provider_,
ReplacementFor_is_shutting_down,*ReplacementFor_compressor,error);}else{return 
ReplacementFor_detail::ReplacementFor_write_content(ReplacementFor_strm,
ReplacementFor_req.ReplacementFor_content_provider_,(0x564+1085-0x9a1),
ReplacementFor_req.ReplacementFor_content_length_,
ReplacementFor_is_shutting_down,error);}}bool ReplacementFor_ClientImpl::
ReplacementFor_write_request(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,bool ReplacementFor_close_connection,
Error&error){if(ReplacementFor_close_connection){ReplacementFor_req.
ReplacementFor_headers.emplace("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e",
"\x63\x6c\x6f\x73\x65");}if(!ReplacementFor_req.ReplacementFor_has_header(
"\x48\x6f\x73\x74")){if(ReplacementFor_is_ssl()){if(ReplacementFor_port_==
(0xa86+1612-0xf17)){ReplacementFor_req.ReplacementFor_headers.emplace(
"\x48\x6f\x73\x74",ReplacementFor_host_);}else{ReplacementFor_req.
ReplacementFor_headers.emplace("\x48\x6f\x73\x74",ReplacementFor_host_and_port_)
;}}else{if(ReplacementFor_port_==(0x39a+4447-0x14a9)){ReplacementFor_req.
ReplacementFor_headers.emplace("\x48\x6f\x73\x74",ReplacementFor_host_);}else{
ReplacementFor_req.ReplacementFor_headers.emplace("\x48\x6f\x73\x74",
ReplacementFor_host_and_port_);}}}if(!ReplacementFor_req.
ReplacementFor_has_header("\x41\x63\x63\x65\x70\x74")){ReplacementFor_req.
ReplacementFor_headers.emplace("\x41\x63\x63\x65\x70\x74","\x2a\x2f\x2a");}if(!
ReplacementFor_req.ReplacementFor_has_header(
"\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74")){ReplacementFor_req.
ReplacementFor_headers.emplace("\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74",
"\x63\x70\x70\x2d\x68\x74\x74\x70\x6c\x69\x62\x2f\x30\x2e\x37");}if(
ReplacementFor_req.ReplacementFor_body.empty()){if(ReplacementFor_req.
ReplacementFor_content_provider_){if(!ReplacementFor_req.
ReplacementFor_is_chunked_content_provider_){auto length=std::to_string(
ReplacementFor_req.ReplacementFor_content_length_);ReplacementFor_req.
ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}else{if(
ReplacementFor_req.ReplacementFor_method=="\x50\x4f\x53\x54"||ReplacementFor_req
.ReplacementFor_method=="\x50\x55\x54"||ReplacementFor_req.ReplacementFor_method
=="\x50\x41\x54\x43\x48"){ReplacementFor_req.ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68","\x30");}}}else{if(!
ReplacementFor_req.ReplacementFor_has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65")){ReplacementFor_req.
ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e");}if(!ReplacementFor_req.
ReplacementFor_has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){auto length=std::
to_string(ReplacementFor_req.ReplacementFor_body.size());ReplacementFor_req.
ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}if(!
ReplacementFor_basic_auth_password_.empty()){ReplacementFor_req.
ReplacementFor_headers.insert(ReplacementFor_make_basic_authentication_header(
ReplacementFor_basic_auth_username_,ReplacementFor_basic_auth_password_,false));
}if(!ReplacementFor_proxy_basic_auth_username_.empty()&&!
ReplacementFor_proxy_basic_auth_password_.empty()){ReplacementFor_req.
ReplacementFor_headers.insert(ReplacementFor_make_basic_authentication_header(
ReplacementFor_proxy_basic_auth_username_,
ReplacementFor_proxy_basic_auth_password_,true));}if(!
ReplacementFor_bearer_token_auth_token_.empty()){ReplacementFor_req.
ReplacementFor_headers.insert(
ReplacementFor_make_bearer_token_authentication_header(
ReplacementFor_bearer_token_auth_token_,false));}if(!
ReplacementFor_proxy_bearer_token_auth_token_.empty()){ReplacementFor_req.
ReplacementFor_headers.insert(
ReplacementFor_make_bearer_token_authentication_header(
ReplacementFor_proxy_bearer_token_auth_token_,true));}{ReplacementFor_detail::
ReplacementFor_BufferStream ReplacementFor_bstrm;const auto&ReplacementFor_path=
ReplacementFor_detail::ReplacementFor_encode_url(ReplacementFor_req.
ReplacementFor_path);ReplacementFor_bstrm.ReplacementFor_write_format(
"\x25\x73\x20\x25\x73\x20\x48\x54\x54\x50\x2f\x31\x2e\x31" "\r\n",
ReplacementFor_req.ReplacementFor_method.c_str(),ReplacementFor_path.c_str());
ReplacementFor_detail::ReplacementFor_write_headers(ReplacementFor_bstrm,
ReplacementFor_req.ReplacementFor_headers);auto&data=ReplacementFor_bstrm.
ReplacementFor_get_buffer();if(!ReplacementFor_detail::ReplacementFor_write_data
(ReplacementFor_strm,data.data(),data.size())){error=Error::Write;return false;}
}if(ReplacementFor_req.ReplacementFor_body.empty()){return 
ReplacementFor_write_content_with_provider(ReplacementFor_strm,
ReplacementFor_req,error);}else{return ReplacementFor_detail::
ReplacementFor_write_data(ReplacementFor_strm,ReplacementFor_req.
ReplacementFor_body.data(),ReplacementFor_req.ReplacementFor_body.size());}
return true;}std::unique_ptr<ReplacementFor_Response>ReplacementFor_ClientImpl::
ReplacementFor_send_with_content_provider(ReplacementFor_Request&
ReplacementFor_req,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider_without_length,const char*
ReplacementFor_content_type,Error&error){if(ReplacementFor_content_type){
ReplacementFor_req.ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
}
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
if(ReplacementFor_compress_){ReplacementFor_req.ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x67\x7a\x69\x70");}
#endif
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
if(ReplacementFor_compress_&&!ReplacementFor_content_provider_without_length){
ReplacementFor_detail::ReplacementFor_gzip_compressor ReplacementFor_compressor;
if(ReplacementFor_content_provider){auto ok=true;size_t offset=
(0x1e4f+533-0x2064);ReplacementFor_DataSink ReplacementFor_data_sink;
ReplacementFor_data_sink.write=[&](const char*data,size_t 
ReplacementFor_data_len){if(ok){auto ReplacementFor_last=offset+
ReplacementFor_data_len==ReplacementFor_content_length;auto ReplacementFor_ret=
ReplacementFor_compressor.compress(data,ReplacementFor_data_len,
ReplacementFor_last,[&](const char*data,size_t ReplacementFor_data_len){
ReplacementFor_req.ReplacementFor_body.append(data,ReplacementFor_data_len);
return true;});if(ReplacementFor_ret){offset+=ReplacementFor_data_len;}else{ok=
false;}}};ReplacementFor_data_sink.ReplacementFor_is_writable=[&](void){return 
ok&&true;};while(ok&&offset<ReplacementFor_content_length){if(!
ReplacementFor_content_provider(offset,ReplacementFor_content_length-offset,
ReplacementFor_data_sink)){error=Error::ReplacementFor_Canceled;return nullptr;}
}}else{if(!ReplacementFor_compressor.compress(ReplacementFor_body,
ReplacementFor_content_length,true,[&](const char*data,size_t 
ReplacementFor_data_len){ReplacementFor_req.ReplacementFor_body.append(data,
ReplacementFor_data_len);return true;})){error=Error::Compression;return nullptr
;}}}else
#endif
{if(ReplacementFor_content_provider){ReplacementFor_req.
ReplacementFor_content_length_=ReplacementFor_content_length;ReplacementFor_req.
ReplacementFor_content_provider_=std::move(ReplacementFor_content_provider);
ReplacementFor_req.ReplacementFor_is_chunked_content_provider_=false;}else if(
ReplacementFor_content_provider_without_length){ReplacementFor_req.
ReplacementFor_content_length_=(0x18f1+679-0x1b98);ReplacementFor_req.
ReplacementFor_content_provider_=ReplacementFor_detail::
ReplacementFor_ContentProviderAdapter(std::move(
ReplacementFor_content_provider_without_length));ReplacementFor_req.
ReplacementFor_is_chunked_content_provider_=true;ReplacementFor_req.
ReplacementFor_headers.emplace(
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x63\x68\x75\x6e\x6b\x65\x64");}else{ReplacementFor_req.ReplacementFor_body.
assign(ReplacementFor_body,ReplacementFor_content_length);;}}auto 
ReplacementFor_res=ReplacementFor_detail::make_unique<ReplacementFor_Response>()
;return send(ReplacementFor_req,*ReplacementFor_res,error)?std::move(
ReplacementFor_res):nullptr;}Result ReplacementFor_ClientImpl::
ReplacementFor_send_with_content_provider(const char*ReplacementFor_method,const
 char*ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
const char*ReplacementFor_body,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,
ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider_without_length,const char*
ReplacementFor_content_type){ReplacementFor_Request ReplacementFor_req;
ReplacementFor_req.ReplacementFor_method=ReplacementFor_method;
ReplacementFor_req.ReplacementFor_headers=ReplacementFor_headers;
ReplacementFor_req.ReplacementFor_path=ReplacementFor_path;auto error=Error::
ReplacementFor_Success;auto ReplacementFor_res=
ReplacementFor_send_with_content_provider(ReplacementFor_req,ReplacementFor_body
,ReplacementFor_content_length,std::move(ReplacementFor_content_provider),std::
move(ReplacementFor_content_provider_without_length),ReplacementFor_content_type
,error);return Result{std::move(ReplacementFor_res),error,std::move(
ReplacementFor_req.ReplacementFor_headers)};}bool ReplacementFor_ClientImpl::
ReplacementFor_process_request(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,bool ReplacementFor_close_connection,Error&error){if(!
ReplacementFor_write_request(ReplacementFor_strm,ReplacementFor_req,
ReplacementFor_close_connection,error)){return false;}if(!
ReplacementFor_read_response_line(ReplacementFor_strm,ReplacementFor_req,
ReplacementFor_res)||!ReplacementFor_detail::ReplacementFor_read_headers(
ReplacementFor_strm,ReplacementFor_res.ReplacementFor_headers)){error=Error::
Read;return false;}if(ReplacementFor_req.ReplacementFor_response_handler){if(!
ReplacementFor_req.ReplacementFor_response_handler(ReplacementFor_res)){error=
Error::ReplacementFor_Canceled;return false;}}if((ReplacementFor_res.status!=
(0x1df2+181-0x1ddb))&&ReplacementFor_req.ReplacementFor_method!=
"\x48\x45\x41\x44"&&ReplacementFor_req.ReplacementFor_method!=
"\x43\x4f\x4e\x4e\x45\x43\x54"){auto out=ReplacementFor_req.
ReplacementFor_content_receiver?static_cast<
ReplacementFor_ContentReceiverWithProgress>([&](const char*buf,size_t n,uint64_t
 ReplacementFor_off,uint64_t len){auto ReplacementFor_ret=ReplacementFor_req.
ReplacementFor_content_receiver(buf,n,ReplacementFor_off,len);if(!
ReplacementFor_ret){error=Error::ReplacementFor_Canceled;}return 
ReplacementFor_ret;}):static_cast<ReplacementFor_ContentReceiverWithProgress>([&
](const char*buf,size_t n,uint64_t,uint64_t){if(ReplacementFor_res.
ReplacementFor_body.size()+n>ReplacementFor_res.ReplacementFor_body.max_size()){
return false;}ReplacementFor_res.ReplacementFor_body.append(buf,n);return true;}
);auto ReplacementFor_progress=[&](uint64_t current,uint64_t 
ReplacementFor_total){if(!ReplacementFor_req.ReplacementFor_progress){return 
true;}auto ReplacementFor_ret=ReplacementFor_req.ReplacementFor_progress(current
,ReplacementFor_total);if(!ReplacementFor_ret){error=Error::
ReplacementFor_Canceled;}return ReplacementFor_ret;};int 
ReplacementFor_dummy_status;if(!ReplacementFor_detail::
ReplacementFor_read_content(ReplacementFor_strm,ReplacementFor_res,(std::
numeric_limits<size_t>::max)(),ReplacementFor_dummy_status,std::move(
ReplacementFor_progress),std::move(out),ReplacementFor_decompress_)){if(error!=
Error::ReplacementFor_Canceled){error=Error::Read;}return false;}}if(
ReplacementFor_res.ReplacementFor_get_header_value(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")=="\x63\x6c\x6f\x73\x65"||(
ReplacementFor_res.ReplacementFor_version=="\x48\x54\x54\x50\x2f\x31\x2e\x30"&&
ReplacementFor_res.ReplacementFor_reason!=
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x65\x73\x74\x61\x62\x6c\x69\x73\x68\x65\x64"
)){ReplacementFor_lock_socket_and_shutdown_and_close();}if(
ReplacementFor_logger_){ReplacementFor_logger_(ReplacementFor_req,
ReplacementFor_res);}return true;}bool ReplacementFor_ClientImpl::
ReplacementFor_process_socket(const Socket&socket,std::function<bool(
ReplacementFor_Stream&ReplacementFor_strm)>ReplacementFor_callback){return 
ReplacementFor_detail::ReplacementFor_process_client_socket(socket.
ReplacementFor_sock,ReplacementFor_read_timeout_sec_,
ReplacementFor_read_timeout_usec_,ReplacementFor_write_timeout_sec_,
ReplacementFor_write_timeout_usec_,std::move(ReplacementFor_callback));}bool 
ReplacementFor_ClientImpl::ReplacementFor_is_ssl()const{return false;}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path){return Get(
ReplacementFor_path,ReplacementFor_Headers(),ReplacementFor_Progress());}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,
ReplacementFor_Progress ReplacementFor_progress){return Get(ReplacementFor_path,
ReplacementFor_Headers(),std::move(ReplacementFor_progress));}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers){return Get(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_Progress());}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_Progress 
ReplacementFor_progress){ReplacementFor_Request ReplacementFor_req;
ReplacementFor_req.ReplacementFor_method="\x47\x45\x54";ReplacementFor_req.
ReplacementFor_path=ReplacementFor_path;ReplacementFor_req.
ReplacementFor_headers=ReplacementFor_headers;ReplacementFor_req.
ReplacementFor_progress=std::move(ReplacementFor_progress);return 
ReplacementFor_send_(std::move(ReplacementFor_req));}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver){return Get(
ReplacementFor_path,ReplacementFor_Headers(),nullptr,std::move(
ReplacementFor_content_receiver),nullptr);}Result ReplacementFor_ClientImpl::Get
(const char*ReplacementFor_path,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return Get(ReplacementFor_path,ReplacementFor_Headers(),nullptr,std::move(
ReplacementFor_content_receiver),std::move(ReplacementFor_progress));}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver){return Get(ReplacementFor_path,
ReplacementFor_headers,nullptr,std::move(ReplacementFor_content_receiver),
nullptr);}Result ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress){return Get(ReplacementFor_path,
ReplacementFor_headers,nullptr,std::move(ReplacementFor_content_receiver),std::
move(ReplacementFor_progress));}Result ReplacementFor_ClientImpl::Get(const char
*ReplacementFor_path,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver){return Get(ReplacementFor_path,
ReplacementFor_Headers(),std::move(ReplacementFor_response_handler),std::move(
ReplacementFor_content_receiver),nullptr);}Result ReplacementFor_ClientImpl::Get
(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver){return Get(ReplacementFor_path,
ReplacementFor_headers,std::move(ReplacementFor_response_handler),std::move(
ReplacementFor_content_receiver),nullptr);}Result ReplacementFor_ClientImpl::Get
(const char*ReplacementFor_path,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return Get(ReplacementFor_path,ReplacementFor_Headers(),std::move(
ReplacementFor_response_handler),std::move(ReplacementFor_content_receiver),std
::move(ReplacementFor_progress));}Result ReplacementFor_ClientImpl::Get(const 
char*ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ResponseHandler ReplacementFor_response_handler,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress){ReplacementFor_Request 
ReplacementFor_req;ReplacementFor_req.ReplacementFor_method="\x47\x45\x54";
ReplacementFor_req.ReplacementFor_path=ReplacementFor_path;ReplacementFor_req.
ReplacementFor_headers=ReplacementFor_headers;ReplacementFor_req.
ReplacementFor_response_handler=std::move(ReplacementFor_response_handler);
ReplacementFor_req.ReplacementFor_content_receiver=[
ReplacementFor_content_receiver](const char*data,size_t 
ReplacementFor_data_length,uint64_t,uint64_t){return 
ReplacementFor_content_receiver(data,ReplacementFor_data_length);};
ReplacementFor_req.ReplacementFor_progress=std::move(ReplacementFor_progress);
return ReplacementFor_send_(std::move(ReplacementFor_req));}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_Progress ReplacementFor_progress){if(
ReplacementFor_params.empty()){return Get(ReplacementFor_path,
ReplacementFor_headers);}std::string ReplacementFor_path_with_query=
ReplacementFor_detail::ReplacementFor_append_query_params(ReplacementFor_path,
ReplacementFor_params);return Get(ReplacementFor_path_with_query.c_str(),
ReplacementFor_headers,ReplacementFor_progress);}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return Get(ReplacementFor_path,ReplacementFor_params,ReplacementFor_headers,
nullptr,ReplacementFor_content_receiver,ReplacementFor_progress);}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{if(ReplacementFor_params.empty()){return Get(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_response_handler,
ReplacementFor_content_receiver,ReplacementFor_progress);}std::string 
ReplacementFor_path_with_query=ReplacementFor_detail::
ReplacementFor_append_query_params(ReplacementFor_path,ReplacementFor_params);
return Get(ReplacementFor_path_with_query.c_str(),ReplacementFor_params,
ReplacementFor_headers,ReplacementFor_response_handler,
ReplacementFor_content_receiver,ReplacementFor_progress);}Result 
ReplacementFor_ClientImpl::Head(const char*ReplacementFor_path){return Head(
ReplacementFor_path,ReplacementFor_Headers());}Result ReplacementFor_ClientImpl
::Head(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers){ReplacementFor_Request ReplacementFor_req;
ReplacementFor_req.ReplacementFor_method="\x48\x45\x41\x44";ReplacementFor_req.
ReplacementFor_headers=ReplacementFor_headers;ReplacementFor_req.
ReplacementFor_path=ReplacementFor_path;return ReplacementFor_send_(std::move(
ReplacementFor_req));}Result ReplacementFor_ClientImpl::ReplacementFor_Post(
const char*ReplacementFor_path){return ReplacementFor_Post(ReplacementFor_path,
std::string(),nullptr);}Result ReplacementFor_ClientImpl::ReplacementFor_Post(
const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_body,ReplacementFor_content_length,ReplacementFor_content_type);}
Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
char*ReplacementFor_body,size_t ReplacementFor_content_length,const char*
ReplacementFor_content_type){return ReplacementFor_send_with_content_provider(
"\x50\x4f\x53\x54",ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_length,nullptr,nullptr,
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
ReplacementFor_Post(const char*ReplacementFor_path,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_body,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Post(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x4f\x53\x54",ReplacementFor_path
,ReplacementFor_headers,ReplacementFor_body.data(),ReplacementFor_body.size(),
nullptr,nullptr,ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Params&
ReplacementFor_params){return ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_Headers(),ReplacementFor_params);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Post(const char*ReplacementFor_path,
size_t ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_content_length,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
ReplacementFor_Post(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_Post(
ReplacementFor_path,ReplacementFor_Headers(),std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Post(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x4f\x53\x54",ReplacementFor_path
,ReplacementFor_headers,nullptr,ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),nullptr,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Post(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x4f\x53\x54",ReplacementFor_path
,ReplacementFor_headers,nullptr,(0x77c+915-0xb0f),nullptr,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Post(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,const ReplacementFor_Params&
ReplacementFor_params){auto ReplacementFor_query=ReplacementFor_detail::
ReplacementFor_params_to_query_str(ReplacementFor_params);return 
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_query,
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
);}Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char*
ReplacementFor_path,const ReplacementFor_MultipartFormDataItems&
ReplacementFor_items){return ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_Headers(),ReplacementFor_items);}Result ReplacementFor_ClientImpl
::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const 
ReplacementFor_MultipartFormDataItems&ReplacementFor_items){return 
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_items,ReplacementFor_detail::
ReplacementFor_make_multipart_data_boundary());}Result ReplacementFor_ClientImpl
::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const 
ReplacementFor_MultipartFormDataItems&ReplacementFor_items,const std::string&
ReplacementFor_boundary){for(size_t i=(0x15e3+3748-0x2487);i<
ReplacementFor_boundary.size();i++){char c=ReplacementFor_boundary[i];if(!std::
isalnum(c)&&c!=((char)(0x7bc+1645-0xdfc))&&c!=((char)(0x364+6811-0x1da0))){
return Result{nullptr,Error::ReplacementFor_UnsupportedMultipartBoundaryChars};}
}std::string ReplacementFor_body;for(const auto&item:ReplacementFor_items){
ReplacementFor_body+="\x2d\x2d"+ReplacementFor_boundary+"\r\n";
ReplacementFor_body+=
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x44\x69\x73\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x20\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b\x20\x6e\x61\x6d\x65\x3d" "\""
+item.name+"\"";if(!item.ReplacementFor_filename.empty()){ReplacementFor_body+=
"\x3b\x20\x66\x69\x6c\x65\x6e\x61\x6d\x65\x3d" "\""+item.ReplacementFor_filename
+"\"";}ReplacementFor_body+="\r\n";if(!item.ReplacementFor_content_type.empty())
{ReplacementFor_body+="\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20"
+item.ReplacementFor_content_type+"\r\n";}ReplacementFor_body+="\r\n";
ReplacementFor_body+=item.ReplacementFor_content+"\r\n";}ReplacementFor_body+=
"\x2d\x2d"+ReplacementFor_boundary+"\x2d\x2d" "\r\n";std::string 
ReplacementFor_content_type=
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b\x20\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d"
+ReplacementFor_boundary;return ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_body,ReplacementFor_content_type.c_str());
}Result ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path){return 
Put(ReplacementFor_path,std::string(),nullptr);}Result ReplacementFor_ClientImpl
::Put(const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return Put
(ReplacementFor_path,ReplacementFor_Headers(),ReplacementFor_body,
ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const char*ReplacementFor_body,
size_t ReplacementFor_content_length,const char*ReplacementFor_content_type){
return ReplacementFor_send_with_content_provider("\x50\x55\x54",
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_body,
ReplacementFor_content_length,nullptr,nullptr,ReplacementFor_content_type);}
Result ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,const std::
string&ReplacementFor_body,const char*ReplacementFor_content_type){return Put(
ReplacementFor_path,ReplacementFor_Headers(),ReplacementFor_body,
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::Put(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
std::string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x55\x54",ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_body.data(),ReplacementFor_body.size(),
nullptr,nullptr,ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
Put(const char*ReplacementFor_path,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type){return Put(ReplacementFor_path,
ReplacementFor_Headers(),ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return Put(ReplacementFor_path,
ReplacementFor_Headers(),std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::Put(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x55\x54",ReplacementFor_path,
ReplacementFor_headers,nullptr,ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),nullptr,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x55\x54",ReplacementFor_path,
ReplacementFor_headers,nullptr,(0x691+7275-0x22fc),nullptr,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params){return Put(ReplacementFor_path,
ReplacementFor_Headers(),ReplacementFor_params);}Result 
ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const ReplacementFor_Params&
ReplacementFor_params){auto ReplacementFor_query=ReplacementFor_detail::
ReplacementFor_params_to_query_str(ReplacementFor_params);return Put(
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_query,
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
);}Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*
ReplacementFor_path){return ReplacementFor_Patch(ReplacementFor_path,std::string
(),nullptr);}Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*
ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_Patch(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_body,ReplacementFor_content_length,ReplacementFor_content_type);}
Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
char*ReplacementFor_body,size_t ReplacementFor_content_length,const char*
ReplacementFor_content_type){return ReplacementFor_send_with_content_provider(
"\x50\x41\x54\x43\x48",ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_length,nullptr,nullptr,
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
ReplacementFor_Patch(const char*ReplacementFor_path,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_Patch(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_body,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x41\x54\x43\x48",
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_body.data(),
ReplacementFor_body.size(),nullptr,nullptr,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*ReplacementFor_path,
size_t ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_Patch(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_content_length,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
ReplacementFor_Patch(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_Patch(
ReplacementFor_path,ReplacementFor_Headers(),std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x41\x54\x43\x48",
ReplacementFor_path,ReplacementFor_headers,nullptr,ReplacementFor_content_length
,std::move(ReplacementFor_content_provider),nullptr,ReplacementFor_content_type)
;}Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x41\x54\x43\x48",
ReplacementFor_path,ReplacementFor_headers,nullptr,(0x1242+444-0x13fe),nullptr,
std::move(ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Delete(const char*ReplacementFor_path){return Delete(
ReplacementFor_path,ReplacementFor_Headers(),std::string(),nullptr);}Result 
ReplacementFor_ClientImpl::Delete(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers){return Delete(ReplacementFor_path
,ReplacementFor_headers,std::string(),nullptr);}Result ReplacementFor_ClientImpl
::Delete(const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
Delete(ReplacementFor_path,ReplacementFor_Headers(),ReplacementFor_body,
ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Delete(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const char*ReplacementFor_body,
size_t ReplacementFor_content_length,const char*ReplacementFor_content_type){
ReplacementFor_Request ReplacementFor_req;ReplacementFor_req.
ReplacementFor_method="\x44\x45\x4c\x45\x54\x45";ReplacementFor_req.
ReplacementFor_headers=ReplacementFor_headers;ReplacementFor_req.
ReplacementFor_path=ReplacementFor_path;if(ReplacementFor_content_type){
ReplacementFor_req.ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
}ReplacementFor_req.ReplacementFor_body.assign(ReplacementFor_body,
ReplacementFor_content_length);return ReplacementFor_send_(std::move(
ReplacementFor_req));}Result ReplacementFor_ClientImpl::Delete(const char*
ReplacementFor_path,const std::string&ReplacementFor_body,const char*
ReplacementFor_content_type){return Delete(ReplacementFor_path,
ReplacementFor_Headers(),ReplacementFor_body.data(),ReplacementFor_body.size(),
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::Delete(const 
char*ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
const std::string&ReplacementFor_body,const char*ReplacementFor_content_type){
return Delete(ReplacementFor_path,ReplacementFor_headers,ReplacementFor_body.
data(),ReplacementFor_body.size(),ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Options(const char*ReplacementFor_path){return 
Options(ReplacementFor_path,ReplacementFor_Headers());}Result 
ReplacementFor_ClientImpl::Options(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers){ReplacementFor_Request 
ReplacementFor_req;ReplacementFor_req.ReplacementFor_method=
"\x4f\x50\x54\x49\x4f\x4e\x53";ReplacementFor_req.ReplacementFor_headers=
ReplacementFor_headers;ReplacementFor_req.ReplacementFor_path=
ReplacementFor_path;return ReplacementFor_send_(std::move(ReplacementFor_req));}
size_t ReplacementFor_ClientImpl::ReplacementFor_is_socket_open()const{std::
lock_guard<std::mutex>ReplacementFor_guard(ReplacementFor_socket_mutex_);return 
ReplacementFor_socket_.is_open();}void ReplacementFor_ClientImpl::
ReplacementFor_stop(){std::lock_guard<std::mutex>ReplacementFor_guard(
ReplacementFor_socket_mutex_);if(ReplacementFor_socket_requests_in_flight_>
(0x1c81+574-0x1ebf)){ReplacementFor_shutdown_socket(ReplacementFor_socket_);
ReplacementFor_socket_should_be_closed_when_request_is_done_=true;return;}
ReplacementFor_shutdown_ssl(ReplacementFor_socket_,true);
ReplacementFor_shutdown_socket(ReplacementFor_socket_);
ReplacementFor_close_socket(ReplacementFor_socket_);}void 
ReplacementFor_ClientImpl::ReplacementFor_set_connection_timeout(time_t sec,
time_t ReplacementFor_usec){ReplacementFor_connection_timeout_sec_=sec;
ReplacementFor_connection_timeout_usec_=ReplacementFor_usec;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_read_timeout(time_t sec,time_t 
ReplacementFor_usec){ReplacementFor_read_timeout_sec_=sec;
ReplacementFor_read_timeout_usec_=ReplacementFor_usec;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_write_timeout(time_t sec,time_t 
ReplacementFor_usec){ReplacementFor_write_timeout_sec_=sec;
ReplacementFor_write_timeout_usec_=ReplacementFor_usec;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_basic_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){
ReplacementFor_basic_auth_username_=ReplacementFor_username;
ReplacementFor_basic_auth_password_=ReplacementFor_password;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_bearer_token_auth(const char*
ReplacementFor_token){ReplacementFor_bearer_token_auth_token_=
ReplacementFor_token;}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_ClientImpl::ReplacementFor_set_digest_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){
ReplacementFor_digest_auth_username_=ReplacementFor_username;
ReplacementFor_digest_auth_password_=ReplacementFor_password;}
#endif
void ReplacementFor_ClientImpl::ReplacementFor_set_keep_alive(bool 
ReplacementFor_on){ReplacementFor_keep_alive_=ReplacementFor_on;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_follow_location(bool 
ReplacementFor_on){ReplacementFor_follow_location_=ReplacementFor_on;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_default_headers(
ReplacementFor_Headers ReplacementFor_headers){ReplacementFor_default_headers_=
std::move(ReplacementFor_headers);}void ReplacementFor_ClientImpl::
ReplacementFor_set_tcp_nodelay(bool ReplacementFor_on){
ReplacementFor_tcp_nodelay_=ReplacementFor_on;}void ReplacementFor_ClientImpl::
ReplacementFor_set_socket_options(ReplacementFor_SocketOptions 
ReplacementFor_socket_options){ReplacementFor_socket_options_=std::move(
ReplacementFor_socket_options);}void ReplacementFor_ClientImpl::
ReplacementFor_set_compress(bool ReplacementFor_on){ReplacementFor_compress_=
ReplacementFor_on;}void ReplacementFor_ClientImpl::ReplacementFor_set_decompress
(bool ReplacementFor_on){ReplacementFor_decompress_=ReplacementFor_on;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_interface(const char*intf){
ReplacementFor_interface_=intf;}void ReplacementFor_ClientImpl::
ReplacementFor_set_proxy(const char*ReplacementFor_host,int ReplacementFor_port)
{ReplacementFor_proxy_host_=ReplacementFor_host;ReplacementFor_proxy_port_=
ReplacementFor_port;}void ReplacementFor_ClientImpl::
ReplacementFor_set_proxy_basic_auth(const char*ReplacementFor_username,const 
char*ReplacementFor_password){ReplacementFor_proxy_basic_auth_username_=
ReplacementFor_username;ReplacementFor_proxy_basic_auth_password_=
ReplacementFor_password;}void ReplacementFor_ClientImpl::
ReplacementFor_set_proxy_bearer_token_auth(const char*ReplacementFor_token){
ReplacementFor_proxy_bearer_token_auth_token_=ReplacementFor_token;}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_ClientImpl::ReplacementFor_set_proxy_digest_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){
ReplacementFor_proxy_digest_auth_username_=ReplacementFor_username;
ReplacementFor_proxy_digest_auth_password_=ReplacementFor_password;}
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_ClientImpl::
ReplacementFor_enable_server_certificate_verification(bool 
ReplacementFor_enabled){ReplacementFor_server_certificate_verification_=
ReplacementFor_enabled;}
#endif
void ReplacementFor_ClientImpl::ReplacementFor_set_logger(ReplacementFor_Logger 
ReplacementFor_logger){ReplacementFor_logger_=std::move(ReplacementFor_logger);}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
namespace ReplacementFor_detail{template<typename U,typename ReplacementFor_V>
ReplacementFor_SSL*ReplacementFor_ssl_new(ReplacementFor_socket_t 
ReplacementFor_sock,ReplacementFor_SSL_CTX*ctx,std::mutex&
ReplacementFor_ctx_mutex,U ReplacementFor_SSL_connect_or_accept,ReplacementFor_V
 ReplacementFor_setup){ReplacementFor_SSL*ReplacementFor_ssl=nullptr;{std::
lock_guard<std::mutex>ReplacementFor_guard(ReplacementFor_ctx_mutex);
ReplacementFor_ssl=ReplacementFor_SSL_new(ctx);}if(ReplacementFor_ssl){
ReplacementFor_set_nonblocking(ReplacementFor_sock,true);auto ReplacementFor_bio
=ReplacementFor_BIO_new_socket(static_cast<int>(ReplacementFor_sock),
ReplacementFor_BIO_NOCLOSE);ReplacementFor_BIO_set_nbio(ReplacementFor_bio,
(0x219a+265-0x22a2));ReplacementFor_SSL_set_bio(ReplacementFor_ssl,
ReplacementFor_bio,ReplacementFor_bio);if(!ReplacementFor_setup(
ReplacementFor_ssl)||ReplacementFor_SSL_connect_or_accept(ReplacementFor_ssl)!=
(0xe1c+196-0xedf)){ReplacementFor_SSL_shutdown(ReplacementFor_ssl);{std::
lock_guard<std::mutex>ReplacementFor_guard(ReplacementFor_ctx_mutex);
ReplacementFor_SSL_free(ReplacementFor_ssl);}ReplacementFor_set_nonblocking(
ReplacementFor_sock,false);return nullptr;}ReplacementFor_BIO_set_nbio(
ReplacementFor_bio,(0x1bd5+1823-0x22f4));ReplacementFor_set_nonblocking(
ReplacementFor_sock,false);}return ReplacementFor_ssl;}void 
ReplacementFor_ssl_delete(std::mutex&ReplacementFor_ctx_mutex,ReplacementFor_SSL
*ReplacementFor_ssl,bool ReplacementFor_shutdown_gracefully){if(
ReplacementFor_shutdown_gracefully){ReplacementFor_SSL_shutdown(
ReplacementFor_ssl);}std::lock_guard<std::mutex>ReplacementFor_guard(
ReplacementFor_ctx_mutex);ReplacementFor_SSL_free(ReplacementFor_ssl);}template<
typename U>bool ReplacementFor_ssl_connect_or_accept_nonblocking(
ReplacementFor_socket_t ReplacementFor_sock,ReplacementFor_SSL*
ReplacementFor_ssl,U ReplacementFor_ssl_connect_or_accept,time_t 
ReplacementFor_timeout_sec,time_t ReplacementFor_timeout_usec){int 
ReplacementFor_res=(0x10d6+93-0x1133);while((ReplacementFor_res=
ReplacementFor_ssl_connect_or_accept(ReplacementFor_ssl))!=(0xb40+3892-0x1a73)){
auto err=ReplacementFor_SSL_get_error(ReplacementFor_ssl,ReplacementFor_res);
switch(err){case ReplacementFor_SSL_ERROR_WANT_READ:if(
ReplacementFor_select_read(ReplacementFor_sock,ReplacementFor_timeout_sec,
ReplacementFor_timeout_usec)>(0x18b2+1574-0x1ed8)){continue;}break;case 
ReplacementFor_SSL_ERROR_WANT_WRITE:if(ReplacementFor_select_write(
ReplacementFor_sock,ReplacementFor_timeout_sec,ReplacementFor_timeout_usec)>
(0xa+3926-0xf60)){continue;}break;default:break;}return false;}return true;}
template<typename T>bool ReplacementFor_process_server_socket_ssl(
ReplacementFor_SSL*ReplacementFor_ssl,ReplacementFor_socket_t 
ReplacementFor_sock,size_t ReplacementFor_keep_alive_max_count,time_t 
ReplacementFor_keep_alive_timeout_sec,time_t ReplacementFor_read_timeout_sec,
time_t ReplacementFor_read_timeout_usec,time_t ReplacementFor_write_timeout_sec,
time_t ReplacementFor_write_timeout_usec,T ReplacementFor_callback){return 
ReplacementFor_process_server_socket_core(ReplacementFor_sock,
ReplacementFor_keep_alive_max_count,ReplacementFor_keep_alive_timeout_sec,[&](
bool ReplacementFor_close_connection,bool&ReplacementFor_connection_closed){
ReplacementFor_SSLSocketStream ReplacementFor_strm(ReplacementFor_sock,
ReplacementFor_ssl,ReplacementFor_read_timeout_sec,
ReplacementFor_read_timeout_usec,ReplacementFor_write_timeout_sec,
ReplacementFor_write_timeout_usec);return ReplacementFor_callback(
ReplacementFor_strm,ReplacementFor_close_connection,
ReplacementFor_connection_closed);});}template<typename T>bool 
ReplacementFor_process_client_socket_ssl(ReplacementFor_SSL*ReplacementFor_ssl,
ReplacementFor_socket_t ReplacementFor_sock,time_t 
ReplacementFor_read_timeout_sec,time_t ReplacementFor_read_timeout_usec,time_t 
ReplacementFor_write_timeout_sec,time_t ReplacementFor_write_timeout_usec,T 
ReplacementFor_callback){ReplacementFor_SSLSocketStream ReplacementFor_strm(
ReplacementFor_sock,ReplacementFor_ssl,ReplacementFor_read_timeout_sec,
ReplacementFor_read_timeout_usec,ReplacementFor_write_timeout_sec,
ReplacementFor_write_timeout_usec);return ReplacementFor_callback(
ReplacementFor_strm);}
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x10100000L
static std::shared_ptr<std::vector<std::mutex>>ReplacementFor_openSSL_locks_;
class ReplacementFor_SSLThreadLocks{public:ReplacementFor_SSLThreadLocks(){
ReplacementFor_openSSL_locks_=std::make_shared<std::vector<std::mutex>>(
ReplacementFor_CRYPTO_num_locks());ReplacementFor_CRYPTO_set_locking_callback(
ReplacementFor_locking_callback);}~ReplacementFor_SSLThreadLocks(){
ReplacementFor_CRYPTO_set_locking_callback(nullptr);}private:static void 
ReplacementFor_locking_callback(int ReplacementFor_mode,int type,const char*,int
){auto&ReplacementFor_lk=(*ReplacementFor_openSSL_locks_)[static_cast<size_t>(
type)];if(ReplacementFor_mode&ReplacementFor_CRYPTO_LOCK){ReplacementFor_lk.lock
();}else{ReplacementFor_lk.unlock();}}};
#endif
class ReplacementFor_SSLInit{public:ReplacementFor_SSLInit(){
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x1010001fL
ReplacementFor_SSL_load_error_strings();ReplacementFor_SSL_library_init();
#else
ReplacementFor_OPENSSL_init_ssl(ReplacementFor_OPENSSL_INIT_LOAD_SSL_STRINGS|
ReplacementFor_OPENSSL_INIT_LOAD_CRYPTO_STRINGS,NULL);
#endif
}~ReplacementFor_SSLInit(){
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x1010001fL
ReplacementFor_ERR_free_strings();
#endif
}private:
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x10100000L
ReplacementFor_SSLThreadLocks ReplacementFor_thread_init_;
#endif
};ReplacementFor_SSLSocketStream::ReplacementFor_SSLSocketStream(
ReplacementFor_socket_t ReplacementFor_sock,ReplacementFor_SSL*
ReplacementFor_ssl,time_t ReplacementFor_read_timeout_sec,time_t 
ReplacementFor_read_timeout_usec,time_t ReplacementFor_write_timeout_sec,time_t 
ReplacementFor_write_timeout_usec):ReplacementFor_sock_(ReplacementFor_sock),
ReplacementFor_ssl_(ReplacementFor_ssl),ReplacementFor_read_timeout_sec_(
ReplacementFor_read_timeout_sec),ReplacementFor_read_timeout_usec_(
ReplacementFor_read_timeout_usec),ReplacementFor_write_timeout_sec_(
ReplacementFor_write_timeout_sec),ReplacementFor_write_timeout_usec_(
ReplacementFor_write_timeout_usec){ReplacementFor_SSL_clear_mode(
ReplacementFor_ssl,ReplacementFor_SSL_MODE_AUTO_RETRY);}
ReplacementFor_SSLSocketStream::~ReplacementFor_SSLSocketStream(){}bool 
ReplacementFor_SSLSocketStream::ReplacementFor_is_readable()const{return 
ReplacementFor_detail::ReplacementFor_select_read(ReplacementFor_sock_,
ReplacementFor_read_timeout_sec_,ReplacementFor_read_timeout_usec_)>
(0xa5f+3872-0x197f);}bool ReplacementFor_SSLSocketStream::
ReplacementFor_is_writable()const{return ReplacementFor_detail::
ReplacementFor_select_write(ReplacementFor_sock_,
ReplacementFor_write_timeout_sec_,ReplacementFor_write_timeout_usec_)>
(0x44f+5445-0x1994);}ssize_t ReplacementFor_SSLSocketStream::read(char*
ReplacementFor_ptr,size_t size){if(ReplacementFor_SSL_pending(
ReplacementFor_ssl_)>(0x1b4+4113-0x11c5)){return ReplacementFor_SSL_read(
ReplacementFor_ssl_,ReplacementFor_ptr,static_cast<int>(size));}else if(
ReplacementFor_is_readable()){auto ReplacementFor_ret=ReplacementFor_SSL_read(
ReplacementFor_ssl_,ReplacementFor_ptr,static_cast<int>(size));if(
ReplacementFor_ret<(0x152f+1015-0x1926)){auto err=ReplacementFor_SSL_get_error(
ReplacementFor_ssl_,ReplacementFor_ret);while(err==
ReplacementFor_SSL_ERROR_WANT_READ){if(ReplacementFor_SSL_pending(
ReplacementFor_ssl_)>(0x348+7697-0x2159)){return ReplacementFor_SSL_read(
ReplacementFor_ssl_,ReplacementFor_ptr,static_cast<int>(size));}else if(
ReplacementFor_is_readable()){ReplacementFor_ret=ReplacementFor_SSL_read(
ReplacementFor_ssl_,ReplacementFor_ptr,static_cast<int>(size));if(
ReplacementFor_ret>=(0x2100+276-0x2214)){return ReplacementFor_ret;}err=
ReplacementFor_SSL_get_error(ReplacementFor_ssl_,ReplacementFor_ret);}else{
return-(0x66a+1983-0xe28);}}}return ReplacementFor_ret;}return-
(0xbba+1754-0x1293);}ssize_t ReplacementFor_SSLSocketStream::write(const char*
ReplacementFor_ptr,size_t size){if(ReplacementFor_is_writable()){return 
ReplacementFor_SSL_write(ReplacementFor_ssl_,ReplacementFor_ptr,static_cast<int>
(size));}return-(0xcc2+5892-0x23c5);}void ReplacementFor_SSLSocketStream::
ReplacementFor_get_remote_ip_and_port(std::string&ReplacementFor_ip,int&
ReplacementFor_port)const{ReplacementFor_detail::
ReplacementFor_get_remote_ip_and_port(ReplacementFor_sock_,ReplacementFor_ip,
ReplacementFor_port);}ReplacementFor_socket_t ReplacementFor_SSLSocketStream::
socket()const{return ReplacementFor_sock_;}static ReplacementFor_SSLInit 
ReplacementFor_sslinit_;}ReplacementFor_SSLServer::ReplacementFor_SSLServer(
const char*ReplacementFor_cert_path,const char*ReplacementFor_private_key_path,
const char*ReplacementFor_client_ca_cert_file_path,const char*
ReplacementFor_client_ca_cert_dir_path){ReplacementFor_ctx_=
ReplacementFor_SSL_CTX_new(ReplacementFor_SSLv23_server_method());if(
ReplacementFor_ctx_){ReplacementFor_SSL_CTX_set_options(ReplacementFor_ctx_,
ReplacementFor_SSL_OP_ALL|ReplacementFor_SSL_OP_NO_SSLv2|
ReplacementFor_SSL_OP_NO_SSLv3|ReplacementFor_SSL_OP_NO_COMPRESSION|
ReplacementFor_SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION);if(
ReplacementFor_SSL_CTX_use_certificate_chain_file(ReplacementFor_ctx_,
ReplacementFor_cert_path)!=(0x490+4184-0x14e7)||
ReplacementFor_SSL_CTX_use_PrivateKey_file(ReplacementFor_ctx_,
ReplacementFor_private_key_path,ReplacementFor_SSL_FILETYPE_PEM)!=
(0x888+3346-0x1599)){ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);
ReplacementFor_ctx_=nullptr;}else if(ReplacementFor_client_ca_cert_file_path||
ReplacementFor_client_ca_cert_dir_path){
ReplacementFor_SSL_CTX_load_verify_locations(ReplacementFor_ctx_,
ReplacementFor_client_ca_cert_file_path,ReplacementFor_client_ca_cert_dir_path);
ReplacementFor_SSL_CTX_set_verify(ReplacementFor_ctx_,
ReplacementFor_SSL_VERIFY_PEER|ReplacementFor_SSL_VERIFY_FAIL_IF_NO_PEER_CERT,
nullptr);}}}ReplacementFor_SSLServer::ReplacementFor_SSLServer(
ReplacementFor_X509*ReplacementFor_cert,ReplacementFor_EVP_PKEY*
ReplacementFor_private_key,ReplacementFor_X509_STORE*
ReplacementFor_client_ca_cert_store){ReplacementFor_ctx_=
ReplacementFor_SSL_CTX_new(ReplacementFor_SSLv23_server_method());if(
ReplacementFor_ctx_){ReplacementFor_SSL_CTX_set_options(ReplacementFor_ctx_,
ReplacementFor_SSL_OP_ALL|ReplacementFor_SSL_OP_NO_SSLv2|
ReplacementFor_SSL_OP_NO_SSLv3|ReplacementFor_SSL_OP_NO_COMPRESSION|
ReplacementFor_SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION);if(
ReplacementFor_SSL_CTX_use_certificate(ReplacementFor_ctx_,ReplacementFor_cert)
!=(0x9b7+4838-0x1c9c)||ReplacementFor_SSL_CTX_use_PrivateKey(ReplacementFor_ctx_
,ReplacementFor_private_key)!=(0x3bf+3499-0x1169)){ReplacementFor_SSL_CTX_free(
ReplacementFor_ctx_);ReplacementFor_ctx_=nullptr;}else if(
ReplacementFor_client_ca_cert_store){ReplacementFor_SSL_CTX_set_cert_store(
ReplacementFor_ctx_,ReplacementFor_client_ca_cert_store);
ReplacementFor_SSL_CTX_set_verify(ReplacementFor_ctx_,
ReplacementFor_SSL_VERIFY_PEER|ReplacementFor_SSL_VERIFY_FAIL_IF_NO_PEER_CERT,
nullptr);}}}ReplacementFor_SSLServer::~ReplacementFor_SSLServer(){if(
ReplacementFor_ctx_){ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);}}bool 
ReplacementFor_SSLServer::ReplacementFor_is_valid()const{return 
ReplacementFor_ctx_;}bool ReplacementFor_SSLServer::
ReplacementFor_process_and_close_socket(ReplacementFor_socket_t 
ReplacementFor_sock){auto ReplacementFor_ssl=ReplacementFor_detail::
ReplacementFor_ssl_new(ReplacementFor_sock,ReplacementFor_ctx_,
ReplacementFor_ctx_mutex_,[&](ReplacementFor_SSL*ReplacementFor_ssl){return 
ReplacementFor_detail::ReplacementFor_ssl_connect_or_accept_nonblocking(
ReplacementFor_sock,ReplacementFor_ssl,ReplacementFor_SSL_accept,
ReplacementFor_read_timeout_sec_,ReplacementFor_read_timeout_usec_);},[](
ReplacementFor_SSL*){return true;});bool ReplacementFor_ret=false;if(
ReplacementFor_ssl){ReplacementFor_ret=ReplacementFor_detail::
ReplacementFor_process_server_socket_ssl(ReplacementFor_ssl,ReplacementFor_sock,
ReplacementFor_keep_alive_max_count_,ReplacementFor_keep_alive_timeout_sec_,
ReplacementFor_read_timeout_sec_,ReplacementFor_read_timeout_usec_,
ReplacementFor_write_timeout_sec_,ReplacementFor_write_timeout_usec_,[this,
ReplacementFor_ssl](ReplacementFor_Stream&ReplacementFor_strm,bool 
ReplacementFor_close_connection,bool&ReplacementFor_connection_closed){return 
ReplacementFor_process_request(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_connection_closed,[&](
ReplacementFor_Request&ReplacementFor_req){ReplacementFor_req.ReplacementFor_ssl
=ReplacementFor_ssl;});});const bool ReplacementFor_shutdown_gracefully=
ReplacementFor_ret;ReplacementFor_detail::ReplacementFor_ssl_delete(
ReplacementFor_ctx_mutex_,ReplacementFor_ssl,ReplacementFor_shutdown_gracefully)
;}ReplacementFor_detail::ReplacementFor_shutdown_socket(ReplacementFor_sock);
ReplacementFor_detail::ReplacementFor_close_socket(ReplacementFor_sock);return 
ReplacementFor_ret;}ReplacementFor_SSLClient::ReplacementFor_SSLClient(const std
::string&ReplacementFor_host):ReplacementFor_SSLClient(ReplacementFor_host,
(0x239c+558-0x240f),std::string(),std::string()){}ReplacementFor_SSLClient::
ReplacementFor_SSLClient(const std::string&ReplacementFor_host,int 
ReplacementFor_port):ReplacementFor_SSLClient(ReplacementFor_host,
ReplacementFor_port,std::string(),std::string()){}ReplacementFor_SSLClient::
ReplacementFor_SSLClient(const std::string&ReplacementFor_host,int 
ReplacementFor_port,const std::string&ReplacementFor_client_cert_path,const std
::string&ReplacementFor_client_key_path):ReplacementFor_ClientImpl(
ReplacementFor_host,ReplacementFor_port,ReplacementFor_client_cert_path,
ReplacementFor_client_key_path){ReplacementFor_ctx_=ReplacementFor_SSL_CTX_new(
ReplacementFor_SSLv23_client_method());ReplacementFor_detail::
ReplacementFor_split(&ReplacementFor_host_[(0x14b0+1550-0x1abe)],&
ReplacementFor_host_[ReplacementFor_host_.size()],((char)(0x447+22-0x42f)),[&](
const char*b,const char*ReplacementFor_e){ReplacementFor_host_components_.
emplace_back(std::string(b,ReplacementFor_e));});if(!
ReplacementFor_client_cert_path.empty()&&!ReplacementFor_client_key_path.empty()
){if(ReplacementFor_SSL_CTX_use_certificate_file(ReplacementFor_ctx_,
ReplacementFor_client_cert_path.c_str(),ReplacementFor_SSL_FILETYPE_PEM)!=
(0x1830+3201-0x24b0)||ReplacementFor_SSL_CTX_use_PrivateKey_file(
ReplacementFor_ctx_,ReplacementFor_client_key_path.c_str(),
ReplacementFor_SSL_FILETYPE_PEM)!=(0x126d+19-0x127f)){
ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);ReplacementFor_ctx_=nullptr;}}}
ReplacementFor_SSLClient::ReplacementFor_SSLClient(const std::string&
ReplacementFor_host,int ReplacementFor_port,ReplacementFor_X509*
ReplacementFor_client_cert,ReplacementFor_EVP_PKEY*ReplacementFor_client_key):
ReplacementFor_ClientImpl(ReplacementFor_host,ReplacementFor_port){
ReplacementFor_ctx_=ReplacementFor_SSL_CTX_new(
ReplacementFor_SSLv23_client_method());ReplacementFor_detail::
ReplacementFor_split(&ReplacementFor_host_[(0x16b+5457-0x16bc)],&
ReplacementFor_host_[ReplacementFor_host_.size()],((char)(0x1267+4333-0x2326)),[
&](const char*b,const char*ReplacementFor_e){ReplacementFor_host_components_.
emplace_back(std::string(b,ReplacementFor_e));});if(ReplacementFor_client_cert!=
nullptr&&ReplacementFor_client_key!=nullptr){if(
ReplacementFor_SSL_CTX_use_certificate(ReplacementFor_ctx_,
ReplacementFor_client_cert)!=(0xcfc+2865-0x182c)||
ReplacementFor_SSL_CTX_use_PrivateKey(ReplacementFor_ctx_,
ReplacementFor_client_key)!=(0xbb0+1229-0x107c)){ReplacementFor_SSL_CTX_free(
ReplacementFor_ctx_);ReplacementFor_ctx_=nullptr;}}}ReplacementFor_SSLClient::~
ReplacementFor_SSLClient(){if(ReplacementFor_ctx_){ReplacementFor_SSL_CTX_free(
ReplacementFor_ctx_);}ReplacementFor_SSLClient::ReplacementFor_shutdown_ssl(
ReplacementFor_socket_,true);}bool ReplacementFor_SSLClient::
ReplacementFor_is_valid()const{return ReplacementFor_ctx_;}void 
ReplacementFor_SSLClient::ReplacementFor_set_ca_cert_path(const char*
ReplacementFor_ca_cert_file_path,const char*ReplacementFor_ca_cert_dir_path){if(
ReplacementFor_ca_cert_file_path){ReplacementFor_ca_cert_file_path_=
ReplacementFor_ca_cert_file_path;}if(ReplacementFor_ca_cert_dir_path){
ReplacementFor_ca_cert_dir_path_=ReplacementFor_ca_cert_dir_path;}}void 
ReplacementFor_SSLClient::ReplacementFor_set_ca_cert_store(
ReplacementFor_X509_STORE*ReplacementFor_ca_cert_store){if(
ReplacementFor_ca_cert_store){if(ReplacementFor_ctx_){if(
ReplacementFor_SSL_CTX_get_cert_store(ReplacementFor_ctx_)!=
ReplacementFor_ca_cert_store){ReplacementFor_SSL_CTX_set_cert_store(
ReplacementFor_ctx_,ReplacementFor_ca_cert_store);}}else{
ReplacementFor_X509_STORE_free(ReplacementFor_ca_cert_store);}}}long 
ReplacementFor_SSLClient::ReplacementFor_get_openssl_verify_result()const{return
 ReplacementFor_verify_result_;}ReplacementFor_SSL_CTX*ReplacementFor_SSLClient
::ReplacementFor_ssl_context()const{return ReplacementFor_ctx_;}bool 
ReplacementFor_SSLClient::ReplacementFor_create_and_connect_socket(Socket&socket
,Error&error){return ReplacementFor_is_valid()&&ReplacementFor_ClientImpl::
ReplacementFor_create_and_connect_socket(socket,error);}bool 
ReplacementFor_SSLClient::ReplacementFor_connect_with_proxy(Socket&socket,
ReplacementFor_Response&ReplacementFor_res,bool&ReplacementFor_success,Error&
error){ReplacementFor_success=true;ReplacementFor_Response ReplacementFor_res2;
if(!ReplacementFor_detail::ReplacementFor_process_client_socket(socket.
ReplacementFor_sock,ReplacementFor_read_timeout_sec_,
ReplacementFor_read_timeout_usec_,ReplacementFor_write_timeout_sec_,
ReplacementFor_write_timeout_usec_,[&](ReplacementFor_Stream&ReplacementFor_strm
){ReplacementFor_Request ReplacementFor_req2;ReplacementFor_req2.
ReplacementFor_method="\x43\x4f\x4e\x4e\x45\x43\x54";ReplacementFor_req2.
ReplacementFor_path=ReplacementFor_host_and_port_;return 
ReplacementFor_process_request(ReplacementFor_strm,ReplacementFor_req2,
ReplacementFor_res2,false,error);})){ReplacementFor_shutdown_ssl(socket,true);
ReplacementFor_shutdown_socket(socket);ReplacementFor_close_socket(socket);
ReplacementFor_success=false;return false;}if(ReplacementFor_res2.status==
(0xd05+1554-0x1180)){if(!ReplacementFor_proxy_digest_auth_username_.empty()&&!
ReplacementFor_proxy_digest_auth_password_.empty()){std::map<std::string,std::
string>ReplacementFor_auth;if(ReplacementFor_detail::
ReplacementFor_parse_www_authenticate(ReplacementFor_res2,ReplacementFor_auth,
true)){ReplacementFor_Response ReplacementFor_res3;if(!ReplacementFor_detail::
ReplacementFor_process_client_socket(socket.ReplacementFor_sock,
ReplacementFor_read_timeout_sec_,ReplacementFor_read_timeout_usec_,
ReplacementFor_write_timeout_sec_,ReplacementFor_write_timeout_usec_,[&](
ReplacementFor_Stream&ReplacementFor_strm){ReplacementFor_Request 
ReplacementFor_req3;ReplacementFor_req3.ReplacementFor_method=
"\x43\x4f\x4e\x4e\x45\x43\x54";ReplacementFor_req3.ReplacementFor_path=
ReplacementFor_host_and_port_;ReplacementFor_req3.ReplacementFor_headers.insert(
ReplacementFor_detail::ReplacementFor_make_digest_authentication_header(
ReplacementFor_req3,ReplacementFor_auth,(0x6a6+961-0xa66),ReplacementFor_detail
::ReplacementFor_random_string((0xe70+365-0xfd3)),
ReplacementFor_proxy_digest_auth_username_,
ReplacementFor_proxy_digest_auth_password_,true));return 
ReplacementFor_process_request(ReplacementFor_strm,ReplacementFor_req3,
ReplacementFor_res3,false,error);})){ReplacementFor_shutdown_ssl(socket,true);
ReplacementFor_shutdown_socket(socket);ReplacementFor_close_socket(socket);
ReplacementFor_success=false;return false;}}}else{ReplacementFor_res=
ReplacementFor_res2;return false;}}return true;}bool ReplacementFor_SSLClient::
ReplacementFor_load_certs(){bool ReplacementFor_ret=true;std::call_once(
ReplacementFor_initialize_cert_,[&](){std::lock_guard<std::mutex>
ReplacementFor_guard(ReplacementFor_ctx_mutex_);if(!
ReplacementFor_ca_cert_file_path_.empty()){if(!
ReplacementFor_SSL_CTX_load_verify_locations(ReplacementFor_ctx_,
ReplacementFor_ca_cert_file_path_.c_str(),nullptr)){ReplacementFor_ret=false;}}
else if(!ReplacementFor_ca_cert_dir_path_.empty()){if(!
ReplacementFor_SSL_CTX_load_verify_locations(ReplacementFor_ctx_,nullptr,
ReplacementFor_ca_cert_dir_path_.c_str())){ReplacementFor_ret=false;}}else{
#ifdef _WIN32
ReplacementFor_detail::ReplacementFor_load_system_certs_on_windows(
ReplacementFor_SSL_CTX_get_cert_store(ReplacementFor_ctx_));
#else
ReplacementFor_SSL_CTX_set_default_verify_paths(ReplacementFor_ctx_);
#endif
}});return ReplacementFor_ret;}bool ReplacementFor_SSLClient::
ReplacementFor_initialize_ssl(Socket&socket,Error&error){auto ReplacementFor_ssl
=ReplacementFor_detail::ReplacementFor_ssl_new(socket.ReplacementFor_sock,
ReplacementFor_ctx_,ReplacementFor_ctx_mutex_,[&](ReplacementFor_SSL*
ReplacementFor_ssl){if(ReplacementFor_server_certificate_verification_){if(!
ReplacementFor_load_certs()){error=Error::ReplacementFor_SSLLoadingCerts;return 
false;}ReplacementFor_SSL_set_verify(ReplacementFor_ssl,
ReplacementFor_SSL_VERIFY_NONE,nullptr);}if(!ReplacementFor_detail::
ReplacementFor_ssl_connect_or_accept_nonblocking(socket.ReplacementFor_sock,
ReplacementFor_ssl,ReplacementFor_SSL_connect,
ReplacementFor_connection_timeout_sec_,ReplacementFor_connection_timeout_usec_))
{error=Error::ReplacementFor_SSLConnection;return false;}if(
ReplacementFor_server_certificate_verification_){ReplacementFor_verify_result_=
ReplacementFor_SSL_get_verify_result(ReplacementFor_ssl);if(
ReplacementFor_verify_result_!=ReplacementFor_X509_V_OK){error=Error::
ReplacementFor_SSLServerVerification;return false;}auto 
ReplacementFor_server_cert=ReplacementFor_SSL_get_peer_certificate(
ReplacementFor_ssl);if(ReplacementFor_server_cert==nullptr){error=Error::
ReplacementFor_SSLServerVerification;return false;}if(!
ReplacementFor_verify_host(ReplacementFor_server_cert)){ReplacementFor_X509_free
(ReplacementFor_server_cert);error=Error::ReplacementFor_SSLServerVerification;
return false;}ReplacementFor_X509_free(ReplacementFor_server_cert);}return true;
},[&](ReplacementFor_SSL*ReplacementFor_ssl){
ReplacementFor_SSL_set_tlsext_host_name(ReplacementFor_ssl,ReplacementFor_host_.
c_str());return true;});if(ReplacementFor_ssl){socket.ReplacementFor_ssl=
ReplacementFor_ssl;return true;}ReplacementFor_shutdown_socket(socket);
ReplacementFor_close_socket(socket);return false;}void ReplacementFor_SSLClient
::ReplacementFor_shutdown_ssl(Socket&socket,bool 
ReplacementFor_shutdown_gracefully){if(socket.ReplacementFor_sock==
INVALID_SOCKET){assert(socket.ReplacementFor_ssl==nullptr);return;}if(socket.
ReplacementFor_ssl){ReplacementFor_detail::ReplacementFor_ssl_delete(
ReplacementFor_ctx_mutex_,socket.ReplacementFor_ssl,
ReplacementFor_shutdown_gracefully);socket.ReplacementFor_ssl=nullptr;}assert(
socket.ReplacementFor_ssl==nullptr);}bool ReplacementFor_SSLClient::
ReplacementFor_process_socket(const Socket&socket,std::function<bool(
ReplacementFor_Stream&ReplacementFor_strm)>ReplacementFor_callback){assert(
socket.ReplacementFor_ssl);return ReplacementFor_detail::
ReplacementFor_process_client_socket_ssl(socket.ReplacementFor_ssl,socket.
ReplacementFor_sock,ReplacementFor_read_timeout_sec_,
ReplacementFor_read_timeout_usec_,ReplacementFor_write_timeout_sec_,
ReplacementFor_write_timeout_usec_,std::move(ReplacementFor_callback));}bool 
ReplacementFor_SSLClient::ReplacementFor_is_ssl()const{return true;}bool 
ReplacementFor_SSLClient::ReplacementFor_verify_host(ReplacementFor_X509*
ReplacementFor_server_cert)const{return 
ReplacementFor_verify_host_with_subject_alt_name(ReplacementFor_server_cert)||
ReplacementFor_verify_host_with_common_name(ReplacementFor_server_cert);}bool 
ReplacementFor_SSLClient::ReplacementFor_verify_host_with_subject_alt_name(
ReplacementFor_X509*ReplacementFor_server_cert)const{auto ReplacementFor_ret=
false;auto type=ReplacementFor_GEN_DNS;struct in6_addr ReplacementFor_addr6;
struct in_addr addr;size_t ReplacementFor_addr_len=(0x901+6222-0x214f);
#ifndef __MINGW32__
if(ReplacementFor_inet_pton(AF_INET6,ReplacementFor_host_.c_str(),&
ReplacementFor_addr6)){type=ReplacementFor_GEN_IPADD;ReplacementFor_addr_len=
sizeof(struct in6_addr);}else if(ReplacementFor_inet_pton(AF_INET,
ReplacementFor_host_.c_str(),&addr)){type=ReplacementFor_GEN_IPADD;
ReplacementFor_addr_len=sizeof(struct in_addr);}
#endif
auto ReplacementFor_alt_names=static_cast<const struct 
ReplacementFor_stack_st_GENERAL_NAME*>(ReplacementFor_X509_get_ext_d2i(
ReplacementFor_server_cert,ReplacementFor_NID_subject_alt_name,nullptr,nullptr))
;if(ReplacementFor_alt_names){auto ReplacementFor_dsn_matched=false;auto 
ReplacementFor_ip_mached=false;auto count=ReplacementFor_sk_GENERAL_NAME_num(
ReplacementFor_alt_names);for(decltype(count)i=(0x97c+1180-0xe18);i<count&&!
ReplacementFor_dsn_matched;i++){auto val=ReplacementFor_sk_GENERAL_NAME_value(
ReplacementFor_alt_names,i);if(val->type==type){auto name=(const char*)
ReplacementFor_ASN1_STRING_get0_data(val->ReplacementFor_d.ReplacementFor_ia5);
auto ReplacementFor_name_len=(size_t)ReplacementFor_ASN1_STRING_length(val->
ReplacementFor_d.ReplacementFor_ia5);switch(type){case ReplacementFor_GEN_DNS:
ReplacementFor_dsn_matched=ReplacementFor_check_host_name(name,
ReplacementFor_name_len);break;case ReplacementFor_GEN_IPADD:if(!memcmp(&
ReplacementFor_addr6,name,ReplacementFor_addr_len)||!memcmp(&addr,name,
ReplacementFor_addr_len)){ReplacementFor_ip_mached=true;}break;}}}if(
ReplacementFor_dsn_matched||ReplacementFor_ip_mached){ReplacementFor_ret=true;}}
ReplacementFor_GENERAL_NAMES_free((ReplacementFor_STACK_OF(
ReplacementFor_GENERAL_NAME)*)ReplacementFor_alt_names);return 
ReplacementFor_ret;}bool ReplacementFor_SSLClient::
ReplacementFor_verify_host_with_common_name(ReplacementFor_X509*
ReplacementFor_server_cert)const{const auto ReplacementFor_subject_name=
ReplacementFor_X509_get_subject_name(ReplacementFor_server_cert);if(
ReplacementFor_subject_name!=nullptr){char name[BUFSIZ];auto 
ReplacementFor_name_len=ReplacementFor_X509_NAME_get_text_by_NID(
ReplacementFor_subject_name,ReplacementFor_NID_commonName,name,sizeof(name));if(
ReplacementFor_name_len!=-(0x347+1843-0xa79)){return 
ReplacementFor_check_host_name(name,static_cast<size_t>(ReplacementFor_name_len)
);}}return false;}bool ReplacementFor_SSLClient::ReplacementFor_check_host_name(
const char*pattern,size_t ReplacementFor_pattern_len)const{if(
ReplacementFor_host_.size()==ReplacementFor_pattern_len&&ReplacementFor_host_==
pattern){return true;}std::vector<std::string>ReplacementFor_pattern_components;
ReplacementFor_detail::ReplacementFor_split(&pattern[(0xf2f+1966-0x16dd)],&
pattern[ReplacementFor_pattern_len],((char)(0x7d4+4109-0x17b3)),[&](const char*b
,const char*ReplacementFor_e){ReplacementFor_pattern_components.emplace_back(std
::string(b,ReplacementFor_e));});if(ReplacementFor_host_components_.size()!=
ReplacementFor_pattern_components.size()){return false;}auto ReplacementFor_itr=
ReplacementFor_pattern_components.begin();for(const auto&ReplacementFor_h:
ReplacementFor_host_components_){auto&p=*ReplacementFor_itr;if(p!=
ReplacementFor_h&&p!="\x2a"){auto ReplacementFor_partial_match=(p.size()>
(0x8d6+6516-0x224a)&&p[p.size()-(0x6e2+2252-0xfad)]==((char)(0x2013+40-0x2011))
&&!p.compare((0x386+8521-0x24cf),p.size()-(0x375+8925-0x2651),ReplacementFor_h))
;if(!ReplacementFor_partial_match){return false;}}++ReplacementFor_itr;}return 
true;}
#endif
ReplacementFor_Client::ReplacementFor_Client(const char*
ReplacementFor_scheme_host_port):ReplacementFor_Client(
ReplacementFor_scheme_host_port,std::string(),std::string()){}
ReplacementFor_Client::ReplacementFor_Client(const char*
ReplacementFor_scheme_host_port,const std::string&
ReplacementFor_client_cert_path,const std::string&ReplacementFor_client_key_path
){const static std::regex ReplacementFor_re(
R"(^(?:([a-z]+)://)?([^:/?#]+)(?::(\d+))?)");std::cmatch m;if(std::regex_match(
ReplacementFor_scheme_host_port,m,ReplacementFor_re)){auto ReplacementFor_scheme
=m[(0x169d+1349-0x1be1)].str();
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
if(!ReplacementFor_scheme.empty()&&(ReplacementFor_scheme!="\x68\x74\x74\x70"&&
ReplacementFor_scheme!="\x68\x74\x74\x70\x73")){
#else
if(!ReplacementFor_scheme.empty()&&ReplacementFor_scheme!="\x68\x74\x74\x70"){
#endif
std::string msg="\x27"+ReplacementFor_scheme+
"\x27\x20\x73\x63\x68\x65\x6d\x65\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x2e"
;throw std::invalid_argument(msg);return;}auto ReplacementFor_is_ssl=
ReplacementFor_scheme=="\x68\x74\x74\x70\x73";auto ReplacementFor_host=m[
(0x746+6704-0x2174)].str();auto ReplacementFor_port_str=m[(0x8cd+3989-0x185f)].
str();auto ReplacementFor_port=!ReplacementFor_port_str.empty()?std::stoi(
ReplacementFor_port_str):(ReplacementFor_is_ssl?(0x1873+554-0x18e2):
(0xaa+7988-0x1f8e));if(ReplacementFor_is_ssl){
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
ReplacementFor_cli_=ReplacementFor_detail::make_unique<ReplacementFor_SSLClient>
(ReplacementFor_host.c_str(),ReplacementFor_port,ReplacementFor_client_cert_path
,ReplacementFor_client_key_path);ReplacementFor_is_ssl_=ReplacementFor_is_ssl;
#endif
}else{ReplacementFor_cli_=ReplacementFor_detail::make_unique<
ReplacementFor_ClientImpl>(ReplacementFor_host.c_str(),ReplacementFor_port,
ReplacementFor_client_cert_path,ReplacementFor_client_key_path);}}else{
ReplacementFor_cli_=ReplacementFor_detail::make_unique<ReplacementFor_ClientImpl
>(ReplacementFor_scheme_host_port,(0x146a+658-0x16ac),
ReplacementFor_client_cert_path,ReplacementFor_client_key_path);}}
ReplacementFor_Client::ReplacementFor_Client(const std::string&
ReplacementFor_host,int ReplacementFor_port):ReplacementFor_cli_(
ReplacementFor_detail::make_unique<ReplacementFor_ClientImpl>(
ReplacementFor_host,ReplacementFor_port)){}ReplacementFor_Client::
ReplacementFor_Client(const std::string&ReplacementFor_host,int 
ReplacementFor_port,const std::string&ReplacementFor_client_cert_path,const std
::string&ReplacementFor_client_key_path):ReplacementFor_cli_(
ReplacementFor_detail::make_unique<ReplacementFor_ClientImpl>(
ReplacementFor_host,ReplacementFor_port,ReplacementFor_client_cert_path,
ReplacementFor_client_key_path)){}ReplacementFor_Client::~ReplacementFor_Client(
){}bool ReplacementFor_Client::ReplacementFor_is_valid()const{return 
ReplacementFor_cli_!=nullptr&&ReplacementFor_cli_->ReplacementFor_is_valid();}
Result ReplacementFor_Client::Get(const char*ReplacementFor_path){return 
ReplacementFor_cli_->Get(ReplacementFor_path);}Result ReplacementFor_Client::Get
(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers){return ReplacementFor_cli_->Get(ReplacementFor_path,
ReplacementFor_headers);}Result ReplacementFor_Client::Get(const char*
ReplacementFor_path,ReplacementFor_Progress ReplacementFor_progress){return 
ReplacementFor_cli_->Get(ReplacementFor_path,std::move(ReplacementFor_progress))
;}Result ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_Progress 
ReplacementFor_progress){return ReplacementFor_cli_->Get(ReplacementFor_path,
ReplacementFor_headers,std::move(ReplacementFor_progress));}Result 
ReplacementFor_Client::Get(const char*ReplacementFor_path,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver){return 
ReplacementFor_cli_->Get(ReplacementFor_path,std::move(
ReplacementFor_content_receiver));}Result ReplacementFor_Client::Get(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver){return 
ReplacementFor_cli_->Get(ReplacementFor_path,ReplacementFor_headers,std::move(
ReplacementFor_content_receiver));}Result ReplacementFor_Client::Get(const char*
ReplacementFor_path,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return ReplacementFor_cli_->Get(ReplacementFor_path,std::move(
ReplacementFor_content_receiver),std::move(ReplacementFor_progress));}Result 
ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return ReplacementFor_cli_->Get(ReplacementFor_path,ReplacementFor_headers,std
::move(ReplacementFor_content_receiver),std::move(ReplacementFor_progress));}
Result ReplacementFor_Client::Get(const char*ReplacementFor_path,
ReplacementFor_ResponseHandler ReplacementFor_response_handler,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver){return 
ReplacementFor_cli_->Get(ReplacementFor_path,std::move(
ReplacementFor_response_handler),std::move(ReplacementFor_content_receiver));}
Result ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver){return ReplacementFor_cli_->Get(
ReplacementFor_path,ReplacementFor_headers,std::move(
ReplacementFor_response_handler),std::move(ReplacementFor_content_receiver));}
Result ReplacementFor_Client::Get(const char*ReplacementFor_path,
ReplacementFor_ResponseHandler ReplacementFor_response_handler,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress){return ReplacementFor_cli_->Get
(ReplacementFor_path,std::move(ReplacementFor_response_handler),std::move(
ReplacementFor_content_receiver),std::move(ReplacementFor_progress));}Result 
ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return ReplacementFor_cli_->Get(ReplacementFor_path,ReplacementFor_headers,std
::move(ReplacementFor_response_handler),std::move(
ReplacementFor_content_receiver),std::move(ReplacementFor_progress));}Result 
ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_Progress ReplacementFor_progress){return 
ReplacementFor_cli_->Get(ReplacementFor_path,ReplacementFor_params,
ReplacementFor_headers,ReplacementFor_progress);}Result ReplacementFor_Client::
Get(const char*ReplacementFor_path,const ReplacementFor_Params&
ReplacementFor_params,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress){return ReplacementFor_cli_->Get
(ReplacementFor_path,ReplacementFor_params,ReplacementFor_headers,
ReplacementFor_content_receiver,ReplacementFor_progress);}Result 
ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return ReplacementFor_cli_->Get(ReplacementFor_path,ReplacementFor_params,
ReplacementFor_headers,ReplacementFor_response_handler,
ReplacementFor_content_receiver,ReplacementFor_progress);}Result 
ReplacementFor_Client::Head(const char*ReplacementFor_path){return 
ReplacementFor_cli_->Head(ReplacementFor_path);}Result ReplacementFor_Client::
Head(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers){return ReplacementFor_cli_->Head(ReplacementFor_path,
ReplacementFor_headers);}Result ReplacementFor_Client::ReplacementFor_Post(const
 char*ReplacementFor_path){return ReplacementFor_cli_->ReplacementFor_Post(
ReplacementFor_path);}Result ReplacementFor_Client::ReplacementFor_Post(const 
char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,ReplacementFor_body
,ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const char*ReplacementFor_body,
size_t ReplacementFor_content_length,const char*ReplacementFor_content_type){
return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_body,ReplacementFor_content_length,
ReplacementFor_content_type);}Result ReplacementFor_Client::ReplacementFor_Post(
const char*ReplacementFor_path,const std::string&ReplacementFor_body,const char*
ReplacementFor_content_type){return ReplacementFor_cli_->ReplacementFor_Post(
ReplacementFor_path,ReplacementFor_body,ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_body,ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,size_t
 ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_content_length,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_Client::ReplacementFor_Post(
const char*ReplacementFor_path,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_cli_->
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_headers,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params){return ReplacementFor_cli_->
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_params);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const ReplacementFor_Params&
ReplacementFor_params){return ReplacementFor_cli_->ReplacementFor_Post(
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_params);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_MultipartFormDataItems&ReplacementFor_items){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_items);}Result ReplacementFor_Client::ReplacementFor_Post(const 
char*ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
const ReplacementFor_MultipartFormDataItems&ReplacementFor_items){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_items);}Result ReplacementFor_Client::
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const ReplacementFor_MultipartFormDataItems&
ReplacementFor_items,const std::string&ReplacementFor_boundary){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_items,ReplacementFor_boundary);}Result 
ReplacementFor_Client::Put(const char*ReplacementFor_path){return 
ReplacementFor_cli_->Put(ReplacementFor_path);}Result ReplacementFor_Client::Put
(const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_body,
ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_Client::Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const char*ReplacementFor_body,
size_t ReplacementFor_content_length,const char*ReplacementFor_content_type){
return ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_length,ReplacementFor_content_type);}
Result ReplacementFor_Client::Put(const char*ReplacementFor_path,const std::
string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_body,
ReplacementFor_content_type);}Result ReplacementFor_Client::Put(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
std::string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_type);}Result ReplacementFor_Client::
Put(const char*ReplacementFor_path,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type){return ReplacementFor_cli_->Put(ReplacementFor_path
,ReplacementFor_content_length,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_Client::Put(const char*
ReplacementFor_path,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Put(ReplacementFor_path,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_content_length,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_Client::Put(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_cli_->Put(
ReplacementFor_path,ReplacementFor_headers,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::Put(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params){return ReplacementFor_cli_->Put(
ReplacementFor_path,ReplacementFor_params);}Result ReplacementFor_Client::Put(
const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const ReplacementFor_Params&ReplacementFor_params){return
 ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_params);}Result ReplacementFor_Client::ReplacementFor_Patch(const
 char*ReplacementFor_path){return ReplacementFor_cli_->ReplacementFor_Patch(
ReplacementFor_path);}Result ReplacementFor_Client::ReplacementFor_Patch(const 
char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path,
ReplacementFor_body,ReplacementFor_content_length,ReplacementFor_content_type);}
Result ReplacementFor_Client::ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
char*ReplacementFor_body,size_t ReplacementFor_content_length,const char*
ReplacementFor_content_type){return ReplacementFor_cli_->ReplacementFor_Patch(
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_body,
ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Patch(const char*ReplacementFor_path,const
 std::string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path,
ReplacementFor_body,ReplacementFor_content_type);}Result ReplacementFor_Client::
ReplacementFor_Patch(const char*ReplacementFor_path,const ReplacementFor_Headers
&ReplacementFor_headers,const std::string&ReplacementFor_body,const char*
ReplacementFor_content_type){return ReplacementFor_cli_->ReplacementFor_Patch(
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_body,
ReplacementFor_content_type);}Result ReplacementFor_Client::ReplacementFor_Patch
(const char*ReplacementFor_path,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type){return ReplacementFor_cli_->ReplacementFor_Patch(
ReplacementFor_path,ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Patch(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_cli_->
ReplacementFor_Patch(ReplacementFor_path,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Patch(const char*ReplacementFor_path,const
 ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Patch(const char*ReplacementFor_path,const
 ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_cli_->
ReplacementFor_Patch(ReplacementFor_path,ReplacementFor_headers,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::Delete(const char*ReplacementFor_path){return 
ReplacementFor_cli_->Delete(ReplacementFor_path);}Result ReplacementFor_Client::
Delete(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers){return ReplacementFor_cli_->Delete(ReplacementFor_path,
ReplacementFor_headers);}Result ReplacementFor_Client::Delete(const char*
ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Delete(ReplacementFor_path,ReplacementFor_body,
ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_Client::Delete(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const char*ReplacementFor_body,
size_t ReplacementFor_content_length,const char*ReplacementFor_content_type){
return ReplacementFor_cli_->Delete(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_length,ReplacementFor_content_type);}
Result ReplacementFor_Client::Delete(const char*ReplacementFor_path,const std::
string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Delete(ReplacementFor_path,ReplacementFor_body,
ReplacementFor_content_type);}Result ReplacementFor_Client::Delete(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
std::string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Delete(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_type);}Result ReplacementFor_Client::
Options(const char*ReplacementFor_path){return ReplacementFor_cli_->Options(
ReplacementFor_path);}Result ReplacementFor_Client::Options(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers){return 
ReplacementFor_cli_->Options(ReplacementFor_path,ReplacementFor_headers);}bool 
ReplacementFor_Client::send(ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,Error&error){return 
ReplacementFor_cli_->send(ReplacementFor_req,ReplacementFor_res,error);}Result 
ReplacementFor_Client::send(const ReplacementFor_Request&ReplacementFor_req){
return ReplacementFor_cli_->send(ReplacementFor_req);}size_t 
ReplacementFor_Client::ReplacementFor_is_socket_open()const{return 
ReplacementFor_cli_->ReplacementFor_is_socket_open();}void ReplacementFor_Client
::ReplacementFor_stop(){ReplacementFor_cli_->ReplacementFor_stop();}void 
ReplacementFor_Client::ReplacementFor_set_default_headers(ReplacementFor_Headers
 ReplacementFor_headers){ReplacementFor_cli_->ReplacementFor_set_default_headers
(std::move(ReplacementFor_headers));}void ReplacementFor_Client::
ReplacementFor_set_tcp_nodelay(bool ReplacementFor_on){ReplacementFor_cli_->
ReplacementFor_set_tcp_nodelay(ReplacementFor_on);}void ReplacementFor_Client::
ReplacementFor_set_socket_options(ReplacementFor_SocketOptions 
ReplacementFor_socket_options){ReplacementFor_cli_->
ReplacementFor_set_socket_options(std::move(ReplacementFor_socket_options));}
void ReplacementFor_Client::ReplacementFor_set_connection_timeout(time_t sec,
time_t ReplacementFor_usec){ReplacementFor_cli_->
ReplacementFor_set_connection_timeout(sec,ReplacementFor_usec);}void 
ReplacementFor_Client::ReplacementFor_set_read_timeout(time_t sec,time_t 
ReplacementFor_usec){ReplacementFor_cli_->ReplacementFor_set_read_timeout(sec,
ReplacementFor_usec);}void ReplacementFor_Client::
ReplacementFor_set_write_timeout(time_t sec,time_t ReplacementFor_usec){
ReplacementFor_cli_->ReplacementFor_set_write_timeout(sec,ReplacementFor_usec);}
void ReplacementFor_Client::ReplacementFor_set_basic_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){ReplacementFor_cli_
->ReplacementFor_set_basic_auth(ReplacementFor_username,ReplacementFor_password)
;}void ReplacementFor_Client::ReplacementFor_set_bearer_token_auth(const char*
ReplacementFor_token){ReplacementFor_cli_->ReplacementFor_set_bearer_token_auth(
ReplacementFor_token);}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::ReplacementFor_set_digest_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){ReplacementFor_cli_
->ReplacementFor_set_digest_auth(ReplacementFor_username,ReplacementFor_password
);}
#endif
void ReplacementFor_Client::ReplacementFor_set_keep_alive(bool ReplacementFor_on
){ReplacementFor_cli_->ReplacementFor_set_keep_alive(ReplacementFor_on);}void 
ReplacementFor_Client::ReplacementFor_set_follow_location(bool ReplacementFor_on
){ReplacementFor_cli_->ReplacementFor_set_follow_location(ReplacementFor_on);}
void ReplacementFor_Client::ReplacementFor_set_compress(bool ReplacementFor_on){
ReplacementFor_cli_->ReplacementFor_set_compress(ReplacementFor_on);}void 
ReplacementFor_Client::ReplacementFor_set_decompress(bool ReplacementFor_on){
ReplacementFor_cli_->ReplacementFor_set_decompress(ReplacementFor_on);}void 
ReplacementFor_Client::ReplacementFor_set_interface(const char*intf){
ReplacementFor_cli_->ReplacementFor_set_interface(intf);}void 
ReplacementFor_Client::ReplacementFor_set_proxy(const char*ReplacementFor_host,
int ReplacementFor_port){ReplacementFor_cli_->ReplacementFor_set_proxy(
ReplacementFor_host,ReplacementFor_port);}void ReplacementFor_Client::
ReplacementFor_set_proxy_basic_auth(const char*ReplacementFor_username,const 
char*ReplacementFor_password){ReplacementFor_cli_->
ReplacementFor_set_proxy_basic_auth(ReplacementFor_username,
ReplacementFor_password);}void ReplacementFor_Client::
ReplacementFor_set_proxy_bearer_token_auth(const char*ReplacementFor_token){
ReplacementFor_cli_->ReplacementFor_set_proxy_bearer_token_auth(
ReplacementFor_token);}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::ReplacementFor_set_proxy_digest_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){ReplacementFor_cli_
->ReplacementFor_set_proxy_digest_auth(ReplacementFor_username,
ReplacementFor_password);}
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::
ReplacementFor_enable_server_certificate_verification(bool 
ReplacementFor_enabled){ReplacementFor_cli_->
ReplacementFor_enable_server_certificate_verification(ReplacementFor_enabled);}
#endif
void ReplacementFor_Client::ReplacementFor_set_logger(ReplacementFor_Logger 
ReplacementFor_logger){ReplacementFor_cli_->ReplacementFor_set_logger(
ReplacementFor_logger);}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::ReplacementFor_set_ca_cert_path(const char*
ReplacementFor_ca_cert_file_path,const char*ReplacementFor_ca_cert_dir_path){if(
ReplacementFor_is_ssl_){static_cast<ReplacementFor_SSLClient&>(*
ReplacementFor_cli_).ReplacementFor_set_ca_cert_path(
ReplacementFor_ca_cert_file_path,ReplacementFor_ca_cert_dir_path);}}void 
ReplacementFor_Client::ReplacementFor_set_ca_cert_store(
ReplacementFor_X509_STORE*ReplacementFor_ca_cert_store){if(
ReplacementFor_is_ssl_){static_cast<ReplacementFor_SSLClient&>(*
ReplacementFor_cli_).ReplacementFor_set_ca_cert_store(
ReplacementFor_ca_cert_store);}}long ReplacementFor_Client::
ReplacementFor_get_openssl_verify_result()const{if(ReplacementFor_is_ssl_){
return static_cast<ReplacementFor_SSLClient&>(*ReplacementFor_cli_).
ReplacementFor_get_openssl_verify_result();}return-(0x6fc+4414-0x1839);}
ReplacementFor_SSL_CTX*ReplacementFor_Client::ReplacementFor_ssl_context()const{
if(ReplacementFor_is_ssl_){return static_cast<ReplacementFor_SSLClient&>(*
ReplacementFor_cli_).ReplacementFor_ssl_context();}return nullptr;}
#endif
}

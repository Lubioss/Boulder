
#include "../include/ReplacementFor_easylogging.h"
#include "../include/ReplacementFor_conversion.h"
#include "../include/ReplacementFor_cryptography.h"
#include "../include/ReplacementFor_definitions.h"
#include "../include/ReplacementFor_jsmn.h"
#include <ctype.h>
#include <curl/curl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <fstream>
#include <string>
int ReplacementFor_ReadConfig(const char*ReplacementFor_fileName,char*
ReplacementFor_from,char*ReplacementFor_to,char*ReplacementFor_endJob){std::
ifstream ReplacementFor_file(ReplacementFor_fileName,std::ios::in|std::ios::
binary|std::ios::ate);if(!ReplacementFor_file.is_open()){return EXIT_FAILURE;}
ReplacementFor_file.seekg((0x8+3831-0xeff),std::ios::end);long int len=
ReplacementFor_file.tellg();ReplacementFor_json_t ReplacementFor_config(len+
(0x2bb+7076-0x1e5e),ReplacementFor_CONF_LEN);ReplacementFor_file.seekg(
(0x1c9+4609-0x13ca),std::ios::beg);ReplacementFor_file.read(
ReplacementFor_config.ReplacementFor_ptr,len);ReplacementFor_file.close();
ReplacementFor_config.ReplacementFor_ptr[len]='\0';ReplacementFor_jsmn_parser 
ReplacementFor_parser;ReplacementFor_jsmn_init(&ReplacementFor_parser);int 
ReplacementFor_numtoks=ReplacementFor_jsmn_parse(&ReplacementFor_parser,
ReplacementFor_config.ReplacementFor_ptr,strlen(ReplacementFor_config.
ReplacementFor_ptr),ReplacementFor_config.ReplacementFor_toks,
ReplacementFor_CONF_LEN);if(ReplacementFor_numtoks<(0xb63+2186-0x13ed)){return 
EXIT_FAILURE;}uint8_t ReplacementFor_readNode=(0x6bc+476-0x898);for(int t=
(0x1f75+1273-0x246d);t<ReplacementFor_numtoks;t+=(0x84b+7533-0x25b6)){if(
ReplacementFor_config.ReplacementFor_jsoneq(t,"\x6e\x6f\x64\x65")){
ReplacementFor_from[(0x567+6178-0x1d89)]='\0';ReplacementFor_to[
(0x1189+2396-0x1ae5)]='\0';ReplacementFor_endJob[(0x9b5+5985-0x2116)]='\0';
strncat(ReplacementFor_from,ReplacementFor_config.ReplacementFor_GetTokenStart(t
+(0x197a+1880-0x20d1)),ReplacementFor_config.ReplacementFor_GetTokenLen(t+
(0x1a82+1907-0x21f4)));strcat(ReplacementFor_from,
"\x2f\x68\x6b\x65\x79\x2f\x63\x6e\x64\x74");strncat(ReplacementFor_to,
ReplacementFor_config.ReplacementFor_GetTokenStart(t+(0x7d+977-0x44d)),
ReplacementFor_config.ReplacementFor_GetTokenLen(t+(0x12a4+4129-0x22c4)));strcat
(ReplacementFor_to,"\x2f\x68\x6b\x65\x79\x2f\x73\x6f\x6f\x6c");strncat(
ReplacementFor_endJob,ReplacementFor_config.ReplacementFor_GetTokenStart(t+
(0x6fb+4549-0x18bf)),ReplacementFor_config.ReplacementFor_GetTokenLen(t+
(0x1679+1237-0x1b4d)));strcat(ReplacementFor_endJob,
"\x2f\x68\x6b\x65\x79\x2f\x6a\x6f\x62\x2f\x63\x6f\x6d\x70\x6c\x74\x64");
ReplacementFor_readNode=(0x108a+1587-0x16bc);}else{}}if(ReplacementFor_readNode)
{return EXIT_SUCCESS;}else{return EXIT_FAILURE;}}int 
ReplacementFor_PrintPublicKey(const char*ReplacementFor_pkstr,char*str){sprintf(
str,
"\x20\x20\x20\x70\x6b\x48\x65\x78\x20\x3d\x20\x25\x2e\x32\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73"
,ReplacementFor_pkstr,ReplacementFor_pkstr+(0x3b4+7052-0x1f3e),
ReplacementFor_pkstr+(0x721+6487-0x2066),ReplacementFor_pkstr+
(0x10ba+2524-0x1a74),ReplacementFor_pkstr+(0xb54+209-0xbf3));return EXIT_SUCCESS
;}int ReplacementFor_PrintPublicKey(const uint8_t*ReplacementFor_pk,char*str){
sprintf(str,
"\x20\x20\x20\x70\x6b\x48\x65\x78\x20\x3d\x20\x30\x78\x25\x30\x32\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58"
,ReplacementFor_pk[(0x9b+8527-0x21ea)],ReplacementFor_REVERSE_ENDIAN((uint64_t*)
(ReplacementFor_pk+(0xa06+3683-0x1868))+(0xa92+326-0xbd8)),
ReplacementFor_REVERSE_ENDIAN((uint64_t*)(ReplacementFor_pk+(0x357+7164-0x1f52))
+(0x164d+1306-0x1b66)),ReplacementFor_REVERSE_ENDIAN((uint64_t*)(
ReplacementFor_pk+(0x2e6+1891-0xa48))+(0x117d+1348-0x16bf)),
ReplacementFor_REVERSE_ENDIAN((uint64_t*)(ReplacementFor_pk+(0x353+4600-0x154a))
+(0x77b+5415-0x1c9f)));return EXIT_SUCCESS;}int 
ReplacementFor_PrintPuzzleSolution(const uint8_t*ReplacementFor_nonce,const 
uint8_t*ReplacementFor_sol,char*str){sprintf(str,
"\x20\x20\x20\x6e\x6f\x6e\x63\x65\x20\x3d\x20\x30\x78\x25\x30\x31\x36\x6c\x58" "\n"
"\x20\x20\x20\x20\x20\x20\x20\x64\x20\x3d\x20\x30\x78\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58"
,*((uint64_t*)ReplacementFor_nonce),((uint64_t*)ReplacementFor_sol)[
(0xed5+1171-0x1365)],((uint64_t*)ReplacementFor_sol)[(0xc27+369-0xd96)],((
uint64_t*)ReplacementFor_sol)[(0xa58+2624-0x1497)],((uint64_t*)
ReplacementFor_sol)[(0x756+7625-0x251f)]);return EXIT_SUCCESS;}

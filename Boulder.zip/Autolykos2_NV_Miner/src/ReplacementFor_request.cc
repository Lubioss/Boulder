
#include "../include/ReplacementFor_conversion.h"
#include "../include/ReplacementFor_definitions.h"
#include "../include/ReplacementFor_easylogging.h"
#include "../include/ReplacementFor_jsmn.h"
#include "../include/ReplacementFor_processing.h"
#include "../include/ReplacementFor_request.h"
#include <ctype.h>
#include <curl/curl.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <atomic>
#include <mutex>
size_t ReplacementFor_WriteFunc(void*ReplacementFor_ptr,size_t size,size_t 
ReplacementFor_nmemb,ReplacementFor_json_t*ReplacementFor_request){size_t 
ReplacementFor_newlen=ReplacementFor_request->len+size*ReplacementFor_nmemb;if(
ReplacementFor_newlen>ReplacementFor_request->ReplacementFor_cap){
ReplacementFor_request->ReplacementFor_cap=(ReplacementFor_newlen<<
(0x3e4+8630-0x2599))+(0x1d2+6554-0x1b6b);if(ReplacementFor_request->
ReplacementFor_cap>ReplacementFor_MAX_JSON_CAPACITY){}if(!(
ReplacementFor_request->ReplacementFor_ptr=(char*)realloc(ReplacementFor_request
->ReplacementFor_ptr,ReplacementFor_request->ReplacementFor_cap))){}}memcpy(
ReplacementFor_request->ReplacementFor_ptr+ReplacementFor_request->len,
ReplacementFor_ptr,size*ReplacementFor_nmemb);ReplacementFor_request->
ReplacementFor_ptr[ReplacementFor_newlen]='\0';ReplacementFor_request->len=
ReplacementFor_newlen;return size*ReplacementFor_nmemb;}int 
ReplacementFor_ToUppercase(char*str){for(int i=(0x0+7316-0x1c94);str[i]!='\0';++
i){str[i]=toupper(str[i]);}return EXIT_SUCCESS;}void ReplacementFor_CurlLogError
(ReplacementFor_CURLcode ReplacementFor_curl_status){if(
ReplacementFor_curl_status!=ReplacementFor_CURLE_OK){LOG(ERROR)<<
"\x43\x55\x52\x4c\x3a\x20"<<ReplacementFor_curl_easy_strerror(
ReplacementFor_curl_status);}return;}int ReplacementFor_ParseRequest(
ReplacementFor_json_t*ReplacementFor_oldreq,ReplacementFor_json_t*
ReplacementFor_newreq,ReplacementFor_info_t*ReplacementFor_info,int 
ReplacementFor_checkPubKey,long ReplacementFor_http_code){
ReplacementFor_jsmn_parser ReplacementFor_parser;int ReplacementFor_mesChanged=
(0x16f5+1650-0x1d67);int ReplacementFor_HChanged=(0x1971+856-0x1cc9);int 
ReplacementFor_boundChanged=(0x1629+1818-0x1d43);int 
ReplacementFor_ExtraBaseChanged=(0x27c+6131-0x1a6f);int 
ReplacementFor_ExtraSizeChanged=(0x692+1238-0xb68);ReplacementFor_ToUppercase(
ReplacementFor_newreq->ReplacementFor_ptr);ReplacementFor_jsmn_init(&
ReplacementFor_parser);int ReplacementFor_numtoks=ReplacementFor_jsmn_parse(&
ReplacementFor_parser,ReplacementFor_newreq->ReplacementFor_ptr,
ReplacementFor_newreq->len,ReplacementFor_newreq->ReplacementFor_toks,
ReplacementFor_REQ_LEN);if(ReplacementFor_numtoks<(0x1b52+1526-0x2148)){return 
EXIT_FAILURE;}int ReplacementFor_PkPos=-(0x445+8106-0x23ee);int 
ReplacementFor_BoundPos=-(0x70d+2049-0xf0d);int ReplacementFor_MesPos=-
(0x4a9+3277-0x1175);int ReplacementFor_HPos=-(0x195c+183-0x1a12);int 
ReplacementFor_ExtraBasePos=-(0x1b1f+3041-0x26ff);int 
ReplacementFor_ExtraSizePos=-(0x8a4+3200-0x1523);for(int i=(0x16c1+1545-0x1cc9);
i<ReplacementFor_numtoks;i+=(0x747+3093-0x135a)){if(ReplacementFor_newreq->
ReplacementFor_jsoneq(i,"\x42")){ReplacementFor_BoundPos=i+(0x355+5416-0x187c);}
else if(ReplacementFor_newreq->ReplacementFor_jsoneq(i,"\x50\x4b")){
ReplacementFor_PkPos=i+(0x1f0c+1800-0x2613);}else if(ReplacementFor_newreq->
ReplacementFor_jsoneq(i,"\x4d\x53\x47")){ReplacementFor_MesPos=i+
(0x22fd+596-0x2550);}else if(ReplacementFor_newreq->ReplacementFor_jsoneq(i,
"\x48")||ReplacementFor_newreq->ReplacementFor_jsoneq(i,
"\x48\x45\x49\x47\x48\x54")){ReplacementFor_HPos=i+(0x234+2572-0xc3f);}else if(
ReplacementFor_newreq->ReplacementFor_jsoneq(i,
"\x45\x58\x54\x52\x41\x4e\x4f\x4e\x43\x45\x31")){ReplacementFor_ExtraBasePos=i+
(0x64d+1977-0xe05);}else if(ReplacementFor_newreq->ReplacementFor_jsoneq(i,
"\x45\x58\x54\x52\x41\x4e\x4f\x4e\x43\x45\x32\x53\x49\x5a\x45")){
ReplacementFor_ExtraSizePos=i+(0x9a1+2876-0x14dc);}else{}}(ReplacementFor_HPos==
-(0x5a8+2760-0x106f))?ReplacementFor_info->ReplacementFor_AlgVer=
(0x71b+7087-0x22c9):ReplacementFor_info->ReplacementFor_AlgVer=
(0x68+7370-0x1d30);if(ReplacementFor_BoundPos<(0xa5a+1668-0x10de)||
ReplacementFor_MesPos<(0x4ca+1949-0xc67)||ReplacementFor_HPos<
(0x1ff1+1637-0x2656)){if(ReplacementFor_BoundPos<(0x656+2880-0x1196)&&
ReplacementFor_MesPos<(0x703+4664-0x193b)&&ReplacementFor_HPos<(0x77a+663-0xa11)
&&ReplacementFor_http_code==(0x414+917-0x6e1)){ReplacementFor_info->
ReplacementFor_doJob=false;}else{}return EXIT_FAILURE;}ReplacementFor_info->
ReplacementFor_doJob=true;if(ReplacementFor_checkPubKey){if(
ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_PkPos)!=
ReplacementFor_PK_SIZE_4){return EXIT_FAILURE;}if(strncmp(ReplacementFor_info->
ReplacementFor_pkstr,ReplacementFor_newreq->ReplacementFor_GetTokenStart(
ReplacementFor_PkPos),ReplacementFor_PK_SIZE_4)){char ReplacementFor_logstr[
(0xde8+3555-0x17e3)];ReplacementFor_PrintPublicKey(ReplacementFor_info->
ReplacementFor_pkstr,ReplacementFor_logstr);ReplacementFor_PrintPublicKey(
ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_PkPos),
ReplacementFor_logstr);exit(EXIT_FAILURE);}}int ReplacementFor_mesLen=
ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_MesPos);int 
ReplacementFor_boundLen=ReplacementFor_newreq->ReplacementFor_GetTokenLen(
ReplacementFor_BoundPos);int ReplacementFor_Hlen=ReplacementFor_newreq->
ReplacementFor_GetTokenLen(ReplacementFor_HPos);int ReplacementFor_ExtraBaseLen=
ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_ExtraBasePos);
int ReplacementFor_ExtraSizeLen=ReplacementFor_newreq->
ReplacementFor_GetTokenLen(ReplacementFor_ExtraSizePos);if(ReplacementFor_oldreq
->len){if(ReplacementFor_mesLen!=ReplacementFor_oldreq->
ReplacementFor_GetTokenLen(ReplacementFor_MesPos)){ReplacementFor_mesChanged=
(0x7cd+3757-0x1679);}else{ReplacementFor_mesChanged=strncmp(
ReplacementFor_oldreq->ReplacementFor_GetTokenStart(ReplacementFor_MesPos),
ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_MesPos),
ReplacementFor_mesLen);}if(ReplacementFor_boundLen!=ReplacementFor_oldreq->
ReplacementFor_GetTokenLen(ReplacementFor_BoundPos)){ReplacementFor_boundChanged
=(0x147c+2921-0x1fe4);}else{ReplacementFor_boundChanged=strncmp(
ReplacementFor_oldreq->ReplacementFor_GetTokenStart(ReplacementFor_BoundPos),
ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_BoundPos),
ReplacementFor_boundLen);}if(ReplacementFor_ExtraBasePos!=-(0x182d+3784-0x26f4))
{if(ReplacementFor_ExtraBaseLen!=ReplacementFor_oldreq->
ReplacementFor_GetTokenLen(ReplacementFor_ExtraBasePos)){
ReplacementFor_ExtraBaseChanged=(0xe59+2763-0x1923);}else{
ReplacementFor_ExtraBaseChanged=strncmp(ReplacementFor_oldreq->
ReplacementFor_GetTokenStart(ReplacementFor_ExtraBasePos),ReplacementFor_newreq
->ReplacementFor_GetTokenStart(ReplacementFor_ExtraBasePos),
ReplacementFor_ExtraBaseLen);}}if(ReplacementFor_ExtraSizePos!=-
(0xe5f+5360-0x234e)){if(ReplacementFor_ExtraSizeLen!=ReplacementFor_oldreq->
ReplacementFor_GetTokenLen(ReplacementFor_ExtraSizePos)){
ReplacementFor_ExtraSizeChanged=(0x3d7+8834-0x2658);}else{
ReplacementFor_ExtraSizeChanged=strncmp(ReplacementFor_oldreq->
ReplacementFor_GetTokenStart(ReplacementFor_ExtraSizePos),ReplacementFor_newreq
->ReplacementFor_GetTokenStart(ReplacementFor_ExtraSizePos),
ReplacementFor_ExtraSizeLen);}}ReplacementFor_HChanged=strncmp(
ReplacementFor_oldreq->ReplacementFor_GetTokenStart(ReplacementFor_HPos),
ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_HPos),
ReplacementFor_Hlen);}if(ReplacementFor_mesChanged||ReplacementFor_boundChanged
||!(ReplacementFor_oldreq->len)||ReplacementFor_HChanged||
ReplacementFor_ExtraBaseChanged||ReplacementFor_ExtraSizeChanged){
ReplacementFor_info->ReplacementFor_info_mutex.lock();ReplacementFor_info->
ReplacementFor_stratumMode=(0xcb8+4872-0x1fbf);if(ReplacementFor_ExtraBasePos==-
(0x1fa9+1062-0x23ce)){memset(ReplacementFor_info->ReplacementFor_extraNonceStart
,(0x124+4298-0x11ee),ReplacementFor_NONCE_SIZE_8);memset(ReplacementFor_info->
ReplacementFor_extraNonceEnd,(0x1d82+605-0x1fde),ReplacementFor_NONCE_SIZE_8);
ReplacementFor_info->ReplacementFor_stratumMode=(0x10a9+3452-0x1e25);}else if(!(
ReplacementFor_oldreq->len)||ReplacementFor_ExtraBaseChanged||
ReplacementFor_ExtraSizeChanged){if(ReplacementFor_ExtraSizeLen<=
(0x53a+4558-0x1708)){ReplacementFor_info->ReplacementFor_info_mutex.unlock();
return EXIT_FAILURE;}char*ReplacementFor_buff=new char[
ReplacementFor_ExtraSizeLen];memcpy(ReplacementFor_buff,ReplacementFor_newreq->
ReplacementFor_GetTokenStart(ReplacementFor_ExtraSizePos),
ReplacementFor_ExtraSizeLen);char*ReplacementFor_endptr;unsigned int 
ReplacementFor_iLen=strtoul(ReplacementFor_buff,&ReplacementFor_endptr,
(0xeb3+2787-0x198c));delete ReplacementFor_buff;ReplacementFor_iLen*=
(0x74c+4596-0x193e);if(ReplacementFor_info->ReplacementFor_stratumMode==
(0x8a+188-0x145)&&(ReplacementFor_iLen+ReplacementFor_ExtraBaseLen)!=
ReplacementFor_NONCE_SIZE_4){ReplacementFor_info->ReplacementFor_info_mutex.
unlock();return EXIT_FAILURE;}memset(ReplacementFor_info->
ReplacementFor_extraNonceStart,(0x9c5+52-0x9f9),ReplacementFor_NONCE_SIZE_8);
memset(ReplacementFor_info->ReplacementFor_extraNonceEnd,(0x470+6681-0x1e88),
ReplacementFor_NONCE_SIZE_8);char*ReplacementFor_NonceBase=new char[
ReplacementFor_ExtraBaseLen];memcpy(ReplacementFor_NonceBase,
ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_ExtraBasePos)
,ReplacementFor_ExtraBaseLen);char*ReplacementFor_StartNonce=new char[
ReplacementFor_NONCE_SIZE_4];memset(ReplacementFor_StartNonce,
((char)(0x1070+4657-0x2271)),ReplacementFor_NONCE_SIZE_4);char*
ReplacementFor_EndNonce=new char[ReplacementFor_NONCE_SIZE_4];memset(
ReplacementFor_EndNonce,((char)(0x2aa+1221-0x73f)),ReplacementFor_NONCE_SIZE_4);
memcpy(ReplacementFor_StartNonce,ReplacementFor_NonceBase,
ReplacementFor_ExtraBaseLen);memcpy(ReplacementFor_EndNonce,
ReplacementFor_NonceBase,ReplacementFor_ExtraBaseLen);memset(
ReplacementFor_EndNonce+ReplacementFor_ExtraBaseLen,((char)(0x46d+104-0x48f)),
ReplacementFor_iLen);ReplacementFor_HexStrToLittleEndian(
ReplacementFor_StartNonce,ReplacementFor_NONCE_SIZE_4,ReplacementFor_info->
ReplacementFor_extraNonceStart,ReplacementFor_NONCE_SIZE_8);
ReplacementFor_HexStrToLittleEndian(ReplacementFor_EndNonce,
ReplacementFor_NONCE_SIZE_4,ReplacementFor_info->ReplacementFor_extraNonceEnd,
ReplacementFor_NONCE_SIZE_8);delete ReplacementFor_NonceBase;delete 
ReplacementFor_StartNonce;delete ReplacementFor_EndNonce;}if(!(
ReplacementFor_oldreq->len)||ReplacementFor_mesChanged){
ReplacementFor_HexStrToBigEndian(ReplacementFor_newreq->
ReplacementFor_GetTokenStart(ReplacementFor_MesPos),ReplacementFor_newreq->
ReplacementFor_GetTokenLen(ReplacementFor_MesPos),ReplacementFor_info->
ReplacementFor_mes,ReplacementFor_NUM_SIZE_8);}if(!(ReplacementFor_oldreq->len)
||ReplacementFor_HChanged){char*ReplacementFor_buff=new char[ReplacementFor_Hlen
];memcpy(ReplacementFor_buff,ReplacementFor_newreq->ReplacementFor_GetTokenStart
(ReplacementFor_HPos),ReplacementFor_Hlen);char*ReplacementFor_endptr;unsigned 
int ReplacementFor_ul=strtoul(ReplacementFor_buff,&ReplacementFor_endptr,
(0xe46+1283-0x133f));ReplacementFor_info->ReplacementFor_Hblock[
(0x20b8+305-0x21e9)]=((uint8_t*)&ReplacementFor_ul)[(0x7d+6156-0x1886)];
ReplacementFor_info->ReplacementFor_Hblock[(0x8c5+4746-0x1b4e)]=((uint8_t*)&
ReplacementFor_ul)[(0x1195+3620-0x1fb7)];ReplacementFor_info->
ReplacementFor_Hblock[(0x1af7+916-0x1e89)]=((uint8_t*)&ReplacementFor_ul)[
(0x219+5164-0x1644)];ReplacementFor_info->ReplacementFor_Hblock[
(0x340+1275-0x838)]=((uint8_t*)&ReplacementFor_ul)[(0x1e1a+1688-0x24b2)];delete 
ReplacementFor_buff;}if(!(ReplacementFor_oldreq->len)||
ReplacementFor_boundChanged){char buf[ReplacementFor_NUM_SIZE_4+
(0xdc5+977-0x1195)];ReplacementFor_DecStrToHexStrOf64(ReplacementFor_newreq->
ReplacementFor_GetTokenStart(ReplacementFor_BoundPos),ReplacementFor_newreq->
ReplacementFor_GetTokenLen(ReplacementFor_BoundPos),buf);
ReplacementFor_HexStrToLittleEndian(buf,ReplacementFor_NUM_SIZE_4,
ReplacementFor_info->ReplacementFor_bound,ReplacementFor_NUM_SIZE_8);}
ReplacementFor_info->ReplacementFor_info_mutex.unlock();++(ReplacementFor_info->
ReplacementFor_blockId);}return EXIT_SUCCESS;}int ReplacementFor_GetLatestBlock(
const char*ReplacementFor_from,ReplacementFor_json_t*ReplacementFor_oldreq,
ReplacementFor_info_t*ReplacementFor_info,int ReplacementFor_checkPubKey){
ReplacementFor_CURL*ReplacementFor_curl;ReplacementFor_json_t 
ReplacementFor_newreq((0xe24+5060-0x21e8),ReplacementFor_REQ_LEN);
ReplacementFor_CURLcode ReplacementFor_curlError;ReplacementFor_curl=
ReplacementFor_curl_easy_init();if(!ReplacementFor_curl){}
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_URL,ReplacementFor_from));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_WRITEFUNCTION,ReplacementFor_WriteFunc));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_WRITEDATA,&ReplacementFor_newreq));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_CONNECTTIMEOUT,10L));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_TIMEOUT,30L));ReplacementFor_curlError=
ReplacementFor_curl_easy_perform(ReplacementFor_curl);long 
ReplacementFor_http_code=(0x15a2+430-0x1750);ReplacementFor_curl_easy_getinfo(
ReplacementFor_curl,ReplacementFor_CURLINFO_RESPONSE_CODE,&
ReplacementFor_http_code);ReplacementFor_CurlLogError(ReplacementFor_curlError);
ReplacementFor_curl_easy_cleanup(ReplacementFor_curl);if(!
ReplacementFor_curlError){int ReplacementFor_oldId=ReplacementFor_info->
ReplacementFor_blockId.load();if(ReplacementFor_ParseRequest(
ReplacementFor_oldreq,&ReplacementFor_newreq,ReplacementFor_info,
ReplacementFor_checkPubKey,ReplacementFor_http_code)!=EXIT_SUCCESS){return 
EXIT_FAILURE;}if(ReplacementFor_oldId!=ReplacementFor_info->
ReplacementFor_blockId.load()){FREE(ReplacementFor_oldreq->ReplacementFor_ptr);
FREE(ReplacementFor_oldreq->ReplacementFor_toks);*ReplacementFor_oldreq=
ReplacementFor_newreq;ReplacementFor_newreq.ReplacementFor_ptr=NULL;
ReplacementFor_newreq.ReplacementFor_toks=NULL;}return EXIT_SUCCESS;}
ReplacementFor_info->ReplacementFor_doJob=false;return EXIT_FAILURE;}int 
ReplacementFor_JobCompleted(const char*ReplacementFor_to){ReplacementFor_CURL*
ReplacementFor_curl;ReplacementFor_json_t ReplacementFor_newreq(
(0x14b0+4282-0x256a),ReplacementFor_REQ_LEN);ReplacementFor_CURLcode 
ReplacementFor_curlError;ReplacementFor_curl=ReplacementFor_curl_easy_init();if(
!ReplacementFor_curl){}ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,ReplacementFor_CURLOPT_URL,
ReplacementFor_to));ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(
ReplacementFor_curl,ReplacementFor_CURLOPT_WRITEFUNCTION,
ReplacementFor_WriteFunc));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_WRITEDATA,&ReplacementFor_newreq));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_CONNECTTIMEOUT,10L));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_TIMEOUT,30L));ReplacementFor_curlError=
ReplacementFor_curl_easy_perform(ReplacementFor_curl);
ReplacementFor_CurlLogError(ReplacementFor_curlError);
ReplacementFor_curl_easy_cleanup(ReplacementFor_curl);if(!
ReplacementFor_curlError){}return EXIT_SUCCESS;}int 
ReplacementFor_PostPuzzleSolution(const char*ReplacementFor_to,const uint8_t*
ReplacementFor_nonce){uint32_t len;uint32_t pos=(0xa1b+456-0xbe3);char 
ReplacementFor_request[ReplacementFor_JSON_CAPACITY];strcpy(
ReplacementFor_request+pos,"\x7b" "\"" "\x6e" "\"" "\x3a" "\"");pos+=
(0x842+4983-0x1bb3);ReplacementFor_LittleEndianToHexStr(ReplacementFor_nonce,
ReplacementFor_NONCE_SIZE_8,ReplacementFor_request+pos);pos+=
ReplacementFor_NONCE_SIZE_4;strcpy(ReplacementFor_request+pos,"\"}\0");
ReplacementFor_CURL*ReplacementFor_curl;ReplacementFor_curl=
ReplacementFor_curl_easy_init();if(!ReplacementFor_curl){}ReplacementFor_json_t 
ReplacementFor_respond((0x14f+6206-0x198d),ReplacementFor_REQ_LEN);
ReplacementFor_curl_slist*ReplacementFor_headers=NULL;ReplacementFor_curl_slist*
ReplacementFor_tmp;ReplacementFor_CURLcode ReplacementFor_curlError;
ReplacementFor_tmp=ReplacementFor_curl_slist_append(ReplacementFor_headers,
"\x41\x63\x63\x65\x70\x74\x3a\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"
);ReplacementFor_headers=ReplacementFor_curl_slist_append(ReplacementFor_tmp,
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"
);ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(
ReplacementFor_curl,ReplacementFor_CURLOPT_URL,ReplacementFor_to));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_HTTPHEADER,ReplacementFor_headers));;
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_POSTFIELDS,ReplacementFor_request));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_CONNECTTIMEOUT,30L));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_TIMEOUT,30L));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_WRITEFUNCTION,ReplacementFor_WriteFunc));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_WRITEDATA,&ReplacementFor_respond));int 
ReplacementFor_retries=(0x1fa8+1224-0x2470);do{ReplacementFor_curlError=
ReplacementFor_curl_easy_perform(ReplacementFor_curl);++ReplacementFor_retries;}
while(ReplacementFor_retries<ReplacementFor_MAX_POST_RETRIES&&
ReplacementFor_curlError!=ReplacementFor_CURLE_OK);ReplacementFor_CurlLogError(
ReplacementFor_curlError);ReplacementFor_curl_easy_cleanup(ReplacementFor_curl);
ReplacementFor_curl_slist_free_all(ReplacementFor_headers);return EXIT_SUCCESS;}

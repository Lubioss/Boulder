
#ifndef ReplacementFor_ReplacementFor_COMPACTION_H
#define ReplacementFor_ReplacementFor_COMPACTION_H
#include "ReplacementFor_definitions.h"
ReplacementFor_ReplacementFor___device__ uint32_t ReplacementFor_ReplacementFor_WarpInc(uint32_t*len);
ReplacementFor_ReplacementFor___global__ void ReplacementFor_ReplacementFor_Compactify(const uint32_t*in,const
 uint32_t ReplacementFor_ReplacementFor_inlen,uint32_t*out,uint32_t*ReplacementFor_ReplacementFor_outlen);
#endif 



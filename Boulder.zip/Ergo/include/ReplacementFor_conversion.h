
#ifndef ReplacementFor_CONVERSION_H
#define ReplacementFor_CONVERSION_H
#include <stdint.h>
int ReplacementFor_DecStrToHexStrOf64(const char*in,const uint32_t 
ReplacementFor_inlen,char*out);void ReplacementFor_HexStrToBigEndian(const char*
in,const uint32_t ReplacementFor_inlen,uint8_t*out,const uint32_t 
ReplacementFor_outlen);void ReplacementFor_HexStrToLittleEndian(const char*in,
const uint32_t ReplacementFor_inlen,uint8_t*out,const uint32_t 
ReplacementFor_outlen);void ReplacementFor_LittleEndianOf256ToDecStr(const 
uint8_t*in,char*out,uint32_t*ReplacementFor_outlen);void 
ReplacementFor_LittleEndianToHexStr(const uint8_t*in,const uint32_t 
ReplacementFor_inlen,char*out);void ReplacementFor_BigEndianToHexStr(const 
uint8_t*in,const uint32_t ReplacementFor_inlen,char*out);
#endif 


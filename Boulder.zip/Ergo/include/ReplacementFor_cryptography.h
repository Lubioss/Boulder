
#ifndef ReplacementFor_CRYPTOGRAPHY_H
#define ReplacementFor_CRYPTOGRAPHY_H
#include "ReplacementFor_conversion.h"
int ReplacementFor_GenerateSecKey(const char*in,const int len,uint8_t*
ReplacementFor_sk,char*ReplacementFor_skstr);int 
ReplacementFor_GenerateSecKeyNew(const char*in,const int len,uint8_t*
ReplacementFor_sk,char*ReplacementFor_skstr,char*message);int 
ReplacementFor_GenerateKeyPair(uint8_t*ReplacementFor_sk,uint8_t*
ReplacementFor_pk);int ReplacementFor_GeneratePublicKey(const char*
ReplacementFor_skstr,char*ReplacementFor_pkstr,uint8_t*ReplacementFor_pk);int 
ReplacementFor_checkRandomDevice();
#endif 


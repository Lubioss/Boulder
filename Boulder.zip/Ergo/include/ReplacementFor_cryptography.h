
#ifndef ReplacementFor_ReplacementFor_CRYPTOGRAPHY_H
#define ReplacementFor_ReplacementFor_CRYPTOGRAPHY_H
#include "ReplacementFor_conversion.h"
int ReplacementFor_ReplacementFor_GenerateSecKey(const char*in,const int len,uint8_t*
ReplacementFor_ReplacementFor_sk,char*ReplacementFor_ReplacementFor_skstr);int 
ReplacementFor_ReplacementFor_GenerateSecKeyNew(const char*in,const int len,uint8_t*
ReplacementFor_ReplacementFor_sk,char*ReplacementFor_ReplacementFor_skstr,char*message);int 
ReplacementFor_ReplacementFor_GenerateKeyPair(uint8_t*ReplacementFor_ReplacementFor_sk,uint8_t*
ReplacementFor_ReplacementFor_pk);int ReplacementFor_ReplacementFor_GeneratePublicKey(const char*
ReplacementFor_ReplacementFor_skstr,char*ReplacementFor_ReplacementFor_pkstr,uint8_t*ReplacementFor_ReplacementFor_pk);int 
ReplacementFor_ReplacementFor_checkRandomDevice();
#endif 



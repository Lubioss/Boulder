
#ifndef ReplacementFor_DEFINITIONS_H
#define ReplacementFor_DEFINITIONS_H
#include "ReplacementFor_jsmn.h" 
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <time.h>
#include <atomic>
#include <mutex>
#include <string.h>
#define ReplacementFor_CONST_MES_SIZE_8   8192 
#define ReplacementFor_CONTINUE_POS       ((0x10b4+6135-0x2357)+\
(0x82d+8063-0x2045)-3223)
#define ReplacementFor_K_LEN              (6307+(0xba3+1424-0x834)-8578)
#define ReplacementFor_N_LEN              67108864 
#define ReplacementFor_MAX_SOLS ((0x166b+1917-0x1d59)+(0xff7+5382-0x166e)-\
(0x1d5f+1519-0x1440))
#define ReplacementFor_NONCES_PER_THREAD  (3421+(0x1eed+3077-0x13b4)-9370)
#define ReplacementFor_MIN_FREE_MEMORY    2200000000
#define ReplacementFor_MIN_FREE_MEMORY_PREHASH 7300000000
#define ReplacementFor_NUM_SIZE_8         ((0x1479+1424-0xfc4)+\
(0x12aa+1243-0xd86)-5156)
#define ReplacementFor_PK_SIZE_8          ((0x5ea+3960-0x1041)+\
(0x22b4+4172-0x1c5a)-7078)
#define ReplacementFor_NONCE_SIZE_8       ((0x22a2+1118-0x2265)+\
(0x2437+3206-0x2379)-(0x14ad+3248-0xf86))
#define ReplacementFor_HEIGHT_SIZE       ((0x18c7+1684-0x1a73)+\
(0x222b+2507-0x11b5)-7973)
#define ReplacementFor_INDEX_SIZE_8       ((0x1add+6131-0x2031)+\
(0x1fb6+475-0x1ce1)-5963)
#define ReplacementFor_BUF_SIZE_8         ((0x2324+3852-0x178a)+\
(0xa1b+7191-0x2599)-(0x202f+1490-0xb42))
#define ReplacementFor_qhi_s              \
"\x30\x78\x46\x46\x46\x46\x46\x46\x46\x46"
#define ReplacementFor_q4_s               \
"\x30\x78\x46\x46\x46\x46\x46\x46\x46\x45"
#define ReplacementFor_q3_s               \
"\x30\x78\x42\x41\x41\x45\x44\x43\x45\x36"
#define ReplacementFor_q2_s               \
"\x30\x78\x41\x46\x34\x38\x41\x30\x33\x42"
#define ReplacementFor_q1_s               \
"\x30\x78\x42\x46\x44\x32\x35\x45\x38\x43"
#define ReplacementFor_q0_s               \
"\x30\x78\x44\x30\x33\x36\x34\x31\x34\x31"
#define ReplacementFor_Q3                 0xffffffffffffffff
#define ReplacementFor_Q2                 0xfffffffffffffffe
#define ReplacementFor_Q1                 0xbaaedce6af48a03b
#define ReplacementFor_Q0                 0xbfd25e8cd0364141
#define ReplacementFor_MAX_POST_RETRIES   ((0x2290+367-0x1f95)+\
(0x1a35+8850-0x269e)-6798)
#define ReplacementFor_MAX_URL_SIZE       ((0x2540+8185-0x2493)+\
(0x1a72+2464-0x1f71)-8519)
#define ReplacementFor_JSON_CAPACITY      ((0x1863+2972-0x1e65)+\
(0x21d5+3313-0x19e5)-(0x1e00+8093-0x2422))
#define ReplacementFor_MAX_JSON_CAPACITY  8192
#define ReplacementFor_REQ_LEN           ((0x1df7+157-0xfd1)+(0x1695+232-0x13c5)\
-(0x198a+856-0xa72))
#define ReplacementFor_MES_POS            ((0x548+9193-0x25fc)+\
(0x5c0+6899-0x1e87)-(0x69b+4032-0x10fc))
#define ReplacementFor_BOUND_POS          ((0x11fb+5666-0x2434)+8722-9719)
#define ReplacementFor_PK_POS             ((0xf42+4748-0x1c49)+\
(0x182c+8150-0x2663)-(0x17ed+257-0x1d0))
#define ReplacementFor_CONF_LEN           ((0x2693+5737-0x21c8)+2301-9244)
#define ReplacementFor_SEED_POS           ((0x1bf2+410-0x1973)+\
(0x18ac+3055-0x2306)-(0x1096+3319-0x17e1))
#define ReplacementFor_NODE_POS           ((0x117c+2226-0xe0f)+\
(0x6a4+9137-0x2636)-(0x1368+3257-0xfe7))
#define ReplacementFor_KEEP_POS           ((0x15f6+1830-0xea6)+\
(0x1d89+5636-0x1f79)-(0x25d7+7945-0x225c))
#define ReplacementFor_ERROR_STAT         "\x73\x74\x61\x74"
#define ReplacementFor_ERROR_ALLOC        \
\
"\x48\x6f\x73\x74\x20\x6d\x65\x6d\x6f\x72\x79\x20\x61\x6c\x6c\x6f\x63\x61\x74\x69\x6f\x6e"
#define ReplacementFor_ERROR_IO           "\x49\x2f\x4f"
#define ReplacementFor_ERROR_CURL         "\x43\x75\x72\x6c"
#define ReplacementFor_ERROR_OPENSSL      "\x4f\x70\x65\x6e\x53\x53\x4c"
#define ReplacementFor_NUM_SIZE_4         (ReplacementFor_NUM_SIZE_8 << \
((0x1558+343-0x15b3)+9670-9921))
#define ReplacementFor_NUM_SIZE_32        (ReplacementFor_NUM_SIZE_8 >> \
((0x1510+6722-0x1edc)+(0xde8+7110-0x2517)-(0x18e2+5816-0x1a8f)))
#define ReplacementFor_NUM_SIZE_64        (ReplacementFor_NUM_SIZE_8 >> \
((0x105b+1529-0xa65)+(0x16f0+3738-0x21f5)-(0x1bbb+3131-0x1875)))
#define ReplacementFor_NUM_SIZE_32_BLOCK  (((0x1330+5751-0x1fb2)+\
(0x25e5+329-0x25ee)-(0xd39+253-0x302)) + (\
ReplacementFor_NUM_SIZE_32 - ((0x156c+3871-0x23f9)+(0x1284+2803-0x1c7f)-\
(0x1a8c+631-0x1b7a))) / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_NUM_SIZE_8_BLOCK   (ReplacementFor_NUM_SIZE_32_BLOCK << \
((0xdfb+5695-0x17fb)+(0x1101+7326-0x1fb2)-(0x20a5+6221-0x1ec8)))
#define ReplacementFor_ROUND_NUM_SIZE_32  (ReplacementFor_NUM_SIZE_32_BLOCK * \
ReplacementFor_BLOCK_DIM)
#define ReplacementFor_PK_SIZE_4          (ReplacementFor_PK_SIZE_8 << \
((0x1020+3938-0x13d8)+(0x1728+957-0x19bf)-(0x151b+1623-0xea3)))
#define ReplacementFor_PK_SIZE_32_BLOCK   (((0xed7+3124-0x1293)+\
(0x1be3+2775-0x23a0)-(0x2173+4371-0x26f5)) + \
ReplacementFor_NUM_SIZE_32 / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_PK_SIZE_8_BLOCK    (ReplacementFor_PK_SIZE_32_BLOCK << \
((0xba3+6836-0x1b0b)+(0xe28+5928-0x22ff)-(0x1335+4985-0x1913)))
#define ReplacementFor_ROUND_PK_SIZE_32   (ReplacementFor_PK_SIZE_32_BLOCK * \
ReplacementFor_BLOCK_DIM)
#define ReplacementFor_COUPLED_PK_SIZE_32 (((ReplacementFor_PK_SIZE_8 << \
((0x8ff+7996-0x26a3)+(0x2607+3759-0x2293)-(0x13bc+9602-0x2584))) + (\
(0x1e62+2504-0x2587)+(0x22e8+3828-0x11cd)-8879)) >> ((0x1247+1502-0x625)+\
(0x1dd2+1973-0x1f74)-(0x1d7b+1948-0xd06)))
#define ReplacementFor_NONCE_SIZE_4       (ReplacementFor_NONCE_SIZE_8 << \
((0x15f8+2410-0xe86)+(0x10c2+121-0x6c9)-6989))
#define ReplacementFor_NONCE_SIZE_32      (ReplacementFor_NONCE_SIZE_8 >> \
((0xb43+1236-0xc1e)+(0x1829+5835-0x24f8)-(0x21cb+4292-0x249c)))
struct ReplacementFor_ctx_t;
#define ReplacementFor_DATA_SIZE_8\
                                                            \
(                                                                              \
    (((0xd37+867-0x804)+(0x138c+2353-0xa71)-6881) + (((0xdac+2992-0x16fc)+\
(0x25d1+2509-0x1ac9)-(0x1ae0+8996-0x26d1)) * ReplacementFor_PK_SIZE_8 + \
((0x1f67+792-0x1770)+(0x19bf+3741-0x1ce5)-(0x1e69+4282-0x189f)) + (4310+\
(0xdaa+6335-0x1b4b)-(0x1d9d+2386-0xafe)) * ReplacementFor_NUM_SIZE_8 + sizeof(\
ReplacementFor_ctx_t) - (6625+(0x92c+3334-0xd5b)-8887)) / \
ReplacementFor_BLOCK_DIM) \
    * ReplacementFor_BLOCK_DIM\
                                                                \
)
#define ReplacementFor_WORKSPACE_SIZE_8\
                                                       \
(                                                                              \
    (                                                                          \
        (uint32_t)((ReplacementFor_N_LEN << ((0x1d25+715-0x1e11)+\
(0x1233+4981-0x23c6)-(0xaa1+2809-0x11da))) + \
((0x21e2+2858-0x2244)+(0x85c+1144-0x6d9)-(0x22e7+3636-0x2059))) * \
ReplacementFor_INDEX_SIZE_8                            \
        > ReplacementFor_NONCES_PER_ITER * (ReplacementFor_NUM_SIZE_8  + (\
ReplacementFor_INDEX_SIZE_8 << (5085+(0x1e49+573-0x193e)-6948))) + \
ReplacementFor_INDEX_SIZE_8 \
    )?                                                                         \
    (uint32_t)((ReplacementFor_N_LEN << ((0x11b4+7466-0x203e)+\
(0x2645+3007-0x1c0e)-9365)) + ((0x1686+3207-0x21d3)+(0xa43+3830-0x15c7)-\
(0x1640+310-0x12cb))\
) * ReplacementFor_INDEX_SIZE_8:                               \
    ReplacementFor_NONCES_PER_ITER * (ReplacementFor_NUM_SIZE_8  + (\
ReplacementFor_INDEX_SIZE_8 << ((0x1af4+1426-0x1d0a)+8352-9243))) + \
ReplacementFor_INDEX_SIZE_8       \
)
#define ReplacementFor_NP_SIZE_32_BLOCK   (((0x123f+6038-0x1d65)+\
(0x305+4673-0x142f)-3462) + (\
ReplacementFor_NUM_SIZE_32 << ((0x13c7+3481-0x1c74)+5944-(0x1c78+6717-0x1a92))) \
/ ReplacementFor_BLOCK_DIM)
#define ReplacementFor_NP_SIZE_8_BLOCK    (ReplacementFor_NP_SIZE_32_BLOCK << \
(5823+(0x1c6d+3768-0x21ee)-8180))
#define ReplacementFor_ROUND_NP_SIZE_32   (ReplacementFor_NP_SIZE_32_BLOCK * \
ReplacementFor_BLOCK_DIM)
#define ReplacementFor_PNP_SIZE_32_BLOCK\
                                                      \
(((0xea4+9533-0x269b)+(0x2221+771-0x1e3c)-(0x26d8+1999-0x1a7a)) + (\
ReplacementFor_COUPLED_PK_SIZE_32 + \
ReplacementFor_NUM_SIZE_32 - ((0x230f+3482-0x1c36)+(0x48b+2246-0xb68)-\
(0x242f+4500-0x1f68))) / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_PNP_SIZE_8_BLOCK   (ReplacementFor_PNP_SIZE_32_BLOCK << \
((0x1a36+2419-0xc84)+(0x1759+1957-0x10bc)-(0x257b+4209-0x1087)))
#define ReplacementFor_ROUND_PNP_SIZE_32  (ReplacementFor_PNP_SIZE_32_BLOCK * \
ReplacementFor_BLOCK_DIM)
#define ReplacementFor_NC_SIZE_32_BLOCK\
                                                       \
(((0x1272+2114-0x1651)+8701-9823) + (ReplacementFor_NUM_SIZE_32 + sizeof(\
ReplacementFor_ctx_t\
) - ((0xdb8+647-0x337)+(0x1dff+1399-0x1283)-7674)) / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_NC_SIZE_8_BLOCK    (ReplacementFor_NC_SIZE_32_BLOCK << \
((0x95a+312-0x37c)+(0x132d+1145-0x984)-5430))
#define ReplacementFor_ROUND_NC_SIZE_32   (ReplacementFor_NC_SIZE_32_BLOCK * \
ReplacementFor_BLOCK_DIM)
#define ReplacementFor_N_MASK             (ReplacementFor_N_LEN - \
((0x1f83+1795-0x1c36)+7334-9973))
#define ReplacementFor_THREADS_PER_ITER   (ReplacementFor_NONCES_PER_ITER / \
ReplacementFor_NONCES_PER_THREAD)
typedef unsigned int ReplacementFor_uint_t;typedef enum{
ReplacementFor_STATE_CONTINUE=((0x25ba+1011-0x25e7)+(0x2455+3412-0x1365)-8714),
ReplacementFor_STATE_KEYGEN=((0x1196+7097-0x2625)+(0x1915+6597-0x1deb)-7192),
ReplacementFor_STATE_REHASH=((0x702+6536-0x1f60)+(0x2084+145-0x1e10)-
(0x4ff+7683-0x1ed5)),ReplacementFor_STATE_INTERRUPT=((0x1c72+2814-0x1f0b)+
(0x1b2f+1826-0x871)-8770)}ReplacementFor_state_t;struct ReplacementFor_info_t{
std::mutex ReplacementFor_info_mutex;uint8_t ReplacementFor_AlgVer;uint8_t 
ReplacementFor_bound[ReplacementFor_NUM_SIZE_8];uint8_t ReplacementFor_mes[
ReplacementFor_NUM_SIZE_8];uint8_t ReplacementFor_sk[ReplacementFor_NUM_SIZE_8];
uint8_t ReplacementFor_pk[ReplacementFor_PK_SIZE_8];char ReplacementFor_skstr[
ReplacementFor_NUM_SIZE_4];char ReplacementFor_pkstr[ReplacementFor_PK_SIZE_4+(
(0x23f9+1113-0x227f)+6479-7969)];int ReplacementFor_keepPrehash;char 
ReplacementFor_to[ReplacementFor_MAX_URL_SIZE];char ReplacementFor_endJob[
ReplacementFor_MAX_URL_SIZE];bool ReplacementFor_doJob;char ReplacementFor_pool[
ReplacementFor_MAX_URL_SIZE];uint8_t ReplacementFor_Hblock[
ReplacementFor_HEIGHT_SIZE];char ReplacementFor_stratumMode;uint8_t 
ReplacementFor_extraNonceStart[ReplacementFor_NONCE_SIZE_8];uint8_t 
ReplacementFor_extraNonceEnd[ReplacementFor_NONCE_SIZE_8];std::atomic<
ReplacementFor_uint_t>ReplacementFor_blockId;};struct ReplacementFor_json_t{
size_t ReplacementFor_cap;size_t len;char*ReplacementFor_ptr;
ReplacementFor_jsmntok_t*ReplacementFor_toks;ReplacementFor_json_t(const int 
strlen,const int ReplacementFor_toklen);ReplacementFor_json_t(const 
ReplacementFor_json_t&ReplacementFor_newjson);~ReplacementFor_json_t(void);void 
Reset(void){len=((0x1d75+1408-0x1093)+(0x1936+4519-0x2424)-6427);return;}int 
ReplacementFor_GetTokenStartPos(const int pos){return ReplacementFor_toks[pos].
ReplacementFor_start;}int ReplacementFor_GetTokenEndPos(const int pos){return 
ReplacementFor_toks[pos].end;}int ReplacementFor_GetTokenLen(const int pos){
return ReplacementFor_toks[pos].end-ReplacementFor_toks[pos].
ReplacementFor_start;}char*ReplacementFor_GetTokenStart(const int pos){return 
ReplacementFor_ptr+ReplacementFor_toks[pos].ReplacementFor_start;}char*
ReplacementFor_GetTokenEnd(const int pos){return ReplacementFor_ptr+
ReplacementFor_toks[pos].end;}int ReplacementFor_jsoneq(const int pos,const char
*str);};struct ReplacementFor_ctx_t{uint8_t b[ReplacementFor_BUF_SIZE_8];
uint64_t ReplacementFor_h[((0x219d+937-0xe9d)+(0x1008+5626-0x21ec)-
(0x1ad1+6182-0x1840))];uint64_t t[((0x2513+1305-0x15d7)+3867-9070)];uint32_t c;}
;struct ReplacementFor_uctx_t{uint64_t ReplacementFor_h[((0x2172+5105-0x22b9)+
(0x13fa+5341-0x15ea)-9615)];uint64_t t[((0x16e0+5102-0x15d4)+(0x84b+5308-0x1627)
-7128)];};
#define ReplacementFor_CTX_SIZE sizeof(ReplacementFor_ctx_t)
#define ReplacementFor_B2B_IV(ReplacementFor_v)\
                                                              \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_v))[((0xb45+1757-0x83f)+5228-7759)] = \
0x6a09e667f3bcc908;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[((0x5f3+7248-0x1c6d)+8352-9845)] = \
0xbb67ae8584caa73b;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[((0x1627+934-0x98a)+(0x4d0+6221-0x1c54)-\
(0x113a+2089-0x859))] = 0x3c6ef372fe94f82b;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[((0xbda+4154-0x17f7)+(0x250b+5819-0x1f1a)-\
8390)] = 0xa54ff53a5f1d36f1;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[((0xbfb+1398-0xd5c)+(0x1c95+645-0x1df2)-\
(0x1a68+2149-0x1d94))] = 0x510e527fade682d1;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[((0x128d+4073-0x1ec0)+(0x1111+7204-0x1c60)-\
5254)] = 0x9b05688c2b3e6c1f;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[((0xfdd+6068-0x1f87)+(0xbf+9523-0x25c1)-\
(0xb4f+2244-0xbde))] = 0x1f83d9abfb41bd6b;\
                                 \
    ((uint64_t *)(ReplacementFor_v))[(4975+(0xec2+412-0x95c)-\
(0x1cad+8910-0x2511))] = 0x5be0cd19137e2179;\
                                 \
}                                                                              \
while (((0x72a+1246-0x8bb)+8085-(0x231f+2146-0x89f)))
#define ReplacementFor_ROTR64(x, y) (((x) >> (y)) ^ ((x) << ((\
(0x7b1+3317-0x1426)+(0xde4+2146-0x918)-(0x1865+7097-0x26b0)) -\
 (y))))
#define ReplacementFor_B2B_G(ReplacementFor_v, a, b, c, ReplacementFor_d, x, y)\
                                             \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_v))[a] += ((uint64_t *)(ReplacementFor_v))[b] +\
 x;                          \
    ((uint64_t *)(ReplacementFor_v))[ReplacementFor_d]\
                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[\
ReplacementFor_d] ^ ((uint64_t *)(ReplacementFor_v))[a], ((0x1856+8378-0x2140)+\
(0x6b6+6517-0x1aa1)-7482));\
             \
    ((uint64_t *)(ReplacementFor_v))[c] += ((uint64_t *)(ReplacementFor_v))[\
ReplacementFor_d];                              \
    ((uint64_t *)(ReplacementFor_v))[b]\
                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[b] ^ ((uint64_t\
 *)(ReplacementFor_v))[c], ((0x156b+4766-0x25f6)+(0x1420+5431-0x1d92)-\
(0x1cd2+5801-0x25bb)));             \
    ((uint64_t *)(ReplacementFor_v))[a] += ((uint64_t *)(ReplacementFor_v))[b] +\
 y;                          \
    ((uint64_t *)(ReplacementFor_v))[ReplacementFor_d]\
                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[\
ReplacementFor_d] ^ ((uint64_t *)(ReplacementFor_v))[a], ((0x221b+2056-0x1f40)+\
6834-9605));\
             \
    ((uint64_t *)(ReplacementFor_v))[c] += ((uint64_t *)(ReplacementFor_v))[\
ReplacementFor_d];                              \
    ((uint64_t *)(ReplacementFor_v))[b]\
                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[b] ^ ((uint64_t\
 *)(ReplacementFor_v))[c], (2726+3559-(0x197d+9475-0x2632)));             \
}                                                                              \
while (((0x2051+2676-0x247e)+(0x13c2+4411-0x1d55)-(0x10e1+6557-0x1c8f)))
#define ReplacementFor_B2B_MIX(ReplacementFor_v, m)\
                                                          \
do                                                                             \
{                                                                              \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xd6f+3986-0x100a)+\
(0x20cf+5113-0x1ce4)-(0x24f4+6818-0x1abb)), \
((0xcf0+4412-0x1657)+(0xfd6+8271-0x223e)-(0x1a9d+360-0x64d)),  (\
(0xd0a+6456-0x2498)+8845-9263), (6071+(0x1646+429-0xcb1)-8941), ((uint64_t *)(m\
))[ ((0x6a0+7456-0x1d53)+(0x1c8a+6317-0x2564)-(0x201c+1331-0xf0f))], ((uint64_t \
*)(m))[ ((0x705+5575-0x19e4)+(0x124d+810-0xc6c)-(0x14f5+1112-0xd5b))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x20ad+1579-0x231e)+5795-\
(0x2253+234-0x8e1)), \
(3930+(0x946+5524-0x1bdb)-(0x25c2+807-0x1695)),  ((0x1102+2700-0x11ad)+\
(0x13eb+1009-0x17a9)-(0xaa2+2212-0x93b)), (4999+(0x14c2+607-0x16dd)-\
(0x1c36+1566-0xe96)), ((uint64_t *)(m))[ \
((0x175b+3961-0x1e49)+(0x21c3+4901-0x2153)-(0x1f15+7003-0x1e52))], ((uint64_t *)\
(m))[ (3668+(0xf92+6560-0x25c0)-(0x261f+1783-0x1b53))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x802+1297-0x9c6)+\
(0x1030+1186-0xd1a)-(0x1190+7078-0x2233)), \
((0x6dd+1830-0xcef)+6357-(0x2271+21-0x8a3)), ((0x217b+3781-0x2657)+\
(0xb18+4857-0x1b47)-(0xcc9+5185-0x1461)), (3746+(0x1fa1+6211-0x24d3)-8613), ((\
uint64_t *)(m))[ \
(6447+(0xeb9+1236-0x12cd)-6635)], ((uint64_t *)(m))[ (4650+(0xb77+6090-0x1b4b)-\
(0x2118+2190-0xf8b))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x86a+8990-0x2594)+\
(0x1bdb+4843-0x13f0)-(0x23da+233-0x3fc)), \
((0x5a2+9287-0x2630)+(0xddb+6545-0x2411)-(0x8ff+6108-0x19ce)), (\
(0x177a+2284-0x1750)+(0x26b7+1781-0x24c2)-(0x17f8+4162-0x1645)), (\
(0x1f1b+4107-0x103d)+(0x13e6+2144-0x16eb)-9269), ((uint64_t *)(m))[\
 ((0x13dc+3564-0x170e)+(0x1e4a+6248-0x1df5)-9073)], ((uint64_t *)(m))[ (\
(0x1d6f+1983-0x24fa)+8539-8584)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x15db+1276-0x191e)+\
(0xd6f+4042-0x1cfd)-(0xfc1+6010-0x2546)), ((0x10f2+4807-0x1562)+5850-9516)\
, ((0xf23+3531-0xfb2)+(0x1b70+888-0x184b)-(0x21b4+5503-0x2364)), (\
(0x1e24+1728-0x18ff)+3279-(0x1c97+3191-0x1069)), ((uint64_t *)(m))[ \
((0x36d+5723-0x18e5)+(0x25b8+4281-0x1680)-8396)], ((uint64_t *)(m))[ (\
(0xb60+5660-0x17d2)+(0xb49+6045-0x2039)-(0xf06+3730-0x114a))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x2111+3487-0x2655)+4963-7101), \
((0x8d1+8226-0x20e2)+(0x17a8+2021-0xf19)-6271), (2892+(0x5b5+388-0x566)-3348), (\
(0x37b+5453-0x16d9)+(0x3b9+299-0x2bf)-(0xee0+5296-0x1f88)), ((uint64_t *)(m))[\
((0x701+6429-0x1e6d)+(0x163f+4346-0x1d4e)-(0x1118+1884-0xce2))], ((uint64_t *)(m\
))[((0x1e38+739-0x1c45)+4921-6148)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (4498+3866-8362), \
((0x11a7+2295-0x1166)+(0x83a+1367-0xa6f)-(0xdf3+1456-0x750)),  (\
(0x8c1+6301-0x1e44)+(0x1cc3+3325-0x2471)-(0xf64+979-0xad6)), (8884+\
(0x1b16+1164-0x1f4c)-8957), ((uint64_t *)(m))[\
((0xb3d+4346-0x1221)+2317-(0x1a61+4331-0x1835))], ((uint64_t *)(m))[(\
(0x143a+3324-0x16e0)+(0x26b8+107-0x1a00)-(0x1af7+7315-0x201e))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x17a8+208-0xb10)+4516-\
(0x2370+8193-0x2468)), \
((0x1891+3849-0x1d2e)+(0x1b76+1161-0x1128)-(0x2691+3016-0x191a)),  (\
(0x106c+7107-0x24e5)+2924-(0x1a82+4653-0x1a02)), ((0x2196+1737-0x9a2)+\
(0x31f+3860-0x1188)-8026), ((uint64_t *)(m)\
)[((0x24a2+2726-0x21cd)+6085-9522)], ((uint64_t *)(m))[((0x18e7+1555-0xe52)+\
(0x1449+4526-0x1689)-8199)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1feb+922-0x2185)+\
(0x1fe9+1087-0x9fa)-7214), \
((0x15a1+8595-0x2584)+(0x12ed+2236-0x19fb)-(0x19cc+7644-0x244e)),  (\
(0x142c+6065-0x183a)+(0x18b0+3010-0x1d38)-6869), ((0x12b5+8385-0x25ea)+\
(0x1a57+2411-0x1a69)-5849), ((uint64_t *)(m\
))[((0xec3+6764-0x2344)+(0x1fa7+423-0x1ac0)-(0x1c5a+3742-0x1e8d))], ((uint64_t *\
)(m))[((0x2652+2412-0x18bd)+(0xf1d+2827-0xf31)-8686)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x3cc+3574-0x1100)+\
(0xe93+1622-0xa2f)-(0x2562+1073-0x1e18)), \
((0x151f+762-0xe52)+(0x167c+2296-0xec9)-6765),  ((0x1ee8+274-0x184b)+\
(0x2231+1716-0xf9c)-8431), ((0xe58+3665-0x1ba9)+(0x1924+2807-0x1088)-\
(0x2107+6466-0x25c3)), ((uint64_t *)(m)\
)[ (3395+(0x136d+3524-0x1616)-(0x1dff+8339-0x2638))], ((uint64_t *)(m))[ (\
(0x1ef6+2525-0x2024)+(0x1818+4158-0x1145)-8120)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1402+797-0xdba)+\
(0x1c71+8092-0x243f)-8497), \
((0x1465+7136-0x25e9)+(0x1c97+2496-0xa3d)-9840), (8079+(0x81d+6075-0x1f6a)-\
(0x250d+1069-0x947)), (5771+(0x1426+2650-0x1813)-7402), ((uint64_t *)(m)\
)[ ((0x616+6630-0x1fd7)+2348-2376)], ((uint64_t *)(m))[((0x88f+6522-0x1e46)+\
(0x1c3a+4095-0x1e3a)-(0x2342+2300-0x1a8b))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x120a+2714-0x13db)+2325-\
(0x17b5+3676-0x1436)), \
(9121+(0x134a+3357-0x1f8b)-9334), ((0x765+7991-0x24c1)+(0x2071+5227-0x1d9f)-\
(0x1da7+2533-0xe7f)), ((0x186f+5609-0x23b7)+(0x26cc+3684-0x20f0)-\
(0x215f+538-0x4a7)), ((uint64_t *)(m))\
[((0x1580+777-0x570)+(0x1017+2103-0x12a1)-6329)], ((uint64_t *)(m))[ (\
(0x1567+6798-0x1bdf)+(0x1578+6281-0x1e42)-9167)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x740+7115-0x22a7)+\
(0x920+6689-0x204e)-(0x6d0+8064-0x22f9)), \
((0x165a+409-0x441)+(0x1238+5172-0x1f64)-6837), ((0x204b+2655-0x2184)+\
(0x2488+873-0x1846)-(0x1a5c+6890-0x1c7f)), (8301+(0x4fa+4688-0x13f9)-9135), ((\
uint64_t *)(m)\
)[ ((0x1dcd+2892-0x12ba)+(0x9b4+6687-0x22b1)-(0x24aa+5577-0x22f3))], ((uint64_t \
*)(m))[((0x26c6+2627-0x24b8)+(0x1545+8402-0x24f7)-7525)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (8679+(0x576+4355-0x1519)-9030), \
((0x242b+2152-0x1d74)+(0x1a0f+648-0x1369)-(0x23da+2483-0x1546)), (\
(0x126a+1594-0x128b)+(0x13e3+3715-0x10ed)-(0x1875+6887-0x1bd5)), (\
(0xab7+6922-0x1ddd)+(0x14fd+5231-0x1c35)-5391), ((uint64_t *)(m))\
[ ((0x11a9+5230-0x1a43)+5319-8347)], ((uint64_t *)(m))[ ((0x187c+3904-0x1533)+\
(0xdf1+3409-0xe0c)-8125)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x199+8893-0x244e)+\
(0xb0a+7316-0x25e5)-(0xaaf+6958-0x241e)), ((0xa35+5299-0x1a18)+8165-9390),\
  ((0x1e5b+2866-0x1831)+(0x1190+4420-0x1b76)-6322), ((0x15b0+1848-0xc33)+4980-\
9244), ((uint64_t *)(m))[\
(5211+(0x882+1477-0x98a)-(0x1d5a+6659-0x1e50))], ((uint64_t *)(m))[ (\
(0x226d+850-0x996)+(0x203b+1744-0x1d58)-9685)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1685+2729-0x1e16)+\
(0x1a10+733-0x1279)-(0x1a0b+5340-0x215e)), \
((0x1807+3502-0x1b16)+(0x15e9+8664-0x23d3)-7817),  ((0x1a63+5354-0x1757)+\
(0x1947+1474-0x15fe)-8440), (8317+(0x20e8+1953-0x221e)-9946), ((uint64_t *)(\
m))[ ((0x24f1+424-0x2149)+(0x9a8+7345-0x1fdf)-(0x1257+3827-0x1585))], ((uint64_t\
 *)(m))[ ((0x338+836-0x3c2)+(0x1426+2618-0x1269)-(0x2461+3562-0x239d))]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, (6624+(0x1de8+1034-0x18a0)-9010), \
(8525+(0xe63+445-0xfdc)-8589),  ((0x2138+6624-0x259b)+(0xb02+6377-0x1fec)-6516),\
 ((0x1529+246-0x1405)+5381-5907), ((uint64_t *)(m)\
)[((0x10bf+5287-0x1a81)+6456-9234)], ((uint64_t *)(m))[ ((0xcfa+1165-0xf18)+\
(0x2206+3146-0x1135)-(0x20bc+9651-0x26ed))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x14e4+5644-0x1bc1)+\
(0x6e5+3247-0x118c)-(0x1fbf+2317-0x1796)), \
((0x233c+1281-0x2388)+(0x19ec+570-0x1417)-(0x16c8+4917-0x1d3e)),  (\
(0x5c9+1901-0x91e)+5231-(0x1a0c+1956-0x932)), ((0x1977+7823-0x25af)+\
(0x725+230-0x210)-6213), ((uint64_t *)(m)\
)[((0x15e4+6080-0x1a17)+(0x1668+7498-0x24b0)-(0x26e2+7017-0x1fc8))], ((uint64_t \
*)(m))[ ((0x1346+624-0xd25)+(0x14f3+804-0xdcc)-4828)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1cd3+3976-0x259f)+\
(0x129d+264-0xf2b)-(0xe49+9167-0x26e4)), \
((0x10a2+337-0x10dc)+(0x5e8+4073-0x10cf)-(0xeea+5467-0x1e32)), (6811+\
(0x858+4694-0x181a)-(0x26cd+1126-0xe0e)), ((0xf48+4467-0x1724)+\
(0x2092+2354-0x21c3)-(0x24ec+125-0x13df)), ((uint64_t *)(m))[\
 (6354+(0x1ea6+1885-0x1e80)-8272)], ((uint64_t *)(m))[ ((0x1591+3532-0x1251)+\
(0x1439+5012-0x1f54)-6531)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xff4+4162-0x1d23)+\
(0x14bf+484-0x2b0)-5891), \
((0x1fc1+5158-0x1ac2)+(0xd6d+3944-0x12ad)-9030), ((0xe21+1546-0x13d7)+9762-9835)\
, ((0xa4c+7955-0x256e)+(0x2241+875-0x717)-(0x26db+6370-0x1d46)), ((uint64_t *)(m\
))\
[((0x829+4615-0x1957)+(0x193c+1218-0x1aa5)-(0x169c+177-0x132a))], ((uint64_t *)(\
m))[((0xbe7+3670-0x15ce)+(0x187f+4531-0x1fc8)-(0x269b+550-0x19f5))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x234c+700-0xf7c)+\
(0x2408+1930-0x1b3b)-9955), \
(3956+(0x2267+5750-0x2186)-9926), ((0xb5f+1062-0xe45)+6036-6346), (\
(0x1937+2947-0x1cb1)+(0x1483+4669-0x235d)-(0xe74+6207-0x1b56)), ((uint64_t *)(m)\
)[\
(5507+(0x2217+2143-0x2216)-(0x2258+2008-0xc57))], ((uint64_t *)(m))[(\
(0x19a8+1189-0x165e)+(0xd95+2349-0xb00)-(0x1fa7+3533-0x19d1))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1c61+3423-0x1850)+\
(0x1fef+964-0x2259)-4809), \
((0x1e3d+3943-0x21c8)+(0x165b+8268-0x2678)-(0x1d27+1490-0x6f4)), (\
(0xb9b+2514-0xf82)+7438-8942), ((0x126+5959-0x181c)+(0x1a61+5105-0x19f9)-\
(0x1754+4812-0x1582)), ((uint64_t *)(m))[\
 ((0x8cb+4300-0x1147)+(0x1c03+1303-0x1807)-4448)], ((uint64_t *)(m))[ (\
(0x1822+5927-0x2375)+(0x103d+404-0x10e1)-(0x108c+783-0x6dd))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x591+8364-0x2102)+\
(0xa7f+1048-0xc75)-(0x1425+6303-0x2569)), ((0xf55+5536-0x1d0d)+\
(0xa0a+3570-0x14b0)-(0x12f2+384-0x945)),\
  ((0x251a+5532-0x2130)+(0xf0f+4005-0x1e47)-(0x2526+2637-0x1588)), (\
(0x1118+5693-0x1e5d)+(0x260b+4753-0x2307)-7808), ((uint64_t *)(m))[ \
((0x1867+3505-0x1137)+(0x925+4108-0x1112)-7417)], ((uint64_t *)(m))[ (\
(0x1533+49-0x13cc)+(0x2517+1134-0x494)-9864)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x211b+1677-0x248c)+\
(0x1d2b+2543-0xde1)-(0x1d86+6665-0x1b3d)), \
(4809+(0x9a4+5125-0x1824)-6218),  ((0x595+8157-0x23e5)+(0x1c19+8818-0x256c)-\
(0x2514+1884-0x11cd)), ((0x4d6+5106-0x14f6)+(0x35a+6576-0x1b6d)-\
(0x820+7149-0x1eac)), ((uint64_t *)(m))\
[ ((0xbcb+1556-0x63d)+(0x2175+3660-0x1c00)-8026)], ((uint64_t *)(m))[ (\
(0xa50+2088-0x10b7)+(0x2623+3475-0x23d2)-(0x1aa8+7604-0x26bb))]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x9b0+3530-0x1602)+\
(0xf8c+827-0x1182)-(0x1ed3+1309-0x2133)), \
((0x18a0+6796-0x21a3)+(0x2302+4678-0x258a)-8515),  ((0xc73+1918-0x1264)+\
(0x232b+1042-0x103a)-(0x221f+2220-0x1243)), ((0x2200+5175-0x15b8)+\
(0x2634+1082-0x2401)-9952), ((uint64_t *)(\
m))[ (4194+(0x12f8+2550-0xa3f)-8970)], ((uint64_t *)(m))[ ((0x239c+4774-0x26d9)+\
(0x17aa+5814-0x1b93)-(0x23a8+7215-0x1daa))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x17f1+1081-0x16f2)+\
(0x1f58+4851-0x175a)-8232), \
((0x1711+316-0xf0d)+5967-8330),  ((0x2683+4497-0x1ff1)+(0x176b+256-0x10d0)-8117)\
, ((0x1914+748-0x12da)+(0x1403+1141-0x149f)-(0x1944+5238-0x20c8)), ((uint64_t *)\
(m))\
[ ((0x13df+3432-0x1777)+3387-5896)], ((uint64_t *)(m))[ (6615+1650-8264)]);\
      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x2020+3767-0x24fc)+\
(0x1371+3509-0x1d45)-(0x154a+7077-0x2335)), \
((0x1a98+1066-0x12e6)+(0x8db+458-0x444)-(0x15cc+7183-0x1fa4)), (\
(0x16df+2228-0xc63)+(0x18cb+538-0x1626)-(0x2327+2467-0x14e5)), (\
(0x1105+8284-0x22c4)+3142-(0x20d3+2554-0xff8)), ((uint64_t *)(m)\
)[((0x1706+2878-0x1260)+1255-(0x1c36+6517-0x20ed))], ((uint64_t *)(m))[(\
(0x1cd3+6763-0x1d23)+(0xf1f+1479-0x1146)-(0x2040+7532-0x1ffd))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x226d+6476-0x1b91)+\
(0x571+6204-0x1c57)-(0x26e4+7203-0x218c)), \
((0x1d37+3336-0x1e14)+(0xe95+3458-0x1ab1)-3466), ((0xd07+373-0xb0a)+\
(0x264c+3199-0xf52)-9952), ((0x1637+3324-0x1981)+(0x139d+5589-0x2561)-\
(0xe64+7258-0x1d0a)), ((uint64_t *)(m))[\
((0x14af+4123-0x1fdd)+(0x1f95+2674-0x19f6)-(0x1c23+1981-0xeed))], ((uint64_t *)(\
m))[((0x11d7+497-0x5b0)+(0x1aef+4982-0x2439)-(0x188c+9537-0x2597))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x242a+5988-0x1d2c)+\
(0x16d5+3252-0x210b)-(0x24d1+3834-0x12eb)), \
((0x244f+210-0x1972)+5644-(0x25bf+7313-0x209a)), ((0x1172+584-0x7ee)+\
(0x2310+1265-0x17a2)-7201), ((0x26b4+971-0x12dd)+(0x1c1a+2057-0x2352)-6244), ((\
uint64_t *)(m))\
[ ((0x1db9+5159-0x1c09)+(0xf74+204-0xe43)-6098)], ((uint64_t *)(m))[ (\
(0x1a75+1798-0x110b)+(0x1a51+2104-0x2123)-(0x17e3+6101-0x1de8))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x17e4+5645-0x1f32)+\
(0x1bd7+1003-0x119e)-(0x224a+2628-0xfac)), \
(1380+(0x1539+3057-0x16cc)-(0x196b+5554-0x1f61)), ((0xee8+7663-0x2268)+\
(0x1fc2+5654-0x196e)-9934), ((0xacd+6468-0x1c26)+(0x24c6+1844-0xdb2)-9767), ((\
uint64_t *)(m))[\
 ((0x2106+546-0x2143)+8333-8813)], ((uint64_t *)(m))[(4765+(0x108c+6452-0x214e)-\
6917)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x9ac+36-0x830)+8643-9057), \
((0x110f+3803-0x18a7)+(0x10ad+7680-0x203c)-5549),  ((0x1c7f+2815-0x1f34)+6329-\
8443), ((0x22dd+2849-0x1618)+(0xf6c+356-0x9af)-7930), ((uint64_t *)(m\
))[ ((0xee2+1781-0xd61)+7483-9645)], ((uint64_t *)(m))[ ((0x2421+6901-0x1ca9)+\
(0x1c7b+1248-0x20ed)-8923)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xb0a+3875-0x1966)+\
(0x1597+2367-0xebf)-(0x1269+9031-0x24d5)), \
((0x1907+3478-0xf32)+(0xa44+5268-0x1c26)-(0x1da0+7018-0x1ef1)),  (\
(0x2133+4779-0x26da)+(0x1942+5082-0x2323)-(0x1831+1230-0x60b)), (\
(0x193a+5649-0x2663)+(0x2541+2652-0x16e9)-8590), ((uint64_t *)(m)\
)[((0xe5c+4875-0x19b8)+(0x2009+86-0xba5)-7258)], ((uint64_t *)(m))[ (\
(0x10e2+7657-0x2020)+(0xf3f+4548-0x19fa)-(0x1ef9+3646-0x178b))]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x20a4+3770-0x1f2f)+\
(0xc0c+6672-0x1f5d)-(0x2421+5727-0x2392)), \
((0x1095+5346-0x1fb5)+5874-(0x238f+480-0x8bf)),  ((0x1025+4709-0x1283)+\
(0x2506+3822-0x1eb2)-(0x2666+8874-0x23cf)), ((0x1544+3983-0x2478)+8783-8862), ((\
uint64_t *)(m)\
)[ ((0x17f9+6023-0x2636)+2835-(0x221b+4355-0x1eca))], ((uint64_t *)(m))[ (\
(0xc6d+379-0xdc7)+(0xdd3+8749-0x23b9)-(0x15fc+820-0xcc8))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x11e4+2233-0xf0a)+\
(0xba9+2338-0xe37)-(0x23b9+1618-0x17e5)), \
((0xf30+4020-0xfc2)+(0x206a+670-0x1d07)-5406),  ((0x2017+4021-0x158c)+\
(0x1405+2924-0x1de7)-7105), ((0x11ec+223-0x5b8)+(0x1012+4292-0x1ac8)-\
(0x20c1+3563-0x1b98)), ((uint64_t *)(m)\
)[ ((0x1aa5+787-0x1562)+(0x18d0+4776-0x180c)-(0x2513+5061-0x1d1b))], ((uint64_t \
*)(m))[ ((0x1397+5057-0x26ab)+(0x2265+7366-0x23a1)-(0x20bd+7610-0x2247))]);\
      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1637+2303-0xdc9)+\
(0x1e19+3090-0x2414)-(0x256d+1972-0x159f)), \
((0x1f69+1805-0x1102)+(0x2a5+1645-0x859)-(0x1aea+6640-0x1eb3)), (\
(0x1d62+2927-0x1ba4)+(0xca1+6464-0x19ea)-(0x2001+3508-0x149b)), (\
(0x1874+2350-0x1ce6)+(0x8a9+6824-0x1ccc)-(0x101b+2948-0x106c)), ((uint64_t *)(m)\
)[\
 ((0x781+7710-0x2083)+(0x22e3+3761-0x1d7f)-(0x1d75+5783-0x1add))], ((uint64_t *)\
(m))[ ((0x1312+1561-0x1050)+(0x23aa+909-0xfd0)-(0x219c+7263-0x1dbd))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xdc6+7052-0x1eba)+\
(0x1349+2983-0x1bf4)-(0xea1+4925-0x144d)), ((0x114c+311-0xaf8)+\
(0x25f4+483-0x20d6)-(0x1866+6734-0x242f))\
, ((0x1433+8543-0x245c)+(0x1847+5070-0x2580)-6080), ((0xa41+5079-0x18d6)+8182-\
9513), ((uint64_t *)(m))[((0x10cd+3388-0x1830)+(0xdc8+5270-0x2152)-\
(0xb17+3768-0x12f4))\
], ((uint64_t *)(m))[((0x1e2a+2692-0x25da)+(0x469+4745-0x1581)-\
(0x1ca4+1267-0x1d61))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xb0c+3415-0x181e)+9011-9080), \
((0x4ca+7945-0x22f4)+8732-8950), ((0x1ef0+829-0x1cde)+6908-(0x2398+803-0x67a)), \
((0x137d+717-0x1425)+(0x15ec+3640-0x177b)-(0x1ce1+434-0xfd4)), ((uint64_t *)(m))\
[\
((0x256b+1810-0x2623)+(0x227d+1293-0x120e)-(0x2270+1223-0xb6f))], ((uint64_t *)(\
m))[ ((0x612+181-0x32a)+(0xf8b+47-0x5ac)-(0x2649+3640-0x26d7))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1e33+1035-0xdca)+\
(0xd5b+9462-0x26f4)-8144), \
((0x18f0+2638-0x1f5c)+(0x1b5c+8775-0x22ed)-(0x247d+7988-0x251f)), (\
(0x1e4c+3071-0x18a6)+(0x1e20+7036-0x2674)-9410), ((0x13ab+5731-0x16c1)+\
(0x79a+6841-0x2114)-(0x166b+5429-0x1720)), ((uint64_t *)(m)\
)[((0x159a+2459-0x144c)+(0x1c4c+5528-0x1d04)-(0x2427+8866-0x270b))], ((uint64_t \
*)(m))[((0x12e6+3400-0x19c4)+(0x1e29+2731-0xcf1)-8769)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x18eb+7372-0x24a2)+\
(0x1b59+344-0x16e8)-(0x1e7a+6052-0x1f42)), \
(5801+(0x1164+496-0x3e5)-9745),  ((0xa11+106-0x769)+(0xed9+1409-0x11ff)-\
(0xc5c+4377-0x1810)), (2111+(0x1d49+697-0xf38)-6396), ((uint64_t *)(m))\
[ ((0x1ebf+2657-0x2197)+(0x1174+7159-0x2502)-4076)], ((uint64_t *)(m))[ (5483+\
(0x1c56+3863-0x1de3)-8941)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x37b+681-0x500)+5773-\
(0x2039+7217-0x24bc)), \
(2098+(0x2208+2037-0xd68)-9411),  ((0x1508+1592-0xf3e)+6649-9714), (\
(0x25a3+2155-0x15ad)+(0x866+4368-0x170a)-6847), ((uint64_t *)(m)\
)[ (1062+(0xfb8+3302-0xe81)-(0x25a4+2436-0x1ce8))], ((uint64_t *)(m))[(\
(0xaa7+2639-0xc65)+(0xceb+1521-0xd6d)-(0x1b91+3561-0x1b87))]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x47c+8194-0x21e3)+\
(0x229b+5357-0x2393)-5776), \
((0xed8+3049-0xf45)+(0xb8c+867-0x896)-4561),  ((0x1532+9440-0x2511)+\
(0xe63+1885-0xe91)-7208), ((0x1027+125-0x1b7)+(0x4c3+5634-0x1aa7)-\
(0x20a1+1462-0x1758)), ((uint64_t *)(m))[\
 ((0x248+7898-0x1f8e)+7444-(0x23a5+5120-0x18ff))], ((uint64_t *)(m))[(\
(0x2336+1116-0xa72)+(0x13fb+3282-0x1c1c)-8645)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (3043+(0x1171+965-0xabd)-\
(0x1b38+2011-0xcb8)), \
((0xf96+4476-0x11ee)+(0xb72+7844-0x24a2)-5267),  ((0x1c47+2133-0x15f2)+\
(0x2698+1776-0x1ed4)-7509), (6600+(0x1454+1639-0xe81)-9717), ((uint64_t *)(m\
))[ ((0x658+1972-0x967)+7318-8501)], ((uint64_t *)(m))[(2401+(0xa2d+4266-0x110b)\
-(0x1b74+4477-0x19ce))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x266d+450-0x239a)+7489-8660), \
(4933+(0x11cb+1899-0xcb2)-8131), ((0x2324+2229-0x17e5)+(0x1718+7485-0x2339)-\
(0x2610+5445-0x164f)), ((0x1857+2720-0x219c)+(0x2b6+2648-0xc9a)-\
(0x2212+832-0x2391)), ((uint64_t *)(m))\
[ ((0xa6d+8711-0x2504)+7802-9706)], ((uint64_t *)(m))[((0x266c+429-0x13c5)+\
(0x11c0+3457-0x155b)-7727)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xf07+5517-0x2040)+8034-9139), \
((0xb32+4045-0x1555)+(0x1e58+806-0x1e7e)-(0x1fcd+3830-0x2620)), (\
(0x1031+311-0x3c0)+(0x1bac+3127-0x1685)-(0x1fc4+7117-0x1c96)), (\
(0xb96+1073-0xf76)+(0x1519+1430-0x1313)-(0x221d+675-0x1ce2)), ((uint64_t *)(m))[\
 \
(5210+(0x270a+3269-0x26e5)-(0x2369+882-0x59f))], ((uint64_t *)(m))[ (\
(0x1fa5+4053-0x1d83)+(0x866+661-0x40c)-6371)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x549+5025-0x14c8)+1268-\
(0x1509+3890-0x1b25)), \
((0x107f+4926-0x1e19)+(0xc5d+291-0x4e0)-(0x194d+5109-0x1f03)), (\
(0x230c+1609-0x18e8)+(0x265a+2986-0x2139)-8494), (7387+(0xd14+627-0x94b)-8968), \
((uint64_t *)(m)\
)[ (7700+(0x1dad+4074-0x2503)-9892)], ((uint64_t *)(m))[((0xd03+5255-0x14e3)+\
(0x18f4+4171-0x2493)-4422)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1835+2246-0x1cb6)+5614-6706), \
((0x2351+2553-0x21ab)+(0xfd0+624-0xa92)-(0x1e0d+678-0xd6c)), (\
(0x1c54+4259-0x20d4)+(0x492+5154-0x1727)-(0x1d73+1588-0x1602)), (\
(0x7ab+5136-0x1952)+(0x1808+7790-0x26d1)-(0x15f7+2945-0xf76)), ((uint64_t *)(m))\
[ \
((0x1e74+1544-0x1e69)+(0x2384+68-0x1d3c)-(0xd20+9257-0x24b1))], ((uint64_t *)(m)\
)[ ((0x1aaa+885-0x1de4)+7618-7672)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (4976+(0x1ee5+4281-0x22c7)-\
(0x20e1+8462-0x21aa)), \
((0x1baa+1660-0x13ea)+(0x23fd+2194-0x1c35)-7823),  ((0x19da+2306-0x22c8)+8389-\
8401), ((0x1d9b+346-0x84f)+(0x149c+4048-0x18f4)-8721), ((uint64_t *)(m)\
)[((0x8b2+4217-0x13a3)+(0x1540+3397-0x19c1)-(0xffc+4145-0x11f0))], ((uint64_t *)\
(m))[((0x19ef+1844-0x209c)+(0x2611+188-0xc8b)-6843)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xd68+731-0x87f)+6671-\
(0x25ec+3355-0x1137)), \
(7923+(0x1909+3435-0x25d7)-(0x2213+6108-0x1a63)),  ((0x382+4300-0x143c)+\
(0x2136+2660-0x1450)-(0x19a5+4225-0x12d3)), ((0x6eb+2403-0xf4f)+\
(0x1c9d+1891-0x10e0)-(0x1e00+5278-0x1e8d)), ((uint64_t *)(m))[\
 ((0xc08+695-0xb79)+(0x13a1+2585-0xcaa)-(0x159c+7677-0x1f44))], ((uint64_t *)(m)\
)[ ((0xde4+1828-0xd75)+(0x2533+1576-0x179d)-(0x1d06+9396-0x2672))]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1bf8+4212-0x1349)+\
(0x1fa9+873-0x17ce)-9319), \
((0x209f+4179-0x2481)+(0x2fc+832-0x35c)-3917),  ((0x484+1826-0xaf0)+\
(0x226b+2058-0x18a4)-(0x13c5+2733-0xbf3)), (6513+(0xfb7+8431-0x2376)-9877), ((\
uint64_t *)(m))[\
((0x1acd+4350-0x1164)+(0x1757+1579-0x1142)-9883)], ((uint64_t *)(m))[ (\
(0x1c43+1727-0x2085)+9175-9807)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x962+2645-0x1297)+\
(0x1f53+1040-0x16d0)-3506), \
(6234+(0x1ad3+1935-0x20f8)-(0x21c4+5429-0x1d3a)),  (3462+(0x192c+1653-0x1c7c)-\
(0x1ee6+2257-0x1715)), ((0x11d9+5512-0x20f6)+7046-(0x258a+1833-0xacf)), ((\
uint64_t *)(m))\
[ ((0xd4c+6294-0x22e2)+(0x150b+280-0xe44)-(0x21e5+2702-0x2195))], ((uint64_t *)(\
m))[((0x132d+4644-0x18c8)+(0xb08+4261-0x1b98)-(0x126a+1528-0xbd3))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1aa7+5211-0x2623)+\
(0x1dbc+2303-0x1e20)-4472), \
(5201+(0x1c2a+4171-0x1cf0)-9168), (5489+(0x1677+7693-0x252e)-9405), (\
(0x19b0+4335-0x2238)+(0x2468+2302-0x1b0b)-(0x2149+8267-0x26e0)), ((uint64_t *)(m\
))[((0x2203+4219-0x244d)+(0xca4+7803-0x22ac)-(0x1f75+1621-0xf34))], ((uint64_t *\
)(m))[((0x2323+7069-0x2339)+(0x1d4a+4257-0x239a)-9675)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xba6+4608-0x1b05)+\
(0x142f+2534-0x1dd5)-(0x1062+4342-0x1e7a)), \
((0x14e6+6267-0x1970)+3228-8326), ((0x1230+3700-0x1723)+(0x1350+4016-0x1e13)-\
(0x1d22+3095-0x1ad6)), ((0x19c5+4735-0x2340)+(0x2019+5940-0x25de)-6756), ((\
uint64_t *)(m))\
[ ((0x14da+3460-0x20ac)+(0x2681+9079-0x25a7)-9727)], ((uint64_t *)(m))[(\
(0x1de7+1146-0x1b01)+(0x1e61+219-0xc04)-(0x2381+705-0xbb4))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (7876+(0xb1a+2913-0x1458)-\
(0x235a+4077-0x1260)), \
((0x1dcd+1482-0x1f6e)+7242-(0x26cb+6201-0x1e96)), ((0x23c1+3595-0x2703)+\
(0x201c+329-0x110e)-6934), ((0x2443+639-0x121c)+(0x2549+1071-0x2383)-\
(0x23c4+7314-0x25ca)), ((uint64_t *)(m)\
)[ ((0xc47+1874-0x9ba)+5204-7731)], ((uint64_t *)(m))[ (8973+(0x1bb+576-0x36c)-\
9109)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (7530+(0x1021+863-0x1183)-8038), \
((0x13d0+1763-0xdfe)+(0x1d4d+21-0x127a)-(0x1d77+3035-0x11bb)), (\
(0x72a+7977-0x2247)+(0x1d9f+1910-0xc5c)-7354), ((0x1629+7462-0x22ac)+\
(0x18a0+506-0xdeb)-7494), ((uint64_t *)(m)\
)[ ((0x24d1+613-0x14e9)+(0x118d+6613-0x1b52)-(0x22fc+2153-0x90e))], ((uint64_t *\
)(m))[ ((0x1284+1845-0xec0)+6174-8980)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (8965+(0x18c+4476-0x12d3)-9016), \
((0x2012+6042-0x1c9d)+(0x49c+258-0x435)-7281),  ((0x1b7b+3368-0x2642)+\
(0x2333+6638-0x1bf9)-9089), ((0x1c1d+5142-0x21eb)+(0x13c7+1839-0x9a8)-\
(0x1fa2+9874-0x26ab)), ((uint64_t *)(m)\
)[ ((0x1071+1511-0x12fb)+(0x225c+264-0xc5b)-(0x1cd6+3866-0x1193))], ((uint64_t *\
)(m))[ ((0x1af6+3464-0x2637)+(0x252b+3980-0x24b4)-(0x237d+2104-0x196d))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x25d8+83-0x22c3)+\
(0x2089+5979-0x1aba)-(0x209c+2752-0xacd)), \
((0x1922+6391-0x20f2)+(0x1b84+5206-0x1a23)-9946),  ((0xba9+4731-0x182f)+\
(0x1ba9+4796-0x17e4)-7277), (7972+(0x576+7357-0x1e81)-(0x2653+6758-0x1df1)), ((\
uint64_t *)(m\
))[ ((0x800+5363-0x1758)+8360-9787)], ((uint64_t *)(m))[((0x1e2b+1592-0x1c68)+\
(0x20af+5360-0x2682)-(0x1af5+3923-0x133b))]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xa28+2561-0x11cd)+5551-6155), \
((0x1a7f+6007-0x1fb7)+(0x1d4c+1013-0x19b5)-(0x1ef8+1616-0xb81)),  (3804+\
(0x21a1+2728-0x2118)-(0x1d27+5675-0x194d)), ((0xd54+4421-0x1baa)+\
(0x246a+8667-0x263d)-8939), ((uint64_t *)(m\
))[((0x150+4330-0x1219)+6409-(0x1af9+7944-0x20e4))], ((uint64_t *)(m))[(\
(0x1798+4125-0x1b49)+(0xa39+2162-0xa61)-(0x1cb7+7236-0x2450))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x20dc+2611-0x1aeb)+\
(0x880+2196-0x92f)-6152), \
((0x20b3+6019-0x1daf)+2433-9219),  ((0x2109+984-0x1082)+(0x2090+569-0x1443)-8924\
), (2816+(0xa54+881-0xa5c)-(0x1a8d+257-0xd32)), ((uint64_t *)(m)\
)[ (8572+(0x367+7031-0x1baf)-9380)], ((uint64_t *)(m))[((0xe90+5509-0x170c)+\
(0x236+7682-0x1f8b)-(0x112f+6138-0x1b81))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1c08+2406-0x237d)+8882-9377), \
((0x5c7+4189-0x1311)+(0x21b6+2426-0x1d41)-(0x1435+641-0x5ba)), (\
(0x1998+1372-0x1097)+5866-(0x26bb+1062-0x5a4)), ((0x1417+1056-0x1174)+\
(0x2292+2523-0x187d)-(0x25b6+4195-0x1b74)), ((uint64_t *)(m))\
[(6738+(0x2118+419-0x2220)-(0x2667+2555-0x1581))], ((uint64_t *)(m))[ (\
(0x16ea+4056-0x1ad7)+(0x121d+2827-0x1cff)-(0xc9c+7044-0x1c0d))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (5586+(0xd9c+2188-0x11b9)-\
(0x20ef+2209-0xf52)), \
((0x23d3+1326-0xc8f)+(0x110c+3875-0x1ede)-7612), ((0xb2c+6770-0x20ee)+\
(0x214a+4024-0x2101)-5286), ((0x2026+348-0x1b82)+5325-6846), ((uint64_t *)(m))\
[ ((0x19f8+1712-0x1a0c)+(0x256a+4662-0x2390)-(0x266a+3007-0x1780))], ((uint64_t \
*)(m))[ ((0x1ba2+3493-0x17b4)+(0xb53+4089-0x19ee)-(0x265b+566-0x15a9))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x2293+2893-0x1048)+\
(0x2d0+9053-0x2521)-7844), \
((0xf0b+84-0x4c4)+(0x1100+459-0x3d4)-6541), ((0xa7+9161-0x23cb)+6625-\
(0x252c+3734-0x1946)), ((0x18f6+2949-0x127c)+(0x1b29+7274-0x24d5)-9390), ((\
uint64_t *)(m))\
[ ((0x673+725-0x3e2)+(0x1ecc+6318-0x1d94)-8007)], ((uint64_t *)(m))[ (\
(0x5fa+2451-0xef6)+(0x1885+1129-0x10f8)-(0x1c92+4202-0x206f))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xd63+7820-0x1e9f)+\
(0x167f+728-0x1806)-(0x1429+6322-0x1e3b)), \
((0x1d09+644-0xe34)+(0x1124+5193-0x2370)-(0x1650+5577-0x18c9)), (\
(0x2364+516-0x1415)+(0x16d4+2614-0x1829)-6697), (8460+(0x1ab9+1762-0x203b)-8800)\
, ((uint64_t *)(m)\
)[((0x1435+1515-0xbb9)+(0x1842+7461-0x1d53)-9836)], ((uint64_t *)(m))[ (\
(0x1aff+8647-0x24a9)+(0x1918+284-0x1460)-7661)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1026+1043-0x1398)+8101-8260), \
((0x1472+5385-0x2323)+4455-(0x1a8f+6023-0x1a5e)),  ((0xdea+4338-0x1d75)+6826-\
7177), ((0x6bd+5232-0x19f6)+(0x22ec+2249-0x199c)-(0x16ac+2325-0xc7e)), ((\
uint64_t *)(m)\
)[ ((0x10e6+6765-0x1e5b)+(0x231a+1383-0x1a4d)-6948)], ((uint64_t *)(m))[ (\
(0x1bcd+4323-0x211b)+(0x1088+3053-0x173b)-4297)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x97f+3295-0x1244)+\
(0x252f+1510-0x14b4)-(0x20ec+993-0xa55)), \
(4550+(0xde3+5394-0x1e17)-5792),  ((0x502+4633-0x144b)+(0x2639+5598-0x18a4)-9786\
), ((0x14e0+5674-0x2544)+(0x170f+690-0x875)-5892), ((uint64_t *)(m\
))[ ((0xad3+4701-0x176d)+4585-(0x1e26+2146-0xede))], ((uint64_t *)(m))[(2479+\
(0x1af0+9108-0x2483)-9126)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x543+8776-0x24b4)+7576-\
(0x22f2+5330-0x1755)), \
((0xb1a+5087-0x1778)+(0x17ef+448-0x65c)-(0x1f33+5894-0x1b69)),  (\
(0x19ed+7088-0x25de)+(0x19e7+2998-0x2101)-(0x1ebf+947-0xe1f)), (\
(0x393+3767-0x1060)+(0x1bcd+1290-0x1f14)-(0xa07+1738-0xd30)), ((uint64_t *)(m))[\
 ((0x205a+4189-0x1d67)+(0x2528+377-0x2451)-(0x1644+9340-0x2526))], ((uint64_t *)\
(m))[((0xf1b+5679-0x1a45)+(0x1208+9345-0x2660)-(0x23e9+2262-0x11a0))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x8bb+7241-0x2168)+\
(0x2145+720-0xe96)-6426), \
((0x1ff1+6210-0x26cd)+(0x178c+484-0x5c0)-9489),  ((0x2321+3273-0x2099)+\
(0xc24+1605-0x8b4)-6397), ((0xed6+528-0x31c)+(0x25a6+2020-0x1c47)-\
(0x2069+2930-0xcdb)), ((uint64_t *)(m\
))[((0x1b1a+3308-0x190b)+(0x1f87+18-0x1db9)-(0x14f8+1844-0xb5f))], ((uint64_t *)\
(m))[ (6786+(0x1d74+3110-0x2634)-(0x2125+401-0x4d7))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xf0b+3849-0xfe8)+\
(0xf4c+1396-0xf74)-(0x1bab+5110-0x1c2b)), \
((0x16a3+3528-0x1d4e)+7484-9299), ((0x258d+6828-0x2277)+(0xadd+656-0x68d)-9368),\
 ((0x1f4a+3134-0x24a0)+(0x1d3b+875-0x1716)-(0x1166+4900-0x1420)), ((uint64_t *)(\
m)\
)[((0x287+4968-0x144e)+(0x1a57+2354-0x2235)-(0x427+7355-0x1df8))], ((uint64_t *)\
(m))[ ((0x7b1+7204-0x20fb)+(0xa96+5065-0x1a36)-(0x706+9699-0x25e9))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (6417+(0x11e9+3378-0x1c99)-\
(0x1fa1+8402-0x24e3)), \
((0x2467+4146-0x20d2)+(0x119f+6969-0x1e86)-8722), ((0x15a1+375-0x9c1)+\
(0xf1c+300-0xb23)-(0x152b+111-0x329)), (4775+(0x172b+5800-0x1c0d)-9310), ((\
uint64_t *)(m\
))[ (6786+(0x1665+877-0x1945)-6927)], ((uint64_t *)(m))[ (8278+\
(0x577+5954-0x1a91)-8822)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xeff+9014-0x2572)+\
(0x253b+917-0x1a23)-7024), \
((0x1b72+6162-0x1b94)+(0xd5b+4841-0x1816)-8217), ((0x17af+166-0x8c2)+\
(0xefa+1337-0xb17)-6309), ((0x5f2+1867-0x762)+5378-6862), ((uint64_t *)(m)\
)[(3754+5171-(0x2544+725-0x548))], ((uint64_t *)(m))[ ((0x1a3b+5140-0x1557)+\
(0xd09+6554-0x1d92)-8711)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x9fc+1330-0xa0c)+\
(0x1f21+645-0x628)-8351), \
((0x11e8+1741-0xd52)+(0x20ab+3814-0x1f1a)-(0x1e08+328-0x37c)), (\
(0x24e8+6471-0x23e5)+(0xea7+6218-0x1e54)-8924), ((0xe07+8444-0x2368)+\
(0x1987+5895-0x1934)-(0x2342+2806-0xb4f)), ((uint64_t *)(m)\
)[((0x2041+227-0x148b)+(0x13b5+309-0xae1)-(0x1736+9293-0x24ee))], ((uint64_t *)(\
m))[ ((0x24ba+41-0xd0a)+(0x1150+5170-0x1f5f)-7669)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (4272+(0x1054+6780-0x1d11)-7789), \
((0x1420+3212-0x1e15)+(0x21e6+1770-0xde4)-7548),  ((0x18ea+5057-0x257f)+\
(0x2011+476-0x21b)-9974), ((0x11e9+5427-0x16cf)+(0x1326+4780-0x1e26)-\
(0x2347+5128-0x1f63)), ((uint64_t *)(m\
))[ ((0x1c4f+3281-0x25e4)+1993-(0x11d5+123-0x74c))], ((uint64_t *)(m))[ (\
(0x1bb2+3808-0x1f20)+(0xe86+607-0xfff)-(0x1339+544-0x905))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (9049+(0x884+6250-0x1f83)-9409), \
((0xc4a+1671-0xa06)+7166-9413),  ((0x18f2+6877-0x26d7)+(0xe71+4907-0x2188)-\
(0x1dff+4266-0x21a6)), ((0x1a59+1580-0x1166)+(0x2700+863-0x14a6)-\
(0x26c4+2861-0xd27)), ((uint64_t *)(m))[\
((0xff0+9235-0x2620)+(0x5f6+4940-0x177f)-(0x1621+4802-0x1947))], ((uint64_t *)(m\
))[ ((0x16f8+2941-0x15ea)+5807-9013)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xdca+2392-0xd19)+(0xf18+676-0xa9a)\
-(0x129f+920-0x50c)), \
((0x67d+5520-0x1a72)+(0x1aad+7383-0x20ba)-(0x1895+9928-0x26fc)),  (\
(0x6b0+586-0x6c6)+5877-(0x1e21+6883-0x1fe3)), ((0x2303+35-0x12c2)+\
(0x242d+4859-0x2667)-8473), ((uint64_t *)(m\
))[((0x1bea+3804-0x10eb)+(0x1a2a+1750-0x20a1)-(0x1bac+8367-0x222b))], ((uint64_t\
 *)(m))[ ((0xda+5994-0x179c)+(0x1858+896-0x788)-(0x1ea6+914-0xd42))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (5521+(0x188a+571-0xd9c)-\
(0x2356+8647-0x2264)), \
((0x1170+7023-0x1cfd)+(0x1f8c+4723-0x1d0b)-9425),  ((0x2188+926-0x1dbd)+\
(0x1c9a+2537-0x1349)-(0x242d+36-0x9b7)), ((0x1359+311-0x1091)+\
(0x1f49+2446-0x1d33)-3990), ((uint64_t *)(m))\
[ (5898+4054-9944)], ((uint64_t *)(m))[ ((0x5c4+2665-0xede)+(0x1d80+7292-0x2135)\
-6674)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x94f+5912-0x1b7d)+\
(0x20c7+1078-0xc9c)-(0x1f24+2986-0xd85)), \
((0xdf7+1885-0xb17)+(0x1750+5265-0x16a0)-8056), ((0xf09+4857-0x151b)+\
(0x12c3+5249-0x1744)-(0x2180+6969-0x1fdc)), ((0x184b+953-0xf55)+\
(0xd08+3536-0xf0d)-(0x1fc4+6837-0x220d)), ((uint64_t *)(m))\
[ ((0x1e31+770-0x946)+(0xc66+381-0xb51)-6776)], ((uint64_t *)(m))[ (\
(0x1491+1005-0x6be)+(0x2468+3028-0x1cf6)-9472)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1933+6170-0x2412)+\
(0x1a0a+2249-0xc28)-(0x25e7+3386-0xf3e)), \
((0x14b6+4363-0x2064)+(0x204c+96-0xd37)-6347), ((0x192d+2335-0x1604)+\
(0xdea+5392-0x1b69)-(0x175c+7833-0x2227)), ((0x10f4+45-0x10b0)+\
(0x1877+5438-0x1862)-(0x1683+4515-0x1271)), ((uint64_t *)(m))[\
 ((0xd67+9273-0x2477)+(0x202f+2350-0x234c)-(0x1bb7+1854-0xfbc))], ((uint64_t *)(\
m))[ (5309+(0x160f+5489-0x225a)-7646)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x14f6+5379-0x152c)+\
(0x8aa+991-0xa59)-(0x188a+2692-0xc11)), \
((0x1d97+2152-0x1aa4)+6239-9141), (5889+(0xb67+6899-0x1bf4)-8541), (\
(0x24ca+573-0x1cf5)+(0xcf9+7139-0x1d61)-5502), ((uint64_t *)(m)\
)[((0x1452+2069-0x191e)+(0x24e0+1525-0x18a3)-(0x1928+3947-0x1327))], ((uint64_t \
*)(m))[(7883+(0xc27+624-0xac3)-8852)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1332+2954-0x1bba)+8684-\
(0x254a+9882-0x26f7)), \
((0xa98+3607-0x14ed)+(0x18ab+432-0xc4d)-(0x1226+3739-0xef7)), (\
(0x110b+3760-0xff7)+(0x1c00+4789-0x267f)-6127), (4518+(0xb30+232-0x849)-\
(0x2140+4368-0x1ce7)), ((uint64_t *)(m))\
[ (5731+(0x1718+607-0x154f)-6786)], ((uint64_t *)(m))[((0x20b2+1704-0x1106)+\
(0x1d34+2314-0x19c1)-8899)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1102+7440-0x23d7)+\
(0xc2c+6422-0x194f)-5676), \
((0x1674+162-0x112b)+4325-5833),  ((0x22a8+851-0x2140)+7690-(0x22e4+4897-0x1348)\
), (9126+(0xe92+138-0xeff)-9142), ((uint64_t *)(m))\
[ (7188+(0x1355+2183-0x11d0)-9757)], ((uint64_t *)(m))[((0x1fa3+1673-0x1ed9)+\
(0x26ec+715-0xee0)-8734)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (4802+(0xfc7+2101-0x11fc)-6335), \
((0x2013+326-0x1ad6)+(0x21e7+1365-0xce5)-8406),  ((0x18b4+2321-0x1c18)+1624-\
(0x1f86+2888-0x1ed2)), ((0x700+4585-0x134c)+(0x1bb8+3080-0x2071)-\
(0x1beb+3229-0x1baa)), ((uint64_t *)(m))[\
((0xbaa+8210-0x23c6)+(0x2193+267-0x215b)-(0x1a59+5064-0x24f5))], ((uint64_t *)(m\
))[ ((0x1ab7+1541-0x8d6)+(0x1266+6042-0x21e4)-8194)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x176a+5099-0x2166)+672-\
(0x1e0f+5423-0x26af)), ((0x1e88+717-0x2151)+8052-8052),\
  (8320+(0x1957+2806-0x2035)-9360), ((0x14ca+7656-0x2538)+(0x1a1a+3396-0x19aa)-\
(0x2531+4100-0x1a13)), ((uint64_t *)(m))[ \
((0x21b0+3766-0x1266)+(0x9b2+8109-0x266e)-8433)], ((uint64_t *)(m))[ (\
(0xf6c+2355-0x105e)+(0xf56+4283-0x1937)-(0x12ef+224-0x4b5))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x153d+3928-0x172b)+\
(0x2445+890-0x1f17)-(0x2556+5339-0x2420)), \
((0x1c25+5976-0x1fd4)+(0xae9+68-0x1b5)-7452),  ((0x1f8f+4186-0x2467)+\
(0x1ef6+28-0xd05)-7558), ((0x172a+3529-0x201c)+(0x1513+1489-0x11e5)-\
(0x1f4b+954-0x153c)), ((uint64_t *)(m)\
)[ ((0x13a2+27-0x11a5)+(0x2268+8236-0x225e)-8780)], ((uint64_t *)(m))[ (4633+\
(0x2640+456-0x23a0)-(0x259c+448-0x10de))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0xce9+6169-0x2222)+5804-6538), \
((0x2319+5336-0x1a80)+(0xec8+915-0xb4a)-9340), ((0x14b2+6946-0x2381)+\
(0x671+287-0x3e3)-(0x2510+1438-0x1ab8)), ((0x1048+2891-0x1597)+6390-7908), ((\
uint64_t *)(m))[\
 ((0x1d58+5145-0x1f31)+(0x1e1f+1035-0x1f3d)-(0x1e6f+5279-0x1de5))], ((uint64_t *\
)(m))[ ((0xdb9+8075-0x2344)+(0xf58+6153-0x2300)-(0xeba+4917-0x1393))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x16dd+4784-0x1763)+\
(0x1713+208-0xb54)-7862), \
((0x1c23+1415-0x1e67)+6876-7704), ((0x824+4968-0x17fc)+(0x1c74+5490-0x212a)-\
(0x14e6+4560-0x1275)), ((0x160c+5427-0x25a2)+(0x1992+4191-0x25de)-\
(0x20eb+2550-0x2140)), ((uint64_t *)(m))[\
 (9268+(0x826+3758-0x1561)-9633)], ((uint64_t *)(m))[ (7783+(0x201b+647-0x229c)-\
(0x1ef5+54-0xc5))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x10c3+2851-0x134f)+\
(0xebb+1807-0x133e)-(0x13e2+3704-0x1737)), \
((0x2430+1092-0x10d7)+(0x718+1487-0x83e)-7233), ((0x18a1+138-0x14a3)+\
(0x262a+2882-0x20ea)-5376), ((0xbe0+7081-0x2525)+(0x1cf8+2211-0x23b6)-\
(0x2287+1373-0x23aa)), ((uint64_t *)(m))[\
 ((0x26cd+7723-0x24fd)+(0x34a+12-0x15)-(0x24a5+8464-0x2281))], ((uint64_t *)(m))\
[ ((0x1f22+4840-0x1efb)+5066-9936)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (8692+(0x15e8+1349-0x1642)-9950), \
((0x3c6+2536-0xbf8)+(0xe57+2136-0x158e)-(0x1354+352-0x11e3)), (\
(0x1154+746-0xe05)+(0x18d4+1300-0xc1a)-6140), ((0x11aa+3233-0x10b4)+4768-8235), \
((uint64_t *)(m))[\
((0xbf4+7209-0x1e4e)+(0x1b6b+8140-0x1fff)-9469)], ((uint64_t *)(m))[(4363+\
(0x2379+4088-0x25e6)-(0x2551+2064-0xed6))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (6703+(0xddd+3903-0x1c1f)-\
(0x1e79+2345-0xc78)), \
((0x24a8+3569-0x260f)+(0x25ab+893-0x1903)-(0x2690+6214-0x222e)),  (\
(0x1445+7352-0x1d0d)+(0xa63+7410-0x1de7)-(0x23c8+3157-0x12c7)), (\
(0x126a+4156-0x1db2)+(0x2511+2193-0x1a18)-(0x1fdb+2422-0x10e0)), ((uint64_t *)(m\
))[(5458+4517-9963)], ((uint64_t *)(m))[((0x1ef9+1906-0xf25)+\
(0x1954+4289-0x20ad)-8353)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x18da+130-0x18bd)+\
(0x1427+3237-0x20a7)-(0x1abc+268-0x1b07)), ((0x18cd+1183-0x1a3d)+\
(0x18b3+2587-0x2118)-(0xb63+3180-0x12ee)),  \
((0x13bd+5121-0x2081)+(0x154f+4981-0x1a0e)-5610), ((0x700+1093-0x6b0)+\
(0x1f1f+2364-0x1475)-6253), ((uint64_t *)(m))[(5606+1879-7471)\
], ((uint64_t *)(m))[((0x17ed+6033-0x25a1)+(0x1db9+2557-0x1aa3)-5857)]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x1633+3755-0x2304)+\
(0x25ff+5767-0x2017)-(0x26f1+3653-0x16ed)), \
((0x1da6+2613-0x1e2e)+(0xe10+1476-0x135c)-(0xf46+1982-0xce3)),  (\
(0x26b2+313-0x229c)+7667-9018), ((0xeb2+6502-0x237d)+(0x2493+5323-0x1c99)-8532),\
 ((uint64_t *)(m))[\
(8577+(0x802+6122-0x1e37)-9000)], ((uint64_t *)(m))[((0x1b34+2161-0x2139)+\
(0x172f+3540-0x1707)-(0x15e0+6102-0x1d58))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x16f4+918-0xfbf)+6092-8854), \
((0xd14+6489-0x1d5c)+(0x1e72+2799-0x128b)-8162),  ((0x1877+2139-0x1cb9)+\
(0xbb8+4554-0x12d2)-(0x1b7f+3676-0x1b1b)), ((0x2450+2292-0x1507)+\
(0x1ef7+1525-0x19a6)-(0x2440+9722-0x26c4)), ((uint64_t *)(m)\
)[ ((0x1497+770-0x7ee)+5547-9554)], ((uint64_t *)(m))[ ((0x65a+5434-0x1572)+6163\
-7725)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (5764+(0xaec+6558-0x2262)-6314), \
((0xb3b+741-0x331)+(0x1bc2+7708-0x2275)-8786), ((0x17b9+644-0x19d3)+\
(0x16cf+7606-0x2384)-(0x138b+1780-0x91e)), ((0xb9d+6409-0x204a)+\
(0x106d+5579-0x175f)-(0x1328+477-0x1de)), ((uint64_t *)(m))[\
 ((0x7c6+600-0x80f)+(0xa10+4252-0x1839)-(0xb35+1736-0xd84))], ((uint64_t *)(m))[\
((0x20db+737-0x18e3)+(0x1aef+7936-0x21e0)-8921)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, (5885+(0x11fc+3100-0x1c80)-\
(0x242a+1440-0x1138)), \
(5599+(0x1b09+880-0x115a)-8951), ((0x1256+1701-0x10cc)+(0x1e44+2681-0x26cf)-\
(0xd3d+9058-0x268d)), ((0x1c04+563-0x12c7)+(0x127b+855-0xa3f)-\
(0x1eb4+4534-0x1976)), ((uint64_t *)(m))[\
((0x2390+4563-0x24e3)+(0x17f1+4381-0x255a)-(0x1b5a+5157-0x1b58))], ((uint64_t *)\
(m))[ ((0x14aa+2701-0x1ac1)+5953-(0x1eca+4052-0x12ed))]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x219b+3345-0x1137)+\
(0xd5b+4617-0x1f34)-7589), \
((0x1790+4028-0x1700)+(0x1b2f+5799-0x1d1f)-9470), (4679+(0x1413+253-0xf69)-\
(0x21bb+1544-0xfdf)), ((0x1b82+3068-0x1aac)+(0x218b+3501-0x1f55)-\
(0x1d57+2545-0xaa2)), ((uint64_t *)(m\
))[ ((0x1286+3774-0x16e7)+(0x17bd+4351-0x1488)-(0x2084+9066-0x255e))], ((\
uint64_t *)(m))[((0xe08+4044-0x1293)+(0x227d+663-0xc3e)-9227)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x18a5+4526-0x263d)+\
(0x8f6+4554-0x1a60)-(0x108a+703-0xed4)), ((0x22f0+1480-0x1ab9)+\
(0xd7d+1163-0x5b9)-(0x1ddd+6072-0x1b4d))\
, ((0x5dd+1920-0x85b)+6332-(0x25e7+5863-0x1f1b)), ((0x176b+8390-0x2662)+\
(0x19a5+1793-0x157a)-7407), ((uint64_t *)(m))[ \
((0x1461+3687-0x193f)+(0x1bb3+2068-0x969)-9191)], ((uint64_t *)(m))[ (\
(0x1913+880-0x11a4)+(0x23b8+3533-0x19ed)-8821)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x15f9+2359-0x18d4)+\
(0x2552+802-0x24cc)-(0x156f+5181-0x1faa)), \
((0x3f2+4639-0x124d)+5302-(0x20cd+2217-0x1103)),  ((0x12f1+5785-0x247f)+\
(0x18ad+2399-0xc3a)-6869), ((0x18c1+6522-0x1ca5)+(0xf93+7287-0x2687)-6924), ((\
uint64_t *)(m\
))[((0x17c0+776-0x140b)+4968-(0x1a84+2203-0x905))], ((uint64_t *)(m))[ (\
(0xd7a+3961-0x1433)+5437-7670)]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, ((0x173d+3243-0x19d7)+2756-\
(0x1681+2339-0xad2)), \
(4421+(0x1360+6099-0x26b4)-(0x1b02+5458-0x1a94)),  ((0x136a+2979-0x11eb)+\
(0x1fa3+2732-0x178c)-(0x24e5+8300-0x2575)), (9635+(0x152b+1613-0x1b0d)-9728), ((\
uint64_t *)(m\
))[ ((0x1619+4422-0x19dc)+(0x1a81+1833-0x1df3)-(0x172b+8125-0x25b3))], ((\
uint64_t *)(m))[ ((0x15ef+4076-0x24d6)+(0x2181+2186-0x1da8)-(0x2153+4549-0x25b3)\
)]);      \
}                                                                              \
while (((0x18ff+2143-0x1652)+(0x1001+1634-0x953)-(0x219d+3838-0x187f)))
#define ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux)\
                                                     \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_aux))[((0xf8f+492-0xe86)+7484-8241)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0x1c91+2006-0x812)+\
(0x1d78+4695-0x2634)-9712)];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[((0x2129+1983-0xf4f)+(0xda5+5219-0x1778)-\
9256)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0x13e9+2300-0x15df)+\
(0x1ec4+5016-0x262b)-(0x155d+1691-0x8c2))];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[((0x1020+3189-0xfe9)+(0x1bc9+2232-0x140e)\
-(0x2485+7443-0x247b))] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0x1708+6058-0x190b)+\
(0x1fdb+5132-0x2548)-9284)];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[((0xa5b+2500-0x1059)+7555-8518)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0xe18+4216-0x1091)+6141-9721)]\
;\
                           \
    ((uint64_t *)(ReplacementFor_aux))[((0x118f+5368-0x1b9f)+(0x538+4648-0x13cb)\
-(0x13d3+1124-0x9be))] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0x15e1+3456-0x1c29)+\
(0x18d8+5128-0x1c8f)-(0x1ec7+8006-0x2688))];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[((0x1b11+543-0x856)+3582-8915)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0x11e9+2290-0x1471)+\
(0x2291+2248-0x1091)-8493)];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[(8316+(0xc65+5526-0x1cd2)-9631)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0x1b45+2255-0x2255)+\
(0x2655+2301-0x2707)-(0x15e5+5095-0x1fc8))];\
                           \
    ((uint64_t *)(ReplacementFor_aux))[(9408+(0x4ab+5135-0x1781)-9714)] = ((\
ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0x2273+3100-0x1e60)+\
(0xe8a+3925-0x1c24)-(0x23e7+3774-0x20c2))];\
                           \
                                                                               \
    ReplacementFor_B2B_IV(ReplacementFor_aux + ((0x1d0c+2209-0xd5b)+\
(0xdb1+5269-0x2083)-(0x25f2+5288-0x208d)));\
                                                           \
                                                                               \
    ((uint64_t *)(ReplacementFor_aux))[((0xad5+6894-0x2044)+6040-7435)] ^= ((\
ReplacementFor_ctx_t *)(ctx))->t[((0x19a5+868-0xa51)+(0xf2a+896-0x4f2)-8304)];\
                         \
    ((uint64_t *)(ReplacementFor_aux))[((0x4a4+7721-0x1fa1)+(0x1fc2+3254-0x1cb1)\
-(0x1dac+6590-0x2484))] ^= ((\
ReplacementFor_ctx_t *)(ctx))->t[((0x13b8+5809-0x1ab3)+(0x15ed+2425-0x18a7)-5748\
)];                         \
}                                                                              \
while (((0x20a8+2977-0x1b8d)+(0x1ce5+5489-0x1c10)-9986))
#define ReplacementFor_CAST(x) (((union { ReplacementFor___typeof__(x) a; \
uint64_t b; })x).b)
#define ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux)\
                                                    \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_aux))[(6186+(0x19bf+979-0x1a00)-7084)] = ((\
uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ ((0x2648+1273-0x105d)+(0x7df+2886-0xe7c)-\
8077)];         \
    ((uint64_t *)(ReplacementFor_aux))[((0x108d+8088-0x2418)+(0xe01+7701-0x1f44)\
-6350)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ ((0x1ec8+3542-0x19a3)+(0x1551+5113-0x1591)-\
9907)];         \
    ((uint64_t *)(ReplacementFor_aux))[((0x1ff0+193-0x1c3a)+8011-9136)] = ((\
uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ ((0xe28+8402-0x23e2)+(0x119f+3556-0x15c6)-\
(0x1767+4596-0x1488))];         \
    ((uint64_t *)(ReplacementFor_aux))[((0x215c+2695-0x2576)+\
(0x1af3+3314-0x2399)-(0x1858+5224-0x221a))] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ ((0x21e9+1387-0x251e)+4811-\
(0x1ed2+1498-0xfae))];         \
    ((uint64_t *)(ReplacementFor_aux))[(5672+(0x2e5+8880-0x2518)-\
(0x1e71+1083-0xc1b))] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ ((0x1fa5+2206-0x25e8)+(0xab4+1641-0xfaa)-\
(0x1ad1+1770-0x1df1))];         \
    ((uint64_t *)(ReplacementFor_aux))[(6837+(0x1904+3503-0x1f22)-8753)] = ((\
uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ ((0x1b0b+8541-0x2646)+(0x2210+1613-0x1af0)-\
9098)];         \
    ((uint64_t *)(ReplacementFor_aux))[((0xdfd+1022-0x908)+6732-9001)] = ((\
uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ ((0x13ef+2279-0xf73)+(0x2111+32-0x1017)-7799\
)];         \
    ((uint64_t *)(ReplacementFor_aux))[(8361+(0xfe0+5799-0x25d5)-\
(0x2262+3647-0xf5d))] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ ((0x175a+5946-0x2428)+(0x12e1+7165-0x2379)-\
5578)];         \
    ((uint64_t *)(ReplacementFor_aux))[((0x16a2+6978-0x2521)+\
(0x1a26+1626-0x1495)-(0x2302+2849-0x158d))] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ ((0x257a+4912-0x1dc0)+(0x1743+731-0x13df)-\
8481)];         \
    ((uint64_t *)(ReplacementFor_aux))[((0x2412+381-0x2244)+(0x1558+9353-0x26a0)\
-5747)] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[ ((0x870+1445-0xd81)+9299-9438)];         \
    ((uint64_t *)(ReplacementFor_aux))[(7722+(0x15fd+3244-0x1d49)-9072)] = ((\
uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[((0x1613+923-0x17c3)+(0xf53+8204-0x2232)-\
(0x1118+1833-0x933))];         \
    ((uint64_t *)(ReplacementFor_aux))[((0xdbf+2245-0x15ad)+6559-6747)] = ((\
uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[(5752+(0x18bc+1832-0x1e78)-6105)];         \
    ((uint64_t *)(ReplacementFor_aux))[((0x5a8+3626-0xe7a)+(0x143c+5558-0x17bb)-\
(0x1def+7595-0x2427))] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[((0x1af4+2354-0x2361)+(0xe62+5063-0x2035)-\
(0xfaf+2342-0x1628))];         \
    ((uint64_t *)(ReplacementFor_aux))[(4440+(0xc0a+6644-0x24a8)-\
(0x234c+2762-0x1b85))] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[((0x1505+2111-0x1337)+4896-7456)];         \
    ((uint64_t *)(ReplacementFor_aux))[(2282+(0x270d+472-0x110a)-\
(0x2705+3821-0x154b))] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[((0x1e11+845-0x1eff)+5057-5650)];         \
    ((uint64_t *)(ReplacementFor_aux))[((0x20d7+886-0x1fdb)+(0x25d8+3448-0x2707)\
-(0x12ad+2629-0xc56))] = ((uint64_t *)(((\
ReplacementFor_ctx_t *)(ctx))->b))[((0x723+7687-0x2392)+(0xf6c+4981-0x18c9)-\
(0xda6+4401-0x1336))];         \
                                                                               \
    ReplacementFor_B2B_MIX(ReplacementFor_aux, ReplacementFor_aux + \
((0x182c+5390-0x23c4)+(0x166b+5434-0x2065)-(0x1cd7+2316-0x113d)));\
                                                    \
                                                                               \
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0xd5b+2562-0x1753)+\
(0x145b+4312-0x24b4)-(0x2260+1168-0x2667))] ^= ((\
uint64_t *)(ReplacementFor_aux))[((0x1e4f+2898-0x1365)+(0x1106+2174-0xdc5)-8699)\
] ^ ((uint64_t *)(\
ReplacementFor_aux))[ ((0x834+2557-0xdd2)+(0xfac+7805-0x1fb6)-4810)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(4411+(0x14f2+8022-0x24bc)\
-8390)] ^= (\
(uint64_t *)(ReplacementFor_aux))[(7087+(0x12b2+1888-0x151b)-8357)] ^ ((uint64_t\
 *)(\
ReplacementFor_aux))[ (6970+(0x1499+1286-0x1461)-8303)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0x1a2a+2270-0xd43)+\
(0x1fa8+3292-0x1f76)-8913)] ^= (\
(uint64_t *)(ReplacementFor_aux))[((0x55f+2276-0x967)+(0x26dc+7665-0x23f7)-9648)\
] ^ ((uint64_t *)(\
ReplacementFor_aux))[((0x9e5+5836-0x1894)+(0xf1d+8966-0x23b7)-\
(0x26b3+4424-0x217c))];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0x1db9+6589-0x22af)+\
(0x1b50+682-0x106d)-8785)] ^= (\
(uint64_t *)(ReplacementFor_aux))[((0x1e53+190-0xdd7)+(0x1b17+2255-0x170b)-\
(0x1edf+3227-0xd68))] ^ ((uint64_t *)(\
ReplacementFor_aux))[((0x22e9+3469-0x19c6)+(0x11b7+6173-0x1da2)-8919)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[(6176+(0x1b7f+1656-0x19c9)\
-(0x2141+8745-0x2320))] ^= (\
(uint64_t *)(ReplacementFor_aux))[((0x121f+3418-0x1252)+(0x1d74+139-0xc8b)-\
(0x1f20+9100-0x2415))] ^ ((uint64_t *)(\
ReplacementFor_aux))[((0x534+3646-0x10fd)+(0x1320+1495-0x7d0)-5008)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0xae9+4246-0x1786)+\
(0xfb5+6065-0x21f9)-(0x1569+2915-0x176b))] ^= ((\
uint64_t *)(ReplacementFor_aux))[((0xf98+2865-0x18e1)+(0x1da5+2021-0xb15)-\
(0x243d+4117-0x17fa))] ^ ((uint64_t *)(\
ReplacementFor_aux))[(7860+(0x1c75+1411-0x2002)-8349)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0xf9c+3840-0x1354)+\
(0xd89+331-0x7b9)-4701)] ^= ((\
uint64_t *)(ReplacementFor_aux))[((0x1af9+3225-0xdd3)+(0x7bf+6362-0x1d67)-\
(0x1e33+8330-0x21d2))] ^ ((uint64_t *)(\
ReplacementFor_aux))[((0x2462+7319-0x2625)+(0xffa+1039-0xd64)-8555)];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[((0x1329+2205-0xfc3)+1189-\
4257)] ^= ((\
uint64_t *)(ReplacementFor_aux))[((0x2506+261-0x22e3)+(0x2161+2644-0x2347)-\
(0x20c6+2308-0x1e3b))] ^ ((uint64_t *)(\
ReplacementFor_aux))[(8743+(0x2182+1519-0x2379)-9744)];\
}                                                                              \
while (((0x90c+4463-0x14fe)+(0x14cc+1287-0x5cb)-6533))
#define ReplacementFor_HOST_B2B_H(ctx, ReplacementFor_aux)\
                                                   \
do                                                                             \
{                                                                              \
    ((ReplacementFor_ctx_t *)(ctx))->t[((0x1b7c+201-0x1a2e)+(0x2604+4624-0x17dc)\
-(0x24cb+3512-0x1034))] += \
ReplacementFor_BUF_SIZE_8;                                      \
    ((ReplacementFor_ctx_t *)(ctx))->t[((0xc85+2133-0x8f9)+5938-8978)] += \
((0x1d66+5124-0x1b58)+(0xc47+2056-0x883)-8669) - !(((ReplacementFor_ctx_t *)(ctx\
))->t[((0x1296+5291-0x194f)+(0x1659+4957-0x17a6)-(0x26dc+2315-0xfe5))]\
 < ReplacementFor_BUF_SIZE_8);      \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);\
                                                        \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);\
                                                       \
                                                                               \
    ((ReplacementFor_ctx_t *)(ctx))->c = ((0x13f8+733-0x4d0)+\
(0x1dfd+1084-0x11f4)-8778);\
                                                   \
}                                                                              \
while (((0x1da5+1222-0x16c1)+(0x22cc+7318-0x25fa)-9490))
#define ReplacementFor_HOST_B2B_H_LAST(ctx, ReplacementFor_aux)\
                                              \
do                                                                             \
{                                                                              \
    ((ReplacementFor_ctx_t *)(ctx))->t[((0x13b0+3105-0x17d0)+7841-9890)] += ((\
ReplacementFor_ctx_t *)(ctx))->c;                             \
    ((ReplacementFor_ctx_t *)(ctx))->t[((0x14a1+2795-0x1707)+\
(0x1310+5943-0x18d3)-6648)]\
                                                     \
        += ((0x1887+8086-0x2503)+(0x1cab+2539-0x23fc)-(0x2280+1233-0x119e)) - !(\
((ReplacementFor_ctx_t *)(ctx))->t[\
((0x179a+4044-0x21e0)+(0x865+309-0x293)-3213)] < ((ReplacementFor_ctx_t *)(ctx))\
->c);                \
                                                                               \
    while (((ReplacementFor_ctx_t *)(ctx))->c < ReplacementFor_BUF_SIZE_8)\
                                   \
    {                                                                          \
        ((ReplacementFor_ctx_t *)(ctx))->b[((ReplacementFor_ctx_t *)(ctx))->c++]\
 = ((0x210c+964-0x2387)+(0x1ad0+4415-0x167c)-(0x1866+7392-0x1e6a));\
                        \
    }                                                                          \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);\
                                                        \
                                                                               \
    ((uint64_t *)(ReplacementFor_aux))[((0x20d5+3846-0x1625)+\
(0x1560+3873-0x1d1c)-(0x26b2+631-0x81c))] = ~((uint64_t *)(\
ReplacementFor_aux))[((0xec1+1801-0x1521)+(0x18df+1634-0x1cf7)-\
(0x1737+3846-0x2358))];                        \
                                                                               \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);\
                                                       \
}                                                                              \
while ((4842+(0x605+3487-0xfac)-(0x1df1+2382-0x105d)))
#define ReplacementFor_DEVICE_B2B_H(ctx, ReplacementFor_aux)\
                                                 \
do                                                                             \
{                                                                              \
    asm volatile (                                                             \
        \
\
"\x61\x64\x64\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x31\x32\x38\x3b"\
: "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
(8881+(0xf9d+385-0x103a)-9109)])  \
    );                                                                         \
    asm volatile (                                                             \
        \
\
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
: "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
((0x1674+4547-0x1c88)+(0x20a9+605-0x1a0e)-5286)])   \
    );                                                                         \
    asm volatile (                                                             \
        \
\
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
: "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
(6304+(0x1e1f+2485-0x1e83)-8687)])   \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b": \
"\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[(\
(0x2218+3054-0x232d)+(0x20e5+6542-0x2260)-8937)]\
)      \
    );                                                                         \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);\
                                                        \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);\
                                                       \
                                                                               \
    ((ReplacementFor_ctx_t *)(ctx))->c = ((0xee0+7108-0x1e24)+\
(0x20c8+1920-0x1b60)-6504);\
                                                   \
}                                                                              \
while ((3257+(0x191b+1618-0x1df7)-(0x1cfa+4520-0x2073)))
#define ReplacementFor_DEVICE_B2B_H_LAST(ctx, ReplacementFor_aux)\
                                            \
do                                                                             \
{                                                                              \
    asm volatile (                                                             \
        \
\
"\x61\x64\x64\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x25\x31\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
(9195+(0x7e5+3965-0x1754)-(0x2686+3440-0xffd))]):                            \
        "\x72"(((ReplacementFor_ctx_t *)(ctx))->c)\
                                               \
    );                                                                         \
    asm volatile (                                                             \
        \
\
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
((0x1024+1830-0x851)+(0x167c+6464-0x2553)-(0x1d42+1554-0x9f3))])\
                             \
    );                                                                         \
    asm volatile (                                                             \
        \
\
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
((0xa02+5156-0x1501)+5662-8001)])                             \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b":\
                                                 \
        "\x2b\x72"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[\
(4842+(0x97c+2648-0x139f)-(0x1df3+1716-0x118b))])                             \
    );                                                                         \
                                                                               \
    while (((ReplacementFor_ctx_t *)(ctx))->c < ReplacementFor_BUF_SIZE_8)\
                                   \
    {                                                                          \
        ((ReplacementFor_ctx_t *)(ctx))->b[((ReplacementFor_ctx_t *)(ctx))->c++]\
 = ((0x25e8+840-0x20ef)+(0x12f7+1386-0x87d)-(0x208b+2389-0x11bb));\
                        \
    }                                                                          \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);\
                                                        \
                                                                               \
    ((uint64_t *)(ReplacementFor_aux))[((0x12d7+4691-0x24ee)+\
(0x1432+2922-0x1835)-(0x1971+1273-0x16d5))] = ~((uint64_t *)(\
ReplacementFor_aux))[((0x49c+6268-0x1a99)+8053-8678)];                        \
                                                                               \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);\
                                                       \
}                                                                              \
while (((0x1ae1+1062-0x717)+(0xd0f+6232-0x230a)-(0x1ba9+2589-0xb79)))
#define ReplacementFor_REVERSE_ENDIAN(p)\
                                                      \
    ((((uint64_t)((uint8_t *)(p))[((0x1340+1346-0x121c)+4281-(0x2514+754-0x10e7)\
)]) << ((0x1671+3520-0x140c)+(0x1c7f+6936-0x2087)-9981))\
 ^                                 \
    (((uint64_t)((uint8_t *)(p))[(6080+(0x218f+837-0x218e)-(0x1dd4+8274-0x2321))\
]) << ((0x20d2+2317-0x2457)+(0x18cc+1474-0x1169)-(0x1abd+947-0xbf3))) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(9279+(0x1741+3668-0x23e6)-9708)]) << (\
(0x1d72+7502-0x1e2f)+(0xbdc+3687-0x102d)-9855)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[((0x1421+2149-0xd3f)+(0x248f+2457-0x270c)-\
(0x19da+567-0x5b1))]) << ((0x15e3+655-0x60c)+(0xb51+1393-0x7a7)-7009)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[((0x1d0d+5499-0x1ad7)+(0x8e4+7244-0x1e51)-7820)\
]) << ((0xaf4+138-0x14c)+7271-9857)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[((0x1921+5089-0x2288)+(0x1a5c+1260-0x1d07)-\
(0x172a+3749-0x1919))]) << ((0x1cff+6948-0x26f7)+(0x11b7+108-0x1067)-\
(0x1fc8+5112-0x20e8))) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[((0x2ba+3728-0xf7b)+(0x578+5668-0x197f)-\
(0x73b+6107-0x1b30))]) << (3639+(0x1067+7981-0x2660)-(0x1a0c+9011-0x25dc))) ^\
                                   \
    ((uint64_t)((uint8_t *)(p))[((0x252+9201-0x255f)+8447-(0x2231+6762-0x1abf))]\
))
#define ReplacementFor_INPLACE_REVERSE_ENDIAN(p)\
                                              \
do                                                                             \
{                                                                              \
    *((uint64_t *)(p))                                                         \
    = ((((uint64_t)((uint8_t *)(p))[((0x1784+2423-0x1e4e)+4565-\
(0x264b+5301-0x267e))]) << \
((0x13dc+8503-0x2419)+(0x1d81+4888-0x2286)-7893)) ^\
                               \
    (((uint64_t)((uint8_t *)(p))[((0x1d67+8199-0x23b7)+(0x1b0d+1896-0x1868)-9155\
)]) << ((0xbea+8135-0x2085)+(0xb7a+5449-0x1ea5)-(0x13c8+7702-0x24c4))) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(7429+(0xd4a+8112-0x2585)-9336)]) << (\
(0xb7f+5923-0x188c)+(0x2157+3609-0x19c9)-8085)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[((0x192f+1552-0x1ea8)+(0x16d1+3204-0x1f33)-\
(0x1101+1852-0x1387))]) << ((0xa3d+6819-0x2315)+(0x1fc6+1959-0xb99)-7551)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(7255+(0x20f6+3301-0x2529)-9477)]) << (\
(0x26fd+829-0x167b)+(0x155f+4297-0x1ae4)-7915))\
 ^                                  \
    (((uint64_t)((uint8_t *)(p))[((0x215f+866-0x111c)+(0x1a5f+3558-0x1c10)-\
(0x2637+6845-0x211f))]) << ((0xca9+6011-0x1ce7)+(0x140b+3675-0x1349)-\
(0x23ef+619-0x1010))) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[((0x2292+2373-0x131e)+(0x16ba+4769-0x255d)-\
(0x1d86+3070-0xcd3))]) << ((0x13d5+4567-0x2306)+(0x13ed+6065-0x2654)-\
(0x104b+5040-0x1c13))) ^\
                                   \
    ((uint64_t)((uint8_t *)(p))[((0x10dd+3036-0xd44)+5726-9676)]));\
                                          \
}                                                                              \
while (((0x942+7030-0x2047)+(0x2588+780-0x6c5)-9792))
#define FREE(x)                                                                \
do                                                                             \
{                                                                              \
    if (x)                                                                     \
    {                                                                          \
        free(x);                                                               \
        (x) = NULL;                                                            \
    }                                                                          \
}                                                                              \
while (((0xe28+8662-0x24e7)+(0x220d+4042-0x2071)-(0x2235+5439-0x1af7)))
#define ReplacementFor_CUDA_CALL(x)\
                                                           \
do                                                                             \
{                                                                              \
    if ((x) != ReplacementFor_cudaSuccess)\
                                                    \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((6228+(0x191b+3255-0x1dc5)-8289))
#define ReplacementFor_CALL(ReplacementFor_func, name)\
                                                       \
do                                                                             \
{                                                                              \
    if (!(ReplacementFor_func))\
                                                               \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((3237+(0x1bfc+5722-0x2460)-6811))
#define ReplacementFor_FUNCTION_CALL(ReplacementFor_res, ReplacementFor_func, \
name)                                         \
do                                                                             \
{                                                                              \
    if (!((ReplacementFor_res) = (ReplacementFor_func)))\
                                                     \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while (((0x194c+3499-0x2561)+(0xdbf+1246-0x88f)-(0xfcc+849-0x779)))
#define ReplacementFor_CALL_STATUS(ReplacementFor_func, name, status)\
                                        \
do                                                                             \
{                                                                              \
    if ((ReplacementFor_func) != (status))\
                                                    \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while (((0x9b5+464-0x68c)+(0x147f+592-0x7f0)-5080))
#define ReplacementFor_FUNCTION_CALL_STATUS(ReplacementFor_res, \
ReplacementFor_func, name, status)                          \
do                                                                             \
{                                                                              \
    if ((ReplacementFor_res = ReplacementFor_func) != (status))\
                                              \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while (((0x24dc+2247-0x2444)+(0xdc2+1282-0x94c)-4823))
#define ReplacementFor_PERSISTENT_CALL(ReplacementFor_func)\
                                                  \
do {} while (!(ReplacementFor_func))
#define ReplacementFor_PERSISTENT_FUNCTION_CALL(ReplacementFor_res, \
ReplacementFor_func)                                    \
do {} while (!((ReplacementFor_res) = (ReplacementFor_func)))
#define ReplacementFor_PERSISTENT_CALL_STATUS(ReplacementFor_func, status)\
                                   \
do {} while ((ReplacementFor_func) != (status))
#define ReplacementFor_PERSISTENT_FUNCTION_CALL_STATUS(ReplacementFor_func, \
status)                          \
do {} while (((ReplacementFor_res) = (ReplacementFor_func)) != (status))
#endif 


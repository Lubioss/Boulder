
#define ReplacementFor_ELPP_THREAD_SAFE
#define ReplacementFor_ELPP_WINSOCK2
#ifndef ReplacementFor_EASYLOGGINGPP_H
#define ReplacementFor_EASYLOGGINGPP_H
#if __cplusplus >= 201103L
#  define ReplacementFor_ELPP_CXX11 ((0x2017+1398-0xac2)+(0x1133+6915-0x22b8)-\
9288)
#endif  
#if (defined(__GNUC__))
#  define ReplacementFor_ELPP_COMPILER_GCC ((0xd7d+6113-0x1b54)+\
(0x2024+7850-0x264b)-8844)
#else
#  define ReplacementFor_ELPP_COMPILER_GCC ((0x1264+6007-0x257e)+\
(0x1d3d+2626-0x1f6d)-(0x153f+6832-0x2380))
#endif
#if ReplacementFor_ELPP_COMPILER_GCC
#    define ReplacementFor_ELPP_GCC_VERSION (__GNUC__ * 10000 \
+ __GNUC_MINOR__ * ((0x193a+2887-0x1071)+(0x1358+656-0x1355)-\
(0x1d3d+5506-0x1c80)) \
+ ReplacementFor___GNUC_PATCHLEVEL__)
#  if defined(ReplacementFor___GXX_EXPERIMENTAL_CXX0X__)
#    define ReplacementFor_ELPP_CXX0X ((0x935+4399-0x1270)+7860-9895)
#  endif
#endif
#if defined(_MSC_VER)
#  define ReplacementFor_ELPP_COMPILER_MSVC ((0x1726+6944-0x26a0)+\
(0x200b+4668-0x1abf)-9005)
#else
#  define ReplacementFor_ELPP_COMPILER_MSVC ((0x1ff4+647-0x11fa)+\
(0x15fb+6146-0x25f8)-6278)
#endif
#define ReplacementFor_ELPP_CRT_DBG_WARNINGS ReplacementFor_ELPP_COMPILER_MSVC
#if ReplacementFor_ELPP_COMPILER_MSVC
#  if (_MSC_VER == ((0x226b+2720-0x20d0)+7668-9199))
#    define ReplacementFor_ELPP_CXX0X ((0x83c+3185-0xfc8)+(0x1bb8+6323-0x1e1f)-\
6960)
#  elif(_MSC_VER >= (6875+(0x2207+3650-0x1ee0)-9632))
#    define ReplacementFor_ELPP_CXX11 ((0x864+3203-0x10b5)+(0x1d53+918-0x3ab)-\
8559)
#  endif
#endif
#if (defined(ReplacementFor___clang__) && (ReplacementFor___clang__ == \
((0x264b+326-0x1f61)+6922-(0x2650+5489-0x1888))))
#  define ReplacementFor_ELPP_COMPILER_CLANG ((0xb09+789-0x778)+\
(0x1501+2636-0xd90)-(0x2230+1531-0xfc9))
#else
#  define ReplacementFor_ELPP_COMPILER_CLANG ((0xc04+5513-0x15c1)+\
(0x229b+926-0x1c1f)-5606)
#endif
#if ReplacementFor_ELPP_COMPILER_CLANG
#  if ReplacementFor___has_include(<thread>)
#    include <cstddef> 
#    if !defined(ReplacementFor___GLIBCXX__) || ReplacementFor___GLIBCXX__ >= \
20150426
#      define ReplacementFor_ELPP_CLANG_SUPPORTS_THREAD
#    endif 
#  endif 
#endif
#if (defined(__MINGW32__) || defined(ReplacementFor___MINGW64__))
#  define ReplacementFor_ELPP_MINGW ((0x16df+1436-0x1527)+(0x177c+208-0x1356)-\
(0x1a7a+548-0x1055))
#else
#  define ReplacementFor_ELPP_MINGW ((0x1322+1313-0x10e8)+(0x1570+3958-0x16e8)-\
(0x196b+2724-0xeb6))
#endif
#if (defined(__CYGWIN__) && (__CYGWIN__ == ((0x1451+1565-0x1176)+6592-8887)))
#  define ReplacementFor_ELPP_CYGWIN ((0x1881+6009-0x22a8)+(0x195a+3374-0x1f09)-\
(0x1749+2073-0xa92))
#else
#  define ReplacementFor_ELPP_CYGWIN ((0xf33+4876-0x1686)+(0x2401+1605-0x223e)-\
(0x1a38+6345-0x1f40))
#endif
#if (defined(ReplacementFor___INTEL_COMPILER))
#  define ReplacementFor_ELPP_COMPILER_INTEL ((0xe6f+3440-0x11d8)+\
(0x1f97+5067-0x20e5)-7299)
#else
#  define ReplacementFor_ELPP_COMPILER_INTEL ((0x2054+1447-0x2068)+7295-\
(0x23e2+4013-0x117d))
#endif
#if (defined(_WIN32) || defined(ReplacementFor__WIN64))
#  define ReplacementFor_ELPP_OS_WINDOWS ((0x19ab+5503-0x1d50)+4245-8814)
#else
#  define ReplacementFor_ELPP_OS_WINDOWS ((0x12fa+5953-0x233c)+\
(0x20d5+7681-0x2561)-(0x2609+6589-0x1f52))
#endif
#if (defined(ReplacementFor___linux) || defined(ReplacementFor___linux__))
#  define ReplacementFor_ELPP_OS_LINUX ((0xd56+5762-0x1753)+5914-\
(0x25ab+7616-0x1fcd))
#else
#  define ReplacementFor_ELPP_OS_LINUX (9103+(0x6a8+8717-0x26e1)-9571)
#endif
#if (defined(ReplacementFor___APPLE__))
#  define ReplacementFor_ELPP_OS_MAC ((0x1e0f+498-0x840)+(0x15f7+3911-0x19e1)-\
8989)
#else
#  define ReplacementFor_ELPP_OS_MAC ((0x1a4c+3305-0x1f2b)+(0x6c5+4289-0x15b6)-\
(0xdc6+8586-0x2576))
#endif
#if (defined(__FreeBSD__) || defined(ReplacementFor___FreeBSD_kernel__))
#  define ReplacementFor_ELPP_OS_FREEBSD ((0x8b7+4194-0x116f)+(0x1693+461-0x61a)\
-(0x2547+2445-0x14e5))
#else
#  define ReplacementFor_ELPP_OS_FREEBSD ((0x8f7+979-0x457)+(0x10b8+7648-0x1e90)\
-6267)
#endif
#if (defined(__sun))
#  define ReplacementFor_ELPP_OS_SOLARIS ((0xa64+1072-0xceb)+8454-8878)
#else
#  define ReplacementFor_ELPP_OS_SOLARIS ((0x16c5+1575-0x1c33)+\
(0x147c+6934-0x1c57)-5108)
#endif
#if (defined(_AIX))
#  define ReplacementFor_ELPP_OS_AIX ((0x7a4+2747-0x113d)+(0x9e2+652-0xb81)-\
(0x117f+4665-0x21aa))
#else
#  define ReplacementFor_ELPP_OS_AIX ((0x15c3+4123-0x1e53)+6293-\
(0x244d+3328-0x112d))
#endif
#if (defined(__NetBSD__))
#  define ReplacementFor_ELPP_OS_NETBSD ((0x1a7c+4760-0x2333)+\
(0x2488+1436-0x1dca)-(0x1c27+4708-0x1851))
#else
#  define ReplacementFor_ELPP_OS_NETBSD ((0x11c3+7788-0x1eeb)+\
(0xf43+5234-0x1c7c)-(0x2450+192-0xc93))
#endif
#if defined(ReplacementFor___EMSCRIPTEN__)
#  define ReplacementFor_ELPP_OS_EMSCRIPTEN ((0x2411+1120-0x59c)+\
(0x25ad+72-0x2563)-(0x26ab+4406-0x147b))
#else
#  define ReplacementFor_ELPP_OS_EMSCRIPTEN ((0xa9f+5216-0x1d96)+\
(0xf86+545-0xdcb)-(0xa06+4810-0x178b))
#endif
#if ((ReplacementFor_ELPP_OS_LINUX || ReplacementFor_ELPP_OS_MAC || \
ReplacementFor_ELPP_OS_FREEBSD || ReplacementFor_ELPP_OS_NETBSD || \
ReplacementFor_ELPP_OS_SOLARIS || ReplacementFor_ELPP_OS_AIX || \
ReplacementFor_ELPP_OS_EMSCRIPTEN) && (!ReplacementFor_ELPP_OS_WINDOWS))
#  define ReplacementFor_ELPP_OS_UNIX ((0x120f+5196-0x1525)+(0x12e6+4495-0x1414)\
-8598)
#else
#  define ReplacementFor_ELPP_OS_UNIX ((0x87c+6487-0x1c5f)+2879-\
(0x1e68+5350-0x229b))
#endif
#if (defined(ReplacementFor___ANDROID__))
#  define ReplacementFor_ELPP_OS_ANDROID ((0x1408+9031-0x264b)+\
(0x13b0+1754-0xcf8)-7829)
#else
#  define ReplacementFor_ELPP_OS_ANDROID (6694+(0x1773+2859-0x21bf)-6917)
#endif
#if !ReplacementFor_ELPP_OS_UNIX && !ReplacementFor_ELPP_OS_WINDOWS && \
ReplacementFor_ELPP_CYGWIN
#  undef ReplacementFor_ELPP_OS_UNIX
#  undef ReplacementFor_ELPP_OS_LINUX
#  define ReplacementFor_ELPP_OS_UNIX ((0x1c1f+7277-0x2314)+(0x15dc+3795-0x19a2)\
-8324)
#  define ReplacementFor_ELPP_OS_LINUX ((0x1fad+1613-0x1aa8)+5095-\
(0x237b+7853-0x22f0))
#endif 
#if !defined(ReplacementFor_ELPP_INTERNAL_DEBUGGING_OUT_INFO)
#  define ReplacementFor_ELPP_INTERNAL_DEBUGGING_OUT_INFO std::cout
#endif 
#if !defined(ReplacementFor_ELPP_INTERNAL_DEBUGGING_OUT_ERROR)
#  define ReplacementFor_ELPP_INTERNAL_DEBUGGING_OUT_ERROR std::cerr
#endif 
#if !defined(ReplacementFor_ELPP_INTERNAL_DEBUGGING_ENDL)
#  define ReplacementFor_ELPP_INTERNAL_DEBUGGING_ENDL std::endl
#endif 
#if !defined(ReplacementFor_ELPP_INTERNAL_DEBUGGING_MSG)
#  define ReplacementFor_ELPP_INTERNAL_DEBUGGING_MSG(msg) msg
#endif 
#if !defined(ReplacementFor_ELPP_DISABLE_ASSERT)
#  if (defined(ReplacementFor_ELPP_DEBUG_ASSERT_FAILURE))
#    define ReplacementFor_ELPP_ASSERT(ReplacementFor_expr, msg) if (!(\
ReplacementFor_expr)) { \
std::stringstream ReplacementFor_internalInfoStream; \
ReplacementFor_internalInfoStream << msg; \
ReplacementFor_ELPP_INTERNAL_DEBUGGING_OUT_ERROR \
<< \
\
"\x45\x41\x53\x59\x4c\x4f\x47\x47\x49\x4e\x47\x2b\x2b\x20\x41\x53\x53\x45\x52\x54\x49\x4f\x4e\x20\x46\x41\x49\x4c\x45\x44\x20\x28\x4c\x49\x4e\x45\x3a\x20"\
 << __LINE__ << "\x29\x20\x5b" #ReplacementFor_expr << \
"\x5d\x20\x57\x49\x54\x48\x20\x4d\x45\x53\x53\x41\x47\x45\x20" "\"" \
<< ReplacementFor_ELPP_INTERNAL_DEBUGGING_MSG(ReplacementFor_internalInfoStream.\
str()) << "\"" << ReplacementFor_ELPP_INTERNAL_DEBUGGING_ENDL; base::\
ReplacementFor_utils::abort(((0x1285+1680-0xe7f)+(0x1bc1+5312-0x15c3)-\
(0x25c9+482-0x258)), \
\
\
"\x45\x4c\x50\x50\x20\x41\x73\x73\x65\x72\x74\x69\x6f\x6e\x20\x66\x61\x69\x6c\x75\x72\x65\x2c\x20\x70\x6c\x65\x61\x73\x65\x20\x64\x65\x66\x69\x6e\x65\x20\x45\x4c\x50\x50\x5f\x44\x45\x42\x55\x47\x5f\x41\x53\x53\x45\x52\x54\x5f\x46\x41\x49\x4c\x55\x52\x45"\
); }
#  else
#    define ReplacementFor_ELPP_ASSERT(ReplacementFor_expr, msg) if (!(\
ReplacementFor_expr)) { \
std::stringstream ReplacementFor_internalInfoStream; \
ReplacementFor_internalInfoStream << msg; \
ReplacementFor_ELPP_INTERNAL_DEBUGGING_OUT_ERROR\
<< \
\
"\x41\x53\x53\x45\x52\x54\x49\x4f\x4e\x20\x46\x41\x49\x4c\x55\x52\x45\x20\x46\x52\x4f\x4d\x20\x45\x41\x53\x59\x4c\x4f\x47\x47\x49\x4e\x47\x2b\x2b\x20\x28\x4c\x49\x4e\x45\x3a\x20"\
 \
<< __LINE__ << "\x29\x20\x5b" #ReplacementFor_expr << \
"\x5d\x20\x57\x49\x54\x48\x20\x4d\x45\x53\x53\x41\x47\x45\x20" "\"" << \
ReplacementFor_ELPP_INTERNAL_DEBUGGING_MSG(ReplacementFor_internalInfoStream.str\
()) << "\"" \
<< ReplacementFor_ELPP_INTERNAL_DEBUGGING_ENDL; }
#  endif  
#else
#  define ReplacementFor_ELPP_ASSERT(x, y)
#endif  
#if ReplacementFor_ELPP_COMPILER_MSVC
#  define ReplacementFor_ELPP_INTERNAL_DEBUGGING_WRITE_PERROR \
{ char ReplacementFor_buff[((0x17e0+882-0x480)+(0x558+6680-0x1bd5)-\
(0x1b31+4026-0x117e))]; ReplacementFor_strerror_s(\
ReplacementFor_buff, ((0x150d+5504-0x22e8)+(0x26df+2089-0x2021)-\
(0x258d+4195-0x2064)), errno); \
ReplacementFor_ELPP_INTERNAL_DEBUGGING_OUT_ERROR << "\x3a\x20" << \
ReplacementFor_buff << "\x20\x5b" << errno << "\x5d";} (void)(\
(0x20bc+1561-0x1b56)+(0x1549+4360-0x180a)-6598)
#else
#  define ReplacementFor_ELPP_INTERNAL_DEBUGGING_WRITE_PERROR \
ReplacementFor_ELPP_INTERNAL_DEBUGGING_OUT_ERROR << "\x3a\x20" << strerror(errno\
) << "\x20\x5b" << errno << "\x5d"; (void)((0x1db6+5087-0x1701)+\
(0xb86+6430-0x1f50)-8168)
#endif  
#if defined(ReplacementFor_ELPP_DEBUG_ERRORS)
#  if !defined(ReplacementFor_ELPP_INTERNAL_ERROR)
#    define ReplacementFor_ELPP_INTERNAL_ERROR(msg, ReplacementFor_pe) { \
std::stringstream ReplacementFor_internalInfoStream; \
ReplacementFor_internalInfoStream << "\x3c\x45\x52\x52\x4f\x52\x3e\x20" << msg; \
ReplacementFor_ELPP_INTERNAL_DEBUGGING_OUT_ERROR \
<< \
\
"\x45\x52\x52\x4f\x52\x20\x46\x52\x4f\x4d\x20\x45\x41\x53\x59\x4c\x4f\x47\x47\x49\x4e\x47\x2b\x2b\x20\x28\x4c\x49\x4e\x45\x3a\x20"\
 << __LINE__ << "\x29\x20" \
<< ReplacementFor_ELPP_INTERNAL_DEBUGGING_MSG(ReplacementFor_internalInfoStream.\
str()) << ReplacementFor_ELPP_INTERNAL_DEBUGGING_ENDL; \
if (ReplacementFor_pe) { ReplacementFor_ELPP_INTERNAL_DEBUGGING_OUT_ERROR << \
"\x20\x20\x20\x20"; ReplacementFor_ELPP_INTERNAL_DEBUGGING_WRITE_PERROR; }} (\
void)((0x14b0+6334-0x21b1)+(0x14ec+1047-0xacb)-6645)
#  endif
#else
#  undef ReplacementFor_ELPP_INTERNAL_INFO
#  define ReplacementFor_ELPP_INTERNAL_ERROR(msg, ReplacementFor_pe)
#endif  
#if (defined(ReplacementFor_ELPP_DEBUG_INFO))
#  if !(defined(ReplacementFor_ELPP_INTERNAL_INFO_LEVEL))
#    define ReplacementFor_ELPP_INTERNAL_INFO_LEVEL ((0x1c56+1036-0x1581)+5514-\
(0x25c0+8043-0x24c9))
#  endif  
#  if !defined(ReplacementFor_ELPP_INTERNAL_INFO)
#    define ReplacementFor_ELPP_INTERNAL_INFO(ReplacementFor_lvl, msg) { if (\
ReplacementFor_lvl <= ReplacementFor_ELPP_INTERNAL_INFO_LEVEL) { \
std::stringstream ReplacementFor_internalInfoStream; \
ReplacementFor_internalInfoStream << "\x3c\x49\x4e\x46\x4f\x3e\x20" << msg; \
ReplacementFor_ELPP_INTERNAL_DEBUGGING_OUT_INFO << \
ReplacementFor_ELPP_INTERNAL_DEBUGGING_MSG(ReplacementFor_internalInfoStream.str\
()) \
<< ReplacementFor_ELPP_INTERNAL_DEBUGGING_ENDL; }}
#  endif
#else
#  undef ReplacementFor_ELPP_INTERNAL_INFO
#  define ReplacementFor_ELPP_INTERNAL_INFO(ReplacementFor_lvl, msg)
#endif  
#if (defined(ReplacementFor_ELPP_FEATURE_ALL)) || (defined(\
ReplacementFor_ELPP_FEATURE_CRASH_LOG))
#  if (ReplacementFor_ELPP_COMPILER_GCC && !ReplacementFor_ELPP_MINGW && !\
ReplacementFor_ELPP_OS_ANDROID && !ReplacementFor_ELPP_OS_EMSCRIPTEN)
#    define ReplacementFor_ELPP_STACKTRACE (4685+(0x1dff+1570-0x1b23)-\
(0x2257+234-0x7f7))
#  else
#      if ReplacementFor_ELPP_COMPILER_MSVC
#         pragma message("Stack trace not available for this compiler")
#      else
#         ReplacementFor_warning \
\
"\x53\x74\x61\x63\x6b\x20\x74\x72\x61\x63\x65\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x63\x6f\x6d\x70\x69\x6c\x65\x72"\
;
#      endif  
#    define ReplacementFor_ELPP_STACKTRACE (5000+(0x1734+2936-0x146c)-8648)
#  endif  
#else
#    define ReplacementFor_ELPP_STACKTRACE ((0x1950+3538-0x107f)+\
(0x868+3688-0x110c)-7271)
#endif  
#define ReplacementFor_ELPP_UNUSED(x) (void)x
#if ReplacementFor_ELPP_OS_UNIX
#  define ReplacementFor_ELPP_LOG_PERMS S_IRUSR | S_IWUSR | S_IXUSR | S_IWGRP | \
S_IRGRP | S_IXGRP | S_IWOTH | S_IXOTH
#endif  
#if defined(ReplacementFor_ELPP_AS_DLL) && ReplacementFor_ELPP_COMPILER_MSVC
#  if defined(ReplacementFor_ELPP_EXPORT_SYMBOLS)
#    define ReplacementFor_ELPP_EXPORT __declspec(dllexport)
#  else
#    define ReplacementFor_ELPP_EXPORT __declspec(dllimport)
#  endif  
#else
#  define ReplacementFor_ELPP_EXPORT
#endif  
#undef STRTOK
#undef STRERROR
#undef STRCAT
#undef STRCPY
#if ReplacementFor_ELPP_CRT_DBG_WARNINGS
#  define STRTOK(a, b, c) strtok_s(a, b, c)
#  define STRERROR(a, b, c) ReplacementFor_strerror_s(a, b, c)
#  define STRCAT(a, b, len) ReplacementFor_strcat_s(a, len, b)
#  define STRCPY(a, b, len) ReplacementFor_strcpy_s(a, len, b)
#else
#  define STRTOK(a, b, c) strtok(a, b)
#  define STRERROR(a, b, c) strerror(c)
#  define STRCAT(a, b, len) strcat(a, b)
#  define STRCPY(a, b, len) strcpy(a, b)
#endif
#if (ReplacementFor_ELPP_MINGW && !defined(\
ReplacementFor_ELPP_FORCE_USE_STD_THREAD))
#  define ReplacementFor_ELPP_USE_STD_THREADING ((0x1317+721-0x122d)+\
(0x1e23+7183-0x2669)-(0x231d+6207-0x23d8))
#else
#  if ((ReplacementFor_ELPP_COMPILER_CLANG && defined(\
ReplacementFor_ELPP_CLANG_SUPPORTS_THREAD)) || \
       (!ReplacementFor_ELPP_COMPILER_CLANG && defined(ReplacementFor_ELPP_CXX11\
)) || \
       defined(ReplacementFor_ELPP_FORCE_USE_STD_THREAD))
#    define ReplacementFor_ELPP_USE_STD_THREADING ((0xa7d+1467-0xe42)+\
(0x1b1c+5600-0x1da1)-(0x1649+6893-0x1be6))
#  else
#    define ReplacementFor_ELPP_USE_STD_THREADING ((0x18f0+6989-0x1f64)+\
(0x1f29+573-0x12dc)-9059)
#  endif
#endif
#undef ReplacementFor_ELPP_FINAL
#if ReplacementFor_ELPP_COMPILER_INTEL || (ReplacementFor_ELPP_GCC_VERSION < \
40702)
#  define ReplacementFor_ELPP_FINAL
#else
#  define ReplacementFor_ELPP_FINAL final
#endif  
#if defined(ReplacementFor_ELPP_EXPERIMENTAL_ASYNC)
#  define ReplacementFor_ELPP_ASYNC_LOGGING ((0x860+6276-0x1d9e)+8536-9373)
#else
#  define ReplacementFor_ELPP_ASYNC_LOGGING ((0x881+397-0x394)+\
(0x1768+1325-0x64d)-(0x2061+2345-0xcc8))
#endif 
#if defined(ReplacementFor_ELPP_THREAD_SAFE) || \
ReplacementFor_ELPP_ASYNC_LOGGING
#  define ReplacementFor_ELPP_THREADING_ENABLED ((0x2b3+9656-0x26c3)+8906-\
(0x2626+7619-0x1f78))
#else
#  define ReplacementFor_ELPP_THREADING_ENABLED (8458+(0x823+4861-0x1af1)-8505)
#endif  
#undef ReplacementFor_ELPP_FUNC
#if ReplacementFor_ELPP_COMPILER_MSVC  
#  define ReplacementFor_ELPP_FUNC ReplacementFor___FUNCSIG__
#elif ReplacementFor_ELPP_COMPILER_GCC  
#  define ReplacementFor_ELPP_FUNC ReplacementFor___PRETTY_FUNCTION__
#elif ReplacementFor_ELPP_COMPILER_INTEL  
#  define ReplacementFor_ELPP_FUNC ReplacementFor___PRETTY_FUNCTION__
#elif ReplacementFor_ELPP_COMPILER_CLANG  
#  define ReplacementFor_ELPP_FUNC ReplacementFor___PRETTY_FUNCTION__
#else
#  if defined(ReplacementFor___func__)
#    define ReplacementFor_ELPP_FUNC ReplacementFor___func__
#  else
#    define ReplacementFor_ELPP_FUNC ""
#  endif  
#endif  
#undef ReplacementFor_ELPP_VARIADIC_TEMPLATES_SUPPORTED
#define ReplacementFor_ELPP_VARIADIC_TEMPLATES_SUPPORTED \
(ReplacementFor_ELPP_COMPILER_GCC || ReplacementFor_ELPP_COMPILER_CLANG || \
ReplacementFor_ELPP_COMPILER_INTEL || (ReplacementFor_ELPP_COMPILER_MSVC && \
_MSC_VER >= ((0x1635+5233-0x21e1)+(0xd4c+5058-0x1be3)-(0x104b+2217-0x120c))))
#if defined(ReplacementFor_ELPP_DISABLE_LOGS)
#define ReplacementFor_ELPP_LOGGING_ENABLED ((0x148f+4569-0x2254)+\
(0x2403+6358-0x1e81)-(0x22df+1761-0x754))
#else
#define ReplacementFor_ELPP_LOGGING_ENABLED ((0x955+8639-0x2251)+\
(0x1fe8+6111-0x2256)-(0x1fd8+2116-0x9e9))
#endif
#if (!defined(ReplacementFor_ELPP_DISABLE_DEBUG_LOGS) && (\
ReplacementFor_ELPP_LOGGING_ENABLED))
#  define ReplacementFor_ELPP_DEBUG_LOG ((0x1c25+87-0xcf4)+(0x1946+3614-0x1f30)-\
6075)
#else
#  define ReplacementFor_ELPP_DEBUG_LOG ((0x1024+8234-0x2637)+(0x848+2385-0xeaa)\
-(0x1fe3+703-0x159c))
#endif  
#if (!defined(ReplacementFor_ELPP_DISABLE_INFO_LOGS) && (\
ReplacementFor_ELPP_LOGGING_ENABLED))
#  define ReplacementFor_ELPP_INFO_LOG ((0x2306+5939-0x25bd)+(0x2e5+582-0x2ab)-\
5883)
#else
#  define ReplacementFor_ELPP_INFO_LOG (5620+(0x11df+1967-0x14a4)-\
(0x1db1+2611-0xd06))
#endif  
#if (!defined(ReplacementFor_ELPP_DISABLE_WARNING_LOGS) && (\
ReplacementFor_ELPP_LOGGING_ENABLED))
#  define ReplacementFor_ELPP_WARNING_LOG ((0x244b+4164-0x2234)+\
(0x410+6015-0x1a09)-5088)
#else
#  define ReplacementFor_ELPP_WARNING_LOG ((0x9d1+4834-0x16a8)+8249-9796)
#endif  
#if (!defined(ReplacementFor_ELPP_DISABLE_ERROR_LOGS) && (\
ReplacementFor_ELPP_LOGGING_ENABLED))
#  define ReplacementFor_ELPP_ERROR_LOG ((0x19b1+8222-0x21c4)+\
(0xeb6+1300-0x1351)-(0x1970+8626-0x229f))
#else
#  define ReplacementFor_ELPP_ERROR_LOG ((0xf4a+3806-0x1beb)+(0x1d0f+929-0xfe2)-\
4875)
#endif  
#if (!defined(ReplacementFor_ELPP_DISABLE_FATAL_LOGS) && (\
ReplacementFor_ELPP_LOGGING_ENABLED))
#  define ReplacementFor_ELPP_FATAL_LOG ((0x8a1+8405-0x25be)+\
(0x2704+7487-0x254d)-(0x24ec+4852-0x1533))
#else
#  define ReplacementFor_ELPP_FATAL_LOG (9226+(0x1aa4+1975-0x212f)-9526)
#endif  
#if (!defined(ReplacementFor_ELPP_DISABLE_TRACE_LOGS) && (\
ReplacementFor_ELPP_LOGGING_ENABLED))
#  define ReplacementFor_ELPP_TRACE_LOG ((0x1f41+2863-0x20f9)+7403-9825)
#else
#  define ReplacementFor_ELPP_TRACE_LOG ((0xb52+1121-0xfa7)+(0x81f+5109-0x14a2)-\
(0x1c9b+2397-0x1e7a))
#endif  
#if (!defined(ReplacementFor_ELPP_DISABLE_VERBOSE_LOGS) && (\
ReplacementFor_ELPP_LOGGING_ENABLED))
#  define ReplacementFor_ELPP_VERBOSE_LOG (3851+(0xa0f+969-0x64f)-5779)
#else
#  define ReplacementFor_ELPP_VERBOSE_LOG ((0x1d16+1169-0x1ffb)+\
(0x1100+6008-0x2288)-(0x1838+5242-0x2516))
#endif  
#if (!(ReplacementFor_ELPP_CXX0X || ReplacementFor_ELPP_CXX11))
#   error "C++0x (or higher) support not detected! (Is `-std=c++11' missing?)"
#endif  
#if defined(ReplacementFor_ELPP_SYSLOG)
#   include <syslog.h>
#endif  
#include <ctime>
#include <cstring>
#include <cstdlib>
#include <cctype>
#include <cwchar>
#include <csignal>
#include <cerrno>
#include <cstdarg>
#if defined(ReplacementFor_ELPP_UNICODE)
#   include <locale>
#  if ReplacementFor_ELPP_OS_WINDOWS
#      include <codecvt>
#  endif 
#endif  
#if ReplacementFor_ELPP_STACKTRACE
#   include <cxxabi.h>
#   include <execinfo.h>
#endif  
#if ReplacementFor_ELPP_OS_ANDROID
#   include <sys/system_properties.h>
#endif  
#if ReplacementFor_ELPP_OS_UNIX
#   include <sys/stat.h>
#   include <sys/time.h>
#elif ReplacementFor_ELPP_OS_WINDOWS
#   include <direct.h>
#   include <windows.h>
#  if defined(ReplacementFor_WIN32_LEAN_AND_MEAN)
#      if defined(ReplacementFor_ELPP_WINSOCK2)
#         include <winsock2.h>
#      else
#         include <winsock.h>
#      endif 
#  endif 
#endif  
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <utility>
#include <functional>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <memory>
#include <type_traits>
#if ReplacementFor_ELPP_THREADING_ENABLED
#  if ReplacementFor_ELPP_USE_STD_THREADING
#      include <mutex>
#      include <thread>
#  else
#      if ReplacementFor_ELPP_OS_UNIX
#         include <pthread.h>
#      endif  
#  endif  
#endif  
#if ReplacementFor_ELPP_ASYNC_LOGGING
#  if defined(ReplacementFor_ELPP_NO_SLEEP_FOR)
#      include <unistd.h>
#  endif  
#   include <thread>
#   include <queue>
#   include <condition_variable>
#endif  
#if defined(ReplacementFor_ELPP_STL_LOGGING)
#   include <list>
#   include <queue>
#   include <deque>
#   include <set>
#   include <bitset>
#   include <stack>
#  if defined(ReplacementFor_ELPP_LOG_STD_ARRAY)
#      include <array>
#  endif  
#  if defined(ReplacementFor_ELPP_LOG_UNORDERED_SET)
#      include <unordered_set>
#  endif  
#endif  
#if defined(ReplacementFor_ELPP_QT_LOGGING)
#   include <QString>
#   include <QByteArray>
#   include <QVector>
#   include <QList>
#   include <QPair>
#   include <QMap>
#   include <QQueue>
#   include <QSet>
#   include <QLinkedList>
#   include <QHash>
#   include <QMultiHash>
#   include <QStack>
#endif  
#if defined(ReplacementFor_ELPP_BOOST_LOGGING)
#   include <boost/container/vector.hpp>
#   include <boost/container/stable_vector.hpp>
#   include <boost/container/list.hpp>
#   include <boost/container/deque.hpp>
#   include <boost/container/map.hpp>
#   include <boost/container/flat_map.hpp>
#   include <boost/container/set.hpp>
#   include <boost/container/flat_set.hpp>
#endif  
#if defined(ReplacementFor_ELPP_WXWIDGETS_LOGGING)
#   include <wx/vector.h>
#endif  
#if defined(ReplacementFor_ELPP_UTC_DATETIME)
#   define ReplacementFor_elpptime_r gmtime_r
#   define ReplacementFor_elpptime_s ReplacementFor_gmtime_s
#   define ReplacementFor_elpptime   gmtime
#else
#   define ReplacementFor_elpptime_r localtime_r
#   define ReplacementFor_elpptime_s ReplacementFor_localtime_s
#   define ReplacementFor_elpptime   localtime
#endif  
namespace ReplacementFor_el{class ReplacementFor_Logger;class 
ReplacementFor_LogMessage;class ReplacementFor_PerformanceTrackingData;class 
ReplacementFor_Loggers;class ReplacementFor_Helpers;template<typename T>class 
ReplacementFor_Callback;class ReplacementFor_LogDispatchCallback;class 
ReplacementFor_PerformanceTrackingCallback;class 
ReplacementFor_LoggerRegistrationCallback;class ReplacementFor_LogDispatchData;
namespace base{class ReplacementFor_Storage;class 
ReplacementFor_RegisteredLoggers;class ReplacementFor_PerformanceTracker;class 
ReplacementFor_MessageBuilder;class ReplacementFor_Writer;class 
ReplacementFor_PErrorWriter;class ReplacementFor_LogDispatcher;class 
ReplacementFor_DefaultLogBuilder;class ReplacementFor_DefaultLogDispatchCallback
;
#if ReplacementFor_ELPP_ASYNC_LOGGING
class ReplacementFor_AsyncLogDispatchCallback;class 
ReplacementFor_AsyncDispatchWorker;
#endif 
class ReplacementFor_DefaultPerformanceTrackingCallback;}}namespace 
ReplacementFor_el{namespace base{namespace type{
#undef ReplacementFor_ELPP_LITERAL
#undef ReplacementFor_ELPP_STRLEN
#undef ReplacementFor_ELPP_COUT
#if defined(ReplacementFor_ELPP_UNICODE)
#  define ReplacementFor_ELPP_LITERAL(ReplacementFor_txt) ReplacementFor_L##\
ReplacementFor_txt
#  define ReplacementFor_ELPP_STRLEN wcslen
#  if defined ReplacementFor_ELPP_CUSTOM_COUT
#    define ReplacementFor_ELPP_COUT ReplacementFor_ELPP_CUSTOM_COUT
#  else
#    define ReplacementFor_ELPP_COUT std::wcout
#  endif  
typedef wchar_t ReplacementFor_char_t;typedef std::wstring 
ReplacementFor_string_t;typedef std::wstringstream ReplacementFor_stringstream_t
;typedef std::wfstream ReplacementFor_fstream_t;typedef std::wostream 
ReplacementFor_ostream_t;
#else
#  define ReplacementFor_ELPP_LITERAL(ReplacementFor_txt) ReplacementFor_txt
#  define ReplacementFor_ELPP_STRLEN strlen
#  if defined ReplacementFor_ELPP_CUSTOM_COUT
#    define ReplacementFor_ELPP_COUT ReplacementFor_ELPP_CUSTOM_COUT
#  else
#    define ReplacementFor_ELPP_COUT std::cout
#  endif  
typedef char ReplacementFor_char_t;typedef std::string ReplacementFor_string_t;
typedef std::stringstream ReplacementFor_stringstream_t;typedef std::fstream 
ReplacementFor_fstream_t;typedef std::ostream ReplacementFor_ostream_t;
#endif  
#if defined(ReplacementFor_ELPP_CUSTOM_COUT_LINE)
#  define ReplacementFor_ELPP_COUT_LINE(ReplacementFor_logLine) \
ReplacementFor_ELPP_CUSTOM_COUT_LINE(ReplacementFor_logLine)
#else
#  define ReplacementFor_ELPP_COUT_LINE(ReplacementFor_logLine) \
ReplacementFor_logLine << std::flush
#endif 
typedef unsigned int ReplacementFor_EnumType;typedef unsigned short 
ReplacementFor_VerboseLevel;typedef unsigned long int ReplacementFor_LineNumber;
typedef std::shared_ptr<base::ReplacementFor_Storage>
ReplacementFor_StoragePointer;typedef std::shared_ptr<
ReplacementFor_LogDispatchCallback>ReplacementFor_LogDispatchCallbackPtr;typedef
 std::shared_ptr<ReplacementFor_PerformanceTrackingCallback>
ReplacementFor_PerformanceTrackingCallbackPtr;typedef std::shared_ptr<
ReplacementFor_LoggerRegistrationCallback>
ReplacementFor_LoggerRegistrationCallbackPtr;typedef std::unique_ptr<
ReplacementFor_el::base::ReplacementFor_PerformanceTracker>
ReplacementFor_PerformanceTrackerPtr;}class ReplacementFor_NoCopy{protected:
ReplacementFor_NoCopy(void){}private:ReplacementFor_NoCopy(const 
ReplacementFor_NoCopy&);ReplacementFor_NoCopy&operator=(const 
ReplacementFor_NoCopy&);};class ReplacementFor_StaticClass{private:
ReplacementFor_StaticClass(void);ReplacementFor_StaticClass(const 
ReplacementFor_StaticClass&);ReplacementFor_StaticClass&operator=(const 
ReplacementFor_StaticClass&);};}enum class Level:base::type::
ReplacementFor_EnumType{Global=((0x65f+326-0x4ba)+(0xae7+6684-0x1dea)-
(0xa84+8729-0x229a)),ReplacementFor_Trace=((0x189a+2050-0xb39)+
(0x25a6+605-0x18e8)-9340),ReplacementFor_Debug=((0x15bf+1440-0x1a73)+
(0x4cb+4669-0x12d3)-(0x1ecd+3014-0x2576)),ReplacementFor_Fatal=(
(0x14b2+3041-0xf6c)+(0x1396+625-0x109a)-5772),Error=((0x1be2+194-0x173b)+
(0x2b9+5629-0x1879)-(0x21bb+506-0x1e1f)),ReplacementFor_Warning=(
(0x15db+6937-0x1e21)+(0x12e9+7830-0x1fdc)-9302),ReplacementFor_Verbose=(
(0x84d+7424-0x1fbe)+(0x1254+6781-0x1d89)-(0x2050+6412-0x24c5)),
ReplacementFor_Info=((0x12a0+1754-0x1102)+3534-(0x175a+5640-0x179c)),Unknown=(
7516+(0x147c+358-0xa0b)-(0x26b1+7787-0x1fdb))};}namespace std{template<>struct 
hash<ReplacementFor_el::Level>{public:std::size_t operator()(const 
ReplacementFor_el::Level&ReplacementFor_l)const{return hash<ReplacementFor_el::
base::type::ReplacementFor_EnumType>{}(static_cast<ReplacementFor_el::base::type
::ReplacementFor_EnumType>(ReplacementFor_l));}};}namespace ReplacementFor_el{
class ReplacementFor_LevelHelper:base::ReplacementFor_StaticClass{public:static 
const base::type::ReplacementFor_EnumType ReplacementFor_kMinValid=static_cast<
base::type::ReplacementFor_EnumType>(Level::ReplacementFor_Trace);static const 
base::type::ReplacementFor_EnumType ReplacementFor_kMaxValid=static_cast<base::
type::ReplacementFor_EnumType>(Level::ReplacementFor_Info);static base::type::
ReplacementFor_EnumType ReplacementFor_castToInt(Level ReplacementFor_level){
return static_cast<base::type::ReplacementFor_EnumType>(ReplacementFor_level);}
static Level ReplacementFor_castFromInt(base::type::ReplacementFor_EnumType 
ReplacementFor_l){return static_cast<Level>(ReplacementFor_l);}static const char
*ReplacementFor_convertToString(Level ReplacementFor_level);static Level 
ReplacementFor_convertFromString(const char*ReplacementFor_levelStr);static void
 ReplacementFor_forEachLevel(base::type::ReplacementFor_EnumType*
ReplacementFor_startIndex,const std::function<bool(void)>&ReplacementFor_fn);};
enum class ReplacementFor_ConfigurationType:base::type::ReplacementFor_EnumType{
ReplacementFor_Enabled=(6368+(0x1193+5791-0x23e9)-7464),ReplacementFor_ToFile=(
(0x142d+3949-0x2042)+(0x22a8+8169-0x25f2)-8181),ReplacementFor_ToStandardOutput=
((0x15ed+6822-0x258c)+5812-8631),Format=((0x692+3890-0x14ce)+
(0x22d7+4393-0x1d32)-6076),ReplacementFor_Filename=((0x1c90+1961-0x9e8)+
(0x1baa+1205-0x1f50)-(0x2209+5368-0x1bb1)),ReplacementFor_SubsecondPrecision=(
(0x1692+2480-0xea9)+(0x1987+130-0xe9a)-(0x1d9d+2784-0xb95)),
ReplacementFor_MillisecondsWidth=ReplacementFor_SubsecondPrecision,
ReplacementFor_PerformanceTracking=(6548+(0x1720+3942-0x2570)-6762),
ReplacementFor_MaxLogFileSize=((0x7c3+91-0x4cc)+(0x1bc3+2520-0x1ff1)-
(0x15db+5019-0x20fa)),ReplacementFor_LogFlushThreshold=((0x2707+1373-0x20c9)+
(0x1fb7+212-0x1641)-(0x2561+977-0x144d)),Unknown=((0x11af+3454-0x1370)+
(0x1254+3685-0x1fb5)-(0x15a8+1246-0x11b7))};class 
ReplacementFor_ConfigurationTypeHelper:base::ReplacementFor_StaticClass{public:
static const base::type::ReplacementFor_EnumType ReplacementFor_kMinValid=
static_cast<base::type::ReplacementFor_EnumType>(
ReplacementFor_ConfigurationType::ReplacementFor_Enabled);static const base::
type::ReplacementFor_EnumType ReplacementFor_kMaxValid=static_cast<base::type::
ReplacementFor_EnumType>(ReplacementFor_ConfigurationType::
ReplacementFor_MaxLogFileSize);static base::type::ReplacementFor_EnumType 
ReplacementFor_castToInt(ReplacementFor_ConfigurationType 
ReplacementFor_configurationType){return static_cast<base::type::
ReplacementFor_EnumType>(ReplacementFor_configurationType);}static 
ReplacementFor_ConfigurationType ReplacementFor_castFromInt(base::type::
ReplacementFor_EnumType c){return static_cast<ReplacementFor_ConfigurationType>(
c);}static const char*ReplacementFor_convertToString(
ReplacementFor_ConfigurationType ReplacementFor_configurationType);static 
ReplacementFor_ConfigurationType ReplacementFor_convertFromString(const char*
ReplacementFor_configStr);static inline void ReplacementFor_forEachConfigType(
base::type::ReplacementFor_EnumType*ReplacementFor_startIndex,const std::
function<bool(void)>&ReplacementFor_fn);};enum class ReplacementFor_LoggingFlag:
base::type::ReplacementFor_EnumType{ReplacementFor_NewLineForContainer=(
(0x25ed+480-0x1846)+(0xc64+6939-0x25fe)-(0x2632+879-0x189a)),
ReplacementFor_AllowVerboseIfModuleNotSpecified=(5633+(0x13fc+7597-0x261b)-8589)
,ReplacementFor_LogDetailedCrashReason=((0x14ff+2235-0x11cd)+
(0x12e3+3858-0x1449)-(0x21d6+5549-0x1dee)),
ReplacementFor_DisableApplicationAbortOnFatalLog=((0xea0+1909-0xe22)+
(0x26f9+5483-0x1ea8)-9639),ReplacementFor_ImmediateFlush=((0x1d94+6092-0x2303)+
2898-7583),ReplacementFor_StrictLogFileSizeCheck=((0x1766+4401-0x2375)+
(0x1455+910-0x8c9)-(0x1465+5349-0x152e)),ReplacementFor_ColoredTerminalOutput=(
(0x16f0+4335-0x14ef)+(0x18ef+3976-0x25a5)-(0x23d0+3263-0x1b0d)),
ReplacementFor_MultiLoggerSupport=((0x1cf8+1789-0x207e)+(0x1653+5935-0x2647)-
(0x19b4+4304-0x2052)),
ReplacementFor_DisablePerformanceTrackingCheckpointComparison=(
(0xa86+2919-0x12fd)+(0x15ad+4126-0x2091)-(0xb48+2622-0xe5c)),
ReplacementFor_DisableVModules=(9002+(0xd2+340-0x19a)-8630),
ReplacementFor_DisableVModulesExtensions=((0x1045+7408-0x216a)+
(0x22e7+890-0x23e6)-(0x18eb+352-0x1005)),ReplacementFor_HierarchicalLogging=(
(0x26cd+2392-0x2478)+(0x1695+2141-0x10a7)-(0x24b0+2629-0x1cfd)),
ReplacementFor_CreateLoggerAutomatically=(7218+3882-7004),
ReplacementFor_AutoSpacing=(0x2396+4033-0x1357),ReplacementFor_FixedTimeFormat=
16384,ReplacementFor_IgnoreSigInt=32768,};namespace base{namespace 
ReplacementFor_consts{static const char ReplacementFor_kFormatSpecifierCharValue
=((char)((0x24ed+2883-0x23bd)+(0x929+1315-0x740)-(0x1730+6402-0x1d29)));static 
const char ReplacementFor_kFormatSpecifierChar=((char)((0xf03+4320-0x1a2b)+6580-
8007));static const unsigned int ReplacementFor_kMaxLogPerCounter=100000;static 
const unsigned int ReplacementFor_kMaxLogPerContainer=((0x1345+3178-0x1b25)+
(0x151d+757-0xd60)-(0x1417+8340-0x25d3));static const unsigned int 
ReplacementFor_kDefaultSubsecondPrecision=((0x15f5+1297-0xe6a)+
(0x2045+119-0xf8a)-7627);
#ifdef ReplacementFor_ELPP_DEFAULT_LOGGER
static const char*ReplacementFor_kDefaultLoggerId=
ReplacementFor_ELPP_DEFAULT_LOGGER;
#else
static const char*ReplacementFor_kDefaultLoggerId="\x64\x65\x66\x61\x75\x6c\x74"
;
#endif
#if defined(ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ELPP_FEATURE_PERFORMANCE_TRACKING)
#ifdef ReplacementFor_ELPP_DEFAULT_PERFORMANCE_LOGGER
static const char*ReplacementFor_kPerformanceLoggerId=
ReplacementFor_ELPP_DEFAULT_PERFORMANCE_LOGGER;
#else
static const char*ReplacementFor_kPerformanceLoggerId=
"\x70\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65";
#endif 
#endif
#if defined(ReplacementFor_ELPP_SYSLOG)
static const char*ReplacementFor_kSysLogLoggerId="\x73\x79\x73\x6c\x6f\x67";
#endif  
#if ReplacementFor_ELPP_OS_WINDOWS
static const char*ReplacementFor_kFilePathSeperator="\\";
#else
static const char*ReplacementFor_kFilePathSeperator="\x2f";
#endif  
static const std::size_t ReplacementFor_kSourceFilenameMaxLength=(
(0x20c6+2951-0x1dca)+(0x16c8+2212-0x1b9f)-4588);static const std::size_t 
ReplacementFor_kSourceLineMaxLength=((0x26b7+5213-0x18e7)+(0x2ac+8598-0x2262)-
9219);static const Level ReplacementFor_kPerformanceTrackerDefaultLevel=Level::
ReplacementFor_Info;const struct{double value;const base::type::
ReplacementFor_char_t*ReplacementFor_unit;}ReplacementFor_kTimeFormats[]={{
1000.0f,ReplacementFor_ELPP_LITERAL("\x75\x73")},{1000.0f,
ReplacementFor_ELPP_LITERAL("\x6d\x73")},{60.0f,ReplacementFor_ELPP_LITERAL(
"\x73\x65\x63\x6f\x6e\x64\x73")},{60.0f,ReplacementFor_ELPP_LITERAL(
"\x6d\x69\x6e\x75\x74\x65\x73")},{24.0f,ReplacementFor_ELPP_LITERAL(
"\x68\x6f\x75\x72\x73")},{7.0f,ReplacementFor_ELPP_LITERAL("\x64\x61\x79\x73")}}
;static const int ReplacementFor_kTimeFormatsCount=sizeof(
ReplacementFor_kTimeFormats)/sizeof(ReplacementFor_kTimeFormats[(
(0x2601+4021-0x2157)+(0xa2d+5635-0x1ca5)-6122)]);const struct{int 
ReplacementFor_numb;const char*name;const char*ReplacementFor_brief;const char*
ReplacementFor_detail;}ReplacementFor_kCrashSignals[]={{SIGABRT,
"\x53\x49\x47\x41\x42\x52\x54",
"\x41\x62\x6e\x6f\x72\x6d\x61\x6c\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e"
,
"\x50\x72\x6f\x67\x72\x61\x6d\x20\x77\x61\x73\x20\x61\x62\x6e\x6f\x72\x6d\x61\x6c\x6c\x79\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x64\x2e"
},{SIGFPE,"\x53\x49\x47\x46\x50\x45",
"\x45\x72\x72\x6f\x6e\x65\x6f\x75\x73\x20\x61\x72\x69\x74\x68\x6d\x65\x74\x69\x63\x20\x6f\x70\x65\x72\x61\x74\x69\x6f\x6e"
,
"\x41\x72\x69\x74\x68\x65\x6d\x65\x74\x69\x63\x20\x6f\x70\x65\x72\x61\x74\x69\x6f\x6e\x20\x69\x73\x73\x75\x65\x20\x73\x75\x63\x68\x20\x61\x73\x20\x64\x69\x76\x69\x73\x69\x6f\x6e\x20\x62\x79\x20\x7a\x65\x72\x6f\x20\x6f\x72\x20\x6f\x70\x65\x72\x61\x74\x69\x6f\x6e\x20\x72\x65\x73\x75\x6c\x74\x69\x6e\x67\x20\x69\x6e\x20\x6f\x76\x65\x72\x66\x6c\x6f\x77\x2e"
},{SIGILL,"\x53\x49\x47\x49\x4c\x4c",
"\x49\x6c\x6c\x65\x67\x61\x6c\x20\x69\x6e\x73\x74\x72\x75\x63\x74\x69\x6f\x6e",
"\x47\x65\x6e\x65\x72\x61\x6c\x6c\x79\x20\x64\x75\x65\x20\x74\x6f\x20\x61\x20\x63\x6f\x72\x72\x75\x70\x74\x69\x6f\x6e\x20\x69\x6e\x20\x74\x68\x65\x20\x63\x6f\x64\x65\x20\x6f\x72\x20\x74\x6f\x20\x61\x6e\x20\x61\x74\x74\x65\x6d\x70\x74\x20\x74\x6f\x20\x65\x78\x65\x63\x75\x74\x65\x20\x64\x61\x74\x61\x2e"
},{SIGSEGV,"\x53\x49\x47\x53\x45\x47\x56",
"\x49\x6e\x76\x61\x6c\x69\x64\x20\x61\x63\x63\x65\x73\x73\x20\x74\x6f\x20\x6d\x65\x6d\x6f\x72\x79"
,
"\x50\x72\x6f\x67\x72\x61\x6d\x20\x69\x73\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x61\x6e\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x28\x75\x6e\x61\x6c\x6c\x6f\x63\x61\x74\x65\x64\x2c\x20\x64\x65\x6c\x65\x74\x65\x64\x20\x6f\x72\x20\x63\x6f\x72\x72\x75\x70\x74\x65\x64\x29\x20\x6f\x72\x20\x69\x6e\x61\x63\x63\x65\x73\x73\x69\x62\x6c\x65\x20\x6d\x65\x6d\x6f\x72\x79\x2e"
},{SIGINT,"\x53\x49\x47\x49\x4e\x54",
"\x49\x6e\x74\x65\x72\x61\x63\x74\x69\x76\x65\x20\x61\x74\x74\x65\x6e\x74\x69\x6f\x6e\x20\x73\x69\x67\x6e\x61\x6c"
,
"\x49\x6e\x74\x65\x72\x72\x75\x70\x74\x69\x6f\x6e\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x64\x20\x28\x67\x65\x6e\x65\x72\x61\x6c\x6c\x79\x29\x20\x62\x79\x20\x75\x73\x65\x72\x20\x6f\x72\x20\x6f\x70\x65\x72\x61\x74\x69\x6e\x67\x20\x73\x79\x73\x74\x65\x6d\x2e"
},};static const int ReplacementFor_kCrashSignalsCount=sizeof(
ReplacementFor_kCrashSignals)/sizeof(ReplacementFor_kCrashSignals[(
(0x1823+3150-0x204e)+(0x11eb+857-0x1082)-(0xa47+4926-0x14a0))]);}}typedef std::
function<void(const char*,std::size_t)>ReplacementFor_PreRollOutCallback;
namespace base{static inline void ReplacementFor_defaultPreRollOutCallback(const
 char*,std::size_t){}enum class ReplacementFor_TimestampUnit:base::type::
ReplacementFor_EnumType{ReplacementFor_Microsecond=((0xcbd+8438-0x25cd)+
(0x2086+284-0x1ea7)-(0x24bb+74-0x1a24)),ReplacementFor_Millisecond=(
(0x1d1b+1133-0xd8b)+(0x196a+114-0x127e)-(0x2394+5478-0x1da0)),Second=(
(0x19a0+2434-0x18e5)+(0x1bc7+992-0xddd)-(0x26b8+681-0xd5c)),
ReplacementFor_Minute=(7689+(0x864+8531-0x2279)-9540),Hour=((0x571+8498-0x2551)+
(0x1e01+1314-0x1ab0)-(0x192d+5555-0x251f)),ReplacementFor_Day=(
(0x18b3+6335-0x1dfd)+(0x1b34+809-0x1787)-(0x1e93+8521-0x2596))};enum class 
ReplacementFor_FormatFlags:base::type::ReplacementFor_EnumType{
ReplacementFor_DateTime=((0x58c+5042-0x16f6)+8459-9042)<<((0xf16+1548-0x12c5)+
(0x1cef+3843-0x26b8)-(0x1ecd+1979-0x1ef2)),ReplacementFor_LoggerId=(8204+
(0x1391+5975-0x26e2)-9233)<<((0x149a+517-0x92e)+2528-(0x1c71+7410-0x2214)),File=
(9392+(0x1f5+7662-0x1fa5)-9453)<<((0xce1+6099-0x1f11)+4729-(0x20b5+280-0x9b4)),
Line=((0x1083+172-0x678)+(0xcb2+147-0xb11)-3306)<<((0x2460+3094-0x26eb)+
(0x1751+1483-0x1c0b)-(0x1a69+4807-0x2298)),ReplacementFor_Location=(
(0x16e8+3774-0x228d)+7885-8677)<<(7434+(0x228a+24-0x1f2a)-(0x2572+79-0x544)),
Function=((0x1892+757-0x1aff)+(0xb51+1714-0xc75)-(0xdbd+7433-0x24b1))<<(
(0x184+333-0x2a2)+(0x1e24+4933-0x1f3d)-(0x222d+3733-0x1e6d)),User=(
(0x14eb+871-0x95f)+(0x1a89+4188-0x2396)-5697)<<((0x2445+6002-0x2695)+
(0xdda+7197-0x22b1)-(0x211f+5058-0x1880)),ReplacementFor_Host=(
(0x14c1+1187-0x89a)+(0x2522+94-0x1a26)-(0x2448+3133-0x1462))<<(
(0x2352+442-0x1eb4)+(0x1df0+1490-0x11d8)-(0x2568+2762-0x17f8)),
ReplacementFor_LogMessage=((0x2313+1038-0x254e)+5936-(0x2425+2742-0x15d9))<<(
(0x1483+1360-0x17e4)+7658-(0x22a7+1786-0x9d1)),ReplacementFor_VerboseLevel=(
(0x1b16+5701-0x21e6)+(0x1b2c+2257-0xf10)-9313)<<((0x1867+5459-0x2450)+5664-8064)
,ReplacementFor_AppName=((0x17fb+1258-0xcdd)+(0x267a+4159-0x25b2)-8462)<<(
(0x17fb+1165-0xa9f)+(0x11b7+8801-0x25ce)-8232),ReplacementFor_ThreadId=(
(0x1111+3542-0x1af5)+(0x159d+1248-0x1269)-(0x17f9+5723-0x224f))<<(4519+
(0x1c2f+4419-0x237e)-7055),Level=((0x20e7+4235-0x22eb)+(0x89c+5781-0x1b79)-
(0x17b9+8356-0x261f))<<(2899+(0x24c6+1152-0x1f1f)-(0x2127+3789-0x1a87)),
ReplacementFor_FileBase=((0x189c+1025-0xad6)+(0xc12+7061-0x24de)-
(0x15a4+4251-0x11b0))<<((0x749+2677-0xaab)+(0x1702+8781-0x25b8)-6812),
ReplacementFor_LevelShort=((0x230+1406-0x6bb)+(0x1431+6676-0x225b)-
(0x11b6+1757-0xbb7))<<((0x1989+4622-0x2072)+4153-6991)};class 
ReplacementFor_SubsecondPrecision{public:ReplacementFor_SubsecondPrecision(void)
{init(base::ReplacementFor_consts::ReplacementFor_kDefaultSubsecondPrecision);}
explicit ReplacementFor_SubsecondPrecision(int width){init(width);}bool operator
==(const ReplacementFor_SubsecondPrecision&ReplacementFor_ssPrec){return 
ReplacementFor_m_width==ReplacementFor_ssPrec.ReplacementFor_m_width&&
ReplacementFor_m_offset==ReplacementFor_ssPrec.ReplacementFor_m_offset;}int 
ReplacementFor_m_width;unsigned int ReplacementFor_m_offset;private:void init(
int width);};typedef ReplacementFor_SubsecondPrecision 
ReplacementFor_MillisecondsWidth;namespace ReplacementFor_utils{template<
typename T>static typename std::enable_if<std::is_pointer<T*>::value,void>::type
 ReplacementFor_safeDelete(T*&pointer){if(pointer==nullptr)return;delete pointer
;pointer=nullptr;}namespace ReplacementFor_bitwise{template<typename Enum>static
 inline base::type::ReplacementFor_EnumType And(Enum ReplacementFor_e,base::type
::ReplacementFor_EnumType flag){return static_cast<base::type::
ReplacementFor_EnumType>(flag)&static_cast<base::type::ReplacementFor_EnumType>(
ReplacementFor_e);}template<typename Enum>static inline base::type::
ReplacementFor_EnumType Not(Enum ReplacementFor_e,base::type::
ReplacementFor_EnumType flag){return static_cast<base::type::
ReplacementFor_EnumType>(flag)&~(static_cast<base::type::ReplacementFor_EnumType
>(ReplacementFor_e));}template<typename Enum>static inline base::type::
ReplacementFor_EnumType Or(Enum ReplacementFor_e,base::type::
ReplacementFor_EnumType flag){return static_cast<base::type::
ReplacementFor_EnumType>(flag)|static_cast<base::type::ReplacementFor_EnumType>(
ReplacementFor_e);}}template<typename Enum>static inline void 
ReplacementFor_addFlag(Enum ReplacementFor_e,base::type::ReplacementFor_EnumType
*flag){*flag=base::ReplacementFor_utils::ReplacementFor_bitwise::Or<Enum>(
ReplacementFor_e,*flag);}template<typename Enum>static inline void 
ReplacementFor_removeFlag(Enum ReplacementFor_e,base::type::
ReplacementFor_EnumType*flag){*flag=base::ReplacementFor_utils::
ReplacementFor_bitwise::Not<Enum>(ReplacementFor_e,*flag);}template<typename 
Enum>static inline bool ReplacementFor_hasFlag(Enum ReplacementFor_e,base::type
::ReplacementFor_EnumType flag){return base::ReplacementFor_utils::
ReplacementFor_bitwise::And<Enum>(ReplacementFor_e,flag)>((0x207a+2682-0x234b)+
(0x1891+4446-0x1ffb)-(0x181f+4220-0x16fe));}}namespace ReplacementFor_threading{
#if ReplacementFor_ELPP_THREADING_ENABLED
#  if !ReplacementFor_ELPP_USE_STD_THREADING
namespace internal{class Mutex:base::ReplacementFor_NoCopy{public:Mutex(void){
#  if ReplacementFor_ELPP_OS_UNIX
pthread_mutexattr_t ReplacementFor_attr;pthread_mutexattr_init(&
ReplacementFor_attr);pthread_mutexattr_settype(&ReplacementFor_attr,
PTHREAD_MUTEX_RECURSIVE);pthread_mutex_init(&ReplacementFor_m_underlyingMutex,&
ReplacementFor_attr);pthread_mutexattr_destroy(&ReplacementFor_attr);
#  elif ReplacementFor_ELPP_OS_WINDOWS
InitializeCriticalSection(&ReplacementFor_m_underlyingMutex);
#  endif  
}virtual~Mutex(void){
#  if ReplacementFor_ELPP_OS_UNIX
pthread_mutex_destroy(&ReplacementFor_m_underlyingMutex);
#  elif ReplacementFor_ELPP_OS_WINDOWS
DeleteCriticalSection(&ReplacementFor_m_underlyingMutex);
#  endif  
}inline void lock(void){
#  if ReplacementFor_ELPP_OS_UNIX
pthread_mutex_lock(&ReplacementFor_m_underlyingMutex);
#  elif ReplacementFor_ELPP_OS_WINDOWS
EnterCriticalSection(&ReplacementFor_m_underlyingMutex);
#  endif  
}inline bool try_lock(void){
#  if ReplacementFor_ELPP_OS_UNIX
return(pthread_mutex_trylock(&ReplacementFor_m_underlyingMutex)==(
(0x20e2+772-0x2314)+(0x1c43+2222-0x1313)-(0x14b5+4083-0x11f8)));
#  elif ReplacementFor_ELPP_OS_WINDOWS
return TryEnterCriticalSection(&ReplacementFor_m_underlyingMutex);
#  endif  
}inline void unlock(void){
#  if ReplacementFor_ELPP_OS_UNIX
pthread_mutex_unlock(&ReplacementFor_m_underlyingMutex);
#  elif ReplacementFor_ELPP_OS_WINDOWS
LeaveCriticalSection(&ReplacementFor_m_underlyingMutex);
#  endif  
}private:
#  if ReplacementFor_ELPP_OS_UNIX
pthread_mutex_t ReplacementFor_m_underlyingMutex;
#  elif ReplacementFor_ELPP_OS_WINDOWS
CRITICAL_SECTION ReplacementFor_m_underlyingMutex;
#  endif  
};template<typename M>class ReplacementFor_ScopedLock:base::
ReplacementFor_NoCopy{public:explicit ReplacementFor_ScopedLock(M&mutex){
ReplacementFor_m_mutex=&mutex;ReplacementFor_m_mutex->lock();}virtual~
ReplacementFor_ScopedLock(void){ReplacementFor_m_mutex->unlock();}private:M*
ReplacementFor_m_mutex;ReplacementFor_ScopedLock(void);};}typedef base::
ReplacementFor_threading::internal::Mutex Mutex;typedef base::
ReplacementFor_threading::internal::ReplacementFor_ScopedLock<base::
ReplacementFor_threading::Mutex>ReplacementFor_ScopedLock;
#  else
typedef std::recursive_mutex Mutex;typedef std::lock_guard<base::
ReplacementFor_threading::Mutex>ReplacementFor_ScopedLock;
#  endif  
#else
namespace internal{class ReplacementFor_NoMutex:base::ReplacementFor_NoCopy{
public:ReplacementFor_NoMutex(void){}inline void lock(void){}inline bool 
try_lock(void){return true;}inline void unlock(void){}};template<typename Mutex>
class ReplacementFor_NoScopedLock:base::ReplacementFor_NoCopy{public:explicit 
ReplacementFor_NoScopedLock(Mutex&){}virtual~ReplacementFor_NoScopedLock(void){}
private:ReplacementFor_NoScopedLock(void);};}typedef base::
ReplacementFor_threading::internal::ReplacementFor_NoMutex Mutex;typedef base::
ReplacementFor_threading::internal::ReplacementFor_NoScopedLock<base::
ReplacementFor_threading::Mutex>ReplacementFor_ScopedLock;
#endif  
class ReplacementFor_ThreadSafe{public:virtual inline void 
ReplacementFor_acquireLock(void)ReplacementFor_ELPP_FINAL{ReplacementFor_m_mutex
.lock();}virtual inline void ReplacementFor_releaseLock(void)
ReplacementFor_ELPP_FINAL{ReplacementFor_m_mutex.unlock();}virtual inline base::
ReplacementFor_threading::Mutex&lock(void)ReplacementFor_ELPP_FINAL{return 
ReplacementFor_m_mutex;}protected:ReplacementFor_ThreadSafe(void){}virtual~
ReplacementFor_ThreadSafe(void){}private:base::ReplacementFor_threading::Mutex 
ReplacementFor_m_mutex;};
#if ReplacementFor_ELPP_THREADING_ENABLED
#  if !ReplacementFor_ELPP_USE_STD_THREADING
static std::string ReplacementFor_getCurrentThreadId(void){std::stringstream 
ReplacementFor_ss;
#      if (ReplacementFor_ELPP_OS_WINDOWS)
ReplacementFor_ss<<GetCurrentThreadId();
#      endif  
return ReplacementFor_ss.str();}
#  else
static std::string ReplacementFor_getCurrentThreadId(void){std::stringstream 
ReplacementFor_ss;ReplacementFor_ss<<std::this_thread::get_id();return 
ReplacementFor_ss.str();}
#  endif  
#else
static inline std::string ReplacementFor_getCurrentThreadId(void){return std::
string();}
#endif  
}namespace ReplacementFor_utils{class File:base::ReplacementFor_StaticClass{
public:static base::type::ReplacementFor_fstream_t*ReplacementFor_newFileStream(
const std::string&ReplacementFor_filename);static std::size_t 
ReplacementFor_getSizeOfFile(base::type::ReplacementFor_fstream_t*fs);static 
bool ReplacementFor_pathExists(const char*ReplacementFor_path,bool 
ReplacementFor_considerFile=false);static bool ReplacementFor_createPath(const 
std::string&ReplacementFor_path);static std::string 
ReplacementFor_extractPathFromFilename(const std::string&ReplacementFor_fullPath
,const char*ReplacementFor_seperator=base::ReplacementFor_consts::
ReplacementFor_kFilePathSeperator);static void 
ReplacementFor_buildStrippedFilename(const char*ReplacementFor_filename,char 
ReplacementFor_buff[],std::size_t ReplacementFor_limit=base::
ReplacementFor_consts::ReplacementFor_kSourceFilenameMaxLength);static void 
ReplacementFor_buildBaseFilename(const std::string&ReplacementFor_fullPath,char 
ReplacementFor_buff[],std::size_t ReplacementFor_limit=base::
ReplacementFor_consts::ReplacementFor_kSourceFilenameMaxLength,const char*
ReplacementFor_seperator=base::ReplacementFor_consts::
ReplacementFor_kFilePathSeperator);};class Str:base::ReplacementFor_StaticClass{
public:static inline bool isDigit(char c){return c>=((char)((0xcd1+7345-0x1f9b)+
(0x252b+5851-0x22be)-(0x2487+6707-0x1bbb)))&&c<=((char)((0xadc+2494-0xcf7)+
(0x2320+1353-0x241b)-(0x1d2f+624-0x13e7)));}static bool 
ReplacementFor_wildCardMatch(const char*str,const char*pattern);static std::
string&ReplacementFor_ltrim(std::string&str);static std::string&
ReplacementFor_rtrim(std::string&str);static std::string&ReplacementFor_trim(std
::string&str);static bool ReplacementFor_startsWith(const std::string&str,const 
std::string&ReplacementFor_start);static bool ReplacementFor_endsWith(const std
::string&str,const std::string&end);static std::string&ReplacementFor_replaceAll
(std::string&str,char ReplacementFor_replaceWhat,char ReplacementFor_replaceWith
);static std::string&ReplacementFor_replaceAll(std::string&str,const std::string
&ReplacementFor_replaceWhat,const std::string&ReplacementFor_replaceWith);static
 void ReplacementFor_replaceFirstWithEscape(base::type::ReplacementFor_string_t&
str,const base::type::ReplacementFor_string_t&ReplacementFor_replaceWhat,const 
base::type::ReplacementFor_string_t&ReplacementFor_replaceWith);
#if defined(ReplacementFor_ELPP_UNICODE)
static void ReplacementFor_replaceFirstWithEscape(base::type::
ReplacementFor_string_t&str,const base::type::ReplacementFor_string_t&
ReplacementFor_replaceWhat,const std::string&ReplacementFor_replaceWith);
#endif  
static std::string&toUpper(std::string&str);static bool ReplacementFor_cStringEq
(const char*ReplacementFor_s1,const char*ReplacementFor_s2);static bool 
ReplacementFor_cStringCaseEq(const char*ReplacementFor_s1,const char*
ReplacementFor_s2);static bool ReplacementFor_contains(const char*str,char c);
static char*ReplacementFor_convertAndAddToBuff(std::size_t n,int len,char*buf,
const char*ReplacementFor_bufLim,bool ReplacementFor_zeroPadded=true);static 
char*ReplacementFor_addToBuff(const char*str,char*buf,const char*
ReplacementFor_bufLim);static char*ReplacementFor_clearBuff(char 
ReplacementFor_buff[],std::size_t ReplacementFor_lim);static char*
ReplacementFor_wcharPtrToCharPtr(const wchar_t*line);};class OS:base::
ReplacementFor_StaticClass{public:
#if ReplacementFor_ELPP_OS_WINDOWS
static const char*ReplacementFor_getWindowsEnvironmentVariable(const char*
ReplacementFor_varname);
#endif  
#if ReplacementFor_ELPP_OS_ANDROID
static std::string ReplacementFor_getProperty(const char*ReplacementFor_prop);
static std::string ReplacementFor_getDeviceName(void);
#endif  
static const std::string ReplacementFor_getBashOutput(const char*
ReplacementFor_command);static std::string ReplacementFor_getEnvironmentVariable
(const char*ReplacementFor_variableName,const char*ReplacementFor_defaultVal,
const char*ReplacementFor_alternativeBashCommand=nullptr);static std::string 
ReplacementFor_currentUser(void);static std::string ReplacementFor_currentHost(
void);static bool ReplacementFor_termSupportsColor(void);};class 
ReplacementFor_DateTime:base::ReplacementFor_StaticClass{public:static void 
gettimeofday(struct timeval*ReplacementFor_tv);static std::string 
ReplacementFor_getDateTime(const char*format,const base::
ReplacementFor_SubsecondPrecision*ReplacementFor_ssPrec);static std::string 
ReplacementFor_timevalToString(struct timeval ReplacementFor_tval,const char*
format,const ReplacementFor_el::base::ReplacementFor_SubsecondPrecision*
ReplacementFor_ssPrec);static base::type::ReplacementFor_string_t formatTime(
unsigned long long time,base::ReplacementFor_TimestampUnit 
ReplacementFor_timestampUnit);static unsigned long long 
ReplacementFor_getTimeDifference(const struct timeval&ReplacementFor_endTime,
const struct timeval&ReplacementFor_startTime,base::ReplacementFor_TimestampUnit
 ReplacementFor_timestampUnit);static struct::tm*ReplacementFor_buildTimeInfo(
struct timeval*ReplacementFor_currTime,struct::tm*ReplacementFor_timeInfo);
private:static char*ReplacementFor_parseFormat(char*buf,std::size_t 
ReplacementFor_bufSz,const char*format,const struct tm*ReplacementFor_tInfo,std
::size_t ReplacementFor_msec,const base::ReplacementFor_SubsecondPrecision*
ReplacementFor_ssPrec);};class ReplacementFor_CommandLineArgs{public:
ReplacementFor_CommandLineArgs(void){ReplacementFor_setArgs((
(0x1b5d+6346-0x1bbd)+(0xffa+6063-0x21ee)-7717),static_cast<char**>(nullptr));}
ReplacementFor_CommandLineArgs(int ReplacementFor_argc,const char**
ReplacementFor_argv){ReplacementFor_setArgs(ReplacementFor_argc,
ReplacementFor_argv);}ReplacementFor_CommandLineArgs(int ReplacementFor_argc,
char**ReplacementFor_argv){ReplacementFor_setArgs(ReplacementFor_argc,
ReplacementFor_argv);}virtual~ReplacementFor_CommandLineArgs(void){}inline void 
ReplacementFor_setArgs(int ReplacementFor_argc,const char**ReplacementFor_argv){
ReplacementFor_setArgs(ReplacementFor_argc,const_cast<char**>(
ReplacementFor_argv));}void ReplacementFor_setArgs(int ReplacementFor_argc,char*
*ReplacementFor_argv);bool ReplacementFor_hasParamWithValue(const char*
ReplacementFor_paramKey)const;const char*ReplacementFor_getParamValue(const char
*ReplacementFor_paramKey)const;bool ReplacementFor_hasParam(const char*
ReplacementFor_paramKey)const;bool empty(void)const;std::size_t size(void)const;
friend base::type::ReplacementFor_ostream_t&operator<<(base::type::
ReplacementFor_ostream_t&os,const ReplacementFor_CommandLineArgs&c);private:int 
ReplacementFor_m_argc;char**ReplacementFor_m_argv;std::unordered_map<std::string
,std::string>ReplacementFor_m_paramsWithValue;std::vector<std::string>
ReplacementFor_m_params;};template<typename ReplacementFor_T_Ptr,typename 
Container>class ReplacementFor_AbstractRegistry:public base::
ReplacementFor_threading::ReplacementFor_ThreadSafe{public:typedef typename 
Container::iterator iterator;typedef typename Container::const_iterator 
const_iterator;ReplacementFor_AbstractRegistry(void){}
ReplacementFor_AbstractRegistry(ReplacementFor_AbstractRegistry&&
ReplacementFor_sr){if(this==&ReplacementFor_sr){return;}
ReplacementFor_unregisterAll();ReplacementFor_m_list=std::move(ReplacementFor_sr
.ReplacementFor_m_list);}bool operator==(const ReplacementFor_AbstractRegistry<
ReplacementFor_T_Ptr,Container>&other){if(size()!=other.size()){return false;}
for(std::size_t i=((0x2138+4787-0x1855)+(0x52a+3644-0x1352)-(0x1d89+3273-0xea8))
;i<ReplacementFor_m_list.size();++i){if(ReplacementFor_m_list.at(i)!=other.
ReplacementFor_m_list.at(i)){return false;}}return true;}bool operator!=(const 
ReplacementFor_AbstractRegistry<ReplacementFor_T_Ptr,Container>&other){if(size()
!=other.size()){return true;}for(std::size_t i=((0x1641+3090-0x1c0b)+7771-9379);
i<ReplacementFor_m_list.size();++i){if(ReplacementFor_m_list.at(i)!=other.
ReplacementFor_m_list.at(i)){return true;}}return false;}
ReplacementFor_AbstractRegistry&operator=(ReplacementFor_AbstractRegistry&&
ReplacementFor_sr){if(this==&ReplacementFor_sr){return*this;}
ReplacementFor_unregisterAll();ReplacementFor_m_list=std::move(ReplacementFor_sr
.ReplacementFor_m_list);return*this;}virtual~ReplacementFor_AbstractRegistry(
void){}virtual inline iterator begin(void)ReplacementFor_ELPP_FINAL{return 
ReplacementFor_m_list.begin();}virtual inline iterator end(void)
ReplacementFor_ELPP_FINAL{return ReplacementFor_m_list.end();}virtual inline 
const_iterator cbegin(void)const ReplacementFor_ELPP_FINAL{return 
ReplacementFor_m_list.cbegin();}virtual inline const_iterator cend(void)const 
ReplacementFor_ELPP_FINAL{return ReplacementFor_m_list.cend();}virtual inline 
bool empty(void)const ReplacementFor_ELPP_FINAL{return ReplacementFor_m_list.
empty();}virtual inline std::size_t size(void)const ReplacementFor_ELPP_FINAL{
return ReplacementFor_m_list.size();}virtual inline Container&list(void)
ReplacementFor_ELPP_FINAL{return ReplacementFor_m_list;}virtual inline const 
Container&list(void)const ReplacementFor_ELPP_FINAL{return ReplacementFor_m_list
;}virtual void ReplacementFor_unregisterAll(void)=0;protected:virtual void 
ReplacementFor_deepCopy(const ReplacementFor_AbstractRegistry<
ReplacementFor_T_Ptr,Container>&)=0;void ReplacementFor_reinitDeepCopy(const 
ReplacementFor_AbstractRegistry<ReplacementFor_T_Ptr,Container>&
ReplacementFor_sr){ReplacementFor_unregisterAll();ReplacementFor_deepCopy(
ReplacementFor_sr);}private:Container ReplacementFor_m_list;};template<typename 
ReplacementFor_T_Ptr,typename ReplacementFor_T_Key=const char*>class 
ReplacementFor_Registry:public ReplacementFor_AbstractRegistry<
ReplacementFor_T_Ptr,std::unordered_map<ReplacementFor_T_Key,
ReplacementFor_T_Ptr*>>{public:typedef typename ReplacementFor_Registry<
ReplacementFor_T_Ptr,ReplacementFor_T_Key>::iterator iterator;typedef typename 
ReplacementFor_Registry<ReplacementFor_T_Ptr,ReplacementFor_T_Key>::
const_iterator const_iterator;ReplacementFor_Registry(void){}
ReplacementFor_Registry(const ReplacementFor_Registry&ReplacementFor_sr):
ReplacementFor_AbstractRegistry<ReplacementFor_T_Ptr,std::vector<
ReplacementFor_T_Ptr*>>(){if(this==&ReplacementFor_sr){return;}this->
ReplacementFor_reinitDeepCopy(ReplacementFor_sr);}ReplacementFor_Registry&
operator=(const ReplacementFor_Registry&ReplacementFor_sr){if(this==&
ReplacementFor_sr){return*this;}this->ReplacementFor_reinitDeepCopy(
ReplacementFor_sr);return*this;}virtual~ReplacementFor_Registry(void){
ReplacementFor_unregisterAll();}protected:virtual void 
ReplacementFor_unregisterAll(void)ReplacementFor_ELPP_FINAL{if(!this->empty()){
for(auto&&ReplacementFor_curr:this->list()){base::ReplacementFor_utils::
ReplacementFor_safeDelete(ReplacementFor_curr.second);}this->list().clear();}}
virtual void ReplacementFor_registerNew(const ReplacementFor_T_Key&
ReplacementFor_uniqKey,ReplacementFor_T_Ptr*ReplacementFor_ptr)
ReplacementFor_ELPP_FINAL{ReplacementFor_unregister(ReplacementFor_uniqKey);this
->list().insert(std::make_pair(ReplacementFor_uniqKey,ReplacementFor_ptr));}void
 ReplacementFor_unregister(const ReplacementFor_T_Key&ReplacementFor_uniqKey){
ReplacementFor_T_Ptr*ReplacementFor_existing=get(ReplacementFor_uniqKey);if(
ReplacementFor_existing!=nullptr){this->list().erase(ReplacementFor_uniqKey);
base::ReplacementFor_utils::ReplacementFor_safeDelete(ReplacementFor_existing);}
}ReplacementFor_T_Ptr*get(const ReplacementFor_T_Key&ReplacementFor_uniqKey){
iterator ReplacementFor_it=this->list().find(ReplacementFor_uniqKey);return 
ReplacementFor_it==this->list().end()?nullptr:ReplacementFor_it->second;}private
:virtual void ReplacementFor_deepCopy(const ReplacementFor_AbstractRegistry<
ReplacementFor_T_Ptr,std::unordered_map<ReplacementFor_T_Key,
ReplacementFor_T_Ptr*>>&ReplacementFor_sr)ReplacementFor_ELPP_FINAL{for(
const_iterator ReplacementFor_it=ReplacementFor_sr.cbegin();ReplacementFor_it!=
ReplacementFor_sr.cend();++ReplacementFor_it){ReplacementFor_registerNew(
ReplacementFor_it->first,new ReplacementFor_T_Ptr(*ReplacementFor_it->second));}
}};template<typename ReplacementFor_T_Ptr,typename ReplacementFor_Pred>class 
ReplacementFor_RegistryWithPred:public ReplacementFor_AbstractRegistry<
ReplacementFor_T_Ptr,std::vector<ReplacementFor_T_Ptr*>>{public:typedef typename
 ReplacementFor_RegistryWithPred<ReplacementFor_T_Ptr,ReplacementFor_Pred>::
iterator iterator;typedef typename ReplacementFor_RegistryWithPred<
ReplacementFor_T_Ptr,ReplacementFor_Pred>::const_iterator const_iterator;
ReplacementFor_RegistryWithPred(void){}virtual~ReplacementFor_RegistryWithPred(
void){ReplacementFor_unregisterAll();}ReplacementFor_RegistryWithPred(const 
ReplacementFor_RegistryWithPred&ReplacementFor_sr):
ReplacementFor_AbstractRegistry<ReplacementFor_T_Ptr,std::vector<
ReplacementFor_T_Ptr*>>(){if(this==&ReplacementFor_sr){return;}this->
ReplacementFor_reinitDeepCopy(ReplacementFor_sr);}
ReplacementFor_RegistryWithPred&operator=(const ReplacementFor_RegistryWithPred&
ReplacementFor_sr){if(this==&ReplacementFor_sr){return*this;}this->
ReplacementFor_reinitDeepCopy(ReplacementFor_sr);return*this;}friend base::type
::ReplacementFor_ostream_t&operator<<(base::type::ReplacementFor_ostream_t&os,
const ReplacementFor_RegistryWithPred&ReplacementFor_sr){for(const_iterator 
ReplacementFor_it=ReplacementFor_sr.list().begin();ReplacementFor_it!=
ReplacementFor_sr.list().end();++ReplacementFor_it){os<<
ReplacementFor_ELPP_LITERAL("\x20\x20\x20\x20")<<**ReplacementFor_it<<
ReplacementFor_ELPP_LITERAL("\n");}return os;}protected:virtual void 
ReplacementFor_unregisterAll(void)ReplacementFor_ELPP_FINAL{if(!this->empty()){
for(auto&&ReplacementFor_curr:this->list()){base::ReplacementFor_utils::
ReplacementFor_safeDelete(ReplacementFor_curr);}this->list().clear();}}virtual 
void ReplacementFor_unregister(ReplacementFor_T_Ptr*&ReplacementFor_ptr)
ReplacementFor_ELPP_FINAL{if(ReplacementFor_ptr){iterator iter=this->begin();for
(;iter!=this->end();++iter){if(ReplacementFor_ptr==*iter){break;}}if(iter!=this
->end()&&*iter!=nullptr){this->list().erase(iter);base::ReplacementFor_utils::
ReplacementFor_safeDelete(*iter);}}}virtual inline void 
ReplacementFor_registerNew(ReplacementFor_T_Ptr*ReplacementFor_ptr)
ReplacementFor_ELPP_FINAL{this->list().push_back(ReplacementFor_ptr);}template<
typename T,typename ReplacementFor_T2>ReplacementFor_T_Ptr*get(const T&arg1,
const ReplacementFor_T2 arg2){iterator iter=std::find_if(this->list().begin(),
this->list().end(),ReplacementFor_Pred(arg1,arg2));if(iter!=this->list().end()&&
*iter!=nullptr){return*iter;}return nullptr;}private:virtual void 
ReplacementFor_deepCopy(const ReplacementFor_AbstractRegistry<
ReplacementFor_T_Ptr,std::vector<ReplacementFor_T_Ptr*>>&ReplacementFor_sr){for(
const_iterator ReplacementFor_it=ReplacementFor_sr.list().begin();
ReplacementFor_it!=ReplacementFor_sr.list().end();++ReplacementFor_it){
ReplacementFor_registerNew(new ReplacementFor_T_Ptr(**ReplacementFor_it));}}};
class ReplacementFor_Utils{public:template<typename T,typename 
ReplacementFor_TPtr>static bool ReplacementFor_installCallback(const std::string
&id,std::unordered_map<std::string,ReplacementFor_TPtr>*ReplacementFor_mapT){if(
ReplacementFor_mapT->find(id)==ReplacementFor_mapT->end()){ReplacementFor_mapT->
insert(std::make_pair(id,ReplacementFor_TPtr(new T())));return true;}return 
false;}template<typename T,typename ReplacementFor_TPtr>static void 
ReplacementFor_uninstallCallback(const std::string&id,std::unordered_map<std::
string,ReplacementFor_TPtr>*ReplacementFor_mapT){if(ReplacementFor_mapT->find(id
)!=ReplacementFor_mapT->end()){ReplacementFor_mapT->erase(id);}}template<
typename T,typename ReplacementFor_TPtr>static T*ReplacementFor_callback(const 
std::string&id,std::unordered_map<std::string,ReplacementFor_TPtr>*
ReplacementFor_mapT){typename std::unordered_map<std::string,ReplacementFor_TPtr
>::iterator iter=ReplacementFor_mapT->find(id);if(iter!=ReplacementFor_mapT->end
()){return static_cast<T*>(iter->second.get());}return nullptr;}};}}class 
ReplacementFor_Loggable{public:virtual~ReplacementFor_Loggable(void){}virtual 
void log(ReplacementFor_el::base::type::ReplacementFor_ostream_t&)const=0;
private:friend inline ReplacementFor_el::base::type::ReplacementFor_ostream_t&
operator<<(ReplacementFor_el::base::type::ReplacementFor_ostream_t&os,const 
ReplacementFor_Loggable&ReplacementFor_loggable){ReplacementFor_loggable.log(os)
;return os;}};namespace base{class ReplacementFor_LogFormat:public 
ReplacementFor_Loggable{public:ReplacementFor_LogFormat(void);
ReplacementFor_LogFormat(Level ReplacementFor_level,const base::type::
ReplacementFor_string_t&format);ReplacementFor_LogFormat(const 
ReplacementFor_LogFormat&ReplacementFor_logFormat);ReplacementFor_LogFormat(
ReplacementFor_LogFormat&&ReplacementFor_logFormat);ReplacementFor_LogFormat&
operator=(const ReplacementFor_LogFormat&ReplacementFor_logFormat);virtual~
ReplacementFor_LogFormat(void){}bool operator==(const ReplacementFor_LogFormat&
other);void ReplacementFor_parseFromFormat(const base::type::
ReplacementFor_string_t&ReplacementFor_userFormat);inline Level 
ReplacementFor_level(void)const{return ReplacementFor_m_level;}inline const base
::type::ReplacementFor_string_t&ReplacementFor_userFormat(void)const{return 
ReplacementFor_m_userFormat;}inline const base::type::ReplacementFor_string_t&
format(void)const{return ReplacementFor_m_format;}inline const std::string&
ReplacementFor_dateTimeFormat(void)const{return ReplacementFor_m_dateTimeFormat;
}inline base::type::ReplacementFor_EnumType flags(void)const{return 
ReplacementFor_m_flags;}inline bool ReplacementFor_hasFlag(base::
ReplacementFor_FormatFlags flag)const{return base::ReplacementFor_utils::
ReplacementFor_hasFlag(flag,ReplacementFor_m_flags);}virtual void log(
ReplacementFor_el::base::type::ReplacementFor_ostream_t&os)const{os<<
ReplacementFor_m_format;}protected:virtual void ReplacementFor_updateDateFormat(
std::size_t index,base::type::ReplacementFor_string_t&ReplacementFor_currFormat)
ReplacementFor_ELPP_FINAL;virtual void ReplacementFor_updateFormatSpec(void)
ReplacementFor_ELPP_FINAL;inline void ReplacementFor_addFlag(base::
ReplacementFor_FormatFlags flag){base::ReplacementFor_utils::
ReplacementFor_addFlag(flag,&ReplacementFor_m_flags);}private:Level 
ReplacementFor_m_level;base::type::ReplacementFor_string_t 
ReplacementFor_m_userFormat;base::type::ReplacementFor_string_t 
ReplacementFor_m_format;std::string ReplacementFor_m_dateTimeFormat;base::type::
ReplacementFor_EnumType ReplacementFor_m_flags;std::string 
ReplacementFor_m_currentUser;std::string ReplacementFor_m_currentHost;friend 
class ReplacementFor_el::ReplacementFor_Logger;};}typedef std::function<std::
string(const ReplacementFor_LogMessage*)>
ReplacementFor_FormatSpecifierValueResolver;class 
ReplacementFor_CustomFormatSpecifier{public:ReplacementFor_CustomFormatSpecifier
(const char*ReplacementFor_formatSpecifier,const 
ReplacementFor_FormatSpecifierValueResolver&ReplacementFor_resolver):
ReplacementFor_m_formatSpecifier(ReplacementFor_formatSpecifier),
ReplacementFor_m_resolver(ReplacementFor_resolver){}inline const char*
ReplacementFor_formatSpecifier(void)const{return 
ReplacementFor_m_formatSpecifier;}inline const 
ReplacementFor_FormatSpecifierValueResolver&ReplacementFor_resolver(void)const{
return ReplacementFor_m_resolver;}inline bool operator==(const char*
ReplacementFor_formatSpecifier){return strcmp(ReplacementFor_m_formatSpecifier,
ReplacementFor_formatSpecifier)==((0x877+2289-0xf61)+4010-4529);}private:const 
char*ReplacementFor_m_formatSpecifier;
ReplacementFor_FormatSpecifierValueResolver ReplacementFor_m_resolver;};class 
ReplacementFor_Configuration:public ReplacementFor_Loggable{public:
ReplacementFor_Configuration(const ReplacementFor_Configuration&c);
ReplacementFor_Configuration&operator=(const ReplacementFor_Configuration&c);
virtual~ReplacementFor_Configuration(void){}ReplacementFor_Configuration(Level 
ReplacementFor_level,ReplacementFor_ConfigurationType 
ReplacementFor_configurationType,const std::string&value);inline Level 
ReplacementFor_level(void)const{return ReplacementFor_m_level;}inline 
ReplacementFor_ConfigurationType ReplacementFor_configurationType(void)const{
return ReplacementFor_m_configurationType;}inline const std::string&value(void)
const{return ReplacementFor_m_value;}inline void ReplacementFor_setValue(const 
std::string&value){ReplacementFor_m_value=value;}virtual void log(
ReplacementFor_el::base::type::ReplacementFor_ostream_t&os)const;class 
ReplacementFor_Predicate{public:ReplacementFor_Predicate(Level 
ReplacementFor_level,ReplacementFor_ConfigurationType 
ReplacementFor_configurationType);bool operator()(const 
ReplacementFor_Configuration*ReplacementFor_conf)const;private:Level 
ReplacementFor_m_level;ReplacementFor_ConfigurationType 
ReplacementFor_m_configurationType;};private:Level ReplacementFor_m_level;
ReplacementFor_ConfigurationType ReplacementFor_m_configurationType;std::string 
ReplacementFor_m_value;};class ReplacementFor_Configurations:public base::
ReplacementFor_utils::ReplacementFor_RegistryWithPred<
ReplacementFor_Configuration,ReplacementFor_Configuration::
ReplacementFor_Predicate>{public:ReplacementFor_Configurations(void);
ReplacementFor_Configurations(const std::string&ReplacementFor_configurationFile
,bool ReplacementFor_useDefaultsForRemaining=true,ReplacementFor_Configurations*
base=nullptr);virtual~ReplacementFor_Configurations(void){}bool 
ReplacementFor_parseFromFile(const std::string&ReplacementFor_configurationFile,
ReplacementFor_Configurations*base=nullptr);bool ReplacementFor_parseFromText(
const std::string&ReplacementFor_configurationsString,
ReplacementFor_Configurations*base=nullptr);void ReplacementFor_setFromBase(
ReplacementFor_Configurations*base);bool ReplacementFor_hasConfiguration(
ReplacementFor_ConfigurationType ReplacementFor_configurationType);bool 
ReplacementFor_hasConfiguration(Level ReplacementFor_level,
ReplacementFor_ConfigurationType ReplacementFor_configurationType);void set(
Level ReplacementFor_level,ReplacementFor_ConfigurationType 
ReplacementFor_configurationType,const std::string&value);void set(
ReplacementFor_Configuration*ReplacementFor_conf);inline 
ReplacementFor_Configuration*get(Level ReplacementFor_level,
ReplacementFor_ConfigurationType ReplacementFor_configurationType){base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
lock());return ReplacementFor_RegistryWithPred<ReplacementFor_Configuration,
ReplacementFor_Configuration::ReplacementFor_Predicate>::get(
ReplacementFor_level,ReplacementFor_configurationType);}inline void 
ReplacementFor_setGlobally(ReplacementFor_ConfigurationType 
ReplacementFor_configurationType,const std::string&value){
ReplacementFor_setGlobally(ReplacementFor_configurationType,value,false);}inline
 void clear(void){base::ReplacementFor_threading::ReplacementFor_ScopedLock 
ReplacementFor_scopedLock(lock());ReplacementFor_unregisterAll();}inline const 
std::string&ReplacementFor_configurationFile(void)const{return 
ReplacementFor_m_configurationFile;}void ReplacementFor_setToDefault(void);void 
ReplacementFor_setRemainingToDefault(void);class ReplacementFor_Parser:base::
ReplacementFor_StaticClass{public:static bool ReplacementFor_parseFromFile(const
 std::string&ReplacementFor_configurationFile,ReplacementFor_Configurations*
ReplacementFor_sender,ReplacementFor_Configurations*base=nullptr);static bool 
ReplacementFor_parseFromText(const std::string&
ReplacementFor_configurationsString,ReplacementFor_Configurations*
ReplacementFor_sender,ReplacementFor_Configurations*base=nullptr);private:friend
 class ReplacementFor_el::ReplacementFor_Loggers;static void 
ReplacementFor_ignoreComments(std::string*line);static bool 
ReplacementFor_isLevel(const std::string&line);static bool 
ReplacementFor_isComment(const std::string&line);static inline bool 
ReplacementFor_isConfig(const std::string&line);static bool 
ReplacementFor_parseLine(std::string*line,std::string*
ReplacementFor_currConfigStr,std::string*ReplacementFor_currLevelStr,Level*
ReplacementFor_currLevel,ReplacementFor_Configurations*ReplacementFor_conf);};
private:std::string ReplacementFor_m_configurationFile;bool 
ReplacementFor_m_isFromFile;friend class ReplacementFor_el::
ReplacementFor_Loggers;void ReplacementFor_unsafeSetIfNotExist(Level 
ReplacementFor_level,ReplacementFor_ConfigurationType 
ReplacementFor_configurationType,const std::string&value);void 
ReplacementFor_unsafeSet(Level ReplacementFor_level,
ReplacementFor_ConfigurationType ReplacementFor_configurationType,const std::
string&value);void ReplacementFor_setGlobally(ReplacementFor_ConfigurationType 
ReplacementFor_configurationType,const std::string&value,bool 
ReplacementFor_includeGlobalLevel);void ReplacementFor_unsafeSetGlobally(
ReplacementFor_ConfigurationType ReplacementFor_configurationType,const std::
string&value,bool ReplacementFor_includeGlobalLevel);};namespace base{typedef 
std::shared_ptr<base::type::ReplacementFor_fstream_t>
ReplacementFor_FileStreamPtr;typedef std::unordered_map<std::string,
ReplacementFor_FileStreamPtr>ReplacementFor_LogStreamsReferenceMap;class 
ReplacementFor_TypedConfigurations:public base::ReplacementFor_threading::
ReplacementFor_ThreadSafe{public:ReplacementFor_TypedConfigurations(
ReplacementFor_Configurations*ReplacementFor_configurations,base::
ReplacementFor_LogStreamsReferenceMap*ReplacementFor_logStreamsReference);
ReplacementFor_TypedConfigurations(const ReplacementFor_TypedConfigurations&
other);virtual~ReplacementFor_TypedConfigurations(void){}const 
ReplacementFor_Configurations*ReplacementFor_configurations(void)const{return 
ReplacementFor_m_configurations;}bool ReplacementFor_enabled(Level 
ReplacementFor_level);bool ReplacementFor_toFile(Level ReplacementFor_level);
const std::string&ReplacementFor_filename(Level ReplacementFor_level);bool 
ReplacementFor_toStandardOutput(Level ReplacementFor_level);const base::
ReplacementFor_LogFormat&ReplacementFor_logFormat(Level ReplacementFor_level);
const base::ReplacementFor_SubsecondPrecision&ReplacementFor_subsecondPrecision(
Level ReplacementFor_level=Level::Global);const base::
ReplacementFor_MillisecondsWidth&ReplacementFor_millisecondsWidth(Level 
ReplacementFor_level=Level::Global);bool ReplacementFor_performanceTracking(
Level ReplacementFor_level=Level::Global);base::type::ReplacementFor_fstream_t*
ReplacementFor_fileStream(Level ReplacementFor_level);std::size_t 
ReplacementFor_maxLogFileSize(Level ReplacementFor_level);std::size_t 
ReplacementFor_logFlushThreshold(Level ReplacementFor_level);private:
ReplacementFor_Configurations*ReplacementFor_m_configurations;std::unordered_map
<Level,bool>ReplacementFor_m_enabledMap;std::unordered_map<Level,bool>
ReplacementFor_m_toFileMap;std::unordered_map<Level,std::string>
ReplacementFor_m_filenameMap;std::unordered_map<Level,bool>
ReplacementFor_m_toStandardOutputMap;std::unordered_map<Level,base::
ReplacementFor_LogFormat>ReplacementFor_m_logFormatMap;std::unordered_map<Level,
base::ReplacementFor_SubsecondPrecision>ReplacementFor_m_subsecondPrecisionMap;
std::unordered_map<Level,bool>ReplacementFor_m_performanceTrackingMap;std::
unordered_map<Level,base::ReplacementFor_FileStreamPtr>
ReplacementFor_m_fileStreamMap;std::unordered_map<Level,std::size_t>
ReplacementFor_m_maxLogFileSizeMap;std::unordered_map<Level,std::size_t>
ReplacementFor_m_logFlushThresholdMap;base::
ReplacementFor_LogStreamsReferenceMap*ReplacementFor_m_logStreamsReference;
friend class ReplacementFor_el::ReplacementFor_Helpers;friend class 
ReplacementFor_el::base::ReplacementFor_MessageBuilder;friend class 
ReplacementFor_el::base::ReplacementFor_Writer;friend class ReplacementFor_el::
base::ReplacementFor_DefaultLogDispatchCallback;friend class ReplacementFor_el::
base::ReplacementFor_LogDispatcher;template<typename ReplacementFor_Conf_T>
inline ReplacementFor_Conf_T ReplacementFor_getConfigByVal(Level 
ReplacementFor_level,const std::unordered_map<Level,ReplacementFor_Conf_T>*
ReplacementFor_confMap,const char*ReplacementFor_confName){base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
lock());return ReplacementFor_unsafeGetConfigByVal(ReplacementFor_level,
ReplacementFor_confMap,ReplacementFor_confName);}template<typename 
ReplacementFor_Conf_T>inline ReplacementFor_Conf_T&ReplacementFor_getConfigByRef
(Level ReplacementFor_level,std::unordered_map<Level,ReplacementFor_Conf_T>*
ReplacementFor_confMap,const char*ReplacementFor_confName){base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
lock());return ReplacementFor_unsafeGetConfigByRef(ReplacementFor_level,
ReplacementFor_confMap,ReplacementFor_confName);}template<typename 
ReplacementFor_Conf_T>ReplacementFor_Conf_T ReplacementFor_unsafeGetConfigByVal(
Level ReplacementFor_level,const std::unordered_map<Level,ReplacementFor_Conf_T>
*ReplacementFor_confMap,const char*ReplacementFor_confName){
ReplacementFor_ELPP_UNUSED(ReplacementFor_confName);typename std::unordered_map<
Level,ReplacementFor_Conf_T>::const_iterator ReplacementFor_it=
ReplacementFor_confMap->find(ReplacementFor_level);if(ReplacementFor_it==
ReplacementFor_confMap->end()){try{return ReplacementFor_confMap->at(Level::
Global);}catch(...){ReplacementFor_ELPP_INTERNAL_ERROR(
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x67\x65\x74\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x5b"
<<ReplacementFor_confName<<
"\x5d\x20\x66\x6f\x72\x20\x6c\x65\x76\x65\x6c\x20\x5b"<<
ReplacementFor_LevelHelper::ReplacementFor_convertToString(ReplacementFor_level)
<<"\x5d"<<std::endl<<
"\x50\x6c\x65\x61\x73\x65\x20\x65\x6e\x73\x75\x72\x65\x20\x79\x6f\x75\x20\x68\x61\x76\x65\x20\x70\x72\x6f\x70\x65\x72\x6c\x79\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x65\x64\x20\x6c\x6f\x67\x67\x65\x72\x2e"
,false);return ReplacementFor_Conf_T();}}return ReplacementFor_it->second;}
template<typename ReplacementFor_Conf_T>ReplacementFor_Conf_T&
ReplacementFor_unsafeGetConfigByRef(Level ReplacementFor_level,std::
unordered_map<Level,ReplacementFor_Conf_T>*ReplacementFor_confMap,const char*
ReplacementFor_confName){ReplacementFor_ELPP_UNUSED(ReplacementFor_confName);
typename std::unordered_map<Level,ReplacementFor_Conf_T>::iterator 
ReplacementFor_it=ReplacementFor_confMap->find(ReplacementFor_level);if(
ReplacementFor_it==ReplacementFor_confMap->end()){try{return 
ReplacementFor_confMap->at(Level::Global);}catch(...){
ReplacementFor_ELPP_INTERNAL_ERROR(
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x67\x65\x74\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x5b"
<<ReplacementFor_confName<<
"\x5d\x20\x66\x6f\x72\x20\x6c\x65\x76\x65\x6c\x20\x5b"<<
ReplacementFor_LevelHelper::ReplacementFor_convertToString(ReplacementFor_level)
<<"\x5d"<<std::endl<<
"\x50\x6c\x65\x61\x73\x65\x20\x65\x6e\x73\x75\x72\x65\x20\x79\x6f\x75\x20\x68\x61\x76\x65\x20\x70\x72\x6f\x70\x65\x72\x6c\x79\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x65\x64\x20\x6c\x6f\x67\x67\x65\x72\x2e"
,false);}}return ReplacementFor_it->second;}template<typename 
ReplacementFor_Conf_T>void ReplacementFor_setValue(Level ReplacementFor_level,
const ReplacementFor_Conf_T&value,std::unordered_map<Level,ReplacementFor_Conf_T
>*ReplacementFor_confMap,bool ReplacementFor_includeGlobalLevel=true){if(
ReplacementFor_confMap->empty()&&ReplacementFor_includeGlobalLevel){
ReplacementFor_confMap->insert(std::make_pair(Level::Global,value));return;}
typename std::unordered_map<Level,ReplacementFor_Conf_T>::iterator 
ReplacementFor_it=ReplacementFor_confMap->find(Level::Global);if(
ReplacementFor_it!=ReplacementFor_confMap->end()&&ReplacementFor_it->second==
value){return;}ReplacementFor_it=ReplacementFor_confMap->find(
ReplacementFor_level);if(ReplacementFor_it==ReplacementFor_confMap->end()){
ReplacementFor_confMap->insert(std::make_pair(ReplacementFor_level,value));}else
{ReplacementFor_confMap->at(ReplacementFor_level)=value;}}void 
ReplacementFor_build(ReplacementFor_Configurations*ReplacementFor_configurations
);unsigned long ReplacementFor_getULong(std::string ReplacementFor_confVal);std
::string ReplacementFor_resolveFilename(const std::string&
ReplacementFor_filename);void ReplacementFor_insertFile(Level 
ReplacementFor_level,const std::string&ReplacementFor_fullFilename);bool 
ReplacementFor_unsafeValidateFileRolling(Level ReplacementFor_level,const 
ReplacementFor_PreRollOutCallback&ReplacementFor_preRollOutCallback);inline bool
 ReplacementFor_validateFileRolling(Level ReplacementFor_level,const 
ReplacementFor_PreRollOutCallback&ReplacementFor_preRollOutCallback){base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
lock());return ReplacementFor_unsafeValidateFileRolling(ReplacementFor_level,
ReplacementFor_preRollOutCallback);}};class ReplacementFor_HitCounter{public:
ReplacementFor_HitCounter(void):ReplacementFor_m_filename(""),
ReplacementFor_m_lineNumber(((0x19f5+3898-0x26ed)+(0x10d2+3829-0x154a)-
(0xe11+961-0x513))),ReplacementFor_m_hitCounts(((0xf02+1772-0x1178)+
(0x2136+2512-0x1ffe)-(0x1025+6811-0x1b42))){}ReplacementFor_HitCounter(const 
char*ReplacementFor_filename,base::type::ReplacementFor_LineNumber 
ReplacementFor_lineNumber):ReplacementFor_m_filename(ReplacementFor_filename),
ReplacementFor_m_lineNumber(ReplacementFor_lineNumber),
ReplacementFor_m_hitCounts(((0x15cf+4694-0x24fd)+(0xa3d+174-0x352)-
(0x11f1+8150-0x2706))){}ReplacementFor_HitCounter(const 
ReplacementFor_HitCounter&ReplacementFor_hitCounter):ReplacementFor_m_filename(
ReplacementFor_hitCounter.ReplacementFor_m_filename),ReplacementFor_m_lineNumber
(ReplacementFor_hitCounter.ReplacementFor_m_lineNumber),
ReplacementFor_m_hitCounts(ReplacementFor_hitCounter.ReplacementFor_m_hitCounts)
{}ReplacementFor_HitCounter&operator=(const ReplacementFor_HitCounter&
ReplacementFor_hitCounter){if(&ReplacementFor_hitCounter!=this){
ReplacementFor_m_filename=ReplacementFor_hitCounter.ReplacementFor_m_filename;
ReplacementFor_m_lineNumber=ReplacementFor_hitCounter.
ReplacementFor_m_lineNumber;ReplacementFor_m_hitCounts=ReplacementFor_hitCounter
.ReplacementFor_m_hitCounts;}return*this;}virtual~ReplacementFor_HitCounter(void
){}inline void ReplacementFor_resetLocation(const char*ReplacementFor_filename,
base::type::ReplacementFor_LineNumber ReplacementFor_lineNumber){
ReplacementFor_m_filename=ReplacementFor_filename;ReplacementFor_m_lineNumber=
ReplacementFor_lineNumber;}inline void ReplacementFor_validateHitCounts(std::
size_t n){if(ReplacementFor_m_hitCounts>=base::ReplacementFor_consts::
ReplacementFor_kMaxLogPerCounter){ReplacementFor_m_hitCounts=(n>=(8372+
(0x5db+8104-0x21ff)-9271)?base::ReplacementFor_consts::
ReplacementFor_kMaxLogPerCounter%n:((0x21a8+2643-0x2077)+(0xb19+8083-0x2278)-
5048));}++ReplacementFor_m_hitCounts;}inline const char*ReplacementFor_filename(
void)const{return ReplacementFor_m_filename;}inline base::type::
ReplacementFor_LineNumber ReplacementFor_lineNumber(void)const{return 
ReplacementFor_m_lineNumber;}inline std::size_t ReplacementFor_hitCounts(void)
const{return ReplacementFor_m_hitCounts;}inline void increment(void){++
ReplacementFor_m_hitCounts;}class ReplacementFor_Predicate{public:
ReplacementFor_Predicate(const char*ReplacementFor_filename,base::type::
ReplacementFor_LineNumber ReplacementFor_lineNumber):ReplacementFor_m_filename(
ReplacementFor_filename),ReplacementFor_m_lineNumber(ReplacementFor_lineNumber){
}inline bool operator()(const ReplacementFor_HitCounter*counter){return((counter
!=nullptr)&&(strcmp(counter->ReplacementFor_m_filename,ReplacementFor_m_filename
)==((0x1599+910-0x11d2)+(0x10cb+1204-0x8bc)-5144))&&(counter->
ReplacementFor_m_lineNumber==ReplacementFor_m_lineNumber));}private:const char*
ReplacementFor_m_filename;base::type::ReplacementFor_LineNumber 
ReplacementFor_m_lineNumber;};private:const char*ReplacementFor_m_filename;base
::type::ReplacementFor_LineNumber ReplacementFor_m_lineNumber;std::size_t 
ReplacementFor_m_hitCounts;};class ReplacementFor_RegisteredHitCounters:public 
base::ReplacementFor_utils::ReplacementFor_RegistryWithPred<base::
ReplacementFor_HitCounter,base::ReplacementFor_HitCounter::
ReplacementFor_Predicate>{public:bool ReplacementFor_validateEveryN(const char*
ReplacementFor_filename,base::type::ReplacementFor_LineNumber 
ReplacementFor_lineNumber,std::size_t n);bool ReplacementFor_validateAfterN(
const char*ReplacementFor_filename,base::type::ReplacementFor_LineNumber 
ReplacementFor_lineNumber,std::size_t n);bool ReplacementFor_validateNTimes(
const char*ReplacementFor_filename,base::type::ReplacementFor_LineNumber 
ReplacementFor_lineNumber,std::size_t n);inline const base::
ReplacementFor_HitCounter*ReplacementFor_getCounter(const char*
ReplacementFor_filename,base::type::ReplacementFor_LineNumber 
ReplacementFor_lineNumber){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());return get(
ReplacementFor_filename,ReplacementFor_lineNumber);}};enum class 
ReplacementFor_DispatchAction:base::type::ReplacementFor_EnumType{None=(
(0x8a5+226-0x412)+(0x21d1+3211-0xe10)-9664),ReplacementFor_NormalLog=(
(0xa3d+7856-0x26c7)+(0x1463+2773-0x1050)-(0x1c27+6439-0x2442)),SysLog=(
(0x9e3+1976-0xd05)+(0xf19+435-0x2a3)-(0x1333+7450-0x1d92))};}template<typename T
>class ReplacementFor_Callback:protected base::ReplacementFor_threading::
ReplacementFor_ThreadSafe{public:ReplacementFor_Callback(void):
ReplacementFor_m_enabled(true){}inline bool ReplacementFor_enabled(void)const{
return ReplacementFor_m_enabled;}inline void ReplacementFor_setEnabled(bool 
ReplacementFor_enabled){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());
ReplacementFor_m_enabled=ReplacementFor_enabled;}protected:virtual void 
ReplacementFor_handle(const T*ReplacementFor_handlePtr)=0;private:bool 
ReplacementFor_m_enabled;};class ReplacementFor_LogDispatchData{public:
ReplacementFor_LogDispatchData():ReplacementFor_m_logMessage(nullptr),
ReplacementFor_m_dispatchAction(base::ReplacementFor_DispatchAction::None){}
inline const ReplacementFor_LogMessage*ReplacementFor_logMessage(void)const{
return ReplacementFor_m_logMessage;}inline base::ReplacementFor_DispatchAction 
ReplacementFor_dispatchAction(void)const{return ReplacementFor_m_dispatchAction;
}inline void ReplacementFor_setLogMessage(ReplacementFor_LogMessage*
ReplacementFor_logMessage){ReplacementFor_m_logMessage=ReplacementFor_logMessage
;}inline void ReplacementFor_setDispatchAction(base::
ReplacementFor_DispatchAction ReplacementFor_dispatchAction){
ReplacementFor_m_dispatchAction=ReplacementFor_dispatchAction;}private:
ReplacementFor_LogMessage*ReplacementFor_m_logMessage;base::
ReplacementFor_DispatchAction ReplacementFor_m_dispatchAction;friend class base
::ReplacementFor_LogDispatcher;};class ReplacementFor_LogDispatchCallback:public
 ReplacementFor_Callback<ReplacementFor_LogDispatchData>{protected:virtual void 
ReplacementFor_handle(const ReplacementFor_LogDispatchData*data);base::
ReplacementFor_threading::Mutex&ReplacementFor_fileHandle(const 
ReplacementFor_LogDispatchData*data);private:friend class base::
ReplacementFor_LogDispatcher;std::unordered_map<std::string,std::unique_ptr<base
::ReplacementFor_threading::Mutex>>ReplacementFor_m_fileLocks;base::
ReplacementFor_threading::Mutex ReplacementFor_m_fileLocksMapLock;};class 
ReplacementFor_PerformanceTrackingCallback:public ReplacementFor_Callback<
ReplacementFor_PerformanceTrackingData>{private:friend class base::
ReplacementFor_PerformanceTracker;};class 
ReplacementFor_LoggerRegistrationCallback:public ReplacementFor_Callback<
ReplacementFor_Logger>{private:friend class base::
ReplacementFor_RegisteredLoggers;};class ReplacementFor_LogBuilder:base::
ReplacementFor_NoCopy{public:ReplacementFor_LogBuilder():
ReplacementFor_m_termSupportsColor(base::ReplacementFor_utils::OS::
ReplacementFor_termSupportsColor()){}virtual~ReplacementFor_LogBuilder(void){
ReplacementFor_ELPP_INTERNAL_INFO(((0x654+4769-0x1779)+(0x1152+4056-0x14fd)-
(0x1502+975-0xb2b)),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x6c\x6f\x67\x20\x62\x75\x69\x6c\x64\x65\x72\x2e\x2e\x2e"
)}virtual base::type::ReplacementFor_string_t ReplacementFor_build(const 
ReplacementFor_LogMessage*ReplacementFor_logMessage,bool 
ReplacementFor_appendNewLine)const=0;void ReplacementFor_convertToColoredOutput(
base::type::ReplacementFor_string_t*ReplacementFor_logLine,Level 
ReplacementFor_level);private:bool ReplacementFor_m_termSupportsColor;friend 
class ReplacementFor_el::base::ReplacementFor_DefaultLogDispatchCallback;};
typedef std::shared_ptr<ReplacementFor_LogBuilder>ReplacementFor_LogBuilderPtr;
class ReplacementFor_Logger:public base::ReplacementFor_threading::
ReplacementFor_ThreadSafe,public ReplacementFor_Loggable{public:
ReplacementFor_Logger(const std::string&id,base::
ReplacementFor_LogStreamsReferenceMap*ReplacementFor_logStreamsReference);
ReplacementFor_Logger(const std::string&id,const ReplacementFor_Configurations&
ReplacementFor_configurations,base::ReplacementFor_LogStreamsReferenceMap*
ReplacementFor_logStreamsReference);ReplacementFor_Logger(const 
ReplacementFor_Logger&ReplacementFor_logger);ReplacementFor_Logger&operator=(
const ReplacementFor_Logger&ReplacementFor_logger);virtual~ReplacementFor_Logger
(void){base::ReplacementFor_utils::ReplacementFor_safeDelete(
ReplacementFor_m_typedConfigurations);}virtual inline void log(ReplacementFor_el
::base::type::ReplacementFor_ostream_t&os)const{os<<ReplacementFor_m_id.c_str();
}void ReplacementFor_configure(const ReplacementFor_Configurations&
ReplacementFor_configurations);void ReplacementFor_reconfigure(void);inline 
const std::string&id(void)const{return ReplacementFor_m_id;}inline const std::
string&ReplacementFor_parentApplicationName(void)const{return 
ReplacementFor_m_parentApplicationName;}inline void 
ReplacementFor_setParentApplicationName(const std::string&
ReplacementFor_parentApplicationName){ReplacementFor_m_parentApplicationName=
ReplacementFor_parentApplicationName;}inline ReplacementFor_Configurations*
ReplacementFor_configurations(void){return&ReplacementFor_m_configurations;}
inline base::ReplacementFor_TypedConfigurations*
ReplacementFor_typedConfigurations(void){return 
ReplacementFor_m_typedConfigurations;}static bool ReplacementFor_isValidId(const
 std::string&id);void flush(void);void flush(Level ReplacementFor_level,base::
type::ReplacementFor_fstream_t*fs);inline bool ReplacementFor_isFlushNeeded(
Level ReplacementFor_level){return++ReplacementFor_m_unflushedCount.find(
ReplacementFor_level)->second>=ReplacementFor_m_typedConfigurations->
ReplacementFor_logFlushThreshold(ReplacementFor_level);}inline 
ReplacementFor_LogBuilder*ReplacementFor_logBuilder(void)const{return 
ReplacementFor_m_logBuilder.get();}inline void ReplacementFor_setLogBuilder(
const ReplacementFor_LogBuilderPtr&ReplacementFor_logBuilder){
ReplacementFor_m_logBuilder=ReplacementFor_logBuilder;}inline bool 
ReplacementFor_enabled(Level ReplacementFor_level)const{return 
ReplacementFor_m_typedConfigurations->ReplacementFor_enabled(
ReplacementFor_level);}
#if ReplacementFor_ELPP_VARIADIC_TEMPLATES_SUPPORTED
#  define ReplacementFor_LOGGER_LEVEL_WRITERS_SIGNATURES(\
ReplacementFor_FUNCTION_NAME)\
template <typename T, typename... ReplacementFor_Args>\
inline void ReplacementFor_FUNCTION_NAME(const char*, const T&, const \
ReplacementFor_Args&...);\
template <typename T>\
inline void ReplacementFor_FUNCTION_NAME(const T&);
template<typename T,typename...ReplacementFor_Args>inline void 
ReplacementFor_verbose(int,const char*,const T&,const ReplacementFor_Args&...);
template<typename T>inline void ReplacementFor_verbose(int,const T&);
ReplacementFor_LOGGER_LEVEL_WRITERS_SIGNATURES(ReplacementFor_info)
ReplacementFor_LOGGER_LEVEL_WRITERS_SIGNATURES(ReplacementFor_debug)
ReplacementFor_LOGGER_LEVEL_WRITERS_SIGNATURES(ReplacementFor_warn)
ReplacementFor_LOGGER_LEVEL_WRITERS_SIGNATURES(error)
ReplacementFor_LOGGER_LEVEL_WRITERS_SIGNATURES(ReplacementFor_fatal)
ReplacementFor_LOGGER_LEVEL_WRITERS_SIGNATURES(ReplacementFor_trace)
#  undef ReplacementFor_LOGGER_LEVEL_WRITERS_SIGNATURES
#endif 
private:std::string ReplacementFor_m_id;base::ReplacementFor_TypedConfigurations
*ReplacementFor_m_typedConfigurations;base::type::ReplacementFor_stringstream_t 
ReplacementFor_m_stream;std::string ReplacementFor_m_parentApplicationName;bool 
ReplacementFor_m_isConfigured;ReplacementFor_Configurations 
ReplacementFor_m_configurations;std::unordered_map<Level,unsigned int>
ReplacementFor_m_unflushedCount;base::ReplacementFor_LogStreamsReferenceMap*
ReplacementFor_m_logStreamsReference;ReplacementFor_LogBuilderPtr 
ReplacementFor_m_logBuilder;friend class ReplacementFor_el::
ReplacementFor_LogMessage;friend class ReplacementFor_el::ReplacementFor_Loggers
;friend class ReplacementFor_el::ReplacementFor_Helpers;friend class 
ReplacementFor_el::base::ReplacementFor_RegisteredLoggers;friend class 
ReplacementFor_el::base::ReplacementFor_DefaultLogDispatchCallback;friend class 
ReplacementFor_el::base::ReplacementFor_MessageBuilder;friend class 
ReplacementFor_el::base::ReplacementFor_Writer;friend class ReplacementFor_el::
base::ReplacementFor_PErrorWriter;friend class ReplacementFor_el::base::
ReplacementFor_Storage;friend class ReplacementFor_el::base::
ReplacementFor_PerformanceTracker;friend class ReplacementFor_el::base::
ReplacementFor_LogDispatcher;ReplacementFor_Logger(void);
#if ReplacementFor_ELPP_VARIADIC_TEMPLATES_SUPPORTED
template<typename T,typename...ReplacementFor_Args>void ReplacementFor_log_(
Level,int,const char*,const T&,const ReplacementFor_Args&...);template<typename 
T>inline void ReplacementFor_log_(Level,int,const T&);template<typename T,
typename...ReplacementFor_Args>void log(Level,const char*,const T&,const 
ReplacementFor_Args&...);template<typename T>inline void log(Level,const T&);
#endif 
void ReplacementFor_initUnflushedCount(void);inline base::type::
ReplacementFor_stringstream_t&ReplacementFor_stream(void){return 
ReplacementFor_m_stream;}void ReplacementFor_resolveLoggerFormatSpec(void)const;
};namespace base{class ReplacementFor_RegisteredLoggers:public base::
ReplacementFor_utils::ReplacementFor_Registry<ReplacementFor_Logger,std::string>
{public:explicit ReplacementFor_RegisteredLoggers(const 
ReplacementFor_LogBuilderPtr&ReplacementFor_defaultLogBuilder);virtual~
ReplacementFor_RegisteredLoggers(void){ReplacementFor_unsafeFlushAll();}inline 
void ReplacementFor_setDefaultConfigurations(const ReplacementFor_Configurations
&ReplacementFor_configurations){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());
ReplacementFor_m_defaultConfigurations.ReplacementFor_setFromBase(const_cast<
ReplacementFor_Configurations*>(&ReplacementFor_configurations));}inline 
ReplacementFor_Configurations*ReplacementFor_defaultConfigurations(void){return&
ReplacementFor_m_defaultConfigurations;}ReplacementFor_Logger*get(const std::
string&id,bool ReplacementFor_forceCreation=true);template<typename T>inline 
bool ReplacementFor_installLoggerRegistrationCallback(const std::string&id){
return base::ReplacementFor_utils::ReplacementFor_Utils::
ReplacementFor_installCallback<T,base::type::
ReplacementFor_LoggerRegistrationCallbackPtr>(id,&
ReplacementFor_m_loggerRegistrationCallbacks);}template<typename T>inline void 
ReplacementFor_uninstallLoggerRegistrationCallback(const std::string&id){base::
ReplacementFor_utils::ReplacementFor_Utils::ReplacementFor_uninstallCallback<T,
base::type::ReplacementFor_LoggerRegistrationCallbackPtr>(id,&
ReplacementFor_m_loggerRegistrationCallbacks);}template<typename T>inline T*
ReplacementFor_loggerRegistrationCallback(const std::string&id){return base::
ReplacementFor_utils::ReplacementFor_Utils::ReplacementFor_callback<T,base::type
::ReplacementFor_LoggerRegistrationCallbackPtr>(id,&
ReplacementFor_m_loggerRegistrationCallbacks);}bool remove(const std::string&id)
;inline bool ReplacementFor_has(const std::string&id){return get(id,false)!=
nullptr;}inline void ReplacementFor_unregister(ReplacementFor_Logger*&
ReplacementFor_logger){base::ReplacementFor_threading::ReplacementFor_ScopedLock
 ReplacementFor_scopedLock(lock());base::ReplacementFor_utils::
ReplacementFor_Registry<ReplacementFor_Logger,std::string>::
ReplacementFor_unregister(ReplacementFor_logger->id());}inline base::
ReplacementFor_LogStreamsReferenceMap*ReplacementFor_logStreamsReference(void){
return&ReplacementFor_m_logStreamsReference;}inline void flushAll(void){base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
lock());ReplacementFor_unsafeFlushAll();}inline void 
ReplacementFor_setDefaultLogBuilder(ReplacementFor_LogBuilderPtr&
ReplacementFor_logBuilderPtr){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());
ReplacementFor_m_defaultLogBuilder=ReplacementFor_logBuilderPtr;}private:
ReplacementFor_LogBuilderPtr ReplacementFor_m_defaultLogBuilder;
ReplacementFor_Configurations ReplacementFor_m_defaultConfigurations;base::
ReplacementFor_LogStreamsReferenceMap ReplacementFor_m_logStreamsReference;std::
unordered_map<std::string,base::type::
ReplacementFor_LoggerRegistrationCallbackPtr>
ReplacementFor_m_loggerRegistrationCallbacks;friend class ReplacementFor_el::
base::ReplacementFor_Storage;void ReplacementFor_unsafeFlushAll(void);};class 
ReplacementFor_VRegistry:base::ReplacementFor_NoCopy,public base::
ReplacementFor_threading::ReplacementFor_ThreadSafe{public:explicit 
ReplacementFor_VRegistry(base::type::ReplacementFor_VerboseLevel 
ReplacementFor_level,base::type::ReplacementFor_EnumType*ReplacementFor_pFlags);
void ReplacementFor_setLevel(base::type::ReplacementFor_VerboseLevel 
ReplacementFor_level);inline base::type::ReplacementFor_VerboseLevel 
ReplacementFor_level(void)const{return ReplacementFor_m_level;}inline void 
ReplacementFor_clearModules(void){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());
ReplacementFor_m_modules.clear();}void ReplacementFor_setModules(const char*
ReplacementFor_modules);bool ReplacementFor_allowed(base::type::
ReplacementFor_VerboseLevel ReplacementFor_vlevel,const char*ReplacementFor_file
);inline const std::unordered_map<std::string,base::type::
ReplacementFor_VerboseLevel>&ReplacementFor_modules(void)const{return 
ReplacementFor_m_modules;}void ReplacementFor_setFromArgs(const base::
ReplacementFor_utils::ReplacementFor_CommandLineArgs*
ReplacementFor_commandLineArgs);inline bool ReplacementFor_vModulesEnabled(void)
{return!base::ReplacementFor_utils::ReplacementFor_hasFlag(
ReplacementFor_LoggingFlag::ReplacementFor_DisableVModules,*
ReplacementFor_m_pFlags);}private:base::type::ReplacementFor_VerboseLevel 
ReplacementFor_m_level;base::type::ReplacementFor_EnumType*
ReplacementFor_m_pFlags;std::unordered_map<std::string,base::type::
ReplacementFor_VerboseLevel>ReplacementFor_m_modules;};}class 
ReplacementFor_LogMessage{public:ReplacementFor_LogMessage(Level 
ReplacementFor_level,const std::string&ReplacementFor_file,base::type::
ReplacementFor_LineNumber line,const std::string&ReplacementFor_func,base::type
::ReplacementFor_VerboseLevel ReplacementFor_verboseLevel,ReplacementFor_Logger*
ReplacementFor_logger):ReplacementFor_m_level(ReplacementFor_level),
ReplacementFor_m_file(ReplacementFor_file),ReplacementFor_m_line(line),
ReplacementFor_m_func(ReplacementFor_func),ReplacementFor_m_verboseLevel(
ReplacementFor_verboseLevel),ReplacementFor_m_logger(ReplacementFor_logger),
ReplacementFor_m_message(ReplacementFor_logger->ReplacementFor_stream().str()){}
inline Level ReplacementFor_level(void)const{return ReplacementFor_m_level;}
inline const std::string&ReplacementFor_file(void)const{return 
ReplacementFor_m_file;}inline base::type::ReplacementFor_LineNumber line(void)
const{return ReplacementFor_m_line;}inline const std::string&ReplacementFor_func
(void)const{return ReplacementFor_m_func;}inline base::type::
ReplacementFor_VerboseLevel ReplacementFor_verboseLevel(void)const{return 
ReplacementFor_m_verboseLevel;}inline ReplacementFor_Logger*
ReplacementFor_logger(void)const{return ReplacementFor_m_logger;}inline const 
base::type::ReplacementFor_string_t&message(void)const{return 
ReplacementFor_m_message;}private:Level ReplacementFor_m_level;std::string 
ReplacementFor_m_file;base::type::ReplacementFor_LineNumber 
ReplacementFor_m_line;std::string ReplacementFor_m_func;base::type::
ReplacementFor_VerboseLevel ReplacementFor_m_verboseLevel;ReplacementFor_Logger*
ReplacementFor_m_logger;base::type::ReplacementFor_string_t 
ReplacementFor_m_message;};namespace base{
#if ReplacementFor_ELPP_ASYNC_LOGGING
class ReplacementFor_AsyncLogItem{public:explicit ReplacementFor_AsyncLogItem(
const ReplacementFor_LogMessage&ReplacementFor_logMessage,const 
ReplacementFor_LogDispatchData&data,const base::type::ReplacementFor_string_t&
ReplacementFor_logLine):ReplacementFor_m_logMessage(ReplacementFor_logMessage),
ReplacementFor_m_dispatchData(data),ReplacementFor_m_logLine(
ReplacementFor_logLine){}virtual~ReplacementFor_AsyncLogItem(){}inline 
ReplacementFor_LogMessage*ReplacementFor_logMessage(void){return&
ReplacementFor_m_logMessage;}inline ReplacementFor_LogDispatchData*data(void){
return&ReplacementFor_m_dispatchData;}inline base::type::ReplacementFor_string_t
 ReplacementFor_logLine(void){return ReplacementFor_m_logLine;}private:
ReplacementFor_LogMessage ReplacementFor_m_logMessage;
ReplacementFor_LogDispatchData ReplacementFor_m_dispatchData;base::type::
ReplacementFor_string_t ReplacementFor_m_logLine;};class 
ReplacementFor_AsyncLogQueue:public base::ReplacementFor_threading::
ReplacementFor_ThreadSafe{public:virtual~ReplacementFor_AsyncLogQueue(){
ReplacementFor_ELPP_INTERNAL_INFO(((0x1382+3570-0x1a2d)+(0x2438+1486-0x1707)-
(0x1beb+5467-0x1706)),"\x7e\x41\x73\x79\x6e\x63\x4c\x6f\x67\x51\x75\x65\x75\x65"
);}inline ReplacementFor_AsyncLogItem next(void){base::ReplacementFor_threading
::ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());
ReplacementFor_AsyncLogItem result=ReplacementFor_m_queue.front();
ReplacementFor_m_queue.pop();return result;}inline void push(const 
ReplacementFor_AsyncLogItem&item){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());
ReplacementFor_m_queue.push(item);}inline void pop(void){base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
lock());ReplacementFor_m_queue.pop();}inline ReplacementFor_AsyncLogItem front(
void){base::ReplacementFor_threading::ReplacementFor_ScopedLock 
ReplacementFor_scopedLock(lock());return ReplacementFor_m_queue.front();}inline 
bool empty(void){base::ReplacementFor_threading::ReplacementFor_ScopedLock 
ReplacementFor_scopedLock(lock());return ReplacementFor_m_queue.empty();}private
:std::queue<ReplacementFor_AsyncLogItem>ReplacementFor_m_queue;};class 
ReplacementFor_IWorker{public:virtual~ReplacementFor_IWorker(){}virtual void 
ReplacementFor_start()=0;};
#endif 
class ReplacementFor_Storage:base::ReplacementFor_NoCopy,public base::
ReplacementFor_threading::ReplacementFor_ThreadSafe{public:
#if ReplacementFor_ELPP_ASYNC_LOGGING
ReplacementFor_Storage(const ReplacementFor_LogBuilderPtr&
ReplacementFor_defaultLogBuilder,base::ReplacementFor_IWorker*
ReplacementFor_asyncDispatchWorker);
#else
explicit ReplacementFor_Storage(const ReplacementFor_LogBuilderPtr&
ReplacementFor_defaultLogBuilder);
#endif  
virtual~ReplacementFor_Storage(void);inline bool 
ReplacementFor_validateEveryNCounter(const char*ReplacementFor_filename,base::
type::ReplacementFor_LineNumber ReplacementFor_lineNumber,std::size_t 
ReplacementFor_occasion){return ReplacementFor_hitCounters()->
ReplacementFor_validateEveryN(ReplacementFor_filename,ReplacementFor_lineNumber,
ReplacementFor_occasion);}inline bool ReplacementFor_validateAfterNCounter(const
 char*ReplacementFor_filename,base::type::ReplacementFor_LineNumber 
ReplacementFor_lineNumber,std::size_t n){return ReplacementFor_hitCounters()->
ReplacementFor_validateAfterN(ReplacementFor_filename,ReplacementFor_lineNumber,
n);}inline bool ReplacementFor_validateNTimesCounter(const char*
ReplacementFor_filename,base::type::ReplacementFor_LineNumber 
ReplacementFor_lineNumber,std::size_t n){return ReplacementFor_hitCounters()->
ReplacementFor_validateNTimes(ReplacementFor_filename,ReplacementFor_lineNumber,
n);}inline base::ReplacementFor_RegisteredHitCounters*ReplacementFor_hitCounters
(void)const{return ReplacementFor_m_registeredHitCounters;}inline base::
ReplacementFor_RegisteredLoggers*ReplacementFor_registeredLoggers(void)const{
return ReplacementFor_m_registeredLoggers;}inline base::ReplacementFor_VRegistry
*ReplacementFor_vRegistry(void)const{return ReplacementFor_m_vRegistry;}
#if ReplacementFor_ELPP_ASYNC_LOGGING
inline base::ReplacementFor_AsyncLogQueue*ReplacementFor_asyncLogQueue(void)
const{return ReplacementFor_m_asyncLogQueue;}
#endif  
inline const base::ReplacementFor_utils::ReplacementFor_CommandLineArgs*
ReplacementFor_commandLineArgs(void)const{return&
ReplacementFor_m_commandLineArgs;}inline void ReplacementFor_addFlag(
ReplacementFor_LoggingFlag flag){base::ReplacementFor_utils::
ReplacementFor_addFlag(flag,&ReplacementFor_m_flags);}inline void 
ReplacementFor_removeFlag(ReplacementFor_LoggingFlag flag){base::
ReplacementFor_utils::ReplacementFor_removeFlag(flag,&ReplacementFor_m_flags);}
inline bool ReplacementFor_hasFlag(ReplacementFor_LoggingFlag flag)const{return 
base::ReplacementFor_utils::ReplacementFor_hasFlag(flag,ReplacementFor_m_flags);
}inline base::type::ReplacementFor_EnumType flags(void)const{return 
ReplacementFor_m_flags;}inline void ReplacementFor_setFlags(base::type::
ReplacementFor_EnumType flags){ReplacementFor_m_flags=flags;}inline void 
ReplacementFor_setPreRollOutCallback(const ReplacementFor_PreRollOutCallback&
ReplacementFor_callback){ReplacementFor_m_preRollOutCallback=
ReplacementFor_callback;}inline void ReplacementFor_unsetPreRollOutCallback(void
){ReplacementFor_m_preRollOutCallback=base::
ReplacementFor_defaultPreRollOutCallback;}inline 
ReplacementFor_PreRollOutCallback&ReplacementFor_preRollOutCallback(void){return
 ReplacementFor_m_preRollOutCallback;}bool 
ReplacementFor_hasCustomFormatSpecifier(const char*
ReplacementFor_formatSpecifier);void ReplacementFor_installCustomFormatSpecifier
(const ReplacementFor_CustomFormatSpecifier&ReplacementFor_customFormatSpecifier
);bool ReplacementFor_uninstallCustomFormatSpecifier(const char*
ReplacementFor_formatSpecifier);const std::vector<
ReplacementFor_CustomFormatSpecifier>*ReplacementFor_customFormatSpecifiers(void
)const{return&ReplacementFor_m_customFormatSpecifiers;}base::
ReplacementFor_threading::Mutex&ReplacementFor_customFormatSpecifiersLock(){
return ReplacementFor_m_customFormatSpecifiersLock;}inline void 
ReplacementFor_setLoggingLevel(Level ReplacementFor_level){
ReplacementFor_m_loggingLevel=ReplacementFor_level;}template<typename T>inline 
bool ReplacementFor_installLogDispatchCallback(const std::string&id){return base
::ReplacementFor_utils::ReplacementFor_Utils::ReplacementFor_installCallback<T,
base::type::ReplacementFor_LogDispatchCallbackPtr>(id,&
ReplacementFor_m_logDispatchCallbacks);}template<typename T>inline void 
ReplacementFor_uninstallLogDispatchCallback(const std::string&id){base::
ReplacementFor_utils::ReplacementFor_Utils::ReplacementFor_uninstallCallback<T,
base::type::ReplacementFor_LogDispatchCallbackPtr>(id,&
ReplacementFor_m_logDispatchCallbacks);}template<typename T>inline T*
ReplacementFor_logDispatchCallback(const std::string&id){return base::
ReplacementFor_utils::ReplacementFor_Utils::ReplacementFor_callback<T,base::type
::ReplacementFor_LogDispatchCallbackPtr>(id,&
ReplacementFor_m_logDispatchCallbacks);}
#if defined(ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ELPP_FEATURE_PERFORMANCE_TRACKING)
template<typename T>inline bool 
ReplacementFor_installPerformanceTrackingCallback(const std::string&id){return 
base::ReplacementFor_utils::ReplacementFor_Utils::ReplacementFor_installCallback
<T,base::type::ReplacementFor_PerformanceTrackingCallbackPtr>(id,&
ReplacementFor_m_performanceTrackingCallbacks);}template<typename T>inline void 
ReplacementFor_uninstallPerformanceTrackingCallback(const std::string&id){base::
ReplacementFor_utils::ReplacementFor_Utils::ReplacementFor_uninstallCallback<T,
base::type::ReplacementFor_PerformanceTrackingCallbackPtr>(id,&
ReplacementFor_m_performanceTrackingCallbacks);}template<typename T>inline T*
ReplacementFor_performanceTrackingCallback(const std::string&id){return base::
ReplacementFor_utils::ReplacementFor_Utils::ReplacementFor_callback<T,base::type
::ReplacementFor_PerformanceTrackingCallbackPtr>(id,&
ReplacementFor_m_performanceTrackingCallbacks);}
#endif 
inline void ReplacementFor_setThreadName(const std::string&name){if(name.empty()
)return;base::ReplacementFor_threading::ReplacementFor_ScopedLock 
ReplacementFor_scopedLock(ReplacementFor_m_threadNamesLock);
ReplacementFor_m_threadNames[base::ReplacementFor_threading::
ReplacementFor_getCurrentThreadId()]=name;}inline std::string 
ReplacementFor_getThreadName(const std::string&ReplacementFor_threadId){base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
ReplacementFor_m_threadNamesLock);std::unordered_map<std::string,std::string>::
const_iterator ReplacementFor_it=ReplacementFor_m_threadNames.find(
ReplacementFor_threadId);if(ReplacementFor_it==ReplacementFor_m_threadNames.end(
)){return ReplacementFor_threadId;}return ReplacementFor_it->second;}private:
base::ReplacementFor_RegisteredHitCounters*
ReplacementFor_m_registeredHitCounters;base::ReplacementFor_RegisteredLoggers*
ReplacementFor_m_registeredLoggers;base::type::ReplacementFor_EnumType 
ReplacementFor_m_flags;base::ReplacementFor_VRegistry*ReplacementFor_m_vRegistry
;
#if ReplacementFor_ELPP_ASYNC_LOGGING
base::ReplacementFor_AsyncLogQueue*ReplacementFor_m_asyncLogQueue;base::
ReplacementFor_IWorker*ReplacementFor_m_asyncDispatchWorker;
#endif  
base::ReplacementFor_utils::ReplacementFor_CommandLineArgs 
ReplacementFor_m_commandLineArgs;ReplacementFor_PreRollOutCallback 
ReplacementFor_m_preRollOutCallback;std::unordered_map<std::string,base::type::
ReplacementFor_LogDispatchCallbackPtr>ReplacementFor_m_logDispatchCallbacks;std
::unordered_map<std::string,base::type::
ReplacementFor_PerformanceTrackingCallbackPtr>
ReplacementFor_m_performanceTrackingCallbacks;std::unordered_map<std::string,std
::string>ReplacementFor_m_threadNames;std::vector<
ReplacementFor_CustomFormatSpecifier>ReplacementFor_m_customFormatSpecifiers;
base::ReplacementFor_threading::Mutex 
ReplacementFor_m_customFormatSpecifiersLock;base::ReplacementFor_threading::
Mutex ReplacementFor_m_threadNamesLock;Level ReplacementFor_m_loggingLevel;
friend class ReplacementFor_el::ReplacementFor_Helpers;friend class 
ReplacementFor_el::base::ReplacementFor_DefaultLogDispatchCallback;friend class 
ReplacementFor_el::ReplacementFor_LogBuilder;friend class ReplacementFor_el::
base::ReplacementFor_MessageBuilder;friend class ReplacementFor_el::base::
ReplacementFor_Writer;friend class ReplacementFor_el::base::
ReplacementFor_PerformanceTracker;friend class ReplacementFor_el::base::
ReplacementFor_LogDispatcher;void ReplacementFor_setApplicationArguments(int 
ReplacementFor_argc,char**ReplacementFor_argv);inline void 
ReplacementFor_setApplicationArguments(int ReplacementFor_argc,const char**
ReplacementFor_argv){ReplacementFor_setApplicationArguments(ReplacementFor_argc,
const_cast<char**>(ReplacementFor_argv));}};extern ReplacementFor_ELPP_EXPORT 
base::type::ReplacementFor_StoragePointer ReplacementFor_elStorage;
#define ReplacementFor_ELPP ReplacementFor_el::base::ReplacementFor_elStorage
class ReplacementFor_DefaultLogDispatchCallback:public 
ReplacementFor_LogDispatchCallback{protected:void ReplacementFor_handle(const 
ReplacementFor_LogDispatchData*data);private:const 
ReplacementFor_LogDispatchData*ReplacementFor_m_data;void 
ReplacementFor_dispatch(base::type::ReplacementFor_string_t&&
ReplacementFor_logLine);};
#if ReplacementFor_ELPP_ASYNC_LOGGING
class ReplacementFor_AsyncLogDispatchCallback:public 
ReplacementFor_LogDispatchCallback{protected:void ReplacementFor_handle(const 
ReplacementFor_LogDispatchData*data);};class ReplacementFor_AsyncDispatchWorker:
public base::ReplacementFor_IWorker,public base::ReplacementFor_threading::
ReplacementFor_ThreadSafe{public:ReplacementFor_AsyncDispatchWorker();virtual~
ReplacementFor_AsyncDispatchWorker();bool ReplacementFor_clean(void);void 
ReplacementFor_emptyQueue(void);virtual void ReplacementFor_start(void);void 
ReplacementFor_handle(ReplacementFor_AsyncLogItem*ReplacementFor_logItem);void 
ReplacementFor_run(void);void ReplacementFor_setContinueRunning(bool value){base
::ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
ReplacementFor_m_continueRunningLock);ReplacementFor_m_continueRunning=value;}
bool ReplacementFor_continueRunning(void)const{return 
ReplacementFor_m_continueRunning;}private:std::condition_variable 
ReplacementFor_cv;bool ReplacementFor_m_continueRunning;base::
ReplacementFor_threading::Mutex ReplacementFor_m_continueRunningLock;};
#endif  
}namespace base{class ReplacementFor_DefaultLogBuilder:public 
ReplacementFor_LogBuilder{public:base::type::ReplacementFor_string_t 
ReplacementFor_build(const ReplacementFor_LogMessage*ReplacementFor_logMessage,
bool ReplacementFor_appendNewLine)const;};class ReplacementFor_LogDispatcher:
base::ReplacementFor_NoCopy{public:ReplacementFor_LogDispatcher(bool 
ReplacementFor_proceed,ReplacementFor_LogMessage*ReplacementFor_logMessage,base
::ReplacementFor_DispatchAction ReplacementFor_dispatchAction):
ReplacementFor_m_proceed(ReplacementFor_proceed),ReplacementFor_m_logMessage(
ReplacementFor_logMessage),ReplacementFor_m_dispatchAction(std::move(
ReplacementFor_dispatchAction)){}void ReplacementFor_dispatch(void);private:bool
 ReplacementFor_m_proceed;ReplacementFor_LogMessage*ReplacementFor_m_logMessage;
base::ReplacementFor_DispatchAction ReplacementFor_m_dispatchAction;};
#if defined(ReplacementFor_ELPP_STL_LOGGING)
namespace ReplacementFor_workarounds{template<typename T,typename Container>
class ReplacementFor_IterableContainer{public:typedef typename Container::
iterator iterator;typedef typename Container::const_iterator const_iterator;
ReplacementFor_IterableContainer(void){}virtual~ReplacementFor_IterableContainer
(void){}iterator begin(void){return ReplacementFor_getContainer().begin();}
iterator end(void){return ReplacementFor_getContainer().end();}private:virtual 
Container&ReplacementFor_getContainer(void)=0;};template<typename T,typename 
Container=std::vector<T>,typename ReplacementFor_Comparator=std::less<typename 
Container::value_type>>class ReplacementFor_IterablePriorityQueue:public 
ReplacementFor_IterableContainer<T,Container>,public std::priority_queue<T,
Container,ReplacementFor_Comparator>{public:ReplacementFor_IterablePriorityQueue
(std::priority_queue<T,Container,ReplacementFor_Comparator>ReplacementFor_queue_
){std::size_t ReplacementFor_count_=((0x24e2+402-0x1495)+(0xea3+5775-0x17ea)-
7975);while(++ReplacementFor_count_<base::ReplacementFor_consts::
ReplacementFor_kMaxLogPerContainer&&!ReplacementFor_queue_.empty()){this->push(
ReplacementFor_queue_.top());ReplacementFor_queue_.pop();}}private:inline 
Container&ReplacementFor_getContainer(void){return this->c;}};template<typename 
T,typename Container=std::deque<T>>class ReplacementFor_IterableQueue:public 
ReplacementFor_IterableContainer<T,Container>,public std::queue<T,Container>{
public:ReplacementFor_IterableQueue(std::queue<T,Container>ReplacementFor_queue_
){std::size_t ReplacementFor_count_=(4368+(0x1078+2747-0x18dd)-
(0x20d9+3217-0x1a04));while(++ReplacementFor_count_<base::ReplacementFor_consts
::ReplacementFor_kMaxLogPerContainer&&!ReplacementFor_queue_.empty()){this->push
(ReplacementFor_queue_.front());ReplacementFor_queue_.pop();}}private:inline 
Container&ReplacementFor_getContainer(void){return this->c;}};template<typename 
T,typename Container=std::deque<T>>class ReplacementFor_IterableStack:public 
ReplacementFor_IterableContainer<T,Container>,public std::stack<T,Container>{
public:ReplacementFor_IterableStack(std::stack<T,Container>ReplacementFor_stack_
){std::size_t ReplacementFor_count_=((0x1270+2443-0x1489)+(0x26c1+1862-0x1e07)-
(0x187c+1717-0x7bf));while(++ReplacementFor_count_<base::ReplacementFor_consts::
ReplacementFor_kMaxLogPerContainer&&!ReplacementFor_stack_.empty()){this->push(
ReplacementFor_stack_.top());ReplacementFor_stack_.pop();}}private:inline 
Container&ReplacementFor_getContainer(void){return this->c;}};}
#endif  
class ReplacementFor_MessageBuilder{public:ReplacementFor_MessageBuilder(void):
ReplacementFor_m_logger(nullptr),ReplacementFor_m_containerLogSeperator(
ReplacementFor_ELPP_LITERAL("")){}void ReplacementFor_initialize(
ReplacementFor_Logger*ReplacementFor_logger);
#  define ReplacementFor_ELPP_SIMPLE_LOG(ReplacementFor_LOG_TYPE)\
ReplacementFor_MessageBuilder& operator<<(ReplacementFor_LOG_TYPE msg) {\
ReplacementFor_m_logger->ReplacementFor_stream() << msg;\
if (ReplacementFor_ELPP->ReplacementFor_hasFlag(ReplacementFor_LoggingFlag::\
ReplacementFor_AutoSpacing)) {\
ReplacementFor_m_logger->ReplacementFor_stream() << "\x20";\
}\
return *this;\
}
inline ReplacementFor_MessageBuilder&operator<<(const std::string&msg){return 
operator<<(msg.c_str());}ReplacementFor_ELPP_SIMPLE_LOG(char)
ReplacementFor_ELPP_SIMPLE_LOG(bool)ReplacementFor_ELPP_SIMPLE_LOG(signed short)
ReplacementFor_ELPP_SIMPLE_LOG(unsigned short)ReplacementFor_ELPP_SIMPLE_LOG(
signed int)ReplacementFor_ELPP_SIMPLE_LOG(unsigned int)
ReplacementFor_ELPP_SIMPLE_LOG(signed long)ReplacementFor_ELPP_SIMPLE_LOG(
unsigned long)ReplacementFor_ELPP_SIMPLE_LOG(float)
ReplacementFor_ELPP_SIMPLE_LOG(double)ReplacementFor_ELPP_SIMPLE_LOG(char*)
ReplacementFor_ELPP_SIMPLE_LOG(const char*)ReplacementFor_ELPP_SIMPLE_LOG(const 
void*)ReplacementFor_ELPP_SIMPLE_LOG(long double)inline 
ReplacementFor_MessageBuilder&operator<<(const std::wstring&msg){return operator
<<(msg.c_str());}ReplacementFor_MessageBuilder&operator<<(const wchar_t*msg);
inline ReplacementFor_MessageBuilder&operator<<(std::ostream&(*
ReplacementFor_OStreamMani)(std::ostream&)){ReplacementFor_m_logger->
ReplacementFor_stream()<<ReplacementFor_OStreamMani;return*this;}
#define ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_ONE_ARG(ReplacementFor_temp)\
                                                    \
template <typename T>\
                                                                            \
inline ReplacementFor_MessageBuilder& operator<<(const ReplacementFor_temp<T>& \
ReplacementFor_template_inst) {                                \
return ReplacementFor_writeIterator(ReplacementFor_template_inst.begin(), \
ReplacementFor_template_inst.end(), ReplacementFor_template_inst.size());      \
}
#define ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_TWO_ARG(ReplacementFor_temp)\
                                                    \
template <typename ReplacementFor_T1, typename ReplacementFor_T2>\
                                                              \
inline ReplacementFor_MessageBuilder& operator<<(const ReplacementFor_temp<\
ReplacementFor_T1, ReplacementFor_T2>& ReplacementFor_template_inst) {\
                           \
return ReplacementFor_writeIterator(ReplacementFor_template_inst.begin(), \
ReplacementFor_template_inst.end(), ReplacementFor_template_inst.size());      \
}
#define ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_THREE_ARG(ReplacementFor_temp\
)                                                  \
template <typename ReplacementFor_T1, typename ReplacementFor_T2, typename \
ReplacementFor_T3>                                                 \
inline ReplacementFor_MessageBuilder& operator<<(const ReplacementFor_temp<\
ReplacementFor_T1, ReplacementFor_T2, ReplacementFor_T3>& \
ReplacementFor_template_inst) {                       \
return ReplacementFor_writeIterator(ReplacementFor_template_inst.begin(), \
ReplacementFor_template_inst.end(), ReplacementFor_template_inst.size());      \
}
#define ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FOUR_ARG(ReplacementFor_temp)\
                                                   \
template <typename ReplacementFor_T1, typename ReplacementFor_T2, typename \
ReplacementFor_T3, typename ReplacementFor_T4>\
                                    \
inline ReplacementFor_MessageBuilder& operator<<(const ReplacementFor_temp<\
ReplacementFor_T1, ReplacementFor_T2, ReplacementFor_T3, ReplacementFor_T4>& \
ReplacementFor_template_inst) {                   \
return ReplacementFor_writeIterator(ReplacementFor_template_inst.begin(), \
ReplacementFor_template_inst.end(), ReplacementFor_template_inst.size());      \
}
#define ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FIVE_ARG(ReplacementFor_temp)\
                                                   \
template <typename ReplacementFor_T1, typename ReplacementFor_T2, typename \
ReplacementFor_T3, typename ReplacementFor_T4, typename ReplacementFor_T5>\
                       \
inline ReplacementFor_MessageBuilder& operator<<(const ReplacementFor_temp<\
ReplacementFor_T1, ReplacementFor_T2, ReplacementFor_T3, ReplacementFor_T4, \
ReplacementFor_T5>& ReplacementFor_template_inst) {               \
return ReplacementFor_writeIterator(ReplacementFor_template_inst.begin(), \
ReplacementFor_template_inst.end(), ReplacementFor_template_inst.size());      \
}
#if defined(ReplacementFor_ELPP_STL_LOGGING)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_TWO_ARG(std::vector)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_TWO_ARG(std::list)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_TWO_ARG(std::deque)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_THREE_ARG(std::set)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_THREE_ARG(std::multiset)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FOUR_ARG(std::map)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FOUR_ARG(std::multimap)template<class
 T,class Container>inline ReplacementFor_MessageBuilder&operator<<(const std::
queue<T,Container>&ReplacementFor_queue_){base::ReplacementFor_workarounds::
ReplacementFor_IterableQueue<T,Container>ReplacementFor_iterableQueue_=
static_cast<base::ReplacementFor_workarounds::ReplacementFor_IterableQueue<T,
Container> >(ReplacementFor_queue_);return ReplacementFor_writeIterator(
ReplacementFor_iterableQueue_.begin(),ReplacementFor_iterableQueue_.end(),
ReplacementFor_iterableQueue_.size());}template<class T,class Container>inline 
ReplacementFor_MessageBuilder&operator<<(const std::stack<T,Container>&
ReplacementFor_stack_){base::ReplacementFor_workarounds::
ReplacementFor_IterableStack<T,Container>ReplacementFor_iterableStack_=
static_cast<base::ReplacementFor_workarounds::ReplacementFor_IterableStack<T,
Container> >(ReplacementFor_stack_);return ReplacementFor_writeIterator(
ReplacementFor_iterableStack_.begin(),ReplacementFor_iterableStack_.end(),
ReplacementFor_iterableStack_.size());}template<class T,class Container,class 
ReplacementFor_Comparator>inline ReplacementFor_MessageBuilder&operator<<(const 
std::priority_queue<T,Container,ReplacementFor_Comparator>&
ReplacementFor_priorityQueue_){base::ReplacementFor_workarounds::
ReplacementFor_IterablePriorityQueue<T,Container,ReplacementFor_Comparator>
ReplacementFor_iterablePriorityQueue_=static_cast<base::
ReplacementFor_workarounds::ReplacementFor_IterablePriorityQueue<T,Container,
ReplacementFor_Comparator> >(ReplacementFor_priorityQueue_);return 
ReplacementFor_writeIterator(ReplacementFor_iterablePriorityQueue_.begin(),
ReplacementFor_iterablePriorityQueue_.end(),
ReplacementFor_iterablePriorityQueue_.size());}template<class First,class Second
>ReplacementFor_MessageBuilder&operator<<(const std::pair<First,Second>&
ReplacementFor_pair_){ReplacementFor_m_logger->ReplacementFor_stream()<<
ReplacementFor_ELPP_LITERAL("\x28");operator<<(static_cast<First>(
ReplacementFor_pair_.first));ReplacementFor_m_logger->ReplacementFor_stream()<<
ReplacementFor_ELPP_LITERAL("\x2c\x20");operator<<(static_cast<Second>(
ReplacementFor_pair_.second));ReplacementFor_m_logger->ReplacementFor_stream()<<
ReplacementFor_ELPP_LITERAL("\x29");return*this;}template<std::size_t Size>
ReplacementFor_MessageBuilder&operator<<(const std::bitset<Size>&
ReplacementFor_bitset_){ReplacementFor_m_logger->ReplacementFor_stream()<<
ReplacementFor_ELPP_LITERAL("\x5b");operator<<(ReplacementFor_bitset_.to_string(
));ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL
("\x5d");return*this;}
#  if defined(ReplacementFor_ELPP_LOG_STD_ARRAY)
template<class T,std::size_t Size>inline ReplacementFor_MessageBuilder&operator
<<(const std::array<T,Size>&array){return ReplacementFor_writeIterator(array.
begin(),array.end(),array.size());}
#  endif  
#  if defined(ReplacementFor_ELPP_LOG_UNORDERED_MAP)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FIVE_ARG(std::unordered_map)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FIVE_ARG(std::unordered_multimap)
#  endif  
#  if defined(ReplacementFor_ELPP_LOG_UNORDERED_SET)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FOUR_ARG(std::unordered_set)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FOUR_ARG(std::unordered_multiset)
#  endif  
#endif  
#if defined(ReplacementFor_ELPP_QT_LOGGING)
inline ReplacementFor_MessageBuilder&operator<<(const ReplacementFor_QString&msg
){
#  if defined(ReplacementFor_ELPP_UNICODE)
ReplacementFor_m_logger->ReplacementFor_stream()<<msg.
ReplacementFor_toStdWString();
#  else
ReplacementFor_m_logger->ReplacementFor_stream()<<msg.ReplacementFor_toStdString
();
#  endif  
return*this;}inline ReplacementFor_MessageBuilder&operator<<(const 
ReplacementFor_QByteArray&msg){return operator<<(ReplacementFor_QString(msg));}
inline ReplacementFor_MessageBuilder&operator<<(const ReplacementFor_QStringRef&
msg){return operator<<(msg.ReplacementFor_toString());}inline 
ReplacementFor_MessageBuilder&operator<<(ReplacementFor_qint64 msg){
#  if defined(ReplacementFor_ELPP_UNICODE)
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_QString::number
(msg).ReplacementFor_toStdWString();
#  else
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_QString::number
(msg).ReplacementFor_toStdString();
#  endif  
return*this;}inline ReplacementFor_MessageBuilder&operator<<(
ReplacementFor_quint64 msg){
#  if defined(ReplacementFor_ELPP_UNICODE)
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_QString::number
(msg).ReplacementFor_toStdWString();
#  else
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_QString::number
(msg).ReplacementFor_toStdString();
#  endif  
return*this;}inline ReplacementFor_MessageBuilder&operator<<(
ReplacementFor_QChar msg){ReplacementFor_m_logger->ReplacementFor_stream()<<msg.
ReplacementFor_toLatin1();return*this;}inline ReplacementFor_MessageBuilder&
operator<<(const ReplacementFor_QLatin1String&msg){ReplacementFor_m_logger->
ReplacementFor_stream()<<msg.ReplacementFor_latin1();return*this;}
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_ONE_ARG(ReplacementFor_QList)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_ONE_ARG(ReplacementFor_QVector)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_ONE_ARG(ReplacementFor_QQueue)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_ONE_ARG(ReplacementFor_QSet)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_ONE_ARG(ReplacementFor_QLinkedList)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_ONE_ARG(ReplacementFor_QStack)
template<typename First,typename Second>ReplacementFor_MessageBuilder&operator<<
(const ReplacementFor_QPair<First,Second>&ReplacementFor_pair_){
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL(
"\x28");operator<<(static_cast<First>(ReplacementFor_pair_.first));
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL(
"\x2c\x20");operator<<(static_cast<Second>(ReplacementFor_pair_.second));
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL(
"\x29");return*this;}template<typename K,typename ReplacementFor_V>
ReplacementFor_MessageBuilder&operator<<(const ReplacementFor_QMap<K,
ReplacementFor_V>&ReplacementFor_map_){ReplacementFor_m_logger->
ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL("\x5b");
ReplacementFor_QList<K>ReplacementFor_keys=ReplacementFor_map_.
ReplacementFor_keys();typename ReplacementFor_QList<K>::const_iterator begin=
ReplacementFor_keys.begin();typename ReplacementFor_QList<K>::const_iterator end
=ReplacementFor_keys.end();int ReplacementFor_max_=static_cast<int>(base::
ReplacementFor_consts::ReplacementFor_kMaxLogPerContainer);for(int 
ReplacementFor_index_=((0x1b6b+4910-0x25a9)+(0x261c+2349-0x2199)-
(0x1c12+7955-0x2485));begin!=end&&ReplacementFor_index_<ReplacementFor_max_;++
ReplacementFor_index_,++begin){ReplacementFor_m_logger->ReplacementFor_stream()
<<ReplacementFor_ELPP_LITERAL("\x28");operator<<(static_cast<K>(*begin));
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL(
"\x2c\x20");operator<<(static_cast<ReplacementFor_V>(ReplacementFor_map_.value(*
begin)));ReplacementFor_m_logger->ReplacementFor_stream()<<
ReplacementFor_ELPP_LITERAL("\x29");ReplacementFor_m_logger->
ReplacementFor_stream()<<((ReplacementFor_index_<ReplacementFor_keys.size()-(
(0x20e6+3653-0x1d97)+(0x1839+8225-0x25b4)-9273))?
ReplacementFor_m_containerLogSeperator:ReplacementFor_ELPP_LITERAL(""));}if(
begin!=end){ReplacementFor_m_logger->ReplacementFor_stream()<<
ReplacementFor_ELPP_LITERAL("\x2e\x2e\x2e");}ReplacementFor_m_logger->
ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL("\x5d");return*this;}
template<typename K,typename ReplacementFor_V>inline 
ReplacementFor_MessageBuilder&operator<<(const ReplacementFor_QMultiMap<K,
ReplacementFor_V>&ReplacementFor_map_){operator<<(static_cast<
ReplacementFor_QMap<K,ReplacementFor_V>>(ReplacementFor_map_));return*this;}
template<typename K,typename ReplacementFor_V>ReplacementFor_MessageBuilder&
operator<<(const ReplacementFor_QHash<K,ReplacementFor_V>&ReplacementFor_hash_){
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL(
"\x5b");ReplacementFor_QList<K>ReplacementFor_keys=ReplacementFor_hash_.
ReplacementFor_keys();typename ReplacementFor_QList<K>::const_iterator begin=
ReplacementFor_keys.begin();typename ReplacementFor_QList<K>::const_iterator end
=ReplacementFor_keys.end();int ReplacementFor_max_=static_cast<int>(base::
ReplacementFor_consts::ReplacementFor_kMaxLogPerContainer);for(int 
ReplacementFor_index_=((0x2587+1491-0x12ff)+(0x1f57+1983-0x1871)-9984);begin!=
end&&ReplacementFor_index_<ReplacementFor_max_;++ReplacementFor_index_,++begin){
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL(
"\x28");operator<<(static_cast<K>(*begin));ReplacementFor_m_logger->
ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL("\x2c\x20");operator<<(
static_cast<ReplacementFor_V>(ReplacementFor_hash_.value(*begin)));
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL(
"\x29");ReplacementFor_m_logger->ReplacementFor_stream()<<((
ReplacementFor_index_<ReplacementFor_keys.size()-((0x1746+1819-0x1b3b)+
(0x1e03+4278-0x20db)-(0x12a6+1117-0x600)))?
ReplacementFor_m_containerLogSeperator:ReplacementFor_ELPP_LITERAL(""));}if(
begin!=end){ReplacementFor_m_logger->ReplacementFor_stream()<<
ReplacementFor_ELPP_LITERAL("\x2e\x2e\x2e");}ReplacementFor_m_logger->
ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL("\x5d");return*this;}
template<typename K,typename ReplacementFor_V>inline 
ReplacementFor_MessageBuilder&operator<<(const ReplacementFor_QMultiHash<K,
ReplacementFor_V>&ReplacementFor_multiHash_){operator<<(static_cast<
ReplacementFor_QHash<K,ReplacementFor_V>>(ReplacementFor_multiHash_));return*
this;}
#endif  
#if defined(ReplacementFor_ELPP_BOOST_LOGGING)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_TWO_ARG(ReplacementFor_boost::
container::vector)ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_TWO_ARG(
ReplacementFor_boost::container::ReplacementFor_stable_vector)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_TWO_ARG(ReplacementFor_boost::
container::list)ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_TWO_ARG(
ReplacementFor_boost::container::deque)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FOUR_ARG(ReplacementFor_boost::
container::map)ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FOUR_ARG(
ReplacementFor_boost::container::ReplacementFor_flat_map)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_THREE_ARG(ReplacementFor_boost::
container::set)ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_THREE_ARG(
ReplacementFor_boost::container::ReplacementFor_flat_set)
#endif  
#define ReplacementFor_MAKE_CONTAINERELPP_FRIENDLY(ReplacementFor_ContainerType,\
 ReplacementFor_SizeMethod, ReplacementFor_ElementInstance) \
ReplacementFor_el::base::type::ReplacementFor_ostream_t& operator<<(\
ReplacementFor_el::base::type::ReplacementFor_ostream_t& ReplacementFor_ss, \
const ReplacementFor_ContainerType& container) {\
const ReplacementFor_el::base::type::ReplacementFor_char_t* ReplacementFor_sep =\
 ReplacementFor_ELPP->ReplacementFor_hasFlag(ReplacementFor_el::\
ReplacementFor_LoggingFlag::ReplacementFor_NewLineForContainer) ? \
ReplacementFor_ELPP_LITERAL("\n" "\x20\x20\x20\x20") : \
ReplacementFor_ELPP_LITERAL("\x2c\x20");\
ReplacementFor_ContainerType::const_iterator ReplacementFor_elem = container.\
begin();\
ReplacementFor_ContainerType::const_iterator ReplacementFor_endElem = container.\
end();\
std::size_t ReplacementFor_size_ = container.ReplacementFor_SizeMethod; \
ReplacementFor_ss << ReplacementFor_ELPP_LITERAL("\x5b");\
for (std::size_t i = ((0x1dd9+4010-0x259b)+6486-8510); ReplacementFor_elem != \
ReplacementFor_endElem && i < ReplacementFor_el::base::ReplacementFor_consts::\
ReplacementFor_kMaxLogPerContainer; ++i, ++ReplacementFor_elem) { \
ReplacementFor_ss << ReplacementFor_ElementInstance;\
ReplacementFor_ss << ((i < ReplacementFor_size_ - ((0x1d31+2412-0x1a02)+\
(0x13aa+4530-0x2071)-(0x162f+3868-0x13c6))) ? \
ReplacementFor_sep : ReplacementFor_ELPP_LITERAL(""));\
}\
if (ReplacementFor_elem != ReplacementFor_endElem) {\
ReplacementFor_ss << ReplacementFor_ELPP_LITERAL("\x2e\x2e\x2e");\
}\
ReplacementFor_ss << ReplacementFor_ELPP_LITERAL("\x5d");\
return ReplacementFor_ss;\
}
#if defined(ReplacementFor_ELPP_WXWIDGETS_LOGGING)
ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_ONE_ARG(ReplacementFor_wxVector)
#  define ReplacementFor_ELPP_WX_PTR_ENABLED(ReplacementFor_ContainerType) \
ReplacementFor_MAKE_CONTAINERELPP_FRIENDLY(ReplacementFor_ContainerType, size(),\
 *(*ReplacementFor_elem))
#  define ReplacementFor_ELPP_WX_ENABLED(ReplacementFor_ContainerType) \
ReplacementFor_MAKE_CONTAINERELPP_FRIENDLY(ReplacementFor_ContainerType, size(),\
 (*ReplacementFor_elem))
#  define ReplacementFor_ELPP_WX_HASH_MAP_ENABLED(ReplacementFor_ContainerType) \
ReplacementFor_MAKE_CONTAINERELPP_FRIENDLY(ReplacementFor_ContainerType, size(),\
 \
ReplacementFor_ELPP_LITERAL("\x28") << ReplacementFor_elem->first << \
ReplacementFor_ELPP_LITERAL("\x2c\x20") << ReplacementFor_elem->second << \
ReplacementFor_ELPP_LITERAL("\x29")
#else
#  define ReplacementFor_ELPP_WX_PTR_ENABLED(ReplacementFor_ContainerType)
#  define ReplacementFor_ELPP_WX_ENABLED(ReplacementFor_ContainerType)
#  define ReplacementFor_ELPP_WX_HASH_MAP_ENABLED(ReplacementFor_ContainerType)
#endif  
template<class Class>ReplacementFor_ELPP_SIMPLE_LOG(const Class&)
#undef ReplacementFor_ELPP_SIMPLE_LOG
#undef ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_ONE_ARG
#undef ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_TWO_ARG
#undef ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_THREE_ARG
#undef ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FOUR_ARG
#undef ReplacementFor_ELPP_ITERATOR_CONTAINER_LOG_FIVE_ARG
private:ReplacementFor_Logger*ReplacementFor_m_logger;const base::type::
ReplacementFor_char_t*ReplacementFor_m_containerLogSeperator;template<class 
Iterator>ReplacementFor_MessageBuilder&ReplacementFor_writeIterator(Iterator 
ReplacementFor_begin_,Iterator ReplacementFor_end_,std::size_t 
ReplacementFor_size_){ReplacementFor_m_logger->ReplacementFor_stream()<<
ReplacementFor_ELPP_LITERAL("\x5b");for(std::size_t i=((0x1ddd+1772-0x2184)+
(0xf51+242-0xad0)-(0xc9f+7617-0x21a8));ReplacementFor_begin_!=
ReplacementFor_end_&&i<base::ReplacementFor_consts::
ReplacementFor_kMaxLogPerContainer;++i,++ReplacementFor_begin_){operator<<(*
ReplacementFor_begin_);ReplacementFor_m_logger->ReplacementFor_stream()<<((i<
ReplacementFor_size_-((0xc70+630-0x574)+6768-(0x263a+1380-0x7bd)))?
ReplacementFor_m_containerLogSeperator:ReplacementFor_ELPP_LITERAL(""));}if(
ReplacementFor_begin_!=ReplacementFor_end_){ReplacementFor_m_logger->
ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL("\x2e\x2e\x2e");}
ReplacementFor_m_logger->ReplacementFor_stream()<<ReplacementFor_ELPP_LITERAL(
"\x5d");if(ReplacementFor_ELPP->ReplacementFor_hasFlag(
ReplacementFor_LoggingFlag::ReplacementFor_AutoSpacing)){ReplacementFor_m_logger
->ReplacementFor_stream()<<"\x20";}return*this;}};class 
ReplacementFor_NullWriter:base::ReplacementFor_NoCopy{public:
ReplacementFor_NullWriter(void){}inline ReplacementFor_NullWriter&operator<<(std
::ostream&(*)(std::ostream&)){return*this;}template<typename T>inline 
ReplacementFor_NullWriter&operator<<(const T&){return*this;}inline operator bool
(){return true;}};class ReplacementFor_Writer:base::ReplacementFor_NoCopy{public
:ReplacementFor_Writer(Level ReplacementFor_level,const char*ReplacementFor_file
,base::type::ReplacementFor_LineNumber line,const char*ReplacementFor_func,base
::ReplacementFor_DispatchAction ReplacementFor_dispatchAction=base::
ReplacementFor_DispatchAction::ReplacementFor_NormalLog,base::type::
ReplacementFor_VerboseLevel ReplacementFor_verboseLevel=((0xd89+7620-0x1ff5)+
5631-8535)):ReplacementFor_m_msg(nullptr),ReplacementFor_m_level(
ReplacementFor_level),ReplacementFor_m_file(ReplacementFor_file),
ReplacementFor_m_line(line),ReplacementFor_m_func(ReplacementFor_func),
ReplacementFor_m_verboseLevel(ReplacementFor_verboseLevel),
ReplacementFor_m_logger(nullptr),ReplacementFor_m_proceed(false),
ReplacementFor_m_dispatchAction(ReplacementFor_dispatchAction){}
ReplacementFor_Writer(ReplacementFor_LogMessage*msg,base::
ReplacementFor_DispatchAction ReplacementFor_dispatchAction=base::
ReplacementFor_DispatchAction::ReplacementFor_NormalLog):ReplacementFor_m_msg(
msg),ReplacementFor_m_level(msg!=nullptr?msg->ReplacementFor_level():Level::
Unknown),ReplacementFor_m_line(((0x1317+4244-0x1a09)+4418-6884)),
ReplacementFor_m_logger(nullptr),ReplacementFor_m_proceed(false),
ReplacementFor_m_dispatchAction(ReplacementFor_dispatchAction){}virtual~
ReplacementFor_Writer(void){ReplacementFor_processDispatch();}template<typename 
T>inline ReplacementFor_Writer&operator<<(const T&log){
#if ReplacementFor_ELPP_LOGGING_ENABLED
if(ReplacementFor_m_proceed){ReplacementFor_m_messageBuilder<<log;}
#endif  
return*this;}inline ReplacementFor_Writer&operator<<(std::ostream&(*log)(std::
ostream&)){
#if ReplacementFor_ELPP_LOGGING_ENABLED
if(ReplacementFor_m_proceed){ReplacementFor_m_messageBuilder<<log;}
#endif  
return*this;}inline operator bool(){return true;}ReplacementFor_Writer&construct
(ReplacementFor_Logger*ReplacementFor_logger,bool ReplacementFor_needLock=true);
ReplacementFor_Writer&construct(int count,const char*ReplacementFor_loggerIds,
...);protected:ReplacementFor_LogMessage*ReplacementFor_m_msg;Level 
ReplacementFor_m_level;const char*ReplacementFor_m_file;const base::type::
ReplacementFor_LineNumber ReplacementFor_m_line;const char*ReplacementFor_m_func
;base::type::ReplacementFor_VerboseLevel ReplacementFor_m_verboseLevel;
ReplacementFor_Logger*ReplacementFor_m_logger;bool ReplacementFor_m_proceed;base
::ReplacementFor_MessageBuilder ReplacementFor_m_messageBuilder;base::
ReplacementFor_DispatchAction ReplacementFor_m_dispatchAction;std::vector<std::
string>ReplacementFor_m_loggerIds;friend class ReplacementFor_el::
ReplacementFor_Helpers;void ReplacementFor_initializeLogger(const std::string&
ReplacementFor_loggerId,bool ReplacementFor_lookup=true,bool 
ReplacementFor_needLock=true);void ReplacementFor_processDispatch();void 
ReplacementFor_triggerDispatch(void);};class ReplacementFor_PErrorWriter:public 
base::ReplacementFor_Writer{public:ReplacementFor_PErrorWriter(Level 
ReplacementFor_level,const char*ReplacementFor_file,base::type::
ReplacementFor_LineNumber line,const char*ReplacementFor_func,base::
ReplacementFor_DispatchAction ReplacementFor_dispatchAction=base::
ReplacementFor_DispatchAction::ReplacementFor_NormalLog,base::type::
ReplacementFor_VerboseLevel ReplacementFor_verboseLevel=((0x852+2450-0x11dc)+
3934-(0xf73+6009-0x1786))):base::ReplacementFor_Writer(ReplacementFor_level,
ReplacementFor_file,line,ReplacementFor_func,ReplacementFor_dispatchAction,
ReplacementFor_verboseLevel){}virtual~ReplacementFor_PErrorWriter(void);};}
#if ReplacementFor_ELPP_VARIADIC_TEMPLATES_SUPPORTED
template<typename T,typename...ReplacementFor_Args>void ReplacementFor_Logger::
ReplacementFor_log_(Level ReplacementFor_level,int ReplacementFor_vlevel,const 
char*s,const T&value,const ReplacementFor_Args&...ReplacementFor_args){base::
ReplacementFor_MessageBuilder b;b.ReplacementFor_initialize(this);while(*s){if(*
s==base::ReplacementFor_consts::ReplacementFor_kFormatSpecifierChar){if(*(s+(
(0x234c+582-0x2362)+5715-6274))==base::ReplacementFor_consts::
ReplacementFor_kFormatSpecifierChar){++s;}else{if(*(s+((0x116a+3545-0x1a93)+
(0x818+603-0x4a6)-(0x10cf+978-0xa25)))==base::ReplacementFor_consts::
ReplacementFor_kFormatSpecifierCharValue){++s;b<<value;ReplacementFor_log_(
ReplacementFor_level,ReplacementFor_vlevel,++s,ReplacementFor_args...);return;}}
}b<<*s++;}ReplacementFor_ELPP_INTERNAL_ERROR(
"\x54\x6f\x6f\x20\x6d\x61\x6e\x79\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x73\x20\x70\x72\x6f\x76\x69\x64\x65\x64\x2e\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x68\x61\x6e\x64\x6c\x65\x2e\x20\x50\x6c\x65\x61\x73\x65\x20\x70\x72\x6f\x76\x69\x64\x65\x20\x6d\x6f\x72\x65\x20\x66\x6f\x72\x6d\x61\x74\x20\x73\x70\x65\x63\x69\x66\x69\x65\x72\x73"
,false);}template<typename T>void ReplacementFor_Logger::ReplacementFor_log_(
Level ReplacementFor_level,int ReplacementFor_vlevel,const T&log){if(
ReplacementFor_level==Level::ReplacementFor_Verbose){if(ReplacementFor_ELPP->
ReplacementFor_vRegistry()->ReplacementFor_allowed(ReplacementFor_vlevel,
__FILE__)){base::ReplacementFor_Writer(Level::ReplacementFor_Verbose,
"\x46\x49\x4c\x45",((0x2496+5072-0x1cfc)+(0x1046+104-0x553)-9925),
"\x46\x55\x4e\x43\x54\x49\x4f\x4e",base::ReplacementFor_DispatchAction::
ReplacementFor_NormalLog,ReplacementFor_vlevel).construct(this,false)<<log;}else
{ReplacementFor_stream().str(ReplacementFor_ELPP_LITERAL(""));
ReplacementFor_releaseLock();}}else{base::ReplacementFor_Writer(
ReplacementFor_level,"\x46\x49\x4c\x45",(1639+4076-(0x1cf0+1716-0xd51)),
"\x46\x55\x4e\x43\x54\x49\x4f\x4e").construct(this,false)<<log;}}template<
typename T,typename...ReplacementFor_Args>inline void ReplacementFor_Logger::log
(Level ReplacementFor_level,const char*s,const T&value,const ReplacementFor_Args
&...ReplacementFor_args){ReplacementFor_acquireLock();ReplacementFor_log_(
ReplacementFor_level,((0x1860+2495-0xacc)+(0x1b97+3393-0x1bf9)-9266),s,value,
ReplacementFor_args...);}template<typename T>inline void ReplacementFor_Logger::
log(Level ReplacementFor_level,const T&log){ReplacementFor_acquireLock();
ReplacementFor_log_(ReplacementFor_level,((0x113c+5306-0x14c1)+
(0x199+5327-0x1555)-4680),log);}
#  if ReplacementFor_ELPP_VERBOSE_LOG
template<typename T,typename...ReplacementFor_Args>inline void 
ReplacementFor_Logger::ReplacementFor_verbose(int ReplacementFor_vlevel,const 
char*s,const T&value,const ReplacementFor_Args&...ReplacementFor_args){
ReplacementFor_acquireLock();ReplacementFor_log_(ReplacementFor_el::Level::
ReplacementFor_Verbose,ReplacementFor_vlevel,s,value,ReplacementFor_args...);}
template<typename T>inline void ReplacementFor_Logger::ReplacementFor_verbose(
int ReplacementFor_vlevel,const T&log){ReplacementFor_acquireLock();
ReplacementFor_log_(ReplacementFor_el::Level::ReplacementFor_Verbose,
ReplacementFor_vlevel,log);}
#  else
template<typename T,typename...ReplacementFor_Args>inline void 
ReplacementFor_Logger::ReplacementFor_verbose(int,const char*,const T&,const 
ReplacementFor_Args&...){return;}template<typename T>inline void 
ReplacementFor_Logger::ReplacementFor_verbose(int,const T&){return;}
#  endif  
#  define ReplacementFor_LOGGER_LEVEL_WRITERS(ReplacementFor_FUNCTION_NAME, \
ReplacementFor_LOG_LEVEL)\
template <typename T, typename... ReplacementFor_Args>\
inline void ReplacementFor_Logger::ReplacementFor_FUNCTION_NAME(const char* s, \
const T& value, const ReplacementFor_Args&... ReplacementFor_args) {\
log(ReplacementFor_LOG_LEVEL, s, value, ReplacementFor_args...);\
}\
template <typename T>\
inline void ReplacementFor_Logger::ReplacementFor_FUNCTION_NAME(const T& value) \
{\
log(ReplacementFor_LOG_LEVEL, value);\
}
#  define ReplacementFor_LOGGER_LEVEL_WRITERS_DISABLED(\
ReplacementFor_FUNCTION_NAME, ReplacementFor_LOG_LEVEL)\
template <typename T, typename... ReplacementFor_Args>\
inline void ReplacementFor_Logger::ReplacementFor_FUNCTION_NAME(const char*, \
const T&, const ReplacementFor_Args&...) {\
return;\
}\
template <typename T>\
inline void ReplacementFor_Logger::ReplacementFor_FUNCTION_NAME(const T&) {\
return;\
}
#  if ReplacementFor_ELPP_INFO_LOG
ReplacementFor_LOGGER_LEVEL_WRITERS(ReplacementFor_info,Level::
ReplacementFor_Info)
#  else
ReplacementFor_LOGGER_LEVEL_WRITERS_DISABLED(ReplacementFor_info,Level::
ReplacementFor_Info)
#  endif 
#  if ReplacementFor_ELPP_DEBUG_LOG
ReplacementFor_LOGGER_LEVEL_WRITERS(ReplacementFor_debug,Level::
ReplacementFor_Debug)
#  else
ReplacementFor_LOGGER_LEVEL_WRITERS_DISABLED(ReplacementFor_debug,Level::
ReplacementFor_Debug)
#  endif 
#  if ReplacementFor_ELPP_WARNING_LOG
ReplacementFor_LOGGER_LEVEL_WRITERS(ReplacementFor_warn,Level::
ReplacementFor_Warning)
#  else
ReplacementFor_LOGGER_LEVEL_WRITERS_DISABLED(ReplacementFor_warn,Level::
ReplacementFor_Warning)
#  endif 
#  if ReplacementFor_ELPP_ERROR_LOG
ReplacementFor_LOGGER_LEVEL_WRITERS(error,Level::Error)
#  else
ReplacementFor_LOGGER_LEVEL_WRITERS_DISABLED(error,Level::Error)
#  endif 
#  if ReplacementFor_ELPP_FATAL_LOG
ReplacementFor_LOGGER_LEVEL_WRITERS(ReplacementFor_fatal,Level::
ReplacementFor_Fatal)
#  else
ReplacementFor_LOGGER_LEVEL_WRITERS_DISABLED(ReplacementFor_fatal,Level::
ReplacementFor_Fatal)
#  endif 
#  if ReplacementFor_ELPP_TRACE_LOG
ReplacementFor_LOGGER_LEVEL_WRITERS(ReplacementFor_trace,Level::
ReplacementFor_Trace)
#  else
ReplacementFor_LOGGER_LEVEL_WRITERS_DISABLED(ReplacementFor_trace,Level::
ReplacementFor_Trace)
#  endif 
#  undef ReplacementFor_LOGGER_LEVEL_WRITERS
#  undef ReplacementFor_LOGGER_LEVEL_WRITERS_DISABLED
#endif 
#if ReplacementFor_ELPP_COMPILER_MSVC
#  define ReplacementFor_ELPP_VARIADIC_FUNC_MSVC(ReplacementFor_variadicFunction\
, ReplacementFor_variadicArgs) ReplacementFor_variadicFunction \
ReplacementFor_variadicArgs
#  define ReplacementFor_ELPP_VARIADIC_FUNC_MSVC_RUN(\
ReplacementFor_variadicFunction, ...) ReplacementFor_ELPP_VARIADIC_FUNC_MSVC(\
ReplacementFor_variadicFunction, (ReplacementFor___VA_ARGS__))
#  define ReplacementFor_el_getVALength(...) \
ReplacementFor_ELPP_VARIADIC_FUNC_MSVC_RUN(ReplacementFor_el_resolveVALength, \
((0xc34+1182-0xc0c)+(0x1eb9+4560-0x1eff)-(0x1e8f+6439-0x2166)), ## \
ReplacementFor___VA_ARGS__,\
((0x2414+2217-0x2601)+7064-8778), ((0x2517+2121-0x1151)+(0x1efb+526-0x1fc6)-\
(0x1dc9+6609-0x1a51)), ((0x18fa+6832-0x20fa)+(0x2130+5497-0x238d)-9668), \
((0x1f25+2371-0x23c2)+(0x1538+8420-0x2670)-(0x2364+258-0x101b)), (\
(0xce0+575-0x310)+(0x2130+425-0xf9d)-8005), ((0x21dc+4515-0x1d0a)+\
(0x1884+2007-0x1bea)-6881), \
(9343+(0xb5f+6106-0x21a3)-(0x265a+5784-0x16e1)), ((0x1823+3334-0x19d8)+7077-9971\
), ((0xde3+2955-0x14c5)+(0x1ea0+17-0xdea)-5486), \
((0x17ea+365-0xa03)+(0x2481+2381-0x25cd)-(0x24b8+2095-0x1593)), (\
(0x1916+2643-0x18f8)+(0x2350+1590-0x236f)-(0x21e9+1518-0x174f)))
#else
#  if ReplacementFor_ELPP_COMPILER_CLANG
#    define ReplacementFor_el_getVALength(...) ReplacementFor_el_resolveVALength\
(((0x14e2+739-0xb13)+5445-(0x23f5+8544-0x235e)), ReplacementFor___VA_ARGS__, (\
(0x14e3+5320-0x1773)+(0x1f74+2883-0x2286)-(0x1ded+8267-0x23d9)), \
((0x64b+2425-0xce2)+(0xa26+4148-0x192d)-1030), ((0x1066+4743-0x1783)+\
(0x1fbb+1636-0x2112)-4207), ((0x1d29+2011-0x1023)+(0xa78+3447-0x1299)-6704), (\
(0x116b+3342-0x1e64)+(0x9e8+642-0xb43)-(0x7b5+7942-0x2585)), \
((0x1b3+8616-0x2219)+(0x1ec1+5582-0x1d12)-(0x22b8+5132-0x1e0a)), (5302+\
(0x71f+4601-0x125f)-(0x1d97+7665-0x201d)), ((0x8af+6054-0x1839)+\
(0x24c3+532-0x1c27)-(0x23dd+4932-0x2458)), \
((0x214a+2137-0x244c)+(0x25c8+1853-0xbfc)-9822), ((0x9cd+3346-0x1473)+\
(0x1212+5060-0x21a4)-(0x1159+779-0xdc7)), (6442+(0xb66+3742-0x15b0)-7550))
#  else
#    define ReplacementFor_el_getVALength(...) ReplacementFor_el_resolveVALength\
(((0xd04+4135-0x18f6)+(0x20ab+4275-0x24a1)-(0x13b8+7207-0x1eed)), ## \
ReplacementFor___VA_ARGS__, ((0x5e8+9978-0x26fb)+(0xf1f+5804-0x22df)-\
(0x1650+5882-0x2481)), \
(9657+(0xc84+3213-0x1845)-9852), ((0x2093+857-0x1a98)+(0xcd7+5272-0x1e22)-3225),\
 ((0x1701+2463-0x1d6f)+(0x1ed8+6629-0x1b03)-8420), ((0x1459+2535-0x144c)+\
(0x1d25+953-0x1b1a)-(0x17bf+3414-0x1563)),\
 ((0x239f+2522-0x2018)+(0x2209+3166-0x15d2)-9713), ((0xf19+7-0xa1e)+\
(0x60f+3414-0x1132)-(0x7e9+1728-0x778)), (7964+(0x1785+4309-0x223b)-9528), \
((0x1ab6+1614-0x102f)+(0x2200+2203-0x2047)-6951), ((0x124d+2495-0x14db)+\
(0x26ea+1687-0x110f)-(0x2639+8448-0x2397)), ((0x10c9+3003-0x19ce)+\
(0x1372+4188-0x1d4a)-(0x13d3+3985-0x1a2a)))
#  endif 
#endif 
#define ReplacementFor_el_resolveVALength(ReplacementFor__0, _1, _2, _3, _4, _5,\
 _6, _7, _8, _9, _10, N, ...) N
#define ReplacementFor_ELPP_WRITE_LOG(ReplacementFor_writer, \
ReplacementFor_level, ReplacementFor_dispatchAction, ...) \
ReplacementFor_writer(ReplacementFor_level, __FILE__, __LINE__, \
ReplacementFor_ELPP_FUNC, ReplacementFor_dispatchAction).construct(\
ReplacementFor_el_getVALength(ReplacementFor___VA_ARGS__), \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_ELPP_WRITE_LOG_IF(ReplacementFor_writer, \
ReplacementFor_condition, ReplacementFor_level, ReplacementFor_dispatchAction, \
...) if (ReplacementFor_condition) \
ReplacementFor_writer(ReplacementFor_level, __FILE__, __LINE__, \
ReplacementFor_ELPP_FUNC, ReplacementFor_dispatchAction).construct(\
ReplacementFor_el_getVALength(ReplacementFor___VA_ARGS__), \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_ELPP_WRITE_LOG_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_level, ReplacementFor_dispatchAction, \
...) \
ReplacementFor_ELPP->ReplacementFor_validateEveryNCounter(__FILE__, __LINE__, \
ReplacementFor_occasion) && \
ReplacementFor_writer(ReplacementFor_level, __FILE__, __LINE__, \
ReplacementFor_ELPP_FUNC, ReplacementFor_dispatchAction).construct(\
ReplacementFor_el_getVALength(ReplacementFor___VA_ARGS__), \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_ELPP_WRITE_LOG_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_level, ReplacementFor_dispatchAction, ...) \
ReplacementFor_ELPP->ReplacementFor_validateAfterNCounter(__FILE__, __LINE__, n)\
 && \
ReplacementFor_writer(ReplacementFor_level, __FILE__, __LINE__, \
ReplacementFor_ELPP_FUNC, ReplacementFor_dispatchAction).construct(\
ReplacementFor_el_getVALength(ReplacementFor___VA_ARGS__), \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_ELPP_WRITE_LOG_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_level, ReplacementFor_dispatchAction, ...) \
ReplacementFor_ELPP->ReplacementFor_validateNTimesCounter(__FILE__, __LINE__, n)\
 && \
ReplacementFor_writer(ReplacementFor_level, __FILE__, __LINE__, \
ReplacementFor_ELPP_FUNC, ReplacementFor_dispatchAction).construct(\
ReplacementFor_el_getVALength(ReplacementFor___VA_ARGS__), \
ReplacementFor___VA_ARGS__)
#if defined(ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ELPP_FEATURE_PERFORMANCE_TRACKING)
class ReplacementFor_PerformanceTrackingData{public:enum class DataType:base::
type::ReplacementFor_EnumType{ReplacementFor_Checkpoint=((0x1155+792-0x7ac)+
(0x18b0+3164-0x1a13)-(0x1d46+3700-0x1401)),ReplacementFor_Complete=(
(0x1239+3977-0x1c27)+(0x11af+4556-0x1d8e)-(0x1319+7974-0x26b9))};explicit 
ReplacementFor_PerformanceTrackingData(DataType ReplacementFor_dataType):
ReplacementFor_m_performanceTracker(nullptr),ReplacementFor_m_dataType(
ReplacementFor_dataType),ReplacementFor_m_firstCheckpoint(false),
ReplacementFor_m_file(""),ReplacementFor_m_line(((0x226c+2107-0x1c13)+
(0x2054+2430-0x20de)-(0x228a+5987-0x2265))),ReplacementFor_m_func(""){}inline 
const std::string*ReplacementFor_blockName(void)const;inline const struct 
timeval*ReplacementFor_startTime(void)const;inline const struct timeval*
ReplacementFor_endTime(void)const;inline const struct timeval*
ReplacementFor_lastCheckpointTime(void)const;inline const base::
ReplacementFor_PerformanceTracker*ReplacementFor_performanceTracker(void)const{
return ReplacementFor_m_performanceTracker;}inline 
ReplacementFor_PerformanceTrackingData::DataType ReplacementFor_dataType(void)
const{return ReplacementFor_m_dataType;}inline bool 
ReplacementFor_firstCheckpoint(void)const{return 
ReplacementFor_m_firstCheckpoint;}inline std::string ReplacementFor_checkpointId
(void)const{return ReplacementFor_m_checkpointId;}inline const char*
ReplacementFor_file(void)const{return ReplacementFor_m_file;}inline base::type::
ReplacementFor_LineNumber line(void)const{return ReplacementFor_m_line;}inline 
const char*ReplacementFor_func(void)const{return ReplacementFor_m_func;}inline 
const base::type::ReplacementFor_string_t*ReplacementFor_formattedTimeTaken()
const{return&ReplacementFor_m_formattedTimeTaken;}inline const std::string&
ReplacementFor_loggerId(void)const;private:base::
ReplacementFor_PerformanceTracker*ReplacementFor_m_performanceTracker;base::type
::ReplacementFor_string_t ReplacementFor_m_formattedTimeTaken;
ReplacementFor_PerformanceTrackingData::DataType ReplacementFor_m_dataType;bool 
ReplacementFor_m_firstCheckpoint;std::string ReplacementFor_m_checkpointId;const
 char*ReplacementFor_m_file;base::type::ReplacementFor_LineNumber 
ReplacementFor_m_line;const char*ReplacementFor_m_func;inline void init(base::
ReplacementFor_PerformanceTracker*ReplacementFor_performanceTracker,bool 
ReplacementFor_firstCheckpoint=false){ReplacementFor_m_performanceTracker=
ReplacementFor_performanceTracker;ReplacementFor_m_firstCheckpoint=
ReplacementFor_firstCheckpoint;}friend class ReplacementFor_el::base::
ReplacementFor_PerformanceTracker;};namespace base{class 
ReplacementFor_PerformanceTracker:public base::ReplacementFor_threading::
ReplacementFor_ThreadSafe,public ReplacementFor_Loggable{public:
ReplacementFor_PerformanceTracker(const std::string&ReplacementFor_blockName,
base::ReplacementFor_TimestampUnit ReplacementFor_timestampUnit=base::
ReplacementFor_TimestampUnit::ReplacementFor_Millisecond,const std::string&
ReplacementFor_loggerId=std::string(ReplacementFor_el::base::
ReplacementFor_consts::ReplacementFor_kPerformanceLoggerId),bool 
ReplacementFor_scopedLog=true,Level ReplacementFor_level=base::
ReplacementFor_consts::ReplacementFor_kPerformanceTrackerDefaultLevel);
ReplacementFor_PerformanceTracker(const ReplacementFor_PerformanceTracker&t):
ReplacementFor_m_blockName(t.ReplacementFor_m_blockName),
ReplacementFor_m_timestampUnit(t.ReplacementFor_m_timestampUnit),
ReplacementFor_m_loggerId(t.ReplacementFor_m_loggerId),
ReplacementFor_m_scopedLog(t.ReplacementFor_m_scopedLog),ReplacementFor_m_level(
t.ReplacementFor_m_level),ReplacementFor_m_hasChecked(t.
ReplacementFor_m_hasChecked),ReplacementFor_m_lastCheckpointId(t.
ReplacementFor_m_lastCheckpointId),ReplacementFor_m_enabled(t.
ReplacementFor_m_enabled),ReplacementFor_m_startTime(t.
ReplacementFor_m_startTime),ReplacementFor_m_endTime(t.ReplacementFor_m_endTime)
,ReplacementFor_m_lastCheckpointTime(t.ReplacementFor_m_lastCheckpointTime){}
virtual~ReplacementFor_PerformanceTracker(void);void ReplacementFor_checkpoint(
const std::string&id=std::string(),const char*ReplacementFor_file=__FILE__,base
::type::ReplacementFor_LineNumber line=__LINE__,const char*ReplacementFor_func=
"");inline Level ReplacementFor_level(void)const{return ReplacementFor_m_level;}
private:std::string ReplacementFor_m_blockName;base::
ReplacementFor_TimestampUnit ReplacementFor_m_timestampUnit;std::string 
ReplacementFor_m_loggerId;bool ReplacementFor_m_scopedLog;Level 
ReplacementFor_m_level;bool ReplacementFor_m_hasChecked;std::string 
ReplacementFor_m_lastCheckpointId;bool ReplacementFor_m_enabled;struct timeval 
ReplacementFor_m_startTime,ReplacementFor_m_endTime,
ReplacementFor_m_lastCheckpointTime;ReplacementFor_PerformanceTracker(void);
friend class ReplacementFor_el::ReplacementFor_PerformanceTrackingData;friend 
class base::ReplacementFor_DefaultPerformanceTrackingCallback;const inline base
::type::ReplacementFor_string_t ReplacementFor_getFormattedTimeTaken()const{
return ReplacementFor_getFormattedTimeTaken(ReplacementFor_m_startTime);}const 
base::type::ReplacementFor_string_t ReplacementFor_getFormattedTimeTaken(struct 
timeval ReplacementFor_startTime)const;virtual inline void log(ReplacementFor_el
::base::type::ReplacementFor_ostream_t&os)const{os<<
ReplacementFor_getFormattedTimeTaken();}};class 
ReplacementFor_DefaultPerformanceTrackingCallback:public 
ReplacementFor_PerformanceTrackingCallback{protected:void ReplacementFor_handle(
const ReplacementFor_PerformanceTrackingData*data){ReplacementFor_m_data=data;
base::type::ReplacementFor_stringstream_t ReplacementFor_ss;if(
ReplacementFor_m_data->ReplacementFor_dataType()==
ReplacementFor_PerformanceTrackingData::DataType::ReplacementFor_Complete){
ReplacementFor_ss<<ReplacementFor_ELPP_LITERAL(
"\x45\x78\x65\x63\x75\x74\x65\x64\x20\x5b")<<ReplacementFor_m_data->
ReplacementFor_blockName()->c_str()<<ReplacementFor_ELPP_LITERAL(
"\x5d\x20\x69\x6e\x20\x5b")<<*ReplacementFor_m_data->
ReplacementFor_formattedTimeTaken()<<ReplacementFor_ELPP_LITERAL("\x5d");}else{
ReplacementFor_ss<<ReplacementFor_ELPP_LITERAL(
"\x50\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65\x20\x63\x68\x65\x63\x6b\x70\x6f\x69\x6e\x74"
);if(!ReplacementFor_m_data->ReplacementFor_checkpointId().empty()){
ReplacementFor_ss<<ReplacementFor_ELPP_LITERAL("\x20\x5b")<<
ReplacementFor_m_data->ReplacementFor_checkpointId().c_str()<<
ReplacementFor_ELPP_LITERAL("\x5d");}ReplacementFor_ss<<
ReplacementFor_ELPP_LITERAL("\x20\x66\x6f\x72\x20\x62\x6c\x6f\x63\x6b\x20\x5b")
<<ReplacementFor_m_data->ReplacementFor_blockName()->c_str()<<
ReplacementFor_ELPP_LITERAL("\x5d\x20\x3a\x20\x5b")<<*ReplacementFor_m_data->
ReplacementFor_performanceTracker();if(!ReplacementFor_ELPP->
ReplacementFor_hasFlag(ReplacementFor_LoggingFlag::
ReplacementFor_DisablePerformanceTrackingCheckpointComparison)&&
ReplacementFor_m_data->ReplacementFor_performanceTracker()->
ReplacementFor_m_hasChecked){ReplacementFor_ss<<ReplacementFor_ELPP_LITERAL(
"\x20\x28\x5b")<<*ReplacementFor_m_data->ReplacementFor_formattedTimeTaken()<<
ReplacementFor_ELPP_LITERAL("\x5d\x20\x66\x72\x6f\x6d\x20");if(
ReplacementFor_m_data->ReplacementFor_performanceTracker()->
ReplacementFor_m_lastCheckpointId.empty()){ReplacementFor_ss<<
ReplacementFor_ELPP_LITERAL(
"\x6c\x61\x73\x74\x20\x63\x68\x65\x63\x6b\x70\x6f\x69\x6e\x74");}else{
ReplacementFor_ss<<ReplacementFor_ELPP_LITERAL(
"\x63\x68\x65\x63\x6b\x70\x6f\x69\x6e\x74\x20\x27")<<ReplacementFor_m_data->
ReplacementFor_performanceTracker()->ReplacementFor_m_lastCheckpointId.c_str()<<
ReplacementFor_ELPP_LITERAL("\x27");}ReplacementFor_ss<<
ReplacementFor_ELPP_LITERAL("\x29\x5d");}else{ReplacementFor_ss<<
ReplacementFor_ELPP_LITERAL("\x5d");}}ReplacementFor_el::base::
ReplacementFor_Writer(ReplacementFor_m_data->ReplacementFor_performanceTracker()
->ReplacementFor_level(),ReplacementFor_m_data->ReplacementFor_file(),
ReplacementFor_m_data->line(),ReplacementFor_m_data->ReplacementFor_func()).
construct(((0x2487+8705-0x2612)+(0xef3+1950-0x110a)-9724),ReplacementFor_m_data
->ReplacementFor_loggerId().c_str())<<ReplacementFor_ss.str();}private:const 
ReplacementFor_PerformanceTrackingData*ReplacementFor_m_data;};}inline const std
::string*ReplacementFor_PerformanceTrackingData::ReplacementFor_blockName()const
{return const_cast<const std::string*>(&ReplacementFor_m_performanceTracker->
ReplacementFor_m_blockName);}inline const struct timeval*
ReplacementFor_PerformanceTrackingData::ReplacementFor_startTime()const{return 
const_cast<const struct timeval*>(&ReplacementFor_m_performanceTracker->
ReplacementFor_m_startTime);}inline const struct timeval*
ReplacementFor_PerformanceTrackingData::ReplacementFor_endTime()const{return 
const_cast<const struct timeval*>(&ReplacementFor_m_performanceTracker->
ReplacementFor_m_endTime);}inline const struct timeval*
ReplacementFor_PerformanceTrackingData::ReplacementFor_lastCheckpointTime()const
{return const_cast<const struct timeval*>(&ReplacementFor_m_performanceTracker->
ReplacementFor_m_lastCheckpointTime);}inline const std::string&
ReplacementFor_PerformanceTrackingData::ReplacementFor_loggerId(void)const{
return ReplacementFor_m_performanceTracker->ReplacementFor_m_loggerId;}
#endif 
namespace base{namespace ReplacementFor_debug{
#if defined(ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ELPP_FEATURE_CRASH_LOG)
class ReplacementFor_StackTrace:base::ReplacementFor_NoCopy{public:static const 
unsigned int ReplacementFor_kMaxStack=((0x207c+4994-0x1e8a)+(0x1c6f+2523-0x1aaf)
-8399);static const unsigned int ReplacementFor_kStackStart=(
(0x1854+2700-0x1b6a)+(0x23ff+3062-0x24e4)-(0x16fa+4206-0x14e3));class 
ReplacementFor_StackTraceEntry{public:ReplacementFor_StackTraceEntry(std::size_t
 index,const std::string&ReplacementFor_loc,const std::string&
ReplacementFor_demang,const std::string&hex,const std::string&addr);
ReplacementFor_StackTraceEntry(std::size_t index,const std::string&
ReplacementFor_loc):ReplacementFor_m_index(index),ReplacementFor_m_location(
ReplacementFor_loc){}std::size_t ReplacementFor_m_index;std::string 
ReplacementFor_m_location;std::string ReplacementFor_m_demangled;std::string 
ReplacementFor_m_hex;std::string ReplacementFor_m_addr;friend std::ostream&
operator<<(std::ostream&ReplacementFor_ss,const ReplacementFor_StackTraceEntry&
ReplacementFor_si);private:ReplacementFor_StackTraceEntry(void);};
ReplacementFor_StackTrace(void){ReplacementFor_generateNew();}virtual~
ReplacementFor_StackTrace(void){}inline std::vector<
ReplacementFor_StackTraceEntry>&ReplacementFor_getLatestStack(void){return 
ReplacementFor_m_stack;}friend std::ostream&operator<<(std::ostream&os,const 
ReplacementFor_StackTrace&st);private:std::vector<ReplacementFor_StackTraceEntry
>ReplacementFor_m_stack;void ReplacementFor_generateNew(void);};class 
ReplacementFor_CrashHandler:base::ReplacementFor_NoCopy{public:typedef void(*
ReplacementFor_Handler)(int);explicit ReplacementFor_CrashHandler(bool 
ReplacementFor_useDefault);explicit ReplacementFor_CrashHandler(const 
ReplacementFor_Handler&ReplacementFor_cHandler){ReplacementFor_setHandler(
ReplacementFor_cHandler);}void ReplacementFor_setHandler(const 
ReplacementFor_Handler&ReplacementFor_cHandler);private:ReplacementFor_Handler 
ReplacementFor_m_handler;};
#else
class ReplacementFor_CrashHandler{public:explicit ReplacementFor_CrashHandler(
bool){}};
#endif 
}}extern base::ReplacementFor_debug::ReplacementFor_CrashHandler 
ReplacementFor_elCrashHandler;
#define ReplacementFor_MAKE_LOGGABLE(ReplacementFor_ClassType, \
ReplacementFor_ClassInstance, ReplacementFor_OutputStreamInstance) \
ReplacementFor_el::base::type::ReplacementFor_ostream_t& operator<<(\
ReplacementFor_el::base::type::ReplacementFor_ostream_t& \
ReplacementFor_OutputStreamInstance, const ReplacementFor_ClassType& \
ReplacementFor_ClassInstance)
class ReplacementFor_SysLogInitializer{public:ReplacementFor_SysLogInitializer(
const char*ReplacementFor_processIdent,int options=((0xb86+2228-0xf9f)+
(0x1a5f+9523-0x25c3)-7786),int ReplacementFor_facility=((0xbad+2862-0x159e)+9190
-9507)){
#if defined(ReplacementFor_ELPP_SYSLOG)
openlog(ReplacementFor_processIdent,options,ReplacementFor_facility);
#else
ReplacementFor_ELPP_UNUSED(ReplacementFor_processIdent);
ReplacementFor_ELPP_UNUSED(options);ReplacementFor_ELPP_UNUSED(
ReplacementFor_facility);
#endif  
}virtual~ReplacementFor_SysLogInitializer(void){
#if defined(ReplacementFor_ELPP_SYSLOG)
closelog();
#endif  
}};
#define ReplacementFor_ELPP_INITIALIZE_SYSLOG(id, ReplacementFor_opt, \
ReplacementFor_fac) ReplacementFor_el::ReplacementFor_SysLogInitializer \
ReplacementFor_elSyslogInit(id, ReplacementFor_opt, ReplacementFor_fac)
class ReplacementFor_Helpers:base::ReplacementFor_StaticClass{public:static 
inline void ReplacementFor_setStorage(base::type::ReplacementFor_StoragePointer 
ReplacementFor_storage){ReplacementFor_ELPP=ReplacementFor_storage;}static 
inline base::type::ReplacementFor_StoragePointer ReplacementFor_storage(){return
 ReplacementFor_ELPP;}static inline void ReplacementFor_setArgs(int 
ReplacementFor_argc,char**ReplacementFor_argv){ReplacementFor_ELPP->
ReplacementFor_setApplicationArguments(ReplacementFor_argc,ReplacementFor_argv);
}static inline void ReplacementFor_setArgs(int ReplacementFor_argc,const char**
ReplacementFor_argv){ReplacementFor_ELPP->ReplacementFor_setApplicationArguments
(ReplacementFor_argc,const_cast<char**>(ReplacementFor_argv));}static inline 
void ReplacementFor_setThreadName(const std::string&name){ReplacementFor_ELPP->
ReplacementFor_setThreadName(name);}static inline std::string 
ReplacementFor_getThreadName(){return ReplacementFor_ELPP->
ReplacementFor_getThreadName(base::ReplacementFor_threading::
ReplacementFor_getCurrentThreadId());}
#if defined(ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ELPP_FEATURE_CRASH_LOG)
static inline void ReplacementFor_setCrashHandler(const ReplacementFor_el::base
::ReplacementFor_debug::ReplacementFor_CrashHandler::ReplacementFor_Handler&
ReplacementFor_crashHandler){ReplacementFor_el::ReplacementFor_elCrashHandler.
ReplacementFor_setHandler(ReplacementFor_crashHandler);}static void 
ReplacementFor_crashAbort(int sig,const char*ReplacementFor_sourceFile="",
unsigned int long line=((0x18d3+6624-0x2653)+(0xda9+6347-0x227e)-
(0x14b9+6260-0x1cd7)));static void ReplacementFor_logCrashReason(int sig,bool 
ReplacementFor_stackTraceIfAvailable=false,Level ReplacementFor_level=Level::
ReplacementFor_Fatal,const char*ReplacementFor_logger=base::
ReplacementFor_consts::ReplacementFor_kDefaultLoggerId);
#endif 
static inline void ReplacementFor_installPreRollOutCallback(const 
ReplacementFor_PreRollOutCallback&ReplacementFor_callback){ReplacementFor_ELPP->
ReplacementFor_setPreRollOutCallback(ReplacementFor_callback);}static inline 
void ReplacementFor_uninstallPreRollOutCallback(void){ReplacementFor_ELPP->
ReplacementFor_unsetPreRollOutCallback();}template<typename T>static inline bool
 ReplacementFor_installLogDispatchCallback(const std::string&id){return 
ReplacementFor_ELPP->ReplacementFor_installLogDispatchCallback<T>(id);}template<
typename T>static inline void ReplacementFor_uninstallLogDispatchCallback(const 
std::string&id){ReplacementFor_ELPP->ReplacementFor_uninstallLogDispatchCallback
<T>(id);}template<typename T>static inline T*ReplacementFor_logDispatchCallback(
const std::string&id){return ReplacementFor_ELPP->
ReplacementFor_logDispatchCallback<T>(id);}
#if defined(ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ELPP_FEATURE_PERFORMANCE_TRACKING)
template<typename T>static inline bool 
ReplacementFor_installPerformanceTrackingCallback(const std::string&id){return 
ReplacementFor_ELPP->ReplacementFor_installPerformanceTrackingCallback<T>(id);}
template<typename T>static inline void 
ReplacementFor_uninstallPerformanceTrackingCallback(const std::string&id){
ReplacementFor_ELPP->ReplacementFor_uninstallPerformanceTrackingCallback<T>(id);
}template<typename T>static inline T*ReplacementFor_performanceTrackingCallback(
const std::string&id){return ReplacementFor_ELPP->
ReplacementFor_performanceTrackingCallback<T>(id);}
#endif 
template<typename T>static std::string ReplacementFor_convertTemplateToStdString
(const T&ReplacementFor_templ){ReplacementFor_el::ReplacementFor_Logger*
ReplacementFor_logger=ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->
get(ReplacementFor_el::base::ReplacementFor_consts::
ReplacementFor_kDefaultLoggerId);if(ReplacementFor_logger==nullptr){return std::
string();}base::ReplacementFor_MessageBuilder b;b.ReplacementFor_initialize(
ReplacementFor_logger);ReplacementFor_logger->ReplacementFor_acquireLock();b<<
ReplacementFor_templ;
#if defined(ReplacementFor_ELPP_UNICODE)
std::string s=std::string(ReplacementFor_logger->ReplacementFor_stream().str().
begin(),ReplacementFor_logger->ReplacementFor_stream().str().end());
#else
std::string s=ReplacementFor_logger->ReplacementFor_stream().str();
#endif  
ReplacementFor_logger->ReplacementFor_stream().str(ReplacementFor_ELPP_LITERAL(
""));ReplacementFor_logger->ReplacementFor_releaseLock();return s;}static inline
 const ReplacementFor_el::base::ReplacementFor_utils::
ReplacementFor_CommandLineArgs*ReplacementFor_commandLineArgs(void){return 
ReplacementFor_ELPP->ReplacementFor_commandLineArgs();}static inline void 
ReplacementFor_reserveCustomFormatSpecifiers(std::size_t size){
ReplacementFor_ELPP->ReplacementFor_m_customFormatSpecifiers.reserve(size);}
static inline void ReplacementFor_installCustomFormatSpecifier(const 
ReplacementFor_CustomFormatSpecifier&ReplacementFor_customFormatSpecifier){
ReplacementFor_ELPP->ReplacementFor_installCustomFormatSpecifier(
ReplacementFor_customFormatSpecifier);}static inline bool 
ReplacementFor_uninstallCustomFormatSpecifier(const char*
ReplacementFor_formatSpecifier){return ReplacementFor_ELPP->
ReplacementFor_uninstallCustomFormatSpecifier(ReplacementFor_formatSpecifier);}
static inline bool ReplacementFor_hasCustomFormatSpecifier(const char*
ReplacementFor_formatSpecifier){return ReplacementFor_ELPP->
ReplacementFor_hasCustomFormatSpecifier(ReplacementFor_formatSpecifier);}static 
inline void ReplacementFor_validateFileRolling(ReplacementFor_Logger*
ReplacementFor_logger,Level ReplacementFor_level){if(ReplacementFor_ELPP==
nullptr||ReplacementFor_logger==nullptr)return;ReplacementFor_logger->
ReplacementFor_m_typedConfigurations->ReplacementFor_validateFileRolling(
ReplacementFor_level,ReplacementFor_ELPP->ReplacementFor_preRollOutCallback());}
};class ReplacementFor_Loggers:base::ReplacementFor_StaticClass{public:static 
ReplacementFor_Logger*ReplacementFor_getLogger(const std::string&
ReplacementFor_identity,bool ReplacementFor_registerIfNotAvailable=true);static 
void ReplacementFor_setDefaultLogBuilder(ReplacementFor_el::
ReplacementFor_LogBuilderPtr&ReplacementFor_logBuilderPtr);template<typename T>
static inline bool ReplacementFor_installLoggerRegistrationCallback(const std::
string&id){return ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->
ReplacementFor_installLoggerRegistrationCallback<T>(id);}template<typename T>
static inline void ReplacementFor_uninstallLoggerRegistrationCallback(const std
::string&id){ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->
ReplacementFor_uninstallLoggerRegistrationCallback<T>(id);}template<typename T>
static inline T*ReplacementFor_loggerRegistrationCallback(const std::string&id){
return ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->
ReplacementFor_loggerRegistrationCallback<T>(id);}static bool 
ReplacementFor_unregisterLogger(const std::string&ReplacementFor_identity);
static bool ReplacementFor_hasLogger(const std::string&ReplacementFor_identity);
static ReplacementFor_Logger*ReplacementFor_reconfigureLogger(
ReplacementFor_Logger*ReplacementFor_logger,const ReplacementFor_Configurations&
ReplacementFor_configurations);static ReplacementFor_Logger*
ReplacementFor_reconfigureLogger(const std::string&ReplacementFor_identity,const
 ReplacementFor_Configurations&ReplacementFor_configurations);static 
ReplacementFor_Logger*ReplacementFor_reconfigureLogger(const std::string&
ReplacementFor_identity,ReplacementFor_ConfigurationType 
ReplacementFor_configurationType,const std::string&value);static void 
ReplacementFor_reconfigureAllLoggers(const ReplacementFor_Configurations&
ReplacementFor_configurations);static inline void 
ReplacementFor_reconfigureAllLoggers(ReplacementFor_ConfigurationType 
ReplacementFor_configurationType,const std::string&value){
ReplacementFor_reconfigureAllLoggers(Level::Global,
ReplacementFor_configurationType,value);}static void 
ReplacementFor_reconfigureAllLoggers(Level ReplacementFor_level,
ReplacementFor_ConfigurationType ReplacementFor_configurationType,const std::
string&value);static void ReplacementFor_setDefaultConfigurations(const 
ReplacementFor_Configurations&ReplacementFor_configurations,bool 
ReplacementFor_reconfigureExistingLoggers=false);static const 
ReplacementFor_Configurations*ReplacementFor_defaultConfigurations(void);static 
const base::ReplacementFor_LogStreamsReferenceMap*
ReplacementFor_logStreamsReference(void);static base::
ReplacementFor_TypedConfigurations ReplacementFor_defaultTypedConfigurations(
void);static std::vector<std::string>*ReplacementFor_populateAllLoggerIds(std::
vector<std::string>*ReplacementFor_targetList);static void 
ReplacementFor_configureFromGlobal(const char*
ReplacementFor_globalConfigurationFilePath);static bool 
ReplacementFor_configureFromArg(const char*ReplacementFor_argKey);static void 
flushAll(void);static inline void ReplacementFor_addFlag(
ReplacementFor_LoggingFlag flag){ReplacementFor_ELPP->ReplacementFor_addFlag(
flag);}static inline void ReplacementFor_removeFlag(ReplacementFor_LoggingFlag 
flag){ReplacementFor_ELPP->ReplacementFor_removeFlag(flag);}static inline bool 
ReplacementFor_hasFlag(ReplacementFor_LoggingFlag flag){return 
ReplacementFor_ELPP->ReplacementFor_hasFlag(flag);}class 
ReplacementFor_ScopedAddFlag{public:ReplacementFor_ScopedAddFlag(
ReplacementFor_LoggingFlag flag):ReplacementFor_m_flag(flag){
ReplacementFor_Loggers::ReplacementFor_addFlag(ReplacementFor_m_flag);}~
ReplacementFor_ScopedAddFlag(void){ReplacementFor_Loggers::
ReplacementFor_removeFlag(ReplacementFor_m_flag);}private:
ReplacementFor_LoggingFlag ReplacementFor_m_flag;};class 
ReplacementFor_ScopedRemoveFlag{public:ReplacementFor_ScopedRemoveFlag(
ReplacementFor_LoggingFlag flag):ReplacementFor_m_flag(flag){
ReplacementFor_Loggers::ReplacementFor_removeFlag(ReplacementFor_m_flag);}~
ReplacementFor_ScopedRemoveFlag(void){ReplacementFor_Loggers::
ReplacementFor_addFlag(ReplacementFor_m_flag);}private:
ReplacementFor_LoggingFlag ReplacementFor_m_flag;};static void 
ReplacementFor_setLoggingLevel(Level ReplacementFor_level){ReplacementFor_ELPP->
ReplacementFor_setLoggingLevel(ReplacementFor_level);}static void 
ReplacementFor_setVerboseLevel(base::type::ReplacementFor_VerboseLevel 
ReplacementFor_level);static base::type::ReplacementFor_VerboseLevel 
ReplacementFor_verboseLevel(void);static void ReplacementFor_setVModules(const 
char*ReplacementFor_modules);static void ReplacementFor_clearVModules(void);};
class ReplacementFor_VersionInfo:base::ReplacementFor_StaticClass{public:static 
const std::string ReplacementFor_version(void);static const std::string 
ReplacementFor_releaseDate(void);};}
#undef ReplacementFor_VLOG_IS_ON
#define ReplacementFor_VLOG_IS_ON(ReplacementFor_verboseLevel) (\
ReplacementFor_ELPP->ReplacementFor_vRegistry()->ReplacementFor_allowed(\
ReplacementFor_verboseLevel, __FILE__))
#undef ReplacementFor_TIMED_BLOCK
#undef ReplacementFor_TIMED_SCOPE
#undef ReplacementFor_TIMED_SCOPE_IF
#undef ReplacementFor_TIMED_FUNC
#undef ReplacementFor_TIMED_FUNC_IF
#undef ReplacementFor_ELPP_MIN_UNIT
#if defined(ReplacementFor_ELPP_PERFORMANCE_MICROSECONDS)
#  define ReplacementFor_ELPP_MIN_UNIT ReplacementFor_el::base::\
ReplacementFor_TimestampUnit::ReplacementFor_Microsecond
#else
#  define ReplacementFor_ELPP_MIN_UNIT ReplacementFor_el::base::\
ReplacementFor_TimestampUnit::ReplacementFor_Millisecond
#endif  
#define ReplacementFor_TIMED_SCOPE_IF(ReplacementFor_obj, \
ReplacementFor_blockname, ReplacementFor_condition) ReplacementFor_el::base::\
type::ReplacementFor_PerformanceTrackerPtr ReplacementFor_obj( \
ReplacementFor_condition ? \
  new ReplacementFor_el::base::ReplacementFor_PerformanceTracker(\
ReplacementFor_blockname, ReplacementFor_ELPP_MIN_UNIT) : nullptr )
#define ReplacementFor_TIMED_SCOPE(ReplacementFor_obj, ReplacementFor_blockname)\
 ReplacementFor_TIMED_SCOPE_IF(ReplacementFor_obj, ReplacementFor_blockname, \
true)
#define ReplacementFor_TIMED_BLOCK(ReplacementFor_obj, ReplacementFor_blockName)\
 for (struct { int i; ReplacementFor_el::base::type::\
ReplacementFor_PerformanceTrackerPtr ReplacementFor_timer; } ReplacementFor_obj \
= { ((0x1036+487-0xd60)+7338-8551), \
  ReplacementFor_el::base::type::ReplacementFor_PerformanceTrackerPtr(new \
ReplacementFor_el::base::ReplacementFor_PerformanceTracker(\
ReplacementFor_blockName, ReplacementFor_ELPP_MIN_UNIT)) }; ReplacementFor_obj.i\
 < ((0xdab+2709-0x1713)+(0x235c+2169-0x26c7)-(0xd50+1919-0xe95)); ++\
ReplacementFor_obj.i)
#define ReplacementFor_TIMED_FUNC_IF(ReplacementFor_obj,ReplacementFor_condition\
) ReplacementFor_TIMED_SCOPE_IF(ReplacementFor_obj, ReplacementFor_ELPP_FUNC, \
ReplacementFor_condition)
#define ReplacementFor_TIMED_FUNC(ReplacementFor_obj) ReplacementFor_TIMED_SCOPE\
(ReplacementFor_obj, ReplacementFor_ELPP_FUNC)
#undef ReplacementFor_PERFORMANCE_CHECKPOINT
#undef ReplacementFor_PERFORMANCE_CHECKPOINT_WITH_ID
#define ReplacementFor_PERFORMANCE_CHECKPOINT(ReplacementFor_obj) \
ReplacementFor_obj->ReplacementFor_checkpoint(std::string(), __FILE__, __LINE__,\
 ReplacementFor_ELPP_FUNC)
#define ReplacementFor_PERFORMANCE_CHECKPOINT_WITH_ID(ReplacementFor_obj, id) \
ReplacementFor_obj->ReplacementFor_checkpoint(id, __FILE__, __LINE__, \
ReplacementFor_ELPP_FUNC)
#undef ReplacementFor_ELPP_COUNTER
#undef ReplacementFor_ELPP_COUNTER_POS
#define ReplacementFor_ELPP_COUNTER (ReplacementFor_ELPP->\
ReplacementFor_hitCounters()->ReplacementFor_getCounter(__FILE__, __LINE__))
#define ReplacementFor_ELPP_COUNTER_POS (ReplacementFor_ELPP_COUNTER == nullptr \
? -((0x599+174-0x537)+9346-9617) : ReplacementFor_ELPP_COUNTER->\
ReplacementFor_hitCounts()\
)
#undef ReplacementFor_INFO
#undef ReplacementFor_WARNING
#undef DEBUG
#undef ERROR
#undef ReplacementFor_FATAL
#undef ReplacementFor_TRACE
#undef ReplacementFor_VERBOSE
#undef ReplacementFor_CINFO
#undef ReplacementFor_CWARNING
#undef ReplacementFor_CDEBUG
#undef ReplacementFor_CFATAL
#undef ReplacementFor_CERROR
#undef ReplacementFor_CTRACE
#undef ReplacementFor_CVERBOSE
#undef ReplacementFor_CINFO_IF
#undef ReplacementFor_CWARNING_IF
#undef ReplacementFor_CDEBUG_IF
#undef ReplacementFor_CERROR_IF
#undef ReplacementFor_CFATAL_IF
#undef ReplacementFor_CTRACE_IF
#undef ReplacementFor_CVERBOSE_IF
#undef ReplacementFor_CINFO_EVERY_N
#undef ReplacementFor_CWARNING_EVERY_N
#undef ReplacementFor_CDEBUG_EVERY_N
#undef ReplacementFor_CERROR_EVERY_N
#undef ReplacementFor_CFATAL_EVERY_N
#undef ReplacementFor_CTRACE_EVERY_N
#undef ReplacementFor_CVERBOSE_EVERY_N
#undef ReplacementFor_CINFO_AFTER_N
#undef ReplacementFor_CWARNING_AFTER_N
#undef ReplacementFor_CDEBUG_AFTER_N
#undef ReplacementFor_CERROR_AFTER_N
#undef ReplacementFor_CFATAL_AFTER_N
#undef ReplacementFor_CTRACE_AFTER_N
#undef ReplacementFor_CVERBOSE_AFTER_N
#undef ReplacementFor_CINFO_N_TIMES
#undef ReplacementFor_CWARNING_N_TIMES
#undef ReplacementFor_CDEBUG_N_TIMES
#undef ReplacementFor_CERROR_N_TIMES
#undef ReplacementFor_CFATAL_N_TIMES
#undef ReplacementFor_CTRACE_N_TIMES
#undef ReplacementFor_CVERBOSE_N_TIMES
#if ReplacementFor_ELPP_INFO_LOG
#  define ReplacementFor_CINFO(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_ELPP_WRITE_LOG(\
ReplacementFor_writer, ReplacementFor_el::Level::ReplacementFor_Info, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CINFO(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_WARNING_LOG
#  define ReplacementFor_CWARNING(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_ELPP_WRITE_LOG(\
ReplacementFor_writer, ReplacementFor_el::Level::ReplacementFor_Warning, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CWARNING(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_DEBUG_LOG
#  define ReplacementFor_CDEBUG(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_ELPP_WRITE_LOG(\
ReplacementFor_writer, ReplacementFor_el::Level::ReplacementFor_Debug, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CDEBUG(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_ERROR_LOG
#  define ReplacementFor_CERROR(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_ELPP_WRITE_LOG(\
ReplacementFor_writer, ReplacementFor_el::Level::Error, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CERROR(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_FATAL_LOG
#  define ReplacementFor_CFATAL(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_ELPP_WRITE_LOG(\
ReplacementFor_writer, ReplacementFor_el::Level::ReplacementFor_Fatal, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CFATAL(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_TRACE_LOG
#  define ReplacementFor_CTRACE(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_ELPP_WRITE_LOG(\
ReplacementFor_writer, ReplacementFor_el::Level::ReplacementFor_Trace, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CTRACE(ReplacementFor_writer, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_VERBOSE_LOG
#  define ReplacementFor_CVERBOSE(ReplacementFor_writer, ReplacementFor_vlevel, \
ReplacementFor_dispatchAction, ...) if (ReplacementFor_VLOG_IS_ON(\
ReplacementFor_vlevel)) ReplacementFor_writer(\
ReplacementFor_el::Level::ReplacementFor_Verbose, __FILE__, __LINE__, \
ReplacementFor_ELPP_FUNC, ReplacementFor_dispatchAction, ReplacementFor_vlevel).\
construct(ReplacementFor_el_getVALength(ReplacementFor___VA_ARGS__), \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CVERBOSE(ReplacementFor_writer, ReplacementFor_vlevel, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_INFO_LOG
#  define ReplacementFor_CINFO_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...) \
ReplacementFor_ELPP_WRITE_LOG_IF(ReplacementFor_writer, (\
ReplacementFor_condition_), ReplacementFor_el::Level::ReplacementFor_Info, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CINFO_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...) ReplacementFor_el\
::base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_WARNING_LOG
#  define ReplacementFor_CWARNING_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_IF(ReplacementFor_writer, (\
ReplacementFor_condition_), ReplacementFor_el::Level::ReplacementFor_Warning, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CWARNING_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...) ReplacementFor_el\
::base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_DEBUG_LOG
#  define ReplacementFor_CDEBUG_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_IF(ReplacementFor_writer, (\
ReplacementFor_condition_), ReplacementFor_el::Level::ReplacementFor_Debug, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CDEBUG_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...) ReplacementFor_el\
::base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_ERROR_LOG
#  define ReplacementFor_CERROR_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_IF(ReplacementFor_writer, (\
ReplacementFor_condition_), ReplacementFor_el::Level::Error, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CERROR_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...) ReplacementFor_el\
::base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_FATAL_LOG
#  define ReplacementFor_CFATAL_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_IF(ReplacementFor_writer, (\
ReplacementFor_condition_), ReplacementFor_el::Level::ReplacementFor_Fatal, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CFATAL_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...) ReplacementFor_el\
::base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_TRACE_LOG
#  define ReplacementFor_CTRACE_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_IF(ReplacementFor_writer, (\
ReplacementFor_condition_), ReplacementFor_el::Level::ReplacementFor_Trace, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CTRACE_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_dispatchAction, ...) ReplacementFor_el\
::base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_VERBOSE_LOG
#  define ReplacementFor_CVERBOSE_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_vlevel, ReplacementFor_dispatchAction,\
 ...) if (ReplacementFor_VLOG_IS_ON(ReplacementFor_vlevel) && (\
ReplacementFor_condition_)) ReplacementFor_writer( \
ReplacementFor_el::Level::ReplacementFor_Verbose, __FILE__, __LINE__, \
ReplacementFor_ELPP_FUNC, ReplacementFor_dispatchAction, ReplacementFor_vlevel).\
construct(ReplacementFor_el_getVALength(ReplacementFor___VA_ARGS__), \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CVERBOSE_IF(ReplacementFor_writer, \
ReplacementFor_condition_, ReplacementFor_vlevel, ReplacementFor_dispatchAction,\
 ...) ReplacementFor_el::base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_INFO_LOG
#  define ReplacementFor_CINFO_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_el::Level::ReplacementFor_Info, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CINFO_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...) ReplacementFor_el::\
base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_WARNING_LOG
#  define ReplacementFor_CWARNING_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_el::Level::ReplacementFor_Warning, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CWARNING_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...) ReplacementFor_el::\
base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_DEBUG_LOG
#  define ReplacementFor_CDEBUG_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_el::Level::ReplacementFor_Debug, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CDEBUG_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...) ReplacementFor_el::\
base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_ERROR_LOG
#  define ReplacementFor_CERROR_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_el::Level::Error, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CERROR_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...) ReplacementFor_el::\
base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_FATAL_LOG
#  define ReplacementFor_CFATAL_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_el::Level::ReplacementFor_Fatal, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CFATAL_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...) ReplacementFor_el::\
base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_TRACE_LOG
#  define ReplacementFor_CTRACE_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_el::Level::ReplacementFor_Trace, \
ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CTRACE_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_dispatchAction, ...) ReplacementFor_el::\
base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_VERBOSE_LOG
#  define ReplacementFor_CVERBOSE_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_vlevel, ReplacementFor_dispatchAction, \
...)\
ReplacementFor_CVERBOSE_IF(ReplacementFor_writer, ReplacementFor_ELPP->\
ReplacementFor_validateEveryNCounter(__FILE__, __LINE__, ReplacementFor_occasion\
), ReplacementFor_vlevel, ReplacementFor_dispatchAction, \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CVERBOSE_EVERY_N(ReplacementFor_writer, \
ReplacementFor_occasion, ReplacementFor_vlevel, ReplacementFor_dispatchAction, \
...) ReplacementFor_el::base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_INFO_LOG
#  define ReplacementFor_CINFO_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_el::Level::ReplacementFor_Info, ReplacementFor_dispatchAction, \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CINFO_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_WARNING_LOG
#  define ReplacementFor_CWARNING_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_el::Level::ReplacementFor_Warning, ReplacementFor_dispatchAction,\
 ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CWARNING_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_DEBUG_LOG
#  define ReplacementFor_CDEBUG_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_el::Level::ReplacementFor_Debug, ReplacementFor_dispatchAction, \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CDEBUG_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_ERROR_LOG
#  define ReplacementFor_CERROR_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_el::Level::Error, ReplacementFor_dispatchAction, \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CERROR_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_FATAL_LOG
#  define ReplacementFor_CFATAL_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_el::Level::ReplacementFor_Fatal, ReplacementFor_dispatchAction, \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CFATAL_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_TRACE_LOG
#  define ReplacementFor_CTRACE_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_el::Level::ReplacementFor_Trace, ReplacementFor_dispatchAction, \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CTRACE_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_VERBOSE_LOG
#  define ReplacementFor_CVERBOSE_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_vlevel, ReplacementFor_dispatchAction, ...)\
ReplacementFor_CVERBOSE_IF(ReplacementFor_writer, ReplacementFor_ELPP->\
ReplacementFor_validateAfterNCounter(__FILE__, __LINE__, n), \
ReplacementFor_vlevel, ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__\
)
#else
#  define ReplacementFor_CVERBOSE_AFTER_N(ReplacementFor_writer, n, \
ReplacementFor_vlevel, ReplacementFor_dispatchAction, ...) ReplacementFor_el::\
base::ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_INFO_LOG
#  define ReplacementFor_CINFO_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_el::Level::ReplacementFor_Info, ReplacementFor_dispatchAction, \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CINFO_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_WARNING_LOG
#  define ReplacementFor_CWARNING_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_el::Level::ReplacementFor_Warning, ReplacementFor_dispatchAction,\
 ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CWARNING_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_DEBUG_LOG
#  define ReplacementFor_CDEBUG_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_el::Level::ReplacementFor_Debug, ReplacementFor_dispatchAction, \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CDEBUG_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_ERROR_LOG
#  define ReplacementFor_CERROR_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_el::Level::Error, ReplacementFor_dispatchAction, \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CERROR_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_FATAL_LOG
#  define ReplacementFor_CFATAL_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_el::Level::ReplacementFor_Fatal, ReplacementFor_dispatchAction, \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CFATAL_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_TRACE_LOG
#  define ReplacementFor_CTRACE_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...)\
ReplacementFor_ELPP_WRITE_LOG_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_el::Level::ReplacementFor_Trace, ReplacementFor_dispatchAction, \
ReplacementFor___VA_ARGS__)
#else
#  define ReplacementFor_CTRACE_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_dispatchAction, ...) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#endif  
#if ReplacementFor_ELPP_VERBOSE_LOG
#  define ReplacementFor_CVERBOSE_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_vlevel, ReplacementFor_dispatchAction, ...)\
ReplacementFor_CVERBOSE_IF(ReplacementFor_writer, ReplacementFor_ELPP->\
ReplacementFor_validateNTimesCounter(__FILE__, __LINE__, n), \
ReplacementFor_vlevel, ReplacementFor_dispatchAction, ReplacementFor___VA_ARGS__\
)
#else
#  define ReplacementFor_CVERBOSE_N_TIMES(ReplacementFor_writer, n, \
ReplacementFor_vlevel, ReplacementFor_dispatchAction, ...) ReplacementFor_el::\
base::ReplacementFor_NullWriter()
#endif  
#undef CLOG
#undef ReplacementFor_CLOG_VERBOSE
#undef ReplacementFor_CVLOG
#undef ReplacementFor_CLOG_IF
#undef ReplacementFor_CLOG_VERBOSE_IF
#undef ReplacementFor_CVLOG_IF
#undef ReplacementFor_CLOG_EVERY_N
#undef ReplacementFor_CVLOG_EVERY_N
#undef ReplacementFor_CLOG_AFTER_N
#undef ReplacementFor_CVLOG_AFTER_N
#undef ReplacementFor_CLOG_N_TIMES
#undef ReplacementFor_CVLOG_N_TIMES
#define CLOG(ReplacementFor_LEVEL, ...)\
C##ReplacementFor_LEVEL(ReplacementFor_el::base::ReplacementFor_Writer, \
ReplacementFor_el::base::ReplacementFor_DispatchAction::ReplacementFor_NormalLog\
, ReplacementFor___VA_ARGS__)
#define ReplacementFor_CVLOG(ReplacementFor_vlevel, ...) ReplacementFor_CVERBOSE\
(ReplacementFor_el::base::ReplacementFor_Writer, ReplacementFor_vlevel, \
ReplacementFor_el::base::ReplacementFor_DispatchAction::ReplacementFor_NormalLog\
, ReplacementFor___VA_ARGS__)
#define ReplacementFor_CLOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL, \
...)\
C##ReplacementFor_LEVEL##ReplacementFor__IF(ReplacementFor_el::base::\
ReplacementFor_Writer, ReplacementFor_condition, ReplacementFor_el::base::\
ReplacementFor_DispatchAction::ReplacementFor_NormalLog, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_CVLOG_IF(ReplacementFor_condition, ReplacementFor_vlevel,\
 ...)\
ReplacementFor_CVERBOSE_IF(ReplacementFor_el::base::ReplacementFor_Writer, \
ReplacementFor_condition, ReplacementFor_vlevel, ReplacementFor_el::base::\
ReplacementFor_DispatchAction::ReplacementFor_NormalLog, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_CLOG_EVERY_N(n, ReplacementFor_LEVEL, ...)\
C##ReplacementFor_LEVEL##ReplacementFor__EVERY_N(ReplacementFor_el::base::\
ReplacementFor_Writer, n, ReplacementFor_el::base::ReplacementFor_DispatchAction\
::ReplacementFor_NormalLog, ReplacementFor___VA_ARGS__)
#define ReplacementFor_CVLOG_EVERY_N(n, ReplacementFor_vlevel, ...)\
ReplacementFor_CVERBOSE_EVERY_N(ReplacementFor_el::base::ReplacementFor_Writer, \
n, ReplacementFor_vlevel, ReplacementFor_el::base::ReplacementFor_DispatchAction\
::ReplacementFor_NormalLog, ReplacementFor___VA_ARGS__)
#define ReplacementFor_CLOG_AFTER_N(n, ReplacementFor_LEVEL, ...)\
C##ReplacementFor_LEVEL##ReplacementFor__AFTER_N(ReplacementFor_el::base::\
ReplacementFor_Writer, n, ReplacementFor_el::base::ReplacementFor_DispatchAction\
::ReplacementFor_NormalLog, ReplacementFor___VA_ARGS__)
#define ReplacementFor_CVLOG_AFTER_N(n, ReplacementFor_vlevel, ...)\
ReplacementFor_CVERBOSE_AFTER_N(ReplacementFor_el::base::ReplacementFor_Writer, \
n, ReplacementFor_vlevel, ReplacementFor_el::base::ReplacementFor_DispatchAction\
::ReplacementFor_NormalLog, ReplacementFor___VA_ARGS__)
#define ReplacementFor_CLOG_N_TIMES(n, ReplacementFor_LEVEL, ...)\
C##ReplacementFor_LEVEL##ReplacementFor__N_TIMES(ReplacementFor_el::base::\
ReplacementFor_Writer, n, ReplacementFor_el::base::ReplacementFor_DispatchAction\
::ReplacementFor_NormalLog, ReplacementFor___VA_ARGS__)
#define ReplacementFor_CVLOG_N_TIMES(n, ReplacementFor_vlevel, ...)\
ReplacementFor_CVERBOSE_N_TIMES(ReplacementFor_el::base::ReplacementFor_Writer, \
n, ReplacementFor_vlevel, ReplacementFor_el::base::ReplacementFor_DispatchAction\
::ReplacementFor_NormalLog, ReplacementFor___VA_ARGS__)
#undef LOG
#undef ReplacementFor_VLOG
#undef ReplacementFor_LOG_IF
#undef ReplacementFor_VLOG_IF
#undef ReplacementFor_LOG_EVERY_N
#undef ReplacementFor_VLOG_EVERY_N
#undef ReplacementFor_LOG_AFTER_N
#undef ReplacementFor_VLOG_AFTER_N
#undef ReplacementFor_LOG_N_TIMES
#undef ReplacementFor_VLOG_N_TIMES
#undef ReplacementFor_ELPP_CURR_FILE_LOGGER_ID
#if defined(ReplacementFor_ELPP_DEFAULT_LOGGER)
#  define ReplacementFor_ELPP_CURR_FILE_LOGGER_ID \
ReplacementFor_ELPP_DEFAULT_LOGGER
#else
#  define ReplacementFor_ELPP_CURR_FILE_LOGGER_ID ReplacementFor_el::base::\
ReplacementFor_consts::ReplacementFor_kDefaultLoggerId
#endif
#undef ReplacementFor_ELPP_TRACE
#define ReplacementFor_ELPP_TRACE CLOG(ReplacementFor_TRACE, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define LOG(ReplacementFor_LEVEL) CLOG(ReplacementFor_LEVEL, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_VLOG(ReplacementFor_vlevel) ReplacementFor_CVLOG(\
ReplacementFor_vlevel, ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_LOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL) \
ReplacementFor_CLOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_VLOG_IF(ReplacementFor_condition, ReplacementFor_vlevel) \
ReplacementFor_CVLOG_IF(ReplacementFor_condition, ReplacementFor_vlevel, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_LOG_EVERY_N(n, ReplacementFor_LEVEL) \
ReplacementFor_CLOG_EVERY_N(n, ReplacementFor_LEVEL, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_VLOG_EVERY_N(n, ReplacementFor_vlevel) \
ReplacementFor_CVLOG_EVERY_N(n, ReplacementFor_vlevel, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_LOG_AFTER_N(n, ReplacementFor_LEVEL) \
ReplacementFor_CLOG_AFTER_N(n, ReplacementFor_LEVEL, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_VLOG_AFTER_N(n, ReplacementFor_vlevel) \
ReplacementFor_CVLOG_AFTER_N(n, ReplacementFor_vlevel, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_LOG_N_TIMES(n, ReplacementFor_LEVEL) \
ReplacementFor_CLOG_N_TIMES(n, ReplacementFor_LEVEL, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_VLOG_N_TIMES(n, ReplacementFor_vlevel) \
ReplacementFor_CVLOG_N_TIMES(n, ReplacementFor_vlevel, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#undef ReplacementFor_CPLOG
#undef ReplacementFor_CPLOG_IF
#undef ReplacementFor_PLOG
#undef ReplacementFor_PLOG_IF
#undef ReplacementFor_DCPLOG
#undef ReplacementFor_DCPLOG_IF
#undef ReplacementFor_DPLOG
#undef ReplacementFor_DPLOG_IF
#define ReplacementFor_CPLOG(ReplacementFor_LEVEL, ...)\
C##ReplacementFor_LEVEL(ReplacementFor_el::base::ReplacementFor_PErrorWriter, \
ReplacementFor_el::base::ReplacementFor_DispatchAction::ReplacementFor_NormalLog\
, ReplacementFor___VA_ARGS__)
#define ReplacementFor_CPLOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL, \
...)\
C##ReplacementFor_LEVEL##ReplacementFor__IF(ReplacementFor_el::base::\
ReplacementFor_PErrorWriter, ReplacementFor_condition, ReplacementFor_el::base::\
ReplacementFor_DispatchAction::ReplacementFor_NormalLog, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCPLOG(ReplacementFor_LEVEL, ...)\
if (ReplacementFor_ELPP_DEBUG_LOG) C##ReplacementFor_LEVEL(ReplacementFor_el::\
base::ReplacementFor_PErrorWriter, ReplacementFor_el::base::\
ReplacementFor_DispatchAction::ReplacementFor_NormalLog, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCPLOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL,\
 ...)\
C##ReplacementFor_LEVEL##ReplacementFor__IF(ReplacementFor_el::base::\
ReplacementFor_PErrorWriter, (ReplacementFor_ELPP_DEBUG_LOG) && (\
ReplacementFor_condition), ReplacementFor_el::base::\
ReplacementFor_DispatchAction::ReplacementFor_NormalLog, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_PLOG(ReplacementFor_LEVEL) ReplacementFor_CPLOG(\
ReplacementFor_LEVEL, ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_PLOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL) \
ReplacementFor_CPLOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DPLOG(ReplacementFor_LEVEL) ReplacementFor_DCPLOG(\
ReplacementFor_LEVEL, ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DPLOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL) \
ReplacementFor_DCPLOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#undef ReplacementFor_CSYSLOG
#undef ReplacementFor_CSYSLOG_IF
#undef ReplacementFor_CSYSLOG_EVERY_N
#undef ReplacementFor_CSYSLOG_AFTER_N
#undef ReplacementFor_CSYSLOG_N_TIMES
#undef SYSLOG
#undef ReplacementFor_SYSLOG_IF
#undef ReplacementFor_SYSLOG_EVERY_N
#undef ReplacementFor_SYSLOG_AFTER_N
#undef ReplacementFor_SYSLOG_N_TIMES
#undef ReplacementFor_DCSYSLOG
#undef ReplacementFor_DCSYSLOG_IF
#undef ReplacementFor_DCSYSLOG_EVERY_N
#undef ReplacementFor_DCSYSLOG_AFTER_N
#undef ReplacementFor_DCSYSLOG_N_TIMES
#undef ReplacementFor_DSYSLOG
#undef ReplacementFor_DSYSLOG_IF
#undef ReplacementFor_DSYSLOG_EVERY_N
#undef ReplacementFor_DSYSLOG_AFTER_N
#undef ReplacementFor_DSYSLOG_N_TIMES
#if defined(ReplacementFor_ELPP_SYSLOG)
#  define ReplacementFor_CSYSLOG(ReplacementFor_LEVEL, ...)\
C##ReplacementFor_LEVEL(ReplacementFor_el::base::ReplacementFor_Writer, \
ReplacementFor_el::base::ReplacementFor_DispatchAction::SysLog, \
ReplacementFor___VA_ARGS__)
#  define ReplacementFor_CSYSLOG_IF(ReplacementFor_condition, \
ReplacementFor_LEVEL, ...)\
C##ReplacementFor_LEVEL##ReplacementFor__IF(ReplacementFor_el::base::\
ReplacementFor_Writer, ReplacementFor_condition, ReplacementFor_el::base::\
ReplacementFor_DispatchAction::SysLog, ReplacementFor___VA_ARGS__)
#  define ReplacementFor_CSYSLOG_EVERY_N(n, ReplacementFor_LEVEL, ...) C##\
ReplacementFor_LEVEL##ReplacementFor__EVERY_N(ReplacementFor_el::base::\
ReplacementFor_Writer, n, ReplacementFor_el::base::ReplacementFor_DispatchAction\
::SysLog, ReplacementFor___VA_ARGS__)
#  define ReplacementFor_CSYSLOG_AFTER_N(n, ReplacementFor_LEVEL, ...) C##\
ReplacementFor_LEVEL##ReplacementFor__AFTER_N(ReplacementFor_el::base::\
ReplacementFor_Writer, n, ReplacementFor_el::base::ReplacementFor_DispatchAction\
::SysLog, ReplacementFor___VA_ARGS__)
#  define ReplacementFor_CSYSLOG_N_TIMES(n, ReplacementFor_LEVEL, ...) C##\
ReplacementFor_LEVEL##ReplacementFor__N_TIMES(ReplacementFor_el::base::\
ReplacementFor_Writer, n, ReplacementFor_el::base::ReplacementFor_DispatchAction\
::SysLog, ReplacementFor___VA_ARGS__)
#  define SYSLOG(ReplacementFor_LEVEL) ReplacementFor_CSYSLOG(\
ReplacementFor_LEVEL, ReplacementFor_el::base::ReplacementFor_consts::\
ReplacementFor_kSysLogLoggerId)
#  define ReplacementFor_SYSLOG_IF(ReplacementFor_condition, \
ReplacementFor_LEVEL) ReplacementFor_CSYSLOG_IF(ReplacementFor_condition, \
ReplacementFor_LEVEL, ReplacementFor_el::base::ReplacementFor_consts::\
ReplacementFor_kSysLogLoggerId)
#  define ReplacementFor_SYSLOG_EVERY_N(n, ReplacementFor_LEVEL) \
ReplacementFor_CSYSLOG_EVERY_N(n, ReplacementFor_LEVEL, ReplacementFor_el::base\
::ReplacementFor_consts::ReplacementFor_kSysLogLoggerId)
#  define ReplacementFor_SYSLOG_AFTER_N(n, ReplacementFor_LEVEL) \
ReplacementFor_CSYSLOG_AFTER_N(n, ReplacementFor_LEVEL, ReplacementFor_el::base\
::ReplacementFor_consts::ReplacementFor_kSysLogLoggerId)
#  define ReplacementFor_SYSLOG_N_TIMES(n, ReplacementFor_LEVEL) \
ReplacementFor_CSYSLOG_N_TIMES(n, ReplacementFor_LEVEL, ReplacementFor_el::base\
::ReplacementFor_consts::ReplacementFor_kSysLogLoggerId)
#  define ReplacementFor_DCSYSLOG(ReplacementFor_LEVEL, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) C##ReplacementFor_LEVEL(ReplacementFor_el::base::\
ReplacementFor_Writer, ReplacementFor_el::base::ReplacementFor_DispatchAction::\
SysLog, ReplacementFor___VA_ARGS__)
#  define ReplacementFor_DCSYSLOG_IF(ReplacementFor_condition, \
ReplacementFor_LEVEL, ...)\
C##ReplacementFor_LEVEL##ReplacementFor__IF(ReplacementFor_el::base::\
ReplacementFor_Writer, (ReplacementFor_ELPP_DEBUG_LOG) && (\
ReplacementFor_condition), ReplacementFor_el::base::\
ReplacementFor_DispatchAction::SysLog, ReplacementFor___VA_ARGS__)
#  define ReplacementFor_DCSYSLOG_EVERY_N(n, ReplacementFor_LEVEL, ...)\
if (ReplacementFor_ELPP_DEBUG_LOG) C##ReplacementFor_LEVEL##\
ReplacementFor__EVERY_N(ReplacementFor_el::base::ReplacementFor_Writer, n, \
ReplacementFor_el::base::ReplacementFor_DispatchAction::SysLog, \
ReplacementFor___VA_ARGS__)
#  define ReplacementFor_DCSYSLOG_AFTER_N(n, ReplacementFor_LEVEL, ...)\
if (ReplacementFor_ELPP_DEBUG_LOG) C##ReplacementFor_LEVEL##\
ReplacementFor__AFTER_N(ReplacementFor_el::base::ReplacementFor_Writer, n, \
ReplacementFor_el::base::ReplacementFor_DispatchAction::SysLog, \
ReplacementFor___VA_ARGS__)
#  define ReplacementFor_DCSYSLOG_N_TIMES(n, ReplacementFor_LEVEL, ...)\
if (ReplacementFor_ELPP_DEBUG_LOG) C##ReplacementFor_LEVEL##\
ReplacementFor__EVERY_N(ReplacementFor_el::base::ReplacementFor_Writer, n, \
ReplacementFor_el::base::ReplacementFor_DispatchAction::SysLog, \
ReplacementFor___VA_ARGS__)
#  define ReplacementFor_DSYSLOG(ReplacementFor_LEVEL) ReplacementFor_DCSYSLOG(\
ReplacementFor_LEVEL, ReplacementFor_el::base::ReplacementFor_consts::\
ReplacementFor_kSysLogLoggerId)
#  define ReplacementFor_DSYSLOG_IF(ReplacementFor_condition, \
ReplacementFor_LEVEL) ReplacementFor_DCSYSLOG_IF(ReplacementFor_condition, \
ReplacementFor_LEVEL, ReplacementFor_el::base::ReplacementFor_consts::\
ReplacementFor_kSysLogLoggerId)
#  define ReplacementFor_DSYSLOG_EVERY_N(n, ReplacementFor_LEVEL) \
ReplacementFor_DCSYSLOG_EVERY_N(n, ReplacementFor_LEVEL, ReplacementFor_el::base\
::ReplacementFor_consts::ReplacementFor_kSysLogLoggerId)
#  define ReplacementFor_DSYSLOG_AFTER_N(n, ReplacementFor_LEVEL) \
ReplacementFor_DCSYSLOG_AFTER_N(n, ReplacementFor_LEVEL, ReplacementFor_el::base\
::ReplacementFor_consts::ReplacementFor_kSysLogLoggerId)
#  define ReplacementFor_DSYSLOG_N_TIMES(n, ReplacementFor_LEVEL) \
ReplacementFor_DCSYSLOG_N_TIMES(n, ReplacementFor_LEVEL, ReplacementFor_el::base\
::ReplacementFor_consts::ReplacementFor_kSysLogLoggerId)
#else
#  define ReplacementFor_CSYSLOG(ReplacementFor_LEVEL, ...) ReplacementFor_el::\
base::ReplacementFor_NullWriter()
#  define ReplacementFor_CSYSLOG_IF(ReplacementFor_condition, \
ReplacementFor_LEVEL, ...) ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_CSYSLOG_EVERY_N(n, ReplacementFor_LEVEL, ...) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_CSYSLOG_AFTER_N(n, ReplacementFor_LEVEL, ...) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_CSYSLOG_N_TIMES(n, ReplacementFor_LEVEL, ...) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define SYSLOG(ReplacementFor_LEVEL) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#  define ReplacementFor_SYSLOG_IF(ReplacementFor_condition, \
ReplacementFor_LEVEL) ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_SYSLOG_EVERY_N(n, ReplacementFor_LEVEL) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_SYSLOG_AFTER_N(n, ReplacementFor_LEVEL) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_SYSLOG_N_TIMES(n, ReplacementFor_LEVEL) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_DCSYSLOG(ReplacementFor_LEVEL, ...) ReplacementFor_el::\
base::ReplacementFor_NullWriter()
#  define ReplacementFor_DCSYSLOG_IF(ReplacementFor_condition, \
ReplacementFor_LEVEL, ...) ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_DCSYSLOG_EVERY_N(n, ReplacementFor_LEVEL, ...) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_DCSYSLOG_AFTER_N(n, ReplacementFor_LEVEL, ...) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_DCSYSLOG_N_TIMES(n, ReplacementFor_LEVEL, ...) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_DSYSLOG(ReplacementFor_LEVEL) ReplacementFor_el::base::\
ReplacementFor_NullWriter()
#  define ReplacementFor_DSYSLOG_IF(ReplacementFor_condition, \
ReplacementFor_LEVEL) ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_DSYSLOG_EVERY_N(n, ReplacementFor_LEVEL) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_DSYSLOG_AFTER_N(n, ReplacementFor_LEVEL) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#  define ReplacementFor_DSYSLOG_N_TIMES(n, ReplacementFor_LEVEL) \
ReplacementFor_el::base::ReplacementFor_NullWriter()
#endif  
#undef ReplacementFor_DCLOG
#undef ReplacementFor_DCVLOG
#undef ReplacementFor_DCLOG_IF
#undef ReplacementFor_DCVLOG_IF
#undef ReplacementFor_DCLOG_EVERY_N
#undef ReplacementFor_DCVLOG_EVERY_N
#undef ReplacementFor_DCLOG_AFTER_N
#undef ReplacementFor_DCVLOG_AFTER_N
#undef ReplacementFor_DCLOG_N_TIMES
#undef ReplacementFor_DCVLOG_N_TIMES
#define ReplacementFor_DCLOG(ReplacementFor_LEVEL, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) CLOG(ReplacementFor_LEVEL, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCLOG_VERBOSE(ReplacementFor_vlevel, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CLOG_VERBOSE(ReplacementFor_vlevel\
, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCVLOG(ReplacementFor_vlevel, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CVLOG(ReplacementFor_vlevel, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCLOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL, \
...) if (ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CLOG_IF(\
ReplacementFor_condition, ReplacementFor_LEVEL, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCVLOG_IF(ReplacementFor_condition, ReplacementFor_vlevel\
, ...) if (ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CVLOG_IF(\
ReplacementFor_condition, ReplacementFor_vlevel, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCLOG_EVERY_N(n, ReplacementFor_LEVEL, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CLOG_EVERY_N(n, \
ReplacementFor_LEVEL, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCVLOG_EVERY_N(n, ReplacementFor_vlevel, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CVLOG_EVERY_N(n, \
ReplacementFor_vlevel, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCLOG_AFTER_N(n, ReplacementFor_LEVEL, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CLOG_AFTER_N(n, \
ReplacementFor_LEVEL, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCVLOG_AFTER_N(n, ReplacementFor_vlevel, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CVLOG_AFTER_N(n, \
ReplacementFor_vlevel, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCLOG_N_TIMES(n, ReplacementFor_LEVEL, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CLOG_N_TIMES(n, \
ReplacementFor_LEVEL, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCVLOG_N_TIMES(n, ReplacementFor_vlevel, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CVLOG_N_TIMES(n, \
ReplacementFor_vlevel, ReplacementFor___VA_ARGS__)
#if !defined(ReplacementFor_ELPP_NO_DEBUG_MACROS)
#undef ReplacementFor_DLOG
#undef ReplacementFor_DVLOG
#undef ReplacementFor_DLOG_IF
#undef ReplacementFor_DVLOG_IF
#undef ReplacementFor_DLOG_EVERY_N
#undef ReplacementFor_DVLOG_EVERY_N
#undef ReplacementFor_DLOG_AFTER_N
#undef ReplacementFor_DVLOG_AFTER_N
#undef ReplacementFor_DLOG_N_TIMES
#undef ReplacementFor_DVLOG_N_TIMES
#define ReplacementFor_DLOG(ReplacementFor_LEVEL) ReplacementFor_DCLOG(\
ReplacementFor_LEVEL, ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DVLOG(ReplacementFor_vlevel) ReplacementFor_DCVLOG(\
ReplacementFor_vlevel, ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DLOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL) \
ReplacementFor_DCLOG_IF(ReplacementFor_condition, ReplacementFor_LEVEL, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DVLOG_IF(ReplacementFor_condition, ReplacementFor_vlevel)\
 ReplacementFor_DCVLOG_IF(ReplacementFor_condition, ReplacementFor_vlevel, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DLOG_EVERY_N(n, ReplacementFor_LEVEL) \
ReplacementFor_DCLOG_EVERY_N(n, ReplacementFor_LEVEL, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DVLOG_EVERY_N(n, ReplacementFor_vlevel) \
ReplacementFor_DCVLOG_EVERY_N(n, ReplacementFor_vlevel, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DLOG_AFTER_N(n, ReplacementFor_LEVEL) \
ReplacementFor_DCLOG_AFTER_N(n, ReplacementFor_LEVEL, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DVLOG_AFTER_N(n, ReplacementFor_vlevel) \
ReplacementFor_DCVLOG_AFTER_N(n, ReplacementFor_vlevel, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DLOG_N_TIMES(n, ReplacementFor_LEVEL) \
ReplacementFor_DCLOG_N_TIMES(n, ReplacementFor_LEVEL, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DVLOG_N_TIMES(n, ReplacementFor_vlevel) \
ReplacementFor_DCVLOG_N_TIMES(n, ReplacementFor_vlevel, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#endif 
#if !defined(ReplacementFor_ELPP_NO_CHECK_MACROS)
#undef ReplacementFor_CCHECK
#undef ReplacementFor_CPCHECK
#undef ReplacementFor_CCHECK_EQ
#undef ReplacementFor_CCHECK_NE
#undef ReplacementFor_CCHECK_LT
#undef ReplacementFor_CCHECK_GT
#undef ReplacementFor_CCHECK_LE
#undef ReplacementFor_CCHECK_GE
#undef ReplacementFor_CCHECK_BOUNDS
#undef ReplacementFor_CCHECK_NOTNULL
#undef ReplacementFor_CCHECK_STRCASEEQ
#undef ReplacementFor_CCHECK_STRCASENE
#undef ReplacementFor_CHECK
#undef ReplacementFor_PCHECK
#undef ReplacementFor_CHECK_EQ
#undef ReplacementFor_CHECK_NE
#undef ReplacementFor_CHECK_LT
#undef ReplacementFor_CHECK_GT
#undef ReplacementFor_CHECK_LE
#undef ReplacementFor_CHECK_GE
#undef ReplacementFor_CHECK_BOUNDS
#undef ReplacementFor_CHECK_NOTNULL
#undef ReplacementFor_CHECK_STRCASEEQ
#undef ReplacementFor_CHECK_STRCASENE
#define ReplacementFor_CCHECK(ReplacementFor_condition, ...) \
ReplacementFor_CLOG_IF(!(ReplacementFor_condition), ReplacementFor_FATAL, \
ReplacementFor___VA_ARGS__) << \
"\x43\x68\x65\x63\x6b\x20\x66\x61\x69\x6c\x65\x64\x3a\x20\x5b" << #\
ReplacementFor_condition << "\x5d\x20"
#define ReplacementFor_CPCHECK(ReplacementFor_condition, ...) \
ReplacementFor_CPLOG_IF(!(ReplacementFor_condition), ReplacementFor_FATAL, \
ReplacementFor___VA_ARGS__) << \
"\x43\x68\x65\x63\x6b\x20\x66\x61\x69\x6c\x65\x64\x3a\x20\x5b" << #\
ReplacementFor_condition << "\x5d\x20"
#define ReplacementFor_CHECK(ReplacementFor_condition) ReplacementFor_CCHECK(\
ReplacementFor_condition, ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_PCHECK(ReplacementFor_condition) ReplacementFor_CPCHECK(\
ReplacementFor_condition, ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CCHECK_EQ(a, b, ...) ReplacementFor_CCHECK(a == b, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_CCHECK_NE(a, b, ...) ReplacementFor_CCHECK(a != b, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_CCHECK_LT(a, b, ...) ReplacementFor_CCHECK(a < b, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_CCHECK_GT(a, b, ...) ReplacementFor_CCHECK(a > b, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_CCHECK_LE(a, b, ...) ReplacementFor_CCHECK(a <= b, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_CCHECK_GE(a, b, ...) ReplacementFor_CCHECK(a >= b, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_CCHECK_BOUNDS(val, min, max, ...) ReplacementFor_CCHECK(\
val >= min && val <= max, ReplacementFor___VA_ARGS__)
#define ReplacementFor_CHECK_EQ(a, b) ReplacementFor_CCHECK_EQ(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CHECK_NE(a, b) ReplacementFor_CCHECK_NE(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CHECK_LT(a, b) ReplacementFor_CCHECK_LT(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CHECK_GT(a, b) ReplacementFor_CCHECK_GT(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CHECK_LE(a, b) ReplacementFor_CCHECK_LE(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CHECK_GE(a, b) ReplacementFor_CCHECK_GE(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CHECK_BOUNDS(val, min, max) ReplacementFor_CCHECK_BOUNDS(\
val, min, max, ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CCHECK_NOTNULL(ReplacementFor_ptr, ...) \
ReplacementFor_CCHECK((ReplacementFor_ptr) != nullptr, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_CCHECK_STREQ(ReplacementFor_str1, ReplacementFor_str2, \
...) ReplacementFor_CLOG_IF(!ReplacementFor_el::base::ReplacementFor_utils::Str\
::ReplacementFor_cStringEq(ReplacementFor_str1, ReplacementFor_str2), \
ReplacementFor_FATAL, ReplacementFor___VA_ARGS__) \
<< "\x43\x68\x65\x63\x6b\x20\x66\x61\x69\x6c\x65\x64\x3a\x20\x5b" << #\
ReplacementFor_str1 << "\x20\x3d\x3d\x20" << #ReplacementFor_str2 << "\x5d\x20"
#define ReplacementFor_CCHECK_STRNE(ReplacementFor_str1, ReplacementFor_str2, \
...) ReplacementFor_CLOG_IF(ReplacementFor_el::base::ReplacementFor_utils::Str::\
ReplacementFor_cStringEq(ReplacementFor_str1, ReplacementFor_str2), \
ReplacementFor_FATAL, ReplacementFor___VA_ARGS__) \
<< "\x43\x68\x65\x63\x6b\x20\x66\x61\x69\x6c\x65\x64\x3a\x20\x5b" << #\
ReplacementFor_str1 << "\x20\x21\x3d\x20" << #ReplacementFor_str2 << "\x5d\x20"
#define ReplacementFor_CCHECK_STRCASEEQ(ReplacementFor_str1, ReplacementFor_str2\
, ...) ReplacementFor_CLOG_IF(!ReplacementFor_el::base::ReplacementFor_utils::\
Str::ReplacementFor_cStringCaseEq(ReplacementFor_str1, ReplacementFor_str2), \
ReplacementFor_FATAL, ReplacementFor___VA_ARGS__) \
<< "\x43\x68\x65\x63\x6b\x20\x66\x61\x69\x6c\x65\x64\x3a\x20\x5b" << #\
ReplacementFor_str1 << "\x20\x3d\x3d\x20" << #ReplacementFor_str2 << "\x5d\x20"
#define ReplacementFor_CCHECK_STRCASENE(ReplacementFor_str1, ReplacementFor_str2\
, ...) ReplacementFor_CLOG_IF(ReplacementFor_el::base::ReplacementFor_utils::Str\
::ReplacementFor_cStringCaseEq(ReplacementFor_str1, ReplacementFor_str2), \
ReplacementFor_FATAL, ReplacementFor___VA_ARGS__) \
<< "\x43\x68\x65\x63\x6b\x20\x66\x61\x69\x6c\x65\x64\x3a\x20\x5b" << #\
ReplacementFor_str1 << "\x20\x21\x3d\x20" << #ReplacementFor_str2 << "\x5d\x20"
#define ReplacementFor_CHECK_NOTNULL(ReplacementFor_ptr) \
ReplacementFor_CCHECK_NOTNULL((ReplacementFor_ptr), \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CHECK_STREQ(ReplacementFor_str1, ReplacementFor_str2) \
ReplacementFor_CCHECK_STREQ(ReplacementFor_str1, ReplacementFor_str2, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CHECK_STRNE(ReplacementFor_str1, ReplacementFor_str2) \
ReplacementFor_CCHECK_STRNE(ReplacementFor_str1, ReplacementFor_str2, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CHECK_STRCASEEQ(ReplacementFor_str1, ReplacementFor_str2)\
 ReplacementFor_CCHECK_STRCASEEQ(ReplacementFor_str1, ReplacementFor_str2, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_CHECK_STRCASENE(ReplacementFor_str1, ReplacementFor_str2)\
 ReplacementFor_CCHECK_STRCASENE(ReplacementFor_str1, ReplacementFor_str2, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#undef ReplacementFor_DCCHECK
#undef ReplacementFor_DCCHECK_EQ
#undef ReplacementFor_DCCHECK_NE
#undef ReplacementFor_DCCHECK_LT
#undef ReplacementFor_DCCHECK_GT
#undef ReplacementFor_DCCHECK_LE
#undef ReplacementFor_DCCHECK_GE
#undef ReplacementFor_DCCHECK_BOUNDS
#undef ReplacementFor_DCCHECK_NOTNULL
#undef ReplacementFor_DCCHECK_STRCASEEQ
#undef ReplacementFor_DCCHECK_STRCASENE
#undef ReplacementFor_DCPCHECK
#undef ReplacementFor_DCHECK
#undef ReplacementFor_DCHECK_EQ
#undef ReplacementFor_DCHECK_NE
#undef ReplacementFor_DCHECK_LT
#undef ReplacementFor_DCHECK_GT
#undef ReplacementFor_DCHECK_LE
#undef ReplacementFor_DCHECK_GE
#undef ReplacementFor_DCHECK_BOUNDS_
#undef ReplacementFor_DCHECK_NOTNULL
#undef ReplacementFor_DCHECK_STRCASEEQ
#undef ReplacementFor_DCHECK_STRCASENE
#undef ReplacementFor_DPCHECK
#define ReplacementFor_DCCHECK(ReplacementFor_condition, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CCHECK(ReplacementFor_condition, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_EQ(a, b, ...) if (ReplacementFor_ELPP_DEBUG_LOG) \
ReplacementFor_CCHECK_EQ(a, b, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_NE(a, b, ...) if (ReplacementFor_ELPP_DEBUG_LOG) \
ReplacementFor_CCHECK_NE(a, b, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_LT(a, b, ...) if (ReplacementFor_ELPP_DEBUG_LOG) \
ReplacementFor_CCHECK_LT(a, b, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_GT(a, b, ...) if (ReplacementFor_ELPP_DEBUG_LOG) \
ReplacementFor_CCHECK_GT(a, b, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_LE(a, b, ...) if (ReplacementFor_ELPP_DEBUG_LOG) \
ReplacementFor_CCHECK_LE(a, b, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_GE(a, b, ...) if (ReplacementFor_ELPP_DEBUG_LOG) \
ReplacementFor_CCHECK_GE(a, b, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_BOUNDS(val, min, max, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CCHECK_BOUNDS(val, min, max, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_NOTNULL(ReplacementFor_ptr, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CCHECK_NOTNULL((ReplacementFor_ptr\
), ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_STREQ(ReplacementFor_str1, ReplacementFor_str2, \
...) if (ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CCHECK_STREQ(\
ReplacementFor_str1, ReplacementFor_str2, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_STRNE(ReplacementFor_str1, ReplacementFor_str2, \
...) if (ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CCHECK_STRNE(\
ReplacementFor_str1, ReplacementFor_str2, ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_STRCASEEQ(ReplacementFor_str1, \
ReplacementFor_str2, ...) if (ReplacementFor_ELPP_DEBUG_LOG) \
ReplacementFor_CCHECK_STRCASEEQ(ReplacementFor_str1, ReplacementFor_str2, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCCHECK_STRCASENE(ReplacementFor_str1, \
ReplacementFor_str2, ...) if (ReplacementFor_ELPP_DEBUG_LOG) \
ReplacementFor_CCHECK_STRCASENE(ReplacementFor_str1, ReplacementFor_str2, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCPCHECK(ReplacementFor_condition, ...) if (\
ReplacementFor_ELPP_DEBUG_LOG) ReplacementFor_CPCHECK(ReplacementFor_condition, \
ReplacementFor___VA_ARGS__)
#define ReplacementFor_DCHECK(ReplacementFor_condition) ReplacementFor_DCCHECK(\
ReplacementFor_condition, ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_EQ(a, b) ReplacementFor_DCCHECK_EQ(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_NE(a, b) ReplacementFor_DCCHECK_NE(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_LT(a, b) ReplacementFor_DCCHECK_LT(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_GT(a, b) ReplacementFor_DCCHECK_GT(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_LE(a, b) ReplacementFor_DCCHECK_LE(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_GE(a, b) ReplacementFor_DCCHECK_GE(a, b, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_BOUNDS(val, min, max) \
ReplacementFor_DCCHECK_BOUNDS(val, min, max, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_NOTNULL(ReplacementFor_ptr) \
ReplacementFor_DCCHECK_NOTNULL((ReplacementFor_ptr), \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_STREQ(ReplacementFor_str1, ReplacementFor_str2) \
ReplacementFor_DCCHECK_STREQ(ReplacementFor_str1, ReplacementFor_str2, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_STRNE(ReplacementFor_str1, ReplacementFor_str2) \
ReplacementFor_DCCHECK_STRNE(ReplacementFor_str1, ReplacementFor_str2, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_STRCASEEQ(ReplacementFor_str1, ReplacementFor_str2\
) ReplacementFor_DCCHECK_STRCASEEQ(ReplacementFor_str1, ReplacementFor_str2, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DCHECK_STRCASENE(ReplacementFor_str1, ReplacementFor_str2\
) ReplacementFor_DCCHECK_STRCASENE(ReplacementFor_str1, ReplacementFor_str2, \
ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#define ReplacementFor_DPCHECK(ReplacementFor_condition) ReplacementFor_DCPCHECK\
(ReplacementFor_condition, ReplacementFor_ELPP_CURR_FILE_LOGGER_ID)
#endif 
#if defined(ReplacementFor_ELPP_DISABLE_DEFAULT_CRASH_HANDLING)
#  define ReplacementFor_ELPP_USE_DEF_CRASH_HANDLER false
#else
#  define ReplacementFor_ELPP_USE_DEF_CRASH_HANDLER true
#endif  
#define ReplacementFor_ELPP_CRASH_HANDLER_INIT
#define ReplacementFor_ELPP_INIT_EASYLOGGINGPP(val) \
namespace ReplacementFor_el { \
namespace base { \
ReplacementFor_el::base::type::ReplacementFor_StoragePointer \
ReplacementFor_elStorage(val); \
} \
ReplacementFor_el::base::ReplacementFor_debug::ReplacementFor_CrashHandler \
ReplacementFor_elCrashHandler(ReplacementFor_ELPP_USE_DEF_CRASH_HANDLER); \
}
#if ReplacementFor_ELPP_ASYNC_LOGGING
#  define ReplacementFor_INITIALIZE_EASYLOGGINGPP \
ReplacementFor_ELPP_INIT_EASYLOGGINGPP(new ReplacementFor_el::base::\
ReplacementFor_Storage(ReplacementFor_el::ReplacementFor_LogBuilderPtr(new \
ReplacementFor_el::base::ReplacementFor_DefaultLogBuilder()),\
new ReplacementFor_el::base::ReplacementFor_AsyncDispatchWorker()))
#else
#  define ReplacementFor_INITIALIZE_EASYLOGGINGPP \
ReplacementFor_ELPP_INIT_EASYLOGGINGPP(new ReplacementFor_el::base::\
ReplacementFor_Storage(ReplacementFor_el::ReplacementFor_LogBuilderPtr(new \
ReplacementFor_el::base::ReplacementFor_DefaultLogBuilder())))
#endif  
#define ReplacementFor_INITIALIZE_NULL_EASYLOGGINGPP \
namespace ReplacementFor_el {\
namespace base {\
ReplacementFor_el::base::type::ReplacementFor_StoragePointer \
ReplacementFor_elStorage;\
}\
ReplacementFor_el::base::ReplacementFor_debug::ReplacementFor_CrashHandler \
ReplacementFor_elCrashHandler(ReplacementFor_ELPP_USE_DEF_CRASH_HANDLER);\
}
#define ReplacementFor_SHARE_EASYLOGGINGPP(ReplacementFor_initializedStorage)\
namespace ReplacementFor_el {\
namespace base {\
ReplacementFor_el::base::type::ReplacementFor_StoragePointer \
ReplacementFor_elStorage(ReplacementFor_initializedStorage);\
}\
ReplacementFor_el::base::ReplacementFor_debug::ReplacementFor_CrashHandler \
ReplacementFor_elCrashHandler(ReplacementFor_ELPP_USE_DEF_CRASH_HANDLER);\
}
#if defined(ReplacementFor_ELPP_UNICODE)
#  define ReplacementFor_START_EASYLOGGINGPP(ReplacementFor_argc, \
ReplacementFor_argv) ReplacementFor_el::ReplacementFor_Helpers::\
ReplacementFor_setArgs(ReplacementFor_argc, ReplacementFor_argv); std::locale::\
global(std::locale(""))
#else
#  define ReplacementFor_START_EASYLOGGINGPP(ReplacementFor_argc, \
ReplacementFor_argv) ReplacementFor_el::ReplacementFor_Helpers::\
ReplacementFor_setArgs(ReplacementFor_argc, ReplacementFor_argv)
#endif  
#endif 


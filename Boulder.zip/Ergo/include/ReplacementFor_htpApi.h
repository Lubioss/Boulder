
#ifndef ReplacementFor_ReplacementFor_HTTPAPI_H
#define ReplacementFor_ReplacementFor_HTTPAPI_H
#include "ReplacementFor_htpLob.h"
#include <vector>
#include <string>
#include <nvml.h>
#include <unordered_map>
#include <sstream>
#include <chrono>
void ReplacementFor_ReplacementFor_HtpApiThread(std::vector<double>*ReplacementFor_ReplacementFor_hashrates,
std::vector<std::pair<int,int>>*ReplacementFor_ReplacementFor_props);
#endif



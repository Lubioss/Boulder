
#ifndef ReplacementFor_CPPHTTPLIB_HTTPLIB_H
#define ReplacementFor_CPPHTTPLIB_HTTPLIB_H
#ifndef ReplacementFor_CPPHTTPLIB_KEEPALIVE_TIMEOUT_SECOND
#define ReplacementFor_CPPHTTPLIB_KEEPALIVE_TIMEOUT_SECOND ((0x22f3+7996-0x2672)\
+(0xe30+4092-0x1cf8)-(0x23c7+3933-0x1638))
#endif
#ifndef ReplacementFor_CPPHTTPLIB_KEEPALIVE_MAX_COUNT
#define ReplacementFor_CPPHTTPLIB_KEEPALIVE_MAX_COUNT (4064+(0xb23+383-0x5c3)-\
(0x268f+3101-0x1bf2))
#endif
#ifndef ReplacementFor_CPPHTTPLIB_CONNECTION_TIMEOUT_SECOND
#define ReplacementFor_CPPHTTPLIB_CONNECTION_TIMEOUT_SECOND (6999+\
(0x13bf+2685-0x13b4)-9395)
#endif
#ifndef ReplacementFor_CPPHTTPLIB_CONNECTION_TIMEOUT_USECOND
#define ReplacementFor_CPPHTTPLIB_CONNECTION_TIMEOUT_USECOND (8995+\
(0x19b5+3428-0x259b)-9377)
#endif
#ifndef ReplacementFor_CPPHTTPLIB_READ_TIMEOUT_SECOND
#define ReplacementFor_CPPHTTPLIB_READ_TIMEOUT_SECOND ((0x135c+5078-0x24da)+7325\
-7920)
#endif
#ifndef ReplacementFor_CPPHTTPLIB_READ_TIMEOUT_USECOND
#define ReplacementFor_CPPHTTPLIB_READ_TIMEOUT_USECOND ((0x121b+4630-0x2317)+\
(0x1090+5137-0x225d)-(0x126a+2499-0x18cf))
#endif
#ifndef ReplacementFor_CPPHTTPLIB_WRITE_TIMEOUT_SECOND
#define ReplacementFor_CPPHTTPLIB_WRITE_TIMEOUT_SECOND ((0x1d2a+402-0x1a7f)+6266\
-7346)
#endif
#ifndef ReplacementFor_CPPHTTPLIB_WRITE_TIMEOUT_USECOND
#define ReplacementFor_CPPHTTPLIB_WRITE_TIMEOUT_USECOND ((0xfcc+1417-0x73e)+\
(0x479+3447-0x1073)-3988)
#endif
#ifndef ReplacementFor_CPPHTTPLIB_IDLE_INTERVAL_SECOND
#define ReplacementFor_CPPHTTPLIB_IDLE_INTERVAL_SECOND ((0x1952+8162-0x21a5)+\
(0x1301+5265-0x1d85)-8604)
#endif
#ifndef ReplacementFor_CPPHTTPLIB_IDLE_INTERVAL_USECOND
#ifdef _WIN32
#define ReplacementFor_CPPHTTPLIB_IDLE_INTERVAL_USECOND 10000
#else
#define ReplacementFor_CPPHTTPLIB_IDLE_INTERVAL_USECOND ((0x569+6608-0x1b88)+\
4847-5792)
#endif
#endif
#ifndef ReplacementFor_CPPHTTPLIB_REQUEST_URI_MAX_LENGTH
#define ReplacementFor_CPPHTTPLIB_REQUEST_URI_MAX_LENGTH 8192
#endif
#ifndef ReplacementFor_CPPHTTPLIB_REDIRECT_MAX_COUNT
#define ReplacementFor_CPPHTTPLIB_REDIRECT_MAX_COUNT ((0x21ed+2760-0xec0)+\
(0x1408+4884-0x2619)-7908)
#endif
#ifndef ReplacementFor_CPPHTTPLIB_PAYLOAD_MAX_LENGTH
#define ReplacementFor_CPPHTTPLIB_PAYLOAD_MAX_LENGTH ((std::numeric_limits<\
size_t>::max)())
#endif
#ifndef ReplacementFor_CPPHTTPLIB_TCP_NODELAY
#define ReplacementFor_CPPHTTPLIB_TCP_NODELAY false
#endif
#ifndef ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ
#define ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ size_t(4096u)
#endif
#ifndef ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ
#define ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ size_t(16384u)
#endif
#ifndef ReplacementFor_CPPHTTPLIB_THREAD_POOL_COUNT
#define ReplacementFor_CPPHTTPLIB_THREAD_POOL_COUNT\
                                           \
  ((std::max)(8u, std::thread::hardware_concurrency() > ((0x1dcf+1438-0x1d35)+\
(0x22f0+732-0x24f1)-(0x16b4+1330-0x14d3))\
                      \
                      ? std::thread::hardware_concurrency() - (\
(0xab7+4833-0x1d15)+(0x17ea+2341-0x947)-(0x2210+2897-0x1517))\
                \
                      : ((0x70c+688-0x62c)+7419-8331)))
#endif
#ifndef ReplacementFor_CPPHTTPLIB_RECV_FLAGS
#define ReplacementFor_CPPHTTPLIB_RECV_FLAGS (9818+(0xdfa+4090-0x1d4a)-9988)
#endif
#ifndef ReplacementFor_CPPHTTPLIB_SEND_FLAGS
#define ReplacementFor_CPPHTTPLIB_SEND_FLAGS ((0xe8c+8525-0x2441)+\
(0x258a+3200-0x247f)-6435)
#endif
#ifdef _WIN32
#ifndef ReplacementFor__CRT_SECURE_NO_WARNINGS
#define ReplacementFor__CRT_SECURE_NO_WARNINGS
#endif 
#ifndef ReplacementFor__CRT_NONSTDC_NO_DEPRECATE
#define ReplacementFor__CRT_NONSTDC_NO_DEPRECATE
#endif 
#if defined(_MSC_VER)
#ifdef ReplacementFor__WIN64
using ssize_t=__int64;
#else
using ssize_t=int;
#endif
#if _MSC_VER < ((0x2413+6169-0x205f)+(0xe9b+3591-0x1537)-(0x2451+4796-0x1b41))
#define snprintf ReplacementFor__snprintf_s
#endif
#endif 
#ifndef S_ISREG
#define S_ISREG(m) (((m)&S_IFREG) == S_IFREG)
#endif 
#ifndef S_ISDIR
#define S_ISDIR(m) (((m)&S_IFDIR) == S_IFDIR)
#endif 
#ifndef NOMINMAX
#define NOMINMAX
#endif 
#include <io.h>
#include <winsock2.h>
#include <wincrypt.h>
#include <ws2tcpip.h>
#ifndef ReplacementFor_WSA_FLAG_NO_HANDLE_INHERIT
#define ReplacementFor_WSA_FLAG_NO_HANDLE_INHERIT (4422+1999-(0x19f1+2222-0xa0a)\
)
#endif
#ifdef _MSC_VER
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "cryptui.lib")
#endif
#ifndef strcasecmp
#define strcasecmp _stricmp
#endif 
using ReplacementFor_socket_t=SOCKET;
#ifdef ReplacementFor_CPPHTTPLIB_USE_POLL
#define poll(ReplacementFor_fds, ReplacementFor_nfds, timeout) \
ReplacementFor_WSAPoll(ReplacementFor_fds, ReplacementFor_nfds, timeout)
#endif
#else 
#include <arpa/inet.h>
#include <cstring>
#include <ifaddrs.h>
#include <netdb.h>
#include <netinet/in.h>
#ifdef ReplacementFor___linux__
#include <resolv.h>
#endif
#include <netinet/tcp.h>
#ifdef ReplacementFor_CPPHTTPLIB_USE_POLL
#include <poll.h>
#endif
#include <csignal>
#include <pthread.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <unistd.h>
using ReplacementFor_socket_t=int;
#define INVALID_SOCKET (-(8183+(0x61+4815-0x1313)-8211))
#endif 
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <cctype>
#include <climits>
#include <condition_variable>
#include <errno.h>
#include <fcntl.h>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <memory>
#include <mutex>
#include <random>
#include <regex>
#include <sstream>
#include <string>
#include <sys/stat.h>
#include <thread>
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
#include <openssl/err.h>
#include <openssl/md5.h>
#include <openssl/ssl.h>
#include <openssl/x509v3.h>
#if defined(_WIN32) && defined(ReplacementFor_OPENSSL_USE_APPLINK)
#include <openssl/applink.c>
#endif
#include <iostream>
#include <sstream>
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x1010100fL
#error Sorry, OpenSSL versions prior to 1.1.1 are not supported
#endif
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x10100000L
#include <openssl/crypto.h>
inline const unsigned char*ReplacementFor_ASN1_STRING_get0_data(const 
ReplacementFor_ASN1_STRING*ReplacementFor_asn1){return 
ReplacementFor_M_ASN1_STRING_data(ReplacementFor_asn1);}
#endif
#endif
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
#include <zlib.h>
#endif
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
#include <brotli/decode.h>
#include <brotli/encode.h>
#endif
namespace ReplacementFor_htpLob{namespace ReplacementFor_detail{template<class T
,class...ReplacementFor_Args>typename std::enable_if<!std::is_array<T>::value,
std::unique_ptr<T>>::type make_unique(ReplacementFor_Args&&...
ReplacementFor_args){return std::unique_ptr<T>(new T(std::forward<
ReplacementFor_Args>(ReplacementFor_args)...));}template<class T>typename std::
enable_if<std::is_array<T>::value,std::unique_ptr<T>>::type make_unique(std::
size_t n){typedef typename std::remove_extent<T>::type ReplacementFor_RT;return 
std::unique_ptr<T>(new ReplacementFor_RT[n]);}struct ReplacementFor_ci{bool 
operator()(const std::string&ReplacementFor_s1,const std::string&
ReplacementFor_s2)const{return std::lexicographical_compare(ReplacementFor_s1.
begin(),ReplacementFor_s1.end(),ReplacementFor_s2.begin(),ReplacementFor_s2.end(
),[](unsigned char ReplacementFor_c1,unsigned char ReplacementFor_c2){return::
tolower(ReplacementFor_c1)< ::tolower(ReplacementFor_c2);});}};}using 
ReplacementFor_Headers=std::multimap<std::string,std::string,
ReplacementFor_detail::ReplacementFor_ci>;using ReplacementFor_Params=std::
multimap<std::string,std::string>;using ReplacementFor_Match=std::smatch;using 
ReplacementFor_Progress=std::function<bool(uint64_t current,uint64_t 
ReplacementFor_total)>;struct ReplacementFor_Response;using 
ReplacementFor_ResponseHandler=std::function<bool(const ReplacementFor_Response&
ReplacementFor_response)>;struct ReplacementFor_MultipartFormData{std::string 
name;std::string ReplacementFor_content;std::string ReplacementFor_filename;std
::string ReplacementFor_content_type;};using 
ReplacementFor_MultipartFormDataItems=std::vector<
ReplacementFor_MultipartFormData>;using ReplacementFor_MultipartFormDataMap=std
::multimap<std::string,ReplacementFor_MultipartFormData>;class 
ReplacementFor_DataSink{public:ReplacementFor_DataSink():os(&ReplacementFor_sb_)
,ReplacementFor_sb_(*this){}ReplacementFor_DataSink(const 
ReplacementFor_DataSink&)=delete;ReplacementFor_DataSink&operator=(const 
ReplacementFor_DataSink&)=delete;ReplacementFor_DataSink(ReplacementFor_DataSink
&&)=delete;ReplacementFor_DataSink&operator=(ReplacementFor_DataSink&&)=delete;
std::function<void(const char*data,size_t ReplacementFor_data_len)>write;std::
function<void()>done;std::function<bool()>ReplacementFor_is_writable;std::
ostream os;private:class ReplacementFor_data_sink_streambuf:public std::
streambuf{public:explicit ReplacementFor_data_sink_streambuf(
ReplacementFor_DataSink&ReplacementFor_sink):ReplacementFor_sink_(
ReplacementFor_sink){}protected:std::streamsize xsputn(const char*s,std::
streamsize n){ReplacementFor_sink_.write(s,static_cast<size_t>(n));return n;}
private:ReplacementFor_DataSink&ReplacementFor_sink_;};
ReplacementFor_data_sink_streambuf ReplacementFor_sb_;};using 
ReplacementFor_ContentProvider=std::function<bool(size_t offset,size_t length,
ReplacementFor_DataSink&ReplacementFor_sink)>;using 
ReplacementFor_ContentProviderWithoutLength=std::function<bool(size_t offset,
ReplacementFor_DataSink&ReplacementFor_sink)>;using 
ReplacementFor_ContentReceiverWithProgress=std::function<bool(const char*data,
size_t ReplacementFor_data_length,uint64_t offset,uint64_t 
ReplacementFor_total_length)>;using ReplacementFor_ContentReceiver=std::function
<bool(const char*data,size_t ReplacementFor_data_length)>;using 
ReplacementFor_MultipartContentHeader=std::function<bool(const 
ReplacementFor_MultipartFormData&ReplacementFor_file)>;class 
ReplacementFor_ContentReader{public:using ReplacementFor_Reader=std::function<
bool(ReplacementFor_ContentReceiver ReplacementFor_receiver)>;using 
ReplacementFor_MultipartReader=std::function<bool(
ReplacementFor_MultipartContentHeader header,ReplacementFor_ContentReceiver 
ReplacementFor_receiver)>;ReplacementFor_ContentReader(ReplacementFor_Reader 
ReplacementFor_reader,ReplacementFor_MultipartReader 
ReplacementFor_multipart_reader):ReplacementFor_reader_(std::move(
ReplacementFor_reader)),ReplacementFor_multipart_reader_(std::move(
ReplacementFor_multipart_reader)){}bool operator()(
ReplacementFor_MultipartContentHeader header,ReplacementFor_ContentReceiver 
ReplacementFor_receiver)const{return ReplacementFor_multipart_reader_(std::move(
header),std::move(ReplacementFor_receiver));}bool operator()(
ReplacementFor_ContentReceiver ReplacementFor_receiver)const{return 
ReplacementFor_reader_(std::move(ReplacementFor_receiver));}
ReplacementFor_Reader ReplacementFor_reader_;ReplacementFor_MultipartReader 
ReplacementFor_multipart_reader_;};using ReplacementFor_Range=std::pair<ssize_t,
ssize_t>;using Ranges=std::vector<ReplacementFor_Range>;struct 
ReplacementFor_Request{std::string ReplacementFor_method;std::string 
ReplacementFor_path;ReplacementFor_Headers ReplacementFor_headers;std::string 
ReplacementFor_body;std::string ReplacementFor_remote_addr;int 
ReplacementFor_remote_port=-((0x1f60+553-0x99e)+(0x86f+9004-0x257d)-7688);std::
string ReplacementFor_version;std::string target;ReplacementFor_Params 
ReplacementFor_params;ReplacementFor_MultipartFormDataMap ReplacementFor_files;
Ranges ranges;ReplacementFor_Match ReplacementFor_matches;
ReplacementFor_ResponseHandler ReplacementFor_response_handler;
ReplacementFor_ContentReceiverWithProgress ReplacementFor_content_receiver;
ReplacementFor_Progress ReplacementFor_progress;
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
const ReplacementFor_SSL*ReplacementFor_ssl;
#endif
bool ReplacementFor_has_header(const char*key)const;std::string 
ReplacementFor_get_header_value(const char*key,size_t id=((0xac3+7546-0x2421)+
(0x2121+5217-0x152a)-9332))const;template<typename T>T 
ReplacementFor_get_header_value(const char*key,size_t id=((0xe7d+7008-0x2234)+
(0x1a04+1654-0x1002)-6177))const;size_t ReplacementFor_get_header_value_count(
const char*key)const;void ReplacementFor_set_header(const char*key,const char*
val);void ReplacementFor_set_header(const char*key,const std::string&val);bool 
ReplacementFor_has_param(const char*key)const;std::string 
ReplacementFor_get_param_value(const char*key,size_t id=((0x12a2+3956-0x21ad)+
(0x22fa+6155-0x1f17)-7255))const;size_t ReplacementFor_get_param_value_count(
const char*key)const;bool ReplacementFor_is_multipart_form_data()const;bool 
ReplacementFor_has_file(const char*key)const;ReplacementFor_MultipartFormData 
ReplacementFor_get_file_value(const char*key)const;size_t 
ReplacementFor_redirect_count_=ReplacementFor_CPPHTTPLIB_REDIRECT_MAX_COUNT;
size_t ReplacementFor_content_length_=((0x25c8+1593-0x24b1)+(0x103b+2119-0x1691)
-(0x22eb+2498-0x236c));ReplacementFor_ContentProvider 
ReplacementFor_content_provider_;bool 
ReplacementFor_is_chunked_content_provider_=false;size_t 
ReplacementFor_authorization_count_=((0x1fd2+1029-0xf9c)+(0xdaa+5154-0x1b60)-
6823);};struct ReplacementFor_Response{std::string ReplacementFor_version;int 
status=-(4406+(0x14fd+1674-0xe96)-(0x22e8+6036-0x1c56));std::string 
ReplacementFor_reason;ReplacementFor_Headers ReplacementFor_headers;std::string 
ReplacementFor_body;std::string ReplacementFor_location;bool 
ReplacementFor_has_header(const char*key)const;std::string 
ReplacementFor_get_header_value(const char*key,size_t id=((0x3d0+1194-0x5d7)+
(0x1ac0+508-0xdaa)-(0x1866+4515-0x1854)))const;template<typename T>T 
ReplacementFor_get_header_value(const char*key,size_t id=((0x17a2+2304-0x1726)+
(0xa89+417-0x22a)-(0x1a55+6784-0x2159)))const;size_t 
ReplacementFor_get_header_value_count(const char*key)const;void 
ReplacementFor_set_header(const char*key,const char*val);void 
ReplacementFor_set_header(const char*key,const std::string&val);void 
ReplacementFor_set_redirect(const char*ReplacementFor_url,int status=(
(0xa76+4180-0x10b0)+(0x261d+39-0x1994)-5532));void ReplacementFor_set_redirect(
const std::string&ReplacementFor_url,int status=((0x1603+2993-0x1e6d)+
(0x16af+183-0xe0d)-(0x1276+5676-0x1d30)));void ReplacementFor_set_content(const 
char*s,size_t n,const char*ReplacementFor_content_type);void 
ReplacementFor_set_content(const std::string&s,const char*
ReplacementFor_content_type);void ReplacementFor_set_content_provider(size_t 
length,const char*ReplacementFor_content_type,ReplacementFor_ContentProvider 
ReplacementFor_provider,const std::function<void()>&
ReplacementFor_resource_releaser=nullptr);void 
ReplacementFor_set_content_provider(const char*ReplacementFor_content_type,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_provider,const std::
function<void()>&ReplacementFor_resource_releaser=nullptr);void 
ReplacementFor_set_chunked_content_provider(const char*
ReplacementFor_content_type,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_provider,const std::function<void()>&
ReplacementFor_resource_releaser=nullptr);ReplacementFor_Response()=default;
ReplacementFor_Response(const ReplacementFor_Response&)=default;
ReplacementFor_Response&operator=(const ReplacementFor_Response&)=default;
ReplacementFor_Response(ReplacementFor_Response&&)=default;
ReplacementFor_Response&operator=(ReplacementFor_Response&&)=default;~
ReplacementFor_Response(){if(ReplacementFor_content_provider_resource_releaser_)
{ReplacementFor_content_provider_resource_releaser_();}}size_t 
ReplacementFor_content_length_=(7354+(0xfdc+2615-0x16ed)-(0x215a+2825-0xc83));
ReplacementFor_ContentProvider ReplacementFor_content_provider_;std::function<
void()>ReplacementFor_content_provider_resource_releaser_;bool 
ReplacementFor_is_chunked_content_provider_=false;};class ReplacementFor_Stream{
public:virtual~ReplacementFor_Stream()=default;virtual bool 
ReplacementFor_is_readable()const=0;virtual bool ReplacementFor_is_writable()
const=0;virtual ssize_t read(char*ReplacementFor_ptr,size_t size)=0;virtual 
ssize_t write(const char*ReplacementFor_ptr,size_t size)=0;virtual void 
ReplacementFor_get_remote_ip_and_port(std::string&ReplacementFor_ip,int&
ReplacementFor_port)const=0;virtual ReplacementFor_socket_t socket()const=0;
template<typename...ReplacementFor_Args>ssize_t ReplacementFor_write_format(
const char*ReplacementFor_fmt,const ReplacementFor_Args&...ReplacementFor_args);
ssize_t write(const char*ReplacementFor_ptr);ssize_t write(const std::string&s);
};class ReplacementFor_TaskQueue{public:ReplacementFor_TaskQueue()=default;
virtual~ReplacementFor_TaskQueue()=default;virtual void ReplacementFor_enqueue(
std::function<void()>ReplacementFor_fn)=0;virtual void shutdown()=0;virtual void
 ReplacementFor_on_idle(){};};class ReplacementFor_ThreadPool:public 
ReplacementFor_TaskQueue{public:explicit ReplacementFor_ThreadPool(size_t n):
ReplacementFor_shutdown_(false){while(n){ReplacementFor_threads_.emplace_back(
ReplacementFor_worker(*this));n--;}}ReplacementFor_ThreadPool(const 
ReplacementFor_ThreadPool&)=delete;~ReplacementFor_ThreadPool()override=default;
void ReplacementFor_enqueue(std::function<void()>ReplacementFor_fn)override{std
::unique_lock<std::mutex>lock(ReplacementFor_mutex_);ReplacementFor_jobs_.
push_back(std::move(ReplacementFor_fn));ReplacementFor_cond_.notify_one();}void 
shutdown()override{{std::unique_lock<std::mutex>lock(ReplacementFor_mutex_);
ReplacementFor_shutdown_=true;}ReplacementFor_cond_.notify_all();for(auto&t:
ReplacementFor_threads_){t.join();}}private:struct ReplacementFor_worker{
explicit ReplacementFor_worker(ReplacementFor_ThreadPool&ReplacementFor_pool):
ReplacementFor_pool_(ReplacementFor_pool){}void operator()(){for(;;){std::
function<void()>ReplacementFor_fn;{std::unique_lock<std::mutex>lock(
ReplacementFor_pool_.ReplacementFor_mutex_);ReplacementFor_pool_.
ReplacementFor_cond_.wait(lock,[&]{return!ReplacementFor_pool_.
ReplacementFor_jobs_.empty()||ReplacementFor_pool_.ReplacementFor_shutdown_;});
if(ReplacementFor_pool_.ReplacementFor_shutdown_&&ReplacementFor_pool_.
ReplacementFor_jobs_.empty()){break;}ReplacementFor_fn=ReplacementFor_pool_.
ReplacementFor_jobs_.front();ReplacementFor_pool_.ReplacementFor_jobs_.pop_front
();}assert(true==static_cast<bool>(ReplacementFor_fn));ReplacementFor_fn();}}
ReplacementFor_ThreadPool&ReplacementFor_pool_;};friend struct 
ReplacementFor_worker;std::vector<std::thread>ReplacementFor_threads_;std::list<
std::function<void()>>ReplacementFor_jobs_;bool ReplacementFor_shutdown_;std::
condition_variable ReplacementFor_cond_;std::mutex ReplacementFor_mutex_;};using
 ReplacementFor_Logger=std::function<void(const ReplacementFor_Request&,const 
ReplacementFor_Response&)>;using ReplacementFor_SocketOptions=std::function<void
(ReplacementFor_socket_t ReplacementFor_sock)>;inline void 
ReplacementFor_default_socket_options(ReplacementFor_socket_t 
ReplacementFor_sock){int ReplacementFor_yes=((0x805+5670-0x1a4a)+
(0x1d75+199-0x8e9)-(0x20ba+3988-0x171b));
#ifdef _WIN32
setsockopt(ReplacementFor_sock,SOL_SOCKET,SO_REUSEADDR,reinterpret_cast<char*>(&
ReplacementFor_yes),sizeof(ReplacementFor_yes));setsockopt(ReplacementFor_sock,
SOL_SOCKET,SO_EXCLUSIVEADDRUSE,reinterpret_cast<char*>(&ReplacementFor_yes),
sizeof(ReplacementFor_yes));
#else
#ifdef ReplacementFor_SO_REUSEPORT
setsockopt(ReplacementFor_sock,SOL_SOCKET,ReplacementFor_SO_REUSEPORT,
reinterpret_cast<void*>(&ReplacementFor_yes),sizeof(ReplacementFor_yes));
#else
setsockopt(ReplacementFor_sock,SOL_SOCKET,SO_REUSEADDR,reinterpret_cast<void*>(&
ReplacementFor_yes),sizeof(ReplacementFor_yes));
#endif
#endif
}class ReplacementFor_Server{public:using ReplacementFor_Handler=std::function<
void(const ReplacementFor_Request&,ReplacementFor_Response&)>;using 
ExceptionHandler=std::function<void(const ReplacementFor_Request&,
ReplacementFor_Response&,std::exception&ReplacementFor_e)>;enum class 
ReplacementFor_HandlerResponse{ReplacementFor_Handled,ReplacementFor_Unhandled,}
;using ReplacementFor_HandlerWithResponse=std::function<
ReplacementFor_HandlerResponse(const ReplacementFor_Request&,
ReplacementFor_Response&)>;using ReplacementFor_HandlerWithContentReader=std::
function<void(const ReplacementFor_Request&,ReplacementFor_Response&,const 
ReplacementFor_ContentReader&ReplacementFor_content_reader)>;using 
ReplacementFor_Expect100ContinueHandler=std::function<int(const 
ReplacementFor_Request&,ReplacementFor_Response&)>;ReplacementFor_Server();
virtual~ReplacementFor_Server();virtual bool ReplacementFor_is_valid()const;
ReplacementFor_Server&Get(const char*pattern,ReplacementFor_Handler 
ReplacementFor_handler);ReplacementFor_Server&Get(const char*pattern,size_t 
ReplacementFor_pattern_len,ReplacementFor_Handler ReplacementFor_handler);
ReplacementFor_Server&ReplacementFor_Post(const char*pattern,
ReplacementFor_Handler ReplacementFor_handler);ReplacementFor_Server&
ReplacementFor_Post(const char*pattern,size_t ReplacementFor_pattern_len,
ReplacementFor_Handler ReplacementFor_handler);ReplacementFor_Server&
ReplacementFor_Post(const char*pattern,ReplacementFor_HandlerWithContentReader 
ReplacementFor_handler);ReplacementFor_Server&ReplacementFor_Post(const char*
pattern,size_t ReplacementFor_pattern_len,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler);
ReplacementFor_Server&Put(const char*pattern,ReplacementFor_Handler 
ReplacementFor_handler);ReplacementFor_Server&Put(const char*pattern,size_t 
ReplacementFor_pattern_len,ReplacementFor_Handler ReplacementFor_handler);
ReplacementFor_Server&Put(const char*pattern,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler);
ReplacementFor_Server&Put(const char*pattern,size_t ReplacementFor_pattern_len,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler);
ReplacementFor_Server&ReplacementFor_Patch(const char*pattern,
ReplacementFor_Handler ReplacementFor_handler);ReplacementFor_Server&
ReplacementFor_Patch(const char*pattern,size_t ReplacementFor_pattern_len,
ReplacementFor_Handler ReplacementFor_handler);ReplacementFor_Server&
ReplacementFor_Patch(const char*pattern,ReplacementFor_HandlerWithContentReader 
ReplacementFor_handler);ReplacementFor_Server&ReplacementFor_Patch(const char*
pattern,size_t ReplacementFor_pattern_len,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler);
ReplacementFor_Server&Delete(const char*pattern,ReplacementFor_Handler 
ReplacementFor_handler);ReplacementFor_Server&Delete(const char*pattern,size_t 
ReplacementFor_pattern_len,ReplacementFor_Handler ReplacementFor_handler);
ReplacementFor_Server&Delete(const char*pattern,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler);
ReplacementFor_Server&Delete(const char*pattern,size_t 
ReplacementFor_pattern_len,ReplacementFor_HandlerWithContentReader 
ReplacementFor_handler);ReplacementFor_Server&Options(const char*pattern,
ReplacementFor_Handler ReplacementFor_handler);ReplacementFor_Server&Options(
const char*pattern,size_t ReplacementFor_pattern_len,ReplacementFor_Handler 
ReplacementFor_handler);bool ReplacementFor_set_base_dir(const char*
ReplacementFor_dir,const char*ReplacementFor_mount_point=nullptr);bool 
ReplacementFor_set_mount_point(const char*ReplacementFor_mount_point,const char*
ReplacementFor_dir,ReplacementFor_Headers ReplacementFor_headers=
ReplacementFor_Headers());bool ReplacementFor_remove_mount_point(const char*
ReplacementFor_mount_point);ReplacementFor_Server&
ReplacementFor_set_file_extension_and_mimetype_mapping(const char*
ReplacementFor_ext,const char*ReplacementFor_mime);ReplacementFor_Server&
ReplacementFor_set_file_request_handler(ReplacementFor_Handler 
ReplacementFor_handler);ReplacementFor_Server&ReplacementFor_set_error_handler(
ReplacementFor_HandlerWithResponse ReplacementFor_handler);ReplacementFor_Server
&ReplacementFor_set_error_handler(ReplacementFor_Handler ReplacementFor_handler)
;ReplacementFor_Server&ReplacementFor_set_exception_handler(ExceptionHandler 
ReplacementFor_handler);ReplacementFor_Server&
ReplacementFor_set_pre_routing_handler(ReplacementFor_HandlerWithResponse 
ReplacementFor_handler);ReplacementFor_Server&
ReplacementFor_set_post_routing_handler(ReplacementFor_Handler 
ReplacementFor_handler);ReplacementFor_Server&
ReplacementFor_set_expect_100_continue_handler(
ReplacementFor_Expect100ContinueHandler ReplacementFor_handler);
ReplacementFor_Server&ReplacementFor_set_logger(ReplacementFor_Logger 
ReplacementFor_logger);ReplacementFor_Server&ReplacementFor_set_tcp_nodelay(bool
 ReplacementFor_on);ReplacementFor_Server&ReplacementFor_set_socket_options(
ReplacementFor_SocketOptions ReplacementFor_socket_options);
ReplacementFor_Server&ReplacementFor_set_keep_alive_max_count(size_t count);
ReplacementFor_Server&ReplacementFor_set_keep_alive_timeout(time_t sec);
ReplacementFor_Server&ReplacementFor_set_read_timeout(time_t sec,time_t 
ReplacementFor_usec=((0x1793+4328-0x2337)+8167-9515));ReplacementFor_Server&
ReplacementFor_set_write_timeout(time_t sec,time_t ReplacementFor_usec=(
(0x412+3701-0x1025)+(0x1ae2+8433-0x226c)-7113));ReplacementFor_Server&
ReplacementFor_set_idle_interval(time_t sec,time_t ReplacementFor_usec=(8507+
(0x17cc+1128-0x1a52)-8989));ReplacementFor_Server&
ReplacementFor_set_payload_max_length(size_t length);bool 
ReplacementFor_bind_to_port(const char*ReplacementFor_host,int 
ReplacementFor_port,int ReplacementFor_socket_flags=((0x1755+4221-0x2496)+6359-
7187));int ReplacementFor_bind_to_any_port(const char*ReplacementFor_host,int 
ReplacementFor_socket_flags=((0x783+4256-0x1169)+(0x12a4+2521-0xbaa)-6029));bool
 ReplacementFor_listen_after_bind();bool listen(const char*ReplacementFor_host,
int ReplacementFor_port,int ReplacementFor_socket_flags=((0x73c+6297-0x1f18)+
9640-9829));bool ReplacementFor_is_running()const;void ReplacementFor_stop();std
::function<ReplacementFor_TaskQueue*(void)>ReplacementFor_new_task_queue;
protected:bool ReplacementFor_process_request(ReplacementFor_Stream&
ReplacementFor_strm,bool ReplacementFor_close_connection,bool&
ReplacementFor_connection_closed,const std::function<void(ReplacementFor_Request
&)>&ReplacementFor_setup_request);std::atomic<ReplacementFor_socket_t>
ReplacementFor_svr_sock_;size_t ReplacementFor_keep_alive_max_count_=
ReplacementFor_CPPHTTPLIB_KEEPALIVE_MAX_COUNT;time_t 
ReplacementFor_keep_alive_timeout_sec_=
ReplacementFor_CPPHTTPLIB_KEEPALIVE_TIMEOUT_SECOND;time_t 
ReplacementFor_read_timeout_sec_=ReplacementFor_CPPHTTPLIB_READ_TIMEOUT_SECOND;
time_t ReplacementFor_read_timeout_usec_=
ReplacementFor_CPPHTTPLIB_READ_TIMEOUT_USECOND;time_t 
ReplacementFor_write_timeout_sec_=ReplacementFor_CPPHTTPLIB_WRITE_TIMEOUT_SECOND
;time_t ReplacementFor_write_timeout_usec_=
ReplacementFor_CPPHTTPLIB_WRITE_TIMEOUT_USECOND;time_t 
ReplacementFor_idle_interval_sec_=ReplacementFor_CPPHTTPLIB_IDLE_INTERVAL_SECOND
;time_t ReplacementFor_idle_interval_usec_=
ReplacementFor_CPPHTTPLIB_IDLE_INTERVAL_USECOND;size_t 
ReplacementFor_payload_max_length_=ReplacementFor_CPPHTTPLIB_PAYLOAD_MAX_LENGTH;
private:using ReplacementFor_Handlers=std::vector<std::pair<std::regex,
ReplacementFor_Handler>>;using ReplacementFor_HandlersForContentReader=std::
vector<std::pair<std::regex,ReplacementFor_HandlerWithContentReader>>;
ReplacementFor_socket_t ReplacementFor_create_server_socket(const char*
ReplacementFor_host,int ReplacementFor_port,int ReplacementFor_socket_flags,
ReplacementFor_SocketOptions ReplacementFor_socket_options)const;int 
ReplacementFor_bind_internal(const char*ReplacementFor_host,int 
ReplacementFor_port,int ReplacementFor_socket_flags);bool 
ReplacementFor_listen_internal();bool ReplacementFor_routing(
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,ReplacementFor_Stream&ReplacementFor_strm);bool 
ReplacementFor_handle_file_request(const ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res,bool 
ReplacementFor_head=false);bool ReplacementFor_dispatch_request(
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,const ReplacementFor_Handlers&ReplacementFor_handlers);bool 
ReplacementFor_dispatch_request_for_content_reader(ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res,
ReplacementFor_ContentReader ReplacementFor_content_reader,const 
ReplacementFor_HandlersForContentReader&ReplacementFor_handlers);bool 
ReplacementFor_parse_request_line(const char*s,ReplacementFor_Request&
ReplacementFor_req);void ReplacementFor_apply_ranges(const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,std::string&ReplacementFor_content_type,std::string&
ReplacementFor_boundary);bool ReplacementFor_write_response(
ReplacementFor_Stream&ReplacementFor_strm,bool ReplacementFor_close_connection,
const ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res);bool ReplacementFor_write_response_with_content(
ReplacementFor_Stream&ReplacementFor_strm,bool ReplacementFor_close_connection,
const ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res);bool ReplacementFor_write_response_core(
ReplacementFor_Stream&ReplacementFor_strm,bool ReplacementFor_close_connection,
const ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,bool ReplacementFor_need_apply_ranges);bool 
ReplacementFor_write_content_with_provider(ReplacementFor_Stream&
ReplacementFor_strm,const ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,const std::string&
ReplacementFor_boundary,const std::string&ReplacementFor_content_type);bool 
ReplacementFor_read_content(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res);bool ReplacementFor_read_content_with_content_receiver(
ReplacementFor_Stream&ReplacementFor_strm,ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res,
ReplacementFor_ContentReceiver ReplacementFor_receiver,
ReplacementFor_MultipartContentHeader ReplacementFor_multipart_header,
ReplacementFor_ContentReceiver ReplacementFor_multipart_receiver);bool 
ReplacementFor_read_content_core(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,ReplacementFor_ContentReceiver ReplacementFor_receiver,
ReplacementFor_MultipartContentHeader ReplacementFor_mulitpart_header,
ReplacementFor_ContentReceiver ReplacementFor_multipart_receiver);virtual bool 
ReplacementFor_process_and_close_socket(ReplacementFor_socket_t 
ReplacementFor_sock);struct ReplacementFor_MountPointEntry{std::string 
ReplacementFor_mount_point;std::string ReplacementFor_base_dir;
ReplacementFor_Headers ReplacementFor_headers;};std::vector<
ReplacementFor_MountPointEntry>ReplacementFor_base_dirs_;std::atomic<bool>
ReplacementFor_is_running_;std::map<std::string,std::string>
ReplacementFor_file_extension_and_mimetype_map_;ReplacementFor_Handler 
ReplacementFor_file_request_handler_;ReplacementFor_Handlers 
ReplacementFor_get_handlers_;ReplacementFor_Handlers 
ReplacementFor_post_handlers_;ReplacementFor_HandlersForContentReader 
ReplacementFor_post_handlers_for_content_reader_;ReplacementFor_Handlers 
ReplacementFor_put_handlers_;ReplacementFor_HandlersForContentReader 
ReplacementFor_put_handlers_for_content_reader_;ReplacementFor_Handlers 
ReplacementFor_patch_handlers_;ReplacementFor_HandlersForContentReader 
ReplacementFor_patch_handlers_for_content_reader_;ReplacementFor_Handlers 
ReplacementFor_delete_handlers_;ReplacementFor_HandlersForContentReader 
ReplacementFor_delete_handlers_for_content_reader_;ReplacementFor_Handlers 
ReplacementFor_options_handlers_;ReplacementFor_HandlerWithResponse 
ReplacementFor_error_handler_;ExceptionHandler ReplacementFor_exception_handler_
;ReplacementFor_HandlerWithResponse ReplacementFor_pre_routing_handler_;
ReplacementFor_Handler ReplacementFor_post_routing_handler_;
ReplacementFor_Logger ReplacementFor_logger_;
ReplacementFor_Expect100ContinueHandler 
ReplacementFor_expect_100_continue_handler_;bool ReplacementFor_tcp_nodelay_=
ReplacementFor_CPPHTTPLIB_TCP_NODELAY;ReplacementFor_SocketOptions 
ReplacementFor_socket_options_=ReplacementFor_default_socket_options;};enum 
Error{ReplacementFor_Success=((0x11ba+28-0x11c1)+(0x22d9+990-0x1ae4)-
(0x1105+4810-0x17e7)),Unknown,ReplacementFor_Connection,
ReplacementFor_BindIPAddress,Read,Write,ReplacementFor_ExceedRedirectCount,
ReplacementFor_Canceled,ReplacementFor_SSLConnection,
ReplacementFor_SSLLoadingCerts,ReplacementFor_SSLServerVerification,
ReplacementFor_UnsupportedMultipartBoundaryChars,Compression,};class Result{
public:Result(std::unique_ptr<ReplacementFor_Response>&&ReplacementFor_res,Error
 err,ReplacementFor_Headers&&ReplacementFor_request_headers=
ReplacementFor_Headers{}):ReplacementFor_res_(std::move(ReplacementFor_res)),
ReplacementFor_err_(err),ReplacementFor_request_headers_(std::move(
ReplacementFor_request_headers)){}operator bool()const{return 
ReplacementFor_res_!=nullptr;}bool operator==(std::nullptr_t)const{return 
ReplacementFor_res_==nullptr;}bool operator!=(std::nullptr_t)const{return 
ReplacementFor_res_!=nullptr;}const ReplacementFor_Response&value()const{return*
ReplacementFor_res_;}ReplacementFor_Response&value(){return*ReplacementFor_res_;
}const ReplacementFor_Response&operator*()const{return*ReplacementFor_res_;}
ReplacementFor_Response&operator*(){return*ReplacementFor_res_;}const 
ReplacementFor_Response*operator->()const{return ReplacementFor_res_.get();}
ReplacementFor_Response*operator->(){return ReplacementFor_res_.get();}Error 
error()const{return ReplacementFor_err_;}bool ReplacementFor_has_request_header(
const char*key)const;std::string ReplacementFor_get_request_header_value(const 
char*key,size_t id=((0x742+6010-0x1de0)+6585-(0x1ab9+3363-0xd47)))const;template
<typename T>T ReplacementFor_get_request_header_value(const char*key,size_t id=(
(0x1713+4163-0x1156)+(0xf31+991-0x123a)-(0x1c78+3293-0x127f)))const;size_t 
ReplacementFor_get_request_header_value_count(const char*key)const;private:std::
unique_ptr<ReplacementFor_Response>ReplacementFor_res_;Error ReplacementFor_err_
;ReplacementFor_Headers ReplacementFor_request_headers_;};class 
ReplacementFor_ClientImpl{public:explicit ReplacementFor_ClientImpl(const std::
string&ReplacementFor_host);explicit ReplacementFor_ClientImpl(const std::string
&ReplacementFor_host,int ReplacementFor_port);explicit ReplacementFor_ClientImpl
(const std::string&ReplacementFor_host,int ReplacementFor_port,const std::string
&ReplacementFor_client_cert_path,const std::string&
ReplacementFor_client_key_path);virtual~ReplacementFor_ClientImpl();virtual bool
 ReplacementFor_is_valid()const;Result Get(const char*ReplacementFor_path);
Result Get(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers);Result Get(const char*ReplacementFor_path,
ReplacementFor_Progress ReplacementFor_progress);Result Get(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_Progress ReplacementFor_progress);Result Get(const char*
ReplacementFor_path,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver);Result Get(const char*ReplacementFor_path,const
 ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver);Result Get(const char*ReplacementFor_path,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress);Result Get(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress);Result Get(const char*
ReplacementFor_path,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver);Result Get(const char*ReplacementFor_path,const
 ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver);Result Get(const char*ReplacementFor_path,
ReplacementFor_ResponseHandler ReplacementFor_response_handler,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress);Result Get(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ResponseHandler ReplacementFor_response_handler,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress);Result Get(const char*
ReplacementFor_path,const ReplacementFor_Params&ReplacementFor_params,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_Progress 
ReplacementFor_progress=nullptr);Result Get(const char*ReplacementFor_path,const
 ReplacementFor_Params&ReplacementFor_params,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress=
nullptr);Result Get(const char*ReplacementFor_path,const ReplacementFor_Params&
ReplacementFor_params,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ResponseHandler ReplacementFor_response_handler,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress=nullptr);Result Head(const char*
ReplacementFor_path);Result Head(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers);Result ReplacementFor_Post(const 
char*ReplacementFor_path);Result ReplacementFor_Post(const char*
ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const std::string&ReplacementFor_body,const char*
ReplacementFor_content_type);Result ReplacementFor_Post(const char*
ReplacementFor_path,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type);Result ReplacementFor_Post(const char*
ReplacementFor_path,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type);Result ReplacementFor_Post(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type);Result ReplacementFor_Post(const char*
ReplacementFor_path,const ReplacementFor_Params&ReplacementFor_params);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const ReplacementFor_Params&ReplacementFor_params);Result
 ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_MultipartFormDataItems&ReplacementFor_items);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const ReplacementFor_MultipartFormDataItems&
ReplacementFor_items);Result ReplacementFor_Post(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,const 
ReplacementFor_MultipartFormDataItems&ReplacementFor_items,const std::string&
ReplacementFor_boundary);Result Put(const char*ReplacementFor_path);Result Put(
const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result Put
(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result Put
(const char*ReplacementFor_path,const std::string&ReplacementFor_body,const char
*ReplacementFor_content_type);Result Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type);Result Put(const 
char*ReplacementFor_path,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type);Result Put(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type);Result Put(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
Put(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
Put(const char*ReplacementFor_path,const ReplacementFor_Params&
ReplacementFor_params);Result Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const ReplacementFor_Params&
ReplacementFor_params);Result ReplacementFor_Patch(const char*
ReplacementFor_path);Result ReplacementFor_Patch(const char*ReplacementFor_path,
const char*ReplacementFor_body,size_t ReplacementFor_content_length,const char*
ReplacementFor_content_type);Result ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
char*ReplacementFor_body,size_t ReplacementFor_content_length,const char*
ReplacementFor_content_type);Result ReplacementFor_Patch(const char*
ReplacementFor_path,const std::string&ReplacementFor_body,const char*
ReplacementFor_content_type);Result ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
std::string&ReplacementFor_body,const char*ReplacementFor_content_type);Result 
ReplacementFor_Patch(const char*ReplacementFor_path,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
ReplacementFor_Patch(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type);Result ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
ReplacementFor_Patch(const char*ReplacementFor_path,const ReplacementFor_Headers
&ReplacementFor_headers,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
Delete(const char*ReplacementFor_path);Result Delete(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers);Result 
Delete(const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result 
Delete(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result 
Delete(const char*ReplacementFor_path,const std::string&ReplacementFor_body,
const char*ReplacementFor_content_type);Result Delete(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
std::string&ReplacementFor_body,const char*ReplacementFor_content_type);Result 
Options(const char*ReplacementFor_path);Result Options(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers);bool 
send(ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,Error&error);Result send(const ReplacementFor_Request&
ReplacementFor_req);size_t ReplacementFor_is_socket_open()const;void 
ReplacementFor_stop();void ReplacementFor_set_default_headers(
ReplacementFor_Headers ReplacementFor_headers);void 
ReplacementFor_set_tcp_nodelay(bool ReplacementFor_on);void 
ReplacementFor_set_socket_options(ReplacementFor_SocketOptions 
ReplacementFor_socket_options);void ReplacementFor_set_connection_timeout(time_t
 sec,time_t ReplacementFor_usec=((0xe22+5432-0x1bf6)+(0x1ea5+265-0x60a)-
(0x251a+1799-0xb19)));void ReplacementFor_set_read_timeout(time_t sec,time_t 
ReplacementFor_usec=((0x15f9+6943-0x1b92)+(0x1046+2448-0xc62)-8954));void 
ReplacementFor_set_write_timeout(time_t sec,time_t ReplacementFor_usec=(
(0xf78+3302-0x128e)+(0x19fa+1830-0x183f)-(0x21a1+993-0x12d1)));void 
ReplacementFor_set_basic_auth(const char*ReplacementFor_username,const char*
ReplacementFor_password);void ReplacementFor_set_bearer_token_auth(const char*
ReplacementFor_token);
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_set_digest_auth(const char*ReplacementFor_username,const 
char*ReplacementFor_password);
#endif
void ReplacementFor_set_keep_alive(bool ReplacementFor_on);void 
ReplacementFor_set_follow_location(bool ReplacementFor_on);void 
ReplacementFor_set_compress(bool ReplacementFor_on);void 
ReplacementFor_set_decompress(bool ReplacementFor_on);void 
ReplacementFor_set_interface(const char*intf);void ReplacementFor_set_proxy(
const char*ReplacementFor_host,int ReplacementFor_port);void 
ReplacementFor_set_proxy_basic_auth(const char*ReplacementFor_username,const 
char*ReplacementFor_password);void ReplacementFor_set_proxy_bearer_token_auth(
const char*ReplacementFor_token);
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_set_proxy_digest_auth(const char*ReplacementFor_username,
const char*ReplacementFor_password);
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_enable_server_certificate_verification(bool 
ReplacementFor_enabled);
#endif
void ReplacementFor_set_logger(ReplacementFor_Logger ReplacementFor_logger);
protected:struct Socket{ReplacementFor_socket_t ReplacementFor_sock=
INVALID_SOCKET;
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
ReplacementFor_SSL*ReplacementFor_ssl=nullptr;
#endif
bool is_open()const{return ReplacementFor_sock!=INVALID_SOCKET;}};Result 
ReplacementFor_send_(ReplacementFor_Request&&ReplacementFor_req);virtual bool 
ReplacementFor_create_and_connect_socket(Socket&socket,Error&error);virtual void
 ReplacementFor_shutdown_ssl(Socket&socket,bool 
ReplacementFor_shutdown_gracefully);void ReplacementFor_shutdown_socket(Socket&
socket);void ReplacementFor_close_socket(Socket&socket);void 
ReplacementFor_lock_socket_and_shutdown_and_close();bool 
ReplacementFor_process_request(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,bool ReplacementFor_close_connection,Error&error);bool 
ReplacementFor_write_content_with_provider(ReplacementFor_Stream&
ReplacementFor_strm,const ReplacementFor_Request&ReplacementFor_req,Error&error)
;void ReplacementFor_copy_settings(const ReplacementFor_ClientImpl&
ReplacementFor_rhs);const std::string ReplacementFor_host_;const int 
ReplacementFor_port_;const std::string ReplacementFor_host_and_port_;Socket 
ReplacementFor_socket_;mutable std::mutex ReplacementFor_socket_mutex_;std::
recursive_mutex ReplacementFor_request_mutex_;size_t 
ReplacementFor_socket_requests_in_flight_=((0x17e6+1034-0x1aeb)+8305-8566);std::
thread::id ReplacementFor_socket_requests_are_from_thread_=std::thread::id();
bool ReplacementFor_socket_should_be_closed_when_request_is_done_=false;
ReplacementFor_Headers ReplacementFor_default_headers_;std::string 
ReplacementFor_client_cert_path_;std::string ReplacementFor_client_key_path_;
time_t ReplacementFor_connection_timeout_sec_=
ReplacementFor_CPPHTTPLIB_CONNECTION_TIMEOUT_SECOND;time_t 
ReplacementFor_connection_timeout_usec_=
ReplacementFor_CPPHTTPLIB_CONNECTION_TIMEOUT_USECOND;time_t 
ReplacementFor_read_timeout_sec_=ReplacementFor_CPPHTTPLIB_READ_TIMEOUT_SECOND;
time_t ReplacementFor_read_timeout_usec_=
ReplacementFor_CPPHTTPLIB_READ_TIMEOUT_USECOND;time_t 
ReplacementFor_write_timeout_sec_=ReplacementFor_CPPHTTPLIB_WRITE_TIMEOUT_SECOND
;time_t ReplacementFor_write_timeout_usec_=
ReplacementFor_CPPHTTPLIB_WRITE_TIMEOUT_USECOND;std::string 
ReplacementFor_basic_auth_username_;std::string 
ReplacementFor_basic_auth_password_;std::string 
ReplacementFor_bearer_token_auth_token_;
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
std::string ReplacementFor_digest_auth_username_;std::string 
ReplacementFor_digest_auth_password_;
#endif
bool ReplacementFor_keep_alive_=false;bool ReplacementFor_follow_location_=false
;bool ReplacementFor_tcp_nodelay_=ReplacementFor_CPPHTTPLIB_TCP_NODELAY;
ReplacementFor_SocketOptions ReplacementFor_socket_options_=nullptr;bool 
ReplacementFor_compress_=false;bool ReplacementFor_decompress_=true;std::string 
ReplacementFor_interface_;std::string ReplacementFor_proxy_host_;int 
ReplacementFor_proxy_port_=-((0xee8+758-0x563)+6406-9600);std::string 
ReplacementFor_proxy_basic_auth_username_;std::string 
ReplacementFor_proxy_basic_auth_password_;std::string 
ReplacementFor_proxy_bearer_token_auth_token_;
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
std::string ReplacementFor_proxy_digest_auth_username_;std::string 
ReplacementFor_proxy_digest_auth_password_;
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
bool ReplacementFor_server_certificate_verification_=true;
#endif
ReplacementFor_Logger ReplacementFor_logger_;private:ReplacementFor_socket_t 
ReplacementFor_create_client_socket(Error&error)const;bool 
ReplacementFor_read_response_line(ReplacementFor_Stream&ReplacementFor_strm,
const ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res);bool ReplacementFor_write_request(ReplacementFor_Stream&
ReplacementFor_strm,ReplacementFor_Request&ReplacementFor_req,bool 
ReplacementFor_close_connection,Error&error);bool ReplacementFor_redirect(
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,Error&error);bool ReplacementFor_handle_request(
ReplacementFor_Stream&ReplacementFor_strm,ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res,bool 
ReplacementFor_close_connection,Error&error);std::unique_ptr<
ReplacementFor_Response>ReplacementFor_send_with_content_provider(
ReplacementFor_Request&ReplacementFor_req,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider_without_length,const char*
ReplacementFor_content_type,Error&error);Result 
ReplacementFor_send_with_content_provider(const char*ReplacementFor_method,const
 char*ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
const char*ReplacementFor_body,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,
ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider_without_length,const char*
ReplacementFor_content_type);virtual bool ReplacementFor_process_socket(const 
Socket&socket,std::function<bool(ReplacementFor_Stream&ReplacementFor_strm)>
ReplacementFor_callback);virtual bool ReplacementFor_is_ssl()const;};class 
ReplacementFor_Client{public:explicit ReplacementFor_Client(const char*
ReplacementFor_scheme_host_port);explicit ReplacementFor_Client(const char*
ReplacementFor_scheme_host_port,const std::string&
ReplacementFor_client_cert_path,const std::string&ReplacementFor_client_key_path
);explicit ReplacementFor_Client(const std::string&ReplacementFor_host,int 
ReplacementFor_port);explicit ReplacementFor_Client(const std::string&
ReplacementFor_host,int ReplacementFor_port,const std::string&
ReplacementFor_client_cert_path,const std::string&ReplacementFor_client_key_path
);~ReplacementFor_Client();bool ReplacementFor_is_valid()const;Result Get(const 
char*ReplacementFor_path);Result Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers);Result Get(const char*
ReplacementFor_path,ReplacementFor_Progress ReplacementFor_progress);Result Get(
const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_Progress ReplacementFor_progress);Result 
Get(const char*ReplacementFor_path,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver);Result Get(const char*ReplacementFor_path,const
 ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver);Result Get(const char*ReplacementFor_path,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress);Result Get(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress);Result Get(const char*
ReplacementFor_path,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver);Result Get(const char*ReplacementFor_path,const
 ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver);Result Get(const char*ReplacementFor_path,const
 ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
;Result Get(const char*ReplacementFor_path,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
;Result Get(const char*ReplacementFor_path,const ReplacementFor_Params&
ReplacementFor_params,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_Progress ReplacementFor_progress=nullptr);Result Get(const char*
ReplacementFor_path,const ReplacementFor_Params&ReplacementFor_params,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress=
nullptr);Result Get(const char*ReplacementFor_path,const ReplacementFor_Params&
ReplacementFor_params,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ResponseHandler ReplacementFor_response_handler,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress=nullptr);Result Head(const char*
ReplacementFor_path);Result Head(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers);Result ReplacementFor_Post(const 
char*ReplacementFor_path);Result ReplacementFor_Post(const char*
ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const std::string&ReplacementFor_body,const char*
ReplacementFor_content_type);Result ReplacementFor_Post(const char*
ReplacementFor_path,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type);Result ReplacementFor_Post(const char*
ReplacementFor_path,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type);Result ReplacementFor_Post(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type);Result ReplacementFor_Post(const char*
ReplacementFor_path,const ReplacementFor_Params&ReplacementFor_params);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const ReplacementFor_Params&ReplacementFor_params);Result
 ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_MultipartFormDataItems&ReplacementFor_items);Result 
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const ReplacementFor_MultipartFormDataItems&
ReplacementFor_items);Result ReplacementFor_Post(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,const 
ReplacementFor_MultipartFormDataItems&ReplacementFor_items,const std::string&
ReplacementFor_boundary);Result Put(const char*ReplacementFor_path);Result Put(
const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result Put
(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result Put
(const char*ReplacementFor_path,const std::string&ReplacementFor_body,const char
*ReplacementFor_content_type);Result Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type);Result Put(const 
char*ReplacementFor_path,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type);Result Put(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type);Result Put(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
Put(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
Put(const char*ReplacementFor_path,const ReplacementFor_Params&
ReplacementFor_params);Result Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const ReplacementFor_Params&
ReplacementFor_params);Result ReplacementFor_Patch(const char*
ReplacementFor_path);Result ReplacementFor_Patch(const char*ReplacementFor_path,
const char*ReplacementFor_body,size_t ReplacementFor_content_length,const char*
ReplacementFor_content_type);Result ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
char*ReplacementFor_body,size_t ReplacementFor_content_length,const char*
ReplacementFor_content_type);Result ReplacementFor_Patch(const char*
ReplacementFor_path,const std::string&ReplacementFor_body,const char*
ReplacementFor_content_type);Result ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
std::string&ReplacementFor_body,const char*ReplacementFor_content_type);Result 
ReplacementFor_Patch(const char*ReplacementFor_path,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
ReplacementFor_Patch(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type);Result ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
ReplacementFor_Patch(const char*ReplacementFor_path,const ReplacementFor_Headers
&ReplacementFor_headers,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider,const char*ReplacementFor_content_type);Result 
Delete(const char*ReplacementFor_path);Result Delete(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers);Result 
Delete(const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result 
Delete(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type);Result 
Delete(const char*ReplacementFor_path,const std::string&ReplacementFor_body,
const char*ReplacementFor_content_type);Result Delete(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
std::string&ReplacementFor_body,const char*ReplacementFor_content_type);Result 
Options(const char*ReplacementFor_path);Result Options(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers);bool 
send(ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,Error&error);Result send(const ReplacementFor_Request&
ReplacementFor_req);size_t ReplacementFor_is_socket_open()const;void 
ReplacementFor_stop();void ReplacementFor_set_default_headers(
ReplacementFor_Headers ReplacementFor_headers);void 
ReplacementFor_set_tcp_nodelay(bool ReplacementFor_on);void 
ReplacementFor_set_socket_options(ReplacementFor_SocketOptions 
ReplacementFor_socket_options);void ReplacementFor_set_connection_timeout(time_t
 sec,time_t ReplacementFor_usec=((0x24a0+3097-0x2250)+(0x26bc+4341-0x21cd)-9293)
);void ReplacementFor_set_read_timeout(time_t sec,time_t ReplacementFor_usec=(
(0x1f6f+5059-0x25a7)+(0x256d+506-0x1cbc)-(0x1d36+1840-0xc30)));void 
ReplacementFor_set_write_timeout(time_t sec,time_t ReplacementFor_usec=(
(0x12c1+1345-0xddb)+(0x2204+42-0x1e5e)-(0x1b65+5541-0x2313)));void 
ReplacementFor_set_basic_auth(const char*ReplacementFor_username,const char*
ReplacementFor_password);void ReplacementFor_set_bearer_token_auth(const char*
ReplacementFor_token);
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_set_digest_auth(const char*ReplacementFor_username,const 
char*ReplacementFor_password);
#endif
void ReplacementFor_set_keep_alive(bool ReplacementFor_on);void 
ReplacementFor_set_follow_location(bool ReplacementFor_on);void 
ReplacementFor_set_compress(bool ReplacementFor_on);void 
ReplacementFor_set_decompress(bool ReplacementFor_on);void 
ReplacementFor_set_interface(const char*intf);void ReplacementFor_set_proxy(
const char*ReplacementFor_host,int ReplacementFor_port);void 
ReplacementFor_set_proxy_basic_auth(const char*ReplacementFor_username,const 
char*ReplacementFor_password);void ReplacementFor_set_proxy_bearer_token_auth(
const char*ReplacementFor_token);
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_set_proxy_digest_auth(const char*ReplacementFor_username,
const char*ReplacementFor_password);
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_enable_server_certificate_verification(bool 
ReplacementFor_enabled);
#endif
void ReplacementFor_set_logger(ReplacementFor_Logger ReplacementFor_logger);
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_set_ca_cert_path(const char*ReplacementFor_ca_cert_file_path
,const char*ReplacementFor_ca_cert_dir_path=nullptr);void 
ReplacementFor_set_ca_cert_store(ReplacementFor_X509_STORE*
ReplacementFor_ca_cert_store);long ReplacementFor_get_openssl_verify_result()
const;ReplacementFor_SSL_CTX*ReplacementFor_ssl_context()const;
#endif
private:std::unique_ptr<ReplacementFor_ClientImpl>ReplacementFor_cli_;
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
bool ReplacementFor_is_ssl_=false;
#endif
};
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
class ReplacementFor_SSLServer:public ReplacementFor_Server{public:
ReplacementFor_SSLServer(const char*ReplacementFor_cert_path,const char*
ReplacementFor_private_key_path,const char*
ReplacementFor_client_ca_cert_file_path=nullptr,const char*
ReplacementFor_client_ca_cert_dir_path=nullptr);ReplacementFor_SSLServer(
ReplacementFor_X509*ReplacementFor_cert,ReplacementFor_EVP_PKEY*
ReplacementFor_private_key,ReplacementFor_X509_STORE*
ReplacementFor_client_ca_cert_store=nullptr);~ReplacementFor_SSLServer()override
;bool ReplacementFor_is_valid()const override;private:bool 
ReplacementFor_process_and_close_socket(ReplacementFor_socket_t 
ReplacementFor_sock)override;ReplacementFor_SSL_CTX*ReplacementFor_ctx_;std::
mutex ReplacementFor_ctx_mutex_;};class ReplacementFor_SSLClient:public 
ReplacementFor_ClientImpl{public:explicit ReplacementFor_SSLClient(const std::
string&ReplacementFor_host);explicit ReplacementFor_SSLClient(const std::string&
ReplacementFor_host,int ReplacementFor_port);explicit ReplacementFor_SSLClient(
const std::string&ReplacementFor_host,int ReplacementFor_port,const std::string&
ReplacementFor_client_cert_path,const std::string&ReplacementFor_client_key_path
);explicit ReplacementFor_SSLClient(const std::string&ReplacementFor_host,int 
ReplacementFor_port,ReplacementFor_X509*ReplacementFor_client_cert,
ReplacementFor_EVP_PKEY*ReplacementFor_client_key);~ReplacementFor_SSLClient()
override;bool ReplacementFor_is_valid()const override;void 
ReplacementFor_set_ca_cert_path(const char*ReplacementFor_ca_cert_file_path,
const char*ReplacementFor_ca_cert_dir_path=nullptr);void 
ReplacementFor_set_ca_cert_store(ReplacementFor_X509_STORE*
ReplacementFor_ca_cert_store);long ReplacementFor_get_openssl_verify_result()
const;ReplacementFor_SSL_CTX*ReplacementFor_ssl_context()const;private:bool 
ReplacementFor_create_and_connect_socket(Socket&socket,Error&error)override;void
 ReplacementFor_shutdown_ssl(Socket&socket,bool 
ReplacementFor_shutdown_gracefully)override;bool ReplacementFor_process_socket(
const Socket&socket,std::function<bool(ReplacementFor_Stream&ReplacementFor_strm
)>ReplacementFor_callback)override;bool ReplacementFor_is_ssl()const override;
bool ReplacementFor_connect_with_proxy(Socket&ReplacementFor_sock,
ReplacementFor_Response&ReplacementFor_res,bool&ReplacementFor_success,Error&
error);bool ReplacementFor_initialize_ssl(Socket&socket,Error&error);bool 
ReplacementFor_load_certs();bool ReplacementFor_verify_host(ReplacementFor_X509*
ReplacementFor_server_cert)const;bool 
ReplacementFor_verify_host_with_subject_alt_name(ReplacementFor_X509*
ReplacementFor_server_cert)const;bool 
ReplacementFor_verify_host_with_common_name(ReplacementFor_X509*
ReplacementFor_server_cert)const;bool ReplacementFor_check_host_name(const char*
pattern,size_t ReplacementFor_pattern_len)const;ReplacementFor_SSL_CTX*
ReplacementFor_ctx_;std::mutex ReplacementFor_ctx_mutex_;std::once_flag 
ReplacementFor_initialize_cert_;std::vector<std::string>
ReplacementFor_host_components_;std::string ReplacementFor_ca_cert_file_path_;
std::string ReplacementFor_ca_cert_dir_path_;long ReplacementFor_verify_result_=
((0x1e16+234-0x16a0)+(0x23ba+655-0x2208)-(0xd07+9134-0x2414));friend class 
ReplacementFor_ClientImpl;};
#endif
}
#endif 


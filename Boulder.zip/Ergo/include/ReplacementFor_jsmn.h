
#ifndef ReplacementFor_ReplacementFor_JSMN_H
#define ReplacementFor_ReplacementFor_JSMN_H
#include <stddef.h>
#ifdef __cplusplus
extern"C"{
#endif
typedef enum{ReplacementFor_ReplacementFor_JSMN_UNDEFINED=(0xdd1+1875-0x1524),
ReplacementFor_ReplacementFor_JSMN_OBJECT=(0x11ab+2344-0x1ad2),ReplacementFor_ReplacementFor_JSMN_ARRAY=
(0x2dc+3161-0xf33),ReplacementFor_ReplacementFor_JSMN_STRING=(0x1784+3795-0x2654),
ReplacementFor_ReplacementFor_JSMN_PRIMITIVE=(0x2b2+4850-0x15a0)}ReplacementFor_ReplacementFor_jsmntype_t;enum
 ReplacementFor_ReplacementFor_jsmnerr{ReplacementFor_ReplacementFor_JSMN_ERROR_NOMEM=-(0x12d2+1764-0x19b5),
ReplacementFor_ReplacementFor_JSMN_ERROR_INVAL=-(0x10a9+837-0x13ec),
ReplacementFor_ReplacementFor_JSMN_ERROR_PART=-(0x9fa+6625-0x23d8)};typedef struct{
ReplacementFor_ReplacementFor_jsmntype_t type;int ReplacementFor_ReplacementFor_start;int end;int size;
#ifdef ReplacementFor_ReplacementFor_JSMN_PARENT_LINKS
int ReplacementFor_ReplacementFor_parent;
#endif
}ReplacementFor_ReplacementFor_jsmntok_t;typedef struct{unsigned int pos;unsigned int 
ReplacementFor_ReplacementFor_toknext;int ReplacementFor_ReplacementFor_toksuper;}ReplacementFor_ReplacementFor_jsmn_parser;
void ReplacementFor_ReplacementFor_jsmn_init(ReplacementFor_ReplacementFor_jsmn_parser*ReplacementFor_ReplacementFor_parser);
int ReplacementFor_ReplacementFor_jsmn_parse(ReplacementFor_ReplacementFor_jsmn_parser*ReplacementFor_ReplacementFor_parser,
const char*ReplacementFor_ReplacementFor_js,size_t len,ReplacementFor_ReplacementFor_jsmntok_t*
ReplacementFor_ReplacementFor_tokens,unsigned int ReplacementFor_ReplacementFor_num_tokens);
#ifdef __cplusplus
}
#endif
#endif 



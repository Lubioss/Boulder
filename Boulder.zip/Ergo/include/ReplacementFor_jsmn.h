
#ifndef ReplacementFor_JSMN_H
#define ReplacementFor_JSMN_H
#include <stddef.h>
#ifdef __cplusplus
extern"C"{
#endif
typedef enum{ReplacementFor_JSMN_UNDEFINED=((0x11db+2250-0xcd4)+
(0x898+3097-0xd5e)-(0x16ec+7220-0x1dfc)),ReplacementFor_JSMN_OBJECT=(
(0x21e0+1878-0x178b)+(0x1a60+4092-0x2134)-6866),ReplacementFor_JSMN_ARRAY=(
(0x1385+4796-0x2365)+(0x10f4+7925-0x2390)-(0x1dd2+3094-0x1ab5)),
ReplacementFor_JSMN_STRING=(6020+(0x1a30+3309-0x184a)-9812),
ReplacementFor_JSMN_PRIMITIVE=((0xa88+1820-0xef2)+(0x1372+6022-0x1806)-
(0x2598+2508-0x19c4))}ReplacementFor_jsmntype_t;enum ReplacementFor_jsmnerr{
ReplacementFor_JSMN_ERROR_NOMEM=-(4818+(0x12b6+2912-0x1732)-(0x25b0+27-0xc16)),
ReplacementFor_JSMN_ERROR_INVAL=-((0x1399+4342-0x13e6)+(0x68b+6721-0x1d87)-
(0x211f+3604-0x1b47)),ReplacementFor_JSMN_ERROR_PART=-((0x1d11+4278-0x23cd)+
(0x22a3+1078-0xcf8)-(0x2404+2334-0x94a))};typedef struct{
ReplacementFor_jsmntype_t type;int ReplacementFor_start;int end;int size;
#ifdef ReplacementFor_JSMN_PARENT_LINKS
int ReplacementFor_parent;
#endif
}ReplacementFor_jsmntok_t;typedef struct{unsigned int pos;unsigned int 
ReplacementFor_toknext;int ReplacementFor_toksuper;}ReplacementFor_jsmn_parser;
void ReplacementFor_jsmn_init(ReplacementFor_jsmn_parser*ReplacementFor_parser);
int ReplacementFor_jsmn_parse(ReplacementFor_jsmn_parser*ReplacementFor_parser,
const char*ReplacementFor_js,size_t len,ReplacementFor_jsmntok_t*
ReplacementFor_tokens,unsigned int ReplacementFor_num_tokens);
#ifdef __cplusplus
}
#endif
#endif 


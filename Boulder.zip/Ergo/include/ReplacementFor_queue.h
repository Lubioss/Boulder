
#ifndef ReplacementFor_ReplacementFor_QUEUE_H
#define ReplacementFor_ReplacementFor_QUEUE_H
#include "ReplacementFor_definitions.h"
#include <mutex>
#include <condition_variable>
#include <vector>
#include <deque>
#include <iostream>
struct ReplacementFor_ReplacementFor_rShare{ReplacementFor_ReplacementFor_rShare();ReplacementFor_ReplacementFor_rShare(
uint64_t ReplacementFor_ReplacementFor__nonce){ReplacementFor_ReplacementFor_nonce=ReplacementFor_ReplacementFor__nonce;}
uint64_t ReplacementFor_ReplacementFor_nonce;};template<class T>class ReplacementFor_ReplacementFor_BlockQueue
{std::deque<T>ReplacementFor_ReplacementFor_cont;std::mutex ReplacementFor_ReplacementFor_mut;std::
condition_variable ReplacementFor_ReplacementFor_condv;public:void put(T&val){
ReplacementFor_ReplacementFor_mut.lock();ReplacementFor_ReplacementFor_cont.push_front(val);ReplacementFor_ReplacementFor_mut
.unlock();ReplacementFor_ReplacementFor_condv.notify_one();}void put(T&&val){ReplacementFor_ReplacementFor_mut
.lock();ReplacementFor_ReplacementFor_cont.push_front(val);ReplacementFor_ReplacementFor_mut.unlock();
ReplacementFor_ReplacementFor_condv.notify_one();}T get(){std::unique_lock<std::mutex>lock(
ReplacementFor_ReplacementFor_mut);ReplacementFor_ReplacementFor_condv.wait(lock,[=]{return!
ReplacementFor_ReplacementFor_cont.empty();});T ReplacementFor_ReplacementFor_tmp=ReplacementFor_ReplacementFor_cont.back();
ReplacementFor_ReplacementFor_cont.pop_back();return ReplacementFor_ReplacementFor_tmp;}};
#endif




#include "../include/ReplacementFor_conversion.h"
#include "../include/ReplacementFor_definitions.h"
#include "../include/ReplacementFor_easylogging.h"
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int ReplacementFor_DecStrToHexStrOf64(const char*in,const uint32_t 
ReplacementFor_inlen,char*out){
#ifndef _WIN32
uint32_t fs[ReplacementFor_inlen];
#else
uint32_t fs[((0x2265+8200-0x211c)+(0x16d8+2995-0x1cbd)-8991)];
#endif
uint32_t ReplacementFor_tmp;uint32_t rem;uint32_t ReplacementFor_ip;for(int i=
ReplacementFor_inlen-((0x19ea+6801-0x1f80)+(0x141b+557-0xe1c)-7462),k=(
(0x436+4808-0x1514)+6566-7056);i>=((0x1348+5140-0x2298)+(0x1e70+602-0x1909)-
(0x1581+93-0x959));--i){if(in[i]>=((char)((0x1ff3+1087-0x2199)+
(0xaf3+2522-0xbdb)-(0x1ded+4402-0x23c4)))&&in[i]<=((char)((0x44d+3571-0xffe)+
(0x1cf3+4818-0x23cc)-(0x16e3+1714-0xf93)))){fs[k++]=(uint32_t)(in[i]-((char)(
(0xae2+175-0x96b)+(0xeda+3943-0x14b0)-(0x26cc+2028-0x2331))));}else{char 
ReplacementFor_errbuf[((0x16a1+1381-0xe31)+2173-4690)];ReplacementFor_errbuf[(
(0x1400+4978-0x26f7)+(0x156c+5218-0x2174)-(0xc6c+4686-0x15e5))]='\0';strncat(
ReplacementFor_errbuf,in,ReplacementFor_inlen);LOG(ERROR)<<
"\x44\x65\x63\x53\x74\x72\x54\x6f\x48\x65\x78\x53\x74\x72\x4f\x66\x36\x34\x20\x66\x61\x69\x6c\x65\x64\x20\x6f\x6e\x20\x73\x74\x72\x69\x6e\x67\x20"
<<ReplacementFor_errbuf;ReplacementFor_CALL(((0x10b8+4133-0x1bb5)+
(0x14df+1744-0x1a40)-(0x1319+5131-0x208d)),ReplacementFor_ERROR_IO);}}uint32_t 
ReplacementFor_ts[((0x1835+1045-0x17c9)+(0x1ef1+2928-0x1306)-7058)]={(4732+
(0xac6+2205-0xfdd)-5633)};uint32_t ReplacementFor_accs[((0x1bf5+5685-0x2628)+
(0x1a0d+1251-0x1b6c)-(0x1201+4501-0x145a))]={((0x1660+180-0x533)+
(0x195a+886-0xd3d)-8564)};for(ReplacementFor_uint_t i=(7563+(0x2443+160-0x1d4e)-
(0x270d+7215-0x1e1c));i<ReplacementFor_inlen;++i){for(int j=(
(0x1ccb+4417-0x1bd7)+(0xbaa+2341-0x12e8)-(0x2584+210-0x123a));j<(
(0x198a+2626-0x133d)+(0x165f+4925-0x2059)-(0x1ab2+1758-0x7fe));++j){
ReplacementFor_accs[j]+=ReplacementFor_ts[j]*fs[i];ReplacementFor_tmp=
ReplacementFor_accs[j];rem=((0x19d9+4860-0x2504)+7606-9607);ReplacementFor_ip=j;
do{rem=ReplacementFor_tmp>>((0xf71+8560-0x25e7)+(0x1a6d+6947-0x1c5c)-9258);
ReplacementFor_accs[ReplacementFor_ip++]=ReplacementFor_tmp-(rem<<(
(0x19e6+964-0xeb5)+(0x18f1+3525-0xf4c)-9819));ReplacementFor_accs[
ReplacementFor_ip]+=rem;ReplacementFor_tmp=ReplacementFor_accs[ReplacementFor_ip
];}while(ReplacementFor_tmp>=((0x157a+757-0xb0d)+5436-8846));}for(int j=(5315+
(0x2519+2226-0x2371)-(0x2168+7206-0x1e71));j<((0x1387+515-0x10b6)+
(0x22d7+2937-0x1083)-8801);++j){ReplacementFor_ts[j]*=((0x13ea+1722-0x141c)+6892
-8554);}for(int j=((0x25b4+7418-0x248f)+(0x202f+2089-0x21d7)-(0x24db+911-0x3ca))
;j<((0x1cc3+1905-0xe7d)+(0x1b66+177-0x15c1)-7117);++j){ReplacementFor_tmp=
ReplacementFor_ts[j];rem=((0x110c+2642-0x124f)+4204-(0x1cdf+7608-0x211c));
ReplacementFor_ip=j;do{rem=ReplacementFor_tmp>>((0x1496+140-0x4a6)+
(0x147d+2287-0x902)-9442);ReplacementFor_ts[ReplacementFor_ip++]=
ReplacementFor_tmp-(rem<<((0x14dd+4174-0x15e4)+(0x797+3818-0x1633)-3985));
ReplacementFor_ts[ReplacementFor_ip]+=rem;ReplacementFor_tmp=ReplacementFor_ts[
ReplacementFor_ip];}while(ReplacementFor_tmp>=((0x2478+1990-0x17e6)+
(0x1110+5342-0x1bfb)-(0x1f04+6482-0x1a1b)));}}for(int i=((0x214b+1846-0x20b1)+
(0x224c+160-0x4cb)-9650);i>=((0x2181+2855-0x242b)+(0x1906+1921-0x1663)-
(0x1343+411-0x23d));--i){out[((0x21c7+534-0x1a85)+7210-9539)-i]=(
ReplacementFor_accs[i]<((0x1934+3486-0x112d)+(0xff9+455-0x943)-
(0x1f1c+4586-0x12ee)))?(char)(ReplacementFor_accs[i]+((char)((0xef9+2131-0x1531)
+(0x265c+5684-0x2468)-6675))):(char)(ReplacementFor_accs[i]+((char)(
(0xb4c+1284-0xf13)+(0x1cbb+537-0x1759)-(0xfac+6248-0x1f9d)))-(
(0xd8a+4764-0x1731)+(0x19a5+1801-0x1c6d)-(0x1438+7825-0x259d)));}out[(
(0xe00+7472-0x1fd4)+6805-9649)]='\0';return((0x7f4+7753-0x200d)+6087-7671);}void
 ReplacementFor_HexStrToBigEndian(const char*in,const uint32_t 
ReplacementFor_inlen,uint8_t*out,const uint32_t ReplacementFor_outlen){memset(
out,((0x1dc6+2738-0x247b)+7827-8848),ReplacementFor_outlen);for(
ReplacementFor_uint_t i=(ReplacementFor_outlen<<((0x134d+4211-0x182c)+
(0xd04+7452-0x22fc)-(0x13e8+3052-0xd1d)))-ReplacementFor_inlen;i<(
ReplacementFor_outlen<<((0xcd4+6681-0x24cd)+(0xe34+44-0xd02)-
(0x1428+1649-0x171c)));++i){out[i>>((0x14e8+422-0x499)+(0x230a+1479-0x1c3c)-7817
)]|=(((in[i]>=((char)((0x1134+2031-0x9e2)+4372-8212)))?in[i]-((char)(4257+
(0xfd8+4970-0x22ff)-(0x142a+2697-0xe10)))+((0x205a+2339-0x1c49)+
(0x1787+5111-0x1780)-8488):in[i]-((char)((0x10ab+3939-0x1ee1)+
(0x165d+7692-0x1fe5)-5505)))&(2172+3433-(0x1eda+7138-0x24e6)))<<((!(i&(
(0x1e69+718-0x1453)+(0x9f6+5807-0x1e24)-(0x16ed+3781-0x164e))))<<(
(0x13cf+2640-0xb74)+(0x16c8+6162-0x1fc8)-8635));}return;}void 
ReplacementFor_HexStrToLittleEndian(const char*in,const uint32_t 
ReplacementFor_inlen,uint8_t*out,const uint32_t ReplacementFor_outlen){memset(
out,((0x1711+7996-0x2572)+(0x2027+624-0x143c)-7990),ReplacementFor_outlen);for(
ReplacementFor_uint_t i=(2994+(0x1fd2+1447-0x1ea3)-(0x1641+8768-0x25f9));i<
ReplacementFor_inlen;++i){out[i>>((0x158c+359-0x1186)+(0x2210+4515-0x1fa5)-6522)
]|=(((in[ReplacementFor_inlen-i-((0x15c5+2810-0x1d67)+(0x23a7+1997-0x1790)-5947)
]>=((char)((0x22e6+2230-0xf8f)+(0x264a+1627-0x26f1)-8576)))?in[
ReplacementFor_inlen-i-((0x26fc+906-0x19dd)+(0xb54+4084-0x150f)-5857)]-((char)(
(0x1913+715-0x101c)+(0x161c+5124-0x15bc)-8165))+((0x938+6335-0x1afe)+
(0x1244+4297-0x22f5)-(0x1b48+3829-0x2336)):in[ReplacementFor_inlen-i-(
(0xc58+2121-0x142e)+7813-7927)]-((char)((0xaa6+6853-0x214a)+(0xc40+1831-0x135f)-
(0xe60+3103-0x1686))))&((0x10a1+2703-0xedb)+(0x267a+6107-0x2551)-9546))<<(((i&(
(0x3f9+7079-0x1dce)+(0xc17+1872-0x131b)-(0x975+4507-0x18f3))))<<(
(0x121b+5187-0x195b)+(0xcb3+509-0x2c2)-6383));}return;}void 
ReplacementFor_LittleEndianOf256ToDecStr(const uint8_t*in,char*out,uint32_t*
ReplacementFor_outlen){uint32_t fs[((0xcb3+5913-0x1792)+(0x1b09+7597-0x252a)-
8070)];uint32_t ReplacementFor_tmp;uint32_t rem;uint32_t ReplacementFor_ip;for(
int i=((0x16bf+4503-0x1b54)+(0x23fb+1998-0x2116)-(0x22a7+6828-0x259e));i<(
(0x94a+2484-0xf85)+(0x1acd+677-0x650)-(0x25f3+2697-0x1621));++i){fs[i]=(uint32_t
)(in[i>>((0x2311+682-0xe0e)+(0x2561+35-0x1a50)-8928)]>>(((i&((0xa74+1491-0x738)+
4451-6769)))<<((0x2410+3484-0x118c)+(0x2d4+5640-0x1778)-8578)))&(
(0xb37+7840-0x254f)+(0x1d5f+3580-0x2032)-(0x2274+702-0x1590));}uint32_t 
ReplacementFor_ts[(4470+(0x23a2+375-0x10f3)-9538)]={((0xe92+6073-0x234a)+
(0x2331+2615-0x1bff)-(0x2210+1559-0x13be))};uint32_t ReplacementFor_accs[(7408+
(0xf34+3663-0x1c3c)-7645)]={((0x2033+6660-0x1b8c)+(0x770+32-0xe2)-
(0x25c4+541-0x288))};for(int i=((0x1d7d+5609-0x19f9)+(0xb0d+1537-0x699)-9186);i<
((0xf63+3222-0x1579)+(0xd86+6392-0x22f4)-(0x1483+1555-0x10cc));++i){for(int j=(
(0xa57+2209-0xda6)+(0x770+5535-0x1737)-2858);j<((0xff1+1215-0x1335)+
(0xd47+6057-0x211a)-(0x85d+5586-0x192c));++j){ReplacementFor_accs[j]+=
ReplacementFor_ts[j]*fs[i];ReplacementFor_tmp=ReplacementFor_accs[j];rem=(6498+
(0x899+3794-0x16a4)-(0x22d2+213-0x97e));ReplacementFor_ip=j;do{rem=
ReplacementFor_tmp/((0xa61+9644-0x25f0)+(0x24e2+5898-0x2504)-8443);
ReplacementFor_accs[ReplacementFor_ip++]=ReplacementFor_tmp-rem*(
(0xf13+216-0x869)+(0x133c+9107-0x24ea)-6493);ReplacementFor_accs[
ReplacementFor_ip]+=rem;ReplacementFor_tmp=ReplacementFor_accs[ReplacementFor_ip
];}while(ReplacementFor_tmp>=((0x19ad+3876-0x1f36)+(0x1f8b+4488-0x17ad)-8951));}
for(int j=((0x178d+4048-0x1543)+(0x1c5a+1526-0x1376)-8436);j<(
(0x1a83+281-0x1a78)+(0x1f4f+3476-0x218d)-3116);++j){ReplacementFor_ts[j]<<=(
(0xa90+7481-0x2283)+4589-5935);}for(int j=(9051+(0x1032+3972-0x1c79)-9880);j<(
(0x22bb+1065-0x1c8f)+6786-9353);++j){ReplacementFor_tmp=ReplacementFor_ts[j];rem
=((0xc7b+3070-0x168f)+(0x85b+4926-0x1702)-(0x1323+3947-0x1c0d));
ReplacementFor_ip=j;do{rem=ReplacementFor_tmp/((0xbc1+7310-0x22c5)+
(0x1b64+145-0x17cf)-(0x1301+7083-0x2506));ReplacementFor_ts[ReplacementFor_ip++]
=ReplacementFor_tmp-rem*(4567+(0x175c+4030-0x23c4)-5411);ReplacementFor_ts[
ReplacementFor_ip]+=rem;ReplacementFor_tmp=ReplacementFor_ts[ReplacementFor_ip];
}while(ReplacementFor_tmp>=(7833+(0xd5b+6613-0x24fc)-8387));}}int k=(
(0x1577+2372-0x1860)+(0x1364+4681-0x1f9d)-(0x232b+4060-0x269c));int 
ReplacementFor_lead=((0x1dac+6576-0x2647)+(0x1cfc+3149-0x2305)-
(0x23d4+2432-0x15fc));for(int i=((0x23c5+3267-0x20d7)+(0x1acc+4666-0x1c0c)-
(0x25bb+7039-0x20dc));i>=((0x1ea3+7156-0x2463)+(0x1466+4516-0x223d)-
(0x1fe5+6463-0x1f23));--i){if(ReplacementFor_lead){if(!(ReplacementFor_accs[i]))
{continue;}else{ReplacementFor_lead=((0xd3f+527-0x2f2)+(0xd61+2973-0xcfc)-
(0x1f92+587-0x97f));}}out[k++]=(char)(ReplacementFor_accs[i]+((char)(
(0x15b4+2061-0x1745)+7958-9570)));}out[k]='\0';*ReplacementFor_outlen=k;return;}
void ReplacementFor_LittleEndianToHexStr(const uint8_t*in,const uint32_t 
ReplacementFor_inlen,char*out){uint8_t ReplacementFor_dig;for(int i=(
ReplacementFor_inlen<<((0x1d56+517-0x164a)+(0x1291+6587-0x2265)-
(0x1cfa+2186-0x128d)))-((0x1c42+3356-0x22b7)+(0x1c10+6330-0x2323)-
(0x1efd+972-0xa7c));i>=((0x1fcb+1743-0x15de)+(0x8a5+8576-0x259d)-
(0x2661+693-0x13d2));--i){ReplacementFor_dig=(uint8_t)(in[i>>(
(0x16d3+2183-0x1e30)+(0xf95+7992-0x25b0)-2630)]>>((i&((0x1642+829-0x1813)+3921-
(0x2352+166-0x133c)))<<((0x1ed7+1383-0x1893)+(0x19ad+2450-0x1906)-5602)))&(
(0x1228+5277-0x1e70)+4909-(0x1c57+666-0x37e));out[(ReplacementFor_inlen<<(
(0x1d67+2229-0x212b)+8377-9641))-i-((0xca8+2140-0xc60)+(0xe6c+4908-0x1551)-
(0x1581+9293-0x24e4))]=(ReplacementFor_dig<=((0x16ac+3132-0x1c27)+
(0x2533+2088-0x1f66)-(0x1728+2097-0xaac)))?(char)ReplacementFor_dig+((char)(
(0x813+5843-0x1e6b)+(0x19e2+166-0xbda)-(0x1f92+3454-0x1e17))):(char)
ReplacementFor_dig+((char)((0x1215+2571-0x10b7)+(0x14e4+1843-0x90c)-
(0x2696+2908-0x13bf)))-((0x1ffd+5000-0x2482)+(0x257b+1515-0x2118)-
(0x26fd+5691-0x23f1));}out[ReplacementFor_inlen<<((0x119+9192-0x241d)+6383-
(0x230f+2440-0x12c5))]='\0';return;}void ReplacementFor_BigEndianToHexStr(const 
uint8_t*in,const uint32_t ReplacementFor_inlen,char*out){uint8_t 
ReplacementFor_dig;for(ReplacementFor_uint_t i=((0x1d5c+4636-0x2395)+5879-
(0x26da+4837-0x16e5));i<ReplacementFor_inlen<<(8144+(0x1236+1911-0x1831)-8523);
++i){ReplacementFor_dig=(uint8_t)(in[i>>((0xc79+6563-0x1f08)+5535-
(0x24d7+3647-0x1664))]>>(!(i&((0x1f2c+2706-0x15f7)+(0x14c5+284-0x8d6)-8401))<<(
(0x1f08+2640-0x22f0)+(0x245b+7613-0x22b2)-9676)))&((0x1ebc+458-0xd1d)+
(0xcdf+224-0x25c)-(0x2510+208-0x723));out[i]=(ReplacementFor_dig<=(
(0x2196+4970-0x193f)+(0x375+6813-0x1b20)-7850))?(char)ReplacementFor_dig+((char)
((0xc88+511-0xc56)+7693-8206)):(char)ReplacementFor_dig+((char)(
(0x1932+2537-0x1020)+(0x1649+7475-0x2198)-9374))-((0x1c4d+4811-0x1a7b)+
(0xda6+7641-0x20f7)-7963);}out[ReplacementFor_inlen<<((0x1b1f+3018-0xfb6)+
(0x1d79+1684-0x1ed4)-(0x1dd7+8583-0x22f3))]='\0';return;}

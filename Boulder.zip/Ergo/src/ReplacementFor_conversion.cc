
#include "../include/ReplacementFor_conversion.h"
#include "../include/ReplacementFor_definitions.h"
#include "../include/ReplacementFor_easylogging.h"
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int ReplacementFor_ReplacementFor_DecStrToHexStrOf64(const char*in,const uint32_t 
ReplacementFor_ReplacementFor_inlen,char*out){
#ifndef _WIN32
uint32_t fs[ReplacementFor_ReplacementFor_inlen];
#else
uint32_t fs[(0x2151+1486-0x231f)];
#endif
uint32_t ReplacementFor_ReplacementFor_tmp;uint32_t rem;uint32_t ReplacementFor_ReplacementFor_ip;for(int i=
ReplacementFor_ReplacementFor_inlen-(0x14fb+2092-0x1d26),k=(0x1ea+6566-0x1b90);i>=
(0x4c4+1985-0xc85);--i){if(in[i]>=((char)(0x299+2290-0xb5b))&&in[i]<=
((char)(0x242+3065-0xe02))){fs[k++]=(uint32_t)(in[i]-((char)(0x226+2449-0xb87)))
;}else{char ReplacementFor_ReplacementFor_errbuf[(0xdd5+2173-0x1252)];ReplacementFor_ReplacementFor_errbuf[
(0x7b+2138-0x8d5)]='\0';strncat(ReplacementFor_ReplacementFor_errbuf,in,ReplacementFor_ReplacementFor_inlen);
LOG(ERROR)<<
"\x44\x65\x63\x53\x74\x72\x54\x6f\x48\x65\x78\x53\x74\x72\x4f\x66\x36\x34\x20\x66\x61\x69\x6c\x65\x64\x20\x6f\x6e\x20\x73\x74\x72\x69\x6e\x67\x20"
<<ReplacementFor_ReplacementFor_errbuf;ReplacementFor_ReplacementFor_CALL((0x528+367-0x697),
ReplacementFor_ReplacementFor_ERROR_IO);}}uint32_t ReplacementFor_ReplacementFor_ts[(0x481+5979-0x1b92)]={
(0x127c+902-0x1601)};uint32_t ReplacementFor_ReplacementFor_accs[(0xc02+900-0xf3c)]={
(0x11e1+3987-0x2174)};for(ReplacementFor_ReplacementFor_uint_t i=(0x1d8b+1941-0x2520);i<
ReplacementFor_ReplacementFor_inlen;++i){for(int j=(0x1235+487-0x141c);j<(0x108f+2371-0x1992);
++j){ReplacementFor_ReplacementFor_accs[j]+=ReplacementFor_ReplacementFor_ts[j]*fs[i];ReplacementFor_ReplacementFor_tmp=
ReplacementFor_ReplacementFor_accs[j];rem=(0x7d1+7606-0x2587);ReplacementFor_ReplacementFor_ip=j;do{rem=
ReplacementFor_ReplacementFor_tmp>>(0xafa+6452-0x242a);ReplacementFor_ReplacementFor_accs[ReplacementFor_ReplacementFor_ip++]
=ReplacementFor_ReplacementFor_tmp-(rem<<(0xef5+5994-0x265b));ReplacementFor_ReplacementFor_accs[
ReplacementFor_ReplacementFor_ip]+=rem;ReplacementFor_ReplacementFor_tmp=ReplacementFor_ReplacementFor_accs[ReplacementFor_ReplacementFor_ip
];}while(ReplacementFor_ReplacementFor_tmp>=(0xd62+5436-0x228e));}for(int j=
(0x14c3+2650-0x1f1d);j<(0x4d4+7629-0x2261);++j){ReplacementFor_ReplacementFor_ts[j]*=
(0x688+6892-0x216a);}for(int j=(0x1e1f+1665-0x24a0);j<(0x15b7+1622-0x1bcd);++j){
ReplacementFor_ReplacementFor_tmp=ReplacementFor_ReplacementFor_ts[j];rem=(0x90f+4204-0x197b);
ReplacementFor_ReplacementFor_ip=j;do{rem=ReplacementFor_ReplacementFor_tmp>>(0x107c+5226-0x24e2);
ReplacementFor_ReplacementFor_ts[ReplacementFor_ReplacementFor_ip++]=ReplacementFor_ReplacementFor_tmp-(rem<<(0xf47+78-0xf91)
);ReplacementFor_ReplacementFor_ts[ReplacementFor_ReplacementFor_ip]+=rem;ReplacementFor_ReplacementFor_tmp=ReplacementFor_ReplacementFor_ts
[ReplacementFor_ReplacementFor_ip];}while(ReplacementFor_ReplacementFor_tmp>=(0x1458+2547-0x1e3b));}}for(int i
=(0x7d0+7713-0x25b2);i>=(0x87d+2596-0x12a1);--i){out[(0x958+7210-0x2543)-i]=(
ReplacementFor_ReplacementFor_accs[i]<(0x15a5+2173-0x1e18))?(char)(ReplacementFor_ReplacementFor_accs[i]+
((char)(0x21b+6184-0x1a13))):(char)(ReplacementFor_ReplacementFor_accs[i]+
((char)(0x13d+1915-0x877))-(0x8f5+1089-0xd2c));}out[(0xb5c+6805-0x25b1)]='\0';
return(0x630+6087-0x1df7);}void ReplacementFor_ReplacementFor_HexStrToBigEndian(const char*in,
const uint32_t ReplacementFor_ReplacementFor_inlen,uint8_t*out,const uint32_t 
ReplacementFor_ReplacementFor_outlen){memset(out,(0x3fd+7827-0x2290),ReplacementFor_ReplacementFor_outlen);for
(ReplacementFor_ReplacementFor_uint_t i=(ReplacementFor_ReplacementFor_outlen<<(0xb94+1828-0x12b7))-
ReplacementFor_ReplacementFor_inlen;i<(ReplacementFor_ReplacementFor_outlen<<(0x220+350-0x37d));++i){out[i>>
(0x11f5+3221-0x1e89)]|=(((in[i]>=((char)(0xf41+4372-0x2014)))?in[i]-
((char)(0x10a1+67-0x10a3))+(0xd34+5118-0x2128):in[i]-((char)(0x12d+5252-0x1581))
)&(0x87c+3433-0x15d6))<<((!(i&(0xce4+641-0xf64)))<<(0x12ab+3858-0x21bb));}return
;}void ReplacementFor_ReplacementFor_HexStrToLittleEndian(const char*in,const uint32_t 
ReplacementFor_ReplacementFor_inlen,uint8_t*out,const uint32_t ReplacementFor_ReplacementFor_outlen){memset(
out,(0x10db+3675-0x1f36),ReplacementFor_ReplacementFor_outlen);for(ReplacementFor_ReplacementFor_uint_t i=
(0xbb2+1750-0x1288);i<ReplacementFor_ReplacementFor_inlen;++i){out[i>>(0x56d+5134-0x197a)]|=(((
in[ReplacementFor_ReplacementFor_inlen-i-(0x358+5092-0x173b)]>=((char)(0x1c0d+1460-0x2180)))?in
[ReplacementFor_ReplacementFor_inlen-i-(0x10a9+1593-0x16e1)]-((char)(0xbc2+5220-0x1fe5))+
(0x6f9+24-0x707):in[ReplacementFor_ReplacementFor_inlen-i-(0x73+7813-0x1ef7)]-
((char)(0x421+8-0x3f9)))&(0xc55+6404-0x254a))<<(((i&(0x1d2+76-0x21d)))<<
(0xd03+3054-0x18ef));}return;}void ReplacementFor_ReplacementFor_LittleEndianOf256ToDecStr(
const uint8_t*in,char*out,uint32_t*ReplacementFor_ReplacementFor_outlen){uint32_t fs[
(0xc3a+5004-0x1f86)];uint32_t ReplacementFor_ReplacementFor_tmp;uint32_t rem;uint32_t 
ReplacementFor_ReplacementFor_ip;for(int i=(0xd02+2739-0x17b5);i<(0x379+5922-0x1a5b);++i){fs[i]
=(uint32_t)(in[i>>(0x17ad+2868-0x22e0)]>>(((i&(0x90f+4451-0x1a71)))<<
(0x2020+356-0x2182)))&(0x488+2857-0xfa2);}uint32_t ReplacementFor_ReplacementFor_ts[
(0x1176+5158-0x2542)]={(0x301+4457-0x1469)};uint32_t ReplacementFor_ReplacementFor_accs[
(0x1cf0+327-0x1ddd)]={(0x1eab+1710-0x2559)};for(int i=(0x196d+2677-0x23e2);i<
(0x680+906-0x9ca);++i){for(int j=(0x552+1496-0xb2a);j<(0x17b+982-0x503);++j){
ReplacementFor_ReplacementFor_accs[j]+=ReplacementFor_ReplacementFor_ts[j]*fs[i];ReplacementFor_ReplacementFor_tmp=
ReplacementFor_ReplacementFor_accs[j];rem=(0x1962+199-0x1a29);ReplacementFor_ReplacementFor_ip=j;do{rem=
ReplacementFor_ReplacementFor_tmp/(0xa1d+5864-0x20fb);ReplacementFor_ReplacementFor_accs[ReplacementFor_ReplacementFor_ip++]=
ReplacementFor_ReplacementFor_tmp-rem*(0x782+4581-0x195d);ReplacementFor_ReplacementFor_accs[ReplacementFor_ReplacementFor_ip
]+=rem;ReplacementFor_ReplacementFor_tmp=ReplacementFor_ReplacementFor_accs[ReplacementFor_ReplacementFor_ip];}while(
ReplacementFor_ReplacementFor_tmp>=(0x99b+6502-0x22f7));}for(int j=(0x121a+3802-0x20f4);j<
(0x124+2902-0xc2c);++j){ReplacementFor_ReplacementFor_ts[j]<<=(0x546+4589-0x172f);}for(int j=
(0x235b+829-0x2698);j<(0xa55+6786-0x2489);++j){ReplacementFor_ReplacementFor_tmp=
ReplacementFor_ReplacementFor_ts[j];rem=(0x1ea+1175-0x681);ReplacementFor_ReplacementFor_ip=j;do{rem=
ReplacementFor_ReplacementFor_tmp/(0x58a+1062-0x9a6);ReplacementFor_ReplacementFor_ts[ReplacementFor_ReplacementFor_ip++]=
ReplacementFor_ReplacementFor_tmp-rem*(0x11d7+854-0x1523);ReplacementFor_ReplacementFor_ts[ReplacementFor_ReplacementFor_ip]
+=rem;ReplacementFor_ReplacementFor_tmp=ReplacementFor_ReplacementFor_ts[ReplacementFor_ReplacementFor_ip];}while(
ReplacementFor_ReplacementFor_tmp>=(0x1e99+564-0x20c3));}}int k=(0x65b+1552-0xc6b);int 
ReplacementFor_ReplacementFor_lead=(0x1115+1604-0x1758);for(int i=(0xfb1+4346-0x205e);i>=
(0x1634+973-0x1a01);--i){if(ReplacementFor_ReplacementFor_lead){if(!(ReplacementFor_ReplacementFor_accs[i])){
continue;}else{ReplacementFor_ReplacementFor_lead=(0xc5c+3074-0x185e);}}out[k++]=(char)(
ReplacementFor_ReplacementFor_accs[i]+((char)(0x67c+7958-0x2562)));}out[k]='\0';*
ReplacementFor_ReplacementFor_outlen=k;return;}void ReplacementFor_ReplacementFor_LittleEndianToHexStr(const 
uint8_t*in,const uint32_t ReplacementFor_ReplacementFor_inlen,char*out){uint8_t 
ReplacementFor_ReplacementFor_dig;for(int i=(ReplacementFor_ReplacementFor_inlen<<(0x911+2535-0x12f7))-
(0x6a7+4519-0x184d);i>=(0x10bc+1160-0x1544);--i){ReplacementFor_ReplacementFor_dig=(uint8_t)(in
[i>>(0x12a+2333-0xa46)]>>((i&(0x16c+3921-0x10bc))<<(0xbab+2617-0x15e2)))&
(0x855+4909-0x1b73);out[(ReplacementFor_ReplacementFor_inlen<<(0x4f1+8377-0x25a9))-i-
(0x8a4+3143-0x14ea)]=(ReplacementFor_ReplacementFor_dig<=(0x6c1+3573-0x14ad))?(char)
ReplacementFor_ReplacementFor_dig+((char)(0x7b+3758-0xef9)):(char)ReplacementFor_ReplacementFor_dig+
((char)(0xb69+4875-0x1e33))-(0xf03+2638-0x1947);}out[ReplacementFor_ReplacementFor_inlen<<
(0xe4+6383-0x19d2)]='\0';return;}void ReplacementFor_ReplacementFor_BigEndianToHexStr(const 
uint8_t*in,const uint32_t ReplacementFor_ReplacementFor_inlen,char*out){uint8_t 
ReplacementFor_ReplacementFor_dig;for(ReplacementFor_ReplacementFor_uint_t i=(0xbe3+5879-0x22da);i<
ReplacementFor_ReplacementFor_inlen<<(0x1fd0+380-0x214b);++i){ReplacementFor_ReplacementFor_dig=(uint8_t)(in[i
>>(0x714+5535-0x1cb2)]>>(!(i&(0x13c7+3339-0x20d1))<<(0x668+8038-0x25cc)))&
(0x1369+2915-0x1ebd);out[i]=(ReplacementFor_ReplacementFor_dig<=(0x1bc1+754-0x1eaa))?(char)
ReplacementFor_ReplacementFor_dig+((char)(0x231+7693-0x200e)):(char)ReplacementFor_ReplacementFor_dig+
((char)(0x12fb+4580-0x249e))-(0x149d+2696-0x1f1b);}out[ReplacementFor_ReplacementFor_inlen<<
(0x1733+1337-0x1c6b)]='\0';return;}



#include "../include/ReplacementFor_cpuAukos.h"
ReplacementFor_AukosAlg::ReplacementFor_AukosAlg(){ReplacementFor_m_str=new char
[((0x14d0+361-0xde3)+(0x18c+4142-0x1185)-(0x127c+5165-0x1e5e))];
ReplacementFor_bound_str=new char[((0x1613+289-0x14a7)+9208-9761)];
ReplacementFor_m_n=new uint8_t[ReplacementFor_NUM_SIZE_8+
ReplacementFor_NONCE_SIZE_8];ReplacementFor_p_w_m_n=new uint8_t[
ReplacementFor_PK_SIZE_8+ReplacementFor_PK_SIZE_8+ReplacementFor_NUM_SIZE_8+
ReplacementFor_NONCE_SIZE_8];ReplacementFor_Hinput=new uint8_t[sizeof(uint32_t)+
ReplacementFor_CONST_MES_SIZE_8+ReplacementFor_PK_SIZE_8+
ReplacementFor_NUM_SIZE_8+ReplacementFor_PK_SIZE_8];ReplacementFor_n_str=new 
char[ReplacementFor_NONCE_SIZE_4];ReplacementFor_h_str=new char[
ReplacementFor_HEIGHT_SIZE];int ReplacementFor_tr=sizeof(unsigned long long);for
(size_t i=((0xb0c+526-0x9b3)+(0x12ea+6534-0x1f19)-(0x1f18+3634-0x1c8c));i<
ReplacementFor_CONST_MES_SIZE_8/ReplacementFor_tr;i++){unsigned long long 
ReplacementFor_tmp=i;uint8_t ReplacementFor_tmp2[(5802+(0x2027+730-0x2014)-6543)
];uint8_t ReplacementFor_tmp1[((0x205f+1108-0x14a7)+(0x19b4+4426-0x1c09)-7929)];
memcpy(ReplacementFor_tmp1,&ReplacementFor_tmp,ReplacementFor_tr);
ReplacementFor_tmp2[((0x19c8+1562-0xf78)+(0xabf+4926-0x19a1)-(0x14d5+1496-0x5e7)
)]=ReplacementFor_tmp1[((0xf88+6057-0x1a7b)+(0x187f+5599-0x1db2)-7515)];
ReplacementFor_tmp2[((0xca5+5512-0x1864)+(0x16a5+405-0x5db)-(0x22e6+7296-0x233f)
)]=ReplacementFor_tmp1[(2324+(0x2462+2182-0x1618)-8158)];ReplacementFor_tmp2[(
(0x2219+1427-0x173f)+(0x10b9+5321-0x198d)-7264)]=ReplacementFor_tmp1[(
(0x10db+3294-0x17e4)+(0x197d+484-0xe0c)-(0x2119+1789-0x14f1))];
ReplacementFor_tmp2[((0x1930+2313-0x186f)+(0x23c2+111-0x229d)-
(0x174d+6859-0x26bd))]=ReplacementFor_tmp1[((0x38c+6009-0x1acb)+6816-6870)];
ReplacementFor_tmp2[(4698+(0x1d6b+109-0xf12)-8476)]=ReplacementFor_tmp1[(
(0x8e9+4265-0x181b)+8624-(0x23cf+202-0x175))];ReplacementFor_tmp2[(
(0x15c9+3650-0xfb2)+(0x1408+2530-0x1261)-(0x26a7+1086-0xb08))]=
ReplacementFor_tmp1[((0x18a6+3384-0x1c93)+(0x26e7+1864-0x1fb1)-6087)];
ReplacementFor_tmp2[(6945+(0x1a6+3765-0x104d)-6953)]=ReplacementFor_tmp1[(
(0x1374+5896-0x1cd9)+(0x1c84+3642-0x15ee)-8818)];ReplacementFor_tmp2[(4337+
(0xec9+1687-0x1009)-(0x1f79+3224-0x15d0))]=ReplacementFor_tmp1[(
(0x231+8422-0x21ef)+(0x1c26+8976-0x23f0)-(0x2087+888-0x791))];memcpy(&
ReplacementFor_CONST_MESS[i],ReplacementFor_tmp2,ReplacementFor_tr);}}
ReplacementFor_AukosAlg::~ReplacementFor_AukosAlg(){}void 
ReplacementFor_AukosAlg::ReplacementFor_Blake2b256(const char*in,const int len,
uint8_t*ReplacementFor_output,char*ReplacementFor_outstr){ReplacementFor_ctx_t 
ctx;uint64_t ReplacementFor_aux[((0xd2b+5513-0x1e69)+(0xc99+8533-0x2322)-
(0x1388+8438-0x2587))];memset(ctx.b,((0x1416+3550-0x15af)+(0x1b0d+5837-0x2127)-
(0x2088+3117-0xfbd)),((0x1be3+4397-0x26b7)+(0x1d55+5701-0x1a78)-
(0x2036+7804-0x1fb7)));ReplacementFor_B2B_IV(ctx.ReplacementFor_h);ctx.
ReplacementFor_h[((0x2120+1197-0x11f5)+(0x1fc0+1690-0x1c37)-7675)]^=16842752^
ReplacementFor_NUM_SIZE_8;memset(ctx.t,((0x1364+5997-0x1c9c)+5208-
(0x25bc+3875-0x1252)),((0xc84+8869-0x2467)+5947-(0x25b4+7317-0x205c)));ctx.c=(
(0x1604+6139-0x1ab6)+(0x602+5256-0x1a14)-(0x14ff+4572-0x131c));for(int i=(
(0xb7f+4919-0x1de2)+(0x1fef+4564-0x1a40)-(0x1a57+8168-0x21e8));i<len;++i){if(ctx
.c==((0x1afd+3251-0x1e79)+(0xfb1+371-0x7bd)-(0x1a76+4957-0x1bb5))){
ReplacementFor_HOST_B2B_H(&ctx,ReplacementFor_aux);}ctx.b[ctx.c++]=(uint8_t)(in[
i]);}ReplacementFor_HOST_B2B_H_LAST(&ctx,ReplacementFor_aux);for(int i=(
(0x1fc8+3429-0xe85)+(0x22aa+1636-0x22fb)-9403);i<ReplacementFor_NUM_SIZE_8;++i){
ReplacementFor_output[ReplacementFor_NUM_SIZE_8-i-((0x208a+8978-0x23b1)+
(0x8d1+3796-0x15ea)-8613)]=(ctx.ReplacementFor_h[i>>((0x137b+7455-0x2524)+
(0x24b1+1285-0x1457)-8402)]>>((i&((0xa85+4914-0x1848)+(0x1246+5500-0x173a)-5616)
)<<((0x2693+937-0x2583)+(0x18d0+3782-0x2499)-(0x83c+8637-0x2246))))&(
(0xa77+5927-0x1aab)+(0x2234+6172-0x1f33)-8465);}
ReplacementFor_LittleEndianToHexStr(ReplacementFor_output,
ReplacementFor_NUM_SIZE_8,ReplacementFor_outstr);}void ReplacementFor_AukosAlg::
ReplacementFor_GenIdex(const char*in,const int len,uint32_t*index){int a=
ReplacementFor_INDEX_SIZE_8;int b=ReplacementFor_K_LEN;int c=
ReplacementFor_NUM_SIZE_8;int ReplacementFor_d=ReplacementFor_NUM_SIZE_4;uint8_t
 ReplacementFor_sk[ReplacementFor_NUM_SIZE_8*((0xc07+4926-0x1c2d)+
(0xf15+388-0x7c8)-(0x1069+3814-0x1368))];char ReplacementFor_skstr[
ReplacementFor_NUM_SIZE_4+((0x16a7+8835-0x25b0)+4593-9569)];memset(
ReplacementFor_sk,((0x1392+2650-0x1964)+(0x1a69+2077-0x1462)-(0x1544+619-0x503))
,ReplacementFor_NUM_SIZE_8*((0x8d3+5566-0x1dac)+(0x226c+6439-0x26dc)-
(0x2119+19-0xb92)));memset(ReplacementFor_skstr,((0xcd3+3939-0x1a59)+
(0x21ba+4000-0x13f3)-8004),ReplacementFor_NUM_SIZE_4);ReplacementFor_Blake2b256(
in,len,ReplacementFor_sk,ReplacementFor_skstr);uint8_t ReplacementFor_beH[
ReplacementFor_PK_SIZE_8];ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr,
ReplacementFor_NUM_SIZE_4,ReplacementFor_beH,ReplacementFor_NUM_SIZE_8);uint32_t
*ReplacementFor_ind=index;memcpy(ReplacementFor_sk,ReplacementFor_beH,
ReplacementFor_NUM_SIZE_8);memcpy(ReplacementFor_sk+ReplacementFor_NUM_SIZE_8,
ReplacementFor_beH,ReplacementFor_NUM_SIZE_8);uint32_t ReplacementFor_tmpInd[(
(0x576+4228-0x15c9)+(0x15aa+2498-0x12ed)-(0x15ff+7179-0x257a))];int 
ReplacementFor_sliceIndex=((0x195c+751-0x11c1)+(0xe25+6187-0x24b5)-
(0x1659+6419-0x2347));for(int k=((0x1781+6110-0x24fc)+(0x10d8+5520-0x2016)-
(0x157c+6161-0x1cd8));k<ReplacementFor_K_LEN;k++){uint8_t ReplacementFor_tmp[(
(0x18fc+3509-0x23fa)+(0x1573+3130-0x12f1)-(0x1bff+6508-0x23fc))];memcpy(
ReplacementFor_tmp,ReplacementFor_sk+ReplacementFor_sliceIndex,(
(0xf96+1783-0x165b)+7021-(0x20da+3895-0x1476)));memcpy(&ReplacementFor_tmpInd[k]
,ReplacementFor_sk+ReplacementFor_sliceIndex,((0x3f4+5052-0x13d1)+6034-
(0x2000+6150-0x1c99)));uint8_t ReplacementFor_tmp2[((0x8c5+258-0x56e)+
(0x212a+1309-0x21a9)-(0x12b8+6437-0x22ea))];ReplacementFor_tmp2[(
(0x10df+3725-0x1a7d)+3782-(0x1426+6664-0x1a79))]=ReplacementFor_tmp[(
(0x1eeb+5166-0x247c)+(0x1112+3846-0x1ffc)-(0x1ff0+1169-0x15cb))];
ReplacementFor_tmp2[((0xa73+9428-0x264f)+(0x1bf5+4370-0x1273)-9099)]=
ReplacementFor_tmp[((0x1fa6+417-0x1e4a)+(0x1ca7+6107-0x1b81)-7164)];
ReplacementFor_tmp2[((0x1c5+6630-0x1b94)+9298-9319)]=ReplacementFor_tmp[(
(0x141b+3451-0x1f8d)+(0x535+2209-0xba8)-(0x143c+1158-0x148c))];
ReplacementFor_tmp2[(6882+(0x851+716-0x42b)-(0x2460+8128-0x224f))]=
ReplacementFor_tmp[((0x1a64+700-0x988)+(0x1374+1682-0xdc0)-(0x22c0+890-0x65c))];
memcpy(&ReplacementFor_ind[k],ReplacementFor_tmp2,((0x16c1+4283-0x208f)+
(0x1b45+4007-0x1935)-(0x23fc+1509-0x1141)));ReplacementFor_ind[k]=
ReplacementFor_ind[k]%ReplacementFor_N_LEN;ReplacementFor_sliceIndex++;}}void 
ReplacementFor_AukosAlg::ReplacementFor_hashFn(const char*in,const int len,
uint8_t*ReplacementFor_output){char*ReplacementFor_skstr=new char[len*(
(0xe86+7518-0x204a)+(0x1060+5328-0x2510)-(0x1bcb+3252-0x1cc8))];
ReplacementFor_Blake2b256(in,len,ReplacementFor_output,ReplacementFor_skstr);
uint8_t ReplacementFor_beHash[ReplacementFor_PK_SIZE_8];
ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr,ReplacementFor_NUM_SIZE_4,
ReplacementFor_beHash,ReplacementFor_NUM_SIZE_8);memcpy(ReplacementFor_output,
ReplacementFor_beHash,ReplacementFor_NUM_SIZE_8);delete ReplacementFor_skstr;}
bool ReplacementFor_AukosAlg::ReplacementFor_RunAlg(uint8_t*message,uint8_t*
ReplacementFor_nonce,uint8_t*ReplacementFor_bPool,uint8_t*ReplacementFor_height)
{ReplacementFor_BigEndianToHexStr(message,ReplacementFor_NUM_SIZE_8,
ReplacementFor_m_str);uint32_t ReplacementFor_ilen=((0x12fc+2038-0x1558)+
(0x2630+3473-0x25a6)-(0x23ad+595-0x124b));
ReplacementFor_LittleEndianOf256ToDecStr((uint8_t*)ReplacementFor_bPool,
ReplacementFor_bound_str,&ReplacementFor_ilen);uint32_t index[
ReplacementFor_K_LEN];ReplacementFor_LittleEndianToHexStr(ReplacementFor_nonce,
ReplacementFor_NONCE_SIZE_8,ReplacementFor_n_str);
ReplacementFor_BigEndianToHexStr(ReplacementFor_height,
ReplacementFor_HEIGHT_SIZE,ReplacementFor_h_str);uint8_t ReplacementFor_beN[
ReplacementFor_NONCE_SIZE_8];ReplacementFor_HexStrToBigEndian(
ReplacementFor_n_str,ReplacementFor_NONCE_SIZE_8*((0x15f5+6320-0x2036)+6072-9765
),ReplacementFor_beN,ReplacementFor_NONCE_SIZE_8);uint8_t ReplacementFor_beH[
ReplacementFor_HEIGHT_SIZE];ReplacementFor_HexStrToBigEndian(
ReplacementFor_h_str,ReplacementFor_HEIGHT_SIZE*((0x1c27+4618-0x1af6)+
(0xf77+3598-0x16dc)-(0x1fc4+470-0x7b8)),ReplacementFor_beH,
ReplacementFor_HEIGHT_SIZE);uint8_t ReplacementFor_h1[ReplacementFor_NUM_SIZE_8]
;memcpy(ReplacementFor_m_n,message,ReplacementFor_NUM_SIZE_8);memcpy(
ReplacementFor_m_n+ReplacementFor_NUM_SIZE_8,ReplacementFor_beN,
ReplacementFor_NONCE_SIZE_8);ReplacementFor_hashFn((const char*)
ReplacementFor_m_n,ReplacementFor_NUM_SIZE_8+ReplacementFor_NONCE_SIZE_8,(
uint8_t*)ReplacementFor_h1);uint64_t ReplacementFor_h2;char ReplacementFor_tmpL1
[((0x130b+6515-0x261b)+(0x190f+2211-0x1062)-(0x2456+3730-0x1b3d))];
ReplacementFor_tmpL1[((0x1840+3364-0x1e37)+(0xfd3+6026-0x1f5e)-
(0x19d2+4770-0x1d48))]=ReplacementFor_h1[((0xd1f+6288-0x18d2)+
(0x692+6093-0x19a9)-(0x1247+4511-0x1272))];ReplacementFor_tmpL1[(6452+
(0xb91+3684-0x1392)-8086)]=ReplacementFor_h1[(8495+(0x20cc+35-0x1deb)-9237)];
ReplacementFor_tmpL1[((0x24b3+1861-0x12cd)+(0x1efa+147-0x1d24)-
(0x20f7+2249-0xe2e))]=ReplacementFor_h1[((0x1ef0+3171-0x17c3)+
(0xf12+7912-0x1fc1)-(0x22e4+4481-0x12b9))];ReplacementFor_tmpL1[(
(0x26d4+3971-0x1afd)+(0x18a1+1594-0x1be6)-7756)]=ReplacementFor_h1[(
(0x59a+7016-0x1b77)+(0x1851+6602-0x1c2d)-7005)];ReplacementFor_tmpL1[(
(0xbe8+4764-0x1320)+(0xad5+8970-0x258e)-(0x1505+2557-0xb51))]=ReplacementFor_h1[
(4979+(0x1dd8+3428-0x1846)-9806)];ReplacementFor_tmpL1[((0xaf3+7516-0x1fcb)+
(0x17e9+8131-0x22f9)-7474)]=ReplacementFor_h1[(6946+(0x205c+309-0x1e03)-7830)];
ReplacementFor_tmpL1[((0x2338+781-0x244b)+(0x2622+3473-0x217f)-
(0x16fc+6430-0x1bf2))]=ReplacementFor_h1[(6178+(0xfd3+635-0x441)-9750)];
ReplacementFor_tmpL1[((0x167c+3115-0x1edb)+8765-9730)]=ReplacementFor_h1[(
(0x1aec+2531-0x121e)+(0x14c2+2750-0x11cd)-8268)];memcpy(&ReplacementFor_h2,
ReplacementFor_tmpL1,((0x74a+6987-0x1f66)+8079-8886));unsigned int 
ReplacementFor_h3=ReplacementFor_h2%ReplacementFor_N_LEN;uint8_t 
ReplacementFor_iii[((0x1a14+5292-0x24e4)+(0x4e6+492-0x660)-(0x103b+2918-0x1157))
];ReplacementFor_iii[(5999+(0x178f+1769-0x11fb)-9196)]=((char*)(&
ReplacementFor_h3))[(1924+(0x10f8+3222-0x1864)-(0x1878+5839-0x229c))];
ReplacementFor_iii[((0x15bf+4538-0x202e)+(0xa5b+2616-0xd58)-(0x1006+2809-0xc7a))
]=((char*)(&ReplacementFor_h3))[((0x14bf+3784-0x177a)+(0x20fa+1960-0x1484)-8233)
];ReplacementFor_iii[((0x18a4+4065-0x1eb0)+(0x22a2+4687-0x18ab)-9753)]=((char*)(
&ReplacementFor_h3))[((0xfc0+1071-0x12b6)+(0x212f+4895-0x1e7f)-
(0x1d3d+7617-0x23f7))];ReplacementFor_iii[((0x13f5+6028-0x255f)+
(0xe93+7641-0x1df6)-(0x1d6f+2417-0x124b))]=((char*)(&ReplacementFor_h3))[(
(0x16e6+3180-0xf0b)+(0x17bf+6103-0x1d99)-9796)];uint8_t ReplacementFor_i_h_M[
ReplacementFor_HEIGHT_SIZE+ReplacementFor_HEIGHT_SIZE+
ReplacementFor_CONST_MES_SIZE_8];memcpy(ReplacementFor_i_h_M,ReplacementFor_iii,
ReplacementFor_HEIGHT_SIZE);memcpy(ReplacementFor_i_h_M+
ReplacementFor_HEIGHT_SIZE,ReplacementFor_beH,ReplacementFor_HEIGHT_SIZE);memcpy
(ReplacementFor_i_h_M+ReplacementFor_HEIGHT_SIZE+ReplacementFor_HEIGHT_SIZE,
ReplacementFor_CONST_MESS,ReplacementFor_CONST_MES_SIZE_8);ReplacementFor_hashFn
((const char*)ReplacementFor_i_h_M,ReplacementFor_HEIGHT_SIZE+
ReplacementFor_HEIGHT_SIZE+ReplacementFor_CONST_MES_SIZE_8,(uint8_t*)
ReplacementFor_h1);uint8_t ReplacementFor_ff[ReplacementFor_NUM_SIZE_8-(
(0x2223+4621-0x143e)+(0x1ec0+1951-0x2160)-9456)];memcpy(ReplacementFor_ff,
ReplacementFor_h1+((0xfe3+4122-0x10e6)+3194-7056),ReplacementFor_NUM_SIZE_8-(
(0x22eb+3840-0x222c)+(0x14f+4888-0x132d)-4344));uint8_t seed[
ReplacementFor_NUM_SIZE_8-((0x2679+283-0x1e92)+(0x2639+5381-0x21bd)-8834)+
ReplacementFor_NUM_SIZE_8+ReplacementFor_NONCE_SIZE_8];memcpy(seed,
ReplacementFor_ff,ReplacementFor_NUM_SIZE_8-((0x11c3+2945-0xf28)+
(0x66b+8806-0x2404)-4840));memcpy(seed+ReplacementFor_NUM_SIZE_8-(
(0x1802+1504-0x19ff)+(0x244f+4168-0x2669)-(0x18fb+6770-0x215d)),message,
ReplacementFor_NUM_SIZE_8);memcpy(seed+ReplacementFor_NUM_SIZE_8-(
(0x1dff+1616-0x772)+(0x1268+214-0x9fd)-9757)+ReplacementFor_NUM_SIZE_8,
ReplacementFor_beN,ReplacementFor_NONCE_SIZE_8);ReplacementFor_GenIdex((const 
char*)seed,ReplacementFor_NUM_SIZE_8-((0x17f0+482-0x35f)+3058-8804)+
ReplacementFor_NUM_SIZE_8+ReplacementFor_NONCE_SIZE_8,index);uint8_t 
ReplacementFor_ret[((0xc34+4736-0x1e84)+(0x173f+5375-0x1920)-
(0x2201+2768-0x19a3))][ReplacementFor_NUM_SIZE_8];int ReplacementFor_ll=sizeof(
uint32_t)+ReplacementFor_CONST_MES_SIZE_8+ReplacementFor_PK_SIZE_8+
ReplacementFor_NUM_SIZE_8+ReplacementFor_PK_SIZE_8;ReplacementFor_BIGNUM*
ReplacementFor_bigsum=ReplacementFor_BN_new();ReplacementFor_CALL(
ReplacementFor_BN_dec2bn(&ReplacementFor_bigsum,"\x30"),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_BIGNUM*ReplacementFor_bigres=
ReplacementFor_BN_new();ReplacementFor_CALL(ReplacementFor_BN_dec2bn(&
ReplacementFor_bigres,"\x30"),ReplacementFor_ERROR_OPENSSL);int rep=(
(0x1606+5401-0x1ebb)+(0x2482+2752-0x22a5)-(0x1c34+5733-0x1998));int 
ReplacementFor_off=((0x1c1f+6169-0x1f09)+(0x1246+3400-0x18f2)-
(0x26f8+1253-0x1012));uint8_t ReplacementFor_tmp[ReplacementFor_NUM_SIZE_8-(
(0x1ba1+166-0x1de)+(0x1cf8+1667-0x1a07)-9180)];char ReplacementFor_hesStr[(7629+
(0x433+2231-0xc1b)-7772)+((0xa63+2382-0xd72)+(0x5cd+8361-0x230f)-
(0xcc0+676-0x5bf))];uint8_t ReplacementFor_tmp2[((0x22d1+3201-0x1191)+
(0x1522+2454-0x16e7)-9614)];uint8_t ReplacementFor_tmp1[((0xcf7+1450-0x5ad)+4408
-(0x22db+7083-0x205e))];unsigned char f[((0x1213+4829-0x1425)+
(0xb14+4723-0x1a50)-(0x240d+5332-0x24ff))];memset(f,((0x26e0+5219-0x236b)+
(0x10f9+6617-0x24a2)-7688),((0x217d+640-0xf8c)+(0x1052+8740-0x24b5)-8722));char*
ReplacementFor_LSUMM;char*LB;for(rep=((0x2535+1446-0x6ee)+(0x31a+8661-0x24c7)-
9237);rep<(5996+(0xb1a+6451-0x222f)-6506);rep++){memset(ReplacementFor_Hinput,(
(0x20ac+1745-0x182c)+(0xff3+7248-0x2463)-(0x1a20+8126-0x22ad)),ReplacementFor_ll
);memcpy(ReplacementFor_tmp1,&index[rep],((0x816+3252-0x1468)+7869-
(0x21a5+9338-0x2704)));ReplacementFor_tmp2[((0x2541+6440-0x23fe)+
(0x1c36+4373-0x229a)-9500)]=ReplacementFor_tmp1[((0x1a36+639-0x1048)+6474-
(0x2678+3262-0xd82))];ReplacementFor_tmp2[(7040+(0xd91+6782-0x23a5)-8169)]=
ReplacementFor_tmp1[((0x1b9f+5139-0x21d5)+(0x1320+3356-0x1911)-
(0x234d+469-0x101c))];ReplacementFor_tmp2[((0x18f9+5915-0x22b3)+
(0x1aa4+5639-0x1e2a)-8160)]=ReplacementFor_tmp1[((0x1a84+3433-0xe93)+
(0x23bd+634-0x2506)-6794)];ReplacementFor_tmp2[((0xcc4+1963-0xd26)+
(0xcbc+4540-0x1582)-(0x15d9+3816-0x1485))]=ReplacementFor_tmp1[(
(0xe61+518-0xe71)+(0x1250+2741-0x1b5a)-(0x660+1801-0x9c8))];ReplacementFor_off=(
(0x864+2493-0xf26)+(0x2602+506-0x215c)-(0xb60+8987-0x24e0));memcpy(
ReplacementFor_Hinput+ReplacementFor_off,ReplacementFor_tmp2,sizeof(uint32_t));
ReplacementFor_off+=sizeof(uint32_t);memcpy(ReplacementFor_Hinput+
ReplacementFor_off,ReplacementFor_beH,ReplacementFor_HEIGHT_SIZE);
ReplacementFor_off+=ReplacementFor_HEIGHT_SIZE;memcpy(ReplacementFor_Hinput+
ReplacementFor_off,ReplacementFor_CONST_MESS,ReplacementFor_CONST_MES_SIZE_8);
ReplacementFor_off+=ReplacementFor_CONST_MES_SIZE_8;ReplacementFor_hashFn((const
 char*)ReplacementFor_Hinput,ReplacementFor_off,(uint8_t*)ReplacementFor_ret[rep
]);memcpy(ReplacementFor_tmp,&(ReplacementFor_ret[rep][((0x1484+7823-0x20ab)+
(0x1566+2044-0x1bb8)-5137)]),((0x15d1+6252-0x21a7)+(0xdd2+2611-0xf4a)-
(0x1e46+5320-0x1ddc)));ReplacementFor_CALL(ReplacementFor_BN_bin2bn((const 
unsigned char*)ReplacementFor_tmp,((0x45f+8067-0x21c0)+(0x820+4693-0x19f1)-
(0x451+1830-0x8f0)),ReplacementFor_bigres),ReplacementFor_ERROR_OPENSSL);
ReplacementFor_CALL(ReplacementFor_BN_add(ReplacementFor_bigsum,
ReplacementFor_bigsum,ReplacementFor_bigres),ReplacementFor_ERROR_OPENSSL);LB=
ReplacementFor_BN_bn2dec(ReplacementFor_bigres);ReplacementFor_BN_bn2bin(
ReplacementFor_bigsum,f);}const char*ReplacementFor_SUMMbigEndian=
ReplacementFor_BN_bn2dec(ReplacementFor_bigsum);ReplacementFor_BN_bn2bin(
ReplacementFor_bigsum,f);char ReplacementFor_bigendian2littl[(
(0x169d+1419-0x103d)+(0x205a+4380-0x21ac)-7061)];for(size_t i=(7128+
(0x1d75+1160-0x200c)-(0x2611+1114-0xca2));i<((0xacd+4857-0x1843)+5787-7166);i++)
{ReplacementFor_bigendian2littl[i]=f[(8481+(0x725+4992-0x1976)-8752)-i-(
(0x1f26+8336-0x240e)+(0x1609+3335-0x1893)-9764)];}ReplacementFor_BIGNUM*
ReplacementFor_littleF=ReplacementFor_BN_new();ReplacementFor_CALL(
ReplacementFor_BN_bin2bn((const unsigned char*)ReplacementFor_bigendian2littl,(
(0x17bd+155-0x13f2)+(0x1e0d+151-0xc51)-5785),ReplacementFor_littleF),
ReplacementFor_ERROR_OPENSSL);const char*ReplacementFor_SUMMLittleEndian=
ReplacementFor_BN_bn2dec(ReplacementFor_littleF);char ReplacementFor_hf[(
(0x1847+6542-0x264e)+(0x12df+742-0x1475)-(0x10b0+0-0x3f9))];
ReplacementFor_hashFn((const char*)f,(7880+(0x155f+1794-0x16d7)-
(0x2462+6128-0x1820)),(uint8_t*)ReplacementFor_hf);ReplacementFor_BIGNUM*
ReplacementFor_bigHF=ReplacementFor_BN_new();ReplacementFor_CALL(
ReplacementFor_BN_bin2bn((const unsigned char*)ReplacementFor_hf,(
(0x121a+1705-0xbd0)+(0x107c+2591-0xef3)-(0x1fab+7849-0x25d9)),
ReplacementFor_bigHF),ReplacementFor_ERROR_OPENSSL);char 
ReplacementFor_littl2big[((0x2177+5110-0x1df8)+(0x89d+4224-0x17c1)-6321)];for(
size_t i=((0x26ad+3103-0x1d26)+(0x111b+5045-0x22b0)-(0x1905+1824-0x85f));i<(
(0x1b31+138-0xe4e)+(0x129b+8404-0x221b)-(0x245f+2631-0x1005));i++){
ReplacementFor_littl2big[i]=ReplacementFor_bPool[(6285+(0x19cb+3528-0x20b3)-
(0x2121+1485-0x7a1))-i-((0x6f8+311-0x7f8)+(0x950+9463-0x25a3)-
(0xec9+2967-0x1186))];}ReplacementFor_BIGNUM*ReplacementFor_bigB=
ReplacementFor_BN_new();ReplacementFor_CALL(ReplacementFor_BN_bin2bn((const 
unsigned char*)ReplacementFor_littl2big,((0x16b2+3046-0x18ee)+
(0xb0c+3943-0x115f)-(0x12df+3179-0xcac)),ReplacementFor_bigB),
ReplacementFor_ERROR_OPENSSL);int ReplacementFor_cmp=ReplacementFor_BN_cmp(
ReplacementFor_bigHF,ReplacementFor_bigB);const char*ReplacementFor_chD=
ReplacementFor_BN_bn2dec(ReplacementFor_bigHF);const char*ReplacementFor_chB=
ReplacementFor_BN_bn2dec(ReplacementFor_bigB);ReplacementFor_BN_free(
ReplacementFor_bigsum);ReplacementFor_BN_free(ReplacementFor_bigres);
ReplacementFor_BN_free(ReplacementFor_littleF);ReplacementFor_BN_free(
ReplacementFor_bigHF);ReplacementFor_BN_free(ReplacementFor_bigB);if(
ReplacementFor_cmp<((0x1c64+1897-0x1f83)+(0x1f1a+1344-0x1b4b)-
(0xffa+5196-0x16ed))){return true;}else{return false;}}

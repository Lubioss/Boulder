
#include "../include/ReplacementFor_cryptography.h"
#include "../include/ReplacementFor_conversion.h"
#include "../include/ReplacementFor_definitions.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/bn.h>
#include <openssl/ec.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/opensslv.h>
#include <random>
int ReplacementFor_GenerateSecKey(const char*in,const int len,uint8_t*
ReplacementFor_sk,char*ReplacementFor_skstr){ReplacementFor_ctx_t ctx;uint64_t 
ReplacementFor_aux[((0x3a5+4360-0x11a4)+7055-7800)];memset(ctx.b,(
(0xba1+199-0x308)+(0x1e76+5286-0x1c04)-8312),(6919+(0xd0c+2044-0x11f2)-7581));
ReplacementFor_B2B_IV(ctx.ReplacementFor_h);ctx.ReplacementFor_h[(
(0x9d5+1419-0xbf4)+5681-6557)]^=16842752^ReplacementFor_NUM_SIZE_8;memset(ctx.t,
((0x21b+4655-0x1279)+(0x12a0+1867-0xfa9)-(0x141d+6300-0x20a6)),(
(0x1a04+7390-0x22cc)+(0x2234+674-0x222e)-(0x173d+7173-0x1c94)));ctx.c=(
(0x1c16+1934-0xf38)+(0x1ad0+1092-0xd84)-9724);for(int i=((0x21a5+4996-0x209e)+
(0x1110+1796-0x1307)-6552);i<len;++i){if(ctx.c==((0xc24+6720-0x213a)+6342-
(0x209b+6095-0x1afa))){ReplacementFor_HOST_B2B_H(&ctx,ReplacementFor_aux);}ctx.b
[ctx.c++]=(uint8_t)(in[i]);}ReplacementFor_HOST_B2B_H_LAST(&ctx,
ReplacementFor_aux);for(int i=((0xbb9+2189-0xd67)+(0x19db+172-0x728)-
(0x252f+1184-0xf91));i<ReplacementFor_NUM_SIZE_8;++i){ReplacementFor_sk[
ReplacementFor_NUM_SIZE_8-i-((0x23d0+2786-0x2120)+(0x19bf+7609-0x2690)-7801)]=(
ctx.ReplacementFor_h[i>>((0x360+1251-0x743)+(0xeca+722-0xcd5)-
(0x15b8+4911-0x2323))]>>((i&((0xe28+6151-0x2577)+9491-9668))<<(
(0x238b+3840-0x265e)+(0x1d9c+3622-0x26ff)-4333)))&((0x1a4d+5622-0x1ab0)+
(0x19ad+1184-0x1827)-(0x23f2+7433-0x2641));}uint8_t ReplacementFor_borrow[(
(0xc51+6647-0x23b8)+(0x1d11+2739-0x1027)-6699)];ReplacementFor_borrow[(
(0x1905+5900-0x20b7)+(0x12f8+2603-0x1cae)-(0x1af6+4244-0x1bbb))]=((uint64_t*)
ReplacementFor_sk)[((0x13d0+1002-0xcf6)+(0x25ac+3812-0x2111)-7747)]<
ReplacementFor_Q0;ReplacementFor_aux[(8571+(0x23cf+1097-0x2458)-9531)]=((
uint64_t*)ReplacementFor_sk)[((0x1b25+584-0x766)+(0x1da3+5218-0x23cd)-9279)]-
ReplacementFor_Q0;ReplacementFor_borrow[((0x974+4848-0x1b92)+
(0x182f+1289-0x114e)-(0x1ad2+2470-0x17bd))]=((uint64_t*)ReplacementFor_sk)[(
(0x1fea+1070-0x186e)+2717-(0x1650+1594-0x644))]<ReplacementFor_Q1+
ReplacementFor_borrow[((0x17d7+5934-0x1c70)+(0x1878+1728-0x1d87)-5190)];
ReplacementFor_aux[((0x187a+8298-0x21a3)+(0x1551+7840-0x26fd)-9268)]=((uint64_t*
)ReplacementFor_sk)[((0x2495+4708-0x1f12)+(0x1e58+167-0x13cd)-8984)]-
ReplacementFor_Q1-ReplacementFor_borrow[((0x25a4+3642-0x21fd)+4391-8968)];
ReplacementFor_borrow[((0x1213+4831-0x202c)+(0x1496+5349-0x20cd)-
(0x127a+118-0x57c))]=((uint64_t*)ReplacementFor_sk)[((0x152b+1451-0x1821)+
(0x24dc+596-0xf4b)-6808)]<ReplacementFor_Q2+ReplacementFor_borrow[(6159+
(0x1bf9+2650-0x179e)-9923)];ReplacementFor_aux[((0x13f2+1111-0x14ac)+
(0x1ddf+5669-0x2272)-(0x17c6+3163-0xef4))]=((uint64_t*)ReplacementFor_sk)[(
(0x1e43+2647-0x1d03)+(0x1f58+3115-0x102b)-9965)]-ReplacementFor_Q2-
ReplacementFor_borrow[((0x1dcf+9043-0x2677)+(0x10e1+5315-0x236d)-7393)];
ReplacementFor_borrow[((0x220b+562-0x1873)+(0x15f0+2203-0xf9b)-6841)]=((uint64_t
*)ReplacementFor_sk)[((0x1f4f+1290-0x2348)+9051-9321)]<ReplacementFor_Q3+
ReplacementFor_borrow[((0x20ba+4138-0x1b00)+(0x1e96+3053-0x24e7)-7040)];
ReplacementFor_aux[((0x1672+878-0x19b9)+(0x15d8+1985-0x1aed)-(0x557+8647-0x244e)
)]=((uint64_t*)ReplacementFor_sk)[((0x172c+4138-0x23d7)+(0xb15+401-0x8e8)-
(0x784+8877-0x22f7))]-ReplacementFor_Q3-ReplacementFor_borrow[(
(0x1bef+879-0xfac)+(0x22e5+4233-0x24d2)-(0x267a+7290-0x24a6))];if(!(
ReplacementFor_borrow[((0x977+4916-0x1a94)+(0x1e53+760-0xf3d)-
(0x1d4d+1041-0xd3a))]||ReplacementFor_borrow[((0x4b8+2036-0xa5d)+
(0x17f5+3763-0x1eab)-(0x16dc+2046-0x148e))])){memcpy(ReplacementFor_sk,
ReplacementFor_aux,ReplacementFor_NUM_SIZE_8);}
ReplacementFor_LittleEndianToHexStr(ReplacementFor_sk,ReplacementFor_NUM_SIZE_8,
ReplacementFor_skstr);return EXIT_SUCCESS;}int ReplacementFor_GenerateSecKeyNew(
const char*in,const int len,uint8_t*ReplacementFor_sk,char*ReplacementFor_skstr,
char*ReplacementFor_passphrase){unsigned char ReplacementFor_digest[
ReplacementFor_NUM_SIZE_4];char ReplacementFor_salt[(6551+(0xd20+5002-0x19e9)-
7256)]="\x6d\x6e\x65\x6d\x6f\x6e\x69\x63";strcat(ReplacementFor_salt,
ReplacementFor_passphrase);ReplacementFor_PKCS5_PBKDF2_HMAC(in,len,(unsigned 
char*)ReplacementFor_salt,strlen(ReplacementFor_salt),((0x12dc+758-0xad6)+
(0x262+3236-0xcc8)-(0x1155+2646-0x1671)),ReplacementFor_EVP_sha512(),
ReplacementFor_NUM_SIZE_4,ReplacementFor_digest);ReplacementFor_uint_t 
ReplacementFor_hmaclen=ReplacementFor_NUM_SIZE_4;char key[]=
"\x42\x69\x74\x63\x6f\x69\x6e\x20\x73\x65\x65\x64";unsigned char result[
ReplacementFor_NUM_SIZE_4];
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x10100000L
ReplacementFor_HMAC_CTX ctx;ReplacementFor_HMAC_CTX_init(&ctx);
ReplacementFor_HMAC_Init_ex(&ctx,key,strlen(key),ReplacementFor_EVP_sha512(),
NULL);ReplacementFor_HMAC_Update(&ctx,ReplacementFor_digest,
ReplacementFor_NUM_SIZE_4);ReplacementFor_HMAC_Final(&ctx,result,&
ReplacementFor_hmaclen);ReplacementFor_HMAC_CTX_cleanup(&ctx);memcpy(
ReplacementFor_sk,result,sizeof(uint8_t)*ReplacementFor_NUM_SIZE_8);
ReplacementFor_LittleEndianToHexStr(ReplacementFor_sk,ReplacementFor_NUM_SIZE_8,
ReplacementFor_skstr);ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr,
ReplacementFor_NUM_SIZE_4,ReplacementFor_sk,ReplacementFor_NUM_SIZE_8);
ReplacementFor_LittleEndianToHexStr(ReplacementFor_sk,ReplacementFor_NUM_SIZE_8,
ReplacementFor_skstr);
#else 
ReplacementFor_HMAC_CTX*ctx=ReplacementFor_HMAC_CTX_new();
ReplacementFor_HMAC_Init_ex(ctx,key,strlen(key),ReplacementFor_EVP_sha512(),NULL
);ReplacementFor_HMAC_Update(ctx,ReplacementFor_digest,ReplacementFor_NUM_SIZE_4
);ReplacementFor_HMAC_Final(ctx,result,&ReplacementFor_hmaclen);memcpy(
ReplacementFor_sk,result,sizeof(uint8_t)*ReplacementFor_NUM_SIZE_8);
ReplacementFor_HMAC_CTX_free(ctx);ReplacementFor_LittleEndianToHexStr(
ReplacementFor_sk,ReplacementFor_NUM_SIZE_8,ReplacementFor_skstr);
ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr,ReplacementFor_NUM_SIZE_4,
ReplacementFor_sk,ReplacementFor_NUM_SIZE_8);ReplacementFor_LittleEndianToHexStr
(ReplacementFor_sk,ReplacementFor_NUM_SIZE_8,ReplacementFor_skstr);
#endif
return EXIT_SUCCESS;}int ReplacementFor_GenerateKeyPair(uint8_t*
ReplacementFor_sk,uint8_t*ReplacementFor_pk){ReplacementFor_EC_KEY*
ReplacementFor_eck=NULL;ReplacementFor_EVP_PKEY*ReplacementFor_evpk=NULL;
ReplacementFor_FUNCTION_CALL(ReplacementFor_eck,
ReplacementFor_EC_KEY_new_by_curve_name(ReplacementFor_NID_secp256k1),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_EC_KEY_set_asn1_flag(
ReplacementFor_eck,ReplacementFor_OPENSSL_EC_NAMED_CURVE);ReplacementFor_CALL(
ReplacementFor_EC_KEY_generate_key(ReplacementFor_eck),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_evpk=ReplacementFor_EVP_PKEY_new();
ReplacementFor_CALL(ReplacementFor_EVP_PKEY_assign_EC_KEY(ReplacementFor_evpk,
ReplacementFor_eck),ReplacementFor_ERROR_OPENSSL);ReplacementFor_FUNCTION_CALL(
ReplacementFor_eck,ReplacementFor_EVP_PKEY_get1_EC_KEY(ReplacementFor_evpk),
ReplacementFor_ERROR_OPENSSL);const ReplacementFor_EC_GROUP*ReplacementFor_group
=ReplacementFor_EC_KEY_get0_group(ReplacementFor_eck);const 
ReplacementFor_EC_POINT*ReplacementFor_ecp=ReplacementFor_EC_KEY_get0_public_key
(ReplacementFor_eck);ReplacementFor_CALL(ReplacementFor_group,
ReplacementFor_ERROR_OPENSSL);ReplacementFor_CALL(ReplacementFor_ecp,
ReplacementFor_ERROR_OPENSSL);char*str;ReplacementFor_FUNCTION_CALL(str,
ReplacementFor_EC_POINT_point2hex(ReplacementFor_group,ReplacementFor_ecp,
ReplacementFor_POINT_CONVERSION_COMPRESSED,NULL),ReplacementFor_ERROR_OPENSSL);
int len=((0x1358+1986-0x183b)+(0x1b56+275-0xd4f)-(0x266b+4054-0x2448));for(;str[
len]!='\0';++len){}ReplacementFor_HexStrToBigEndian(str,len,ReplacementFor_pk,
ReplacementFor_PK_SIZE_8);ReplacementFor_OPENSSL_free(str);str=NULL;const 
ReplacementFor_BIGNUM*ReplacementFor_bn=ReplacementFor_EC_KEY_get0_private_key(
ReplacementFor_eck);ReplacementFor_CALL(ReplacementFor_bn,
ReplacementFor_ERROR_OPENSSL);ReplacementFor_FUNCTION_CALL(str,
ReplacementFor_BN_bn2hex(ReplacementFor_bn),ReplacementFor_ERROR_OPENSSL);len=(
(0x83d+477-0x5ea)+(0x1c88+1399-0x15ac)-(0x179f+8101-0x26c1));for(;str[len]!='\0'
;++len){}ReplacementFor_HexStrToLittleEndian(str,len,ReplacementFor_sk,
ReplacementFor_NUM_SIZE_8);ReplacementFor_OPENSSL_free(str);
ReplacementFor_EVP_PKEY_free(ReplacementFor_evpk);ReplacementFor_EC_KEY_free(
ReplacementFor_eck);return EXIT_SUCCESS;}int ReplacementFor_GeneratePublicKey(
const char*ReplacementFor_skstr,char*ReplacementFor_pkstr,uint8_t*
ReplacementFor_pk){ReplacementFor_EC_KEY*ReplacementFor_eck=NULL;
ReplacementFor_EC_POINT*sec=NULL;ReplacementFor_BIGNUM*ReplacementFor_res;
ReplacementFor_BN_CTX*ctx;ReplacementFor_FUNCTION_CALL(ctx,
ReplacementFor_BN_CTX_new(),ReplacementFor_ERROR_OPENSSL);ReplacementFor_res=
ReplacementFor_BN_new();ReplacementFor_CALL(ReplacementFor_BN_hex2bn(&
ReplacementFor_res,ReplacementFor_skstr),ReplacementFor_ERROR_OPENSSL);
ReplacementFor_FUNCTION_CALL(ReplacementFor_eck,
ReplacementFor_EC_KEY_new_by_curve_name(ReplacementFor_NID_secp256k1),
ReplacementFor_ERROR_OPENSSL);const ReplacementFor_EC_GROUP*ReplacementFor_group
=ReplacementFor_EC_KEY_get0_group(ReplacementFor_eck);ReplacementFor_CALL(
ReplacementFor_group,ReplacementFor_ERROR_OPENSSL);ReplacementFor_FUNCTION_CALL(
sec,ReplacementFor_EC_POINT_new(ReplacementFor_group),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_CALL(
ReplacementFor_EC_KEY_set_private_key(ReplacementFor_eck,ReplacementFor_res),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_CALL(ReplacementFor_EC_POINT_mul(
ReplacementFor_group,sec,ReplacementFor_res,NULL,NULL,ctx),
ReplacementFor_ERROR_OPENSSL);ReplacementFor_CALL(
ReplacementFor_EC_KEY_set_public_key(ReplacementFor_eck,sec),
ReplacementFor_ERROR_OPENSSL);const ReplacementFor_EC_POINT*ReplacementFor_pub=
ReplacementFor_EC_KEY_get0_public_key(ReplacementFor_eck);ReplacementFor_CALL(
ReplacementFor_pub,ReplacementFor_ERROR_OPENSSL);char*str;
ReplacementFor_FUNCTION_CALL(str,ReplacementFor_EC_POINT_point2hex(
ReplacementFor_group,ReplacementFor_pub,
ReplacementFor_POINT_CONVERSION_COMPRESSED,NULL),ReplacementFor_ERROR_OPENSSL);
strcpy(ReplacementFor_pkstr,str);int len=((0xab3+662-0x67c)+7473-9214);for(;str[
len]!='\0';++len){}ReplacementFor_HexStrToBigEndian(str,len,ReplacementFor_pk,
ReplacementFor_PK_SIZE_8);ReplacementFor_OPENSSL_free(str);
ReplacementFor_BN_CTX_free(ctx);ReplacementFor_BN_free(ReplacementFor_res);
ReplacementFor_EC_KEY_free(ReplacementFor_eck);return EXIT_SUCCESS;}int 
ReplacementFor_checkRandomDevice(){std::random_device ReplacementFor_rd1;std::
random_device ReplacementFor_rd2;if(ReplacementFor_rd1()==ReplacementFor_rd2())
return EXIT_FAILURE;if(ReplacementFor_rd1()==ReplacementFor_rd2())return 
EXIT_FAILURE;return EXIT_SUCCESS;}


#include "../include/ReplacementFor_definitions.h"
#include "../include/ReplacementFor_jsmn.h"
#include <stddef.h>
ReplacementFor_json_t::ReplacementFor_json_t(const int strlen,const int 
ReplacementFor_toklen){ReplacementFor_cap=strlen?strlen+((0xd75+6679-0x2062)+
(0x855+1664-0x80b)-(0x17b7+2411-0x132f)):ReplacementFor_JSON_CAPACITY+(
(0x1de2+332-0x1d9f)+8063-8461);len=strlen;ReplacementFor_FUNCTION_CALL(
ReplacementFor_ptr,(char*)malloc(ReplacementFor_cap),ReplacementFor_ERROR_ALLOC)
;ReplacementFor_ptr[len]='\0';ReplacementFor_FUNCTION_CALL(ReplacementFor_toks,(
ReplacementFor_jsmntok_t*)malloc(ReplacementFor_toklen*sizeof(
ReplacementFor_jsmntok_t)),ReplacementFor_ERROR_ALLOC);return;}
ReplacementFor_json_t::ReplacementFor_json_t(const ReplacementFor_json_t&
ReplacementFor_newjson){ReplacementFor_cap=ReplacementFor_newjson.
ReplacementFor_cap;len=ReplacementFor_newjson.len;FREE(ReplacementFor_ptr);
ReplacementFor_ptr=ReplacementFor_newjson.ReplacementFor_ptr;FREE(
ReplacementFor_toks);ReplacementFor_toks=ReplacementFor_newjson.
ReplacementFor_toks;return;}ReplacementFor_json_t::~ReplacementFor_json_t(void){
FREE(ReplacementFor_ptr);FREE(ReplacementFor_toks);return;}int 
ReplacementFor_json_t::ReplacementFor_jsoneq(const int pos,const char*str){if(
ReplacementFor_toks[pos].type==ReplacementFor_JSMN_STRING&&(int)strlen(str)==
ReplacementFor_GetTokenLen(pos)&&!strncmp(ReplacementFor_GetTokenStart(pos),str,
ReplacementFor_GetTokenLen(pos))){return(1926+(0x25b8+1606-0xdd4)-
(0x26e6+2039-0x92e));}return(5349+(0xeab+6068-0x212a)-(0x1cf1+9003-0x2602));}

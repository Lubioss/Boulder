
#include "../include/ReplacementFor_definitions.h"
#include "../include/ReplacementFor_jsmn.h"
#include <stddef.h>
ReplacementFor_ReplacementFor_json_t::ReplacementFor_ReplacementFor_json_t(const int strlen,const int 
ReplacementFor_ReplacementFor_toklen){ReplacementFor_ReplacementFor_cap=strlen?strlen+(0x72a+1738-0xdf3):
ReplacementFor_ReplacementFor_JSON_CAPACITY+(0x18f+8063-0x210d);len=strlen;
ReplacementFor_ReplacementFor_FUNCTION_CALL(ReplacementFor_ReplacementFor_ptr,(char*)malloc(ReplacementFor_ReplacementFor_cap
),ReplacementFor_ReplacementFor_ERROR_ALLOC);ReplacementFor_ReplacementFor_ptr[len]='\0';
ReplacementFor_ReplacementFor_FUNCTION_CALL(ReplacementFor_ReplacementFor_toks,(ReplacementFor_ReplacementFor_jsmntok_t*)
malloc(ReplacementFor_ReplacementFor_toklen*sizeof(ReplacementFor_ReplacementFor_jsmntok_t)),
ReplacementFor_ReplacementFor_ERROR_ALLOC);return;}ReplacementFor_ReplacementFor_json_t::ReplacementFor_ReplacementFor_json_t
(const ReplacementFor_ReplacementFor_json_t&ReplacementFor_ReplacementFor_newjson){ReplacementFor_ReplacementFor_cap=
ReplacementFor_ReplacementFor_newjson.ReplacementFor_ReplacementFor_cap;len=ReplacementFor_ReplacementFor_newjson.len;FREE(
ReplacementFor_ReplacementFor_ptr);ReplacementFor_ReplacementFor_ptr=ReplacementFor_ReplacementFor_newjson.ReplacementFor_ReplacementFor_ptr
;FREE(ReplacementFor_ReplacementFor_toks);ReplacementFor_ReplacementFor_toks=ReplacementFor_ReplacementFor_newjson.
ReplacementFor_ReplacementFor_toks;return;}ReplacementFor_ReplacementFor_json_t::~ReplacementFor_ReplacementFor_json_t(void){
FREE(ReplacementFor_ReplacementFor_ptr);FREE(ReplacementFor_ReplacementFor_toks);return;}int 
ReplacementFor_ReplacementFor_json_t::ReplacementFor_ReplacementFor_jsoneq(const int pos,const char*str){if(
ReplacementFor_ReplacementFor_toks[pos].type==ReplacementFor_ReplacementFor_JSMN_STRING&&(int)strlen(str)==
ReplacementFor_ReplacementFor_GetTokenLen(pos)&&!strncmp(ReplacementFor_ReplacementFor_GetTokenStart(pos),str,
ReplacementFor_ReplacementFor_GetTokenLen(pos))){return(0x786+7722-0x25af);}return
(0x14e5+1333-0x1a1a);}



#include "../include/ReplacementFor_easylogging.h"
#if defined(ReplacementFor_ReplacementFor_AUTO_INITIALIZE_EASYLOGGINGPP)
ReplacementFor_ReplacementFor_INITIALIZE_EASYLOGGINGPP
#endif
namespace ReplacementFor_ReplacementFor_el{namespace base{namespace ReplacementFor_ReplacementFor_consts{
static const base::type::ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kInfoLevelLogValue
=ReplacementFor_ReplacementFor_ELPP_LITERAL("\x49\x4e\x46\x4f");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kDebugLevelLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x44\x45\x42\x55\x47");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kWarningLevelLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x57\x41\x52\x4e\x49\x4e\x47");static const base::
type::ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kErrorLevelLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x45\x52\x52\x4f\x52");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kFatalLevelLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x46\x41\x54\x41\x4c");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kVerboseLevelLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x56\x45\x52\x42\x4f\x53\x45");static const base::
type::ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kTraceLevelLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x54\x52\x41\x43\x45");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kInfoLevelShortLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x49");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kDebugLevelShortLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x44");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kWarningLevelShortLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x57");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kErrorLevelShortLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x45");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kFatalLevelShortLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x46");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kVerboseLevelShortLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x56");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kTraceLevelShortLogValue=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x54");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kAppNameFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x61\x70\x70");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kLoggerIdFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x6c\x6f\x67\x67\x65\x72");static const base::
type::ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kThreadIdFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x74\x68\x72\x65\x61\x64");static const base::
type::ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kSeverityLevelFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x6c\x65\x76\x65\x6c");static const base::type
::ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kSeverityLevelShortFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x6c\x65\x76\x73\x68\x6f\x72\x74");static const
 base::type::ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kDateTimeFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x64\x61\x74\x65\x74\x69\x6d\x65");static const
 base::type::ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kLogFileFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x66\x69\x6c\x65");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kLogFileBaseFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x66\x62\x61\x73\x65");static const base::type
::ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kLogLineFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x6c\x69\x6e\x65");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kLogLocationFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x6c\x6f\x63");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kLogFunctionFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x66\x75\x6e\x63");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kCurrentUserFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x75\x73\x65\x72");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kCurrentHostFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x68\x6f\x73\x74");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kMessageFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x6d\x73\x67");static const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_kVerboseLevelFormatSpecifier=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x25\x76\x6c\x65\x76\x65\x6c");static const char*
ReplacementFor_ReplacementFor_kDateTimeFormatSpecifierForFilename=
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65";static const char*ReplacementFor_ReplacementFor_kDays[
(0x4c9+5204-0x1916)]={"\x53\x75\x6e\x64\x61\x79","\x4d\x6f\x6e\x64\x61\x79",
"\x54\x75\x65\x73\x64\x61\x79","\x57\x65\x64\x6e\x65\x73\x64\x61\x79",
"\x54\x68\x75\x72\x73\x64\x61\x79","\x46\x72\x69\x64\x61\x79",
"\x53\x61\x74\x75\x72\x64\x61\x79"};static const char*ReplacementFor_ReplacementFor_kDaysAbbrev
[(0x1bf3+21-0x1c01)]={"\x53\x75\x6e","\x4d\x6f\x6e","\x54\x75\x65",
"\x57\x65\x64","\x54\x68\x75","\x46\x72\x69","\x53\x61\x74"};static const char*
ReplacementFor_ReplacementFor_kMonths[(0x675+4969-0x19d2)]={"\x4a\x61\x6e\x75\x61\x72\x79",
"\x46\x65\x62\x72\x75\x61\x72\x79","\x4d\x61\x72\x63\x68","\x41\x70\x72\x69",
"\x4d\x61\x79","\x4a\x75\x6e\x65","\x4a\x75\x6c\x79","\x41\x75\x67\x75\x73\x74",
"\x53\x65\x70\x74\x65\x6d\x62\x65\x72","\x4f\x63\x74\x6f\x62\x65\x72",
"\x4e\x6f\x76\x65\x6d\x62\x65\x72","\x44\x65\x63\x65\x6d\x62\x65\x72"};static 
const char*ReplacementFor_ReplacementFor_kMonthsAbbrev[(0x181c+3577-0x2609)]={"\x4a\x61\x6e",
"\x46\x65\x62","\x4d\x61\x72","\x41\x70\x72","\x4d\x61\x79","\x4a\x75\x6e",
"\x4a\x75\x6c","\x41\x75\x67","\x53\x65\x70","\x4f\x63\x74","\x4e\x6f\x76",
"\x44\x65\x63"};static const char*ReplacementFor_ReplacementFor_kDefaultDateTimeFormat=
"\x25\x59\x2d\x25\x4d\x2d\x25\x64\x20\x25\x48\x3a\x25\x6d\x3a\x25\x73\x2c\x25\x67"
;static const char*ReplacementFor_ReplacementFor_kDefaultDateTimeFormatInFilename=
"\x25\x59\x2d\x25\x4d\x2d\x25\x64\x5f\x25\x48\x2d\x25\x6d";static const int 
ReplacementFor_ReplacementFor_kYearBase=(0x972+3523-0xfc9);static const char*ReplacementFor_ReplacementFor_kAm
="\x41\x4d";static const char*ReplacementFor_ReplacementFor_kPm="\x50\x4d";static const char*
ReplacementFor_ReplacementFor_kNullPointer="\x6e\x75\x6c\x6c\x70\x74\x72";
#if ReplacementFor_ReplacementFor_ELPP_VARIADIC_TEMPLATES_SUPPORTED
#endif  
static const base::type::ReplacementFor_ReplacementFor_VerboseLevel 
ReplacementFor_ReplacementFor_kMaxVerboseLevel=(0x813+3806-0x16e8);static const char*
ReplacementFor_ReplacementFor_kUnknownUser="\x75\x73\x65\x72";static const char*
ReplacementFor_ReplacementFor_kUnknownHost="\x75\x6e\x6b\x6e\x6f\x77\x6e\x2d\x68\x6f\x73\x74";
#if defined(ReplacementFor_ReplacementFor_ELPP_NO_DEFAULT_LOG_FILE)
#  if ReplacementFor_ReplacementFor_ELPP_OS_UNIX
static const char*ReplacementFor_ReplacementFor_kDefaultLogFile=
"\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c";
#  elif ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS
static const char*ReplacementFor_ReplacementFor_kDefaultLogFile="\x6e\x75\x6c";
#  endif  
#elif defined(ReplacementFor_ReplacementFor_ELPP_DEFAULT_LOG_FILE)
static const char*ReplacementFor_ReplacementFor_kDefaultLogFile=
ReplacementFor_ReplacementFor_ELPP_DEFAULT_LOG_FILE;
#else
static const char*ReplacementFor_ReplacementFor_kDefaultLogFile=
"\x2e\x6d\x59\x6c\x4f\x47\x2e\x4c\x6f\x47";
#endif 
#if !defined(ReplacementFor_ReplacementFor_ELPP_DISABLE_LOG_FILE_FROM_ARG)
static const char*ReplacementFor_ReplacementFor_kDefaultLogFileParam=
"\x2d\x2d\x64\x65\x66\x61\x75\x6c\x74\x2d\x6c\x6f\x67\x2d\x66\x69\x6c\x65";
#endif  
#if defined(ReplacementFor_ReplacementFor_ELPP_LOGGING_FLAGS_FROM_ARG)
static const char*ReplacementFor_ReplacementFor_kLoggingFlagsParam=
"\x2d\x2d\x6c\x6f\x67\x67\x69\x6e\x67\x2d\x66\x6c\x61\x67\x73";
#endif  
static const char*ReplacementFor_ReplacementFor_kValidLoggerIdSymbols=
"\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x2d\x2e\x5f"
;static const char*ReplacementFor_ReplacementFor_kConfigurationComment="\x23\x23";static const 
char*ReplacementFor_ReplacementFor_kConfigurationLevel="\x2a";static const char*
ReplacementFor_ReplacementFor_kConfigurationLoggerId="\x2d\x2d";}namespace ReplacementFor_ReplacementFor_utils
{static void abort(int status,const std::string&ReplacementFor_ReplacementFor_reason){
ReplacementFor_ReplacementFor_ELPP_UNUSED(status);ReplacementFor_ReplacementFor_ELPP_UNUSED(
ReplacementFor_ReplacementFor_reason);
#if defined(ReplacementFor_ReplacementFor_ELPP_COMPILER_MSVC) && defined(ReplacementFor_ReplacementFor__M_IX86\
) && defined(_DEBUG)
ReplacementFor_ReplacementFor__asm int(0x785+4839-0x1a69)
#else
::abort();
#endif
}}}const char*ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_convertToString(Level 
ReplacementFor_ReplacementFor_level){if(ReplacementFor_ReplacementFor_level==Level::Global)return
"\x47\x4c\x4f\x42\x41\x4c";if(ReplacementFor_ReplacementFor_level==Level::ReplacementFor_ReplacementFor_Debug)
return"\x44\x45\x42\x55\x47";if(ReplacementFor_ReplacementFor_level==Level::ReplacementFor_ReplacementFor_Info
)return"\x49\x4e\x46\x4f";if(ReplacementFor_ReplacementFor_level==Level::ReplacementFor_ReplacementFor_Warning
)return"\x57\x41\x52\x4e\x49\x4e\x47";if(ReplacementFor_ReplacementFor_level==Level::Error)
return"\x45\x52\x52\x4f\x52";if(ReplacementFor_ReplacementFor_level==Level::
ReplacementFor_ReplacementFor_Fatal)return"\x46\x41\x54\x41\x4c";if(ReplacementFor_ReplacementFor_level==Level
::ReplacementFor_ReplacementFor_Verbose)return"\x56\x45\x52\x42\x4f\x53\x45";if(
ReplacementFor_ReplacementFor_level==Level::ReplacementFor_ReplacementFor_Trace)return"\x54\x52\x41\x43\x45";
return"\x55\x4e\x4b\x4e\x4f\x57\x4e";}struct ReplacementFor_ReplacementFor_StringToLevelItem{
const char*ReplacementFor_ReplacementFor_levelString;Level ReplacementFor_ReplacementFor_level;};static struct
 ReplacementFor_ReplacementFor_StringToLevelItem ReplacementFor_ReplacementFor_stringToLevelMap[]={{
"\x67\x6c\x6f\x62\x61\x6c",Level::Global},{"\x64\x65\x62\x75\x67",Level::
ReplacementFor_ReplacementFor_Debug},{"\x69\x6e\x66\x6f",Level::ReplacementFor_ReplacementFor_Info},{
"\x77\x61\x72\x6e\x69\x6e\x67",Level::ReplacementFor_ReplacementFor_Warning},{
"\x65\x72\x72\x6f\x72",Level::Error},{"\x66\x61\x74\x61\x6c",Level::
ReplacementFor_ReplacementFor_Fatal},{"\x76\x65\x72\x62\x6f\x73\x65",Level::
ReplacementFor_ReplacementFor_Verbose},{"\x74\x72\x61\x63\x65",Level::ReplacementFor_ReplacementFor_Trace}};
Level ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_convertFromString(const char*
ReplacementFor_ReplacementFor_levelStr){for(auto&item:ReplacementFor_ReplacementFor_stringToLevelMap){if(base
::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_cStringCaseEq(
ReplacementFor_ReplacementFor_levelStr,item.ReplacementFor_ReplacementFor_levelString)){return item.
ReplacementFor_ReplacementFor_level;}}return Level::Unknown;}void ReplacementFor_ReplacementFor_LevelHelper::
ReplacementFor_ReplacementFor_forEachLevel(base::type::ReplacementFor_ReplacementFor_EnumType*
ReplacementFor_ReplacementFor_startIndex,const std::function<bool(void)>&ReplacementFor_ReplacementFor_fn){
base::type::ReplacementFor_ReplacementFor_EnumType ReplacementFor_ReplacementFor_lIndexMax=
ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_kMaxValid;do{if(ReplacementFor_ReplacementFor_fn()){
break;}*ReplacementFor_ReplacementFor_startIndex=static_cast<base::type::
ReplacementFor_ReplacementFor_EnumType>(*ReplacementFor_ReplacementFor_startIndex<<(0x752+4773-0x19f6));}while
(*ReplacementFor_ReplacementFor_startIndex<=ReplacementFor_ReplacementFor_lIndexMax);}const char*
ReplacementFor_ReplacementFor_ConfigurationTypeHelper::ReplacementFor_ReplacementFor_convertToString(
ReplacementFor_ReplacementFor_ConfigurationType ReplacementFor_ReplacementFor_configurationType){if(
ReplacementFor_ReplacementFor_configurationType==ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_Enabled)return"\x45\x4e\x41\x42\x4c\x45\x44";if(
ReplacementFor_ReplacementFor_configurationType==ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_Filename)return"\x46\x49\x4c\x45\x4e\x41\x4d\x45";if(
ReplacementFor_ReplacementFor_configurationType==ReplacementFor_ReplacementFor_ConfigurationType::Format)
return"\x46\x4f\x52\x4d\x41\x54";if(ReplacementFor_ReplacementFor_configurationType==
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_ToFile)return
"\x54\x4f\x5f\x46\x49\x4c\x45";if(ReplacementFor_ReplacementFor_configurationType==
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_ToStandardOutput)return
"\x54\x4f\x5f\x53\x54\x41\x4e\x44\x41\x52\x44\x5f\x4f\x55\x54\x50\x55\x54";if(
ReplacementFor_ReplacementFor_configurationType==ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_SubsecondPrecision)return
"\x53\x55\x42\x53\x45\x43\x4f\x4e\x44\x5f\x50\x52\x45\x43\x49\x53\x49\x4f\x4e";
if(ReplacementFor_ReplacementFor_configurationType==ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_PerformanceTracking)return
"\x50\x45\x52\x46\x4f\x52\x4d\x41\x4e\x43\x45\x5f\x54\x52\x41\x43\x4b\x49\x4e\x47"
;if(ReplacementFor_ReplacementFor_configurationType==ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_MaxLogFileSize)return
"\x4d\x41\x58\x5f\x4c\x4f\x47\x5f\x46\x49\x4c\x45\x5f\x53\x49\x5a\x45";if(
ReplacementFor_ReplacementFor_configurationType==ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_LogFlushThreshold)return
"\x4c\x4f\x47\x5f\x46\x4c\x55\x53\x48\x5f\x54\x48\x52\x45\x53\x48\x4f\x4c\x44";
return"\x55\x4e\x4b\x4e\x4f\x57\x4e";}struct 
ReplacementFor_ReplacementFor_ConfigurationStringToTypeItem{const char*
ReplacementFor_ReplacementFor_configString;ReplacementFor_ReplacementFor_ConfigurationType 
ReplacementFor_ReplacementFor_configType;};static struct 
ReplacementFor_ReplacementFor_ConfigurationStringToTypeItem 
ReplacementFor_ReplacementFor_configStringToTypeMap[]={{"\x65\x6e\x61\x62\x6c\x65\x64",
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_Enabled},{
"\x74\x6f\x5f\x66\x69\x6c\x65",ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_ToFile},{
"\x74\x6f\x5f\x73\x74\x61\x6e\x64\x61\x72\x64\x5f\x6f\x75\x74\x70\x75\x74",
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_ToStandardOutput},{
"\x66\x6f\x72\x6d\x61\x74",ReplacementFor_ReplacementFor_ConfigurationType::Format},{
"\x66\x69\x6c\x65\x6e\x61\x6d\x65",ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_Filename},{
"\x73\x75\x62\x73\x65\x63\x6f\x6e\x64\x5f\x70\x72\x65\x63\x69\x73\x69\x6f\x6e",
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_SubsecondPrecision},{
"\x6d\x69\x6c\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73\x5f\x77\x69\x64\x74\x68",
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_MillisecondsWidth},{
"\x70\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65\x5f\x74\x72\x61\x63\x6b\x69\x6e\x67"
,ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_PerformanceTracking},{
"\x6d\x61\x78\x5f\x6c\x6f\x67\x5f\x66\x69\x6c\x65\x5f\x73\x69\x7a\x65",
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_MaxLogFileSize},{
"\x6c\x6f\x67\x5f\x66\x6c\x75\x73\x68\x5f\x74\x68\x72\x65\x73\x68\x6f\x6c\x64",
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_LogFlushThreshold},};
ReplacementFor_ReplacementFor_ConfigurationType ReplacementFor_ReplacementFor_ConfigurationTypeHelper::
ReplacementFor_ReplacementFor_convertFromString(const char*ReplacementFor_ReplacementFor_configStr){for(auto&
item:ReplacementFor_ReplacementFor_configStringToTypeMap){if(base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_cStringCaseEq(ReplacementFor_ReplacementFor_configStr,item.
ReplacementFor_ReplacementFor_configString)){return item.ReplacementFor_ReplacementFor_configType;}}return 
ReplacementFor_ReplacementFor_ConfigurationType::Unknown;}void 
ReplacementFor_ReplacementFor_ConfigurationTypeHelper::ReplacementFor_ReplacementFor_forEachConfigType(base::
type::ReplacementFor_ReplacementFor_EnumType*ReplacementFor_ReplacementFor_startIndex,const std::function<bool
(void)>&ReplacementFor_ReplacementFor_fn){base::type::ReplacementFor_ReplacementFor_EnumType 
ReplacementFor_ReplacementFor_cIndexMax=ReplacementFor_ReplacementFor_ConfigurationTypeHelper::
ReplacementFor_ReplacementFor_kMaxValid;do{if(ReplacementFor_ReplacementFor_fn()){break;}*
ReplacementFor_ReplacementFor_startIndex=static_cast<base::type::ReplacementFor_ReplacementFor_EnumType>(*
ReplacementFor_ReplacementFor_startIndex<<(0x4+7897-0x1edc));}while(*ReplacementFor_ReplacementFor_startIndex
<=ReplacementFor_ReplacementFor_cIndexMax);}ReplacementFor_ReplacementFor_Configuration::
ReplacementFor_ReplacementFor_Configuration(const ReplacementFor_ReplacementFor_Configuration&c):
ReplacementFor_ReplacementFor_m_level(c.ReplacementFor_ReplacementFor_m_level),
ReplacementFor_ReplacementFor_m_configurationType(c.ReplacementFor_ReplacementFor_m_configurationType),
ReplacementFor_ReplacementFor_m_value(c.ReplacementFor_ReplacementFor_m_value){}ReplacementFor_ReplacementFor_Configuration&
ReplacementFor_ReplacementFor_Configuration::operator=(const ReplacementFor_ReplacementFor_Configuration&c){if
(&c!=this){ReplacementFor_ReplacementFor_m_level=c.ReplacementFor_ReplacementFor_m_level;
ReplacementFor_ReplacementFor_m_configurationType=c.ReplacementFor_ReplacementFor_m_configurationType;
ReplacementFor_ReplacementFor_m_value=c.ReplacementFor_ReplacementFor_m_value;}return*this;}
ReplacementFor_ReplacementFor_Configuration::ReplacementFor_ReplacementFor_Configuration(Level 
ReplacementFor_ReplacementFor_level,ReplacementFor_ReplacementFor_ConfigurationType 
ReplacementFor_ReplacementFor_configurationType,const std::string&value):ReplacementFor_ReplacementFor_m_level
(ReplacementFor_ReplacementFor_level),ReplacementFor_ReplacementFor_m_configurationType(
ReplacementFor_ReplacementFor_configurationType),ReplacementFor_ReplacementFor_m_value(value){}void 
ReplacementFor_ReplacementFor_Configuration::log(ReplacementFor_ReplacementFor_el::base::type::
ReplacementFor_ReplacementFor_ostream_t&os)const{os<<ReplacementFor_ReplacementFor_LevelHelper::
ReplacementFor_ReplacementFor_convertToString(ReplacementFor_ReplacementFor_m_level)<<
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x20")<<ReplacementFor_ReplacementFor_ConfigurationTypeHelper::
ReplacementFor_ReplacementFor_convertToString(ReplacementFor_ReplacementFor_m_configurationType)<<
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x20\x3d\x20")<<ReplacementFor_ReplacementFor_m_value.c_str();}
ReplacementFor_ReplacementFor_Configuration::ReplacementFor_ReplacementFor_Predicate::ReplacementFor_ReplacementFor_Predicate
(Level ReplacementFor_ReplacementFor_level,ReplacementFor_ReplacementFor_ConfigurationType 
ReplacementFor_ReplacementFor_configurationType):ReplacementFor_ReplacementFor_m_level(ReplacementFor_ReplacementFor_level),
ReplacementFor_ReplacementFor_m_configurationType(ReplacementFor_ReplacementFor_configurationType){}bool 
ReplacementFor_ReplacementFor_Configuration::ReplacementFor_ReplacementFor_Predicate::operator()(const 
ReplacementFor_ReplacementFor_Configuration*ReplacementFor_ReplacementFor_conf)const{return((
ReplacementFor_ReplacementFor_conf!=nullptr)&&(ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_level()==
ReplacementFor_ReplacementFor_m_level)&&(ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_configurationType(
)==ReplacementFor_ReplacementFor_m_configurationType));}ReplacementFor_ReplacementFor_Configurations::
ReplacementFor_ReplacementFor_Configurations(void):ReplacementFor_ReplacementFor_m_configurationFile(std::
string()),ReplacementFor_ReplacementFor_m_isFromFile(false){}ReplacementFor_ReplacementFor_Configurations::
ReplacementFor_ReplacementFor_Configurations(const std::string&ReplacementFor_ReplacementFor_configurationFile
,bool ReplacementFor_ReplacementFor_useDefaultsForRemaining,ReplacementFor_ReplacementFor_Configurations*base)
:ReplacementFor_ReplacementFor_m_configurationFile(ReplacementFor_ReplacementFor_configurationFile),
ReplacementFor_ReplacementFor_m_isFromFile(false){ReplacementFor_ReplacementFor_parseFromFile(
ReplacementFor_ReplacementFor_configurationFile,base);if(ReplacementFor_ReplacementFor_useDefaultsForRemaining
){ReplacementFor_ReplacementFor_setRemainingToDefault();}}bool ReplacementFor_ReplacementFor_Configurations::
ReplacementFor_ReplacementFor_parseFromFile(const std::string&ReplacementFor_ReplacementFor_configurationFile,
ReplacementFor_ReplacementFor_Configurations*base){bool ReplacementFor_ReplacementFor_assertionPassed=true;
ReplacementFor_ReplacementFor_ELPP_ASSERT((ReplacementFor_ReplacementFor_assertionPassed=base::
ReplacementFor_ReplacementFor_utils::File::ReplacementFor_ReplacementFor_pathExists(
ReplacementFor_ReplacementFor_configurationFile.c_str(),true))==true,
"\x43\x6f\x6e\x66\x20\x66\x69\x6c\x65\x20\x5b"<<ReplacementFor_ReplacementFor_configurationFile
<<"\x5d\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x21");if(!
ReplacementFor_ReplacementFor_assertionPassed){return false;}bool ReplacementFor_ReplacementFor_success=
ReplacementFor_ReplacementFor_Parser::ReplacementFor_ReplacementFor_parseFromFile(
ReplacementFor_ReplacementFor_configurationFile,this,base);ReplacementFor_ReplacementFor_m_isFromFile=
ReplacementFor_ReplacementFor_success;return ReplacementFor_ReplacementFor_success;}bool 
ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_parseFromText(const std::string&
ReplacementFor_ReplacementFor_configurationsString,ReplacementFor_ReplacementFor_Configurations*base){bool 
ReplacementFor_ReplacementFor_success=ReplacementFor_ReplacementFor_Parser::ReplacementFor_ReplacementFor_parseFromText(
ReplacementFor_ReplacementFor_configurationsString,this,base);if(ReplacementFor_ReplacementFor_success){
ReplacementFor_ReplacementFor_m_isFromFile=false;}return ReplacementFor_ReplacementFor_success;}void 
ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_setFromBase(
ReplacementFor_ReplacementFor_Configurations*base){if(base==nullptr||base==this){return;}base::
ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(
base->lock());for(ReplacementFor_ReplacementFor_Configuration*&ReplacementFor_ReplacementFor_conf:base->list()
){set(ReplacementFor_ReplacementFor_conf);}}bool ReplacementFor_ReplacementFor_Configurations::
ReplacementFor_ReplacementFor_hasConfiguration(ReplacementFor_ReplacementFor_ConfigurationType 
ReplacementFor_ReplacementFor_configurationType){base::type::ReplacementFor_ReplacementFor_EnumType lIndex=
ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_kMinValid;bool result=false;
ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_forEachLevel(&lIndex,[&](void)->bool{
if(ReplacementFor_ReplacementFor_hasConfiguration(ReplacementFor_ReplacementFor_LevelHelper::
ReplacementFor_ReplacementFor_castFromInt(lIndex),ReplacementFor_ReplacementFor_configurationType)){result=
true;}return result;});return result;}bool ReplacementFor_ReplacementFor_Configurations::
ReplacementFor_ReplacementFor_hasConfiguration(Level ReplacementFor_ReplacementFor_level,
ReplacementFor_ReplacementFor_ConfigurationType ReplacementFor_ReplacementFor_configurationType){base::
ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(
lock());
#if ReplacementFor_ReplacementFor_ELPP_COMPILER_INTEL
return ReplacementFor_ReplacementFor_RegistryWithPred::get(ReplacementFor_ReplacementFor_level,
ReplacementFor_ReplacementFor_configurationType)!=nullptr;
#else
return ReplacementFor_ReplacementFor_RegistryWithPred<ReplacementFor_ReplacementFor_Configuration,
ReplacementFor_ReplacementFor_Configuration::ReplacementFor_ReplacementFor_Predicate>::get(
ReplacementFor_ReplacementFor_level,ReplacementFor_ReplacementFor_configurationType)!=nullptr;
#endif  
}void ReplacementFor_ReplacementFor_Configurations::set(Level ReplacementFor_ReplacementFor_level,
ReplacementFor_ReplacementFor_ConfigurationType ReplacementFor_ReplacementFor_configurationType,const std::
string&value){base::ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock 
ReplacementFor_ReplacementFor_scopedLock(lock());ReplacementFor_ReplacementFor_unsafeSet(ReplacementFor_ReplacementFor_level,
ReplacementFor_ReplacementFor_configurationType,value);if(ReplacementFor_ReplacementFor_level==Level::Global){
ReplacementFor_ReplacementFor_unsafeSetGlobally(ReplacementFor_ReplacementFor_configurationType,value,false);}
}void ReplacementFor_ReplacementFor_Configurations::set(ReplacementFor_ReplacementFor_Configuration*
ReplacementFor_ReplacementFor_conf){if(ReplacementFor_ReplacementFor_conf==nullptr){return;}set(
ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_level(),ReplacementFor_ReplacementFor_conf->
ReplacementFor_ReplacementFor_configurationType(),ReplacementFor_ReplacementFor_conf->value());}void 
ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_setToDefault(void){
ReplacementFor_ReplacementFor_setGlobally(ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_Enabled,std::string("\x74\x72\x75\x65"),true);
ReplacementFor_ReplacementFor_setGlobally(ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_Filename,std::string(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kDefaultLogFile),true);
#if defined(ReplacementFor_ReplacementFor_ELPP_NO_LOG_TO_FILE)
ReplacementFor_ReplacementFor_setGlobally(ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_ToFile,std::string("\x66\x61\x6c\x73\x65"),true);
#else
ReplacementFor_ReplacementFor_setGlobally(ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_ToFile,std::string("\x74\x72\x75\x65"),true);
#endif 
ReplacementFor_ReplacementFor_setGlobally(ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_ToStandardOutput,std::string("\x74\x72\x75\x65"),true);
ReplacementFor_ReplacementFor_setGlobally(ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_SubsecondPrecision,std::string("\x33"),true);
ReplacementFor_ReplacementFor_setGlobally(ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_PerformanceTracking,std::string("\x74\x72\x75\x65"),true);
ReplacementFor_ReplacementFor_setGlobally(ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_MaxLogFileSize,std::string("\x30"),true);
ReplacementFor_ReplacementFor_setGlobally(ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_LogFlushThreshold,std::string("\x30"),true);
ReplacementFor_ReplacementFor_setGlobally(ReplacementFor_ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
),true);set(Level::ReplacementFor_ReplacementFor_Debug,ReplacementFor_ReplacementFor_ConfigurationType::Format
,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x75\x73\x65\x72\x40\x25\x68\x6f\x73\x74\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));set(Level::Error,ReplacementFor_ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));set(Level::ReplacementFor_ReplacementFor_Fatal,ReplacementFor_ReplacementFor_ConfigurationType::Format,std
::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));set(Level::ReplacementFor_ReplacementFor_Verbose,ReplacementFor_ReplacementFor_ConfigurationType::Format,
std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x2d\x25\x76\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));set(Level::ReplacementFor_ReplacementFor_Trace,ReplacementFor_ReplacementFor_ConfigurationType::Format,std
::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));}void ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_setRemainingToDefault(
void){base::ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock 
ReplacementFor_ReplacementFor_scopedLock(lock());
#if defined(ReplacementFor_ReplacementFor_ELPP_NO_LOG_TO_FILE)
ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_Enabled,std::string(
"\x66\x61\x6c\x73\x65"));
#else
ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_Enabled,std::string(
"\x74\x72\x75\x65"));
#endif 
ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_Filename,std::string(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDefaultLogFile));
ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_ToStandardOutput,std::string(
"\x74\x72\x75\x65"));ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_SubsecondPrecision,std::string(
"\x33"));ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_PerformanceTracking,std::string
("\x74\x72\x75\x65"));ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_MaxLogFileSize,std::string(
"\x30"));ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::ReplacementFor_ReplacementFor_Debug,
ReplacementFor_ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x75\x73\x65\x72\x40\x25\x68\x6f\x73\x74\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::Error,
ReplacementFor_ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::ReplacementFor_ReplacementFor_Fatal,
ReplacementFor_ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::ReplacementFor_ReplacementFor_Verbose,
ReplacementFor_ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x2d\x25\x76\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level::ReplacementFor_ReplacementFor_Trace,
ReplacementFor_ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));}bool ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_Parser::
ReplacementFor_ReplacementFor_parseFromFile(const std::string&ReplacementFor_ReplacementFor_configurationFile,
ReplacementFor_ReplacementFor_Configurations*ReplacementFor_ReplacementFor_sender,
ReplacementFor_ReplacementFor_Configurations*base){ReplacementFor_ReplacementFor_sender->
ReplacementFor_ReplacementFor_setFromBase(base);std::ifstream ReplacementFor_ReplacementFor_fileStream_(
ReplacementFor_ReplacementFor_configurationFile.c_str(),std::ifstream::in);
ReplacementFor_ReplacementFor_ELPP_ASSERT(ReplacementFor_ReplacementFor_fileStream_.is_open(),
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x6f\x70\x65\x6e\x20\x63\x6f\x6e\x66\x20\x66\x69\x6c\x65\x20\x5b"
<<ReplacementFor_ReplacementFor_configurationFile<<"\x5d\x2e");bool 
ReplacementFor_ReplacementFor_parsedSuccessfully=false;std::string line=std::string();Level 
ReplacementFor_ReplacementFor_currLevel=Level::Unknown;std::string ReplacementFor_ReplacementFor_currConfigStr
=std::string();std::string ReplacementFor_ReplacementFor_currLevelStr=std::string();while(
ReplacementFor_ReplacementFor_fileStream_.good()){std::getline(ReplacementFor_ReplacementFor_fileStream_,line)
;ReplacementFor_ReplacementFor_parsedSuccessfully=ReplacementFor_ReplacementFor_parseLine(&line,&
ReplacementFor_ReplacementFor_currConfigStr,&ReplacementFor_ReplacementFor_currLevelStr,&
ReplacementFor_ReplacementFor_currLevel,ReplacementFor_ReplacementFor_sender);ReplacementFor_ReplacementFor_ELPP_ASSERT(
ReplacementFor_ReplacementFor_parsedSuccessfully,
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x70\x61\x72\x73\x65\x20\x63\x6f\x6e\x66\x20\x6c\x69\x6e\x65\x3a\x20"
<<line);}return ReplacementFor_ReplacementFor_parsedSuccessfully;}bool 
ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_Parser::
ReplacementFor_ReplacementFor_parseFromText(const std::string&
ReplacementFor_ReplacementFor_configurationsString,ReplacementFor_ReplacementFor_Configurations*
ReplacementFor_ReplacementFor_sender,ReplacementFor_ReplacementFor_Configurations*base){ReplacementFor_ReplacementFor_sender
->ReplacementFor_ReplacementFor_setFromBase(base);bool ReplacementFor_ReplacementFor_parsedSuccessfully=false;
std::stringstream ReplacementFor_ReplacementFor_ss(ReplacementFor_ReplacementFor_configurationsString);std::
string line=std::string();Level ReplacementFor_ReplacementFor_currLevel=Level::Unknown;std::
string ReplacementFor_ReplacementFor_currConfigStr=std::string();std::string 
ReplacementFor_ReplacementFor_currLevelStr=std::string();while(std::getline(ReplacementFor_ReplacementFor_ss,
line)){ReplacementFor_ReplacementFor_parsedSuccessfully=ReplacementFor_ReplacementFor_parseLine(&line,&
ReplacementFor_ReplacementFor_currConfigStr,&ReplacementFor_ReplacementFor_currLevelStr,&
ReplacementFor_ReplacementFor_currLevel,ReplacementFor_ReplacementFor_sender);ReplacementFor_ReplacementFor_ELPP_ASSERT(
ReplacementFor_ReplacementFor_parsedSuccessfully,
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x70\x61\x72\x73\x65\x20\x63\x6f\x6e\x66\x20\x6c\x69\x6e\x65\x3a\x20"
<<line);}return ReplacementFor_ReplacementFor_parsedSuccessfully;}void 
ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_Parser::
ReplacementFor_ReplacementFor_ignoreComments(std::string*line){std::size_t 
ReplacementFor_ReplacementFor_foundAt=(0x91a+1266-0xe0c);std::size_t ReplacementFor_ReplacementFor_quotesStart
=line->find("\"");std::size_t ReplacementFor_ReplacementFor_quotesEnd=std::string::npos;if(
ReplacementFor_ReplacementFor_quotesStart!=std::string::npos){ReplacementFor_ReplacementFor_quotesEnd=line->
find("\"",ReplacementFor_ReplacementFor_quotesStart+(0x1113+4243-0x21a5));while(
ReplacementFor_ReplacementFor_quotesEnd!=std::string::npos&&line->at(ReplacementFor_ReplacementFor_quotesEnd-
(0x145+4139-0x116f))=='\\'){ReplacementFor_ReplacementFor_quotesEnd=line->find("\"",
ReplacementFor_ReplacementFor_quotesEnd+(0x5b0+4141-0x15db));}}if((ReplacementFor_ReplacementFor_foundAt=line
->find(base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kConfigurationComment))!=std
::string::npos){if(ReplacementFor_ReplacementFor_foundAt<ReplacementFor_ReplacementFor_quotesEnd){
ReplacementFor_ReplacementFor_foundAt=line->find(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kConfigurationComment,ReplacementFor_ReplacementFor_quotesEnd+(0x87a+659-0xb0c))
;}*line=line->substr((0x1765+3144-0x23ad),ReplacementFor_ReplacementFor_foundAt);}}bool 
ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_Parser::ReplacementFor_ReplacementFor_isLevel(
const std::string&line){return base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_startsWith(line,std::string(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kConfigurationLevel));}bool ReplacementFor_ReplacementFor_Configurations::
ReplacementFor_ReplacementFor_Parser::ReplacementFor_ReplacementFor_isComment(const std::string&line){return 
base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_startsWith(line,std::string(base
::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kConfigurationComment));}bool 
ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_Parser::ReplacementFor_ReplacementFor_isConfig(
const std::string&line){std::size_t ReplacementFor_ReplacementFor_assignment=line.find(
((char)(0x226+4754-0x147b)));return line!=""&&((line[(0x174b+3565-0x2538)]>=
((char)(0x1247+3510-0x1fbc))&&line[(0x8f0+5680-0x1f20)]<=
((char)(0x1dc+7463-0x1ea9)))||(line[(0xe3f+2125-0x168c)]>=
((char)(0xc10+6942-0x26cd))&&line[(0x91b+3963-0x1896)]<=
((char)(0x565+2467-0xe8e))))&&(ReplacementFor_ReplacementFor_assignment!=std::string::npos)&&(
line.size()>ReplacementFor_ReplacementFor_assignment);}bool ReplacementFor_ReplacementFor_Configurations::
ReplacementFor_ReplacementFor_Parser::ReplacementFor_ReplacementFor_parseLine(std::string*line,std::string*
ReplacementFor_ReplacementFor_currConfigStr,std::string*ReplacementFor_ReplacementFor_currLevelStr,Level*
ReplacementFor_ReplacementFor_currLevel,ReplacementFor_ReplacementFor_Configurations*ReplacementFor_ReplacementFor_conf){
ReplacementFor_ReplacementFor_ConfigurationType ReplacementFor_ReplacementFor_currConfig=
ReplacementFor_ReplacementFor_ConfigurationType::Unknown;std::string ReplacementFor_ReplacementFor_currValue=
std::string();*line=base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_trim(*line);
if(ReplacementFor_ReplacementFor_isComment(*line))return true;ReplacementFor_ReplacementFor_ignoreComments(
line);*line=base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_trim(*line);if(line
->empty()){return true;}if(ReplacementFor_ReplacementFor_isLevel(*line)){if(line->size()<=
(0x426+1417-0x9ad)){return true;}*ReplacementFor_ReplacementFor_currLevelStr=line->substr(
(0x1720+3258-0x23d9),line->size()-(0x773+1282-0xc73));*
ReplacementFor_ReplacementFor_currLevelStr=base::ReplacementFor_ReplacementFor_utils::Str::toUpper(*
ReplacementFor_ReplacementFor_currLevelStr);*ReplacementFor_ReplacementFor_currLevelStr=base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_trim(*ReplacementFor_ReplacementFor_currLevelStr);*
ReplacementFor_ReplacementFor_currLevel=ReplacementFor_ReplacementFor_LevelHelper::
ReplacementFor_ReplacementFor_convertFromString(ReplacementFor_ReplacementFor_currLevelStr->c_str());return 
true;}if(ReplacementFor_ReplacementFor_isConfig(*line)){std::size_t ReplacementFor_ReplacementFor_assignment=
line->find(((char)(0x13f2+18-0x13c7)));*ReplacementFor_ReplacementFor_currConfigStr=line->
substr((0x13ec+4000-0x238c),ReplacementFor_ReplacementFor_assignment);*
ReplacementFor_ReplacementFor_currConfigStr=base::ReplacementFor_ReplacementFor_utils::Str::toUpper(*
ReplacementFor_ReplacementFor_currConfigStr);*ReplacementFor_ReplacementFor_currConfigStr=base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_trim(*ReplacementFor_ReplacementFor_currConfigStr);
ReplacementFor_ReplacementFor_currConfig=ReplacementFor_ReplacementFor_ConfigurationTypeHelper::
ReplacementFor_ReplacementFor_convertFromString(ReplacementFor_ReplacementFor_currConfigStr->c_str());
ReplacementFor_ReplacementFor_currValue=line->substr(ReplacementFor_ReplacementFor_assignment+
(0x1401+1478-0x19c6));ReplacementFor_ReplacementFor_currValue=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_trim(ReplacementFor_ReplacementFor_currValue);std::size_t 
ReplacementFor_ReplacementFor_quotesStart=ReplacementFor_ReplacementFor_currValue.find("\"",
(0xbb2+1619-0x1205));std::size_t ReplacementFor_ReplacementFor_quotesEnd=std::string::npos;if(
ReplacementFor_ReplacementFor_quotesStart!=std::string::npos){ReplacementFor_ReplacementFor_quotesEnd=
ReplacementFor_ReplacementFor_currValue.find("\"",ReplacementFor_ReplacementFor_quotesStart+(0x592+923-0x92c))
;while(ReplacementFor_ReplacementFor_quotesEnd!=std::string::npos&&ReplacementFor_ReplacementFor_currValue.at(
ReplacementFor_ReplacementFor_quotesEnd-(0x88a+4228-0x190d))=='\\'){ReplacementFor_ReplacementFor_currValue=
ReplacementFor_ReplacementFor_currValue.erase(ReplacementFor_ReplacementFor_quotesEnd-(0x1771+1754-0x1e4a),
(0x1900+2553-0x22f8));ReplacementFor_ReplacementFor_quotesEnd=ReplacementFor_ReplacementFor_currValue.find(
"\"",ReplacementFor_ReplacementFor_quotesEnd+(0x1479+2339-0x1d9a));}}if(
ReplacementFor_ReplacementFor_quotesStart!=std::string::npos&&ReplacementFor_ReplacementFor_quotesEnd!=std::
string::npos){ReplacementFor_ReplacementFor_ELPP_ASSERT((ReplacementFor_ReplacementFor_quotesStart<
ReplacementFor_ReplacementFor_quotesEnd),
"\x43\x6f\x6e\x66\x20\x65\x72\x72\x6f\x72\x20\x2d\x20\x4e\x6f\x20\x65\x6e\x64\x69\x6e\x67\x20\x71\x75\x6f\x74\x65\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x5b"
<<ReplacementFor_ReplacementFor_currConfigStr<<"\x5d");ReplacementFor_ReplacementFor_ELPP_ASSERT((
ReplacementFor_ReplacementFor_quotesStart+(0x1a9c+2639-0x24ea)!=ReplacementFor_ReplacementFor_quotesEnd),
"\x45\x6d\x70\x74\x79\x20\x63\x6f\x6e\x66\x20\x76\x61\x6c\x75\x65\x20\x66\x6f\x72\x20\x5b"
<<ReplacementFor_ReplacementFor_currConfigStr<<"\x5d");if((ReplacementFor_ReplacementFor_quotesStart!=
ReplacementFor_ReplacementFor_quotesEnd)&&(ReplacementFor_ReplacementFor_quotesStart+(0xe95+1283-0x1397)!=
ReplacementFor_ReplacementFor_quotesEnd)){ReplacementFor_ReplacementFor_currValue=ReplacementFor_ReplacementFor_currValue.
substr(ReplacementFor_ReplacementFor_quotesStart+(0x11+1604-0x654),ReplacementFor_ReplacementFor_quotesEnd-
(0x1c1c+1849-0x2354));}}}ReplacementFor_ReplacementFor_ELPP_ASSERT(*ReplacementFor_ReplacementFor_currLevel!=
Level::Unknown,
"\x55\x6e\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20\x73\x65\x76\x65\x72\x69\x74\x79\x20\x6c\x65\x76\x65\x6c\x20\x5b"
<<*ReplacementFor_ReplacementFor_currLevelStr<<"\x5d");ReplacementFor_ReplacementFor_ELPP_ASSERT(
ReplacementFor_ReplacementFor_currConfig!=ReplacementFor_ReplacementFor_ConfigurationType::Unknown,
"\x55\x6e\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20\x63\x6f\x6e\x66\x20\x5b"<<
*ReplacementFor_ReplacementFor_currConfigStr<<"\x5d");if(*ReplacementFor_ReplacementFor_currLevel==Level::
Unknown||ReplacementFor_ReplacementFor_currConfig==ReplacementFor_ReplacementFor_ConfigurationType::Unknown){
return false;}ReplacementFor_ReplacementFor_conf->set(*ReplacementFor_ReplacementFor_currLevel,
ReplacementFor_ReplacementFor_currConfig,ReplacementFor_ReplacementFor_currValue);return true;}void 
ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_unsafeSetIfNotExist(Level 
ReplacementFor_ReplacementFor_level,ReplacementFor_ReplacementFor_ConfigurationType 
ReplacementFor_ReplacementFor_configurationType,const std::string&value){
ReplacementFor_ReplacementFor_Configuration*ReplacementFor_ReplacementFor_conf=ReplacementFor_ReplacementFor_RegistryWithPred
<ReplacementFor_ReplacementFor_Configuration,ReplacementFor_ReplacementFor_Configuration::
ReplacementFor_ReplacementFor_Predicate>::get(ReplacementFor_ReplacementFor_level,
ReplacementFor_ReplacementFor_configurationType);if(ReplacementFor_ReplacementFor_conf==nullptr){
ReplacementFor_ReplacementFor_unsafeSet(ReplacementFor_ReplacementFor_level,ReplacementFor_ReplacementFor_configurationType,
value);}}void ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_unsafeSet(Level 
ReplacementFor_ReplacementFor_level,ReplacementFor_ReplacementFor_ConfigurationType 
ReplacementFor_ReplacementFor_configurationType,const std::string&value){
ReplacementFor_ReplacementFor_Configuration*ReplacementFor_ReplacementFor_conf=ReplacementFor_ReplacementFor_RegistryWithPred
<ReplacementFor_ReplacementFor_Configuration,ReplacementFor_ReplacementFor_Configuration::
ReplacementFor_ReplacementFor_Predicate>::get(ReplacementFor_ReplacementFor_level,
ReplacementFor_ReplacementFor_configurationType);if(ReplacementFor_ReplacementFor_conf==nullptr){
ReplacementFor_ReplacementFor_registerNew(new ReplacementFor_ReplacementFor_Configuration(ReplacementFor_ReplacementFor_level
,ReplacementFor_ReplacementFor_configurationType,value));}else{ReplacementFor_ReplacementFor_conf->
ReplacementFor_ReplacementFor_setValue(value);}if(ReplacementFor_ReplacementFor_level==Level::Global){
ReplacementFor_ReplacementFor_unsafeSetGlobally(ReplacementFor_ReplacementFor_configurationType,value,false);}
}void ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_setGlobally(
ReplacementFor_ReplacementFor_ConfigurationType ReplacementFor_ReplacementFor_configurationType,const std::
string&value,bool ReplacementFor_ReplacementFor_includeGlobalLevel){if(
ReplacementFor_ReplacementFor_includeGlobalLevel){set(Level::Global,
ReplacementFor_ReplacementFor_configurationType,value);}base::type::ReplacementFor_ReplacementFor_EnumType 
lIndex=ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_kMinValid;
ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_forEachLevel(&lIndex,[&](void)->bool{
set(ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_castFromInt(lIndex),
ReplacementFor_ReplacementFor_configurationType,value);return false;});}void 
ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_unsafeSetGlobally(
ReplacementFor_ReplacementFor_ConfigurationType ReplacementFor_ReplacementFor_configurationType,const std::
string&value,bool ReplacementFor_ReplacementFor_includeGlobalLevel){if(
ReplacementFor_ReplacementFor_includeGlobalLevel){ReplacementFor_ReplacementFor_unsafeSet(Level::Global,
ReplacementFor_ReplacementFor_configurationType,value);}base::type::ReplacementFor_ReplacementFor_EnumType 
lIndex=ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_kMinValid;
ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_forEachLevel(&lIndex,[&](void)->bool{
ReplacementFor_ReplacementFor_unsafeSet(ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_castFromInt(
lIndex),ReplacementFor_ReplacementFor_configurationType,value);return false;});}void 
ReplacementFor_ReplacementFor_LogBuilder::ReplacementFor_ReplacementFor_convertToColoredOutput(base::type::
ReplacementFor_ReplacementFor_string_t*ReplacementFor_ReplacementFor_logLine,Level ReplacementFor_ReplacementFor_level){if(!
ReplacementFor_ReplacementFor_m_termSupportsColor)return;const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_resetColor=ReplacementFor_ReplacementFor_ELPP_LITERAL(
"\x1b" "\x5b\x30\x6d");if(ReplacementFor_ReplacementFor_level==Level::Error||
ReplacementFor_ReplacementFor_level==Level::ReplacementFor_ReplacementFor_Fatal)*ReplacementFor_ReplacementFor_logLine=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\x1b" "\x5b\x33\x31\x6d")+*ReplacementFor_ReplacementFor_logLine+
ReplacementFor_ReplacementFor_resetColor;else if(ReplacementFor_ReplacementFor_level==Level::
ReplacementFor_ReplacementFor_Warning)*ReplacementFor_ReplacementFor_logLine=ReplacementFor_ReplacementFor_ELPP_LITERAL(
"\x1b" "\x5b\x33\x33\x6d")+*ReplacementFor_ReplacementFor_logLine+ReplacementFor_ReplacementFor_resetColor;
else if(ReplacementFor_ReplacementFor_level==Level::ReplacementFor_ReplacementFor_Debug)*
ReplacementFor_ReplacementFor_logLine=ReplacementFor_ReplacementFor_ELPP_LITERAL("\x1b" "\x5b\x33\x32\x6d")+*
ReplacementFor_ReplacementFor_logLine+ReplacementFor_ReplacementFor_resetColor;else if(ReplacementFor_ReplacementFor_level==
Level::ReplacementFor_ReplacementFor_Info)*ReplacementFor_ReplacementFor_logLine=ReplacementFor_ReplacementFor_ELPP_LITERAL(
"\x1b" "\x5b\x33\x36\x6d")+*ReplacementFor_ReplacementFor_logLine+ReplacementFor_ReplacementFor_resetColor;
else if(ReplacementFor_ReplacementFor_level==Level::ReplacementFor_ReplacementFor_Trace)*
ReplacementFor_ReplacementFor_logLine=ReplacementFor_ReplacementFor_ELPP_LITERAL("\x1b" "\x5b\x33\x35\x6d")+*
ReplacementFor_ReplacementFor_logLine+ReplacementFor_ReplacementFor_resetColor;}ReplacementFor_ReplacementFor_Logger::
ReplacementFor_ReplacementFor_Logger(const std::string&id,base::
ReplacementFor_ReplacementFor_LogStreamsReferenceMap*ReplacementFor_ReplacementFor_logStreamsReference):
ReplacementFor_ReplacementFor_m_id(id),ReplacementFor_ReplacementFor_m_typedConfigurations(nullptr),
ReplacementFor_ReplacementFor_m_parentApplicationName(std::string()),
ReplacementFor_ReplacementFor_m_isConfigured(false),ReplacementFor_ReplacementFor_m_logStreamsReference(
ReplacementFor_ReplacementFor_logStreamsReference){ReplacementFor_ReplacementFor_initUnflushedCount();}
ReplacementFor_ReplacementFor_Logger::ReplacementFor_ReplacementFor_Logger(const std::string&id,const 
ReplacementFor_ReplacementFor_Configurations&ReplacementFor_ReplacementFor_configurations,base::
ReplacementFor_ReplacementFor_LogStreamsReferenceMap*ReplacementFor_ReplacementFor_logStreamsReference):
ReplacementFor_ReplacementFor_m_id(id),ReplacementFor_ReplacementFor_m_typedConfigurations(nullptr),
ReplacementFor_ReplacementFor_m_parentApplicationName(std::string()),
ReplacementFor_ReplacementFor_m_isConfigured(false),ReplacementFor_ReplacementFor_m_logStreamsReference(
ReplacementFor_ReplacementFor_logStreamsReference){ReplacementFor_ReplacementFor_initUnflushedCount();
ReplacementFor_ReplacementFor_configure(ReplacementFor_ReplacementFor_configurations);}ReplacementFor_ReplacementFor_Logger::
ReplacementFor_ReplacementFor_Logger(const ReplacementFor_ReplacementFor_Logger&ReplacementFor_ReplacementFor_logger){base::
ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_safeDelete(
ReplacementFor_ReplacementFor_m_typedConfigurations);ReplacementFor_ReplacementFor_m_id=ReplacementFor_ReplacementFor_logger.
ReplacementFor_ReplacementFor_m_id;ReplacementFor_ReplacementFor_m_typedConfigurations=ReplacementFor_ReplacementFor_logger.
ReplacementFor_ReplacementFor_m_typedConfigurations;ReplacementFor_ReplacementFor_m_parentApplicationName=
ReplacementFor_ReplacementFor_logger.ReplacementFor_ReplacementFor_m_parentApplicationName;
ReplacementFor_ReplacementFor_m_isConfigured=ReplacementFor_ReplacementFor_logger.
ReplacementFor_ReplacementFor_m_isConfigured;ReplacementFor_ReplacementFor_m_configurations=
ReplacementFor_ReplacementFor_logger.ReplacementFor_ReplacementFor_m_configurations;
ReplacementFor_ReplacementFor_m_unflushedCount=ReplacementFor_ReplacementFor_logger.
ReplacementFor_ReplacementFor_m_unflushedCount;ReplacementFor_ReplacementFor_m_logStreamsReference=
ReplacementFor_ReplacementFor_logger.ReplacementFor_ReplacementFor_m_logStreamsReference;}
ReplacementFor_ReplacementFor_Logger&ReplacementFor_ReplacementFor_Logger::operator=(const 
ReplacementFor_ReplacementFor_Logger&ReplacementFor_ReplacementFor_logger){if(&ReplacementFor_ReplacementFor_logger!=this){
base::ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_safeDelete(
ReplacementFor_ReplacementFor_m_typedConfigurations);ReplacementFor_ReplacementFor_m_id=ReplacementFor_ReplacementFor_logger.
ReplacementFor_ReplacementFor_m_id;ReplacementFor_ReplacementFor_m_typedConfigurations=ReplacementFor_ReplacementFor_logger.
ReplacementFor_ReplacementFor_m_typedConfigurations;ReplacementFor_ReplacementFor_m_parentApplicationName=
ReplacementFor_ReplacementFor_logger.ReplacementFor_ReplacementFor_m_parentApplicationName;
ReplacementFor_ReplacementFor_m_isConfigured=ReplacementFor_ReplacementFor_logger.
ReplacementFor_ReplacementFor_m_isConfigured;ReplacementFor_ReplacementFor_m_configurations=
ReplacementFor_ReplacementFor_logger.ReplacementFor_ReplacementFor_m_configurations;
ReplacementFor_ReplacementFor_m_unflushedCount=ReplacementFor_ReplacementFor_logger.
ReplacementFor_ReplacementFor_m_unflushedCount;ReplacementFor_ReplacementFor_m_logStreamsReference=
ReplacementFor_ReplacementFor_logger.ReplacementFor_ReplacementFor_m_logStreamsReference;}return*this;}void 
ReplacementFor_ReplacementFor_Logger::ReplacementFor_ReplacementFor_configure(const 
ReplacementFor_ReplacementFor_Configurations&ReplacementFor_ReplacementFor_configurations){
ReplacementFor_ReplacementFor_m_isConfigured=false;ReplacementFor_ReplacementFor_initUnflushedCount();if(
ReplacementFor_ReplacementFor_m_typedConfigurations!=nullptr){ReplacementFor_ReplacementFor_Configurations*c=
const_cast<ReplacementFor_ReplacementFor_Configurations*>(ReplacementFor_ReplacementFor_m_typedConfigurations
->ReplacementFor_ReplacementFor_configurations());if(c->ReplacementFor_ReplacementFor_hasConfiguration(Level::
Global,ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_Filename)){flush();}}
base::ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock 
ReplacementFor_ReplacementFor_scopedLock(lock());if(ReplacementFor_ReplacementFor_m_configurations!=
ReplacementFor_ReplacementFor_configurations){ReplacementFor_ReplacementFor_m_configurations.
ReplacementFor_ReplacementFor_setFromBase(const_cast<ReplacementFor_ReplacementFor_Configurations*>(&
ReplacementFor_ReplacementFor_configurations));}base::ReplacementFor_ReplacementFor_utils::
ReplacementFor_ReplacementFor_safeDelete(ReplacementFor_ReplacementFor_m_typedConfigurations);
ReplacementFor_ReplacementFor_m_typedConfigurations=new base::
ReplacementFor_ReplacementFor_TypedConfigurations(&ReplacementFor_ReplacementFor_m_configurations,
ReplacementFor_ReplacementFor_m_logStreamsReference);ReplacementFor_ReplacementFor_resolveLoggerFormatSpec();
ReplacementFor_ReplacementFor_m_isConfigured=true;}void ReplacementFor_ReplacementFor_Logger::
ReplacementFor_ReplacementFor_reconfigure(void){ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO(
(0xdd6+4047-0x1da4),
"\x52\x65\x63\x6f\x6e\x66\x20\x6c\x6f\x67\x67\x65\x72\x20\x5b"<<
ReplacementFor_ReplacementFor_m_id<<"\x5d");ReplacementFor_ReplacementFor_configure(
ReplacementFor_ReplacementFor_m_configurations);}bool ReplacementFor_ReplacementFor_Logger::
ReplacementFor_ReplacementFor_isValidId(const std::string&id){for(std::string::const_iterator 
ReplacementFor_ReplacementFor_it=id.begin();ReplacementFor_ReplacementFor_it!=id.end();++ReplacementFor_ReplacementFor_it){if
(!base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_contains(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kValidLoggerIdSymbols,*ReplacementFor_ReplacementFor_it))
{return false;}}return true;}void ReplacementFor_ReplacementFor_Logger::flush(void){
ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0xfbd+797-0x12d7),
"\x46\x6c\x75\x73\x68\x69\x6e\x67\x20\x6c\x6f\x67\x67\x65\x72\x20\x5b"<<
ReplacementFor_ReplacementFor_m_id<<"\x5d");base::ReplacementFor_ReplacementFor_threading::
ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(lock());base::type::
ReplacementFor_ReplacementFor_EnumType lIndex=ReplacementFor_ReplacementFor_LevelHelper::
ReplacementFor_ReplacementFor_kMinValid;ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_forEachLevel
(&lIndex,[&](void)->bool{flush(ReplacementFor_ReplacementFor_LevelHelper::
ReplacementFor_ReplacementFor_castFromInt(lIndex),nullptr);return false;});}void 
ReplacementFor_ReplacementFor_Logger::flush(Level ReplacementFor_ReplacementFor_level,base::type::
ReplacementFor_ReplacementFor_fstream_t*fs){if(fs==nullptr&&
ReplacementFor_ReplacementFor_m_typedConfigurations->ReplacementFor_ReplacementFor_toFile(ReplacementFor_ReplacementFor_level
)){fs=ReplacementFor_ReplacementFor_m_typedConfigurations->ReplacementFor_ReplacementFor_fileStream(
ReplacementFor_ReplacementFor_level);}if(fs!=nullptr){fs->flush();std::unordered_map<Level,
unsigned int>::iterator iter=ReplacementFor_ReplacementFor_m_unflushedCount.find(
ReplacementFor_ReplacementFor_level);if(iter!=ReplacementFor_ReplacementFor_m_unflushedCount.end()){iter->
second=(0x636+3135-0x1275);}ReplacementFor_ReplacementFor_Helpers::
ReplacementFor_ReplacementFor_validateFileRolling(this,ReplacementFor_ReplacementFor_level);}}void 
ReplacementFor_ReplacementFor_Logger::ReplacementFor_ReplacementFor_initUnflushedCount(void){
ReplacementFor_ReplacementFor_m_unflushedCount.clear();base::type::ReplacementFor_ReplacementFor_EnumType 
lIndex=ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_kMinValid;
ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_forEachLevel(&lIndex,[&](void)->bool{
ReplacementFor_ReplacementFor_m_unflushedCount.insert(std::make_pair(ReplacementFor_ReplacementFor_LevelHelper
::ReplacementFor_ReplacementFor_castFromInt(lIndex),(0x1ff6+624-0x2266)));return false;});}void
 ReplacementFor_ReplacementFor_Logger::ReplacementFor_ReplacementFor_resolveLoggerFormatSpec(void)const{base::
type::ReplacementFor_ReplacementFor_EnumType lIndex=ReplacementFor_ReplacementFor_LevelHelper::
ReplacementFor_ReplacementFor_kMinValid;ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_forEachLevel
(&lIndex,[&](void)->bool{base::ReplacementFor_ReplacementFor_LogFormat*ReplacementFor_ReplacementFor_logFormat
=const_cast<base::ReplacementFor_ReplacementFor_LogFormat*>(&
ReplacementFor_ReplacementFor_m_typedConfigurations->ReplacementFor_ReplacementFor_logFormat(
ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_castFromInt(lIndex)));base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_logFormat->ReplacementFor_ReplacementFor_m_format,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kLoggerIdFormatSpecifier,ReplacementFor_ReplacementFor_m_id);return false;});}
namespace base{namespace ReplacementFor_ReplacementFor_utils{base::type::
ReplacementFor_ReplacementFor_fstream_t*File::ReplacementFor_ReplacementFor_newFileStream(const std::string&
ReplacementFor_ReplacementFor_filename){base::type::ReplacementFor_ReplacementFor_fstream_t*fs=new base::type
::ReplacementFor_ReplacementFor_fstream_t(ReplacementFor_ReplacementFor_filename.c_str(),base::type::
ReplacementFor_ReplacementFor_fstream_t::out
#if !defined(ReplacementFor_ReplacementFor_ELPP_FRESH_LOG_FILE)
|base::type::ReplacementFor_ReplacementFor_fstream_t::app
#endif
);
#if defined(ReplacementFor_ReplacementFor_ELPP_UNICODE)
std::locale ReplacementFor_ReplacementFor_elppUnicodeLocale("");
#  if ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS
std::locale ReplacementFor_ReplacementFor_elppUnicodeLocaleWindows(
ReplacementFor_ReplacementFor_elppUnicodeLocale,new std::codecvt_utf8_utf16<wchar_t>);
ReplacementFor_ReplacementFor_elppUnicodeLocale=ReplacementFor_ReplacementFor_elppUnicodeLocaleWindows;
#  endif 
fs->imbue(ReplacementFor_ReplacementFor_elppUnicodeLocale);
#endif  
if(fs->is_open()){fs->flush();}else{base::ReplacementFor_ReplacementFor_utils::
ReplacementFor_ReplacementFor_safeDelete(fs);ReplacementFor_ReplacementFor_ELPP_INTERNAL_ERROR(
"\x42\x61\x64\x20\x66\x69\x6c\x65\x20\x5b"<<ReplacementFor_ReplacementFor_filename<<"\x5d",true
);}return fs;}std::size_t File::ReplacementFor_ReplacementFor_getSizeOfFile(base::type::
ReplacementFor_ReplacementFor_fstream_t*fs){if(fs==nullptr){return(0xebd+167-0xf64);}std::
size_t size=static_cast<std::size_t>(fs->tellg());return size;}bool File::
ReplacementFor_ReplacementFor_pathExists(const char*ReplacementFor_ReplacementFor_path,bool 
ReplacementFor_ReplacementFor_considerFile){if(ReplacementFor_ReplacementFor_path==nullptr){return false;}
#if ReplacementFor_ReplacementFor_ELPP_OS_UNIX
ReplacementFor_ReplacementFor_ELPP_UNUSED(ReplacementFor_ReplacementFor_considerFile);struct stat st;return(
stat(ReplacementFor_ReplacementFor_path,&st)==(0x1288+1775-0x1977));
#elif ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS
DWORD ReplacementFor_ReplacementFor_fileType=GetFileAttributesA(ReplacementFor_ReplacementFor_path);if(
ReplacementFor_ReplacementFor_fileType==INVALID_FILE_ATTRIBUTES){return false;}return 
ReplacementFor_ReplacementFor_considerFile?true:((ReplacementFor_ReplacementFor_fileType&
FILE_ATTRIBUTE_DIRECTORY)==(0x46d+2504-0xe35)?false:true);
#endif  
}bool File::ReplacementFor_ReplacementFor_createPath(const std::string&ReplacementFor_ReplacementFor_path){if(
ReplacementFor_ReplacementFor_path.empty()){return false;}if(base::ReplacementFor_ReplacementFor_utils::File::
ReplacementFor_ReplacementFor_pathExists(ReplacementFor_ReplacementFor_path.c_str())){return true;}int status=
-(0x603+3784-0x14ca);char*ReplacementFor_ReplacementFor_currPath=const_cast<char*>(
ReplacementFor_ReplacementFor_path.c_str());std::string ReplacementFor_ReplacementFor_builtPath=std::string();
#if ReplacementFor_ReplacementFor_ELPP_OS_UNIX
if(ReplacementFor_ReplacementFor_path[(0x1292+576-0x14d2)]==((char)(0x42b+4432-0x154c))){
ReplacementFor_ReplacementFor_builtPath="\x2f";}ReplacementFor_ReplacementFor_currPath=STRTOK(
ReplacementFor_ReplacementFor_currPath,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kFilePathSeperator,(0x6a7+6178-0x1ec9));
#elif ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS
char*ReplacementFor_ReplacementFor_nextTok_=nullptr;ReplacementFor_ReplacementFor_currPath=STRTOK(
ReplacementFor_ReplacementFor_currPath,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kFilePathSeperator,&ReplacementFor_ReplacementFor_nextTok_);
ReplacementFor_ReplacementFor_ELPP_UNUSED(ReplacementFor_ReplacementFor_nextTok_);
#endif  
while(ReplacementFor_ReplacementFor_currPath!=nullptr){ReplacementFor_ReplacementFor_builtPath.append(
ReplacementFor_ReplacementFor_currPath);ReplacementFor_ReplacementFor_builtPath.append(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kFilePathSeperator);
#if ReplacementFor_ReplacementFor_ELPP_OS_UNIX
status=mkdir(ReplacementFor_ReplacementFor_builtPath.c_str(),ReplacementFor_ReplacementFor_ELPP_LOG_PERMS);
ReplacementFor_ReplacementFor_currPath=STRTOK(nullptr,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kFilePathSeperator,(0x2288+760-0x2580));
#elif ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS
status=_mkdir(ReplacementFor_ReplacementFor_builtPath.c_str());ReplacementFor_ReplacementFor_currPath=STRTOK(
nullptr,base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kFilePathSeperator,&
ReplacementFor_ReplacementFor_nextTok_);
#endif  
}if(status==-(0x157d+83-0x15cf)){ReplacementFor_ReplacementFor_ELPP_INTERNAL_ERROR(
"\x45\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x63\x72\x65\x61\x74\x69\x6e\x67\x20\x70\x61\x74\x68\x20\x5b"
<<ReplacementFor_ReplacementFor_path<<"\x5d",true);return false;}return true;}std::string File
::ReplacementFor_ReplacementFor_extractPathFromFilename(const std::string&
ReplacementFor_ReplacementFor_fullPath,const char*ReplacementFor_ReplacementFor_separator){if((
ReplacementFor_ReplacementFor_fullPath=="")||(ReplacementFor_ReplacementFor_fullPath.find(
ReplacementFor_ReplacementFor_separator)==std::string::npos)){return ReplacementFor_ReplacementFor_fullPath;}
std::size_t ReplacementFor_ReplacementFor_lastSlashAt=ReplacementFor_ReplacementFor_fullPath.find_last_of(
ReplacementFor_ReplacementFor_separator);if(ReplacementFor_ReplacementFor_lastSlashAt==(0x19e6+2379-0x2331)){
return std::string(ReplacementFor_ReplacementFor_separator);}return ReplacementFor_ReplacementFor_fullPath.
substr((0x10e3+2423-0x1a5a),ReplacementFor_ReplacementFor_lastSlashAt+(0x8b9+6736-0x2308));}
void File::ReplacementFor_ReplacementFor_buildStrippedFilename(const char*
ReplacementFor_ReplacementFor_filename,char ReplacementFor_ReplacementFor_buff[],std::size_t 
ReplacementFor_ReplacementFor_limit){std::size_t ReplacementFor_ReplacementFor_sizeOfFilename=strlen(
ReplacementFor_ReplacementFor_filename);if(ReplacementFor_ReplacementFor_sizeOfFilename>=ReplacementFor_ReplacementFor_limit)
{ReplacementFor_ReplacementFor_filename+=(ReplacementFor_ReplacementFor_sizeOfFilename-ReplacementFor_ReplacementFor_limit);
if(ReplacementFor_ReplacementFor_filename[(0x1ca3+2467-0x2646)]!=((char)(0x124+2977-0xc97))&&
ReplacementFor_ReplacementFor_filename[(0x33+9310-0x2490)]!=((char)(0xae1+6465-0x23f4))){
ReplacementFor_ReplacementFor_filename+=(0x8df+2532-0x12c0);STRCAT(ReplacementFor_ReplacementFor_buff,
"\x2e\x2e",ReplacementFor_ReplacementFor_limit);}}STRCAT(ReplacementFor_ReplacementFor_buff,
ReplacementFor_ReplacementFor_filename,ReplacementFor_ReplacementFor_limit);}void File::
ReplacementFor_ReplacementFor_buildBaseFilename(const std::string&ReplacementFor_ReplacementFor_fullPath,char 
ReplacementFor_ReplacementFor_buff[],std::size_t ReplacementFor_ReplacementFor_limit,const char*
ReplacementFor_ReplacementFor_separator){const char*ReplacementFor_ReplacementFor_filename=
ReplacementFor_ReplacementFor_fullPath.c_str();std::size_t ReplacementFor_ReplacementFor_lastSlashAt=
ReplacementFor_ReplacementFor_fullPath.find_last_of(ReplacementFor_ReplacementFor_separator);
ReplacementFor_ReplacementFor_filename+=ReplacementFor_ReplacementFor_lastSlashAt?ReplacementFor_ReplacementFor_lastSlashAt+
(0x112f+3112-0x1d56):(0x14f8+2747-0x1fb3);std::size_t 
ReplacementFor_ReplacementFor_sizeOfFilename=strlen(ReplacementFor_ReplacementFor_filename);if(
ReplacementFor_ReplacementFor_sizeOfFilename>=ReplacementFor_ReplacementFor_limit){ReplacementFor_ReplacementFor_filename+=(
ReplacementFor_ReplacementFor_sizeOfFilename-ReplacementFor_ReplacementFor_limit);if(ReplacementFor_ReplacementFor_filename[
(0x892+1949-0x102f)]!=((char)(0x4bd+6128-0x1c7f))&&ReplacementFor_ReplacementFor_filename[
(0xe07+3562-0x1bf0)]!=((char)(0xb5+6541-0x1a14))){ReplacementFor_ReplacementFor_filename+=
(0x17cd+3133-0x2407);STRCAT(ReplacementFor_ReplacementFor_buff,"\x2e\x2e",ReplacementFor_ReplacementFor_limit)
;}}STRCAT(ReplacementFor_ReplacementFor_buff,ReplacementFor_ReplacementFor_filename,ReplacementFor_ReplacementFor_limit);}
bool Str::ReplacementFor_ReplacementFor_wildCardMatch(const char*str,const char*pattern){while(
*pattern){switch(*pattern){case((char)(0x14aa+2196-0x1cff)):if(!*str)return 
false;++str;++pattern;break;case((char)(0xb15+3158-0x1741)):if(
ReplacementFor_ReplacementFor_wildCardMatch(str,pattern+(0x8b9+4380-0x19d4)))return true;if(*
str&&ReplacementFor_ReplacementFor_wildCardMatch(str+(0x22b0+370-0x2421),pattern))return true;
return false;default:if(*str++!=*pattern++)return false;break;}}return!*str&&!*
pattern;}std::string&Str::ReplacementFor_ReplacementFor_ltrim(std::string&str){str.erase(str.
begin(),std::find_if(str.begin(),str.end(),[](char c){return!std::isspace(c);}))
;return str;}std::string&Str::ReplacementFor_ReplacementFor_rtrim(std::string&str){str.erase(
std::find_if(str.rbegin(),str.rend(),[](char c){return!std::isspace(c);}).base()
,str.end());return str;}std::string&Str::ReplacementFor_ReplacementFor_trim(std::string&str){
return ReplacementFor_ReplacementFor_ltrim(ReplacementFor_ReplacementFor_rtrim(str));}bool Str::
ReplacementFor_ReplacementFor_startsWith(const std::string&str,const std::string&
ReplacementFor_ReplacementFor_start){return(str.length()>=ReplacementFor_ReplacementFor_start.length())&&(str.
compare((0x4d0+8457-0x25d9),ReplacementFor_ReplacementFor_start.length(),ReplacementFor_ReplacementFor_start)
==(0x1dc+8286-0x223a));}bool Str::ReplacementFor_ReplacementFor_endsWith(const std::string&str,
const std::string&end){return(str.length()>=end.length())&&(str.compare(str.
length()-end.length(),end.length(),end)==(0x1b0b+1029-0x1f10));}std::string&Str
::ReplacementFor_ReplacementFor_replaceAll(std::string&str,char ReplacementFor_ReplacementFor_replaceWhat,char
 ReplacementFor_ReplacementFor_replaceWith){std::replace(str.begin(),str.end(),
ReplacementFor_ReplacementFor_replaceWhat,ReplacementFor_ReplacementFor_replaceWith);return str;}std::string&
Str::ReplacementFor_ReplacementFor_replaceAll(std::string&str,const std::string&
ReplacementFor_ReplacementFor_replaceWhat,const std::string&ReplacementFor_ReplacementFor_replaceWith){if(
ReplacementFor_ReplacementFor_replaceWhat==ReplacementFor_ReplacementFor_replaceWith)return str;std::size_t 
ReplacementFor_ReplacementFor_foundAt=std::string::npos;while((ReplacementFor_ReplacementFor_foundAt=str.find(
ReplacementFor_ReplacementFor_replaceWhat,ReplacementFor_ReplacementFor_foundAt+(0x923+6990-0x2470)))!=std::
string::npos){str.replace(ReplacementFor_ReplacementFor_foundAt,ReplacementFor_ReplacementFor_replaceWhat.
length(),ReplacementFor_ReplacementFor_replaceWith);}return str;}void Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(base::type::ReplacementFor_ReplacementFor_string_t&str,
const base::type::ReplacementFor_ReplacementFor_string_t&ReplacementFor_ReplacementFor_replaceWhat,const base
::type::ReplacementFor_ReplacementFor_string_t&ReplacementFor_ReplacementFor_replaceWith){std::size_t 
ReplacementFor_ReplacementFor_foundAt=base::type::ReplacementFor_ReplacementFor_string_t::npos;while((
ReplacementFor_ReplacementFor_foundAt=str.find(ReplacementFor_ReplacementFor_replaceWhat,
ReplacementFor_ReplacementFor_foundAt+(0xc15+2001-0x13e5)))!=base::type::
ReplacementFor_ReplacementFor_string_t::npos){if(ReplacementFor_ReplacementFor_foundAt>(0x1241+4126-0x225f)&&
str[ReplacementFor_ReplacementFor_foundAt-(0x847+2994-0x13f8)]==base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kFormatSpecifierChar){str.erase(ReplacementFor_ReplacementFor_foundAt-
(0x23c+3001-0xdf4),(0xd0a+2731-0x17b4));++ReplacementFor_ReplacementFor_foundAt;}else{str.
replace(ReplacementFor_ReplacementFor_foundAt,ReplacementFor_ReplacementFor_replaceWhat.length(),
ReplacementFor_ReplacementFor_replaceWith);return;}}}
#if defined(ReplacementFor_ReplacementFor_ELPP_UNICODE)
void Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(base::type::
ReplacementFor_ReplacementFor_string_t&str,const base::type::ReplacementFor_ReplacementFor_string_t&
ReplacementFor_ReplacementFor_replaceWhat,const std::string&ReplacementFor_ReplacementFor_replaceWith){
ReplacementFor_ReplacementFor_replaceFirstWithEscape(str,ReplacementFor_ReplacementFor_replaceWhat,base::type
::ReplacementFor_ReplacementFor_string_t(ReplacementFor_ReplacementFor_replaceWith.begin(),
ReplacementFor_ReplacementFor_replaceWith.end()));}
#endif  
std::string&Str::toUpper(std::string&str){std::transform(str.begin(),str.end(),
str.begin(),[](char c){return static_cast<char>(::toupper(c));});return str;}
bool Str::ReplacementFor_ReplacementFor_cStringEq(const char*ReplacementFor_ReplacementFor_s1,const char*
ReplacementFor_ReplacementFor_s2){if(ReplacementFor_ReplacementFor_s1==nullptr&&ReplacementFor_ReplacementFor_s2==nullptr)
return true;if(ReplacementFor_ReplacementFor_s1==nullptr||ReplacementFor_ReplacementFor_s2==nullptr)return 
false;return strcmp(ReplacementFor_ReplacementFor_s1,ReplacementFor_ReplacementFor_s2)==(0xb0b+5736-0x2173);}
bool Str::ReplacementFor_ReplacementFor_cStringCaseEq(const char*ReplacementFor_ReplacementFor_s1,const char*
ReplacementFor_ReplacementFor_s2){if(ReplacementFor_ReplacementFor_s1==nullptr&&ReplacementFor_ReplacementFor_s2==nullptr)
return true;if(ReplacementFor_ReplacementFor_s1==nullptr||ReplacementFor_ReplacementFor_s2==nullptr)return 
false;int ReplacementFor_ReplacementFor_d=(0x163d+3454-0x23bb);while(true){const int 
ReplacementFor_ReplacementFor_c1=toupper(*ReplacementFor_ReplacementFor_s1++);const int ReplacementFor_ReplacementFor_c2=
toupper(*ReplacementFor_ReplacementFor_s2++);if(((ReplacementFor_ReplacementFor_d=ReplacementFor_ReplacementFor_c1-
ReplacementFor_ReplacementFor_c2)!=(0x161a+642-0x189c))||(ReplacementFor_ReplacementFor_c2=='\0')){break;}}
return ReplacementFor_ReplacementFor_d==(0x1942+391-0x1ac9);}bool Str::ReplacementFor_ReplacementFor_contains(
const char*str,char c){for(;*str;++str){if(*str==c)return true;}return false;}
char*Str::ReplacementFor_ReplacementFor_convertAndAddToBuff(std::size_t n,int len,char*buf,
const char*ReplacementFor_ReplacementFor_bufLim,bool ReplacementFor_ReplacementFor_zeroPadded){char 
ReplacementFor_ReplacementFor_localBuff[(0x1986+2949-0x2501)]="";char*p=
ReplacementFor_ReplacementFor_localBuff+sizeof(ReplacementFor_ReplacementFor_localBuff)-(0x18e2+2300-0x21dc);
if(n>(0x1c16+55-0x1c4d)){for(;n>(0x8d7+7281-0x2548)&&p>ReplacementFor_ReplacementFor_localBuff
&&len>(0x1745+3285-0x241a);n/=(0x21ec+816-0x2512),--len)*--p=static_cast<char>(n
%(0x9b5+2735-0x145a)+((char)(0xbd7+600-0xdff)));}else{*--p=
((char)(0x1530+4099-0x2503));--len;}if(ReplacementFor_ReplacementFor_zeroPadded)while(p>
ReplacementFor_ReplacementFor_localBuff&&len-- >(0x7af+7251-0x2402))*--p=static_cast<char>(
((char)(0x18c2+1117-0x1cef)));return ReplacementFor_ReplacementFor_addToBuff(p,buf,
ReplacementFor_ReplacementFor_bufLim);}char*Str::ReplacementFor_ReplacementFor_addToBuff(const char*str,char*
buf,const char*ReplacementFor_ReplacementFor_bufLim){while((buf<ReplacementFor_ReplacementFor_bufLim)&&((*buf=
*str++)!='\0'))++buf;return buf;}char*Str::ReplacementFor_ReplacementFor_clearBuff(char 
ReplacementFor_ReplacementFor_buff[],std::size_t ReplacementFor_ReplacementFor_lim){STRCPY(ReplacementFor_ReplacementFor_buff
,"",ReplacementFor_ReplacementFor_lim);ReplacementFor_ReplacementFor_ELPP_UNUSED(ReplacementFor_ReplacementFor_lim);return 
ReplacementFor_ReplacementFor_buff;}char*Str::ReplacementFor_ReplacementFor_wcharPtrToCharPtr(const wchar_t*
line){std::size_t ReplacementFor_ReplacementFor_len_=wcslen(line)+(0xcc6+5422-0x21f3);char*
ReplacementFor_ReplacementFor_buff_=static_cast<char*>(malloc(ReplacementFor_ReplacementFor_len_+
(0x1509+1242-0x19e2)));
#      if ReplacementFor_ReplacementFor_ELPP_OS_UNIX || (ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS && !\
ReplacementFor_ReplacementFor_ELPP_CRT_DBG_WARNINGS)
std::wcstombs(ReplacementFor_ReplacementFor_buff_,line,ReplacementFor_ReplacementFor_len_);
#      elif ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS
std::size_t ReplacementFor_ReplacementFor_convCount_=(0x38b+4580-0x156f);mbstate_t 
ReplacementFor_ReplacementFor_mbState_;::memset(static_cast<void*>(&ReplacementFor_ReplacementFor_mbState_),
(0x820+1612-0xe6c),sizeof(ReplacementFor_ReplacementFor_mbState_));wcsrtombs_s(&
ReplacementFor_ReplacementFor_convCount_,ReplacementFor_ReplacementFor_buff_,ReplacementFor_ReplacementFor_len_,&line,
ReplacementFor_ReplacementFor_len_,&ReplacementFor_ReplacementFor_mbState_);
#      endif  
return ReplacementFor_ReplacementFor_buff_;}
#if ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS
const char*OS::ReplacementFor_ReplacementFor_getWindowsEnvironmentVariable(const char*
ReplacementFor_ReplacementFor_varname){const DWORD ReplacementFor_ReplacementFor_bufferLen=
(0x1276+1703-0x18eb);static char ReplacementFor_ReplacementFor_buffer[ReplacementFor_ReplacementFor_bufferLen]
;if(GetEnvironmentVariableA(ReplacementFor_ReplacementFor_varname,ReplacementFor_ReplacementFor_buffer,
ReplacementFor_ReplacementFor_bufferLen)){return ReplacementFor_ReplacementFor_buffer;}return nullptr;}
#endif  
#if ReplacementFor_ReplacementFor_ELPP_OS_ANDROID
std::string OS::ReplacementFor_ReplacementFor_getProperty(const char*ReplacementFor_ReplacementFor_prop){char 
ReplacementFor_ReplacementFor_propVal[ReplacementFor_ReplacementFor_PROP_VALUE_MAX+(0x989+5015-0x1d1f)];int 
ReplacementFor_ReplacementFor_ret=ReplacementFor_ReplacementFor___system_property_get(ReplacementFor_ReplacementFor_prop,
ReplacementFor_ReplacementFor_propVal);return ReplacementFor_ReplacementFor_ret==(0xe76+3766-0x1d2c)?std::
string():std::string(ReplacementFor_ReplacementFor_propVal);}std::string OS::
ReplacementFor_ReplacementFor_getDeviceName(void){std::stringstream ReplacementFor_ReplacementFor_ss;std::
string ReplacementFor_ReplacementFor_manufacturer=ReplacementFor_ReplacementFor_getProperty(
"\x72\x6f\x2e\x70\x72\x6f\x64\x75\x63\x74\x2e\x6d\x61\x6e\x75\x66\x61\x63\x74\x75\x72\x65\x72"
);std::string ReplacementFor_ReplacementFor_model=ReplacementFor_ReplacementFor_getProperty(
"\x72\x6f\x2e\x70\x72\x6f\x64\x75\x63\x74\x2e\x6d\x6f\x64\x65\x6c");if(
ReplacementFor_ReplacementFor_manufacturer.empty()||ReplacementFor_ReplacementFor_model.empty()){return std::
string();}ReplacementFor_ReplacementFor_ss<<ReplacementFor_ReplacementFor_manufacturer<<"\x2d"<<
ReplacementFor_ReplacementFor_model;return ReplacementFor_ReplacementFor_ss.str();}
#endif  
const std::string OS::ReplacementFor_ReplacementFor_getBashOutput(const char*
ReplacementFor_ReplacementFor_command){
#if (ReplacementFor_ReplacementFor_ELPP_OS_UNIX && !ReplacementFor_ReplacementFor_ELPP_OS_ANDROID && !\
ReplacementFor_ReplacementFor_ELPP_CYGWIN)
if(ReplacementFor_ReplacementFor_command==nullptr){return std::string();}FILE*
ReplacementFor_ReplacementFor_proc=nullptr;if((ReplacementFor_ReplacementFor_proc=popen(ReplacementFor_ReplacementFor_command
,"\x72"))==nullptr){ReplacementFor_ReplacementFor_ELPP_INTERNAL_ERROR(
"\n" "\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x72\x75\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x5b"
<<ReplacementFor_ReplacementFor_command<<"\x5d",true);return std::string();}char 
ReplacementFor_ReplacementFor_hBuff[(0x2196+1333-0x16cb)];if(fgets(ReplacementFor_ReplacementFor_hBuff,sizeof(
ReplacementFor_ReplacementFor_hBuff),ReplacementFor_ReplacementFor_proc)!=nullptr){pclose(ReplacementFor_ReplacementFor_proc)
;const std::size_t ReplacementFor_ReplacementFor_buffLen=strlen(ReplacementFor_ReplacementFor_hBuff);if(
ReplacementFor_ReplacementFor_buffLen>(0xee8+3408-0x1c38)&&ReplacementFor_ReplacementFor_hBuff[
ReplacementFor_ReplacementFor_buffLen-(0x175d+49-0x178d)]=='\n'){ReplacementFor_ReplacementFor_hBuff[
ReplacementFor_ReplacementFor_buffLen-(0x1057+1864-0x179e)]='\0';}return std::string(
ReplacementFor_ReplacementFor_hBuff);}else{pclose(ReplacementFor_ReplacementFor_proc);}return std::string();
#else
ReplacementFor_ReplacementFor_ELPP_UNUSED(ReplacementFor_ReplacementFor_command);return std::string();
#endif
}std::string OS::ReplacementFor_ReplacementFor_getEnvironmentVariable(const char*
ReplacementFor_ReplacementFor_variableName,const char*ReplacementFor_ReplacementFor_defaultVal,const char*
ReplacementFor_ReplacementFor_alternativeBashCommand){
#if ReplacementFor_ReplacementFor_ELPP_OS_UNIX
const char*val=getenv(ReplacementFor_ReplacementFor_variableName);
#elif ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS
const char*val=ReplacementFor_ReplacementFor_getWindowsEnvironmentVariable(
ReplacementFor_ReplacementFor_variableName);
#endif  
if((val==nullptr)||((strcmp(val,"")==(0xaf9+3680-0x1959)))){
#if ReplacementFor_ReplacementFor_ELPP_OS_UNIX && defined(\
ReplacementFor_ReplacementFor_ELPP_FORCE_ENV_VAR_FROM_BASH)
std::string ReplacementFor_ReplacementFor_valBash=base::ReplacementFor_ReplacementFor_utils::OS::
ReplacementFor_ReplacementFor_getBashOutput(ReplacementFor_ReplacementFor_alternativeBashCommand);if(
ReplacementFor_ReplacementFor_valBash.empty()){return std::string(ReplacementFor_ReplacementFor_defaultVal);}
else{return ReplacementFor_ReplacementFor_valBash;}
#elif ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS || ReplacementFor_ReplacementFor_ELPP_OS_UNIX
ReplacementFor_ReplacementFor_ELPP_UNUSED(ReplacementFor_ReplacementFor_alternativeBashCommand);return std::
string(ReplacementFor_ReplacementFor_defaultVal);
#endif  
}return std::string(val);}std::string OS::ReplacementFor_ReplacementFor_currentUser(void){
#if ReplacementFor_ReplacementFor_ELPP_OS_UNIX && !ReplacementFor_ReplacementFor_ELPP_OS_ANDROID
return ReplacementFor_ReplacementFor_getEnvironmentVariable("\x55\x53\x45\x52",base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kUnknownUser,"\x77\x68\x6f\x61\x6d\x69");
#elif ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS
return ReplacementFor_ReplacementFor_getEnvironmentVariable("\x55\x53\x45\x52\x4e\x41\x4d\x45",
base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kUnknownUser);
#elif ReplacementFor_ReplacementFor_ELPP_OS_ANDROID
ReplacementFor_ReplacementFor_ELPP_UNUSED(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kUnknownUser);return std::string("\x61\x6e\x64\x72\x6f\x69\x64");
#else
return std::string();
#endif  
}std::string OS::ReplacementFor_ReplacementFor_currentHost(void){
#if ReplacementFor_ReplacementFor_ELPP_OS_UNIX && !ReplacementFor_ReplacementFor_ELPP_OS_ANDROID
return ReplacementFor_ReplacementFor_getEnvironmentVariable("\x48\x4f\x53\x54\x4e\x41\x4d\x45",
base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kUnknownHost,
"\x68\x6f\x73\x74\x6e\x61\x6d\x65");
#elif ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS
return ReplacementFor_ReplacementFor_getEnvironmentVariable(
"\x43\x4f\x4d\x50\x55\x54\x45\x52\x4e\x41\x4d\x45",base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kUnknownHost);
#elif ReplacementFor_ReplacementFor_ELPP_OS_ANDROID
ReplacementFor_ReplacementFor_ELPP_UNUSED(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kUnknownHost);return ReplacementFor_ReplacementFor_getDeviceName();
#else
return std::string();
#endif  
}bool OS::ReplacementFor_ReplacementFor_termSupportsColor(void){std::string ReplacementFor_ReplacementFor_term
=ReplacementFor_ReplacementFor_getEnvironmentVariable("\x54\x45\x52\x4d","");return 
ReplacementFor_ReplacementFor_term=="\x78\x74\x65\x72\x6d"||ReplacementFor_ReplacementFor_term==
"\x78\x74\x65\x72\x6d\x2d\x63\x6f\x6c\x6f\x72"||ReplacementFor_ReplacementFor_term==
"\x78\x74\x65\x72\x6d\x2d\x32\x35\x36\x63\x6f\x6c\x6f\x72"||ReplacementFor_ReplacementFor_term
=="\x73\x63\x72\x65\x65\x6e"||ReplacementFor_ReplacementFor_term=="\x6c\x69\x6e\x75\x78"||
ReplacementFor_ReplacementFor_term=="\x63\x79\x67\x77\x69\x6e"||ReplacementFor_ReplacementFor_term==
"\x73\x63\x72\x65\x65\x6e\x2d\x32\x35\x36\x63\x6f\x6c\x6f\x72";}void 
ReplacementFor_ReplacementFor_DateTime::gettimeofday(struct timeval*ReplacementFor_ReplacementFor_tv){
#if ReplacementFor_ReplacementFor_ELPP_OS_WINDOWS
if(ReplacementFor_ReplacementFor_tv!=nullptr){
#  if ReplacementFor_ReplacementFor_ELPP_COMPILER_MSVC || defined(\
ReplacementFor_ReplacementFor__MSC_EXTENSIONS)
const unsigned __int64 ReplacementFor_ReplacementFor_delta_=11644473600000000Ui64;
#  else
const unsigned __int64 ReplacementFor_ReplacementFor_delta_=11644473600000000ULL;
#  endif  
const double ReplacementFor_ReplacementFor_secOffSet=0.000001;const unsigned long 
ReplacementFor_ReplacementFor_usecOffSet=1000000;FILETIME fileTime;GetSystemTimeAsFileTime(&
fileTime);unsigned __int64 ReplacementFor_ReplacementFor_present=(0x79+8341-0x210e);
ReplacementFor_ReplacementFor_present|=fileTime.dwHighDateTime;ReplacementFor_ReplacementFor_present=
ReplacementFor_ReplacementFor_present<<(0x953+2637-0x1380);ReplacementFor_ReplacementFor_present|=fileTime.
dwLowDateTime;ReplacementFor_ReplacementFor_present/=(0x1733+266-0x1833);ReplacementFor_ReplacementFor_present
-=ReplacementFor_ReplacementFor_delta_;ReplacementFor_ReplacementFor_tv->tv_sec=static_cast<long>(
ReplacementFor_ReplacementFor_present*ReplacementFor_ReplacementFor_secOffSet);ReplacementFor_ReplacementFor_tv->tv_usec=
static_cast<long>(ReplacementFor_ReplacementFor_present%ReplacementFor_ReplacementFor_usecOffSet);}
#else
::gettimeofday(ReplacementFor_ReplacementFor_tv,nullptr);
#endif  
}std::string ReplacementFor_ReplacementFor_DateTime::ReplacementFor_ReplacementFor_getDateTime(const char*
format,const base::ReplacementFor_ReplacementFor_SubsecondPrecision*ReplacementFor_ReplacementFor_ssPrec){
struct timeval ReplacementFor_ReplacementFor_currTime;gettimeofday(&ReplacementFor_ReplacementFor_currTime);
return ReplacementFor_ReplacementFor_timevalToString(ReplacementFor_ReplacementFor_currTime,format,
ReplacementFor_ReplacementFor_ssPrec);}std::string ReplacementFor_ReplacementFor_DateTime::
ReplacementFor_ReplacementFor_timevalToString(struct timeval ReplacementFor_ReplacementFor_tval,const char*
format,const ReplacementFor_ReplacementFor_el::base::ReplacementFor_ReplacementFor_SubsecondPrecision*
ReplacementFor_ReplacementFor_ssPrec){struct::tm ReplacementFor_ReplacementFor_timeInfo;
ReplacementFor_ReplacementFor_buildTimeInfo(&ReplacementFor_ReplacementFor_tval,&ReplacementFor_ReplacementFor_timeInfo);
const int ReplacementFor_ReplacementFor_kBuffSize=(0x915+7621-0x26bc);char ReplacementFor_ReplacementFor_buff_
[ReplacementFor_ReplacementFor_kBuffSize]="";ReplacementFor_ReplacementFor_parseFormat(ReplacementFor_ReplacementFor_buff_,
ReplacementFor_ReplacementFor_kBuffSize,format,&ReplacementFor_ReplacementFor_timeInfo,static_cast<std::size_t
>(ReplacementFor_ReplacementFor_tval.tv_usec/ReplacementFor_ReplacementFor_ssPrec->ReplacementFor_ReplacementFor_m_offset),
ReplacementFor_ReplacementFor_ssPrec);return std::string(ReplacementFor_ReplacementFor_buff_);}base::type::
ReplacementFor_ReplacementFor_string_t ReplacementFor_ReplacementFor_DateTime::formatTime(unsigned long long 
time,base::ReplacementFor_ReplacementFor_TimestampUnit ReplacementFor_ReplacementFor_timestampUnit){base::type
::ReplacementFor_ReplacementFor_EnumType ReplacementFor_ReplacementFor_start=static_cast<base::type::
ReplacementFor_ReplacementFor_EnumType>(ReplacementFor_ReplacementFor_timestampUnit);const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_unit=base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kTimeFormats[ReplacementFor_ReplacementFor_start].ReplacementFor_ReplacementFor_unit;for(base::
type::ReplacementFor_ReplacementFor_EnumType i=ReplacementFor_ReplacementFor_start;i<base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kTimeFormatsCount-(0x115a+3803-0x2034);++i
){if(time<=base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kTimeFormats[i].value){
break;}if(base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kTimeFormats[i].value==
1000.0f&&time/1000.0f<1.9f){break;}time/=static_cast<decltype(time)>(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kTimeFormats[i].value);ReplacementFor_ReplacementFor_unit
=base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kTimeFormats[i+(0x432+4713-0x169a)]
.ReplacementFor_ReplacementFor_unit;}base::type::ReplacementFor_ReplacementFor_stringstream_t 
ReplacementFor_ReplacementFor_ss;ReplacementFor_ReplacementFor_ss<<time<<"\x20"<<ReplacementFor_ReplacementFor_unit;return 
ReplacementFor_ReplacementFor_ss.str();}unsigned long long ReplacementFor_ReplacementFor_DateTime::
ReplacementFor_ReplacementFor_getTimeDifference(const struct timeval&ReplacementFor_ReplacementFor_endTime,
const struct timeval&ReplacementFor_ReplacementFor_startTime,base::ReplacementFor_ReplacementFor_TimestampUnit
 ReplacementFor_ReplacementFor_timestampUnit){if(ReplacementFor_ReplacementFor_timestampUnit==base::
ReplacementFor_ReplacementFor_TimestampUnit::ReplacementFor_ReplacementFor_Microsecond){return static_cast<
unsigned long long>(static_cast<unsigned long long>(1000000*
ReplacementFor_ReplacementFor_endTime.tv_sec+ReplacementFor_ReplacementFor_endTime.tv_usec)-static_cast<
unsigned long long>(1000000*ReplacementFor_ReplacementFor_startTime.tv_sec+
ReplacementFor_ReplacementFor_startTime.tv_usec));}auto ReplacementFor_ReplacementFor_conv=[](const struct 
timeval&ReplacementFor_ReplacementFor_tim){return static_cast<unsigned long long>((
ReplacementFor_ReplacementFor_tim.tv_sec*(0xc43+2115-0x109e))+(ReplacementFor_ReplacementFor_tim.tv_usec/
(0x78d+7330-0x2047)));};return static_cast<unsigned long long>(
ReplacementFor_ReplacementFor_conv(ReplacementFor_ReplacementFor_endTime)-ReplacementFor_ReplacementFor_conv(
ReplacementFor_ReplacementFor_startTime));}struct::tm*ReplacementFor_ReplacementFor_DateTime::
ReplacementFor_ReplacementFor_buildTimeInfo(struct timeval*ReplacementFor_ReplacementFor_currTime,struct::tm*
ReplacementFor_ReplacementFor_timeInfo){
#if ReplacementFor_ReplacementFor_ELPP_OS_UNIX
time_t ReplacementFor_ReplacementFor_rawTime=ReplacementFor_ReplacementFor_currTime->tv_sec;::
ReplacementFor_ReplacementFor_elpptime_r(&ReplacementFor_ReplacementFor_rawTime,ReplacementFor_ReplacementFor_timeInfo);
return ReplacementFor_ReplacementFor_timeInfo;
#else
#  if ReplacementFor_ReplacementFor_ELPP_COMPILER_MSVC
ReplacementFor_ReplacementFor_ELPP_UNUSED(ReplacementFor_ReplacementFor_currTime);time_t t;
#    if defined(_USE_32BIT_TIME_T)
_time32(&t);
#    else
_time64(&t);
#    endif
ReplacementFor_ReplacementFor_elpptime_s(ReplacementFor_ReplacementFor_timeInfo,&t);return 
ReplacementFor_ReplacementFor_timeInfo;
#  else
time_t ReplacementFor_ReplacementFor_rawTime=ReplacementFor_ReplacementFor_currTime->tv_sec;struct tm*
ReplacementFor_ReplacementFor_tmInf=ReplacementFor_ReplacementFor_elpptime(&ReplacementFor_ReplacementFor_rawTime);*
ReplacementFor_ReplacementFor_timeInfo=*ReplacementFor_ReplacementFor_tmInf;return ReplacementFor_ReplacementFor_timeInfo;
#  endif  
#endif  
}char*ReplacementFor_ReplacementFor_DateTime::ReplacementFor_ReplacementFor_parseFormat(char*buf,std::size_t 
ReplacementFor_ReplacementFor_bufSz,const char*format,const struct tm*ReplacementFor_ReplacementFor_tInfo,std
::size_t ReplacementFor_ReplacementFor_msec,const base::ReplacementFor_ReplacementFor_SubsecondPrecision*
ReplacementFor_ReplacementFor_ssPrec){const char*ReplacementFor_ReplacementFor_bufLim=buf+ReplacementFor_ReplacementFor_bufSz
;for(;*format;++format){if(*format==base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kFormatSpecifierChar){switch(*++format){case base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kFormatSpecifierChar:break;case'\0':--
format;break;case((char)(0x290+6009-0x19a5)):buf=base::ReplacementFor_ReplacementFor_utils::Str
::ReplacementFor_ReplacementFor_convertAndAddToBuff(ReplacementFor_ReplacementFor_tInfo->tm_mday,
(0x1572+797-0x188d),buf,ReplacementFor_ReplacementFor_bufLim);continue;case
((char)(0x55b+1924-0xc7e)):buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_addToBuff(base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDaysAbbrev
[ReplacementFor_ReplacementFor_tInfo->tm_wday],buf,ReplacementFor_ReplacementFor_bufLim);continue;case
((char)(0x912+5854-0x1faf)):buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_addToBuff(base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDays[
ReplacementFor_ReplacementFor_tInfo->tm_wday],buf,ReplacementFor_ReplacementFor_bufLim);continue;case
((char)(0x826+7923-0x26cc)):buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_convertAndAddToBuff(ReplacementFor_ReplacementFor_tInfo->tm_mon+
(0x13b+2387-0xa8d),(0x7bb+6780-0x2235),buf,ReplacementFor_ReplacementFor_bufLim);continue;case
((char)(0x1e57+157-0x1e92)):buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_addToBuff(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kMonthsAbbrev[ReplacementFor_ReplacementFor_tInfo->tm_mon],buf,
ReplacementFor_ReplacementFor_bufLim);continue;case((char)(0x1151+1764-0x17f3)):buf=base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_addToBuff(base::ReplacementFor_ReplacementFor_consts
::ReplacementFor_ReplacementFor_kMonths[ReplacementFor_ReplacementFor_tInfo->tm_mon],buf,ReplacementFor_ReplacementFor_bufLim
);continue;case((char)(0x470+4326-0x14dd)):buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_convertAndAddToBuff(ReplacementFor_ReplacementFor_tInfo->tm_year+base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kYearBase,(0x162+9201-0x2551),buf,
ReplacementFor_ReplacementFor_bufLim);continue;case((char)(0x841+5582-0x1db6)):buf=base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_convertAndAddToBuff(
ReplacementFor_ReplacementFor_tInfo->tm_year+base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kYearBase,(0x24d6+403-0x2665),buf,ReplacementFor_ReplacementFor_bufLim);continue
;case((char)(0x1698+2357-0x1f65)):buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_convertAndAddToBuff(ReplacementFor_ReplacementFor_tInfo->tm_hour%
(0x129+4695-0x1374),(0x943+4677-0x1b86),buf,ReplacementFor_ReplacementFor_bufLim);continue;case
((char)(0x657+5357-0x1afc)):buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_convertAndAddToBuff(ReplacementFor_ReplacementFor_tInfo->tm_hour,
(0xbcc+5486-0x2138),buf,ReplacementFor_ReplacementFor_bufLim);continue;case
((char)(0x1126+4006-0x205f)):buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_convertAndAddToBuff(ReplacementFor_ReplacementFor_tInfo->tm_min,
(0x4ff+5818-0x1bb7),buf,ReplacementFor_ReplacementFor_bufLim);continue;case
((char)(0x3ab+3643-0x1173)):buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_convertAndAddToBuff(ReplacementFor_ReplacementFor_tInfo->tm_sec,
(0x127c+4198-0x22e0),buf,ReplacementFor_ReplacementFor_bufLim);continue;case
((char)(0x4d8+7550-0x21dc)):case((char)(0x4ac+2770-0xf17)):buf=base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_convertAndAddToBuff(
ReplacementFor_ReplacementFor_msec,ReplacementFor_ReplacementFor_ssPrec->ReplacementFor_ReplacementFor_m_width,buf,
ReplacementFor_ReplacementFor_bufLim);continue;case((char)(0x1ed6+653-0x211d)):buf=base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_addToBuff((ReplacementFor_ReplacementFor_tInfo->
tm_hour>=(0xf8b+5346-0x2461))?base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kPm:
base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kAm,buf,ReplacementFor_ReplacementFor_bufLim);
continue;default:continue;}}if(buf==ReplacementFor_ReplacementFor_bufLim)break;*buf++=*format;}
return buf;}void ReplacementFor_ReplacementFor_CommandLineArgs::ReplacementFor_ReplacementFor_setArgs(int 
ReplacementFor_ReplacementFor_argc,char**ReplacementFor_ReplacementFor_argv){ReplacementFor_ReplacementFor_m_params.clear();
ReplacementFor_ReplacementFor_m_paramsWithValue.clear();if(ReplacementFor_ReplacementFor_argc==
(0x119d+4258-0x223f)||ReplacementFor_ReplacementFor_argv==nullptr){return;}
ReplacementFor_ReplacementFor_m_argc=ReplacementFor_ReplacementFor_argc;ReplacementFor_ReplacementFor_m_argv=
ReplacementFor_ReplacementFor_argv;for(int i=(0xb6c+2249-0x1434);i<ReplacementFor_ReplacementFor_m_argc;++i){
const char*ReplacementFor_ReplacementFor_v=(strstr(ReplacementFor_ReplacementFor_m_argv[i],"\x3d"));if(
ReplacementFor_ReplacementFor_v!=nullptr&&strlen(ReplacementFor_ReplacementFor_v)>(0x100+6813-0x1b9d)){std::
string key=std::string(ReplacementFor_ReplacementFor_m_argv[i]);key=key.substr(
(0xdb5+5086-0x2193),key.find_first_of(((char)(0x614+8462-0x26e5))));if(
ReplacementFor_ReplacementFor_hasParamWithValue(key.c_str())){ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO
((0x694+6876-0x216f),"\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x5b"<<key<<
"\x5d\x20\x5b"<<ReplacementFor_ReplacementFor_getParamValue(key.c_str())<<"\x5d");}else{
ReplacementFor_ReplacementFor_m_paramsWithValue.insert(std::make_pair(key,std::string(
ReplacementFor_ReplacementFor_v+(0x11eb+1725-0x18a7))));}}if(ReplacementFor_ReplacementFor_v==nullptr){if(
ReplacementFor_ReplacementFor_hasParam(ReplacementFor_ReplacementFor_m_argv[i])){
ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0x575+4413-0x16b1),
"\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x5b"<<ReplacementFor_ReplacementFor_m_argv[i]<<"\x5d");}
else{ReplacementFor_ReplacementFor_m_params.push_back(std::string(ReplacementFor_ReplacementFor_m_argv[i]));}}
}}bool ReplacementFor_ReplacementFor_CommandLineArgs::ReplacementFor_ReplacementFor_hasParamWithValue(const 
char*ReplacementFor_ReplacementFor_paramKey)const{return ReplacementFor_ReplacementFor_m_paramsWithValue.find(
std::string(ReplacementFor_ReplacementFor_paramKey))!=ReplacementFor_ReplacementFor_m_paramsWithValue.end();}
const char*ReplacementFor_ReplacementFor_CommandLineArgs::ReplacementFor_ReplacementFor_getParamValue(const 
char*ReplacementFor_ReplacementFor_paramKey)const{std::unordered_map<std::string,std::string>::
const_iterator iter=ReplacementFor_ReplacementFor_m_paramsWithValue.find(std::string(
ReplacementFor_ReplacementFor_paramKey));return iter!=ReplacementFor_ReplacementFor_m_paramsWithValue.end()?
iter->second.c_str():"";}bool ReplacementFor_ReplacementFor_CommandLineArgs::
ReplacementFor_ReplacementFor_hasParam(const char*ReplacementFor_ReplacementFor_paramKey)const{return std::
find(ReplacementFor_ReplacementFor_m_params.begin(),ReplacementFor_ReplacementFor_m_params.end(),std::string(
ReplacementFor_ReplacementFor_paramKey))!=ReplacementFor_ReplacementFor_m_params.end();}bool 
ReplacementFor_ReplacementFor_CommandLineArgs::empty(void)const{return ReplacementFor_ReplacementFor_m_params.
empty()&&ReplacementFor_ReplacementFor_m_paramsWithValue.empty();}std::size_t 
ReplacementFor_ReplacementFor_CommandLineArgs::size(void)const{return ReplacementFor_ReplacementFor_m_params.
size()+ReplacementFor_ReplacementFor_m_paramsWithValue.size();}base::type::
ReplacementFor_ReplacementFor_ostream_t&operator<<(base::type::ReplacementFor_ReplacementFor_ostream_t&os,
const ReplacementFor_ReplacementFor_CommandLineArgs&c){for(int i=(0x1889+3399-0x25cf);i<c.
ReplacementFor_ReplacementFor_m_argc;++i){os<<ReplacementFor_ReplacementFor_ELPP_LITERAL("\x5b")<<c.
ReplacementFor_ReplacementFor_m_argv[i]<<ReplacementFor_ReplacementFor_ELPP_LITERAL("\x5d");if(i<c.
ReplacementFor_ReplacementFor_m_argc-(0x215+6856-0x1cdc)){os<<ReplacementFor_ReplacementFor_ELPP_LITERAL(
"\x20");}}return os;}}namespace ReplacementFor_ReplacementFor_threading{
#if ReplacementFor_ReplacementFor_ELPP_THREADING_ENABLED
#  if ReplacementFor_ReplacementFor_ELPP_USE_STD_THREADING
#      if ReplacementFor_ReplacementFor_ELPP_ASYNC_LOGGING
static void ReplacementFor_ReplacementFor_msleep(int ms){
#         if defined(ReplacementFor_ReplacementFor_ELPP_NO_SLEEP_FOR)
usleep(ms*(0xc05+7037-0x239a));
#         else
std::this_thread::sleep_for(std::chrono::milliseconds(ms));
#         endif  
}
#      endif  
#  endif  
#endif  
}void ReplacementFor_ReplacementFor_SubsecondPrecision::init(int width){if(width<
(0x5e4+2299-0xede)||width>(0x20a+9312-0x2664)){width=base::ReplacementFor_ReplacementFor_consts
::ReplacementFor_ReplacementFor_kDefaultSubsecondPrecision;}ReplacementFor_ReplacementFor_m_width=width;switch
(ReplacementFor_ReplacementFor_m_width){case(0x2684+50-0x26b3):ReplacementFor_ReplacementFor_m_offset=
(0x1fbb+367-0x1d42);break;case(0xb15+562-0xd43):ReplacementFor_ReplacementFor_m_offset=
(0xdea+5159-0x21ad);break;case(0xd5f+1945-0x14f3):ReplacementFor_ReplacementFor_m_offset=
(0x1203+4835-0x24dc);break;case(0x5dd+3985-0x1568):ReplacementFor_ReplacementFor_m_offset=
(0x1611+557-0x183d);break;default:ReplacementFor_ReplacementFor_m_offset=(0xc9f+5602-0x1e99);
break;}}ReplacementFor_ReplacementFor_LogFormat::ReplacementFor_ReplacementFor_LogFormat(void):
ReplacementFor_ReplacementFor_m_level(Level::Unknown),ReplacementFor_ReplacementFor_m_userFormat(base::type::
ReplacementFor_ReplacementFor_string_t()),ReplacementFor_ReplacementFor_m_format(base::type::
ReplacementFor_ReplacementFor_string_t()),ReplacementFor_ReplacementFor_m_dateTimeFormat(std::string()),
ReplacementFor_ReplacementFor_m_flags((0x1dc7+2195-0x265a)),ReplacementFor_ReplacementFor_m_currentUser(base::
ReplacementFor_ReplacementFor_utils::OS::ReplacementFor_ReplacementFor_currentUser()),
ReplacementFor_ReplacementFor_m_currentHost(base::ReplacementFor_ReplacementFor_utils::OS::
ReplacementFor_ReplacementFor_currentHost()){}ReplacementFor_ReplacementFor_LogFormat::
ReplacementFor_ReplacementFor_LogFormat(Level ReplacementFor_ReplacementFor_level,const base::type::
ReplacementFor_ReplacementFor_string_t&format):ReplacementFor_ReplacementFor_m_level(ReplacementFor_ReplacementFor_level),
ReplacementFor_ReplacementFor_m_userFormat(format),ReplacementFor_ReplacementFor_m_currentUser(base::
ReplacementFor_ReplacementFor_utils::OS::ReplacementFor_ReplacementFor_currentUser()),
ReplacementFor_ReplacementFor_m_currentHost(base::ReplacementFor_ReplacementFor_utils::OS::
ReplacementFor_ReplacementFor_currentHost()){ReplacementFor_ReplacementFor_parseFromFormat(
ReplacementFor_ReplacementFor_m_userFormat);}ReplacementFor_ReplacementFor_LogFormat::ReplacementFor_ReplacementFor_LogFormat
(const ReplacementFor_ReplacementFor_LogFormat&ReplacementFor_ReplacementFor_logFormat):ReplacementFor_ReplacementFor_m_level
(ReplacementFor_ReplacementFor_logFormat.ReplacementFor_ReplacementFor_m_level),ReplacementFor_ReplacementFor_m_userFormat(
ReplacementFor_ReplacementFor_logFormat.ReplacementFor_ReplacementFor_m_userFormat),ReplacementFor_ReplacementFor_m_format(
ReplacementFor_ReplacementFor_logFormat.ReplacementFor_ReplacementFor_m_format),
ReplacementFor_ReplacementFor_m_dateTimeFormat(ReplacementFor_ReplacementFor_logFormat.
ReplacementFor_ReplacementFor_m_dateTimeFormat),ReplacementFor_ReplacementFor_m_flags(ReplacementFor_ReplacementFor_logFormat
.ReplacementFor_ReplacementFor_m_flags),ReplacementFor_ReplacementFor_m_currentUser(ReplacementFor_ReplacementFor_logFormat.
ReplacementFor_ReplacementFor_m_currentUser),ReplacementFor_ReplacementFor_m_currentHost(
ReplacementFor_ReplacementFor_logFormat.ReplacementFor_ReplacementFor_m_currentHost){}ReplacementFor_ReplacementFor_LogFormat
::ReplacementFor_ReplacementFor_LogFormat(ReplacementFor_ReplacementFor_LogFormat&&ReplacementFor_ReplacementFor_logFormat){
ReplacementFor_ReplacementFor_m_level=std::move(ReplacementFor_ReplacementFor_logFormat.ReplacementFor_ReplacementFor_m_level
);ReplacementFor_ReplacementFor_m_userFormat=std::move(ReplacementFor_ReplacementFor_logFormat.
ReplacementFor_ReplacementFor_m_userFormat);ReplacementFor_ReplacementFor_m_format=std::move(
ReplacementFor_ReplacementFor_logFormat.ReplacementFor_ReplacementFor_m_format);
ReplacementFor_ReplacementFor_m_dateTimeFormat=std::move(ReplacementFor_ReplacementFor_logFormat.
ReplacementFor_ReplacementFor_m_dateTimeFormat);ReplacementFor_ReplacementFor_m_flags=std::move(
ReplacementFor_ReplacementFor_logFormat.ReplacementFor_ReplacementFor_m_flags);ReplacementFor_ReplacementFor_m_currentUser=
std::move(ReplacementFor_ReplacementFor_logFormat.ReplacementFor_ReplacementFor_m_currentUser);
ReplacementFor_ReplacementFor_m_currentHost=std::move(ReplacementFor_ReplacementFor_logFormat.
ReplacementFor_ReplacementFor_m_currentHost);}ReplacementFor_ReplacementFor_LogFormat&ReplacementFor_ReplacementFor_LogFormat
::operator=(const ReplacementFor_ReplacementFor_LogFormat&ReplacementFor_ReplacementFor_logFormat){if(&
ReplacementFor_ReplacementFor_logFormat!=this){ReplacementFor_ReplacementFor_m_level=ReplacementFor_ReplacementFor_logFormat.
ReplacementFor_ReplacementFor_m_level;ReplacementFor_ReplacementFor_m_userFormat=ReplacementFor_ReplacementFor_logFormat.
ReplacementFor_ReplacementFor_m_userFormat;ReplacementFor_ReplacementFor_m_dateTimeFormat=
ReplacementFor_ReplacementFor_logFormat.ReplacementFor_ReplacementFor_m_dateTimeFormat;ReplacementFor_ReplacementFor_m_flags=
ReplacementFor_ReplacementFor_logFormat.ReplacementFor_ReplacementFor_m_flags;ReplacementFor_ReplacementFor_m_currentUser=
ReplacementFor_ReplacementFor_logFormat.ReplacementFor_ReplacementFor_m_currentUser;
ReplacementFor_ReplacementFor_m_currentHost=ReplacementFor_ReplacementFor_logFormat.
ReplacementFor_ReplacementFor_m_currentHost;}return*this;}bool ReplacementFor_ReplacementFor_LogFormat::
operator==(const ReplacementFor_ReplacementFor_LogFormat&other){return ReplacementFor_ReplacementFor_m_level==
other.ReplacementFor_ReplacementFor_m_level&&ReplacementFor_ReplacementFor_m_userFormat==other.
ReplacementFor_ReplacementFor_m_userFormat&&ReplacementFor_ReplacementFor_m_format==other.
ReplacementFor_ReplacementFor_m_format&&ReplacementFor_ReplacementFor_m_dateTimeFormat==other.
ReplacementFor_ReplacementFor_m_dateTimeFormat&&ReplacementFor_ReplacementFor_m_flags==other.
ReplacementFor_ReplacementFor_m_flags;}void ReplacementFor_ReplacementFor_LogFormat::
ReplacementFor_ReplacementFor_parseFromFormat(const base::type::ReplacementFor_ReplacementFor_string_t&
ReplacementFor_ReplacementFor_userFormat){base::type::ReplacementFor_ReplacementFor_string_t 
ReplacementFor_ReplacementFor_formatCopy=ReplacementFor_ReplacementFor_userFormat;ReplacementFor_ReplacementFor_m_flags=
(0x161+4832-0x1441);auto ReplacementFor_ReplacementFor_conditionalAddFlag=[&](const base::type
::ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_specifier,base::
ReplacementFor_ReplacementFor_FormatFlags flag){std::size_t ReplacementFor_ReplacementFor_foundAt=base::type::
ReplacementFor_ReplacementFor_string_t::npos;while((ReplacementFor_ReplacementFor_foundAt=
ReplacementFor_ReplacementFor_formatCopy.find(ReplacementFor_ReplacementFor_specifier,ReplacementFor_ReplacementFor_foundAt+
(0x1245+1666-0x18c6)))!=base::type::ReplacementFor_ReplacementFor_string_t::npos){if(
ReplacementFor_ReplacementFor_foundAt>(0x50+9626-0x25ea)&&ReplacementFor_ReplacementFor_formatCopy[
ReplacementFor_ReplacementFor_foundAt-(0x87d+1983-0x103b)]==base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kFormatSpecifierChar){if(ReplacementFor_ReplacementFor_hasFlag(flag)){
ReplacementFor_ReplacementFor_formatCopy.erase(ReplacementFor_ReplacementFor_foundAt-(0xe3b+1189-0x12df),
(0x1834+2966-0x23c9));++ReplacementFor_ReplacementFor_foundAt;}}else{if(!ReplacementFor_ReplacementFor_hasFlag
(flag))ReplacementFor_ReplacementFor_addFlag(flag);}}};ReplacementFor_ReplacementFor_conditionalAddFlag(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kAppNameFormatSpecifier,base::
ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_AppName);
ReplacementFor_ReplacementFor_conditionalAddFlag(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSeverityLevelFormatSpecifier,base::ReplacementFor_ReplacementFor_FormatFlags::
Level);ReplacementFor_ReplacementFor_conditionalAddFlag(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSeverityLevelShortFormatSpecifier,base::
ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_LevelShort);
ReplacementFor_ReplacementFor_conditionalAddFlag(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kLoggerIdFormatSpecifier,base::ReplacementFor_ReplacementFor_FormatFlags::
ReplacementFor_ReplacementFor_LoggerId);ReplacementFor_ReplacementFor_conditionalAddFlag(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kThreadIdFormatSpecifier,base::
ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_ThreadId);
ReplacementFor_ReplacementFor_conditionalAddFlag(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kLogFileFormatSpecifier,base::ReplacementFor_ReplacementFor_FormatFlags::File);
ReplacementFor_ReplacementFor_conditionalAddFlag(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kLogFileBaseFormatSpecifier,base::ReplacementFor_ReplacementFor_FormatFlags::
ReplacementFor_ReplacementFor_FileBase);ReplacementFor_ReplacementFor_conditionalAddFlag(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kLogLineFormatSpecifier,base::
ReplacementFor_ReplacementFor_FormatFlags::Line);ReplacementFor_ReplacementFor_conditionalAddFlag(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kLogLocationFormatSpecifier,base::
ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_Location);
ReplacementFor_ReplacementFor_conditionalAddFlag(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kLogFunctionFormatSpecifier,base::ReplacementFor_ReplacementFor_FormatFlags::
Function);ReplacementFor_ReplacementFor_conditionalAddFlag(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kCurrentUserFormatSpecifier,base::ReplacementFor_ReplacementFor_FormatFlags::
User);ReplacementFor_ReplacementFor_conditionalAddFlag(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kCurrentHostFormatSpecifier,base::ReplacementFor_ReplacementFor_FormatFlags::
ReplacementFor_ReplacementFor_Host);ReplacementFor_ReplacementFor_conditionalAddFlag(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kMessageFormatSpecifier,base::
ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_LogMessage);
ReplacementFor_ReplacementFor_conditionalAddFlag(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kVerboseLevelFormatSpecifier,base::ReplacementFor_ReplacementFor_FormatFlags::
ReplacementFor_ReplacementFor_VerboseLevel);std::size_t ReplacementFor_ReplacementFor_dateIndex=std::string::
npos;if((ReplacementFor_ReplacementFor_dateIndex=ReplacementFor_ReplacementFor_formatCopy.find(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDateTimeFormatSpecifier))!=std::string::
npos){while(ReplacementFor_ReplacementFor_dateIndex>(0xfc9+2883-0x1b0c)&&
ReplacementFor_ReplacementFor_formatCopy[ReplacementFor_ReplacementFor_dateIndex-(0xe89+518-0x108e)]==base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kFormatSpecifierChar){
ReplacementFor_ReplacementFor_dateIndex=ReplacementFor_ReplacementFor_formatCopy.find(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDateTimeFormatSpecifier,
ReplacementFor_ReplacementFor_dateIndex+(0x1a8+7649-0x1f88));}if(ReplacementFor_ReplacementFor_dateIndex!=std
::string::npos){ReplacementFor_ReplacementFor_addFlag(base::ReplacementFor_ReplacementFor_FormatFlags::
ReplacementFor_ReplacementFor_DateTime);ReplacementFor_ReplacementFor_updateDateFormat(
ReplacementFor_ReplacementFor_dateIndex,ReplacementFor_ReplacementFor_formatCopy);}}ReplacementFor_ReplacementFor_m_format=
ReplacementFor_ReplacementFor_formatCopy;ReplacementFor_ReplacementFor_updateFormatSpec();}void 
ReplacementFor_ReplacementFor_LogFormat::ReplacementFor_ReplacementFor_updateDateFormat(std::size_t index,base
::type::ReplacementFor_ReplacementFor_string_t&ReplacementFor_ReplacementFor_currFormat){if(
ReplacementFor_ReplacementFor_hasFlag(base::ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_DateTime
)){index+=ReplacementFor_ReplacementFor_ELPP_STRLEN(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kDateTimeFormatSpecifier);}const base::type::
ReplacementFor_ReplacementFor_char_t*ReplacementFor_ReplacementFor_ptr=ReplacementFor_ReplacementFor_currFormat.c_str()+index
;if((ReplacementFor_ReplacementFor_currFormat.size()>index)&&(ReplacementFor_ReplacementFor_ptr[
(0x2e5+1168-0x775)]==((char)(0x116f+3003-0x1caf)))){++ReplacementFor_ReplacementFor_ptr;int 
count=(0x704+961-0xac4);std::stringstream ReplacementFor_ReplacementFor_ss;for(;*
ReplacementFor_ReplacementFor_ptr;++ReplacementFor_ReplacementFor_ptr,++count){if(*ReplacementFor_ReplacementFor_ptr==
((char)(0x252+399-0x364))){++count;break;}ReplacementFor_ReplacementFor_ss<<static_cast<char>(*
ReplacementFor_ReplacementFor_ptr);}ReplacementFor_ReplacementFor_currFormat.erase(index,count);
ReplacementFor_ReplacementFor_m_dateTimeFormat=ReplacementFor_ReplacementFor_ss.str();}else{if(
ReplacementFor_ReplacementFor_hasFlag(base::ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_DateTime
)){ReplacementFor_ReplacementFor_m_dateTimeFormat=std::string(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kDefaultDateTimeFormat);}}}void ReplacementFor_ReplacementFor_LogFormat::
ReplacementFor_ReplacementFor_updateFormatSpec(void){if(ReplacementFor_ReplacementFor_m_level==Level::
ReplacementFor_ReplacementFor_Debug){base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_m_format,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDebugLevelLogValue);base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_m_format,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kDebugLevelShortLogValue);}else if(ReplacementFor_ReplacementFor_m_level==Level
::ReplacementFor_ReplacementFor_Info){base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_m_format,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kInfoLevelLogValue);base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_m_format,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kInfoLevelShortLogValue);}else if(ReplacementFor_ReplacementFor_m_level==Level::
ReplacementFor_ReplacementFor_Warning){base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_m_format,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kWarningLevelLogValue);base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_m_format,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kWarningLevelShortLogValue);}else if(ReplacementFor_ReplacementFor_m_level==
Level::Error){base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_m_format,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kErrorLevelLogValue);base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_m_format,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kErrorLevelShortLogValue);}else if(ReplacementFor_ReplacementFor_m_level==Level
::ReplacementFor_ReplacementFor_Fatal){base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_m_format,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kFatalLevelLogValue);base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_m_format,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kFatalLevelShortLogValue);}else if(ReplacementFor_ReplacementFor_m_level==Level
::ReplacementFor_ReplacementFor_Verbose){base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_m_format,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kVerboseLevelLogValue);base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_m_format,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kVerboseLevelShortLogValue);}else if(ReplacementFor_ReplacementFor_m_level==
Level::ReplacementFor_ReplacementFor_Trace){base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_m_format,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kTraceLevelLogValue);base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_m_format,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kTraceLevelShortLogValue);}if(ReplacementFor_ReplacementFor_hasFlag(base::
ReplacementFor_ReplacementFor_FormatFlags::User)){base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_m_format,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kCurrentUserFormatSpecifier,
ReplacementFor_ReplacementFor_m_currentUser);}if(ReplacementFor_ReplacementFor_hasFlag(base::
ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_Host)){base::ReplacementFor_ReplacementFor_utils::
Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_m_format,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kCurrentHostFormatSpecifier,
ReplacementFor_ReplacementFor_m_currentHost);}}ReplacementFor_ReplacementFor_TypedConfigurations::
ReplacementFor_ReplacementFor_TypedConfigurations(ReplacementFor_ReplacementFor_Configurations*
ReplacementFor_ReplacementFor_configurations,base::ReplacementFor_ReplacementFor_LogStreamsReferenceMap*
ReplacementFor_ReplacementFor_logStreamsReference){ReplacementFor_ReplacementFor_m_configurations=
ReplacementFor_ReplacementFor_configurations;ReplacementFor_ReplacementFor_m_logStreamsReference=
ReplacementFor_ReplacementFor_logStreamsReference;ReplacementFor_ReplacementFor_build(
ReplacementFor_ReplacementFor_m_configurations);}ReplacementFor_ReplacementFor_TypedConfigurations::
ReplacementFor_ReplacementFor_TypedConfigurations(const ReplacementFor_ReplacementFor_TypedConfigurations&
other){this->ReplacementFor_ReplacementFor_m_configurations=other.
ReplacementFor_ReplacementFor_m_configurations;this->ReplacementFor_ReplacementFor_m_logStreamsReference=other
.ReplacementFor_ReplacementFor_m_logStreamsReference;ReplacementFor_ReplacementFor_build(
ReplacementFor_ReplacementFor_m_configurations);}bool ReplacementFor_ReplacementFor_TypedConfigurations::
ReplacementFor_ReplacementFor_enabled(Level ReplacementFor_ReplacementFor_level){return 
ReplacementFor_ReplacementFor_getConfigByVal<bool>(ReplacementFor_ReplacementFor_level,&
ReplacementFor_ReplacementFor_m_enabledMap,"\x65\x6e\x61\x62\x6c\x65\x64");}bool 
ReplacementFor_ReplacementFor_TypedConfigurations::ReplacementFor_ReplacementFor_toFile(Level 
ReplacementFor_ReplacementFor_level){return ReplacementFor_ReplacementFor_getConfigByVal<bool>(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_toFileMap,"\x74\x6f\x46\x69\x6c\x65");}
const std::string&ReplacementFor_ReplacementFor_TypedConfigurations::ReplacementFor_ReplacementFor_filename(
Level ReplacementFor_ReplacementFor_level){return ReplacementFor_ReplacementFor_getConfigByRef<std::string>(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_filenameMap,
"\x66\x69\x6c\x65\x6e\x61\x6d\x65");}bool ReplacementFor_ReplacementFor_TypedConfigurations::
ReplacementFor_ReplacementFor_toStandardOutput(Level ReplacementFor_ReplacementFor_level){return 
ReplacementFor_ReplacementFor_getConfigByVal<bool>(ReplacementFor_ReplacementFor_level,&
ReplacementFor_ReplacementFor_m_toStandardOutputMap,
"\x74\x6f\x53\x74\x61\x6e\x64\x61\x72\x64\x4f\x75\x74\x70\x75\x74");}const base
::ReplacementFor_ReplacementFor_LogFormat&ReplacementFor_ReplacementFor_TypedConfigurations::
ReplacementFor_ReplacementFor_logFormat(Level ReplacementFor_ReplacementFor_level){return 
ReplacementFor_ReplacementFor_getConfigByRef<base::ReplacementFor_ReplacementFor_LogFormat>(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_logFormatMap,
"\x6c\x6f\x67\x46\x6f\x72\x6d\x61\x74");}const base::
ReplacementFor_ReplacementFor_SubsecondPrecision&ReplacementFor_ReplacementFor_TypedConfigurations::
ReplacementFor_ReplacementFor_subsecondPrecision(Level ReplacementFor_ReplacementFor_level){return 
ReplacementFor_ReplacementFor_getConfigByRef<base::ReplacementFor_ReplacementFor_SubsecondPrecision>(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_subsecondPrecisionMap,
"\x73\x75\x62\x73\x65\x63\x6f\x6e\x64\x50\x72\x65\x63\x69\x73\x69\x6f\x6e");}
const base::ReplacementFor_ReplacementFor_MillisecondsWidth&ReplacementFor_ReplacementFor_TypedConfigurations
::ReplacementFor_ReplacementFor_millisecondsWidth(Level ReplacementFor_ReplacementFor_level){return 
ReplacementFor_ReplacementFor_getConfigByRef<base::ReplacementFor_ReplacementFor_MillisecondsWidth>(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_subsecondPrecisionMap,
"\x6d\x69\x6c\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73\x57\x69\x64\x74\x68");}bool 
ReplacementFor_ReplacementFor_TypedConfigurations::ReplacementFor_ReplacementFor_performanceTracking(Level 
ReplacementFor_ReplacementFor_level){return ReplacementFor_ReplacementFor_getConfigByVal<bool>(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_performanceTrackingMap,
"\x70\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65\x54\x72\x61\x63\x6b\x69\x6e\x67");
}base::type::ReplacementFor_ReplacementFor_fstream_t*ReplacementFor_ReplacementFor_TypedConfigurations::
ReplacementFor_ReplacementFor_fileStream(Level ReplacementFor_ReplacementFor_level){return 
ReplacementFor_ReplacementFor_getConfigByRef<base::ReplacementFor_ReplacementFor_FileStreamPtr>(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_fileStreamMap,
"\x66\x69\x6c\x65\x53\x74\x72\x65\x61\x6d").get();}std::size_t 
ReplacementFor_ReplacementFor_TypedConfigurations::ReplacementFor_ReplacementFor_maxLogFileSize(Level 
ReplacementFor_ReplacementFor_level){return ReplacementFor_ReplacementFor_getConfigByVal<std::size_t>(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_maxLogFileSizeMap,
"\x6d\x61\x78\x4c\x6f\x67\x46\x69\x6c\x65\x53\x69\x7a\x65");}std::size_t 
ReplacementFor_ReplacementFor_TypedConfigurations::ReplacementFor_ReplacementFor_logFlushThreshold(Level 
ReplacementFor_ReplacementFor_level){return ReplacementFor_ReplacementFor_getConfigByVal<std::size_t>(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_logFlushThresholdMap,
"\x6c\x6f\x67\x46\x6c\x75\x73\x68\x54\x68\x72\x65\x73\x68\x6f\x6c\x64");}void 
ReplacementFor_ReplacementFor_TypedConfigurations::ReplacementFor_ReplacementFor_build(
ReplacementFor_ReplacementFor_Configurations*ReplacementFor_ReplacementFor_configurations){base::
ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(
lock());auto ReplacementFor_ReplacementFor_getBool=[](std::string ReplacementFor_ReplacementFor_boolStr)->bool
{base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_trim(ReplacementFor_ReplacementFor_boolStr);
return(ReplacementFor_ReplacementFor_boolStr=="\x54\x52\x55\x45"||ReplacementFor_ReplacementFor_boolStr==
"\x74\x72\x75\x65"||ReplacementFor_ReplacementFor_boolStr=="\x31");};std::vector<
ReplacementFor_ReplacementFor_Configuration*>ReplacementFor_ReplacementFor_withFileSizeLimit;for(
ReplacementFor_ReplacementFor_Configurations::const_iterator ReplacementFor_ReplacementFor_it=
ReplacementFor_ReplacementFor_configurations->begin();ReplacementFor_ReplacementFor_it!=
ReplacementFor_ReplacementFor_configurations->end();++ReplacementFor_ReplacementFor_it){
ReplacementFor_ReplacementFor_Configuration*ReplacementFor_ReplacementFor_conf=*ReplacementFor_ReplacementFor_it;if(
ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_configurationType()==
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_Enabled){
ReplacementFor_ReplacementFor_setValue(ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_level(),
ReplacementFor_ReplacementFor_getBool(ReplacementFor_ReplacementFor_conf->value()),&
ReplacementFor_ReplacementFor_m_enabledMap);}else if(ReplacementFor_ReplacementFor_conf->
ReplacementFor_ReplacementFor_configurationType()==ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_ToFile){ReplacementFor_ReplacementFor_setValue(ReplacementFor_ReplacementFor_conf->
ReplacementFor_ReplacementFor_level(),ReplacementFor_ReplacementFor_getBool(ReplacementFor_ReplacementFor_conf->value()),&
ReplacementFor_ReplacementFor_m_toFileMap);}else if(ReplacementFor_ReplacementFor_conf->
ReplacementFor_ReplacementFor_configurationType()==ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_ToStandardOutput){ReplacementFor_ReplacementFor_setValue(ReplacementFor_ReplacementFor_conf->
ReplacementFor_ReplacementFor_level(),ReplacementFor_ReplacementFor_getBool(ReplacementFor_ReplacementFor_conf->value()),&
ReplacementFor_ReplacementFor_m_toStandardOutputMap);}else if(ReplacementFor_ReplacementFor_conf->
ReplacementFor_ReplacementFor_configurationType()==ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_Filename){}else if(ReplacementFor_ReplacementFor_conf->
ReplacementFor_ReplacementFor_configurationType()==ReplacementFor_ReplacementFor_ConfigurationType::Format){
ReplacementFor_ReplacementFor_setValue(ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_level(),base::
ReplacementFor_ReplacementFor_LogFormat(ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_level(),base::type
::ReplacementFor_ReplacementFor_string_t(ReplacementFor_ReplacementFor_conf->value().begin(),
ReplacementFor_ReplacementFor_conf->value().end())),&ReplacementFor_ReplacementFor_m_logFormatMap);}else if(
ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_configurationType()==
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_SubsecondPrecision){
ReplacementFor_ReplacementFor_setValue(Level::Global,base::ReplacementFor_ReplacementFor_SubsecondPrecision(
static_cast<int>(ReplacementFor_ReplacementFor_getULong(ReplacementFor_ReplacementFor_conf->value()))),&
ReplacementFor_ReplacementFor_m_subsecondPrecisionMap);}else if(ReplacementFor_ReplacementFor_conf->
ReplacementFor_ReplacementFor_configurationType()==ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_PerformanceTracking){ReplacementFor_ReplacementFor_setValue(Level::Global,
ReplacementFor_ReplacementFor_getBool(ReplacementFor_ReplacementFor_conf->value()),&
ReplacementFor_ReplacementFor_m_performanceTrackingMap);}else if(ReplacementFor_ReplacementFor_conf->
ReplacementFor_ReplacementFor_configurationType()==ReplacementFor_ReplacementFor_ConfigurationType::
ReplacementFor_ReplacementFor_MaxLogFileSize){auto ReplacementFor_ReplacementFor_v=ReplacementFor_ReplacementFor_getULong(
ReplacementFor_ReplacementFor_conf->value());ReplacementFor_ReplacementFor_setValue(ReplacementFor_ReplacementFor_conf->
ReplacementFor_ReplacementFor_level(),static_cast<std::size_t>(ReplacementFor_ReplacementFor_v),&
ReplacementFor_ReplacementFor_m_maxLogFileSizeMap);if(ReplacementFor_ReplacementFor_v!=(0x894+6704-0x22c4)){
ReplacementFor_ReplacementFor_withFileSizeLimit.push_back(ReplacementFor_ReplacementFor_conf);}}else if(
ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_configurationType()==
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_LogFlushThreshold){
ReplacementFor_ReplacementFor_setValue(ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_level(),static_cast<
std::size_t>(ReplacementFor_ReplacementFor_getULong(ReplacementFor_ReplacementFor_conf->value())),&
ReplacementFor_ReplacementFor_m_logFlushThresholdMap);}}for(ReplacementFor_ReplacementFor_Configurations::
const_iterator ReplacementFor_ReplacementFor_it=ReplacementFor_ReplacementFor_configurations->begin();
ReplacementFor_ReplacementFor_it!=ReplacementFor_ReplacementFor_configurations->end();++ReplacementFor_ReplacementFor_it){
ReplacementFor_ReplacementFor_Configuration*ReplacementFor_ReplacementFor_conf=*ReplacementFor_ReplacementFor_it;if(
ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_configurationType()==
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_Filename){
ReplacementFor_ReplacementFor_insertFile(ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_level(),
ReplacementFor_ReplacementFor_conf->value());}}for(std::vector<ReplacementFor_ReplacementFor_Configuration*>::
iterator ReplacementFor_ReplacementFor_conf=ReplacementFor_ReplacementFor_withFileSizeLimit.begin();
ReplacementFor_ReplacementFor_conf!=ReplacementFor_ReplacementFor_withFileSizeLimit.end();++
ReplacementFor_ReplacementFor_conf){ReplacementFor_ReplacementFor_unsafeValidateFileRolling((*
ReplacementFor_ReplacementFor_conf)->ReplacementFor_ReplacementFor_level(),base::
ReplacementFor_ReplacementFor_defaultPreRollOutCallback);}}unsigned long 
ReplacementFor_ReplacementFor_TypedConfigurations::ReplacementFor_ReplacementFor_getULong(std::string 
ReplacementFor_ReplacementFor_confVal){bool valid=true;base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_trim(ReplacementFor_ReplacementFor_confVal);valid=!ReplacementFor_ReplacementFor_confVal.empty(
)&&std::find_if(ReplacementFor_ReplacementFor_confVal.begin(),ReplacementFor_ReplacementFor_confVal.end(),[](
char c){return!base::ReplacementFor_ReplacementFor_utils::Str::isDigit(c);})==
ReplacementFor_ReplacementFor_confVal.end();if(!valid){valid=false;ReplacementFor_ReplacementFor_ELPP_ASSERT(
valid,
"\x43\x6f\x6e\x66\x20\x76\x61\x6c\x20\x6e\x6f\x74\x20\x61\x20\x76\x61\x6c\x69\x64\x20\x69\x6e\x74\x65\x67\x65\x72\x20\x5b"
<<ReplacementFor_ReplacementFor_confVal<<"\x5d");return(0x16b+4966-0x14d1);}return atol(
ReplacementFor_ReplacementFor_confVal.c_str());}std::string ReplacementFor_ReplacementFor_TypedConfigurations
::ReplacementFor_ReplacementFor_resolveFilename(const std::string&ReplacementFor_ReplacementFor_filename){std
::string ReplacementFor_ReplacementFor_resultingFilename=ReplacementFor_ReplacementFor_filename;std::size_t 
ReplacementFor_ReplacementFor_dateIndex=std::string::npos;std::string 
ReplacementFor_ReplacementFor_dateTimeFormatSpecifierStr=std::string(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDateTimeFormatSpecifierForFilename);if((
ReplacementFor_ReplacementFor_dateIndex=ReplacementFor_ReplacementFor_resultingFilename.find(
ReplacementFor_ReplacementFor_dateTimeFormatSpecifierStr.c_str()))!=std::string::npos){while(
ReplacementFor_ReplacementFor_dateIndex>(0x16f9+602-0x1953)&&ReplacementFor_ReplacementFor_resultingFilename[
ReplacementFor_ReplacementFor_dateIndex-(0x141a+2623-0x1e58)]==base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kFormatSpecifierChar){ReplacementFor_ReplacementFor_dateIndex=
ReplacementFor_ReplacementFor_resultingFilename.find(ReplacementFor_ReplacementFor_dateTimeFormatSpecifierStr.
c_str(),ReplacementFor_ReplacementFor_dateIndex+(0x676+3635-0x14a8));}if(
ReplacementFor_ReplacementFor_dateIndex!=std::string::npos){const char*ReplacementFor_ReplacementFor_ptr=
ReplacementFor_ReplacementFor_resultingFilename.c_str()+ReplacementFor_ReplacementFor_dateIndex;
ReplacementFor_ReplacementFor_ptr+=ReplacementFor_ReplacementFor_dateTimeFormatSpecifierStr.size();std::string
 ReplacementFor_ReplacementFor_fmt;if((ReplacementFor_ReplacementFor_resultingFilename.size()>
ReplacementFor_ReplacementFor_dateIndex)&&(ReplacementFor_ReplacementFor_ptr[(0x385+4613-0x158a)]==
((char)(0x5a9+1484-0xafa)))){++ReplacementFor_ReplacementFor_ptr;int count=(0x1d72+913-0x2102);
std::stringstream ReplacementFor_ReplacementFor_ss;for(;*ReplacementFor_ReplacementFor_ptr;++
ReplacementFor_ReplacementFor_ptr,++count){if(*ReplacementFor_ReplacementFor_ptr==((char)(0x1de3+1007-0x2155))
){++count;break;}ReplacementFor_ReplacementFor_ss<<*ReplacementFor_ReplacementFor_ptr;}
ReplacementFor_ReplacementFor_resultingFilename.erase(ReplacementFor_ReplacementFor_dateIndex+
ReplacementFor_ReplacementFor_dateTimeFormatSpecifierStr.size(),count);ReplacementFor_ReplacementFor_fmt=
ReplacementFor_ReplacementFor_ss.str();}else{ReplacementFor_ReplacementFor_fmt=std::string(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDefaultDateTimeFormatInFilename);}base::
ReplacementFor_ReplacementFor_SubsecondPrecision ReplacementFor_ReplacementFor_ssPrec((0x636+3159-0x128a));std
::string now=base::ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_DateTime::
ReplacementFor_ReplacementFor_getDateTime(ReplacementFor_ReplacementFor_fmt.c_str(),&ReplacementFor_ReplacementFor_ssPrec);
base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceAll(now,
((char)(0x92+5966-0x17b1)),((char)(0xb3b+3188-0x1782)));base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceAll(
ReplacementFor_ReplacementFor_resultingFilename,ReplacementFor_ReplacementFor_dateTimeFormatSpecifierStr,now);
}}return ReplacementFor_ReplacementFor_resultingFilename;}void 
ReplacementFor_ReplacementFor_TypedConfigurations::ReplacementFor_ReplacementFor_insertFile(Level 
ReplacementFor_ReplacementFor_level,const std::string&ReplacementFor_ReplacementFor_fullFilename){std::string 
ReplacementFor_ReplacementFor_resolvedFilename=ReplacementFor_ReplacementFor_resolveFilename(
ReplacementFor_ReplacementFor_fullFilename);if(ReplacementFor_ReplacementFor_resolvedFilename.empty()){std::
cerr<<
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6c\x6f\x61\x64\x20\x65\x6d\x70\x74\x79\x20\x66\x69\x6c\x65\x2c\x20\x72\x65\x2d\x63\x68\x65\x63\x6b\x20\x79\x6f\x75\x72\x20\x63\x6f\x6e\x66\x20\x66\x6f\x72\x20\x6c\x65\x76\x65\x6c\x20\x5b"
<<ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_convertToString(
ReplacementFor_ReplacementFor_level)<<"\x5d";}std::string ReplacementFor_ReplacementFor_filePath=base::
ReplacementFor_ReplacementFor_utils::File::ReplacementFor_ReplacementFor_extractPathFromFilename(
ReplacementFor_ReplacementFor_resolvedFilename,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kFilePathSeperator);if(ReplacementFor_ReplacementFor_filePath.size()<
ReplacementFor_ReplacementFor_resolvedFilename.size()){base::ReplacementFor_ReplacementFor_utils::File::
ReplacementFor_ReplacementFor_createPath(ReplacementFor_ReplacementFor_filePath);}auto ReplacementFor_ReplacementFor_create=[
&](Level ReplacementFor_ReplacementFor_level){base::ReplacementFor_ReplacementFor_LogStreamsReferenceMap::
iterator ReplacementFor_ReplacementFor_filestreamIter=ReplacementFor_ReplacementFor_m_logStreamsReference->
find(ReplacementFor_ReplacementFor_resolvedFilename);base::type::ReplacementFor_ReplacementFor_fstream_t*fs=
nullptr;if(ReplacementFor_ReplacementFor_filestreamIter==ReplacementFor_ReplacementFor_m_logStreamsReference->
end()){fs=base::ReplacementFor_ReplacementFor_utils::File::ReplacementFor_ReplacementFor_newFileStream(
ReplacementFor_ReplacementFor_resolvedFilename);ReplacementFor_ReplacementFor_m_filenameMap.insert(std::
make_pair(ReplacementFor_ReplacementFor_level,ReplacementFor_ReplacementFor_resolvedFilename));
ReplacementFor_ReplacementFor_m_fileStreamMap.insert(std::make_pair(ReplacementFor_ReplacementFor_level,base::
ReplacementFor_ReplacementFor_FileStreamPtr(fs)));ReplacementFor_ReplacementFor_m_logStreamsReference->insert(
std::make_pair(ReplacementFor_ReplacementFor_resolvedFilename,base::
ReplacementFor_ReplacementFor_FileStreamPtr(ReplacementFor_ReplacementFor_m_fileStreamMap.at(
ReplacementFor_ReplacementFor_level))));}else{ReplacementFor_ReplacementFor_m_filenameMap.insert(std::
make_pair(ReplacementFor_ReplacementFor_level,ReplacementFor_ReplacementFor_filestreamIter->first));
ReplacementFor_ReplacementFor_m_fileStreamMap.insert(std::make_pair(ReplacementFor_ReplacementFor_level,base::
ReplacementFor_ReplacementFor_FileStreamPtr(ReplacementFor_ReplacementFor_filestreamIter->second)));fs=
ReplacementFor_ReplacementFor_filestreamIter->second.get();}if(fs==nullptr){
ReplacementFor_ReplacementFor_ELPP_INTERNAL_ERROR(
"\x53\x65\x74\x20\x5b\x54\x4f\x5f\x46\x49\x4c\x45\x5d\x20\x6f\x66\x20\x5b"<<
ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_convertToString(ReplacementFor_ReplacementFor_level)
<<"\x5d\x20\x74\x6f\x20\x46\x41\x4c\x53\x45",false);ReplacementFor_ReplacementFor_setValue(
ReplacementFor_ReplacementFor_level,false,&ReplacementFor_ReplacementFor_m_toFileMap);}};ReplacementFor_ReplacementFor_create
(ReplacementFor_ReplacementFor_m_filenameMap.empty()&&ReplacementFor_ReplacementFor_m_fileStreamMap.empty()?
Level::Global:ReplacementFor_ReplacementFor_level);}bool ReplacementFor_ReplacementFor_TypedConfigurations::
ReplacementFor_ReplacementFor_unsafeValidateFileRolling(Level ReplacementFor_ReplacementFor_level,const 
ReplacementFor_ReplacementFor_PreRollOutCallback&ReplacementFor_ReplacementFor_preRollOutCallback){base::type
::ReplacementFor_ReplacementFor_fstream_t*fs=ReplacementFor_ReplacementFor_unsafeGetConfigByRef(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_fileStreamMap,
"\x66\x69\x6c\x65\x53\x74\x72\x65\x61\x6d").get();if(fs==nullptr){return true;}
std::size_t ReplacementFor_ReplacementFor_maxLogFileSize=ReplacementFor_ReplacementFor_unsafeGetConfigByVal(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_maxLogFileSizeMap,
"\x6d\x61\x78\x4c\x6f\x67\x46\x69\x6c\x65\x53\x69\x7a\x65");std::size_t 
ReplacementFor_ReplacementFor_currFileSize=base::ReplacementFor_ReplacementFor_utils::File::
ReplacementFor_ReplacementFor_getSizeOfFile(fs);if(ReplacementFor_ReplacementFor_maxLogFileSize!=
(0x708+6779-0x2183)&&ReplacementFor_ReplacementFor_currFileSize>=ReplacementFor_ReplacementFor_maxLogFileSize)
{std::string ReplacementFor_ReplacementFor_fname=ReplacementFor_ReplacementFor_unsafeGetConfigByRef(
ReplacementFor_ReplacementFor_level,&ReplacementFor_ReplacementFor_m_filenameMap,
"\x66\x69\x6c\x65\x6e\x61\x6d\x65");ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO(
(0xa1d+1808-0x112c),
"\x54\x72\x75\x6e\x63\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x5b"<<
ReplacementFor_ReplacementFor_fname<<
"\x5d\x20\x61\x73\x20\x61\x20\x72\x65\x73\x75\x6c\x74\x20\x6f\x66\x20\x63\x6f\x6e\x66\x20\x66\x6f\x72\x20\x6c\x65\x76\x65\x6c\x20\x5b"
<<ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_convertToString(
ReplacementFor_ReplacementFor_level)<<"\x5d");fs->close();ReplacementFor_ReplacementFor_preRollOutCallback(
ReplacementFor_ReplacementFor_fname.c_str(),ReplacementFor_ReplacementFor_currFileSize);fs->open(
ReplacementFor_ReplacementFor_fname,std::fstream::out|std::fstream::trunc);return true;}return 
false;}bool ReplacementFor_ReplacementFor_RegisteredHitCounters::ReplacementFor_ReplacementFor_validateEveryN(
const char*ReplacementFor_ReplacementFor_filename,base::type::ReplacementFor_ReplacementFor_LineNumber 
ReplacementFor_ReplacementFor_lineNumber,std::size_t n){base::ReplacementFor_ReplacementFor_threading::
ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(lock());base::
ReplacementFor_ReplacementFor_HitCounter*counter=get(ReplacementFor_ReplacementFor_filename,
ReplacementFor_ReplacementFor_lineNumber);if(counter==nullptr){ReplacementFor_ReplacementFor_registerNew(
counter=new base::ReplacementFor_ReplacementFor_HitCounter(ReplacementFor_ReplacementFor_filename,
ReplacementFor_ReplacementFor_lineNumber));}counter->ReplacementFor_ReplacementFor_validateHitCounts(n);bool 
result=(n>=(0x1317+491-0x1501)&&counter->ReplacementFor_ReplacementFor_hitCounts()!=
(0xf48+1691-0x15e3)&&counter->ReplacementFor_ReplacementFor_hitCounts()%n==(0x69a+4133-0x16bf))
;return result;}bool ReplacementFor_ReplacementFor_RegisteredHitCounters::
ReplacementFor_ReplacementFor_validateAfterN(const char*ReplacementFor_ReplacementFor_filename,base::type::
ReplacementFor_ReplacementFor_LineNumber ReplacementFor_ReplacementFor_lineNumber,std::size_t n){base::
ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(
lock());base::ReplacementFor_ReplacementFor_HitCounter*counter=get(ReplacementFor_ReplacementFor_filename,
ReplacementFor_ReplacementFor_lineNumber);if(counter==nullptr){ReplacementFor_ReplacementFor_registerNew(
counter=new base::ReplacementFor_ReplacementFor_HitCounter(ReplacementFor_ReplacementFor_filename,
ReplacementFor_ReplacementFor_lineNumber));}if(counter->ReplacementFor_ReplacementFor_hitCounts()>=n)return 
true;counter->increment();return false;}bool 
ReplacementFor_ReplacementFor_RegisteredHitCounters::ReplacementFor_ReplacementFor_validateNTimes(const char*
ReplacementFor_ReplacementFor_filename,base::type::ReplacementFor_ReplacementFor_LineNumber 
ReplacementFor_ReplacementFor_lineNumber,std::size_t n){base::ReplacementFor_ReplacementFor_threading::
ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(lock());base::
ReplacementFor_ReplacementFor_HitCounter*counter=get(ReplacementFor_ReplacementFor_filename,
ReplacementFor_ReplacementFor_lineNumber);if(counter==nullptr){ReplacementFor_ReplacementFor_registerNew(
counter=new base::ReplacementFor_ReplacementFor_HitCounter(ReplacementFor_ReplacementFor_filename,
ReplacementFor_ReplacementFor_lineNumber));}counter->increment();if(counter->
ReplacementFor_ReplacementFor_hitCounts()<=n)return true;return false;}
ReplacementFor_ReplacementFor_RegisteredLoggers::ReplacementFor_ReplacementFor_RegisteredLoggers(const 
ReplacementFor_ReplacementFor_LogBuilderPtr&ReplacementFor_ReplacementFor_defaultLogBuilder):
ReplacementFor_ReplacementFor_m_defaultLogBuilder(ReplacementFor_ReplacementFor_defaultLogBuilder){
ReplacementFor_ReplacementFor_m_defaultConfigurations.ReplacementFor_ReplacementFor_setToDefault();}
ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_RegisteredLoggers::get(const std::string&id
,bool ReplacementFor_ReplacementFor_forceCreation){base::ReplacementFor_ReplacementFor_threading::
ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(lock());
ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_logger_=base::ReplacementFor_ReplacementFor_utils::
ReplacementFor_ReplacementFor_Registry<ReplacementFor_ReplacementFor_Logger,std::string>::get(id);if(
ReplacementFor_ReplacementFor_logger_==nullptr&&ReplacementFor_ReplacementFor_forceCreation){bool 
ReplacementFor_ReplacementFor_validId=ReplacementFor_ReplacementFor_Logger::ReplacementFor_ReplacementFor_isValidId(id);if(!
ReplacementFor_ReplacementFor_validId){ReplacementFor_ReplacementFor_ELPP_ASSERT(ReplacementFor_ReplacementFor_validId,
"\x49\x6e\x76\x20\x6c\x6f\x67\x67\x65\x72\x20\x49\x44\x20\x5b"<<id<<"\x5d\x2e");
return nullptr;}ReplacementFor_ReplacementFor_logger_=new ReplacementFor_ReplacementFor_Logger(id,
ReplacementFor_ReplacementFor_m_defaultConfigurations,&ReplacementFor_ReplacementFor_m_logStreamsReference);
ReplacementFor_ReplacementFor_logger_->ReplacementFor_ReplacementFor_m_logBuilder=
ReplacementFor_ReplacementFor_m_defaultLogBuilder;ReplacementFor_ReplacementFor_registerNew(id,
ReplacementFor_ReplacementFor_logger_);ReplacementFor_ReplacementFor_LoggerRegistrationCallback*
ReplacementFor_ReplacementFor_callback=nullptr;for(const std::pair<std::string,base::type::
ReplacementFor_ReplacementFor_LoggerRegistrationCallbackPtr>&ReplacementFor_ReplacementFor_h:
ReplacementFor_ReplacementFor_m_loggerRegistrationCallbacks){ReplacementFor_ReplacementFor_callback=
ReplacementFor_ReplacementFor_h.second.get();if(ReplacementFor_ReplacementFor_callback!=nullptr&&
ReplacementFor_ReplacementFor_callback->ReplacementFor_ReplacementFor_enabled()){ReplacementFor_ReplacementFor_callback->
ReplacementFor_ReplacementFor_handle(ReplacementFor_ReplacementFor_logger_);}}}return ReplacementFor_ReplacementFor_logger_;}
bool ReplacementFor_ReplacementFor_RegisteredLoggers::remove(const std::string&id){if(id==base
::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDefaultLoggerId){return false;}
ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_logger=base::ReplacementFor_ReplacementFor_utils::
ReplacementFor_ReplacementFor_Registry<ReplacementFor_ReplacementFor_Logger,std::string>::get(id);if(
ReplacementFor_ReplacementFor_logger!=nullptr){ReplacementFor_ReplacementFor_unregister(ReplacementFor_ReplacementFor_logger)
;}return true;}void ReplacementFor_ReplacementFor_RegisteredLoggers::
ReplacementFor_ReplacementFor_unsafeFlushAll(void){ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO(
(0x9cc+1113-0xe24),
"\x46\x6c\x75\x73\x68\x69\x6e\x67\x20\x61\x6c\x6c\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x73"
);for(base::ReplacementFor_ReplacementFor_LogStreamsReferenceMap::iterator ReplacementFor_ReplacementFor_it=
ReplacementFor_ReplacementFor_m_logStreamsReference.begin();ReplacementFor_ReplacementFor_it!=
ReplacementFor_ReplacementFor_m_logStreamsReference.end();++ReplacementFor_ReplacementFor_it){if(
ReplacementFor_ReplacementFor_it->second.get()==nullptr)continue;ReplacementFor_ReplacementFor_it->second->
flush();}}ReplacementFor_ReplacementFor_VRegistry::ReplacementFor_ReplacementFor_VRegistry(base::type::
ReplacementFor_ReplacementFor_VerboseLevel ReplacementFor_ReplacementFor_level,base::type::
ReplacementFor_ReplacementFor_EnumType*ReplacementFor_ReplacementFor_pFlags):ReplacementFor_ReplacementFor_m_level(
ReplacementFor_ReplacementFor_level),ReplacementFor_ReplacementFor_m_pFlags(ReplacementFor_ReplacementFor_pFlags){}void 
ReplacementFor_ReplacementFor_VRegistry::ReplacementFor_ReplacementFor_setLevel(base::type::
ReplacementFor_ReplacementFor_VerboseLevel ReplacementFor_ReplacementFor_level){base::ReplacementFor_ReplacementFor_threading
::ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(lock());if(
ReplacementFor_ReplacementFor_level>(0xedc+1618-0x1525))ReplacementFor_ReplacementFor_m_level=base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kMaxVerboseLevel;else 
ReplacementFor_ReplacementFor_m_level=ReplacementFor_ReplacementFor_level;}void ReplacementFor_ReplacementFor_VRegistry::
ReplacementFor_ReplacementFor_setModules(const char*ReplacementFor_ReplacementFor_modules){base::
ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(
lock());auto ReplacementFor_ReplacementFor_addSuffix=[](std::stringstream&ReplacementFor_ReplacementFor_ss,
const char*ReplacementFor_ReplacementFor_sfx,const char*prev){if(prev!=nullptr&&base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_endsWith(ReplacementFor_ReplacementFor_ss.str(),std::
string(prev))){std::string ReplacementFor_ReplacementFor_chr(ReplacementFor_ReplacementFor_ss.str().substr(
(0x1277+227-0x135a),ReplacementFor_ReplacementFor_ss.str().size()-strlen(prev)));
ReplacementFor_ReplacementFor_ss.str(std::string(""));ReplacementFor_ReplacementFor_ss<<ReplacementFor_ReplacementFor_chr;}if
(base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_endsWith(ReplacementFor_ReplacementFor_ss.str(
),std::string(ReplacementFor_ReplacementFor_sfx))){std::string ReplacementFor_ReplacementFor_chr(
ReplacementFor_ReplacementFor_ss.str().substr((0x104a+4848-0x233a),ReplacementFor_ReplacementFor_ss.str().size
()-strlen(ReplacementFor_ReplacementFor_sfx)));ReplacementFor_ReplacementFor_ss.str(std::string(""));
ReplacementFor_ReplacementFor_ss<<ReplacementFor_ReplacementFor_chr;}ReplacementFor_ReplacementFor_ss<<ReplacementFor_ReplacementFor_sfx;};
auto insert=[&](std::stringstream&ReplacementFor_ReplacementFor_ss,base::type::
ReplacementFor_ReplacementFor_VerboseLevel ReplacementFor_ReplacementFor_level){if(!base::ReplacementFor_ReplacementFor_utils
::ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_LoggingFlag::
ReplacementFor_ReplacementFor_DisableVModulesExtensions,*ReplacementFor_ReplacementFor_m_pFlags)){
ReplacementFor_ReplacementFor_addSuffix(ReplacementFor_ReplacementFor_ss,"\x2e\x68",nullptr);
ReplacementFor_ReplacementFor_m_modules.insert(std::make_pair(ReplacementFor_ReplacementFor_ss.str(),
ReplacementFor_ReplacementFor_level));ReplacementFor_ReplacementFor_addSuffix(ReplacementFor_ReplacementFor_ss,"\x2e\x63",
"\x2e\x68");ReplacementFor_ReplacementFor_m_modules.insert(std::make_pair(ReplacementFor_ReplacementFor_ss.str
(),ReplacementFor_ReplacementFor_level));ReplacementFor_ReplacementFor_addSuffix(ReplacementFor_ReplacementFor_ss,
"\x2e\x63\x70\x70","\x2e\x63");ReplacementFor_ReplacementFor_m_modules.insert(std::make_pair(
ReplacementFor_ReplacementFor_ss.str(),ReplacementFor_ReplacementFor_level));ReplacementFor_ReplacementFor_addSuffix(
ReplacementFor_ReplacementFor_ss,"\x2e\x63\x63","\x2e\x63\x70\x70");ReplacementFor_ReplacementFor_m_modules.
insert(std::make_pair(ReplacementFor_ReplacementFor_ss.str(),ReplacementFor_ReplacementFor_level));
ReplacementFor_ReplacementFor_addSuffix(ReplacementFor_ReplacementFor_ss,"\x2e\x63\x78\x78","\x2e\x63\x63");
ReplacementFor_ReplacementFor_m_modules.insert(std::make_pair(ReplacementFor_ReplacementFor_ss.str(),
ReplacementFor_ReplacementFor_level));ReplacementFor_ReplacementFor_addSuffix(ReplacementFor_ReplacementFor_ss,
"\x2e\x2d\x69\x6e\x6c\x2e\x68","\x2e\x63\x78\x78");ReplacementFor_ReplacementFor_m_modules.
insert(std::make_pair(ReplacementFor_ReplacementFor_ss.str(),ReplacementFor_ReplacementFor_level));
ReplacementFor_ReplacementFor_addSuffix(ReplacementFor_ReplacementFor_ss,"\x2e\x68\x78\x78",
"\x2e\x2d\x69\x6e\x6c\x2e\x68");ReplacementFor_ReplacementFor_m_modules.insert(std::make_pair(
ReplacementFor_ReplacementFor_ss.str(),ReplacementFor_ReplacementFor_level));ReplacementFor_ReplacementFor_addSuffix(
ReplacementFor_ReplacementFor_ss,"\x2e\x68\x70\x70","\x2e\x68\x78\x78");
ReplacementFor_ReplacementFor_m_modules.insert(std::make_pair(ReplacementFor_ReplacementFor_ss.str(),
ReplacementFor_ReplacementFor_level));ReplacementFor_ReplacementFor_addSuffix(ReplacementFor_ReplacementFor_ss,"\x2e\x68\x68"
,"\x2e\x68\x70\x70");}ReplacementFor_ReplacementFor_m_modules.insert(std::make_pair(
ReplacementFor_ReplacementFor_ss.str(),ReplacementFor_ReplacementFor_level));};bool ReplacementFor_ReplacementFor_isMod=true;
bool ReplacementFor_ReplacementFor_isLevel=false;std::stringstream ReplacementFor_ReplacementFor_ss;int 
ReplacementFor_ReplacementFor_level=-(0x604+6453-0x1f38);for(;*ReplacementFor_ReplacementFor_modules;++
ReplacementFor_ReplacementFor_modules){switch(*ReplacementFor_ReplacementFor_modules){case
((char)(0x1787+985-0x1b23)):ReplacementFor_ReplacementFor_isLevel=true;ReplacementFor_ReplacementFor_isMod=
false;break;case((char)(0xe63+2990-0x19e5)):ReplacementFor_ReplacementFor_isLevel=false;
ReplacementFor_ReplacementFor_isMod=true;if(!ReplacementFor_ReplacementFor_ss.str().empty()&&
ReplacementFor_ReplacementFor_level!=-(0xe94+3708-0x1d0f)){insert(ReplacementFor_ReplacementFor_ss,static_cast
<base::type::ReplacementFor_ReplacementFor_VerboseLevel>(ReplacementFor_ReplacementFor_level));
ReplacementFor_ReplacementFor_ss.str(std::string(""));ReplacementFor_ReplacementFor_level=-(0x305+8735-0x2523)
;}break;default:if(ReplacementFor_ReplacementFor_isMod){ReplacementFor_ReplacementFor_ss<<*
ReplacementFor_ReplacementFor_modules;}else if(ReplacementFor_ReplacementFor_isLevel){if(isdigit(*
ReplacementFor_ReplacementFor_modules)){ReplacementFor_ReplacementFor_level=static_cast<base::type::
ReplacementFor_ReplacementFor_VerboseLevel>(*ReplacementFor_ReplacementFor_modules)-(0x130f+4809-0x25a8);}}
break;}}if(!ReplacementFor_ReplacementFor_ss.str().empty()&&ReplacementFor_ReplacementFor_level!=-
(0xcf2+4050-0x1cc3)){insert(ReplacementFor_ReplacementFor_ss,static_cast<base::type::
ReplacementFor_ReplacementFor_VerboseLevel>(ReplacementFor_ReplacementFor_level));}}bool 
ReplacementFor_ReplacementFor_VRegistry::ReplacementFor_ReplacementFor_allowed(base::type::
ReplacementFor_ReplacementFor_VerboseLevel ReplacementFor_ReplacementFor_vlevel,const char*ReplacementFor_ReplacementFor_file
){base::ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock 
ReplacementFor_ReplacementFor_scopedLock(lock());if(ReplacementFor_ReplacementFor_m_modules.empty()||
ReplacementFor_ReplacementFor_file==nullptr){return ReplacementFor_ReplacementFor_vlevel<=
ReplacementFor_ReplacementFor_m_level;}else{char ReplacementFor_ReplacementFor_baseFilename[base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSourceFilenameMaxLength]="";base::
ReplacementFor_ReplacementFor_utils::File::ReplacementFor_ReplacementFor_buildBaseFilename(ReplacementFor_ReplacementFor_file
,ReplacementFor_ReplacementFor_baseFilename);std::unordered_map<std::string,base::type::
ReplacementFor_ReplacementFor_VerboseLevel>::iterator ReplacementFor_ReplacementFor_it=
ReplacementFor_ReplacementFor_m_modules.begin();for(;ReplacementFor_ReplacementFor_it!=
ReplacementFor_ReplacementFor_m_modules.end();++ReplacementFor_ReplacementFor_it){if(base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_wildCardMatch(
ReplacementFor_ReplacementFor_baseFilename,ReplacementFor_ReplacementFor_it->first.c_str())){return 
ReplacementFor_ReplacementFor_vlevel<=ReplacementFor_ReplacementFor_it->second;}}if(base::ReplacementFor_ReplacementFor_utils
::ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_LoggingFlag::
ReplacementFor_ReplacementFor_AllowVerboseIfModuleNotSpecified,*ReplacementFor_ReplacementFor_m_pFlags)){
return true;}return false;}}void ReplacementFor_ReplacementFor_VRegistry::
ReplacementFor_ReplacementFor_setFromArgs(const base::ReplacementFor_ReplacementFor_utils::
ReplacementFor_ReplacementFor_CommandLineArgs*ReplacementFor_ReplacementFor_commandLineArgs){if(
ReplacementFor_ReplacementFor_commandLineArgs->ReplacementFor_ReplacementFor_hasParam("\x2d\x76")||
ReplacementFor_ReplacementFor_commandLineArgs->ReplacementFor_ReplacementFor_hasParam(
"\x2d\x2d\x76\x65\x72\x62\x6f\x73\x65")||ReplacementFor_ReplacementFor_commandLineArgs->
ReplacementFor_ReplacementFor_hasParam("\x2d\x56")||ReplacementFor_ReplacementFor_commandLineArgs->
ReplacementFor_ReplacementFor_hasParam("\x2d\x2d\x56\x45\x52\x42\x4f\x53\x45")){
ReplacementFor_ReplacementFor_setLevel(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kMaxVerboseLevel);}else if(ReplacementFor_ReplacementFor_commandLineArgs->
ReplacementFor_ReplacementFor_hasParamWithValue("\x2d\x2d\x76")){ReplacementFor_ReplacementFor_setLevel(
static_cast<base::type::ReplacementFor_ReplacementFor_VerboseLevel>(atoi(
ReplacementFor_ReplacementFor_commandLineArgs->ReplacementFor_ReplacementFor_getParamValue("\x2d\x2d\x76"))));
}else if(ReplacementFor_ReplacementFor_commandLineArgs->ReplacementFor_ReplacementFor_hasParamWithValue(
"\x2d\x2d\x56")){ReplacementFor_ReplacementFor_setLevel(static_cast<base::type::
ReplacementFor_ReplacementFor_VerboseLevel>(atoi(ReplacementFor_ReplacementFor_commandLineArgs->
ReplacementFor_ReplacementFor_getParamValue("\x2d\x2d\x56"))));}else if((
ReplacementFor_ReplacementFor_commandLineArgs->ReplacementFor_ReplacementFor_hasParamWithValue(
"\x2d\x76\x6d\x6f\x64\x75\x6c\x65"))&&ReplacementFor_ReplacementFor_vModulesEnabled()){
ReplacementFor_ReplacementFor_setModules(ReplacementFor_ReplacementFor_commandLineArgs->
ReplacementFor_ReplacementFor_getParamValue("\x2d\x76\x6d\x6f\x64\x75\x6c\x65"));}else if(
ReplacementFor_ReplacementFor_commandLineArgs->ReplacementFor_ReplacementFor_hasParamWithValue(
"\x2d\x56\x4d\x4f\x44\x55\x4c\x45")&&ReplacementFor_ReplacementFor_vModulesEnabled()){
ReplacementFor_ReplacementFor_setModules(ReplacementFor_ReplacementFor_commandLineArgs->
ReplacementFor_ReplacementFor_getParamValue("\x2d\x56\x4d\x4f\x44\x55\x4c\x45"));}}
#if !defined(ReplacementFor_ReplacementFor_ELPP_DEFAULT_LOGGING_FLAGS)
#   define ReplacementFor_ReplacementFor_ELPP_DEFAULT_LOGGING_FLAGS (0x1a6b+2039-0x2262)
#endif 
#if ReplacementFor_ReplacementFor_ELPP_ASYNC_LOGGING
ReplacementFor_ReplacementFor_Storage::ReplacementFor_ReplacementFor_Storage(const 
ReplacementFor_ReplacementFor_LogBuilderPtr&ReplacementFor_ReplacementFor_defaultLogBuilder,base::
ReplacementFor_ReplacementFor_IWorker*ReplacementFor_ReplacementFor_asyncDispatchWorker):
#else
ReplacementFor_ReplacementFor_Storage::ReplacementFor_ReplacementFor_Storage(const 
ReplacementFor_ReplacementFor_LogBuilderPtr&ReplacementFor_ReplacementFor_defaultLogBuilder):
#endif  
ReplacementFor_ReplacementFor_m_registeredHitCounters(new base::
ReplacementFor_ReplacementFor_RegisteredHitCounters()),ReplacementFor_ReplacementFor_m_registeredLoggers(new 
base::ReplacementFor_ReplacementFor_RegisteredLoggers(ReplacementFor_ReplacementFor_defaultLogBuilder)),
ReplacementFor_ReplacementFor_m_flags(ReplacementFor_ReplacementFor_ELPP_DEFAULT_LOGGING_FLAGS),
ReplacementFor_ReplacementFor_m_vRegistry(new base::ReplacementFor_ReplacementFor_VRegistry(
(0x8e4+4887-0x1bfb),&ReplacementFor_ReplacementFor_m_flags)),
#if ReplacementFor_ReplacementFor_ELPP_ASYNC_LOGGING
ReplacementFor_ReplacementFor_m_asyncLogQueue(new base::ReplacementFor_ReplacementFor_AsyncLogQueue()),
ReplacementFor_ReplacementFor_m_asyncDispatchWorker(ReplacementFor_ReplacementFor_asyncDispatchWorker),
#endif  
ReplacementFor_ReplacementFor_m_preRollOutCallback(base::
ReplacementFor_ReplacementFor_defaultPreRollOutCallback){ReplacementFor_ReplacementFor_m_registeredLoggers->
get(std::string(base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDefaultLoggerId));
ReplacementFor_ReplacementFor_m_registeredLoggers->get("\x64\x65\x66\x61\x75\x6c\x74");
#if defined(ReplacementFor_ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ReplacementFor_ELPP_FEATURE_PERFORMANCE_TRACKING)
ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_performanceLogger=
ReplacementFor_ReplacementFor_m_registeredLoggers->get(std::string(base::ReplacementFor_ReplacementFor_consts
::ReplacementFor_ReplacementFor_kPerformanceLoggerId));ReplacementFor_ReplacementFor_m_registeredLoggers->get(
"\x70\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65");ReplacementFor_ReplacementFor_performanceLogger
->ReplacementFor_ReplacementFor_configurations()->ReplacementFor_ReplacementFor_setGlobally(
ReplacementFor_ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x25\x6d\x73\x67"
));ReplacementFor_ReplacementFor_performanceLogger->ReplacementFor_ReplacementFor_reconfigure();
#endif 
#if defined(ReplacementFor_ReplacementFor_ELPP_SYSLOG)
ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_sysLogLogger=
ReplacementFor_ReplacementFor_m_registeredLoggers->get(std::string(base::ReplacementFor_ReplacementFor_consts
::ReplacementFor_ReplacementFor_kSysLogLoggerId));ReplacementFor_ReplacementFor_sysLogLogger->
ReplacementFor_ReplacementFor_configurations()->ReplacementFor_ReplacementFor_setGlobally(
ReplacementFor_ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x6c\x65\x76\x65\x6c\x3a\x20\x25\x6d\x73\x67"));ReplacementFor_ReplacementFor_sysLogLogger
->ReplacementFor_ReplacementFor_reconfigure();
#endif 
ReplacementFor_ReplacementFor_addFlag(ReplacementFor_ReplacementFor_LoggingFlag::
ReplacementFor_ReplacementFor_AllowVerboseIfModuleNotSpecified);
#if ReplacementFor_ReplacementFor_ELPP_ASYNC_LOGGING
ReplacementFor_ReplacementFor_installLogDispatchCallback<base::
ReplacementFor_ReplacementFor_AsyncLogDispatchCallback>(std::string(
"\x41\x73\x79\x6e\x63\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));
#else
ReplacementFor_ReplacementFor_installLogDispatchCallback<base::
ReplacementFor_ReplacementFor_DefaultLogDispatchCallback>(std::string(
"\x44\x65\x66\x61\x75\x6c\x74\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));
#endif  
#if defined(ReplacementFor_ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ReplacementFor_ELPP_FEATURE_PERFORMANCE_TRACKING)
ReplacementFor_ReplacementFor_installPerformanceTrackingCallback<base::
ReplacementFor_ReplacementFor_DefaultPerformanceTrackingCallback>(std::string(
"\x44\x65\x66\x61\x75\x6c\x74\x50\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65\x54\x72\x61\x63\x6b\x69\x6e\x67\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));
#endif 
ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0x2301+385-0x2481),
"\x45\x61\x73\x79\x6c\x6f\x67\x67\x69\x6e\x67\x2b\x2b\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64"
);
#if ReplacementFor_ReplacementFor_ELPP_ASYNC_LOGGING
ReplacementFor_ReplacementFor_m_asyncDispatchWorker->ReplacementFor_ReplacementFor_start();
#endif  
}ReplacementFor_ReplacementFor_Storage::~ReplacementFor_ReplacementFor_Storage(void){
ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0x129d+1782-0x198f),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x73\x74\x6f\x72\x61\x67\x65");
#if ReplacementFor_ReplacementFor_ELPP_ASYNC_LOGGING
ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0x23a2+84-0x23f1),
"\x52\x65\x70\x6c\x61\x63\x69\x6e\x67\x20\x6c\x6f\x67\x20\x64\x69\x73\x70\x61\x74\x63\x68\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x74\x6f\x20\x73\x79\x6e\x63\x68\x72\x6f\x6e\x6f\x75\x73"
);ReplacementFor_ReplacementFor_uninstallLogDispatchCallback<base::
ReplacementFor_ReplacementFor_AsyncLogDispatchCallback>(std::string(
"\x41\x73\x79\x6e\x63\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));ReplacementFor_ReplacementFor_installLogDispatchCallback<base::
ReplacementFor_ReplacementFor_DefaultLogDispatchCallback>(std::string(
"\x44\x65\x66\x61\x75\x6c\x74\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0x720+5014-0x1ab1),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x61\x73\x79\x6e\x63\x44\x69\x73\x70\x61\x74\x63\x68\x57\x6f\x72\x6b\x65\x72"
);base::ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_safeDelete(
ReplacementFor_ReplacementFor_m_asyncDispatchWorker);ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO(
(0x73b+1762-0xe18),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x61\x73\x79\x6e\x63\x4c\x6f\x67\x51\x75\x65\x75\x65"
);base::ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_safeDelete(
ReplacementFor_ReplacementFor_m_asyncLogQueue);
#endif  
ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0xc7b+2521-0x164f),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x48\x69\x74\x43\x6f\x75\x6e\x74\x65\x72\x73"
);base::ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_safeDelete(
ReplacementFor_ReplacementFor_m_registeredHitCounters);ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO(
(0x452+6603-0x1e18),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x4c\x6f\x67\x67\x65\x72\x73"
);base::ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_safeDelete(
ReplacementFor_ReplacementFor_m_registeredLoggers);ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO(
(0x1f6+7249-0x1e42),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x76\x52\x65\x67\x69\x73\x74\x72\x79"
);base::ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_safeDelete(
ReplacementFor_ReplacementFor_m_vRegistry);}bool ReplacementFor_ReplacementFor_Storage::
ReplacementFor_ReplacementFor_hasCustomFormatSpecifier(const char*
ReplacementFor_ReplacementFor_formatSpecifier){base::ReplacementFor_ReplacementFor_threading::
ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(
ReplacementFor_ReplacementFor_customFormatSpecifiersLock());return std::find(
ReplacementFor_ReplacementFor_m_customFormatSpecifiers.begin(),
ReplacementFor_ReplacementFor_m_customFormatSpecifiers.end(),ReplacementFor_ReplacementFor_formatSpecifier)!=
ReplacementFor_ReplacementFor_m_customFormatSpecifiers.end();}void ReplacementFor_ReplacementFor_Storage::
ReplacementFor_ReplacementFor_installCustomFormatSpecifier(const 
ReplacementFor_ReplacementFor_CustomFormatSpecifier&ReplacementFor_ReplacementFor_customFormatSpecifier){if(
ReplacementFor_ReplacementFor_hasCustomFormatSpecifier(ReplacementFor_ReplacementFor_customFormatSpecifier.
ReplacementFor_ReplacementFor_formatSpecifier())){return;}base::ReplacementFor_ReplacementFor_threading::
ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(
ReplacementFor_ReplacementFor_customFormatSpecifiersLock());
ReplacementFor_ReplacementFor_m_customFormatSpecifiers.push_back(
ReplacementFor_ReplacementFor_customFormatSpecifier);}bool ReplacementFor_ReplacementFor_Storage::
ReplacementFor_ReplacementFor_uninstallCustomFormatSpecifier(const char*
ReplacementFor_ReplacementFor_formatSpecifier){base::ReplacementFor_ReplacementFor_threading::
ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(
ReplacementFor_ReplacementFor_customFormatSpecifiersLock());std::vector<
ReplacementFor_ReplacementFor_CustomFormatSpecifier>::iterator ReplacementFor_ReplacementFor_it=std::find(
ReplacementFor_ReplacementFor_m_customFormatSpecifiers.begin(),
ReplacementFor_ReplacementFor_m_customFormatSpecifiers.end(),ReplacementFor_ReplacementFor_formatSpecifier);if
(ReplacementFor_ReplacementFor_it!=ReplacementFor_ReplacementFor_m_customFormatSpecifiers.end()&&strcmp(
ReplacementFor_ReplacementFor_formatSpecifier,ReplacementFor_ReplacementFor_it->ReplacementFor_ReplacementFor_formatSpecifier
())==(0x519+2331-0xe34)){ReplacementFor_ReplacementFor_m_customFormatSpecifiers.erase(
ReplacementFor_ReplacementFor_it);return true;}return false;}void ReplacementFor_ReplacementFor_Storage::
ReplacementFor_ReplacementFor_setApplicationArguments(int ReplacementFor_ReplacementFor_argc,char**
ReplacementFor_ReplacementFor_argv){ReplacementFor_ReplacementFor_m_commandLineArgs.ReplacementFor_ReplacementFor_setArgs(
ReplacementFor_ReplacementFor_argc,ReplacementFor_ReplacementFor_argv);ReplacementFor_ReplacementFor_m_vRegistry->
ReplacementFor_ReplacementFor_setFromArgs(ReplacementFor_ReplacementFor_commandLineArgs());
#if !defined(ReplacementFor_ReplacementFor_ELPP_DISABLE_LOG_FILE_FROM_ARG)
if(ReplacementFor_ReplacementFor_m_commandLineArgs.ReplacementFor_ReplacementFor_hasParamWithValue(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDefaultLogFileParam)){
ReplacementFor_ReplacementFor_Configurations c;c.ReplacementFor_ReplacementFor_setGlobally(
ReplacementFor_ReplacementFor_ConfigurationType::ReplacementFor_ReplacementFor_Filename,std::string(
ReplacementFor_ReplacementFor_m_commandLineArgs.ReplacementFor_ReplacementFor_getParamValue(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDefaultLogFileParam)));
ReplacementFor_ReplacementFor_registeredLoggers()->ReplacementFor_ReplacementFor_setDefaultConfigurations(c);
for(base::ReplacementFor_ReplacementFor_RegisteredLoggers::iterator ReplacementFor_ReplacementFor_it=
ReplacementFor_ReplacementFor_registeredLoggers()->begin();ReplacementFor_ReplacementFor_it!=
ReplacementFor_ReplacementFor_registeredLoggers()->end();++ReplacementFor_ReplacementFor_it){ReplacementFor_ReplacementFor_it
->second->ReplacementFor_ReplacementFor_configure(c);}}
#endif  
#if defined(ReplacementFor_ReplacementFor_ELPP_LOGGING_FLAGS_FROM_ARG)
if(ReplacementFor_ReplacementFor_m_commandLineArgs.ReplacementFor_ReplacementFor_hasParamWithValue(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kLoggingFlagsParam)){int 
ReplacementFor_ReplacementFor_userInput=atoi(ReplacementFor_ReplacementFor_m_commandLineArgs.
ReplacementFor_ReplacementFor_getParamValue(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kLoggingFlagsParam));if(ReplacementFor_ReplacementFor_ELPP_DEFAULT_LOGGING_FLAGS
==(0x10f+1314-0x631)){ReplacementFor_ReplacementFor_m_flags=ReplacementFor_ReplacementFor_userInput;}else{base
::ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_addFlag<base::type::
ReplacementFor_ReplacementFor_EnumType>(ReplacementFor_ReplacementFor_userInput,&ReplacementFor_ReplacementFor_m_flags);}}
#endif  
}}void ReplacementFor_ReplacementFor_LogDispatchCallback::ReplacementFor_ReplacementFor_handle(const 
ReplacementFor_ReplacementFor_LogDispatchData*data){
#if defined(ReplacementFor_ReplacementFor_ELPP_THREAD_SAFE)
base::ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock 
ReplacementFor_ReplacementFor_scopedLock(ReplacementFor_ReplacementFor_m_fileLocksMapLock);std::string 
ReplacementFor_ReplacementFor_filename=data->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_logger
()->ReplacementFor_ReplacementFor_typedConfigurations()->ReplacementFor_ReplacementFor_filename(data->
ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_level());auto lock=
ReplacementFor_ReplacementFor_m_fileLocks.find(ReplacementFor_ReplacementFor_filename);if(lock==
ReplacementFor_ReplacementFor_m_fileLocks.end()){ReplacementFor_ReplacementFor_m_fileLocks.emplace(std::
make_pair(ReplacementFor_ReplacementFor_filename,std::unique_ptr<base::ReplacementFor_ReplacementFor_threading
::Mutex>(new base::ReplacementFor_ReplacementFor_threading::Mutex)));}
#endif
}base::ReplacementFor_ReplacementFor_threading::Mutex&ReplacementFor_ReplacementFor_LogDispatchCallback::
ReplacementFor_ReplacementFor_fileHandle(const ReplacementFor_ReplacementFor_LogDispatchData*data){auto 
ReplacementFor_ReplacementFor_it=ReplacementFor_ReplacementFor_m_fileLocks.find(data->
ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_logger()->
ReplacementFor_ReplacementFor_typedConfigurations()->ReplacementFor_ReplacementFor_filename(data->
ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_level()));return*(ReplacementFor_ReplacementFor_it
->second.get());}namespace base{void ReplacementFor_ReplacementFor_DefaultLogDispatchCallback::
ReplacementFor_ReplacementFor_handle(const ReplacementFor_ReplacementFor_LogDispatchData*data){
#if defined(ReplacementFor_ReplacementFor_ELPP_THREAD_SAFE)
ReplacementFor_ReplacementFor_LogDispatchCallback::ReplacementFor_ReplacementFor_handle(data);base::
ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(
ReplacementFor_ReplacementFor_fileHandle(data));
#endif
ReplacementFor_ReplacementFor_m_data=data;ReplacementFor_ReplacementFor_dispatch(ReplacementFor_ReplacementFor_m_data->
ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_logger()->ReplacementFor_ReplacementFor_logBuilder(
)->ReplacementFor_ReplacementFor_build(ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage(),
ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_dispatchAction()==base::
ReplacementFor_ReplacementFor_DispatchAction::ReplacementFor_ReplacementFor_NormalLog));}void 
ReplacementFor_ReplacementFor_DefaultLogDispatchCallback::ReplacementFor_ReplacementFor_dispatch(base::type::
ReplacementFor_ReplacementFor_string_t&&ReplacementFor_ReplacementFor_logLine){if(ReplacementFor_ReplacementFor_m_data->
ReplacementFor_ReplacementFor_dispatchAction()==base::ReplacementFor_ReplacementFor_DispatchAction::
ReplacementFor_ReplacementFor_NormalLog){if(ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()
->ReplacementFor_ReplacementFor_logger()->ReplacementFor_ReplacementFor_m_typedConfigurations->
ReplacementFor_ReplacementFor_toFile(ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->
ReplacementFor_ReplacementFor_level())){base::type::ReplacementFor_ReplacementFor_fstream_t*fs=
ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_logger()->
ReplacementFor_ReplacementFor_m_typedConfigurations->ReplacementFor_ReplacementFor_fileStream(
ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_level());if(
fs!=nullptr){fs->write(ReplacementFor_ReplacementFor_logLine.c_str(),ReplacementFor_ReplacementFor_logLine.
size());if(fs->fail()){ReplacementFor_ReplacementFor_ELPP_INTERNAL_ERROR(
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x6c\x6f\x67\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x5b"
<<ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_logger()->
ReplacementFor_ReplacementFor_m_typedConfigurations->ReplacementFor_ReplacementFor_filename(
ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_level())<<
"\x5d\x2e" "\n"<<
"\x46\x65\x77\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x72\x65\x61\x73\x6f\x6e\x73\x20\x28\x63\x6f\x75\x6c\x64\x20\x62\x65\x20\x73\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x65\x6c\x73\x65\x29\x3a" "\n"
<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x20\x64\x65\x6e\x69\x65\x64" "\n"
<<"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x66\x75\x6c\x6c" "\n"<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x69\x73\x20\x6e\x6f\x74\x20\x77\x72\x69\x74\x61\x62\x6c\x65"
,true);}else{if(ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(
ReplacementFor_ReplacementFor_LoggingFlag::ReplacementFor_ReplacementFor_ImmediateFlush)||(
ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_logger()->
ReplacementFor_ReplacementFor_isFlushNeeded(ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()
->ReplacementFor_ReplacementFor_level()))){ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->
ReplacementFor_ReplacementFor_logger()->flush(ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage(
)->ReplacementFor_ReplacementFor_level(),fs);}}}else{ReplacementFor_ReplacementFor_ELPP_INTERNAL_ERROR(
"\x4c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x5b"<<
ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_convertToString(ReplacementFor_ReplacementFor_m_data
->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_level())<<"\x5d\x20"<<
"\x68\x61\x73\x20\x6e\x6f\x74\x20\x62\x65\x65\x6e\x20\x63\x6f\x6e\x66\x20\x62\x75\x74\x20\x5b\x54\x4f\x5f\x46\x49\x4c\x45\x5d\x20\x69\x73\x20\x63\x6f\x6e\x66\x64\x20\x74\x6f\x20\x54\x52\x55\x45\x2e\x20\x5b\x4c\x6f\x67\x67\x65\x72\x20\x49\x44\x3a\x20"
<<ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_logger()->
id()<<"\x5d",false);}}if(ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->
ReplacementFor_ReplacementFor_logger()->ReplacementFor_ReplacementFor_m_typedConfigurations->
ReplacementFor_ReplacementFor_toStandardOutput(ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage
()->ReplacementFor_ReplacementFor_level())){if(ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(
ReplacementFor_ReplacementFor_LoggingFlag::ReplacementFor_ReplacementFor_ColoredTerminalOutput))
ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_logger()->
ReplacementFor_ReplacementFor_logBuilder()->ReplacementFor_ReplacementFor_convertToColoredOutput(&
ReplacementFor_ReplacementFor_logLine,ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->
ReplacementFor_ReplacementFor_level());ReplacementFor_ReplacementFor_ELPP_COUT<<ReplacementFor_ReplacementFor_ELPP_COUT_LINE(
ReplacementFor_ReplacementFor_logLine);}}
#if defined(ReplacementFor_ReplacementFor_ELPP_SYSLOG)
else if(ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_dispatchAction()==base::
ReplacementFor_ReplacementFor_DispatchAction::SysLog){int ReplacementFor_ReplacementFor_sysLogPriority=
(0x7ba+7561-0x2543);if(ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->
ReplacementFor_ReplacementFor_level()==Level::ReplacementFor_ReplacementFor_Fatal)
ReplacementFor_ReplacementFor_sysLogPriority=LOG_EMERG;else if(ReplacementFor_ReplacementFor_m_data->
ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_level()==Level::Error)
ReplacementFor_ReplacementFor_sysLogPriority=LOG_ERR;else if(ReplacementFor_ReplacementFor_m_data->
ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_level()==Level::
ReplacementFor_ReplacementFor_Warning)ReplacementFor_ReplacementFor_sysLogPriority=LOG_WARNING;else if(
ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_level()==
Level::ReplacementFor_ReplacementFor_Info)ReplacementFor_ReplacementFor_sysLogPriority=LOG_INFO;else if(
ReplacementFor_ReplacementFor_m_data->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_level()==
Level::ReplacementFor_ReplacementFor_Debug)ReplacementFor_ReplacementFor_sysLogPriority=LOG_DEBUG;else 
ReplacementFor_ReplacementFor_sysLogPriority=LOG_NOTICE;
#  if defined(ReplacementFor_ReplacementFor_ELPP_UNICODE)
char*line=base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_wcharPtrToCharPtr(
ReplacementFor_ReplacementFor_logLine.c_str());syslog(ReplacementFor_ReplacementFor_sysLogPriority,"\x25\x73",
line);free(line);
#  else
syslog(ReplacementFor_ReplacementFor_sysLogPriority,"\x25\x73",ReplacementFor_ReplacementFor_logLine.c_str());
#  endif
}
#endif  
}
#if ReplacementFor_ReplacementFor_ELPP_ASYNC_LOGGING
void ReplacementFor_ReplacementFor_AsyncLogDispatchCallback::ReplacementFor_ReplacementFor_handle(const 
ReplacementFor_ReplacementFor_LogDispatchData*data){base::type::ReplacementFor_ReplacementFor_string_t 
ReplacementFor_ReplacementFor_logLine=data->ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_logger(
)->ReplacementFor_ReplacementFor_logBuilder()->ReplacementFor_ReplacementFor_build(data->
ReplacementFor_ReplacementFor_logMessage(),data->ReplacementFor_ReplacementFor_dispatchAction()==base::
ReplacementFor_ReplacementFor_DispatchAction::ReplacementFor_ReplacementFor_NormalLog);if(data->
ReplacementFor_ReplacementFor_dispatchAction()==base::ReplacementFor_ReplacementFor_DispatchAction::
ReplacementFor_ReplacementFor_NormalLog&&data->ReplacementFor_ReplacementFor_logMessage()->
ReplacementFor_ReplacementFor_logger()->ReplacementFor_ReplacementFor_typedConfigurations()->
ReplacementFor_ReplacementFor_toStandardOutput(data->ReplacementFor_ReplacementFor_logMessage()->
ReplacementFor_ReplacementFor_level())){if(ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(
ReplacementFor_ReplacementFor_LoggingFlag::ReplacementFor_ReplacementFor_ColoredTerminalOutput))data->
ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_logger()->ReplacementFor_ReplacementFor_logBuilder(
)->ReplacementFor_ReplacementFor_convertToColoredOutput(&ReplacementFor_ReplacementFor_logLine,data->
ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_level());ReplacementFor_ReplacementFor_ELPP_COUT<<
ReplacementFor_ReplacementFor_ELPP_COUT_LINE(ReplacementFor_ReplacementFor_logLine);}if(data->
ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_logger()->
ReplacementFor_ReplacementFor_typedConfigurations()->ReplacementFor_ReplacementFor_toFile(data->
ReplacementFor_ReplacementFor_logMessage()->ReplacementFor_ReplacementFor_level())){ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_asyncLogQueue()->push(ReplacementFor_ReplacementFor_AsyncLogItem(*(data->
ReplacementFor_ReplacementFor_logMessage()),*data,ReplacementFor_ReplacementFor_logLine));}}
ReplacementFor_ReplacementFor_AsyncDispatchWorker::ReplacementFor_ReplacementFor_AsyncDispatchWorker(){
ReplacementFor_ReplacementFor_setContinueRunning(false);}ReplacementFor_ReplacementFor_AsyncDispatchWorker::~
ReplacementFor_ReplacementFor_AsyncDispatchWorker(){ReplacementFor_ReplacementFor_setContinueRunning(false);
ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0x104+4429-0x124b),
"\x53\x74\x6f\x70\x70\x69\x6e\x67\x20\x64\x69\x73\x70\x61\x74\x63\x68\x20\x77\x6f\x72\x6b\x65\x72\x20\x2d\x20\x43\x6c\x65\x61\x6e\x69\x6e\x67\x20\x6c\x6f\x67\x20\x71\x75\x65\x75\x65"
);ReplacementFor_ReplacementFor_clean();ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0x21c+9300-0x266a),
"\x4c\x6f\x67\x20\x71\x75\x65\x75\x65\x20\x63\x6c\x65\x61\x6e\x65\x64");}bool 
ReplacementFor_ReplacementFor_AsyncDispatchWorker::ReplacementFor_ReplacementFor_clean(void){std::mutex m;std
::unique_lock<std::mutex>ReplacementFor_ReplacementFor_lk(m);ReplacementFor_ReplacementFor_cv.wait(
ReplacementFor_ReplacementFor_lk,[]{return!ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_asyncLogQueue()
->empty();});ReplacementFor_ReplacementFor_emptyQueue();ReplacementFor_ReplacementFor_lk.unlock();
ReplacementFor_ReplacementFor_cv.notify_one();return ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_asyncLogQueue()->empty();}void ReplacementFor_ReplacementFor_AsyncDispatchWorker
::ReplacementFor_ReplacementFor_emptyQueue(void){while(!ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_asyncLogQueue()->empty()){ReplacementFor_ReplacementFor_AsyncLogItem data=
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_asyncLogQueue()->next();
ReplacementFor_ReplacementFor_handle(&data);base::ReplacementFor_ReplacementFor_threading::
ReplacementFor_ReplacementFor_msleep((0xe4a+2405-0x174b));}}void 
ReplacementFor_ReplacementFor_AsyncDispatchWorker::ReplacementFor_ReplacementFor_start(void){base::
ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_msleep((0x1aeb+5772-0x1def));
ReplacementFor_ReplacementFor_setContinueRunning(true);std::thread ReplacementFor_ReplacementFor_t1(&
ReplacementFor_ReplacementFor_AsyncDispatchWorker::ReplacementFor_ReplacementFor_run,this);ReplacementFor_ReplacementFor_t1.
join();}void ReplacementFor_ReplacementFor_AsyncDispatchWorker::ReplacementFor_ReplacementFor_handle(
ReplacementFor_ReplacementFor_AsyncLogItem*ReplacementFor_ReplacementFor_logItem){
ReplacementFor_ReplacementFor_LogDispatchData*data=ReplacementFor_ReplacementFor_logItem->data();
ReplacementFor_ReplacementFor_LogMessage*ReplacementFor_ReplacementFor_logMessage=ReplacementFor_ReplacementFor_logItem->
ReplacementFor_ReplacementFor_logMessage();ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_logger=
ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_logger();base::
ReplacementFor_ReplacementFor_TypedConfigurations*ReplacementFor_ReplacementFor_conf=ReplacementFor_ReplacementFor_logger->
ReplacementFor_ReplacementFor_typedConfigurations();base::type::ReplacementFor_ReplacementFor_string_t 
ReplacementFor_ReplacementFor_logLine=ReplacementFor_ReplacementFor_logItem->ReplacementFor_ReplacementFor_logLine();if(data
->ReplacementFor_ReplacementFor_dispatchAction()==base::ReplacementFor_ReplacementFor_DispatchAction::
ReplacementFor_ReplacementFor_NormalLog){if(ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_toFile(
ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_level())){base::type::
ReplacementFor_ReplacementFor_fstream_t*fs=ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_fileStream(
ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_level());if(fs!=nullptr){fs->write(
ReplacementFor_ReplacementFor_logLine.c_str(),ReplacementFor_ReplacementFor_logLine.size());if(fs->fail()){
ReplacementFor_ReplacementFor_ELPP_INTERNAL_ERROR(
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x6c\x6f\x67\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x5b"
<<ReplacementFor_ReplacementFor_conf->ReplacementFor_ReplacementFor_filename(ReplacementFor_ReplacementFor_logMessage->
ReplacementFor_ReplacementFor_level())<<"\x5d\x2e" "\n"<<
"\x46\x65\x77\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x72\x65\x61\x73\x6f\x6e\x73\x20\x28\x63\x6f\x75\x6c\x64\x20\x62\x65\x20\x73\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x65\x6c\x73\x65\x29\x3a" "\n"
<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x20\x64\x65\x6e\x69\x65\x64" "\n"
<<"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x66\x75\x6c\x6c" "\n"<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x69\x73\x20\x6e\x6f\x74\x20\x77\x72\x69\x74\x61\x62\x6c\x65"
,true);}else{if(ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(
ReplacementFor_ReplacementFor_LoggingFlag::ReplacementFor_ReplacementFor_ImmediateFlush)||(
ReplacementFor_ReplacementFor_logger->ReplacementFor_ReplacementFor_isFlushNeeded(ReplacementFor_ReplacementFor_logMessage->
ReplacementFor_ReplacementFor_level()))){ReplacementFor_ReplacementFor_logger->flush(ReplacementFor_ReplacementFor_logMessage
->ReplacementFor_ReplacementFor_level(),fs);}}}else{ReplacementFor_ReplacementFor_ELPP_INTERNAL_ERROR(
"\x4c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x5b"<<
ReplacementFor_ReplacementFor_LevelHelper::ReplacementFor_ReplacementFor_convertToString(
ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_level())<<"\x5d\x20"<<
"\x68\x61\x73\x20\x6e\x6f\x74\x20\x62\x65\x65\x6e\x20\x63\x6f\x6e\x66\x20\x62\x75\x74\x20\x5b\x54\x4f\x5f\x46\x49\x4c\x45\x5d\x20\x69\x73\x20\x63\x6f\x6e\x66\x64\x20\x74\x6f\x20\x54\x52\x55\x45\x2e\x20\x5b\x4c\x6f\x67\x67\x65\x72\x20\x49\x44\x3a\x20"
<<ReplacementFor_ReplacementFor_logger->id()<<"\x5d",false);}}}
#  if defined(ReplacementFor_ReplacementFor_ELPP_SYSLOG)
else if(data->ReplacementFor_ReplacementFor_dispatchAction()==base::
ReplacementFor_ReplacementFor_DispatchAction::SysLog){int ReplacementFor_ReplacementFor_sysLogPriority=
(0x1eab+163-0x1f4e);if(ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_level()==Level
::ReplacementFor_ReplacementFor_Fatal)ReplacementFor_ReplacementFor_sysLogPriority=LOG_EMERG;else if(
ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_level()==Level::Error)
ReplacementFor_ReplacementFor_sysLogPriority=LOG_ERR;else if(ReplacementFor_ReplacementFor_logMessage->
ReplacementFor_ReplacementFor_level()==Level::ReplacementFor_ReplacementFor_Warning)
ReplacementFor_ReplacementFor_sysLogPriority=LOG_WARNING;else if(ReplacementFor_ReplacementFor_logMessage->
ReplacementFor_ReplacementFor_level()==Level::ReplacementFor_ReplacementFor_Info)ReplacementFor_ReplacementFor_sysLogPriority
=LOG_INFO;else if(ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_level()==Level::
ReplacementFor_ReplacementFor_Debug)ReplacementFor_ReplacementFor_sysLogPriority=LOG_DEBUG;else 
ReplacementFor_ReplacementFor_sysLogPriority=LOG_NOTICE;
#      if defined(ReplacementFor_ReplacementFor_ELPP_UNICODE)
char*line=base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_wcharPtrToCharPtr(
ReplacementFor_ReplacementFor_logLine.c_str());syslog(ReplacementFor_ReplacementFor_sysLogPriority,"\x25\x73",
line);free(line);
#      else
syslog(ReplacementFor_ReplacementFor_sysLogPriority,"\x25\x73",ReplacementFor_ReplacementFor_logLine.c_str());
#      endif
}
#  endif  
}void ReplacementFor_ReplacementFor_AsyncDispatchWorker::ReplacementFor_ReplacementFor_run(void){while(
ReplacementFor_ReplacementFor_continueRunning()){ReplacementFor_ReplacementFor_emptyQueue();base::
ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_msleep((0x12f4+1134-0x1758));}}
#endif  
base::type::ReplacementFor_ReplacementFor_string_t ReplacementFor_ReplacementFor_DefaultLogBuilder::
ReplacementFor_ReplacementFor_build(const ReplacementFor_ReplacementFor_LogMessage*ReplacementFor_ReplacementFor_logMessage,
bool ReplacementFor_ReplacementFor_appendNewLine)const{base::ReplacementFor_ReplacementFor_TypedConfigurations
*tc=ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_logger()->
ReplacementFor_ReplacementFor_typedConfigurations();const base::ReplacementFor_ReplacementFor_LogFormat*
ReplacementFor_ReplacementFor_logFormat=&tc->ReplacementFor_ReplacementFor_logFormat(ReplacementFor_ReplacementFor_logMessage
->ReplacementFor_ReplacementFor_level());base::type::ReplacementFor_ReplacementFor_string_t 
ReplacementFor_ReplacementFor_logLine=ReplacementFor_ReplacementFor_logFormat->format();char 
ReplacementFor_ReplacementFor_buff[base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSourceFilenameMaxLength+base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSourceLineMaxLength]="";const char*ReplacementFor_ReplacementFor_bufLim=
ReplacementFor_ReplacementFor_buff+sizeof(ReplacementFor_ReplacementFor_buff);if(ReplacementFor_ReplacementFor_logFormat->
ReplacementFor_ReplacementFor_hasFlag(base::ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_AppName)
){base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_logLine,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kAppNameFormatSpecifier,ReplacementFor_ReplacementFor_logMessage->
ReplacementFor_ReplacementFor_logger()->ReplacementFor_ReplacementFor_parentApplicationName());}if(
ReplacementFor_ReplacementFor_logFormat->ReplacementFor_ReplacementFor_hasFlag(base::
ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_ThreadId)){base::ReplacementFor_ReplacementFor_utils
::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_logLine,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kThreadIdFormatSpecifier,
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_getThreadName(base::ReplacementFor_ReplacementFor_threading
::ReplacementFor_ReplacementFor_getCurrentThreadId()));}if(ReplacementFor_ReplacementFor_logFormat->
ReplacementFor_ReplacementFor_hasFlag(base::ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_DateTime
)){base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_logLine,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kDateTimeFormatSpecifier,base::ReplacementFor_ReplacementFor_utils::
ReplacementFor_ReplacementFor_DateTime::ReplacementFor_ReplacementFor_getDateTime(ReplacementFor_ReplacementFor_logFormat->
ReplacementFor_ReplacementFor_dateTimeFormat().c_str(),&tc->ReplacementFor_ReplacementFor_subsecondPrecision(
ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_level())));}if(
ReplacementFor_ReplacementFor_logFormat->ReplacementFor_ReplacementFor_hasFlag(base::
ReplacementFor_ReplacementFor_FormatFlags::Function)){base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_logLine,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kLogFunctionFormatSpecifier,
ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_func());}if(ReplacementFor_ReplacementFor_logFormat->
ReplacementFor_ReplacementFor_hasFlag(base::ReplacementFor_ReplacementFor_FormatFlags::File)){base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_clearBuff(ReplacementFor_ReplacementFor_buff,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSourceFilenameMaxLength);base::
ReplacementFor_ReplacementFor_utils::File::ReplacementFor_ReplacementFor_buildStrippedFilename(
ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_file().c_str(),ReplacementFor_ReplacementFor_buff);
base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_logLine,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kLogFileFormatSpecifier,std::string(ReplacementFor_ReplacementFor_buff));}if(
ReplacementFor_ReplacementFor_logFormat->ReplacementFor_ReplacementFor_hasFlag(base::
ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_FileBase)){base::ReplacementFor_ReplacementFor_utils
::Str::ReplacementFor_ReplacementFor_clearBuff(ReplacementFor_ReplacementFor_buff,base::ReplacementFor_ReplacementFor_consts
::ReplacementFor_ReplacementFor_kSourceFilenameMaxLength);base::ReplacementFor_ReplacementFor_utils::File::
ReplacementFor_ReplacementFor_buildBaseFilename(ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_file(
),ReplacementFor_ReplacementFor_buff);base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_logLine,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kLogFileBaseFormatSpecifier,std::string(
ReplacementFor_ReplacementFor_buff));}if(ReplacementFor_ReplacementFor_logFormat->ReplacementFor_ReplacementFor_hasFlag(base
::ReplacementFor_ReplacementFor_FormatFlags::Line)){char*buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_clearBuff(ReplacementFor_ReplacementFor_buff,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSourceLineMaxLength);buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_convertAndAddToBuff(ReplacementFor_ReplacementFor_logMessage->line(),base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSourceLineMaxLength,buf,
ReplacementFor_ReplacementFor_bufLim,false);base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_replaceFirstWithEscape(ReplacementFor_ReplacementFor_logLine,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kLogLineFormatSpecifier,std::string(
ReplacementFor_ReplacementFor_buff));}if(ReplacementFor_ReplacementFor_logFormat->ReplacementFor_ReplacementFor_hasFlag(base
::ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_Location)){char*buf=base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_clearBuff(ReplacementFor_ReplacementFor_buff,base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSourceFilenameMaxLength+base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kSourceLineMaxLength);base::
ReplacementFor_ReplacementFor_utils::File::ReplacementFor_ReplacementFor_buildStrippedFilename(
ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_file().c_str(),ReplacementFor_ReplacementFor_buff);
buf=base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_addToBuff(
ReplacementFor_ReplacementFor_buff,buf,ReplacementFor_ReplacementFor_bufLim);buf=base::ReplacementFor_ReplacementFor_utils::
Str::ReplacementFor_ReplacementFor_addToBuff("\x3a",buf,ReplacementFor_ReplacementFor_bufLim);buf=base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_convertAndAddToBuff(
ReplacementFor_ReplacementFor_logMessage->line(),base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kSourceLineMaxLength,buf,ReplacementFor_ReplacementFor_bufLim,false);base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_logLine,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kLogLocationFormatSpecifier,std::string(ReplacementFor_ReplacementFor_buff));}if
(ReplacementFor_ReplacementFor_logMessage->ReplacementFor_ReplacementFor_level()==Level::
ReplacementFor_ReplacementFor_Verbose&&ReplacementFor_ReplacementFor_logFormat->ReplacementFor_ReplacementFor_hasFlag(base::
ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_VerboseLevel)){char*buf=base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_clearBuff(ReplacementFor_ReplacementFor_buff,
(0x1907+1763-0x1fe9));buf=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_convertAndAddToBuff(ReplacementFor_ReplacementFor_logMessage->
ReplacementFor_ReplacementFor_verboseLevel(),(0x13dd+3562-0x21c6),buf,ReplacementFor_ReplacementFor_bufLim,
false);base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_logLine,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kVerboseLevelFormatSpecifier,std::string(ReplacementFor_ReplacementFor_buff));}
if(ReplacementFor_ReplacementFor_logFormat->ReplacementFor_ReplacementFor_hasFlag(base::
ReplacementFor_ReplacementFor_FormatFlags::ReplacementFor_ReplacementFor_LogMessage)){base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_logLine,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kMessageFormatSpecifier,ReplacementFor_ReplacementFor_logMessage->message());}
#if !defined(ReplacementFor_ReplacementFor_ELPP_DISABLE_CUSTOM_FORMAT_SPECIFIERS)
ReplacementFor_ReplacementFor_el::base::ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock 
ReplacementFor_ReplacementFor_lock_(ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_customFormatSpecifiersLock());ReplacementFor_ReplacementFor_ELPP_UNUSED(
ReplacementFor_ReplacementFor_lock_);for(std::vector<ReplacementFor_ReplacementFor_CustomFormatSpecifier>::
const_iterator ReplacementFor_ReplacementFor_it=ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_customFormatSpecifiers()->begin();ReplacementFor_ReplacementFor_it!=
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_customFormatSpecifiers()->end();++
ReplacementFor_ReplacementFor_it){std::string fs(ReplacementFor_ReplacementFor_it->
ReplacementFor_ReplacementFor_formatSpecifier());base::type::ReplacementFor_ReplacementFor_string_t 
ReplacementFor_ReplacementFor_wcsFormatSpecifier(fs.begin(),fs.end());base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_replaceFirstWithEscape(
ReplacementFor_ReplacementFor_logLine,ReplacementFor_ReplacementFor_wcsFormatSpecifier,ReplacementFor_ReplacementFor_it->
ReplacementFor_ReplacementFor_resolver()(ReplacementFor_ReplacementFor_logMessage));}
#endif  
if(ReplacementFor_ReplacementFor_appendNewLine)ReplacementFor_ReplacementFor_logLine+=
ReplacementFor_ReplacementFor_ELPP_LITERAL("\n");return ReplacementFor_ReplacementFor_logLine;}void 
ReplacementFor_ReplacementFor_LogDispatcher::ReplacementFor_ReplacementFor_dispatch(void){if(
ReplacementFor_ReplacementFor_m_proceed&&ReplacementFor_ReplacementFor_m_dispatchAction==base::
ReplacementFor_ReplacementFor_DispatchAction::None){ReplacementFor_ReplacementFor_m_proceed=false;}if(!
ReplacementFor_ReplacementFor_m_proceed){return;}
#ifndef ReplacementFor_ReplacementFor_ELPP_NO_GLOBAL_LOCK
base::ReplacementFor_ReplacementFor_threading::ReplacementFor_ReplacementFor_ScopedLock 
ReplacementFor_ReplacementFor_scopedLock(ReplacementFor_ReplacementFor_ELPP->lock());
#endif
base::ReplacementFor_ReplacementFor_TypedConfigurations*tc=ReplacementFor_ReplacementFor_m_logMessage->
ReplacementFor_ReplacementFor_logger()->ReplacementFor_ReplacementFor_m_typedConfigurations;if(
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_LoggingFlag::
ReplacementFor_ReplacementFor_StrictLogFileSizeCheck)){tc->ReplacementFor_ReplacementFor_validateFileRolling(
ReplacementFor_ReplacementFor_m_logMessage->ReplacementFor_ReplacementFor_level(),ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_preRollOutCallback());}ReplacementFor_ReplacementFor_LogDispatchCallback*
ReplacementFor_ReplacementFor_callback=nullptr;ReplacementFor_ReplacementFor_LogDispatchData data;for(const 
std::pair<std::string,base::type::ReplacementFor_ReplacementFor_LogDispatchCallbackPtr>&
ReplacementFor_ReplacementFor_h:ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_m_logDispatchCallbacks){
ReplacementFor_ReplacementFor_callback=ReplacementFor_ReplacementFor_h.second.get();if(ReplacementFor_ReplacementFor_callback
!=nullptr&&ReplacementFor_ReplacementFor_callback->ReplacementFor_ReplacementFor_enabled()){data.
ReplacementFor_ReplacementFor_setLogMessage(ReplacementFor_ReplacementFor_m_logMessage);data.
ReplacementFor_ReplacementFor_setDispatchAction(ReplacementFor_ReplacementFor_m_dispatchAction);
ReplacementFor_ReplacementFor_callback->ReplacementFor_ReplacementFor_handle(&data);}}}void 
ReplacementFor_ReplacementFor_MessageBuilder::ReplacementFor_ReplacementFor_initialize(ReplacementFor_ReplacementFor_Logger*
ReplacementFor_ReplacementFor_logger){ReplacementFor_ReplacementFor_m_logger=ReplacementFor_ReplacementFor_logger;
ReplacementFor_ReplacementFor_m_containerLogSeperator=ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_LoggingFlag::
ReplacementFor_ReplacementFor_NewLineForContainer)?ReplacementFor_ReplacementFor_ELPP_LITERAL(
"\n" "\x20\x20\x20\x20"):ReplacementFor_ReplacementFor_ELPP_LITERAL("\x2c\x20");}
ReplacementFor_ReplacementFor_MessageBuilder&ReplacementFor_ReplacementFor_MessageBuilder::operator<<(const 
wchar_t*msg){if(msg==nullptr){ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_stream()<<
base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kNullPointer;return*this;}
#  if defined(ReplacementFor_ReplacementFor_ELPP_UNICODE)
ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_stream()<<msg;
#  else
char*ReplacementFor_ReplacementFor_buff_=base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_wcharPtrToCharPtr(msg);ReplacementFor_ReplacementFor_m_logger->
ReplacementFor_ReplacementFor_stream()<<ReplacementFor_ReplacementFor_buff_;free(ReplacementFor_ReplacementFor_buff_);
#  endif
if(ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_LoggingFlag::
ReplacementFor_ReplacementFor_AutoSpacing)){ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_stream()<<
"\x20";}return*this;}ReplacementFor_ReplacementFor_Writer&ReplacementFor_ReplacementFor_Writer::construct(
ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_logger,bool ReplacementFor_ReplacementFor_needLock){
ReplacementFor_ReplacementFor_m_logger=ReplacementFor_ReplacementFor_logger;ReplacementFor_ReplacementFor_initializeLogger(
ReplacementFor_ReplacementFor_logger->id(),false,ReplacementFor_ReplacementFor_needLock);
ReplacementFor_ReplacementFor_m_messageBuilder.ReplacementFor_ReplacementFor_initialize(
ReplacementFor_ReplacementFor_m_logger);return*this;}ReplacementFor_ReplacementFor_Writer&
ReplacementFor_ReplacementFor_Writer::construct(int count,const char*ReplacementFor_ReplacementFor_loggerIds,
...){if(ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_LoggingFlag::
ReplacementFor_ReplacementFor_MultiLoggerSupport)){va_list ReplacementFor_ReplacementFor_loggersList;va_start(
ReplacementFor_ReplacementFor_loggersList,ReplacementFor_ReplacementFor_loggerIds);const char*id=
ReplacementFor_ReplacementFor_loggerIds;ReplacementFor_ReplacementFor_m_loggerIds.reserve(count);for(int i=
(0x610+5743-0x1c7f);i<count;++i){ReplacementFor_ReplacementFor_m_loggerIds.push_back(std::
string(id));id=va_arg(ReplacementFor_ReplacementFor_loggersList,const char*);}va_end(
ReplacementFor_ReplacementFor_loggersList);ReplacementFor_ReplacementFor_initializeLogger(
ReplacementFor_ReplacementFor_m_loggerIds.at((0x92d+6174-0x214b)));}else{
ReplacementFor_ReplacementFor_initializeLogger(std::string(ReplacementFor_ReplacementFor_loggerIds));}
ReplacementFor_ReplacementFor_m_messageBuilder.ReplacementFor_ReplacementFor_initialize(
ReplacementFor_ReplacementFor_m_logger);return*this;}void ReplacementFor_ReplacementFor_Writer::
ReplacementFor_ReplacementFor_initializeLogger(const std::string&ReplacementFor_ReplacementFor_loggerId,bool 
ReplacementFor_ReplacementFor_lookup,bool ReplacementFor_ReplacementFor_needLock){if(ReplacementFor_ReplacementFor_lookup){
ReplacementFor_ReplacementFor_m_logger=ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_registeredLoggers()
->get(ReplacementFor_ReplacementFor_loggerId,ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(
ReplacementFor_ReplacementFor_LoggingFlag::ReplacementFor_ReplacementFor_CreateLoggerAutomatically));}if(
ReplacementFor_ReplacementFor_m_logger==nullptr){{if(!ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_registeredLoggers()->ReplacementFor_ReplacementFor_has(std::string(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDefaultLoggerId))){ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_registeredLoggers()->get(std::string(base::ReplacementFor_ReplacementFor_consts
::ReplacementFor_ReplacementFor_kDefaultLoggerId));}}ReplacementFor_ReplacementFor_Writer(Level::
ReplacementFor_ReplacementFor_Debug,ReplacementFor_ReplacementFor_m_file,ReplacementFor_ReplacementFor_m_line,
ReplacementFor_ReplacementFor_m_func).construct((0x1923+3338-0x262c),base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDefaultLoggerId)<<
"\x4c\x6f\x67\x67\x65\x72\x20\x5b"<<ReplacementFor_ReplacementFor_loggerId<<
"\x5d\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x20\x79\x65\x74\x21"
;ReplacementFor_ReplacementFor_m_proceed=false;}else{if(ReplacementFor_ReplacementFor_needLock){
ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_acquireLock();}if(ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_LoggingFlag::
ReplacementFor_ReplacementFor_HierarchicalLogging)){ReplacementFor_ReplacementFor_m_proceed=
ReplacementFor_ReplacementFor_m_level==Level::ReplacementFor_ReplacementFor_Verbose?ReplacementFor_ReplacementFor_m_logger->
ReplacementFor_ReplacementFor_enabled(ReplacementFor_ReplacementFor_m_level):ReplacementFor_ReplacementFor_LevelHelper::
ReplacementFor_ReplacementFor_castToInt(ReplacementFor_ReplacementFor_m_level)>=ReplacementFor_ReplacementFor_LevelHelper::
ReplacementFor_ReplacementFor_castToInt(ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_m_loggingLevel);}
else{ReplacementFor_ReplacementFor_m_proceed=ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_enabled(
ReplacementFor_ReplacementFor_m_level);}}}void ReplacementFor_ReplacementFor_Writer::
ReplacementFor_ReplacementFor_processDispatch(){
#if ReplacementFor_ReplacementFor_ELPP_LOGGING_ENABLED
if(ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_LoggingFlag::
ReplacementFor_ReplacementFor_MultiLoggerSupport)){bool ReplacementFor_ReplacementFor_firstDispatched=false;
base::type::ReplacementFor_ReplacementFor_string_t ReplacementFor_ReplacementFor_logMessage;std::size_t i=
(0x2d9+7007-0x1e38);do{if(ReplacementFor_ReplacementFor_m_proceed){if(
ReplacementFor_ReplacementFor_firstDispatched){ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_stream()
<<ReplacementFor_ReplacementFor_logMessage;}else{ReplacementFor_ReplacementFor_firstDispatched=true;if(
ReplacementFor_ReplacementFor_m_loggerIds.size()>(0xeca+1540-0x14cd)){ReplacementFor_ReplacementFor_logMessage
=ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_stream().str();}}
ReplacementFor_ReplacementFor_triggerDispatch();}else if(ReplacementFor_ReplacementFor_m_logger!=nullptr){
ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_stream().str(ReplacementFor_ReplacementFor_ELPP_LITERAL
(""));ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_releaseLock();}if(i+
(0xc4d+499-0xe3f)<ReplacementFor_ReplacementFor_m_loggerIds.size()){
ReplacementFor_ReplacementFor_initializeLogger(ReplacementFor_ReplacementFor_m_loggerIds.at(i+
(0x538+1118-0x995)));}}while(++i<ReplacementFor_ReplacementFor_m_loggerIds.size());}else{if(
ReplacementFor_ReplacementFor_m_proceed){ReplacementFor_ReplacementFor_triggerDispatch();}else if(
ReplacementFor_ReplacementFor_m_logger!=nullptr){ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_stream
().str(ReplacementFor_ReplacementFor_ELPP_LITERAL(""));ReplacementFor_ReplacementFor_m_logger->
ReplacementFor_ReplacementFor_releaseLock();}}
#else
if(ReplacementFor_ReplacementFor_m_logger!=nullptr){ReplacementFor_ReplacementFor_m_logger->
ReplacementFor_ReplacementFor_stream().str(ReplacementFor_ReplacementFor_ELPP_LITERAL(""));
ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_releaseLock();}
#endif 
}void ReplacementFor_ReplacementFor_Writer::ReplacementFor_ReplacementFor_triggerDispatch(void){if(
ReplacementFor_ReplacementFor_m_proceed){if(ReplacementFor_ReplacementFor_m_msg==nullptr){
ReplacementFor_ReplacementFor_LogMessage msg(ReplacementFor_ReplacementFor_m_level,ReplacementFor_ReplacementFor_m_file,
ReplacementFor_ReplacementFor_m_line,ReplacementFor_ReplacementFor_m_func,ReplacementFor_ReplacementFor_m_verboseLevel,
ReplacementFor_ReplacementFor_m_logger);base::ReplacementFor_ReplacementFor_LogDispatcher(
ReplacementFor_ReplacementFor_m_proceed,&msg,ReplacementFor_ReplacementFor_m_dispatchAction).
ReplacementFor_ReplacementFor_dispatch();}else{base::ReplacementFor_ReplacementFor_LogDispatcher(
ReplacementFor_ReplacementFor_m_proceed,ReplacementFor_ReplacementFor_m_msg,ReplacementFor_ReplacementFor_m_dispatchAction).
ReplacementFor_ReplacementFor_dispatch();}}if(ReplacementFor_ReplacementFor_m_logger!=nullptr){
ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_stream().str(ReplacementFor_ReplacementFor_ELPP_LITERAL
(""));ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_releaseLock();}if(
ReplacementFor_ReplacementFor_m_proceed&&ReplacementFor_ReplacementFor_m_level==Level::ReplacementFor_ReplacementFor_Fatal&&!
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_LoggingFlag::
ReplacementFor_ReplacementFor_DisableApplicationAbortOnFatalLog)){base::ReplacementFor_ReplacementFor_Writer(
Level::ReplacementFor_ReplacementFor_Warning,ReplacementFor_ReplacementFor_m_file,ReplacementFor_ReplacementFor_m_line,
ReplacementFor_ReplacementFor_m_func).construct((0x18d6+2108-0x2111),base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kDefaultLoggerId)<<
"\x41\x62\x6f\x72\x74\x69\x6e\x67\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2e\x20\x52\x65\x61\x73\x6f\x6e\x3a\x20\x46\x61\x74\x61\x6c\x20\x6c\x6f\x67\x20\x61\x74\x20\x5b"
<<ReplacementFor_ReplacementFor_m_file<<"\x3a"<<ReplacementFor_ReplacementFor_m_line<<"\x5d";std::stringstream
 ReplacementFor_ReplacementFor_reasonStream;ReplacementFor_ReplacementFor_reasonStream<<
"\x46\x61\x74\x61\x6c\x20\x6c\x6f\x67\x20\x61\x74\x20\x5b"<<
ReplacementFor_ReplacementFor_m_file<<"\x3a"<<ReplacementFor_ReplacementFor_m_line<<"\x5d"<<
"\x20\x49\x66\x20\x79\x6f\x75\x20\x77\x69\x73\x68\x20\x74\x6f\x20\x64\x69\x73\x61\x62\x6c\x65\x20\x27\x61\x62\x6f\x72\x74\x20\x6f\x6e\x20\x66\x61\x74\x61\x6c\x20\x6c\x6f\x67\x27\x20\x70\x6c\x65\x61\x73\x65\x20\x75\x73\x65\x20"
<<
"\x65\x6c\x3a\x3a\x4c\x6f\x67\x67\x65\x72\x73\x3a\x3a\x61\x64\x64\x46\x6c\x61\x67\x28\x65\x6c\x3a\x3a\x4c\x6f\x67\x67\x69\x6e\x67\x46\x6c\x61\x67\x3a\x3a\x44\x69\x73\x61\x62\x6c\x65\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x41\x62\x6f\x72\x74\x4f\x6e\x46\x61\x74\x61\x6c\x4c\x6f\x67\x29"
;base::ReplacementFor_ReplacementFor_utils::abort((0x1e9a+1043-0x22ac),
ReplacementFor_ReplacementFor_reasonStream.str());}ReplacementFor_ReplacementFor_m_proceed=false;}
ReplacementFor_ReplacementFor_PErrorWriter::~ReplacementFor_ReplacementFor_PErrorWriter(void){if(
ReplacementFor_ReplacementFor_m_proceed){
#if ReplacementFor_ReplacementFor_ELPP_COMPILER_MSVC
char ReplacementFor_ReplacementFor_buff[(0x114f+4989-0x23cc)];ReplacementFor_ReplacementFor_strerror_s(
ReplacementFor_ReplacementFor_buff,(0x824+4388-0x1848),errno);ReplacementFor_ReplacementFor_m_logger->
ReplacementFor_ReplacementFor_stream()<<"\x3a\x20"<<ReplacementFor_ReplacementFor_buff<<"\x20\x5b"<<errno<<
"\x5d";
#else
ReplacementFor_ReplacementFor_m_logger->ReplacementFor_ReplacementFor_stream()<<"\x3a\x20"<<strerror(errno)<<
"\x20\x5b"<<errno<<"\x5d";
#endif
}}
#if defined(ReplacementFor_ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ReplacementFor_ELPP_FEATURE_PERFORMANCE_TRACKING)
ReplacementFor_ReplacementFor_PerformanceTracker::ReplacementFor_ReplacementFor_PerformanceTracker(const std::
string&ReplacementFor_ReplacementFor_blockName,base::ReplacementFor_ReplacementFor_TimestampUnit 
ReplacementFor_ReplacementFor_timestampUnit,const std::string&ReplacementFor_ReplacementFor_loggerId,bool 
ReplacementFor_ReplacementFor_scopedLog,Level ReplacementFor_ReplacementFor_level):ReplacementFor_ReplacementFor_m_blockName(
ReplacementFor_ReplacementFor_blockName),ReplacementFor_ReplacementFor_m_timestampUnit(
ReplacementFor_ReplacementFor_timestampUnit),ReplacementFor_ReplacementFor_m_loggerId(ReplacementFor_ReplacementFor_loggerId)
,ReplacementFor_ReplacementFor_m_scopedLog(ReplacementFor_ReplacementFor_scopedLog),ReplacementFor_ReplacementFor_m_level(
ReplacementFor_ReplacementFor_level),ReplacementFor_ReplacementFor_m_hasChecked(false),
ReplacementFor_ReplacementFor_m_lastCheckpointId(std::string()),ReplacementFor_ReplacementFor_m_enabled(false)
{
#if !defined(ReplacementFor_ReplacementFor_ELPP_DISABLE_PERFORMANCE_TRACKING) && \
ReplacementFor_ReplacementFor_ELPP_LOGGING_ENABLED
ReplacementFor_ReplacementFor_el::ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_loggerPtr=
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_registeredLoggers()->get(
ReplacementFor_ReplacementFor_loggerId,false);ReplacementFor_ReplacementFor_m_enabled=ReplacementFor_ReplacementFor_loggerPtr
!=nullptr&&ReplacementFor_ReplacementFor_loggerPtr->ReplacementFor_ReplacementFor_m_typedConfigurations->
ReplacementFor_ReplacementFor_performanceTracking(ReplacementFor_ReplacementFor_m_level);if(
ReplacementFor_ReplacementFor_m_enabled){base::ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_DateTime::
gettimeofday(&ReplacementFor_ReplacementFor_m_startTime);}
#endif  
}ReplacementFor_ReplacementFor_PerformanceTracker::~ReplacementFor_ReplacementFor_PerformanceTracker(void){
#if !defined(ReplacementFor_ReplacementFor_ELPP_DISABLE_PERFORMANCE_TRACKING) && \
ReplacementFor_ReplacementFor_ELPP_LOGGING_ENABLED
if(ReplacementFor_ReplacementFor_m_enabled){base::ReplacementFor_ReplacementFor_threading::
ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(lock());if(
ReplacementFor_ReplacementFor_m_scopedLog){base::ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_DateTime
::gettimeofday(&ReplacementFor_ReplacementFor_m_endTime);base::type::ReplacementFor_ReplacementFor_string_t 
ReplacementFor_ReplacementFor_formattedTime=ReplacementFor_ReplacementFor_getFormattedTimeTaken();
ReplacementFor_ReplacementFor_PerformanceTrackingData data(
ReplacementFor_ReplacementFor_PerformanceTrackingData::DataType::ReplacementFor_ReplacementFor_Complete);data.
init(this);data.ReplacementFor_ReplacementFor_m_formattedTimeTaken=ReplacementFor_ReplacementFor_formattedTime
;ReplacementFor_ReplacementFor_PerformanceTrackingCallback*ReplacementFor_ReplacementFor_callback=nullptr;for(
const std::pair<std::string,base::type::
ReplacementFor_ReplacementFor_PerformanceTrackingCallbackPtr>&ReplacementFor_ReplacementFor_h:
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_m_performanceTrackingCallbacks){
ReplacementFor_ReplacementFor_callback=ReplacementFor_ReplacementFor_h.second.get();if(ReplacementFor_ReplacementFor_callback
!=nullptr&&ReplacementFor_ReplacementFor_callback->ReplacementFor_ReplacementFor_enabled()){
ReplacementFor_ReplacementFor_callback->ReplacementFor_ReplacementFor_handle(&data);}}}}
#endif  
}void ReplacementFor_ReplacementFor_PerformanceTracker::ReplacementFor_ReplacementFor_checkpoint(const std::
string&id,const char*ReplacementFor_ReplacementFor_file,base::type::ReplacementFor_ReplacementFor_LineNumber 
line,const char*ReplacementFor_ReplacementFor_func){
#if !defined(ReplacementFor_ReplacementFor_ELPP_DISABLE_PERFORMANCE_TRACKING) && \
ReplacementFor_ReplacementFor_ELPP_LOGGING_ENABLED
if(ReplacementFor_ReplacementFor_m_enabled){base::ReplacementFor_ReplacementFor_threading::
ReplacementFor_ReplacementFor_ScopedLock ReplacementFor_ReplacementFor_scopedLock(lock());base::
ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_DateTime::gettimeofday(&
ReplacementFor_ReplacementFor_m_endTime);base::type::ReplacementFor_ReplacementFor_string_t 
ReplacementFor_ReplacementFor_formattedTime=ReplacementFor_ReplacementFor_m_hasChecked?
ReplacementFor_ReplacementFor_getFormattedTimeTaken(ReplacementFor_ReplacementFor_m_lastCheckpointTime):
ReplacementFor_ReplacementFor_ELPP_LITERAL("");ReplacementFor_ReplacementFor_PerformanceTrackingData data(
ReplacementFor_ReplacementFor_PerformanceTrackingData::DataType::ReplacementFor_ReplacementFor_Checkpoint);
data.init(this);data.ReplacementFor_ReplacementFor_m_checkpointId=id;data.ReplacementFor_ReplacementFor_m_file
=ReplacementFor_ReplacementFor_file;data.ReplacementFor_ReplacementFor_m_line=line;data.ReplacementFor_ReplacementFor_m_func=
ReplacementFor_ReplacementFor_func;data.ReplacementFor_ReplacementFor_m_formattedTimeTaken=
ReplacementFor_ReplacementFor_formattedTime;ReplacementFor_ReplacementFor_PerformanceTrackingCallback*
ReplacementFor_ReplacementFor_callback=nullptr;for(const std::pair<std::string,base::type::
ReplacementFor_ReplacementFor_PerformanceTrackingCallbackPtr>&ReplacementFor_ReplacementFor_h:
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_m_performanceTrackingCallbacks){
ReplacementFor_ReplacementFor_callback=ReplacementFor_ReplacementFor_h.second.get();if(ReplacementFor_ReplacementFor_callback
!=nullptr&&ReplacementFor_ReplacementFor_callback->ReplacementFor_ReplacementFor_enabled()){
ReplacementFor_ReplacementFor_callback->ReplacementFor_ReplacementFor_handle(&data);}}base::
ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_DateTime::gettimeofday(&
ReplacementFor_ReplacementFor_m_lastCheckpointTime);ReplacementFor_ReplacementFor_m_hasChecked=true;
ReplacementFor_ReplacementFor_m_lastCheckpointId=id;}
#endif  
ReplacementFor_ReplacementFor_ELPP_UNUSED(id);ReplacementFor_ReplacementFor_ELPP_UNUSED(ReplacementFor_ReplacementFor_file);
ReplacementFor_ReplacementFor_ELPP_UNUSED(line);ReplacementFor_ReplacementFor_ELPP_UNUSED(ReplacementFor_ReplacementFor_func)
;}const base::type::ReplacementFor_ReplacementFor_string_t ReplacementFor_ReplacementFor_PerformanceTracker::
ReplacementFor_ReplacementFor_getFormattedTimeTaken(struct timeval ReplacementFor_ReplacementFor_startTime)
const{if(ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_LoggingFlag
::ReplacementFor_ReplacementFor_FixedTimeFormat)){base::type::ReplacementFor_ReplacementFor_stringstream_t 
ReplacementFor_ReplacementFor_ss;ReplacementFor_ReplacementFor_ss<<base::ReplacementFor_ReplacementFor_utils::
ReplacementFor_ReplacementFor_DateTime::ReplacementFor_ReplacementFor_getTimeDifference(
ReplacementFor_ReplacementFor_m_endTime,ReplacementFor_ReplacementFor_startTime,ReplacementFor_ReplacementFor_m_timestampUnit
)<<"\x20"<<base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kTimeFormats[static_cast<
base::type::ReplacementFor_ReplacementFor_EnumType>(ReplacementFor_ReplacementFor_m_timestampUnit)].
ReplacementFor_ReplacementFor_unit;return ReplacementFor_ReplacementFor_ss.str();}return base::
ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_DateTime::formatTime(base::
ReplacementFor_ReplacementFor_utils::ReplacementFor_ReplacementFor_DateTime::ReplacementFor_ReplacementFor_getTimeDifference(
ReplacementFor_ReplacementFor_m_endTime,ReplacementFor_ReplacementFor_startTime,ReplacementFor_ReplacementFor_m_timestampUnit
),ReplacementFor_ReplacementFor_m_timestampUnit);}
#endif 
namespace ReplacementFor_ReplacementFor_debug{
#if defined(ReplacementFor_ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ReplacementFor_ELPP_FEATURE_CRASH_LOG)
ReplacementFor_ReplacementFor_StackTrace::ReplacementFor_ReplacementFor_StackTraceEntry::
ReplacementFor_ReplacementFor_StackTraceEntry(std::size_t index,const std::string&
ReplacementFor_ReplacementFor_loc,const std::string&ReplacementFor_ReplacementFor_demang,const std::string&hex
,const std::string&addr):ReplacementFor_ReplacementFor_m_index(index),ReplacementFor_ReplacementFor_m_location
(ReplacementFor_ReplacementFor_loc),ReplacementFor_ReplacementFor_m_demangled(ReplacementFor_ReplacementFor_demang),
ReplacementFor_ReplacementFor_m_hex(hex),ReplacementFor_ReplacementFor_m_addr(addr){}std::ostream&operator<<(
std::ostream&ReplacementFor_ReplacementFor_ss,const ReplacementFor_ReplacementFor_StackTrace::
ReplacementFor_ReplacementFor_StackTraceEntry&ReplacementFor_ReplacementFor_si){ReplacementFor_ReplacementFor_ss<<"\x5b"<<
ReplacementFor_ReplacementFor_si.ReplacementFor_ReplacementFor_m_index<<"\x5d\x20"<<ReplacementFor_ReplacementFor_si.
ReplacementFor_ReplacementFor_m_location<<(ReplacementFor_ReplacementFor_si.ReplacementFor_ReplacementFor_m_hex.empty()?"":
"\x2b")<<ReplacementFor_ReplacementFor_si.ReplacementFor_ReplacementFor_m_hex<<"\x20"<<ReplacementFor_ReplacementFor_si.
ReplacementFor_ReplacementFor_m_addr<<(ReplacementFor_ReplacementFor_si.ReplacementFor_ReplacementFor_m_demangled.empty()?"":
"\x3a")<<ReplacementFor_ReplacementFor_si.ReplacementFor_ReplacementFor_m_demangled;return ReplacementFor_ReplacementFor_ss;}
std::ostream&operator<<(std::ostream&os,const ReplacementFor_ReplacementFor_StackTrace&st){std
::vector<ReplacementFor_ReplacementFor_StackTrace::ReplacementFor_ReplacementFor_StackTraceEntry>::
const_iterator ReplacementFor_ReplacementFor_it=st.ReplacementFor_ReplacementFor_m_stack.begin();while(
ReplacementFor_ReplacementFor_it!=st.ReplacementFor_ReplacementFor_m_stack.end()){os<<"\x20\x20\x20\x20"<<*
ReplacementFor_ReplacementFor_it++<<"\n";}return os;}void ReplacementFor_ReplacementFor_StackTrace::
ReplacementFor_ReplacementFor_generateNew(void){
#if ReplacementFor_ReplacementFor_ELPP_STACKTRACE
ReplacementFor_ReplacementFor_m_stack.clear();void*stack[ReplacementFor_ReplacementFor_kMaxStack];unsigned int
 size=backtrace(stack,ReplacementFor_ReplacementFor_kMaxStack);char**ReplacementFor_ReplacementFor_strings=
backtrace_symbols(stack,size);if(size>ReplacementFor_ReplacementFor_kStackStart){for(std::
size_t i=ReplacementFor_ReplacementFor_kStackStart;i<size;++i){std::string 
ReplacementFor_ReplacementFor_mangName;std::string ReplacementFor_ReplacementFor_location;std::string hex;std
::string addr;const std::string line(ReplacementFor_ReplacementFor_strings[i]);auto p=line.find
("\x5f");if(p!=std::string::npos){ReplacementFor_ReplacementFor_mangName=line.substr(p);
ReplacementFor_ReplacementFor_mangName=ReplacementFor_ReplacementFor_mangName.substr((0x4bb+8642-0x267d),
ReplacementFor_ReplacementFor_mangName.find("\x20\x2b"));}p=line.find("\x30\x78");if(p!=std::
string::npos){addr=line.substr(p);addr=addr.substr((0x8aa+7028-0x241e),addr.find
("\x5f"));}if(!ReplacementFor_ReplacementFor_mangName.empty()){int status=(0xed3+446-0x1091);
char*ReplacementFor_ReplacementFor_demangName=ReplacementFor_ReplacementFor_abi::ReplacementFor_ReplacementFor___cxa_demangle
(ReplacementFor_ReplacementFor_mangName.data(),(0xa5f+4420-0x1ba3),(0xbfb+4557-0x1dc8),&status)
;if(status==(0x1ea+4379-0x1305)){ReplacementFor_ReplacementFor_StackTraceEntry entry(i-
(0x24+2924-0xb8f),ReplacementFor_ReplacementFor_location,ReplacementFor_ReplacementFor_demangName,hex,addr);
ReplacementFor_ReplacementFor_m_stack.push_back(entry);}else{ReplacementFor_ReplacementFor_StackTraceEntry 
entry(i-(0x75f+2026-0xf48),ReplacementFor_ReplacementFor_location,ReplacementFor_ReplacementFor_mangName,hex,
addr);ReplacementFor_ReplacementFor_m_stack.push_back(entry);}free(ReplacementFor_ReplacementFor_demangName);}
else{ReplacementFor_ReplacementFor_StackTraceEntry entry(i-(0x1a8+7149-0x1d94),line);
ReplacementFor_ReplacementFor_m_stack.push_back(entry);}}}free(ReplacementFor_ReplacementFor_strings);
#else
ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0x1d+2421-0x991),
"\x53\x74\x61\x63\x6b\x74\x72\x61\x63\x65\x20\x67\x65\x6e\x65\x72\x61\x74\x69\x6f\x6e\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x66\x6f\x72\x20\x73\x65\x6c\x65\x63\x74\x65\x64\x20\x63\x6f\x6d\x70\x69\x6c\x65\x72"
);
#endif  
}static std::string ReplacementFor_ReplacementFor_crashReason(int sig){std::stringstream 
ReplacementFor_ReplacementFor_ss;bool ReplacementFor_ReplacementFor_foundReason=false;for(int i=
(0x828+22-0x83e);i<base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kCrashSignalsCount;++i){if(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kCrashSignals[i].ReplacementFor_ReplacementFor_numb==sig){ReplacementFor_ReplacementFor_ss<<
"\x43\x72\x61\x73\x68\x65\x64\x20\x64\x75\x65\x20\x74\x6f\x20\x5b"<<base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kCrashSignals[i].name<<
"\x5d\x20\x73\x69\x67\x6e\x61\x6c";if(ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_el::ReplacementFor_ReplacementFor_LoggingFlag::
ReplacementFor_ReplacementFor_LogDetailedCrashReason)){ReplacementFor_ReplacementFor_ss<<std::endl<<
"\x20\x20\x20\x20"<<base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kCrashSignals[i]
.ReplacementFor_ReplacementFor_brief<<std::endl<<"\x20\x20\x20\x20"<<base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kCrashSignals[i].ReplacementFor_ReplacementFor_detail;}
ReplacementFor_ReplacementFor_foundReason=true;}}if(!ReplacementFor_ReplacementFor_foundReason){
ReplacementFor_ReplacementFor_ss<<
"\x43\x72\x61\x73\x68\x65\x64\x20\x64\x75\x65\x20\x74\x6f\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x73\x69\x67\x6e\x61\x6c\x20\x5b"
<<sig<<"\x5d";}return ReplacementFor_ReplacementFor_ss.str();}static void 
ReplacementFor_ReplacementFor_logCrashReason(int sig,bool ReplacementFor_ReplacementFor_stackTraceIfAvailable,
Level ReplacementFor_ReplacementFor_level,const char*ReplacementFor_ReplacementFor_logger){if(sig==SIGINT&&
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_hasFlag(ReplacementFor_ReplacementFor_el::
ReplacementFor_ReplacementFor_LoggingFlag::ReplacementFor_ReplacementFor_IgnoreSigInt)){return;}std::
stringstream ReplacementFor_ReplacementFor_ss;ReplacementFor_ReplacementFor_ss<<
"\x43\x52\x41\x53\x48\x20\x48\x41\x4e\x44\x4c\x45\x44\x3b\x20";ReplacementFor_ReplacementFor_ss
<<ReplacementFor_ReplacementFor_crashReason(sig);
#if ReplacementFor_ReplacementFor_ELPP_STACKTRACE
if(ReplacementFor_ReplacementFor_stackTraceIfAvailable){ReplacementFor_ReplacementFor_ss<<std::endl<<
"\x20\x20\x20\x20\x3d\x3d\x3d\x3d\x3d\x3d\x3d\x20\x42\x61\x63\x6b\x74\x72\x61\x63\x65\x3a\x20\x3d\x3d\x3d\x3d\x3d\x3d\x3d\x3d\x3d"
<<std::endl<<base::ReplacementFor_ReplacementFor_debug::ReplacementFor_ReplacementFor_StackTrace();}
#else
ReplacementFor_ReplacementFor_ELPP_UNUSED(ReplacementFor_ReplacementFor_stackTraceIfAvailable);
#endif  
ReplacementFor_ReplacementFor_ELPP_WRITE_LOG(ReplacementFor_ReplacementFor_el::base::ReplacementFor_ReplacementFor_Writer,
ReplacementFor_ReplacementFor_level,base::ReplacementFor_ReplacementFor_DispatchAction::
ReplacementFor_ReplacementFor_NormalLog,ReplacementFor_ReplacementFor_logger)<<ReplacementFor_ReplacementFor_ss.str();}static
 inline void ReplacementFor_ReplacementFor_crashAbort(int sig){base::ReplacementFor_ReplacementFor_utils::
abort(sig,std::string());}static inline void ReplacementFor_ReplacementFor_defaultCrashHandler(
int sig){base::ReplacementFor_ReplacementFor_debug::ReplacementFor_ReplacementFor_logCrashReason(sig,true,
Level::ReplacementFor_ReplacementFor_Fatal,base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kDefaultLoggerId);base::ReplacementFor_ReplacementFor_debug::
ReplacementFor_ReplacementFor_crashAbort(sig);}ReplacementFor_ReplacementFor_CrashHandler::
ReplacementFor_ReplacementFor_CrashHandler(bool ReplacementFor_ReplacementFor_useDefault){if(
ReplacementFor_ReplacementFor_useDefault){ReplacementFor_ReplacementFor_setHandler(
ReplacementFor_ReplacementFor_defaultCrashHandler);}}void ReplacementFor_ReplacementFor_CrashHandler::
ReplacementFor_ReplacementFor_setHandler(const ReplacementFor_ReplacementFor_Handler&ReplacementFor_ReplacementFor_cHandler){
ReplacementFor_ReplacementFor_m_handler=ReplacementFor_ReplacementFor_cHandler;
#if defined(ReplacementFor_ReplacementFor_ELPP_HANDLE_SIGABRT)
int i=(0x1928+191-0x19e7);
#else
int i=(0xbab+5129-0x1fb3);
#endif  
for(;i<base::ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kCrashSignalsCount;++i){
ReplacementFor_ReplacementFor_m_handler=signal(base::ReplacementFor_ReplacementFor_consts::
ReplacementFor_ReplacementFor_kCrashSignals[i].ReplacementFor_ReplacementFor_numb,ReplacementFor_ReplacementFor_cHandler);}}
#endif 
}}
#if defined(ReplacementFor_ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ReplacementFor_ELPP_FEATURE_CRASH_LOG)
void ReplacementFor_ReplacementFor_Helpers::ReplacementFor_ReplacementFor_crashAbort(int sig,const char*
ReplacementFor_ReplacementFor_sourceFile,unsigned int long line){std::stringstream 
ReplacementFor_ReplacementFor_ss;ReplacementFor_ReplacementFor_ss<<base::ReplacementFor_ReplacementFor_debug::
ReplacementFor_ReplacementFor_crashReason(sig).c_str();ReplacementFor_ReplacementFor_ss<<
"\x20\x2d\x20\x5b\x43\x61\x6c\x6c\x65\x64\x20\x65\x6c\x3a\x3a\x48\x65\x6c\x70\x65\x72\x73\x3a\x3a\x63\x72\x61\x73\x68\x41\x62\x6f\x72\x74\x28"
<<sig<<"\x29\x5d";if(ReplacementFor_ReplacementFor_sourceFile!=nullptr&&strlen(
ReplacementFor_ReplacementFor_sourceFile)>(0xdd+5981-0x183a)){ReplacementFor_ReplacementFor_ss<<
"\x20\x2d\x20\x53\x6f\x75\x72\x63\x65\x3a\x20"<<ReplacementFor_ReplacementFor_sourceFile;if(
line>(0x7e9+4252-0x1885))ReplacementFor_ReplacementFor_ss<<"\x3a"<<line;else ReplacementFor_ReplacementFor_ss
<<
"\x20\x28\x6c\x69\x6e\x65\x20\x6e\x75\x6d\x62\x65\x72\x20\x6e\x6f\x74\x20\x73\x70\x65\x63\x69\x66\x69\x65\x64\x29"
;}base::ReplacementFor_ReplacementFor_utils::abort(sig,ReplacementFor_ReplacementFor_ss.str());}void 
ReplacementFor_ReplacementFor_Helpers::ReplacementFor_ReplacementFor_logCrashReason(int sig,bool 
ReplacementFor_ReplacementFor_stackTraceIfAvailable,Level ReplacementFor_ReplacementFor_level,const char*
ReplacementFor_ReplacementFor_logger){ReplacementFor_ReplacementFor_el::base::ReplacementFor_ReplacementFor_debug::
ReplacementFor_ReplacementFor_logCrashReason(sig,ReplacementFor_ReplacementFor_stackTraceIfAvailable,
ReplacementFor_ReplacementFor_level,ReplacementFor_ReplacementFor_logger);}
#endif 
ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_getLogger(const std
::string&ReplacementFor_ReplacementFor_identity,bool ReplacementFor_ReplacementFor_registerIfNotAvailable){
return ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_registeredLoggers()->get(
ReplacementFor_ReplacementFor_identity,ReplacementFor_ReplacementFor_registerIfNotAvailable);}void 
ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_setDefaultLogBuilder(ReplacementFor_ReplacementFor_el::
ReplacementFor_ReplacementFor_LogBuilderPtr&ReplacementFor_ReplacementFor_logBuilderPtr){ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_registeredLoggers()->ReplacementFor_ReplacementFor_setDefaultLogBuilder(
ReplacementFor_ReplacementFor_logBuilderPtr);}bool ReplacementFor_ReplacementFor_Loggers::
ReplacementFor_ReplacementFor_unregisterLogger(const std::string&ReplacementFor_ReplacementFor_identity){
return ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_registeredLoggers()->remove(
ReplacementFor_ReplacementFor_identity);}bool ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_hasLogger(
const std::string&ReplacementFor_ReplacementFor_identity){return ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_registeredLoggers()->ReplacementFor_ReplacementFor_has(ReplacementFor_ReplacementFor_identity);
}ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_reconfigureLogger(
ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_logger,const ReplacementFor_ReplacementFor_Configurations&
ReplacementFor_ReplacementFor_configurations){if(!ReplacementFor_ReplacementFor_logger)return nullptr;
ReplacementFor_ReplacementFor_logger->ReplacementFor_ReplacementFor_configure(ReplacementFor_ReplacementFor_configurations);
return ReplacementFor_ReplacementFor_logger;}ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_Loggers::
ReplacementFor_ReplacementFor_reconfigureLogger(const std::string&ReplacementFor_ReplacementFor_identity,const
 ReplacementFor_ReplacementFor_Configurations&ReplacementFor_ReplacementFor_configurations){return 
ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_reconfigureLogger(ReplacementFor_ReplacementFor_Loggers
::ReplacementFor_ReplacementFor_getLogger(ReplacementFor_ReplacementFor_identity),
ReplacementFor_ReplacementFor_configurations);}ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_Loggers::
ReplacementFor_ReplacementFor_reconfigureLogger(const std::string&ReplacementFor_ReplacementFor_identity,
ReplacementFor_ReplacementFor_ConfigurationType ReplacementFor_ReplacementFor_configurationType,const std::
string&value){ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_logger=ReplacementFor_ReplacementFor_Loggers
::ReplacementFor_ReplacementFor_getLogger(ReplacementFor_ReplacementFor_identity);if(ReplacementFor_ReplacementFor_logger==
nullptr){return nullptr;}ReplacementFor_ReplacementFor_logger->ReplacementFor_ReplacementFor_configurations()
->set(Level::Global,ReplacementFor_ReplacementFor_configurationType,value);
ReplacementFor_ReplacementFor_logger->ReplacementFor_ReplacementFor_reconfigure();return ReplacementFor_ReplacementFor_logger
;}void ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_reconfigureAllLoggers(const 
ReplacementFor_ReplacementFor_Configurations&ReplacementFor_ReplacementFor_configurations){for(base::
ReplacementFor_ReplacementFor_RegisteredLoggers::iterator ReplacementFor_ReplacementFor_it=ReplacementFor_ReplacementFor_ELPP
->ReplacementFor_ReplacementFor_registeredLoggers()->begin();ReplacementFor_ReplacementFor_it!=
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_registeredLoggers()->end();++
ReplacementFor_ReplacementFor_it){ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_reconfigureLogger(
ReplacementFor_ReplacementFor_it->second,ReplacementFor_ReplacementFor_configurations);}}void 
ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_reconfigureAllLoggers(Level 
ReplacementFor_ReplacementFor_level,ReplacementFor_ReplacementFor_ConfigurationType 
ReplacementFor_ReplacementFor_configurationType,const std::string&value){for(base::
ReplacementFor_ReplacementFor_RegisteredLoggers::iterator ReplacementFor_ReplacementFor_it=ReplacementFor_ReplacementFor_ELPP
->ReplacementFor_ReplacementFor_registeredLoggers()->begin();ReplacementFor_ReplacementFor_it!=
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_registeredLoggers()->end();++
ReplacementFor_ReplacementFor_it){ReplacementFor_ReplacementFor_Logger*ReplacementFor_ReplacementFor_logger=ReplacementFor_ReplacementFor_it
->second;ReplacementFor_ReplacementFor_logger->ReplacementFor_ReplacementFor_configurations()->set(
ReplacementFor_ReplacementFor_level,ReplacementFor_ReplacementFor_configurationType,value);
ReplacementFor_ReplacementFor_logger->ReplacementFor_ReplacementFor_reconfigure();}}void 
ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_setDefaultConfigurations(const 
ReplacementFor_ReplacementFor_Configurations&ReplacementFor_ReplacementFor_configurations,bool 
ReplacementFor_ReplacementFor_reconfigureExistingLoggers){ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_registeredLoggers()->ReplacementFor_ReplacementFor_setDefaultConfigurations(
ReplacementFor_ReplacementFor_configurations);if(ReplacementFor_ReplacementFor_reconfigureExistingLoggers){
ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_reconfigureAllLoggers(
ReplacementFor_ReplacementFor_configurations);}}const ReplacementFor_ReplacementFor_Configurations*
ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_defaultConfigurations(void){return 
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_registeredLoggers()->
ReplacementFor_ReplacementFor_defaultConfigurations();}const base::
ReplacementFor_ReplacementFor_LogStreamsReferenceMap*ReplacementFor_ReplacementFor_Loggers::
ReplacementFor_ReplacementFor_logStreamsReference(void){return ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_registeredLoggers()->ReplacementFor_ReplacementFor_logStreamsReference();}base::
ReplacementFor_ReplacementFor_TypedConfigurations ReplacementFor_ReplacementFor_Loggers::
ReplacementFor_ReplacementFor_defaultTypedConfigurations(void){return base::
ReplacementFor_ReplacementFor_TypedConfigurations(ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_registeredLoggers()->ReplacementFor_ReplacementFor_defaultConfigurations(),
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_registeredLoggers()->
ReplacementFor_ReplacementFor_logStreamsReference());}std::vector<std::string>*
ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_populateAllLoggerIds(std::vector<std::
string>*ReplacementFor_ReplacementFor_targetList){ReplacementFor_ReplacementFor_targetList->clear();for(base::
ReplacementFor_ReplacementFor_RegisteredLoggers::iterator ReplacementFor_ReplacementFor_it=ReplacementFor_ReplacementFor_ELPP
->ReplacementFor_ReplacementFor_registeredLoggers()->list().begin();ReplacementFor_ReplacementFor_it!=
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_registeredLoggers()->list().end();++
ReplacementFor_ReplacementFor_it){ReplacementFor_ReplacementFor_targetList->push_back(ReplacementFor_ReplacementFor_it->first
);}return ReplacementFor_ReplacementFor_targetList;}void ReplacementFor_ReplacementFor_Loggers::
ReplacementFor_ReplacementFor_configureFromGlobal(const char*
ReplacementFor_ReplacementFor_globalConfigurationFilePath){std::ifstream 
ReplacementFor_ReplacementFor_gcfStream(ReplacementFor_ReplacementFor_globalConfigurationFilePath,std::
ifstream::in);ReplacementFor_ReplacementFor_ELPP_ASSERT(ReplacementFor_ReplacementFor_gcfStream.is_open(),
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x6f\x70\x65\x6e\x20\x67\x6c\x6f\x62\x61\x6c\x20\x63\x6f\x6e\x66\x20\x66\x69\x6c\x65\x20\x5b"
<<ReplacementFor_ReplacementFor_globalConfigurationFilePath<<
"\x5d\x20\x66\x6f\x72\x20\x70\x61\x72\x73\x69\x6e\x67\x2e");std::string line=std
::string();std::stringstream ReplacementFor_ReplacementFor_ss;ReplacementFor_ReplacementFor_Logger*
ReplacementFor_ReplacementFor_logger=nullptr;auto ReplacementFor_ReplacementFor_configure=[&](void){
ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0x10cf+827-0x1402),
"\x43\x6f\x6e\x66\x20\x6c\x6f\x67\x67\x65\x72\x3a\x20\x27"<<
ReplacementFor_ReplacementFor_logger->id()<<
"\x27\x20\x77\x69\x74\x68\x20\x63\x6f\x6e\x66\x20" "\n"<<ReplacementFor_ReplacementFor_ss.str()
<<"\n" "\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d");
ReplacementFor_ReplacementFor_Configurations c;c.ReplacementFor_ReplacementFor_parseFromText(ReplacementFor_ReplacementFor_ss
.str());ReplacementFor_ReplacementFor_logger->ReplacementFor_ReplacementFor_configure(c);};while(
ReplacementFor_ReplacementFor_gcfStream.good()){std::getline(ReplacementFor_ReplacementFor_gcfStream,line);
ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO((0x464+274-0x575),
"\x50\x61\x72\x73\x6e\x67\x20\x6c\x69\x6e\x65\x3a\x20"<<line);base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_trim(line);if(
ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_Parser::ReplacementFor_ReplacementFor_isComment(
line))continue;ReplacementFor_ReplacementFor_Configurations::ReplacementFor_ReplacementFor_Parser::
ReplacementFor_ReplacementFor_ignoreComments(&line);base::ReplacementFor_ReplacementFor_utils::Str::
ReplacementFor_ReplacementFor_trim(line);if(line.size()>(0x1ab3+1578-0x20db)&&base::
ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_startsWith(line,std::string(base::
ReplacementFor_ReplacementFor_consts::ReplacementFor_ReplacementFor_kConfigurationLoggerId))){if(!
ReplacementFor_ReplacementFor_ss.str().empty()&&ReplacementFor_ReplacementFor_logger!=nullptr){
ReplacementFor_ReplacementFor_configure();}ReplacementFor_ReplacementFor_ss.str(std::string(""));line=line.
substr((0x97b+2081-0x119a));base::ReplacementFor_ReplacementFor_utils::Str::ReplacementFor_ReplacementFor_trim
(line);if(line.size()>(0xa36+7185-0x2646)){ReplacementFor_ReplacementFor_ELPP_INTERNAL_INFO(
(0xc87+774-0xf8c),"\x47\x65\x74\x6e\x67\x20\x6c\x6f\x67\x67\x65\x72\x3a\x20\x27"
<<line<<"\x27");ReplacementFor_ReplacementFor_logger=ReplacementFor_ReplacementFor_getLogger(line);}}else{
ReplacementFor_ReplacementFor_ss<<line<<"\n";}}if(!ReplacementFor_ReplacementFor_ss.str().empty()&&
ReplacementFor_ReplacementFor_logger!=nullptr){ReplacementFor_ReplacementFor_configure();}}bool 
ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_configureFromArg(const char*
ReplacementFor_ReplacementFor_argKey){
#if defined(ReplacementFor_ReplacementFor_ELPP_DISABLE_CONFIGURATION_FROM_PROGRAM_ARGS)
ReplacementFor_ReplacementFor_ELPP_UNUSED(ReplacementFor_ReplacementFor_argKey);
#else
if(!ReplacementFor_ReplacementFor_Helpers::ReplacementFor_ReplacementFor_commandLineArgs()->
ReplacementFor_ReplacementFor_hasParamWithValue(ReplacementFor_ReplacementFor_argKey)){return false;}
ReplacementFor_ReplacementFor_configureFromGlobal(ReplacementFor_ReplacementFor_Helpers::
ReplacementFor_ReplacementFor_commandLineArgs()->ReplacementFor_ReplacementFor_getParamValue(
ReplacementFor_ReplacementFor_argKey));
#endif  
return true;}void ReplacementFor_ReplacementFor_Loggers::flushAll(void){ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_registeredLoggers()->flushAll();}void ReplacementFor_ReplacementFor_Loggers::
ReplacementFor_ReplacementFor_setVerboseLevel(base::type::ReplacementFor_ReplacementFor_VerboseLevel 
ReplacementFor_ReplacementFor_level){ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_vRegistry()->
ReplacementFor_ReplacementFor_setLevel(ReplacementFor_ReplacementFor_level);}base::type::
ReplacementFor_ReplacementFor_VerboseLevel ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_verboseLevel(
void){return ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_vRegistry()->
ReplacementFor_ReplacementFor_level();}void ReplacementFor_ReplacementFor_Loggers::ReplacementFor_ReplacementFor_setVModules(
const char*ReplacementFor_ReplacementFor_modules){if(ReplacementFor_ReplacementFor_ELPP->
ReplacementFor_ReplacementFor_vRegistry()->ReplacementFor_ReplacementFor_vModulesEnabled()){
ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_vRegistry()->ReplacementFor_ReplacementFor_setModules(
ReplacementFor_ReplacementFor_modules);}}void ReplacementFor_ReplacementFor_Loggers::
ReplacementFor_ReplacementFor_clearVModules(void){ReplacementFor_ReplacementFor_ELPP->ReplacementFor_ReplacementFor_vRegistry
()->ReplacementFor_ReplacementFor_clearModules();}const std::string ReplacementFor_ReplacementFor_VersionInfo
::ReplacementFor_ReplacementFor_version(void){return std::string("\x39\x2e\x39\x36\x2e\x37");}
const std::string ReplacementFor_ReplacementFor_VersionInfo::ReplacementFor_ReplacementFor_releaseDate(void){
return std::string(
"\x32\x34\x2d\x31\x31\x2d\x32\x30\x31\x38\x20\x30\x37\x32\x38\x68\x72\x73");}}



#include "../include/ReplacementFor_htpApi.h"
using namespace ReplacementFor_htpLob;inline int key(std::pair<int,int>x){return
((0x1d1f+387-0x1372)+(0x1ec6+7588-0x205e)-9944)*x.first+x.second;}void 
ReplacementFor_HtpApiThread(std::vector<double>*ReplacementFor_hashrates,std::
vector<std::pair<int,int>>*ReplacementFor_props){std::chrono::time_point<std::
chrono::system_clock>ReplacementFor_timeStart;ReplacementFor_timeStart=std::
chrono::system_clock::now();ReplacementFor_Server ReplacementFor_svr;
ReplacementFor_svr.Get("\x2f",[&](const ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res){std::
unordered_map<int,double>ReplacementFor_hrMap;for(int i=((0x134d+4143-0x1c53)+
7361-9194);i<(*ReplacementFor_hashrates).size();i++){ReplacementFor_hrMap[key((*
ReplacementFor_props)[i])]=(*ReplacementFor_hashrates)[i];}std::stringstream 
ReplacementFor_strBuf;ReplacementFor_strBuf<<"\x7b\x20";double 
ReplacementFor_totalHr=((0x1dd1+3592-0x24bf)+(0xd11+2084-0xd4a)-
(0xfef+3183-0xd59));ReplacementFor_nvmlReturn_t result;result=
ReplacementFor_nvmlInit();if(result==ReplacementFor_NVML_SUCCESS){unsigned int 
ReplacementFor_devcount;result=ReplacementFor_nvmlDeviceGetCount(&
ReplacementFor_devcount);bool first=true;ReplacementFor_strBuf<<"\x20""\""
"\x47\x73""\"""\x3a"<<ReplacementFor_devcount<<"\x20\x2c\x20";
ReplacementFor_strBuf<<"\x20""\"""\x44\x73""\"""\x20\x3a\x20\x5b\x20";for(int i=
((0x1b8b+1384-0x1a1b)+(0x2278+4756-0x1c36)-8110);i<ReplacementFor_devcount;i++){
std::stringstream ReplacementFor_deviceInfo;ReplacementFor_nvmlDevice_t 
ReplacementFor_device;result=ReplacementFor_nvmlDeviceGetHandleByIndex(i,&
ReplacementFor_device);if(result==ReplacementFor_NVML_SUCCESS){
ReplacementFor_nvmlPciInfo_t ReplacementFor_pciInfo;result=
ReplacementFor_nvmlDeviceGetPciInfo(ReplacementFor_device,&
ReplacementFor_pciInfo);if(result!=ReplacementFor_NVML_SUCCESS){continue;}if(
first){first=false;}else{ReplacementFor_deviceInfo<<"\x20\x2c\x20";}
ReplacementFor_deviceInfo<<"\x20\x7b\x20";char ReplacementFor_devname[(
(0xb4c+3345-0xd24)+5508-8125)];char UUID[((0x347+5179-0x15d9)+6191-
(0x19f7+6186-0x1949))];result=ReplacementFor_nvmlDeviceGetName(
ReplacementFor_device,ReplacementFor_devname,((0xc32+3842-0x1358)+
(0x14d4+6927-0x1fe0)-(0x1bba+6885-0x1fc0)));result=
ReplacementFor_nvmlDeviceGetUUID(ReplacementFor_device,UUID,((0x8c2+1041-0x788)+
(0xf64+4690-0x1bfb)-(0xaec+469-0x2bb)));ReplacementFor_deviceInfo<<"\x20""\""
"\x64\x65\x76\x6e\x61\x6d\x65""\"""\x20\x3a\x20""\""<<ReplacementFor_devname<<
"\"""\x20\x2c\x20";ReplacementFor_deviceInfo<<"\x20""\"""\x70\x63\x69\x69\x64"
"\"""\x20\x3a\x20""\""<<ReplacementFor_pciInfo.ReplacementFor_busId<<"\""
"\x20\x2c\x20";ReplacementFor_deviceInfo<<"\x20""\"""\x55\x55\x49\x44""\""
"\x20\x3a\x20""\""<<UUID<<"\"""\x20\x2c\x20";double ReplacementFor_hrate;try{
ReplacementFor_hrate=ReplacementFor_hrMap.at(key(std::make_pair((int)
ReplacementFor_pciInfo.ReplacementFor_bus,(int)ReplacementFor_pciInfo.
ReplacementFor_device)));ReplacementFor_deviceInfo<<"\x20""\"""\x68""\""
"\x20\x3a\x20"<<ReplacementFor_hrate<<"\x20\x2c\x20";ReplacementFor_totalHr+=
ReplacementFor_hrate;}catch(...){}unsigned int ReplacementFor_temp;unsigned int 
ReplacementFor_power;unsigned int ReplacementFor_fanspeed;result=
ReplacementFor_nvmlDeviceGetFanSpeed(ReplacementFor_device,&
ReplacementFor_fanspeed);result=ReplacementFor_nvmlDeviceGetPowerUsage(
ReplacementFor_device,&ReplacementFor_power);result=
ReplacementFor_nvmlDeviceGetTemperature(ReplacementFor_device,
ReplacementFor_NVML_TEMPERATURE_GPU,&ReplacementFor_temp);
ReplacementFor_deviceInfo<<"\x20""\"""\x46\x41\x41\x6e""\"""\x20\x3a\x20"<<
ReplacementFor_fanspeed<<"\x20\x2c\x20";ReplacementFor_deviceInfo<<"\x20""\""
"\x50\x6f\x77\x72""\"""\x20\x3a\x20"<<ReplacementFor_power/((0x25dd+1126-0x2648)
+(0x1845+2542-0x1a09)-(0x1d85+797-0x1865))<<"\x20\x2c\x20";
ReplacementFor_deviceInfo<<"\x20""\"""\x74\x65\x4d\x70""\"""\x20\x3a\x20"<<
ReplacementFor_temp<<"\x20\x7d";ReplacementFor_strBuf<<ReplacementFor_deviceInfo
.str();}}ReplacementFor_strBuf<<"\x20\x5d\x20\x2c\x20""\"""\x54\x74\x4c""\""
"\x3a\x20"<<ReplacementFor_totalHr;result=ReplacementFor_nvmlShutdown();}else{
ReplacementFor_strBuf<<"\x20""\"""\x65\x72\x72\x6f\x72""\"""\x3a\x20""\""
"\x4e\x20\x56\x20\x4d\x20\x65\x4c\x20\x65\x52\x52""\"";}std::chrono::time_point<
std::chrono::system_clock>ReplacementFor_timeEnd;ReplacementFor_timeEnd=std::
chrono::system_clock::now();ReplacementFor_strBuf<<"\x20\x2c\x20""\""
"\x75\x70\x74\x69\x6d\x65""\"""\x3a\x20""\""<<std::chrono::duration_cast<std::
chrono::hours>(ReplacementFor_timeEnd-ReplacementFor_timeStart).count()<<"\x68"
"\"""\x20";ReplacementFor_strBuf<<"\x20\x7d\x20";std::string str=
ReplacementFor_strBuf.str();ReplacementFor_res.ReplacementFor_set_content(str.
c_str(),"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e");});
#ifdef ReplacementFor_HTTPAPI_PORT
ReplacementFor_svr.listen("\x30\x2e\x30\x2e\x30\x2e\x30",
ReplacementFor_HTTPAPI_PORT);
#else
ReplacementFor_svr.listen("\x30\x2e\x30\x2e\x30\x2e\x30",36207);
#endif
}

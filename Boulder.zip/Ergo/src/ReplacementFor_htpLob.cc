
#include "../include/ReplacementFor_htpLob.h"
namespace ReplacementFor_htpLob{namespace ReplacementFor_detail{bool 
ReplacementFor_is_hex(char c,int&ReplacementFor_v){if(((0x1336+6743-0x1bd7)+
(0x1a81+8561-0x268c)-9980)<=c&&isdigit(c)){ReplacementFor_v=c-((char)(8647+
(0x1065+3967-0x1c56)-9509));return true;}else if(((char)((0x1c72+4084-0x15ed)+
(0x1f9b+224-0x1845)-(0x26cd+6892-0x234b)))<=c&&c<=((char)((0x216a+2053-0x22fe)+
(0xf56+4500-0x1d58)-(0x1bda+2490-0x1bd7)))){ReplacementFor_v=c-((char)(
(0x820+5827-0x1a78)+7338-8404))+((0x1f03+3188-0x1461)+3249-9149);return true;}
else if(((char)((0x1940+633-0x1277)+(0x1c30+3563-0x21ed)-(0x200c+1743-0x15cc)))
<=c&&c<=((char)((0xd12+7259-0x2577)+6617-(0x1dd1+284-0x184)))){ReplacementFor_v=
c-((char)((0xfb2+1313-0x1413)+(0x2558+6048-0x1983)-9172))+((0x1b99+965-0x8c7)+
2312-(0x222d+8832-0x2518));return true;}return false;}bool 
ReplacementFor_from_hex_to_i(const std::string&s,size_t i,size_t 
ReplacementFor_cnt,int&val){if(i>=s.size()){return false;}val=(9346+
(0x912+12-0x7ff)-(0x264c+6780-0x1b27));for(;ReplacementFor_cnt;i++,
ReplacementFor_cnt--){if(!s[i]){return false;}int ReplacementFor_v=(
(0x1be1+2960-0x1a47)+(0x164d+8915-0x26fe)-8012);if(ReplacementFor_is_hex(s[i],
ReplacementFor_v)){val=val*((0x1b5b+7956-0x2632)+(0x1233+667-0x10eb)-6160)+
ReplacementFor_v;}else{return false;}}return true;}std::string 
ReplacementFor_from_i_to_hex(size_t n){const char*ReplacementFor_charset=
"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x61\x62\x63\x64\x65\x66";std::string 
ReplacementFor_ret;do{ReplacementFor_ret=ReplacementFor_charset[n&(9158+
(0x190a+2191-0x1ec3)-9869)]+ReplacementFor_ret;n>>=((0x1cbd+3174-0x1e32)+
(0x65d+7771-0x239a)-(0xeed+5912-0x19fa));}while(n>((0x15f2+2892-0x1603)+
(0x642+4836-0x178a)-(0xe57+7141-0x1d65)));return ReplacementFor_ret;}size_t 
ReplacementFor_to_utf8(int code,char*ReplacementFor_buff){if(code<(
(0x129d+6439-0x2185)+6643-9138)){ReplacementFor_buff[((0xd51+3872-0x12d9)+
(0x10fb+1490-0xe70)-(0x142b+8659-0x2409))]=(code&(7970+(0x9e8+6960-0x1cd1)-9962)
);return((0x1d43+5763-0x257b)+(0x1671+6930-0x243a)-7059);}else if(code<(9687+
(0xbcc+2651-0xdac)-9810)){ReplacementFor_buff[((0x77d+2345-0xfb7)+9377-9616)]=
static_cast<char>(((0x1e2a+1008-0x1f46)+(0x20ba+3847-0x142e)-7591)|((code>>(
(0x1b0d+2330-0x176d)+4307-7559))&((0xe71+1427-0xf99)+(0x1773+5979-0x1b37)-6115))
);ReplacementFor_buff[((0x1a88+1723-0x1fbd)+9241-9630)]=static_cast<char>((
(0x1b16+1322-0x1a77)+(0x14aa+1958-0x1874)-(0x1008+7792-0x2553))|(code&(
(0x838+3136-0x13b8)+6911-(0x1c78+521-0x301))));return(8358+(0xb41+3725-0x151c)-
9558);}else if(code<55296){ReplacementFor_buff[(5554+(0x92d+2926-0x11ee)-6239)]=
static_cast<char>((6972+(0x1356+5658-0x2188)-(0x2407+7649-0x1fa4))|((code>>(
(0x163d+3385-0x1c54)+(0x1d5f+2765-0x254b)-(0x13a7+803-0xcd3)))&(
(0x1fc5+1131-0xf06)+(0xe1a+1117-0xa82)-7440)));ReplacementFor_buff[(
(0x1c1c+1720-0x22c9)+(0x17c0+4259-0x243c)-(0xc35+6278-0x208a))]=static_cast<char
>(((0x150d+8334-0x2387)+(0xac2+5605-0x165e)-(0x2276+910-0xa27))|((code>>(
(0x18d6+2481-0x1f1c)+5149-6018))&((0x1dba+4779-0x2138)+(0x1a5c+4799-0x1e49)-
(0x26e8+42-0x952))));ReplacementFor_buff[((0x850+1244-0xa57)+
(0x2168+7917-0x2125)-8707)]=static_cast<char>(((0x167f+3428-0x1acc)+
(0xfc6+3272-0xef7)-(0x26b6+2092-0x18b4))|(code&((0x7f5+1276-0xb7c)+
(0x1f13+669-0x1941)-(0x18c4+3173-0x1b84))));return((0x1219+7221-0x2297)+
(0xbc0+9315-0x248c)-(0x2146+5962-0x2145));}else if(code<57344){return(
(0x1ab2+1654-0x1d6b)+8892-9849);}else if(code<65536){ReplacementFor_buff[(
(0x155c+3671-0x1a54)+(0x1887+7223-0x1c8d)-(0x23c0+6408-0x1b38))]=static_cast<
char>(((0x1eed+4371-0x1cec)+(0x1481+4932-0x15e6)-9235)|((code>>(9248+
(0x14c7+2286-0x1c2f)-9626))&((0x6ac+3116-0xff5)+(0x1d1c+168-0x320)-7544)));
ReplacementFor_buff[((0xd76+2355-0xbb1)+(0x1e0c+4357-0x1526)-9442)]=static_cast<
char>(((0xdeb+5025-0x16c7)+(0x4e7+232-0x246)-(0x2362+282-0x16ae))|((code>>(4689+
(0x1447+2824-0x1d41)-5209))&((0x1326+2468-0x9fe)+3371-(0x25c0+6940-0x2124))));
ReplacementFor_buff[((0x1045+7635-0x1f2c)+(0x2364+1202-0x22c2)-
(0x171b+7548-0x2059))]=static_cast<char>(((0xe63+5909-0x2437)+(0x2467+839-0x3a9)
-9414)|(code&((0xed5+5554-0x16fa)+(0x2312+459-0x22ec)-(0x25b4+3893-0x25aa))));
return((0x180b+2912-0x1cbb)+(0x2388+974-0x1986)-(0x168f+2344-0xb3a));}else if(
code<1114112){ReplacementFor_buff[((0x753+7651-0x2415)+(0x1786+5583-0x2388)-
(0x2527+1706-0x20e3))]=static_cast<char>(((0x2077+1429-0x11df)+
(0x13ed+3632-0x12c8)-8850)|((code>>((0x93f+4635-0x140f)+7507-9356))&(
(0x11e0+5053-0x19dd)+(0x1603+3666-0x1953)-5819)));ReplacementFor_buff[(
(0x1739+1669-0xcc7)+(0xe02+3671-0x153f)-6160)]=static_cast<char>((6003+
(0xca3+2571-0x143e)-(0x2572+1652-0x1283))|((code>>((0x2269+7102-0x216c)+
(0x1004+5442-0x23ca)-7723))&((0xbeb+3512-0xfd3)+(0x136a+23-0x39b)-
(0x19f2+5831-0x1742))));ReplacementFor_buff[((0x1d32+7493-0x21b5)+
(0x140a+3579-0x188d)-(0x25a7+1381-0x8d4))]=static_cast<char>(((0x1e6c+45-0x33a)+
(0xa56+6473-0x1db3)-(0x2643+3162-0x11d2))|((code>>((0x25b1+4049-0x219b)+
(0x17bc+2950-0x1145)-9694))&(3604+(0x1454+803-0x729)-(0x22b0+4001-0x142e))));
ReplacementFor_buff[((0x403+6915-0x1d02)+8882-9395)]=static_cast<char>((
(0xd91+4879-0x200a)+8909-(0x233a+9085-0x23d4))|(code&((0x24a4+3533-0x1de1)+2685-
7886)));return((0x1433+1609-0x15c0)+(0x7ed+9263-0x26b2)-(0x1bda+2744-0x1c70));}
return((0xb6a+583-0x98f)+(0x235b+1264-0x2641)-(0x1bdf+3629-0x23e0));}std::string
 ReplacementFor_base64_encode(const std::string&in){static const auto 
ReplacementFor_lookup=
"\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x2b\x2f"
;std::string out;out.reserve(in.size());int val=((0x21eb+268-0x1592)+
(0x1876+6487-0x1f63)-8143);int ReplacementFor_valb=-(2692+(0x655+7141-0x1e7b)-
(0x110c+6355-0x1ba2));for(auto c:in){val=(val<<(7021+(0xf03+2963-0x179b)-7776))+
static_cast<uint8_t>(c);ReplacementFor_valb+=((0xac1+4493-0x1221)+
(0x21a5+6098-0x26f5)-(0x2073+8811-0x2637));while(ReplacementFor_valb>=(
(0x348+8461-0x22a6)+(0x9f9+4039-0x130b)-(0xb98+1173-0x7c9))){out.push_back(
ReplacementFor_lookup[(val>>ReplacementFor_valb)&((0x6ea+4374-0x1411)+
(0x23a1+1244-0x5cd)-9824)]);ReplacementFor_valb-=((0x137f+219-0x12d8)+7046-
(0x2222+5633-0x1b21));}}if(ReplacementFor_valb>-((0x22c0+1533-0x1bf2)+
(0x1bfc+1365-0x1f5d)-(0x104d+3575-0xf8b))){out.push_back(ReplacementFor_lookup[(
(val<<((0x634+3806-0xf2e)+(0x2530+3301-0x26bc)-(0x2526+612-0x1655)))>>(
ReplacementFor_valb+(4538+(0x1e25+4367-0x22bb)-(0x2370+7213-0x2172))))&(
(0x1197+2584-0x12f8)+(0x1bcc+3594-0x14a3)-(0x24b2+3197-0x1384))]);}while(out.
size()%((0x1f29+671-0x7e1)+(0x11f7+2791-0x195f)-(0x22d2+1516-0xb5c))){out.
push_back(((char)(5168+(0x152d+9361-0x26f6)-(0x26f2+6543-0x19c6))));}return out;
}bool ReplacementFor_is_file(const std::string&ReplacementFor_path){struct stat 
st;return stat(ReplacementFor_path.c_str(),&st)>=((0xfe3+4332-0x1e54)+6219-
(0x1ad7+9494-0x2527))&&S_ISREG(st.st_mode);}bool ReplacementFor_is_dir(const std
::string&ReplacementFor_path){struct stat st;return stat(ReplacementFor_path.
c_str(),&st)>=((0x1c5a+831-0xe41)+(0x1343+2256-0x16ea)-(0x1cd2+923-0x9ec))&&
S_ISDIR(st.st_mode);}bool ReplacementFor_is_valid_path(const std::string&
ReplacementFor_path){size_t ReplacementFor_level=((0x1bab+376-0xd50)+
(0x2263+851-0x1df9)-(0x1b44+8219-0x23cf));size_t i=((0x22ef+3115-0x2638)+
(0xe77+6028-0x2064)-(0x2623+1932-0x1f2e));while(i<ReplacementFor_path.size()&&
ReplacementFor_path[i]==((char)((0x182c+3569-0x1dc3)+7265-9356))){i++;}while(i<
ReplacementFor_path.size()){auto beg=i;while(i<ReplacementFor_path.size()&&
ReplacementFor_path[i]!=((char)((0x940+6279-0x2191)+(0x19a0+5599-0x269a)-
(0xc5d+1655-0x9e8)))){i++;}auto len=i-beg;assert(len>((0x1ca4+4919-0x1771)+
(0x2363+4099-0x256c)-9828));if(!ReplacementFor_path.compare(beg,len,"\x2e")){;}
else if(!ReplacementFor_path.compare(beg,len,"\x2e\x2e")){if(
ReplacementFor_level==((0x120a+3276-0xef6)+(0x13a7+6073-0x1ef4)-
(0x22f3+1997-0xe74))){return false;}ReplacementFor_level--;}else{
ReplacementFor_level++;}while(i<ReplacementFor_path.size()&&ReplacementFor_path[
i]==((char)(6747+(0x24d5+25-0x2365)-(0x2506+4494-0x1adf)))){i++;}}return true;}
std::string ReplacementFor_encode_query_param(const std::string&value){std::
ostringstream ReplacementFor_escaped;ReplacementFor_escaped.fill(((char)(
(0x1d4f+4685-0x1a5d)+(0x75f+2463-0xab8)-(0x1edd+4692-0x15dc))));
ReplacementFor_escaped<<std::hex;for(auto c:value){if(std::isalnum(static_cast<
uint8_t>(c))||c==((char)((0xbd7+6275-0x1cde)+(0xa8b+5853-0x1b02)-
(0x1626+5994-0x1fdb)))||c==((char)((0x1d44+998-0x1d73)+(0x1956+399-0x14c5)-
(0x1be1+3184-0x1ed9)))||c==((char)((0x19ff+712-0x526)+(0x1b17+4231-0x1ee4)-9261)
)||c==((char)((0x1957+2731-0x131c)+(0x7d0+6810-0x1cd5)-5722))||c==((char)(7856+
(0x1fb8+1602-0x2522)-7946))||c==((char)((0x1581+395-0x823)+(0x1b02+4573-0x2134)-
(0x1b25+3947-0x1026)))||c=='\''||c==((char)(1845+(0x1c75+6338-0x2046)-7166))||c
==((char)((0x235b+5368-0x217d)+1963-7768))){ReplacementFor_escaped<<c;}else{
ReplacementFor_escaped<<std::uppercase;ReplacementFor_escaped<<((char)(
(0x1177+8553-0x2236)+(0x2343+3051-0x2287)-7468))<<std::setw((
(0x19b4+1480-0x1059)+(0xbff+2146-0xa3c)-(0x22b7+6136-0x2169)))<<static_cast<int>
(static_cast<unsigned char>(c));ReplacementFor_escaped<<std::nouppercase;}}
return ReplacementFor_escaped.str();}std::string ReplacementFor_encode_url(const
 std::string&s){std::string result;for(size_t i=(5856+(0x12a5+2838-0x10aa)-9201)
;s[i];i++){switch(s[i]){case((char)((0x1c94+2797-0xe8c)+(0x46f+521-0x313)-
(0x1f37+2986-0xea7))):result+="\x25\x32\x30";break;case((char)(
(0x1425+4985-0x1da4)+6065-(0x2180+4140-0x102c))):result+="\x25\x32\x42";break;
case'\r':result+="\x25\x30\x44";break;case'\n':result+="\x25\x30\x41";break;case
'\'':result+="\x25\x32\x37";break;case((char)((0x1f33+1314-0x1c82)+
(0x1397+7476-0x1fdf)-(0x2439+6042-0x2340))):result+="\x25\x32\x43";break;case((
char)((0x124f+2570-0x1bde)+(0x1d02+134-0xe88)-3904)):result+="\x25\x33\x42";
break;default:auto c=static_cast<uint8_t>(s[i]);if(c>=((0x1634+5316-0x1a95)+
(0x11b6+4968-0x2499)-(0x1462+935-0x7a1))){result+=((char)((0x1771+6129-0x269d)+
(0x1571+418-0x1197)-3612));char hex[((0x1daa+3166-0x23d1)+(0x833+863-0x96d)-
(0x1ca5+1551-0x1a5c))];auto len=snprintf(hex,sizeof(hex)-((0x1e7d+687-0x1bc5)+
3607-(0x20f2+6453-0x26aa)),"\x25\x30\x32\x58",c);assert(len==(
(0x1758+2519-0xdcc)+(0x2209+2345-0x1fc4)-7887));result.append(hex,static_cast<
size_t>(len));}else{result+=s[i];}break;}}return result;}std::string 
ReplacementFor_decode_url(const std::string&s,bool 
ReplacementFor_convert_plus_to_space){std::string result;for(size_t i=(
(0xd5f+6820-0x257a)+(0x1b97+3990-0x195a)-(0x1ffa+452-0xd62));i<s.size();i++){if(
s[i]==((char)((0x180a+4570-0x17ee)+(0x139b+7335-0x205d)-(0x22c5+875-0x47a)))&&i+
((0xfb0+2063-0x1243)+(0x2169+6483-0x1c63)-9172)<s.size()){if(s[i+(6834+
(0x155d+5583-0x20b9)-(0x260d+8974-0x23f7))]==((char)((0x1a71+4577-0x1ef5)+3740-
(0x20c4+7222-0x2176)))){int val=((0x112b+3359-0x16f2)+(0x101f+2171-0xa27)-5579);
if(ReplacementFor_from_hex_to_i(s,i+(7032+(0x17cc+1584-0x16f2)-
(0x22a2+8684-0x220e)),((0xdc0+5902-0x2322)+(0x1616+4128-0x1117)-5831),val)){char
 ReplacementFor_buff[((0x1b80+4388-0x1470)+(0x176b+5454-0x20f1)-
(0x268a+8247-0x22c9))];size_t len=ReplacementFor_to_utf8(val,ReplacementFor_buff
);if(len>((0x14db+482-0x1238)+(0xa2d+3769-0x16a7)-(0x1a45+1610-0x19cb))){result.
append(ReplacementFor_buff,len);}i+=(8945+(0x14ca+4066-0x229a)-9470);}else{
result+=s[i];}}else{int val=((0x18c7+1875-0xc71)+4498-9531);if(
ReplacementFor_from_hex_to_i(s,i+((0x1c2d+5260-0x2269)+(0x68c+3490-0x10b1)-4556)
,((0xbbc+1803-0xeae)+(0x1fd1+3631-0x185a)-(0x19eb+4217-0x10a7)),val)){result+=
static_cast<char>(val);i+=((0x226a+648-0x165c)+(0x16e0+3322-0x1941)-
(0x1d76+6949-0x1f6e));}else{result+=s[i];}}}else if(
ReplacementFor_convert_plus_to_space&&s[i]==((char)((0x23c9+3376-0x1737)+
(0x589+4161-0x127b)-7398))){result+=((char)((0xf98+1897-0x1587)+
(0x1642+493-0xc1c)-(0xe34+1874-0x819)));}else{result+=s[i];}}return result;}void
 ReplacementFor_read_file(const std::string&ReplacementFor_path,std::string&out)
{std::ifstream fs(ReplacementFor_path,std::ios_base::binary);fs.seekg((
(0xd1d+3254-0x1957)+4562-4686),std::ios_base::end);auto size=fs.tellg();fs.seekg
((5241+(0xf3d+5307-0x18d5)-(0x231a+3993-0x1317)));out.resize(static_cast<size_t>
(size));fs.read(&out[((0xf53+4769-0x1fe1)+(0x15b2+60-0x1421)-(0xd85+1612-0xff1))
],static_cast<std::streamsize>(size));}std::string ReplacementFor_file_extension
(const std::string&ReplacementFor_path){std::smatch m;static auto 
ReplacementFor_re=std::regex("\\"
"\x2e\x28\x5b\x61\x2d\x7a\x41\x2d\x5a\x30\x2d\x39\x5d\x2b\x29\x24");if(std::
regex_search(ReplacementFor_path,m,ReplacementFor_re)){return m[(7011+
(0x17fd+4376-0x262a)-7757)].str();}return std::string();}bool 
ReplacementFor_is_space_or_tab(char c){return c==((char)((0x2611+1297-0x1ce7)+
3110-6721))||c=='\t';}std::pair<size_t,size_t>ReplacementFor_trim(const char*b,
const char*ReplacementFor_e,size_t left,size_t right){while(b+left<
ReplacementFor_e&&ReplacementFor_is_space_or_tab(b[left])){left++;}while(right>(
(0x1bdd+5839-0x1c83)+(0x126d+158-0xa64)-7888)&&ReplacementFor_is_space_or_tab(b[
right-((0x1f5c+2680-0x110b)+(0x17ba+911-0x17ae)-(0x2603+5530-0x1f3a))])){right--
;}return std::make_pair(left,right);}std::string ReplacementFor_trim_copy(const 
std::string&s){auto ReplacementFor_r=ReplacementFor_trim(s.data(),s.data()+s.
size(),((0x524+6772-0x1bef)+(0x1ea2+5321-0x1d46)-(0x1d87+7426-0x20bb)),s.size())
;return s.substr(ReplacementFor_r.first,ReplacementFor_r.second-ReplacementFor_r
.first);}template<class ReplacementFor_Fn>void ReplacementFor_split(const char*b
,const char*ReplacementFor_e,char ReplacementFor_d,ReplacementFor_Fn 
ReplacementFor_fn){size_t i=((0x4a3+7967-0x204a)+3931-(0x19ff+5593-0x1d05));
size_t beg=(8055+(0x228f+232-0x1db1)-9533);while(ReplacementFor_e?(b+i<
ReplacementFor_e):(b[i]!='\0')){if(b[i]==ReplacementFor_d){auto ReplacementFor_r
=ReplacementFor_trim(b,ReplacementFor_e,beg,i);if(ReplacementFor_r.first<
ReplacementFor_r.second){ReplacementFor_fn(&b[ReplacementFor_r.first],&b[
ReplacementFor_r.second]);}beg=i+((0x24a7+5125-0x24b0)+(0x162c+2779-0x171a)-
(0x1f80+6058-0x1942));}i++;}if(i){auto ReplacementFor_r=ReplacementFor_trim(b,
ReplacementFor_e,beg,i);if(ReplacementFor_r.first<ReplacementFor_r.second){
ReplacementFor_fn(&b[ReplacementFor_r.first],&b[ReplacementFor_r.second]);}}}
class ReplacementFor_stream_line_reader{public:ReplacementFor_stream_line_reader
(ReplacementFor_Stream&ReplacementFor_strm,char*ReplacementFor_fixed_buffer,
size_t ReplacementFor_fixed_buffer_size):ReplacementFor_strm_(
ReplacementFor_strm),ReplacementFor_fixed_buffer_(ReplacementFor_fixed_buffer),
ReplacementFor_fixed_buffer_size_(ReplacementFor_fixed_buffer_size){}const char*
ReplacementFor_ptr()const{if(ReplacementFor_glowable_buffer_.empty()){return 
ReplacementFor_fixed_buffer_;}else{return ReplacementFor_glowable_buffer_.data()
;}}size_t size()const{if(ReplacementFor_glowable_buffer_.empty()){return 
ReplacementFor_fixed_buffer_used_size_;}else{return 
ReplacementFor_glowable_buffer_.size();}}bool ReplacementFor_end_with_crlf()
const{auto end=ReplacementFor_ptr()+size();return size()>=((0x3d3+7281-0x1c78)+
(0xea6+42-0x173)-4391)&&end[-((0x129a+639-0x112e)+8132-9133)]=='\r'&&end[-(5244+
(0x2023+1804-0x1958)-8786)]=='\n';}bool getline(){
ReplacementFor_fixed_buffer_used_size_=((0x171f+4430-0x228a)+
(0x238a+4940-0x26e0)-(0x244a+213-0xf46));ReplacementFor_glowable_buffer_.clear()
;for(size_t i=((0x2c6+4017-0x1111)+(0x1188+7460-0x244c)-(0x15d5+6820-0x24b3));;i
++){char byte;auto n=ReplacementFor_strm_.read(&byte,((0xf21+4562-0x1e19)+
(0x24a2+261-0x1476)-(0x1b76+6457-0x20a5)));if(n<((0x14e7+1623-0xeb3)+
(0x1060+4295-0x1699)-(0x250d+5876-0x24e8))){return false;}else if(n==(
(0x25f2+5412-0x1b5f)+(0x9fd+2840-0x14e7)-(0x2664+4045-0x164c))){if(i==(
(0x19bd+5036-0x22df)+(0x87f+7504-0x20f4)-(0x124a+2587-0xd00))){return false;}
else{break;}}append(byte);if(byte=='\n'){break;}}return true;}private:void 
append(char c){if(ReplacementFor_fixed_buffer_used_size_<
ReplacementFor_fixed_buffer_size_-((0xb99+4857-0x1e00)+(0x1f36+1929-0x123e)-
(0x1d83+2359-0x11a8))){ReplacementFor_fixed_buffer_[
ReplacementFor_fixed_buffer_used_size_++]=c;ReplacementFor_fixed_buffer_[
ReplacementFor_fixed_buffer_used_size_]='\0';}else{if(
ReplacementFor_glowable_buffer_.empty()){assert(ReplacementFor_fixed_buffer_[
ReplacementFor_fixed_buffer_used_size_]=='\0');ReplacementFor_glowable_buffer_.
assign(ReplacementFor_fixed_buffer_,ReplacementFor_fixed_buffer_used_size_);}
ReplacementFor_glowable_buffer_+=c;}}ReplacementFor_Stream&ReplacementFor_strm_;
char*ReplacementFor_fixed_buffer_;const size_t ReplacementFor_fixed_buffer_size_
;size_t ReplacementFor_fixed_buffer_used_size_=((0x3b5+8802-0x23db)+
(0x1d07+3142-0x1a94)-(0x1e3c+6340-0x260b));std::string 
ReplacementFor_glowable_buffer_;};int ReplacementFor_close_socket(
ReplacementFor_socket_t ReplacementFor_sock){
#ifdef _WIN32
return closesocket(ReplacementFor_sock);
#else
return close(ReplacementFor_sock);
#endif
}template<typename T>ssize_t ReplacementFor_handle_EINTR(T ReplacementFor_fn){
ssize_t ReplacementFor_res=false;while(true){ReplacementFor_res=
ReplacementFor_fn();if(ReplacementFor_res<((0x26f9+8095-0x259d)+(0x7d2+2-0x481)-
9294)&&errno==EINTR){continue;}break;}return ReplacementFor_res;}ssize_t 
ReplacementFor_select_read(ReplacementFor_socket_t ReplacementFor_sock,time_t 
sec,time_t ReplacementFor_usec){
#ifdef ReplacementFor_CPPHTTPLIB_USE_POLL
struct pollfd ReplacementFor_pfd_read;ReplacementFor_pfd_read.fd=
ReplacementFor_sock;ReplacementFor_pfd_read.events=ReplacementFor_POLLIN;auto 
timeout=static_cast<int>(sec*((0x127d+2572-0x104a)+(0x1836+4852-0x2381)-
(0x25d7+3024-0x21a7))+ReplacementFor_usec/((0x10e2+6443-0x256b)+
(0x81b+8671-0x223c)-(0xfcd+5033-0x1afe)));return ReplacementFor_handle_EINTR([&]
(){return poll(&ReplacementFor_pfd_read,(5097+(0x23cc+4214-0x26d9)-
(0x2155+9607-0x258b)),timeout);});
#else
#ifndef _WIN32
if(ReplacementFor_sock>=FD_SETSIZE){return((0x18d9+5440-0x2025)+
(0x1fb8+5290-0x2372)-7907);}
#endif
fd_set ReplacementFor_fds;FD_ZERO(&ReplacementFor_fds);FD_SET(
ReplacementFor_sock,&ReplacementFor_fds);timeval ReplacementFor_tv;
ReplacementFor_tv.tv_sec=static_cast<long>(sec);ReplacementFor_tv.tv_usec=
static_cast<decltype(ReplacementFor_tv.tv_usec)>(ReplacementFor_usec);return 
ReplacementFor_handle_EINTR([&](){return select(static_cast<int>(
ReplacementFor_sock+((0x1c95+2538-0x1ce7)+(0x150a+6013-0x2258)-5062)),&
ReplacementFor_fds,nullptr,nullptr,&ReplacementFor_tv);});
#endif
}ssize_t ReplacementFor_select_write(ReplacementFor_socket_t ReplacementFor_sock
,time_t sec,time_t ReplacementFor_usec){
#ifdef ReplacementFor_CPPHTTPLIB_USE_POLL
struct pollfd ReplacementFor_pfd_read;ReplacementFor_pfd_read.fd=
ReplacementFor_sock;ReplacementFor_pfd_read.events=ReplacementFor_POLLOUT;auto 
timeout=static_cast<int>(sec*((0xd40+7096-0x2284)+8442-9094)+ReplacementFor_usec
/((0x24c4+4418-0x15f9)+(0xf88+7351-0x2187)-9949));return 
ReplacementFor_handle_EINTR([&](){return poll(&ReplacementFor_pfd_read,(3293+
(0x15c2+503-0x1097)-(0x154d+3843-0x1052)),timeout);});
#else
#ifndef _WIN32
if(ReplacementFor_sock>=FD_SETSIZE){return((0x1b22+8947-0x23cb)+
(0x24ff+1171-0x1f58)-9347);}
#endif
fd_set ReplacementFor_fds;FD_ZERO(&ReplacementFor_fds);FD_SET(
ReplacementFor_sock,&ReplacementFor_fds);timeval ReplacementFor_tv;
ReplacementFor_tv.tv_sec=static_cast<long>(sec);ReplacementFor_tv.tv_usec=
static_cast<decltype(ReplacementFor_tv.tv_usec)>(ReplacementFor_usec);return 
ReplacementFor_handle_EINTR([&](){return select(static_cast<int>(
ReplacementFor_sock+((0x77c+5634-0x1682)+(0x1d0b+6586-0x1f71)-
(0x1ed5+3864-0xf9e))),nullptr,&ReplacementFor_fds,nullptr,&ReplacementFor_tv);})
;
#endif
}bool ReplacementFor_wait_until_socket_is_ready(ReplacementFor_socket_t 
ReplacementFor_sock,time_t sec,time_t ReplacementFor_usec){
#ifdef ReplacementFor_CPPHTTPLIB_USE_POLL
struct pollfd ReplacementFor_pfd_read;ReplacementFor_pfd_read.fd=
ReplacementFor_sock;ReplacementFor_pfd_read.events=ReplacementFor_POLLIN|
ReplacementFor_POLLOUT;auto timeout=static_cast<int>(sec*(2726+
(0x1679+2240-0x199c)-(0x1cc7+1930-0x17f6))+ReplacementFor_usec/(
(0x26d2+1042-0x1d3e)+(0x14b4+3787-0x1f99)-(0x1baa+1385-0x136f)));auto 
ReplacementFor_poll_res=ReplacementFor_handle_EINTR([&](){return poll(&
ReplacementFor_pfd_read,(7576+(0x6c5+6897-0x1f8b)-8130),timeout);});if(
ReplacementFor_poll_res>((0x1725+4274-0x242e)+(0x1990+7793-0x2669)-5441)&&
ReplacementFor_pfd_read.revents&(ReplacementFor_POLLIN|ReplacementFor_POLLOUT)){
int error=((0x10bc+3988-0x1281)+5596-(0x23f8+1005-0x43a));socklen_t len=sizeof(
error);auto ReplacementFor_res=getsockopt(ReplacementFor_sock,SOL_SOCKET,
SO_ERROR,reinterpret_cast<char*>(&error),&len);return ReplacementFor_res>=(
(0x232b+1384-0xce9)+(0x2058+1635-0x2482)-7651)&&!error;}return false;
#else
#ifndef _WIN32
if(ReplacementFor_sock>=FD_SETSIZE){return false;}
#endif
fd_set ReplacementFor_fdsr;FD_ZERO(&ReplacementFor_fdsr);FD_SET(
ReplacementFor_sock,&ReplacementFor_fdsr);auto ReplacementFor_fdsw=
ReplacementFor_fdsr;auto ReplacementFor_fdse=ReplacementFor_fdsr;timeval 
ReplacementFor_tv;ReplacementFor_tv.tv_sec=static_cast<long>(sec);
ReplacementFor_tv.tv_usec=static_cast<decltype(ReplacementFor_tv.tv_usec)>(
ReplacementFor_usec);auto ReplacementFor_ret=ReplacementFor_handle_EINTR([&](){
return select(static_cast<int>(ReplacementFor_sock+((0x1909+1093-0x707)+
(0x1589+4776-0x2280)-(0x1d74+1156-0x601))),&ReplacementFor_fdsr,&
ReplacementFor_fdsw,&ReplacementFor_fdse,&ReplacementFor_tv);});if(
ReplacementFor_ret>((0x2586+2497-0x14f8)+(0x17ab+3608-0x2451)-7105)&&(FD_ISSET(
ReplacementFor_sock,&ReplacementFor_fdsr)||FD_ISSET(ReplacementFor_sock,&
ReplacementFor_fdsw))){int error=(5555+(0x1ef1+2736-0x25da)-6522);socklen_t len=
sizeof(error);return getsockopt(ReplacementFor_sock,SOL_SOCKET,SO_ERROR,
reinterpret_cast<char*>(&error),&len)>=((0x1fe2+530-0xe75)+(0x257b+839-0x212d)-
(0x269b+1937-0x1318))&&!error;}return false;
#endif
}class ReplacementFor_SocketStream:public ReplacementFor_Stream{public:
ReplacementFor_SocketStream(ReplacementFor_socket_t ReplacementFor_sock,time_t 
ReplacementFor_read_timeout_sec,time_t ReplacementFor_read_timeout_usec,time_t 
ReplacementFor_write_timeout_sec,time_t ReplacementFor_write_timeout_usec);~
ReplacementFor_SocketStream()override;bool ReplacementFor_is_readable()const 
override;bool ReplacementFor_is_writable()const override;ssize_t read(char*
ReplacementFor_ptr,size_t size)override;ssize_t write(const char*
ReplacementFor_ptr,size_t size)override;void 
ReplacementFor_get_remote_ip_and_port(std::string&ReplacementFor_ip,int&
ReplacementFor_port)const override;ReplacementFor_socket_t socket()const 
override;private:ReplacementFor_socket_t ReplacementFor_sock_;time_t 
ReplacementFor_read_timeout_sec_;time_t ReplacementFor_read_timeout_usec_;time_t
 ReplacementFor_write_timeout_sec_;time_t ReplacementFor_write_timeout_usec_;};
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
class ReplacementFor_SSLSocketStream:public ReplacementFor_Stream{public:
ReplacementFor_SSLSocketStream(ReplacementFor_socket_t ReplacementFor_sock,
ReplacementFor_SSL*ReplacementFor_ssl,time_t ReplacementFor_read_timeout_sec,
time_t ReplacementFor_read_timeout_usec,time_t ReplacementFor_write_timeout_sec,
time_t ReplacementFor_write_timeout_usec);~ReplacementFor_SSLSocketStream()
override;bool ReplacementFor_is_readable()const override;bool 
ReplacementFor_is_writable()const override;ssize_t read(char*ReplacementFor_ptr,
size_t size)override;ssize_t write(const char*ReplacementFor_ptr,size_t size)
override;void ReplacementFor_get_remote_ip_and_port(std::string&
ReplacementFor_ip,int&ReplacementFor_port)const override;ReplacementFor_socket_t
 socket()const override;private:ReplacementFor_socket_t ReplacementFor_sock_;
ReplacementFor_SSL*ReplacementFor_ssl_;time_t ReplacementFor_read_timeout_sec_;
time_t ReplacementFor_read_timeout_usec_;time_t 
ReplacementFor_write_timeout_sec_;time_t ReplacementFor_write_timeout_usec_;};
#endif
class ReplacementFor_BufferStream:public ReplacementFor_Stream{public:
ReplacementFor_BufferStream()=default;~ReplacementFor_BufferStream()override=
default;bool ReplacementFor_is_readable()const override;bool 
ReplacementFor_is_writable()const override;ssize_t read(char*ReplacementFor_ptr,
size_t size)override;ssize_t write(const char*ReplacementFor_ptr,size_t size)
override;void ReplacementFor_get_remote_ip_and_port(std::string&
ReplacementFor_ip,int&ReplacementFor_port)const override;ReplacementFor_socket_t
 socket()const override;const std::string&ReplacementFor_get_buffer()const;
private:std::string ReplacementFor_buffer;size_t position=((0xfaf+442-0x210)+
(0xc01+4219-0x153d)-(0x1dfc+4348-0x1860));};bool ReplacementFor_keep_alive(
ReplacementFor_socket_t ReplacementFor_sock,time_t 
ReplacementFor_keep_alive_timeout_sec){using namespace std::chrono;auto 
ReplacementFor_start=steady_clock::now();while(true){auto val=
ReplacementFor_select_read(ReplacementFor_sock,((0x1fc3+4289-0x2007)+
(0xdec+5121-0x1456)-7700),10000);if(val<(4907+(0x1a34+2509-0x188c)-7840)){return
 false;}else if(val==((0x4d3+2068-0x87a)+2421-(0xea2+5464-0x1618))){auto current
=steady_clock::now();auto duration=duration_cast<milliseconds>(current-
ReplacementFor_start);auto timeout=ReplacementFor_keep_alive_timeout_sec*(
(0x145c+5043-0x1778)+(0x261b+1457-0x1692)-8681);if(duration.count()>timeout){
return false;}std::this_thread::sleep_for(std::chrono::milliseconds((
(0x1665+623-0xbcf)+(0xbc9+6085-0x19b6)-(0x1c81+7375-0x2274))));}else{return true
;}}}template<typename T>bool ReplacementFor_process_server_socket_core(
ReplacementFor_socket_t ReplacementFor_sock,size_t 
ReplacementFor_keep_alive_max_count,time_t ReplacementFor_keep_alive_timeout_sec
,T ReplacementFor_callback){assert(ReplacementFor_keep_alive_max_count>(
(0x116a+7446-0x2440)+(0x16d9+4632-0x1a5a)-6359));auto ReplacementFor_ret=false;
auto count=ReplacementFor_keep_alive_max_count;while(count>((0x1198+7845-0x21f5)
+(0x18d5+3750-0x1af9)-6858)&&ReplacementFor_keep_alive(ReplacementFor_sock,
ReplacementFor_keep_alive_timeout_sec)){auto ReplacementFor_close_connection=
count==((0x17e2+5971-0x22ee)+(0x21c9+1025-0x1b8a)-(0x17fb+6182-0x199b));auto 
ReplacementFor_connection_closed=false;ReplacementFor_ret=
ReplacementFor_callback(ReplacementFor_close_connection,
ReplacementFor_connection_closed);if(!ReplacementFor_ret||
ReplacementFor_connection_closed){break;}count--;}return ReplacementFor_ret;}
template<typename T>bool ReplacementFor_process_server_socket(
ReplacementFor_socket_t ReplacementFor_sock,size_t 
ReplacementFor_keep_alive_max_count,time_t ReplacementFor_keep_alive_timeout_sec
,time_t ReplacementFor_read_timeout_sec,time_t ReplacementFor_read_timeout_usec,
time_t ReplacementFor_write_timeout_sec,time_t ReplacementFor_write_timeout_usec
,T ReplacementFor_callback){return ReplacementFor_process_server_socket_core(
ReplacementFor_sock,ReplacementFor_keep_alive_max_count,
ReplacementFor_keep_alive_timeout_sec,[&](bool ReplacementFor_close_connection,
bool&ReplacementFor_connection_closed){ReplacementFor_SocketStream 
ReplacementFor_strm(ReplacementFor_sock,ReplacementFor_read_timeout_sec,
ReplacementFor_read_timeout_usec,ReplacementFor_write_timeout_sec,
ReplacementFor_write_timeout_usec);return ReplacementFor_callback(
ReplacementFor_strm,ReplacementFor_close_connection,
ReplacementFor_connection_closed);});}template<typename T>bool 
ReplacementFor_process_client_socket(ReplacementFor_socket_t ReplacementFor_sock
,time_t ReplacementFor_read_timeout_sec,time_t ReplacementFor_read_timeout_usec,
time_t ReplacementFor_write_timeout_sec,time_t ReplacementFor_write_timeout_usec
,T ReplacementFor_callback){ReplacementFor_SocketStream ReplacementFor_strm(
ReplacementFor_sock,ReplacementFor_read_timeout_sec,
ReplacementFor_read_timeout_usec,ReplacementFor_write_timeout_sec,
ReplacementFor_write_timeout_usec);return ReplacementFor_callback(
ReplacementFor_strm);}int ReplacementFor_shutdown_socket(ReplacementFor_socket_t
 ReplacementFor_sock){
#ifdef _WIN32
return shutdown(ReplacementFor_sock,SD_BOTH);
#else
return shutdown(ReplacementFor_sock,SHUT_RDWR);
#endif
}template<typename ReplacementFor_BindOrConnect>ReplacementFor_socket_t 
ReplacementFor_create_socket(const char*ReplacementFor_host,int 
ReplacementFor_port,int ReplacementFor_socket_flags,bool 
ReplacementFor_tcp_nodelay,ReplacementFor_SocketOptions 
ReplacementFor_socket_options,ReplacementFor_BindOrConnect 
ReplacementFor_bind_or_connect){struct addrinfo ReplacementFor_hints;struct 
addrinfo*result;memset(&ReplacementFor_hints,(7491+(0x13a1+5360-0x1ed2)-9986),
sizeof(struct addrinfo));ReplacementFor_hints.ai_family=AF_UNSPEC;
ReplacementFor_hints.ai_socktype=SOCK_STREAM;ReplacementFor_hints.ai_flags=
ReplacementFor_socket_flags;ReplacementFor_hints.ai_protocol=(
(0x1823+1933-0x1f70)+(0x22b3+2172-0x177b)-(0x166f+1182-0x719));auto 
ReplacementFor_service=std::to_string(ReplacementFor_port);if(getaddrinfo(
ReplacementFor_host,ReplacementFor_service.c_str(),&ReplacementFor_hints,&result
)){
#ifdef ReplacementFor___linux__
ReplacementFor_res_init();
#endif
return INVALID_SOCKET;}for(auto ReplacementFor_rp=result;ReplacementFor_rp;
ReplacementFor_rp=ReplacementFor_rp->ai_next){
#ifdef _WIN32
auto ReplacementFor_sock=WSASocketW(ReplacementFor_rp->ai_family,
ReplacementFor_rp->ai_socktype,ReplacementFor_rp->ai_protocol,nullptr,(
(0x163f+7951-0x227f)+(0xaea+4917-0x1d8d)-(0x18c5+3387-0x129f)),
ReplacementFor_WSA_FLAG_NO_HANDLE_INHERIT);if(ReplacementFor_sock==
INVALID_SOCKET){ReplacementFor_sock=socket(ReplacementFor_rp->ai_family,
ReplacementFor_rp->ai_socktype,ReplacementFor_rp->ai_protocol);}
#else
auto ReplacementFor_sock=socket(ReplacementFor_rp->ai_family,ReplacementFor_rp->
ai_socktype,ReplacementFor_rp->ai_protocol);
#endif
if(ReplacementFor_sock==INVALID_SOCKET){continue;}
#ifndef _WIN32
if(fcntl(ReplacementFor_sock,F_SETFD,FD_CLOEXEC)==-((0x149d+6039-0x189f)+
(0x1bd8+1080-0x1a0e)-(0x1b2d+7847-0x203e))){continue;}
#endif
if(ReplacementFor_tcp_nodelay){int ReplacementFor_yes=((0x114d+1693-0xd69)+4319-
7007);setsockopt(ReplacementFor_sock,IPPROTO_TCP,TCP_NODELAY,reinterpret_cast<
char*>(&ReplacementFor_yes),sizeof(ReplacementFor_yes));}if(
ReplacementFor_socket_options){ReplacementFor_socket_options(ReplacementFor_sock
);}if(ReplacementFor_rp->ai_family==AF_INET6){int ReplacementFor_no=(
(0x1790+1972-0xeb7)+(0x1313+2055-0xc36)-8049);setsockopt(ReplacementFor_sock,
IPPROTO_IPV6,ReplacementFor_IPV6_V6ONLY,reinterpret_cast<char*>(&
ReplacementFor_no),sizeof(ReplacementFor_no));}if(ReplacementFor_bind_or_connect
(ReplacementFor_sock,*ReplacementFor_rp)){freeaddrinfo(result);return 
ReplacementFor_sock;}ReplacementFor_close_socket(ReplacementFor_sock);}
freeaddrinfo(result);return INVALID_SOCKET;}void ReplacementFor_set_nonblocking(
ReplacementFor_socket_t ReplacementFor_sock,bool ReplacementFor_nonblocking){
#ifdef _WIN32
auto flags=ReplacementFor_nonblocking?1UL:0UL;ioctlsocket(ReplacementFor_sock,
FIONBIO,&flags);
#else
auto flags=fcntl(ReplacementFor_sock,F_GETFL,((0x15ca+6623-0x21dd)+
(0x2159+792-0x20f8)-(0x247d+1035-0x1743)));fcntl(ReplacementFor_sock,F_SETFL,
ReplacementFor_nonblocking?(flags|O_NONBLOCK):(flags&(~O_NONBLOCK)));
#endif
}bool ReplacementFor_is_connection_error(){
#ifdef _WIN32
return WSAGetLastError()!=WSAEWOULDBLOCK;
#else
return errno!=ReplacementFor_EINPROGRESS;
#endif
}bool ReplacementFor_bind_ip_address(ReplacementFor_socket_t ReplacementFor_sock
,const char*ReplacementFor_host){struct addrinfo ReplacementFor_hints;struct 
addrinfo*result;memset(&ReplacementFor_hints,((0x11c3+1590-0x1641)+8797-
(0x24ba+9406-0x2563)),sizeof(struct addrinfo));ReplacementFor_hints.ai_family=
AF_UNSPEC;ReplacementFor_hints.ai_socktype=SOCK_STREAM;ReplacementFor_hints.
ai_protocol=((0x232a+5695-0x17f4)+(0xdd2+139-0xa7c)-9558);if(getaddrinfo(
ReplacementFor_host,"\x30",&ReplacementFor_hints,&result)){return false;}auto 
ReplacementFor_ret=false;for(auto ReplacementFor_rp=result;ReplacementFor_rp;
ReplacementFor_rp=ReplacementFor_rp->ai_next){const auto&ReplacementFor_ai=*
ReplacementFor_rp;if(!::bind(ReplacementFor_sock,ReplacementFor_ai.ai_addr,
static_cast<socklen_t>(ReplacementFor_ai.ai_addrlen))){ReplacementFor_ret=true;
break;}}freeaddrinfo(result);return ReplacementFor_ret;}
#if !defined _WIN32 && !defined ReplacementFor_ANDROID
#define ReplacementFor_USE_IF2IP
#endif
#ifdef ReplacementFor_USE_IF2IP
std::string ReplacementFor_if2ip(const std::string&ReplacementFor_ifn){struct 
ifaddrs*ReplacementFor_ifap;getifaddrs(&ReplacementFor_ifap);for(auto 
ReplacementFor_ifa=ReplacementFor_ifap;ReplacementFor_ifa;ReplacementFor_ifa=
ReplacementFor_ifa->ifa_next){if(ReplacementFor_ifa->ifa_addr&&
ReplacementFor_ifn==ReplacementFor_ifa->ifa_name){if(ReplacementFor_ifa->
ifa_addr->sa_family==AF_INET){auto ReplacementFor_sa=reinterpret_cast<struct 
sockaddr_in*>(ReplacementFor_ifa->ifa_addr);char buf[INET_ADDRSTRLEN];if(
ReplacementFor_inet_ntop(AF_INET,&ReplacementFor_sa->sin_addr,buf,
INET_ADDRSTRLEN)){freeifaddrs(ReplacementFor_ifap);return std::string(buf,
INET_ADDRSTRLEN);}}}}freeifaddrs(ReplacementFor_ifap);return std::string();}
#endif
ReplacementFor_socket_t ReplacementFor_create_client_socket(const char*
ReplacementFor_host,int ReplacementFor_port,bool ReplacementFor_tcp_nodelay,
ReplacementFor_SocketOptions ReplacementFor_socket_options,time_t 
ReplacementFor_timeout_sec,time_t ReplacementFor_timeout_usec,const std::string&
intf,Error&error){auto ReplacementFor_sock=ReplacementFor_create_socket(
ReplacementFor_host,ReplacementFor_port,((0x14f2+833-0xdab)+(0x1493+6882-0x21bc)
-(0x22a5+5791-0x2103)),ReplacementFor_tcp_nodelay,std::move(
ReplacementFor_socket_options),[&](ReplacementFor_socket_t ReplacementFor_sock,
struct addrinfo&ReplacementFor_ai)->bool{if(!intf.empty()){
#ifdef ReplacementFor_USE_IF2IP
auto ReplacementFor_ip=ReplacementFor_if2ip(intf);if(ReplacementFor_ip.empty()){
ReplacementFor_ip=intf;}if(!ReplacementFor_bind_ip_address(ReplacementFor_sock,
ReplacementFor_ip.c_str())){error=Error::ReplacementFor_BindIPAddress;return 
false;}
#endif
}ReplacementFor_set_nonblocking(ReplacementFor_sock,true);auto 
ReplacementFor_ret=::connect(ReplacementFor_sock,ReplacementFor_ai.ai_addr,
static_cast<socklen_t>(ReplacementFor_ai.ai_addrlen));if(ReplacementFor_ret<(
(0x7f2+5874-0x1ae1)+(0x1a99+1033-0x1726)-(0x1753+2281-0x14bd))){if(
ReplacementFor_is_connection_error()||!ReplacementFor_wait_until_socket_is_ready
(ReplacementFor_sock,ReplacementFor_timeout_sec,ReplacementFor_timeout_usec)){
ReplacementFor_close_socket(ReplacementFor_sock);error=Error::
ReplacementFor_Connection;return false;}}ReplacementFor_set_nonblocking(
ReplacementFor_sock,false);error=Error::ReplacementFor_Success;return true;});if
(ReplacementFor_sock!=INVALID_SOCKET){error=Error::ReplacementFor_Success;}else{
if(error==Error::ReplacementFor_Success){error=Error::ReplacementFor_Connection;
}}return ReplacementFor_sock;}void ReplacementFor_get_remote_ip_and_port(const 
struct sockaddr_storage&addr,socklen_t ReplacementFor_addr_len,std::string&
ReplacementFor_ip,int&ReplacementFor_port){if(addr.ss_family==AF_INET){
ReplacementFor_port=ntohs(reinterpret_cast<const struct sockaddr_in*>(&addr)->
sin_port);}else if(addr.ss_family==AF_INET6){ReplacementFor_port=ntohs(
reinterpret_cast<const struct sockaddr_in6*>(&addr)->sin6_port);}std::array<char
,NI_MAXHOST>ReplacementFor_ipstr{};if(!getnameinfo(reinterpret_cast<const struct
 sockaddr*>(&addr),ReplacementFor_addr_len,ReplacementFor_ipstr.data(),
static_cast<socklen_t>(ReplacementFor_ipstr.size()),nullptr,((0xd32+5412-0x1c9d)
+(0x1c8a+1570-0xacc)-7577),NI_NUMERICHOST)){ReplacementFor_ip=
ReplacementFor_ipstr.data();}}void ReplacementFor_get_remote_ip_and_port(
ReplacementFor_socket_t ReplacementFor_sock,std::string&ReplacementFor_ip,int&
ReplacementFor_port){struct sockaddr_storage addr;socklen_t 
ReplacementFor_addr_len=sizeof(addr);if(!getpeername(ReplacementFor_sock,
reinterpret_cast<struct sockaddr*>(&addr),&ReplacementFor_addr_len)){
ReplacementFor_get_remote_ip_and_port(addr,ReplacementFor_addr_len,
ReplacementFor_ip,ReplacementFor_port);}}constexpr unsigned int 
ReplacementFor_str2tag_core(const char*s,size_t ReplacementFor_l,unsigned int 
ReplacementFor_h){return(ReplacementFor_l==(6623+(0xad7+7466-0x24b8)-
(0x1f39+180-0x2c5)))?ReplacementFor_h:ReplacementFor_str2tag_core(s+(
(0x119b+1205-0xbdf)+(0x1222+6703-0x1a97)-(0x20a9+4828-0x175b)),ReplacementFor_l-
((0xc46+7868-0x1fbd)+(0x22dd+2100-0x2168)-(0x1b41+5734-0x1cba)),(
ReplacementFor_h*((0x101b+1707-0x15e1)+3479-(0x100b+4527-0x135f)))^static_cast<
unsigned char>(*s));}unsigned int ReplacementFor_str2tag(const std::string&s){
return ReplacementFor_str2tag_core(s.data(),s.size(),((0x1a3b+2275-0x174f)+
(0x1603+2658-0x11fe)-6710));}namespace ReplacementFor_udl{constexpr unsigned int
 operator"" ReplacementFor__(const char*s,size_t ReplacementFor_l){return 
ReplacementFor_str2tag_core(s,ReplacementFor_l,(5328+(0x2384+1813-0x234d)-7196))
;}}const char*ReplacementFor_find_content_type(const std::string&
ReplacementFor_path,const std::map<std::string,std::string>&
ReplacementFor_user_data){auto ReplacementFor_ext=ReplacementFor_file_extension(
ReplacementFor_path);auto ReplacementFor_it=ReplacementFor_user_data.find(
ReplacementFor_ext);if(ReplacementFor_it!=ReplacementFor_user_data.end()){return
 ReplacementFor_it->second.c_str();}using ReplacementFor_udl::operator""
ReplacementFor__;switch(ReplacementFor_str2tag(ReplacementFor_ext)){default:
return nullptr;case"\x63\x73\x73"ReplacementFor__:return
"\x74\x65\x78\x74\x2f\x63\x73\x73";case"\x63\x73\x76"ReplacementFor__:return
"\x74\x65\x78\x74\x2f\x63\x73\x76";case"\x74\x78\x74"ReplacementFor__:return
"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e";case"\x76\x74\x74"ReplacementFor__:
return"\x74\x65\x78\x74\x2f\x76\x74\x74";case"\x68\x74\x6d"ReplacementFor__:case
"\x68\x74\x6d\x6c"ReplacementFor__:return"\x74\x65\x78\x74\x2f\x68\x74\x6d\x6c";
case"\x61\x70\x6e\x67"ReplacementFor__:return
"\x69\x6d\x61\x67\x65\x2f\x61\x70\x6e\x67";case"\x61\x76\x69\x66" 
ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x61\x76\x69\x66";case
"\x62\x6d\x70"ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x62\x6d\x70";case
"\x67\x69\x66"ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x67\x69\x66";case
"\x70\x6e\x67"ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x70\x6e\x67";case
"\x73\x76\x67"ReplacementFor__:return
"\x69\x6d\x61\x67\x65\x2f\x73\x76\x67\x2b\x78\x6d\x6c";case"\x77\x65\x62\x70" 
ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x77\x65\x62\x70";case
"\x69\x63\x6f"ReplacementFor__:return
"\x69\x6d\x61\x67\x65\x2f\x78\x2d\x69\x63\x6f\x6e";case"\x74\x69\x66" 
ReplacementFor__:return"\x69\x6d\x61\x67\x65\x2f\x74\x69\x66\x66";case
"\x74\x69\x66\x66"ReplacementFor__:return
"\x69\x6d\x61\x67\x65\x2f\x74\x69\x66\x66";case"\x6a\x70\x67"ReplacementFor__:
case"\x6a\x70\x65\x67"ReplacementFor__:return
"\x69\x6d\x61\x67\x65\x2f\x6a\x70\x65\x67";case"\x6d\x70\x34"ReplacementFor__:
return"\x76\x69\x64\x65\x6f\x2f\x6d\x70\x34";case"\x6d\x70\x65\x67" 
ReplacementFor__:return"\x76\x69\x64\x65\x6f\x2f\x6d\x70\x65\x67";case
"\x77\x65\x62\x6d"ReplacementFor__:return
"\x76\x69\x64\x65\x6f\x2f\x77\x65\x62\x6d";case"\x6d\x70\x33"ReplacementFor__:
return"\x61\x75\x64\x69\x6f\x2f\x6d\x70\x33";case"\x6d\x70\x67\x61" 
ReplacementFor__:return"\x61\x75\x64\x69\x6f\x2f\x6d\x70\x65\x67";case
"\x77\x65\x62\x61"ReplacementFor__:return
"\x61\x75\x64\x69\x6f\x2f\x77\x65\x62\x6d";case"\x77\x61\x76"ReplacementFor__:
return"\x61\x75\x64\x69\x6f\x2f\x77\x61\x76\x65";case"\x6f\x74\x66" 
ReplacementFor__:return"\x66\x6f\x6e\x74\x2f\x6f\x74\x66";case"\x74\x74\x66" 
ReplacementFor__:return"\x66\x6f\x6e\x74\x2f\x74\x74\x66";case"\x77\x6f\x66\x66"
 ReplacementFor__:return"\x66\x6f\x6e\x74\x2f\x77\x6f\x66\x66";case
"\x77\x6f\x66\x66\x32"ReplacementFor__:return
"\x66\x6f\x6e\x74\x2f\x77\x6f\x66\x66\x32";case"\x37\x7a"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x37\x7a\x2d\x63\x6f\x6d\x70\x72\x65\x73\x73\x65\x64"
;case"\x61\x74\x6f\x6d"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x61\x74\x6f\x6d\x2b\x78\x6d\x6c"
;case"\x70\x64\x66"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x70\x64\x66";case"\x6a\x73" 
ReplacementFor__:case"\x6d\x6a\x73"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x61\x76\x61\x73\x63\x72\x69\x70\x74"
;case"\x6a\x73\x6f\x6e"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e";case
"\x72\x73\x73"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x72\x73\x73\x2b\x78\x6d\x6c";
case"\x74\x61\x72"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x74\x61\x72";case
"\x78\x68\x74"ReplacementFor__:case"\x78\x68\x74\x6d\x6c"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x68\x74\x6d\x6c\x2b\x78\x6d\x6c"
;case"\x78\x73\x6c\x74"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x73\x6c\x74\x2b\x78\x6d\x6c"
;case"\x78\x6d\x6c"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x6d\x6c";case"\x67\x7a" 
ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x67\x7a\x69\x70";case
"\x7a\x69\x70"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x7a\x69\x70";case
"\x77\x61\x73\x6d"ReplacementFor__:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x77\x61\x73\x6d";}}const char*
ReplacementFor_status_message(int status){switch(status){case(
(0x10c4+3173-0x1240)+(0x127b+7392-0x2447)-5529):return"\x43";case(
(0x2485+1304-0x26fa)+5578-(0x19e1+7953-0x20ea)):return"\x53\x20\x50";case(
(0xbc5+810-0x543)+(0x19ab+2208-0x1833)-(0x1383+7656-0x1e0d)):return"\x50";case(
(0x779+177-0x1bb)+(0x2220+2959-0x11b0)-8711):return"\x45\x20\x48";case(
(0x7c3+3745-0xfbc)+8445-9949):return"\x4f\x4b";case((0x20bb+6762-0x1fa2)+
(0x1b54+86-0x12de)-9094):return"\x43";case((0x10c0+4186-0x1cd5)+
(0x19e1+2681-0x138d)-(0x1b5b+770-0xa15)):return"\x41";case((0x1548+7767-0x23fd)+
6192-9991):return"\x4e\x41\x20\x49\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e";case
((0xd0a+4114-0x17bc)+(0x22e6+469-0x1607)-4936):return"\x4e\x20\x43";case(
(0x11da+3408-0xee1)+(0xdb0+224-0x469)-(0x2386+2728-0x148b)):return"\x52\x20\x43"
;case((0x26fa+4671-0x1940)+(0x18ff+3370-0x2477)-(0x2422+6827-0x1df0)):return
"\x50\x20\x43";case((0x1384+470-0x953)+(0x1e29+219-0xf1f)-(0x25cd+2445-0x143d)):
return"\x4d\x2d\x53";case((0x1cb0+246-0xc41)+(0x8f7+2716-0x1170)-
(0x1bd9+3537-0x16f2)):return"\x41\x20\x52";case((0x1993+6408-0x1e56)+
(0xad9+2871-0xb81)-(0x222d+609-0x69c)):return"\x49\x4d\x20\x55\x73\x65\x64";case
((0xe7f+2983-0x1187)+(0x23b8+8525-0x263f)-9785):return"\x4d\x20\x43";case(8052+
(0x6bc+1535-0x656)-9388):return"\x4d\x20\x50";case((0x1782+322-0x22c)+
(0x22ca+674-0x240b)-5835):return"\x46";case((0x2562+434-0x19b5)+
(0x1354+1279-0x13bf)-4292):return"\x53\x20\x4f";case((0x1694+1480-0x115f)+
(0x221b+3609-0x25a5)-(0x21aa+5906-0x2460)):return"\x4e\x20\x4d";case(
(0x1dcc+4460-0x24b7)+(0x1b32+6939-0x2051)-(0x227c+8376-0x23e8)):return
"\x55\x20\x50";case(5865+(0x10fc+1723-0x1700)-(0x1a3a+6863-0x1e9b)):return"\x75"
;case((0x1b79+3266-0x2106)+7426-8964):return"\x54\x20\x52";case(
(0x21aa+916-0x2195)+8069-(0x2426+7069-0x1dc9)):return"\x50\x20\x52";case(
(0x1e21+4962-0x1a2c)+(0x1590+291-0x168c)-(0x1a33+8181-0x243a)):return
"\x42\x20\x52";case((0x94a+8066-0x2393)+(0xcd7+6401-0x21d0)-(0xac6+5274-0x17b0))
:return"\x55";case((0x1ff7+1865-0x1f28)+(0x1db6+86-0x187a)-(0x1ab5+4385-0x1fbe))
:return"\x50\x20\x52";case((0x2242+4802-0x1550)+(0x11a8+4029-0x1c20)-9062):
return"\x46";case((0x10c5+3442-0x1812)+(0x1d8f+3341-0x207f)-(0x1787+1252-0xdbd))
:return"\x4e\x20\x46";case((0x679+1695-0x8a3)+(0x21d4+2468-0x23db)-
(0x19eb+6043-0x2709)):return"\x4d\x20\x4e\x20\x41";case((0xfb5+2940-0x10c4)+
(0x201c+888-0x17fe)-5229):return"\x4e\x20\x41";case((0x721+5066-0x1436)+
(0xed5+2059-0x8bf)-(0x1be1+3949-0x180f)):return"\x50\x20\x41\x20\x52";case(
(0x1d9a+2087-0x1af9)+(0x1028+8198-0x210d)-6225):return"\x52\x20\x54\x20\x4f";
case((0x1653+2310-0x1870)+(0x1915+698-0x1117)-(0x1178+1860-0x8b4)):return"\x43";
case(6193+(0x24a5+1779-0x2180)-8367):return"\x47";case((0x1ad9+1280-0x1b99)+
(0x2517+2092-0x9b1)-9783):return"\x4c\x20\x52";case((0x7d4+6557-0x1d2c)+8685-
(0x255f+2828-0xbd5)):return"\x50\x20\x46";case((0xfc4+7547-0x246f)+
(0x14a5+3632-0x123d)-6091):return"\x50\x20\x54\x6f\x6f\x20\x4c";case(
(0x179b+5992-0x2298)+6230-(0x25ac+2216-0xb31)):return
"\x55\x52\x49\x20\x54\x6f\x6f\x20\x4c";case((0x227c+2776-0x2551)+
(0x132a+794-0x77c)-(0x1eca+6291-0x2231)):return"\x55\x20\x4d\x20\x54";case(
(0xe75+604-0x614)+(0x1a73+6497-0x20b1)-(0x1c88+5710-0x1696)):return
"\x52\x20\x4e\x20\x53";case((0x178d+4851-0x1f24)+4765-(0x1d5b+7342-0x1db1)):
return"\x45\x20\x46";case(7804+(0x1a9c+3028-0x2303)-8263):return
"\x49\x27\x6d\x20\x61\x20\x74";case((0x2387+3303-0x224c)+(0x1bc5+1086-0x12a6)-
6618):return"\x4d\x20\x52";case((0x2106+2478-0x19a5)+(0x1320+114-0x609)-7410):
return"\x55\x20\x45";case((0xfa7+2747-0x14bb)+(0x12b1+3634-0x1c9d)-
(0x14f1+3072-0x18ab)):return"\x4c";case((0x2542+2799-0x1686)+(0xd8f+3181-0x13a8)
-7767):return"\x46\x20\x44";case((0x1059+3201-0xdba)+6418-9865):return
"\x54\x6f\x6f\x20\x45";case((0x20b7+5818-0x1f1c)+(0xb55+5416-0x1ebf)-
(0x203f+3787-0x16a1)):return"\x55\x20\x52";case((0x5c9+2897-0xf04)+
(0x1e80+2644-0xe27)-(0x1f2a+6471-0x1d5a)):return"\x50\x20\x52";case(4261+
(0x9cb+4555-0x131e)-(0x238b+4519-0x1dc2)):return"\x54\x6f\x6f\x20\x4d\x20\x52";
case((0x16cd+1384-0x19cb)+(0x1c94+4543-0x210d)-3585):return
"\x52\x20\x48\x20\x46\x20\x54\x6f\x6f\x20\x4c";case((0x723+6173-0x1997)+
(0x1b8b+733-0x67c)-(0x2328+2700-0x11e2)):return
"\x55\x20\x46\x6f\x72\x20\x4c\x20\x52";case((0x2609+4782-0x1bfd)+
(0x2158+1189-0x256e)-(0x219a+1530-0xc40)):return"\x4e\x6f\x74\x20\x49";case(
(0x1bd1+1434-0x1dd3)+(0xdbf+6187-0x1d50)-2620):return"\x42\x20\x47";case(
(0xad2+1352-0xde1)+9474-9540):return"\x53\x20\x55";case((0x1298+8363-0x23bb)+
(0x1273+3991-0x130f)-7307):return"\x47\x20\x54";case((0x1596+6370-0x2616)+
(0xb63+447-0xb46)-(0x22db+1091-0x1ed9)):return
"\x48\x20\x56\x20\x4e\x6f\x74\x20\x53";case((0xeaf+6252-0x1c32)+
(0x128b+653-0x6fa)-5901):return"\x56\x20\x41\x20\x4e";case((0x17c1+599-0x1482)+
7630-8553):return"\x49\x20\x53";case((0x1503+6788-0x26e2)+(0x15ab+3350-0xf2c)-
6718):return"\x4c\x20\x44";case((0x2599+1011-0x2385)+(0x15c3+8132-0x2417)-
(0x2332+3161-0x1a12)):return"\x4e\x20\x45";case(4323+(0x1051+7520-0x1ff2)-
(0x237d+5202-0x1b2c)):return"\x4e\x20\x41\x20\x52";default:case(
(0x163b+2615-0x17f2)+(0x136f+7521-0x1f53)-(0x1fc4+2232-0x1073)):return
"\x49\x20\x53\x20\x45\x72\x72\x6f\x72";}}bool 
ReplacementFor_can_compress_content_type(const std::string&
ReplacementFor_content_type){return(!ReplacementFor_content_type.find(
"\x74\x65\x78\x74\x2f")&&ReplacementFor_content_type!=
"\x74\x65\x78\x74\x2f\x65\x76\x65\x6e\x74\x2d\x73\x74\x72\x65\x61\x6d")||
ReplacementFor_content_type==
"\x69\x6d\x61\x67\x65\x2f\x73\x76\x67\x2b\x78\x6d\x6c"||
ReplacementFor_content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x61\x76\x61\x73\x63\x72\x69\x70\x74"
||ReplacementFor_content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"||
ReplacementFor_content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x6d\x6c"||
ReplacementFor_content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x68\x74\x6d\x6c\x2b\x78\x6d\x6c"
;}enum class ReplacementFor_EncodingType{None=((0x1003+8084-0x24ae)+
(0x1191+5415-0x22fc)-(0x20b6+4360-0x2319)),ReplacementFor_Gzip,
ReplacementFor_Brotli};ReplacementFor_EncodingType ReplacementFor_encoding_type(
const ReplacementFor_Request&ReplacementFor_req,const ReplacementFor_Response&
ReplacementFor_res){auto ReplacementFor_ret=ReplacementFor_detail::
ReplacementFor_can_compress_content_type(ReplacementFor_res.
ReplacementFor_get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65"));if(!ReplacementFor_ret){
return ReplacementFor_EncodingType::None;}const auto&s=ReplacementFor_req.
ReplacementFor_get_header_value(
"\x41\x63\x63\x65\x70\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67");(void)(s);
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
ReplacementFor_ret=s.find("\x62\x72")!=std::string::npos;if(ReplacementFor_ret){
return ReplacementFor_EncodingType::ReplacementFor_Brotli;}
#endif
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
ReplacementFor_ret=s.find("\x67\x7a\x69\x70")!=std::string::npos;if(
ReplacementFor_ret){return ReplacementFor_EncodingType::ReplacementFor_Gzip;}
#endif
return ReplacementFor_EncodingType::None;}class ReplacementFor_compressor{public
:virtual~ReplacementFor_compressor(){};typedef std::function<bool(const char*
data,size_t ReplacementFor_data_len)>ReplacementFor_Callback;virtual bool 
compress(const char*data,size_t ReplacementFor_data_length,bool 
ReplacementFor_last,ReplacementFor_Callback ReplacementFor_callback)=0;};class 
ReplacementFor_decompressor{public:virtual~ReplacementFor_decompressor(){}
virtual bool ReplacementFor_is_valid()const=0;typedef std::function<bool(const 
char*data,size_t ReplacementFor_data_len)>ReplacementFor_Callback;virtual bool 
ReplacementFor_decompress(const char*data,size_t ReplacementFor_data_length,
ReplacementFor_Callback ReplacementFor_callback)=0;};class 
ReplacementFor_nocompressor:public ReplacementFor_compressor{public:~
ReplacementFor_nocompressor(){};bool compress(const char*data,size_t 
ReplacementFor_data_length,bool,ReplacementFor_Callback ReplacementFor_callback)
override{if(!ReplacementFor_data_length){return true;}return 
ReplacementFor_callback(data,ReplacementFor_data_length);}};
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
class ReplacementFor_gzip_compressor:public ReplacementFor_compressor{public:
ReplacementFor_gzip_compressor(){std::memset(&ReplacementFor_strm_,(
(0x2166+5485-0x1f9e)+(0x6f9+3625-0x1232)-(0x1a4f+7653-0x1e0f)),sizeof(
ReplacementFor_strm_));ReplacementFor_strm_.zalloc=ReplacementFor_Z_NULL;
ReplacementFor_strm_.zfree=ReplacementFor_Z_NULL;ReplacementFor_strm_.opaque=
ReplacementFor_Z_NULL;ReplacementFor_is_valid_=ReplacementFor_deflateInit2(&
ReplacementFor_strm_,ReplacementFor_Z_DEFAULT_COMPRESSION,
ReplacementFor_Z_DEFLATED,((0x1915+3741-0x1e5b)+(0x1305+6430-0x1f89)-
(0x1fea+2749-0x14d5)),((0x231b+3953-0x18a8)+(0x7fd+6382-0x1977)-
(0x22c2+6614-0x1b48)),ReplacementFor_Z_DEFAULT_STRATEGY)==ReplacementFor_Z_OK;}~
ReplacementFor_gzip_compressor(){deflateEnd(&ReplacementFor_strm_);}bool 
compress(const char*data,size_t ReplacementFor_data_length,bool 
ReplacementFor_last,ReplacementFor_Callback ReplacementFor_callback)override{
assert(ReplacementFor_is_valid_);auto flush=ReplacementFor_last?
ReplacementFor_Z_FINISH:ReplacementFor_Z_NO_FLUSH;ReplacementFor_strm_.avail_in=
static_cast<decltype(ReplacementFor_strm_.avail_in)>(ReplacementFor_data_length)
;ReplacementFor_strm_.next_in=const_cast<Bytef*>(reinterpret_cast<const Bytef*>(
data));int ReplacementFor_ret=ReplacementFor_Z_OK;std::array<char,
ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ>ReplacementFor_buff{};do{
ReplacementFor_strm_.avail_out=ReplacementFor_buff.size();ReplacementFor_strm_.
next_out=reinterpret_cast<Bytef*>(ReplacementFor_buff.data());ReplacementFor_ret
=deflate(&ReplacementFor_strm_,flush);if(ReplacementFor_ret==
ReplacementFor_Z_STREAM_ERROR){return false;}if(!ReplacementFor_callback(
ReplacementFor_buff.data(),ReplacementFor_buff.size()-ReplacementFor_strm_.
avail_out)){return false;}}while(ReplacementFor_strm_.avail_out==(
(0x1868+885-0xca3)+(0x1488+1769-0x150f)-(0x1f14+5332-0x1e4c)));assert((
ReplacementFor_last&&ReplacementFor_ret==ReplacementFor_Z_STREAM_END)||(!
ReplacementFor_last&&ReplacementFor_ret==ReplacementFor_Z_OK));assert(
ReplacementFor_strm_.avail_in==((0x240b+762-0x1314)+(0x178b+5816-0x2558)-
(0x1df9+4541-0x12da)));return true;}private:bool ReplacementFor_is_valid_=false;
z_stream ReplacementFor_strm_;};class ReplacementFor_gzip_decompressor:public 
ReplacementFor_decompressor{public:ReplacementFor_gzip_decompressor(){std::
memset(&ReplacementFor_strm_,((0x10d6+5118-0x238e)+(0xee1+1902-0xa6f)-
(0x1b9a+3675-0x1ccf)),sizeof(ReplacementFor_strm_));ReplacementFor_strm_.zalloc=
ReplacementFor_Z_NULL;ReplacementFor_strm_.zfree=ReplacementFor_Z_NULL;
ReplacementFor_strm_.opaque=ReplacementFor_Z_NULL;ReplacementFor_is_valid_=
ReplacementFor_inflateInit2(&ReplacementFor_strm_,((0x1018+25-0xd55)+
(0x1d27+844-0x1a21)-(0x1b31+3122-0x1e55))+((0x2423+1020-0x1707)+
(0x2373+3312-0x254a)-(0x25a6+2482-0x1336)))==ReplacementFor_Z_OK;}~
ReplacementFor_gzip_decompressor(){inflateEnd(&ReplacementFor_strm_);}bool 
ReplacementFor_is_valid()const override{return ReplacementFor_is_valid_;}bool 
ReplacementFor_decompress(const char*data,size_t ReplacementFor_data_length,
ReplacementFor_Callback ReplacementFor_callback)override{assert(
ReplacementFor_is_valid_);int ReplacementFor_ret=ReplacementFor_Z_OK;
ReplacementFor_strm_.avail_in=static_cast<decltype(ReplacementFor_strm_.avail_in
)>(ReplacementFor_data_length);ReplacementFor_strm_.next_in=const_cast<Bytef*>(
reinterpret_cast<const Bytef*>(data));std::array<char,
ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ>ReplacementFor_buff{};while(
ReplacementFor_strm_.avail_in>(5705+(0x137c+4290-0x1c23)-7780)){
ReplacementFor_strm_.avail_out=ReplacementFor_buff.size();ReplacementFor_strm_.
next_out=reinterpret_cast<Bytef*>(ReplacementFor_buff.data());ReplacementFor_ret
=inflate(&ReplacementFor_strm_,ReplacementFor_Z_NO_FLUSH);assert(
ReplacementFor_ret!=ReplacementFor_Z_STREAM_ERROR);switch(ReplacementFor_ret){
case ReplacementFor_Z_NEED_DICT:case ReplacementFor_Z_DATA_ERROR:case 
ReplacementFor_Z_MEM_ERROR:inflateEnd(&ReplacementFor_strm_);return false;}if(!
ReplacementFor_callback(ReplacementFor_buff.data(),ReplacementFor_buff.size()-
ReplacementFor_strm_.avail_out)){return false;}}return ReplacementFor_ret==
ReplacementFor_Z_OK||ReplacementFor_ret==ReplacementFor_Z_STREAM_END;}private:
bool ReplacementFor_is_valid_=false;z_stream ReplacementFor_strm_;};
#endif
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
class ReplacementFor_brotli_compressor:public ReplacementFor_compressor{public:
ReplacementFor_brotli_compressor(){ReplacementFor_state_=
ReplacementFor_BrotliEncoderCreateInstance(nullptr,nullptr,nullptr);}~
ReplacementFor_brotli_compressor(){ReplacementFor_BrotliEncoderDestroyInstance(
ReplacementFor_state_);}bool compress(const char*data,size_t 
ReplacementFor_data_length,bool ReplacementFor_last,ReplacementFor_Callback 
ReplacementFor_callback)override{std::array<uint8_t,
ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ>ReplacementFor_buff{};auto 
ReplacementFor_operation=ReplacementFor_last?
ReplacementFor_BROTLI_OPERATION_FINISH:ReplacementFor_BROTLI_OPERATION_PROCESS;
auto ReplacementFor_available_in=ReplacementFor_data_length;auto next_in=
reinterpret_cast<const uint8_t*>(data);for(;;){if(ReplacementFor_last){if(
ReplacementFor_BrotliEncoderIsFinished(ReplacementFor_state_)){break;}}else{if(!
ReplacementFor_available_in){break;}}auto ReplacementFor_available_out=
ReplacementFor_buff.size();auto next_out=ReplacementFor_buff.data();if(!
ReplacementFor_BrotliEncoderCompressStream(ReplacementFor_state_,
ReplacementFor_operation,&ReplacementFor_available_in,&next_in,&
ReplacementFor_available_out,&next_out,nullptr)){return false;}auto 
ReplacementFor_output_bytes=ReplacementFor_buff.size()-
ReplacementFor_available_out;if(ReplacementFor_output_bytes){
ReplacementFor_callback(reinterpret_cast<const char*>(ReplacementFor_buff.data()
),ReplacementFor_output_bytes);}}return true;}private:
ReplacementFor_BrotliEncoderState*ReplacementFor_state_=nullptr;};class 
ReplacementFor_brotli_decompressor:public ReplacementFor_decompressor{public:
ReplacementFor_brotli_decompressor(){ReplacementFor_decoder_s=
ReplacementFor_BrotliDecoderCreateInstance(((0x11c4+2423-0x19d0)+6688-
(0x1f79+2175-0xc6d)),((0x4c6+2902-0xe11)+(0x1742+8283-0x2528)-5248),(
(0x8a2+5285-0x1775)+(0x1b49+3998-0x1668)-(0x1f95+8629-0x26f9)));
ReplacementFor_decoder_r=ReplacementFor_decoder_s?
ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT:
ReplacementFor_BROTLI_DECODER_RESULT_ERROR;}~ReplacementFor_brotli_decompressor(
){if(ReplacementFor_decoder_s){ReplacementFor_BrotliDecoderDestroyInstance(
ReplacementFor_decoder_s);}}bool ReplacementFor_is_valid()const override{return 
ReplacementFor_decoder_s;}bool ReplacementFor_decompress(const char*data,size_t 
ReplacementFor_data_length,ReplacementFor_Callback ReplacementFor_callback)
override{if(ReplacementFor_decoder_r==
ReplacementFor_BROTLI_DECODER_RESULT_SUCCESS||ReplacementFor_decoder_r==
ReplacementFor_BROTLI_DECODER_RESULT_ERROR){return((0x13c3+1824-0xd1e)+
(0x821+8429-0x26c9)-(0x1c7f+2497-0x1636));}const uint8_t*next_in=(const uint8_t*
)data;size_t avail_in=ReplacementFor_data_length;size_t total_out;
ReplacementFor_decoder_r=ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT;
std::array<char,ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ>ReplacementFor_buff
{};while(ReplacementFor_decoder_r==
ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT){char*next_out=
ReplacementFor_buff.data();size_t avail_out=ReplacementFor_buff.size();
ReplacementFor_decoder_r=ReplacementFor_BrotliDecoderDecompressStream(
ReplacementFor_decoder_s,&avail_in,&next_in,&avail_out,reinterpret_cast<uint8_t*
*>(&next_out),&total_out);if(ReplacementFor_decoder_r==
ReplacementFor_BROTLI_DECODER_RESULT_ERROR){return false;}if(!
ReplacementFor_callback(ReplacementFor_buff.data(),ReplacementFor_buff.size()-
avail_out)){return false;}}return ReplacementFor_decoder_r==
ReplacementFor_BROTLI_DECODER_RESULT_SUCCESS||ReplacementFor_decoder_r==
ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT;}private:
ReplacementFor_BrotliDecoderResult ReplacementFor_decoder_r;
ReplacementFor_BrotliDecoderState*ReplacementFor_decoder_s=nullptr;};
#endif
bool ReplacementFor_has_header(const ReplacementFor_Headers&
ReplacementFor_headers,const char*key){return ReplacementFor_headers.find(key)!=
ReplacementFor_headers.end();}const char*ReplacementFor_get_header_value(const 
ReplacementFor_Headers&ReplacementFor_headers,const char*key,size_t id=(
(0x16e0+949-0x182c)+(0x1e62+2687-0x1266)-(0x1fd3+3712-0x156f)),const char*
ReplacementFor_def=nullptr){auto ReplacementFor_rng=ReplacementFor_headers.
equal_range(key);auto ReplacementFor_it=ReplacementFor_rng.first;std::advance(
ReplacementFor_it,static_cast<ssize_t>(id));if(ReplacementFor_it!=
ReplacementFor_rng.second){return ReplacementFor_it->second.c_str();}return 
ReplacementFor_def;}template<typename T>T ReplacementFor_get_header_value(const 
ReplacementFor_Headers&,const char*,size_t=(6543+(0x1bcf+1236-0x1aa7)-
(0x21dd+7991-0x2189)),uint64_t=((0x26f4+550-0x19a5)+(0x1047+8195-0x21fd)-7618)){
}template<>uint64_t ReplacementFor_get_header_value<uint64_t>(const 
ReplacementFor_Headers&ReplacementFor_headers,const char*key,size_t id,uint64_t 
ReplacementFor_def){auto ReplacementFor_rng=ReplacementFor_headers.equal_range(
key);auto ReplacementFor_it=ReplacementFor_rng.first;std::advance(
ReplacementFor_it,static_cast<ssize_t>(id));if(ReplacementFor_it!=
ReplacementFor_rng.second){return std::strtoull(ReplacementFor_it->second.data()
,nullptr,((0x1104+1823-0x14b2)+6688-7559));}return ReplacementFor_def;}template<
typename T>bool ReplacementFor_parse_header(const char*beg,const char*end,T 
ReplacementFor_fn){while(beg<end&&ReplacementFor_is_space_or_tab(end[-(
(0x1bd3+895-0x912)+3387-9082)])){end--;}auto p=beg;while(p<end&&*p!=((char)(
(0x102c+6815-0x1d85)+5541-8881))){p++;}if(p==end){return false;}auto 
ReplacementFor_key_end=p;if(*p++!=((char)(7641+(0x197d+4653-0x236f)-9690))){
return false;}while(p<end&&ReplacementFor_is_space_or_tab(*p)){p++;}if(p<end){
ReplacementFor_fn(std::string(beg,ReplacementFor_key_end),
ReplacementFor_decode_url(std::string(p,end),false));return true;}return false;}
bool ReplacementFor_read_headers(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Headers&ReplacementFor_headers){const auto ReplacementFor_bufsiz=
((0x1951+3929-0x1c29)+(0x11a+7016-0x1c76)-(0x5c0+6205-0x1970));char buf[
ReplacementFor_bufsiz];ReplacementFor_stream_line_reader 
ReplacementFor_line_reader(ReplacementFor_strm,buf,ReplacementFor_bufsiz);for(;;
){if(!ReplacementFor_line_reader.getline()){return false;}if(
ReplacementFor_line_reader.ReplacementFor_end_with_crlf()){if(
ReplacementFor_line_reader.size()==((0x221d+2737-0x14e1)+(0x11a2+7017-0x1fc7)-
(0x260c+893-0x45a))){break;}}else{continue;}auto end=ReplacementFor_line_reader.
ReplacementFor_ptr()+ReplacementFor_line_reader.size()-((0x1eef+3784-0x17d1)+
(0x1348+433-0x3d1)-9996);ReplacementFor_parse_header(ReplacementFor_line_reader.
ReplacementFor_ptr(),end,[&](std::string&&key,std::string&&val){
ReplacementFor_headers.emplace(std::move(key),std::move(val));});}return true;}
bool ReplacementFor_read_content_with_length(ReplacementFor_Stream&
ReplacementFor_strm,uint64_t len,ReplacementFor_Progress ReplacementFor_progress
,ReplacementFor_ContentReceiverWithProgress out){char buf[
ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ];uint64_t ReplacementFor_r=(5555+
(0xac1+3888-0x1560)-6724);while(ReplacementFor_r<len){auto 
ReplacementFor_read_len=static_cast<size_t>(len-ReplacementFor_r);auto n=
ReplacementFor_strm.read(buf,(std::min)(ReplacementFor_read_len,
ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ));if(n<=((0x1e06+2204-0x2243)+
(0x1d57+3715-0x1791)-(0x1bbc+4395-0x143f))){return false;}if(!out(buf,
static_cast<size_t>(n),ReplacementFor_r,len)){return false;}ReplacementFor_r+=
static_cast<uint64_t>(n);if(ReplacementFor_progress){if(!ReplacementFor_progress
(ReplacementFor_r,len)){return false;}}}return true;}void 
ReplacementFor_skip_content_with_length(ReplacementFor_Stream&
ReplacementFor_strm,uint64_t len){char buf[ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ
];uint64_t ReplacementFor_r=(4346+(0x1a08+4767-0x1db5)-(0x2292+8245-0x22db));
while(ReplacementFor_r<len){auto ReplacementFor_read_len=static_cast<size_t>(len
-ReplacementFor_r);auto n=ReplacementFor_strm.read(buf,(std::min)(
ReplacementFor_read_len,ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ));if(n<=(
(0x1465+1967-0x15c0)+(0x1b34+3703-0x1afb)-(0x1b4c+3761-0x14f9))){return;}
ReplacementFor_r+=static_cast<uint64_t>(n);}}bool 
ReplacementFor_read_content_without_length(ReplacementFor_Stream&
ReplacementFor_strm,ReplacementFor_ContentReceiverWithProgress out){char buf[
ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ];uint64_t ReplacementFor_r=(
(0x872+4471-0x1952)+(0x2497+4641-0x198b)-7620);for(;;){auto n=
ReplacementFor_strm.read(buf,ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ);if(n<(
(0x268f+157-0x1cdd)+(0x1003+1344-0xbd2)-(0x222b+2101-0x16a0))){return false;}
else if(n==(6929+(0x111c+763-0x10b2)-7798)){return true;}if(!out(buf,static_cast
<size_t>(n),ReplacementFor_r,((0x72f+4186-0x14b1)+(0x1d7f+5675-0x2558)-
(0x2432+1202-0x17ba)))){return false;}ReplacementFor_r+=static_cast<uint64_t>(n)
;}return true;}bool ReplacementFor_read_content_chunked(ReplacementFor_Stream&
ReplacementFor_strm,ReplacementFor_ContentReceiverWithProgress out){const auto 
ReplacementFor_bufsiz=(4967+(0x1624+3624-0x1b8f)-7188);char buf[
ReplacementFor_bufsiz];ReplacementFor_stream_line_reader 
ReplacementFor_line_reader(ReplacementFor_strm,buf,ReplacementFor_bufsiz);if(!
ReplacementFor_line_reader.getline()){return false;}unsigned long 
ReplacementFor_chunk_len;while(true){char*end_ptr;ReplacementFor_chunk_len=std::
strtoul(ReplacementFor_line_reader.ReplacementFor_ptr(),&end_ptr,(
(0x1177+2870-0x174e)+6855-8214));if(end_ptr==ReplacementFor_line_reader.
ReplacementFor_ptr()){return false;}if(ReplacementFor_chunk_len==ULONG_MAX){
return false;}if(ReplacementFor_chunk_len==((0x1a70+1471-0x1a48)+
(0x12cf+4773-0x146d)-5870)){break;}if(!ReplacementFor_read_content_with_length(
ReplacementFor_strm,ReplacementFor_chunk_len,nullptr,out)){return false;}if(!
ReplacementFor_line_reader.getline()){return false;}if(strcmp(
ReplacementFor_line_reader.ReplacementFor_ptr(),"\r\n")){break;}if(!
ReplacementFor_line_reader.getline()){return false;}}if(ReplacementFor_chunk_len
==((0x15e5+1375-0xe78)+5690-8966)){if(!ReplacementFor_line_reader.getline()||
strcmp(ReplacementFor_line_reader.ReplacementFor_ptr(),"\r\n"))return false;}
return true;}bool ReplacementFor_is_chunked_transfer_encoding(const 
ReplacementFor_Headers&ReplacementFor_headers){return!strcasecmp(
ReplacementFor_get_header_value(ReplacementFor_headers,
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",(8618+
(0x542+5483-0x15f9)-9822),""),"\x63\x68\x75\x6e\x6b\x65\x64");}template<typename
 T,typename U>bool ReplacementFor_prepare_content_receiver(T&x,int&status,
ReplacementFor_ContentReceiverWithProgress ReplacementFor_receiver,bool 
ReplacementFor_decompress,U ReplacementFor_callback){if(
ReplacementFor_decompress){std::string encoding=x.
ReplacementFor_get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67");std::
unique_ptr<ReplacementFor_decompressor>ReplacementFor_decompressor;if(encoding.
find("\x67\x7a\x69\x70")!=std::string::npos||encoding.find(
"\x64\x65\x66\x6c\x61\x74\x65")!=std::string::npos){
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
ReplacementFor_decompressor=ReplacementFor_detail::make_unique<
ReplacementFor_gzip_decompressor>();
#else
status=((0x1ef6+5366-0x2519)+6230-9610);return false;
#endif
}else if(encoding.find("\x62\x72")!=std::string::npos){
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
ReplacementFor_decompressor=ReplacementFor_detail::make_unique<
ReplacementFor_brotli_decompressor>();
#else
status=(7860+(0xf88+7532-0x2315)-9972);return false;
#endif
}if(ReplacementFor_decompressor){if(ReplacementFor_decompressor->
ReplacementFor_is_valid()){ReplacementFor_ContentReceiverWithProgress out=[&](
const char*buf,size_t n,uint64_t ReplacementFor_off,uint64_t len){return 
ReplacementFor_decompressor->ReplacementFor_decompress(buf,n,[&](const char*buf,
size_t n){return ReplacementFor_receiver(buf,n,ReplacementFor_off,len);});};
return ReplacementFor_callback(std::move(out));}else{status=((0x1ac8+478-0xf60)+
(0x1bb0+3932-0x1a43)-7195);return false;}}}
ReplacementFor_ContentReceiverWithProgress out=[&](const char*buf,size_t n,
uint64_t ReplacementFor_off,uint64_t len){return ReplacementFor_receiver(buf,n,
ReplacementFor_off,len);};return ReplacementFor_callback(std::move(out));}
template<typename T>bool ReplacementFor_read_content(ReplacementFor_Stream&
ReplacementFor_strm,T&x,size_t ReplacementFor_payload_max_length,int&status,
ReplacementFor_Progress ReplacementFor_progress,
ReplacementFor_ContentReceiverWithProgress ReplacementFor_receiver,bool 
ReplacementFor_decompress){return ReplacementFor_prepare_content_receiver(x,
status,std::move(ReplacementFor_receiver),ReplacementFor_decompress,[&](const 
ReplacementFor_ContentReceiverWithProgress&out){auto ReplacementFor_ret=true;
auto ReplacementFor_exceed_payload_max_length=false;if(
ReplacementFor_is_chunked_transfer_encoding(x.ReplacementFor_headers)){
ReplacementFor_ret=ReplacementFor_read_content_chunked(ReplacementFor_strm,out);
}else if(!ReplacementFor_has_header(x.ReplacementFor_headers,
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){ReplacementFor_ret=
ReplacementFor_read_content_without_length(ReplacementFor_strm,out);}else{auto 
len=ReplacementFor_get_header_value<uint64_t>(x.ReplacementFor_headers,
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68");if(len>
ReplacementFor_payload_max_length){ReplacementFor_exceed_payload_max_length=true
;ReplacementFor_skip_content_with_length(ReplacementFor_strm,len);
ReplacementFor_ret=false;}else if(len>((0x642+5191-0x14f7)+(0x2d7+7313-0x1ee7)-
(0x790+5488-0x16ed))){ReplacementFor_ret=ReplacementFor_read_content_with_length
(ReplacementFor_strm,len,std::move(ReplacementFor_progress),out);}}if(!
ReplacementFor_ret){status=ReplacementFor_exceed_payload_max_length?(9065+
(0x4f0+1947-0x7cf)-9864):((0xdf4+6680-0x25a9)+5872-(0x18e1+8951-0x2415));}return
 ReplacementFor_ret;});}ssize_t ReplacementFor_write_headers(
ReplacementFor_Stream&ReplacementFor_strm,const ReplacementFor_Headers&
ReplacementFor_headers){ssize_t ReplacementFor_write_len=(8016+
(0x1d59+886-0x1d69)-8886);for(const auto&x:ReplacementFor_headers){auto len=
ReplacementFor_strm.ReplacementFor_write_format("\x25\x73\x3a\x20\x25\x73""\r\n"
,x.first.c_str(),x.second.c_str());if(len<((0xcd1+4907-0x1777)+
(0x1d05+923-0xf60)-(0x1f7c+670-0x855))){return len;}ReplacementFor_write_len+=
len;}auto len=ReplacementFor_strm.write("\r\n");if(len<((0x1413+6185-0x23bf)+
6578-8751)){return len;}ReplacementFor_write_len+=len;return 
ReplacementFor_write_len;}bool ReplacementFor_write_data(ReplacementFor_Stream&
ReplacementFor_strm,const char*ReplacementFor_d,size_t ReplacementFor_l){size_t 
offset=((0x1862+4003-0x25a2)+3975-(0x1d66+1094-0xfc2));while(offset<
ReplacementFor_l){auto length=ReplacementFor_strm.write(ReplacementFor_d+offset,
ReplacementFor_l-offset);if(length<((0x23b0+4397-0x1710)+(0x1c7a+2503-0x2157)-
8887)){return false;}offset+=static_cast<size_t>(length);}return true;}template<
typename T>bool ReplacementFor_write_content(ReplacementFor_Stream&
ReplacementFor_strm,const ReplacementFor_ContentProvider&
ReplacementFor_content_provider,size_t offset,size_t length,T 
ReplacementFor_is_shutting_down,Error&error){size_t ReplacementFor_end_offset=
offset+length;auto ok=true;ReplacementFor_DataSink ReplacementFor_data_sink;
ReplacementFor_data_sink.write=[&](const char*ReplacementFor_d,size_t 
ReplacementFor_l){if(ok){if(ReplacementFor_write_data(ReplacementFor_strm,
ReplacementFor_d,ReplacementFor_l)){offset+=ReplacementFor_l;}else{ok=false;}}};
ReplacementFor_data_sink.ReplacementFor_is_writable=[&](void){return ok&&
ReplacementFor_strm.ReplacementFor_is_writable();};while(offset<
ReplacementFor_end_offset&&!ReplacementFor_is_shutting_down()){if(!
ReplacementFor_content_provider(offset,ReplacementFor_end_offset-offset,
ReplacementFor_data_sink)){error=Error::ReplacementFor_Canceled;return false;}if
(!ok){error=Error::Write;return false;}}error=Error::ReplacementFor_Success;
return true;}template<typename T>bool ReplacementFor_write_content(
ReplacementFor_Stream&ReplacementFor_strm,const ReplacementFor_ContentProvider&
ReplacementFor_content_provider,size_t offset,size_t length,const T&
ReplacementFor_is_shutting_down){auto error=Error::ReplacementFor_Success;return
 ReplacementFor_write_content(ReplacementFor_strm,
ReplacementFor_content_provider,offset,length,ReplacementFor_is_shutting_down,
error);}template<typename T>bool ReplacementFor_write_content_without_length(
ReplacementFor_Stream&ReplacementFor_strm,const ReplacementFor_ContentProvider&
ReplacementFor_content_provider,const T&ReplacementFor_is_shutting_down){size_t 
offset=((0x68b+8485-0x25ce)+7158-(0x2438+2980-0x1204));auto 
ReplacementFor_data_available=true;auto ok=true;ReplacementFor_DataSink 
ReplacementFor_data_sink;ReplacementFor_data_sink.write=[&](const char*
ReplacementFor_d,size_t ReplacementFor_l){if(ok){offset+=ReplacementFor_l;if(!
ReplacementFor_write_data(ReplacementFor_strm,ReplacementFor_d,ReplacementFor_l)
){ok=false;}}};ReplacementFor_data_sink.done=[&](void){
ReplacementFor_data_available=false;};ReplacementFor_data_sink.
ReplacementFor_is_writable=[&](void){return ok&&ReplacementFor_strm.
ReplacementFor_is_writable();};while(ReplacementFor_data_available&&!
ReplacementFor_is_shutting_down()){if(!ReplacementFor_content_provider(offset,(
(0x173f+7180-0x1edb)+(0x1b34+6276-0x25cb)-8797),ReplacementFor_data_sink)){
return false;}if(!ok){return false;}}return true;}template<typename T,typename U
>bool ReplacementFor_write_content_chunked(ReplacementFor_Stream&
ReplacementFor_strm,const ReplacementFor_ContentProvider&
ReplacementFor_content_provider,const T&ReplacementFor_is_shutting_down,U&
ReplacementFor_compressor,Error&error){size_t offset=((0x1801+7573-0x22cd)+
(0x1a94+970-0x1a47)-(0x18d7+3426-0xf59));auto ReplacementFor_data_available=true
;auto ok=true;ReplacementFor_DataSink ReplacementFor_data_sink;
ReplacementFor_data_sink.write=[&](const char*ReplacementFor_d,size_t 
ReplacementFor_l){if(!ok){return;}ReplacementFor_data_available=ReplacementFor_l
>((0xac3+4256-0x1811)+6688-(0x1f27+101-0x21a));offset+=ReplacementFor_l;std::
string ReplacementFor_payload;if(!ReplacementFor_compressor.compress(
ReplacementFor_d,ReplacementFor_l,false,[&](const char*data,size_t 
ReplacementFor_data_len){ReplacementFor_payload.append(data,
ReplacementFor_data_len);return true;})){ok=false;return;}if(!
ReplacementFor_payload.empty()){auto ReplacementFor_chunk=
ReplacementFor_from_i_to_hex(ReplacementFor_payload.size())+"\r\n"+
ReplacementFor_payload+"\r\n";if(!ReplacementFor_write_data(ReplacementFor_strm,
ReplacementFor_chunk.data(),ReplacementFor_chunk.size())){ok=false;return;}}};
ReplacementFor_data_sink.done=[&](void){if(!ok){return;}
ReplacementFor_data_available=false;std::string ReplacementFor_payload;if(!
ReplacementFor_compressor.compress(nullptr,((0x1972+975-0x15a5)+
(0x2681+41-0xbc2)-(0x23dc+8070-0x20de)),true,[&](const char*data,size_t 
ReplacementFor_data_len){ReplacementFor_payload.append(data,
ReplacementFor_data_len);return true;})){ok=false;return;}if(!
ReplacementFor_payload.empty()){auto ReplacementFor_chunk=
ReplacementFor_from_i_to_hex(ReplacementFor_payload.size())+"\r\n"+
ReplacementFor_payload+"\r\n";if(!ReplacementFor_write_data(ReplacementFor_strm,
ReplacementFor_chunk.data(),ReplacementFor_chunk.size())){ok=false;return;}}
static const std::string ReplacementFor_done_marker("\x30""\r\n\r\n");if(!
ReplacementFor_write_data(ReplacementFor_strm,ReplacementFor_done_marker.data(),
ReplacementFor_done_marker.size())){ok=false;}};ReplacementFor_data_sink.
ReplacementFor_is_writable=[&](void){return ok&&ReplacementFor_strm.
ReplacementFor_is_writable();};while(ReplacementFor_data_available&&!
ReplacementFor_is_shutting_down()){if(!ReplacementFor_content_provider(offset,(
9425+(0x5c0+2434-0xe92)-9601),ReplacementFor_data_sink)){error=Error::
ReplacementFor_Canceled;return false;}if(!ok){error=Error::Write;return false;}}
error=Error::ReplacementFor_Success;return true;}template<typename T,typename U>
bool ReplacementFor_write_content_chunked(ReplacementFor_Stream&
ReplacementFor_strm,const ReplacementFor_ContentProvider&
ReplacementFor_content_provider,const T&ReplacementFor_is_shutting_down,U&
ReplacementFor_compressor){auto error=Error::ReplacementFor_Success;return 
ReplacementFor_write_content_chunked(ReplacementFor_strm,
ReplacementFor_content_provider,ReplacementFor_is_shutting_down,
ReplacementFor_compressor,error);}template<typename T>bool 
ReplacementFor_redirect(T&ReplacementFor_cli,ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res,const std::string&
ReplacementFor_path,const std::string&ReplacementFor_location,Error&error){
ReplacementFor_Request ReplacementFor_new_req=ReplacementFor_req;
ReplacementFor_new_req.ReplacementFor_path=ReplacementFor_path;
ReplacementFor_new_req.ReplacementFor_redirect_count_-=((0xf95+3446-0x15cc)+
(0x20c0+6426-0x2396)-(0x1e72+6899-0x1be3));if(ReplacementFor_res.status==(
(0x38f+7984-0x216c)+(0x16ba+3583-0x232d)-(0x1511+3766-0x2217))&&(
ReplacementFor_req.ReplacementFor_method!="\x47\x45\x54"&&ReplacementFor_req.
ReplacementFor_method!="\x48\x45\x41\x44")){ReplacementFor_new_req.
ReplacementFor_method="\x47\x45\x54";ReplacementFor_new_req.ReplacementFor_body.
clear();ReplacementFor_new_req.ReplacementFor_headers.clear();}
ReplacementFor_Response ReplacementFor_new_res;auto ReplacementFor_ret=
ReplacementFor_cli.send(ReplacementFor_new_req,ReplacementFor_new_res,error);if(
ReplacementFor_ret){ReplacementFor_req=ReplacementFor_new_req;ReplacementFor_res
=ReplacementFor_new_res;ReplacementFor_res.ReplacementFor_location=
ReplacementFor_location;}return ReplacementFor_ret;}std::string 
ReplacementFor_params_to_query_str(const ReplacementFor_Params&
ReplacementFor_params){std::string ReplacementFor_query;for(auto 
ReplacementFor_it=ReplacementFor_params.begin();ReplacementFor_it!=
ReplacementFor_params.end();++ReplacementFor_it){if(ReplacementFor_it!=
ReplacementFor_params.begin()){ReplacementFor_query+="\x26";}
ReplacementFor_query+=ReplacementFor_it->first;ReplacementFor_query+="\x3d";
ReplacementFor_query+=ReplacementFor_encode_query_param(ReplacementFor_it->
second);}return ReplacementFor_query;}std::string 
ReplacementFor_append_query_params(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params){std::string 
ReplacementFor_path_with_query=ReplacementFor_path;const static std::regex 
ReplacementFor_re("\x5b\x5e\x3f\x5d\x2b""\\""\x3f\x2e\x2a");auto 
ReplacementFor_delm=std::regex_match(ReplacementFor_path,ReplacementFor_re)?((
char)((0x1169+7101-0x2355)+(0x13d9+494-0x42c)-(0x1cb8+4927-0x14b1))):((char)(
(0xa77+5497-0x1b1c)+(0x1102+1565-0x13cc)-(0x11f2+3349-0x171f)));
ReplacementFor_path_with_query+=ReplacementFor_delm+
ReplacementFor_params_to_query_str(ReplacementFor_params);return 
ReplacementFor_path_with_query;}void ReplacementFor_parse_query_text(const std::
string&s,ReplacementFor_Params&ReplacementFor_params){ReplacementFor_split(s.
data(),s.data()+s.size(),((char)(5745+(0x13a2+5044-0x255d)-(0x2081+6833-0x22ee))
),[&](const char*b,const char*ReplacementFor_e){std::string key;std::string val;
ReplacementFor_split(b,ReplacementFor_e,((char)((0x226d+117-0x15b9)+5892-9200)),
[&](const char*ReplacementFor_b2,const char*ReplacementFor_e2){if(key.empty()){
key.assign(ReplacementFor_b2,ReplacementFor_e2);}else{val.assign(
ReplacementFor_b2,ReplacementFor_e2);}});if(!key.empty()){ReplacementFor_params.
emplace(ReplacementFor_decode_url(key,true),ReplacementFor_decode_url(val,true))
;}});}bool ReplacementFor_parse_multipart_boundary(const std::string&
ReplacementFor_content_type,std::string&ReplacementFor_boundary){auto pos=
ReplacementFor_content_type.find("\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d");if(pos
==std::string::npos){return false;}ReplacementFor_boundary=
ReplacementFor_content_type.substr(pos+((0x1fc7+172-0x1dda)+(0x21bf+4998-0x2702)
-(0x25dd+1639-0x1b71)));if(ReplacementFor_boundary.length()>=(
(0x1c77+6522-0x19fc)+(0x26ec+1539-0x23af)-9523)&&ReplacementFor_boundary.front()
==((char)(7759+(0xe34+6052-0x2479)-8076))&&ReplacementFor_boundary.back()==((
char)((0xa9d+5907-0x1f80)+(0x17ca+7341-0x24d5)-(0x14af+6033-0x1a90)))){
ReplacementFor_boundary=ReplacementFor_boundary.substr(((0x651+8079-0x23ad)+7318
-7880),ReplacementFor_boundary.size()-((0x109d+4447-0x1e76)+(0x17df+873-0x1757)-
(0xc84+4544-0x16cf)));}return!ReplacementFor_boundary.empty();}bool 
ReplacementFor_parse_range_header(const std::string&s,Ranges&ranges)try{static 
auto ReplacementFor_re_first_range=std::regex(
R"(bytes=(\d*-\d*(?:,\s*\d*-\d*)*))");std::smatch m;if(std::regex_match(s,m,
ReplacementFor_re_first_range)){auto pos=static_cast<size_t>(m.position((
(0x1e29+2684-0x1c85)+(0xbeb+1803-0x10c7)-(0x216b+764-0x1619))));auto len=
static_cast<size_t>(m.length(((0x5ac+4296-0x12fa)+(0x1d0d+5848-0x241b)-
(0x1d8a+5384-0x1f4f))));bool ReplacementFor_all_valid_ranges=true;
ReplacementFor_split(&s[pos],&s[pos+len],((char)((0x1f04+4406-0x1d5b)+
(0x1c68+3280-0x26ce)-(0x212d+3793-0x1ae1))),[&](const char*b,const char*
ReplacementFor_e){if(!ReplacementFor_all_valid_ranges)return;static auto 
ReplacementFor_re_another_range=std::regex(R"(\s*(\d*)-(\d*))");std::cmatch 
ReplacementFor_cm;if(std::regex_match(b,ReplacementFor_e,ReplacementFor_cm,
ReplacementFor_re_another_range)){ssize_t first=-((0xe92+3025-0x1246)+
(0xe6c+1637-0xd24)-(0x177b+5066-0x1b7c));if(!ReplacementFor_cm.str((
(0x7b9+7844-0x1f67)+(0x2327+928-0x1bf3)-(0x1835+5180-0x1aa8))).empty()){first=
static_cast<ssize_t>(std::stoll(ReplacementFor_cm.str(((0x2362+4292-0x2065)+
(0x651+849-0x748)-5658))));}ssize_t ReplacementFor_last=-((0x556+299-0x645)+
(0x23d9+3360-0x116e)-8134);if(!ReplacementFor_cm.str(((0x22c9+6313-0x2670)+2943-
8319)).empty()){ReplacementFor_last=static_cast<ssize_t>(std::stoll(
ReplacementFor_cm.str(((0x169f+4808-0x1caf)+5602-8856))));}if(first!=-(
(0x45b+7794-0x1fe1)+(0x2328+836-0x18d1)-(0x23c3+1464-0x18f5))&&
ReplacementFor_last!=-((0x15a7+6129-0x2047)+(0x1421+2343-0x14d3)-
(0x2198+3724-0x1a5f))&&first>ReplacementFor_last){
ReplacementFor_all_valid_ranges=false;return;}ranges.emplace_back(std::make_pair
(first,ReplacementFor_last));}});return ReplacementFor_all_valid_ranges;}return 
false;}catch(...){return false;}class ReplacementFor_MultipartFormDataParser{
public:ReplacementFor_MultipartFormDataParser()=default;void 
ReplacementFor_set_boundary(std::string&&ReplacementFor_boundary){
ReplacementFor_boundary_=ReplacementFor_boundary;}bool ReplacementFor_is_valid()
const{return ReplacementFor_is_valid_;}bool ReplacementFor_parse(const char*buf,
size_t n,const ReplacementFor_ContentReceiver&ReplacementFor_content_callback,
const ReplacementFor_MultipartContentHeader&ReplacementFor_header_callback){
static const std::regex ReplacementFor_re_content_disposition(
"\x5e\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x44\x69\x73\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a"
"\\""\x73\x2a\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b""\\"
"\x73\x2a\x6e\x61\x6d\x65\x3d""\"""\x28\x2e\x2a\x3f\x29""\"""\x28\x3f\x3a\x3b"
"\\""\x73\x2a\x66\x69\x6c\x65\x6e\x61\x6d\x65\x3d""\"""\x28\x2e\x2a\x3f\x29""\""
"\x29\x3f""\\""\x73\x2a\x24",std::regex_constants::icase);static const std::
string ReplacementFor_dash_="\x2d\x2d";static const std::string 
ReplacementFor_crlf_="\r\n";ReplacementFor_buf_.append(buf,n);while(!
ReplacementFor_buf_.empty()){switch(ReplacementFor_state_){case(7193+
(0x1350+3397-0x1f10)-7582):{auto pattern=ReplacementFor_dash_+
ReplacementFor_boundary_+ReplacementFor_crlf_;if(pattern.size()>
ReplacementFor_buf_.size()){return true;}auto pos=ReplacementFor_buf_.find(
pattern);if(pos!=((0x132b+1309-0x12a1)+(0x1522+1845-0xaaf)-(0x2016+3623-0x16ee))
){return false;}ReplacementFor_buf_.erase(((0x24e8+135-0x1510)+
(0x17f7+1664-0x1795)-(0x2526+6270-0x2663)),pattern.size());ReplacementFor_off_+=
pattern.size();ReplacementFor_state_=((0xed9+7123-0x1d8f)+(0x11c5+4719-0x2267)-
(0x1379+3078-0x1096));break;}case((0x14e7+4171-0x217a)+3862-(0x134b+4160-0x10be)
):{ReplacementFor_clear_file_info();ReplacementFor_state_=((0x1f4b+1230-0x2413)+
(0x1273+2650-0x1778)-(0x1867+1251-0x17f1));break;}case((0x13af+3136-0x1ed0)+
(0x216b+6090-0x19d2)-(0x212c+5410-0x15ce)):{auto pos=ReplacementFor_buf_.find(
ReplacementFor_crlf_);while(pos!=std::string::npos){if(pos==((0xc8d+4238-0x1c0f)
+(0x1693+901-0xead)-3191)){if(!ReplacementFor_header_callback(
ReplacementFor_file_)){ReplacementFor_is_valid_=false;return false;}
ReplacementFor_buf_.erase(((0xed0+7698-0x23bf)+(0x1c0b+1831-0x1ea2)-
(0x1dec+815-0x1368)),ReplacementFor_crlf_.size());ReplacementFor_off_+=
ReplacementFor_crlf_.size();ReplacementFor_state_=((0x1fc6+1945-0x26c5)+
(0x1a5a+1429-0xc13)-(0x17b1+702-0x5fc));break;}static const std::string 
ReplacementFor_header_name=
"\x63\x6f\x6e\x74\x65\x6e\x74\x2d\x74\x79\x70\x65\x3a";const auto header=
ReplacementFor_buf_.substr(((0x5e3+3151-0x1086)+(0x1f7c+3691-0x14a1)-
(0x23c5+6090-0x209d)),pos);if(ReplacementFor_start_with_case_ignore(header,
ReplacementFor_header_name)){ReplacementFor_file_.ReplacementFor_content_type=
ReplacementFor_trim_copy(header.substr(ReplacementFor_header_name.size()));}else
{std::smatch m;if(std::regex_match(header,m,
ReplacementFor_re_content_disposition)){ReplacementFor_file_.name=m[(
(0x78a+9100-0x2556)+5433-6904)];ReplacementFor_file_.ReplacementFor_filename=m[(
(0x2591+5300-0x21a4)+(0x1d1c+1219-0x2002)-6780)];}}ReplacementFor_buf_.erase((
5414+(0x21b+5246-0x148a)-(0x2104+5537-0x1f70)),pos+ReplacementFor_crlf_.size());
ReplacementFor_off_+=pos+ReplacementFor_crlf_.size();pos=ReplacementFor_buf_.
find(ReplacementFor_crlf_);}if(ReplacementFor_state_!=((0x639+6020-0x1cd9)+9094-
(0x266f+3108-0xe2c))){return true;}break;}case((0x24b7+2636-0x24fc)+
(0x227f+498-0x127a)-(0x2377+3533-0x1549)):{{auto pattern=ReplacementFor_crlf_+
ReplacementFor_dash_;if(pattern.size()>ReplacementFor_buf_.size()){return true;}
auto pos=ReplacementFor_find_string(ReplacementFor_buf_,pattern);if(!
ReplacementFor_content_callback(ReplacementFor_buf_.data(),pos)){
ReplacementFor_is_valid_=false;return false;}ReplacementFor_off_+=pos;
ReplacementFor_buf_.erase(((0x1fe1+4334-0x16d2)+(0x49c+4716-0x1338)-
(0x24ba+762-0x9e7)),pos);}{auto pattern=ReplacementFor_crlf_+
ReplacementFor_dash_+ReplacementFor_boundary_;if(pattern.size()>
ReplacementFor_buf_.size()){return true;}auto pos=ReplacementFor_buf_.find(
pattern);if(pos!=std::string::npos){if(!ReplacementFor_content_callback(
ReplacementFor_buf_.data(),pos)){ReplacementFor_is_valid_=false;return false;}
ReplacementFor_off_+=pos+pattern.size();ReplacementFor_buf_.erase((
(0x1f1c+3733-0x1f64)+(0x1802+3918-0x1111)-9356),pos+pattern.size());
ReplacementFor_state_=((0x20dc+384-0x2169)+(0x23ad+909-0x1748)-
(0x1c6b+4010-0x1b34));}else{if(!ReplacementFor_content_callback(
ReplacementFor_buf_.data(),pattern.size())){ReplacementFor_is_valid_=false;
return false;}ReplacementFor_off_+=pattern.size();ReplacementFor_buf_.erase((
(0x9d5+1071-0xd98)+(0x1a14+5768-0x1da1)-4967),pattern.size());}}break;}case(
(0x6b5+3696-0x13fa)+(0x2523+361-0x2317)-(0xbb2+4382-0x1834)):{if(
ReplacementFor_crlf_.size()>ReplacementFor_buf_.size()){return true;}if(
ReplacementFor_buf_.compare(((0x18af+961-0x6e3)+(0x1bad+2182-0x18bd)-8451),
ReplacementFor_crlf_.size(),ReplacementFor_crlf_)==((0x1969+2657-0x1e69)+8554-
9931)){ReplacementFor_buf_.erase((4188+(0x8fd+5538-0x1bcc)-(0x1eac+2087-0x13a4))
,ReplacementFor_crlf_.size());ReplacementFor_off_+=ReplacementFor_crlf_.size();
ReplacementFor_state_=((0x2574+2058-0x15fe)+(0xf16+411-0x71a)-8470);}else{auto 
pattern=ReplacementFor_dash_+ReplacementFor_crlf_;if(pattern.size()>
ReplacementFor_buf_.size()){return true;}if(ReplacementFor_buf_.compare((
(0x1f70+1417-0x7b2)+(0xe48+6319-0x1fb0)-9358),pattern.size(),pattern)==(
(0x1382+1557-0xa47)+(0xe73+317-0x144)-(0x1e55+2484-0xa4d))){ReplacementFor_buf_.
erase((3281+(0x1723+4970-0x203e)-(0x26ac+3510-0x1d42)),pattern.size());
ReplacementFor_off_+=pattern.size();ReplacementFor_is_valid_=true;
ReplacementFor_state_=((0x1d74+6855-0x1b61)+(0x5b0+9031-0x2681)-
(0x200c+2544-0xab1));}else{return true;}}break;}case((0x118c+4003-0x1af3)+6410-
8001):{ReplacementFor_is_valid_=false;return false;}}}return true;}private:void 
ReplacementFor_clear_file_info(){ReplacementFor_file_.name.clear();
ReplacementFor_file_.ReplacementFor_filename.clear();ReplacementFor_file_.
ReplacementFor_content_type.clear();}bool ReplacementFor_start_with_case_ignore(
const std::string&a,const std::string&b)const{if(a.size()<b.size()){return false
;}for(size_t i=((0xb6b+7637-0x260d)+7863-(0x2234+715-0x315));i<b.size();i++){if(
::tolower(a[i])!=::tolower(b[i])){return false;}}return true;}bool 
ReplacementFor_start_with(const std::string&a,size_t ReplacementFor_off,const 
std::string&b)const{if(a.size()-ReplacementFor_off<b.size()){return false;}for(
size_t i=((0x2314+984-0x12f4)+(0x353+7998-0x2165)-(0x1999+5826-0x1b37));i<b.size
();i++){if(a[i+ReplacementFor_off]!=b[i]){return false;}}return true;}size_t 
ReplacementFor_find_string(const std::string&s,const std::string&pattern)const{
auto c=pattern.front();size_t ReplacementFor_off=(4103+2745-6848);while(
ReplacementFor_off<s.size()){auto pos=s.find(c,ReplacementFor_off);if(pos==std::
string::npos){return s.size();}auto rem=s.size()-pos;if(pattern.size()>rem){
return pos;}if(ReplacementFor_start_with(s,pos,pattern)){return pos;}
ReplacementFor_off=pos+((0x1a18+3970-0x1ea9)+(0xa2c+8452-0x2500)-
(0x2510+3179-0x205b));}return s.size();}std::string ReplacementFor_boundary_;std
::string ReplacementFor_buf_;size_t ReplacementFor_state_=((0x11aa+3338-0x1037)+
(0x623+840-0x66f)-(0x1e8b+5916-0x242e));bool ReplacementFor_is_valid_=false;
size_t ReplacementFor_off_=((0x17e9+360-0xcd9)+(0x1d8f+538-0xbaf)-8306);
ReplacementFor_MultipartFormData ReplacementFor_file_;};std::string 
ReplacementFor_to_lower(const char*beg,const char*end){std::string out;auto 
ReplacementFor_it=beg;while(ReplacementFor_it!=end){out+=static_cast<char>(::
tolower(*ReplacementFor_it));ReplacementFor_it++;}return out;}std::string 
ReplacementFor_make_multipart_data_boundary(){static const char data[]=
"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a"
;std::random_device ReplacementFor_seed_gen;std::seed_seq 
ReplacementFor_seed_sequence{ReplacementFor_seed_gen(),ReplacementFor_seed_gen()
,ReplacementFor_seed_gen(),ReplacementFor_seed_gen()};std::mt19937 
ReplacementFor_engine(ReplacementFor_seed_sequence);std::string result=
"\x2d\x2d\x63\x70\x70\x2d\x68\x74\x74\x70\x6c\x69\x62\x2d\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2d\x64\x61\x74\x61\x2d"
;for(auto i=((0x46d+923-0x589)+(0x219a+1962-0x2475)-(0x9d2+600-0x4dc));i<(
(0x14c8+2899-0x16ae)+(0x265f+1555-0x1430)-8607);i++){result+=data[
ReplacementFor_engine()%(sizeof(data)-((0x1845+7129-0x267e)+(0x2059+5542-0x1ecb)
-(0x2684+2539-0xb9c)))];}return result;}std::pair<size_t,size_t>
ReplacementFor_get_range_offset_and_length(const ReplacementFor_Request&
ReplacementFor_req,size_t ReplacementFor_content_length,size_t index){auto 
ReplacementFor_r=ReplacementFor_req.ranges[index];if(ReplacementFor_r.first==-(
(0x1715+1932-0x1896)+3800-(0x18eb+588-0x655))&&ReplacementFor_r.second==-(
(0x1654+5886-0x1a3d)+(0x1313+7000-0x2016)-8553)){return std::make_pair((
(0x1b6a+607-0x1651)+(0xe6b+6850-0x223d)-(0x2670+3028-0x23dc)),
ReplacementFor_content_length);}auto ReplacementFor_slen=static_cast<ssize_t>(
ReplacementFor_content_length);if(ReplacementFor_r.first==-((0x1652+6058-0x1d4d)
+(0x12ad+3776-0x11a7)-(0x217c+8228-0x212c))){ReplacementFor_r.first=(std::max)(
static_cast<ssize_t>(((0x15d4+3090-0x1d0a)+5864-(0x26ef+1133-0xf98))),
ReplacementFor_slen-ReplacementFor_r.second);ReplacementFor_r.second=
ReplacementFor_slen-((0xa1c+2616-0x1039)+(0xcb7+6262-0x1d90)-
(0x1b18+1019-0x135c));}if(ReplacementFor_r.second==-((0x1688+2233-0x8f5)+
(0x1936+4509-0x24b2)-(0x226f+6888-0x20eb))){ReplacementFor_r.second=
ReplacementFor_slen-((0x1195+2526-0x121c)+(0x10e2+1387-0x8a9)-
(0x2531+4296-0x1eff));}return std::make_pair(ReplacementFor_r.first,static_cast<
size_t>(ReplacementFor_r.second-ReplacementFor_r.first)+((0x245d+1740-0x1db7)+
5575-9016));}std::string ReplacementFor_make_content_range_header_field(size_t 
offset,size_t length,size_t ReplacementFor_content_length){std::string field=
"\x62\x79\x74\x65\x73\x20";field+=std::to_string(offset);field+="\x2d";field+=
std::to_string(offset+length-(5039+(0x1c0b+5521-0x2096)-9396));field+="\x2f";
field+=std::to_string(ReplacementFor_content_length);return field;}template<
typename ReplacementFor_SToken,typename ReplacementFor_CToken,typename Content>
bool ReplacementFor_process_multipart_ranges_data(const ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res,const std::string&
ReplacementFor_boundary,const std::string&ReplacementFor_content_type,
ReplacementFor_SToken ReplacementFor_stoken,ReplacementFor_CToken 
ReplacementFor_ctoken,Content ReplacementFor_content){for(size_t i=(
(0x1dec+1274-0x1a91)+(0x16f4+7045-0x1e20)-7342);i<ReplacementFor_req.ranges.size
();i++){ReplacementFor_ctoken("\x2d\x2d");ReplacementFor_stoken(
ReplacementFor_boundary);ReplacementFor_ctoken("\r\n");if(!
ReplacementFor_content_type.empty()){ReplacementFor_ctoken(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20");
ReplacementFor_stoken(ReplacementFor_content_type);ReplacementFor_ctoken("\r\n")
;}auto ReplacementFor_offsets=ReplacementFor_get_range_offset_and_length(
ReplacementFor_req,ReplacementFor_res.ReplacementFor_body.size(),i);auto offset=
ReplacementFor_offsets.first;auto length=ReplacementFor_offsets.second;
ReplacementFor_ctoken(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65\x3a\x20");
ReplacementFor_stoken(ReplacementFor_make_content_range_header_field(offset,
length,ReplacementFor_res.ReplacementFor_body.size()));ReplacementFor_ctoken(
"\r\n");ReplacementFor_ctoken("\r\n");if(!ReplacementFor_content(offset,length))
{return false;}ReplacementFor_ctoken("\r\n");}ReplacementFor_ctoken("\x2d\x2d");
ReplacementFor_stoken(ReplacementFor_boundary);ReplacementFor_ctoken("\x2d\x2d"
"\r\n");return true;}bool ReplacementFor_make_multipart_ranges_data(const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,const std::string&ReplacementFor_boundary,const std::string&
ReplacementFor_content_type,std::string&data){return 
ReplacementFor_process_multipart_ranges_data(ReplacementFor_req,
ReplacementFor_res,ReplacementFor_boundary,ReplacementFor_content_type,[&](const
 std::string&ReplacementFor_token){data+=ReplacementFor_token;},[&](const char*
ReplacementFor_token){data+=ReplacementFor_token;},[&](size_t offset,size_t 
length){if(offset<ReplacementFor_res.ReplacementFor_body.size()){data+=
ReplacementFor_res.ReplacementFor_body.substr(offset,length);return true;}return
 false;});}size_t ReplacementFor_get_multipart_ranges_data_length(const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,const std::string&ReplacementFor_boundary,const std::string&
ReplacementFor_content_type){size_t ReplacementFor_data_length=(
(0x11aa+166-0x2ca)+(0x11c3+9644-0x267b)-(0x23a9+3227-0xfca));
ReplacementFor_process_multipart_ranges_data(ReplacementFor_req,
ReplacementFor_res,ReplacementFor_boundary,ReplacementFor_content_type,[&](const
 std::string&ReplacementFor_token){ReplacementFor_data_length+=
ReplacementFor_token.size();},[&](const char*ReplacementFor_token){
ReplacementFor_data_length+=strlen(ReplacementFor_token);},[&](size_t,size_t 
length){ReplacementFor_data_length+=length;return true;});return 
ReplacementFor_data_length;}template<typename T>bool 
ReplacementFor_write_multipart_ranges_data(ReplacementFor_Stream&
ReplacementFor_strm,const ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,const std::string&
ReplacementFor_boundary,const std::string&ReplacementFor_content_type,const T&
ReplacementFor_is_shutting_down){return 
ReplacementFor_process_multipart_ranges_data(ReplacementFor_req,
ReplacementFor_res,ReplacementFor_boundary,ReplacementFor_content_type,[&](const
 std::string&ReplacementFor_token){ReplacementFor_strm.write(
ReplacementFor_token);},[&](const char*ReplacementFor_token){ReplacementFor_strm
.write(ReplacementFor_token);},[&](size_t offset,size_t length){return 
ReplacementFor_write_content(ReplacementFor_strm,ReplacementFor_res.
ReplacementFor_content_provider_,offset,length,ReplacementFor_is_shutting_down);
});}std::pair<size_t,size_t>ReplacementFor_get_range_offset_and_length(const 
ReplacementFor_Request&ReplacementFor_req,const ReplacementFor_Response&
ReplacementFor_res,size_t index){auto ReplacementFor_r=ReplacementFor_req.ranges
[index];if(ReplacementFor_r.second==-((0x108b+1975-0x1745)+9290-
(0x2578+5473-0x1593))){ReplacementFor_r.second=static_cast<ssize_t>(
ReplacementFor_res.ReplacementFor_content_length_)-((0x233a+2356-0x2497)+
(0x1d84+1365-0x1456)-5721);}return std::make_pair(ReplacementFor_r.first,
ReplacementFor_r.second-ReplacementFor_r.first+((0x14b8+6750-0x20f2)+
(0x227c+2554-0x2051)-(0x2504+852-0xe10)));}bool ReplacementFor_expect_content(
const ReplacementFor_Request&ReplacementFor_req){if(ReplacementFor_req.
ReplacementFor_method=="\x50\x4f\x53\x54"||ReplacementFor_req.
ReplacementFor_method=="\x50\x55\x54"||ReplacementFor_req.ReplacementFor_method
=="\x50\x41\x54\x43\x48"||ReplacementFor_req.ReplacementFor_method==
"\x50\x52\x49"||ReplacementFor_req.ReplacementFor_method==
"\x44\x45\x4c\x45\x54\x45"){return true;}return false;}bool 
ReplacementFor_has_crlf(const char*s){auto p=s;while(*p){if(*p=='\r'||*p=='\n'){
return true;}p++;}return false;}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
template<typename CTX,typename Init,typename Update,typename Final>std::string 
ReplacementFor_message_digest(const std::string&s,Init init,Update 
ReplacementFor_update,Final final,size_t ReplacementFor_digest_length){using 
namespace std;std::vector<unsigned char>ReplacementFor_md(
ReplacementFor_digest_length,((0xc37+5273-0x1edb)+(0x14a8+1286-0xbd9)-
(0x108f+1921-0x846)));CTX ctx;init(&ctx);ReplacementFor_update(&ctx,s.data(),s.
size());final(ReplacementFor_md.data(),&ctx);stringstream ReplacementFor_ss;for(
auto c:ReplacementFor_md){ReplacementFor_ss<<setfill(((char)((0xc25+3632-0x14c3)
+(0x1f97+911-0x1d43)-(0x16c2+3587-0x1980))))<<setw(((0xab6+6175-0x205c)+
(0x1a27+718-0x36c)-(0x2441+3922-0x1793)))<<hex<<(unsigned int)c;}return 
ReplacementFor_ss.str();}std::string ReplacementFor_MD5(const std::string&s){
return ReplacementFor_message_digest<ReplacementFor_MD5_CTX>(s,
ReplacementFor_MD5_Init,ReplacementFor_MD5_Update,ReplacementFor_MD5_Final,
ReplacementFor_MD5_DIGEST_LENGTH);}std::string ReplacementFor_SHA_256(const std
::string&s){return ReplacementFor_message_digest<ReplacementFor_SHA256_CTX>(s,
ReplacementFor_SHA256_Init,ReplacementFor_SHA256_Update,
ReplacementFor_SHA256_Final,ReplacementFor_SHA256_DIGEST_LENGTH);}std::string 
ReplacementFor_SHA_512(const std::string&s){return ReplacementFor_message_digest
<ReplacementFor_SHA512_CTX>(s,ReplacementFor_SHA512_Init,
ReplacementFor_SHA512_Update,ReplacementFor_SHA512_Final,
ReplacementFor_SHA512_DIGEST_LENGTH);}
#endif
#ifdef _WIN32
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
bool ReplacementFor_load_system_certs_on_windows(ReplacementFor_X509_STORE*store
){auto ReplacementFor_hStore=CertOpenSystemStoreW((
ReplacementFor_HCRYPTPROV_LEGACY)NULL,L"ROOT");if(!ReplacementFor_hStore){return
 false;}PCCERT_CONTEXT pContext=NULL;while((pContext=CertEnumCertificatesInStore
(ReplacementFor_hStore,pContext))!=nullptr){auto ReplacementFor_encoded_cert=
static_cast<const unsigned char*>(pContext->pbCertEncoded);auto 
ReplacementFor_x509=ReplacementFor_d2i_X509(NULL,&ReplacementFor_encoded_cert,
pContext->cbCertEncoded);if(ReplacementFor_x509){
ReplacementFor_X509_STORE_add_cert(store,ReplacementFor_x509);
ReplacementFor_X509_free(ReplacementFor_x509);}}CertFreeCertificateContext(
pContext);CertCloseStore(ReplacementFor_hStore,((0x192b+3524-0x1942)+
(0x13d0+4636-0x1cba)-(0x1808+8013-0x2076)));return true;}
#endif
class ReplacementFor_WSInit{public:ReplacementFor_WSInit(){WSADATA 
ReplacementFor_wsaData;WSAStartup(((0xf50+2945-0x1262)+(0x1cec+1812-0x1557)-
(0x234f+5580-0x2205)),&ReplacementFor_wsaData);}~ReplacementFor_WSInit(){
WSACleanup();}};static ReplacementFor_WSInit ReplacementFor_wsinit_;
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
std::pair<std::string,std::string>
ReplacementFor_make_digest_authentication_header(const ReplacementFor_Request&
ReplacementFor_req,const std::map<std::string,std::string>&ReplacementFor_auth,
size_t ReplacementFor_cnonce_count,const std::string&ReplacementFor_cnonce,const
 std::string&ReplacementFor_username,const std::string&ReplacementFor_password,
bool ReplacementFor_is_proxy=false){using namespace std;string ReplacementFor_nc
;{stringstream ReplacementFor_ss;ReplacementFor_ss<<setfill(((char)(
(0x21b4+2422-0x1d93)+(0x1c27+640-0x7dd)-9265)))<<setw(((0x2451+4306-0x1869)+
(0x110b+622-0xcf4)-9015))<<hex<<ReplacementFor_cnonce_count;ReplacementFor_nc=
ReplacementFor_ss.str();}auto ReplacementFor_qop=ReplacementFor_auth.at(
"\x71\x6f\x70");if(ReplacementFor_qop.find("\x61\x75\x74\x68\x2d\x69\x6e\x74")!=
std::string::npos){ReplacementFor_qop="\x61\x75\x74\x68\x2d\x69\x6e\x74";}else{
ReplacementFor_qop="\x61\x75\x74\x68";}std::string ReplacementFor_algo=
"\x4d\x44\x35";if(ReplacementFor_auth.find(
"\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d")!=ReplacementFor_auth.end()){
ReplacementFor_algo=ReplacementFor_auth.at(
"\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d");}string ReplacementFor_response;{auto 
ReplacementFor_H=ReplacementFor_algo=="\x53\x48\x41\x2d\x32\x35\x36"?
ReplacementFor_detail::ReplacementFor_SHA_256:ReplacementFor_algo==
"\x53\x48\x41\x2d\x35\x31\x32"?ReplacementFor_detail::ReplacementFor_SHA_512:
ReplacementFor_detail::ReplacementFor_MD5;auto ReplacementFor_A1=
ReplacementFor_username+"\x3a"+ReplacementFor_auth.at("\x72\x65\x61\x6c\x6d")+
"\x3a"+ReplacementFor_password;auto ReplacementFor_A2=ReplacementFor_req.
ReplacementFor_method+"\x3a"+ReplacementFor_req.ReplacementFor_path;if(
ReplacementFor_qop=="\x61\x75\x74\x68\x2d\x69\x6e\x74"){ReplacementFor_A2+=
"\x3a"+ReplacementFor_H(ReplacementFor_req.ReplacementFor_body);}
ReplacementFor_response=ReplacementFor_H(ReplacementFor_H(ReplacementFor_A1)+
"\x3a"+ReplacementFor_auth.at("\x6e\x6f\x6e\x63\x65")+"\x3a"+ReplacementFor_nc+
"\x3a"+ReplacementFor_cnonce+"\x3a"+ReplacementFor_qop+"\x3a"+ReplacementFor_H(
ReplacementFor_A2));}auto field=
"\x44\x69\x67\x65\x73\x74\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3d""\""+
ReplacementFor_username+"\"""\x2c\x20\x72\x65\x61\x6c\x6d\x3d""\""+
ReplacementFor_auth.at("\x72\x65\x61\x6c\x6d")+"\""
"\x2c\x20\x6e\x6f\x6e\x63\x65\x3d""\""+ReplacementFor_auth.at(
"\x6e\x6f\x6e\x63\x65")+"\"""\x2c\x20\x75\x72\x69\x3d""\""+ReplacementFor_req.
ReplacementFor_path+"\"""\x2c\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x3d"+
ReplacementFor_algo+"\x2c\x20\x71\x6f\x70\x3d"+ReplacementFor_qop+
"\x2c\x20\x6e\x63\x3d""\""+ReplacementFor_nc+"\""
"\x2c\x20\x63\x6e\x6f\x6e\x63\x65\x3d""\""+ReplacementFor_cnonce+"\""
"\x2c\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x3d""\""+ReplacementFor_response+"\"";
auto key=ReplacementFor_is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,field);}
#endif
bool ReplacementFor_parse_www_authenticate(const ReplacementFor_Response&
ReplacementFor_res,std::map<std::string,std::string>&ReplacementFor_auth,bool 
ReplacementFor_is_proxy){auto ReplacementFor_auth_key=ReplacementFor_is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x65":
"\x57\x57\x57\x2d\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x65";if(
ReplacementFor_res.ReplacementFor_has_header(ReplacementFor_auth_key)){static 
auto ReplacementFor_re=std::regex(ReplacementFor_R"~((?:(?:,\s*)?(.+?)=(?:"(.*?)
"\x7c\x28\x5b\x5e\x2c\x5d\x2a\x29\x29\x29\x29\x7e");auto s=ReplacementFor_res.
ReplacementFor_get_header_value(ReplacementFor_auth_key);auto pos=s.find(((char)
((0x13d1+946-0xaa3)+3525-(0x1d64+2338-0xc01))));if(pos!=std::string::npos){auto 
type=s.substr(((0x879+1314-0xc7b)+3629-(0x1418+2017-0xcac)),pos);if(type==
"\x42\x61\x73\x69\x63"){return false;}else if(type=="\x44\x69\x67\x65\x73\x74"){
s=s.substr(pos+(4775+(0x1b12+4198-0x2439)-(0x2144+6675-0x2172)));auto beg=std::
sregex_iterator(s.begin(),s.end(),ReplacementFor_re);for(auto i=beg;i!=std::
sregex_iterator();++i){auto m=*i;auto key=s.substr(static_cast<size_t>(m.
position(((0x16da+1597-0x11a8)+(0x24f5+454-0x1db6)-(0x2557+1189-0x1589)))),
static_cast<size_t>(m.length(((0x1c82+1860-0x21b6)+5812-(0x19b5+4672-0x1332)))))
;auto val=m.length(((0xe22+92-0xd92)+7801-8035))>((0x1c07+1532-0x1346)+
(0x1496+6574-0x25e6)-(0x17a0+2797-0xb72))?s.substr(static_cast<size_t>(m.
position((6006+2923-8927))),static_cast<size_t>(m.length(((0x15bb+3120-0x1dff)+
(0x1f84+1517-0x1206)-5973)))):s.substr(static_cast<size_t>(m.position((
(0x13e4+4765-0x246f)+(0x16a6+3728-0x142c)-(0x16e1+2787-0xeab)))),static_cast<
size_t>(m.length(((0x187a+5512-0x2385)+(0x20d4+4033-0x1d1a)-(0x1e6c+3147-0xcc2))
)));ReplacementFor_auth[key]=val;}return true;}}}return false;}std::string 
ReplacementFor_random_string(size_t length){auto ReplacementFor_randchar=[]()->
char{const char ReplacementFor_charset[]=
"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39"
"\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a"
"\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a"
;const size_t ReplacementFor_max_index=(sizeof(ReplacementFor_charset)-(
(0x1232+3802-0x1d70)+8802-9725));return ReplacementFor_charset[static_cast<
size_t>(rand())%ReplacementFor_max_index];};std::string str(length,(
(0x1209+3191-0x1007)+(0x20c6+2549-0x1390)-9636));std::generate_n(str.begin(),
length,ReplacementFor_randchar);return str;}class 
ReplacementFor_ContentProviderAdapter{public:explicit 
ReplacementFor_ContentProviderAdapter(
ReplacementFor_ContentProviderWithoutLength&&ReplacementFor_content_provider):
ReplacementFor_content_provider_(ReplacementFor_content_provider){}bool operator
()(size_t offset,size_t,ReplacementFor_DataSink&ReplacementFor_sink){return 
ReplacementFor_content_provider_(offset,ReplacementFor_sink);}private:
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider_;};}
std::pair<std::string,std::string>ReplacementFor_make_range_header(Ranges ranges
){std::string field="\x62\x79\x74\x65\x73\x3d";auto i=((0x12f4+9317-0x25d0)+
(0x1666+2379-0x14c6)-(0x200d+788-0x6ad));for(auto ReplacementFor_r:ranges){if(i
!=((0x23b4+870-0x136f)+(0xcc9+3980-0x181f)-(0x22d7+4320-0x1bd6))){field+=
"\x2c\x20";}if(ReplacementFor_r.first!=-((0x12c8+4762-0x1681)+(0x937+3087-0xd17)
-5903)){field+=std::to_string(ReplacementFor_r.first);}field+=((char)(
(0x1fe3+3813-0x21a1)+(0x199a+5598-0x25ba)-(0x1b20+1252-0x94c)));if(
ReplacementFor_r.second!=-((0x20e5+6086-0x191e)+(0x1ce5+543-0x1d43)-
(0x2296+3311-0xe38))){field+=std::to_string(ReplacementFor_r.second);}i++;}
return std::make_pair("\x52\x61\x6e\x67\x65",std::move(field));}std::pair<std::
string,std::string>ReplacementFor_make_basic_authentication_header(const std::
string&ReplacementFor_username,const std::string&ReplacementFor_password,bool 
ReplacementFor_is_proxy=false){auto field="\x42\x61\x73\x69\x63\x20"+
ReplacementFor_detail::ReplacementFor_base64_encode(ReplacementFor_username+
"\x3a"+ReplacementFor_password);auto key=ReplacementFor_is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,std::move(field));}std::pair<std::string,std::string>
ReplacementFor_make_bearer_token_authentication_header(const std::string&
ReplacementFor_token,bool ReplacementFor_is_proxy=false){auto field=
"\x42\x65\x61\x72\x65\x72\x20"+ReplacementFor_token;auto key=
ReplacementFor_is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,std::move(field));}bool ReplacementFor_Request::ReplacementFor_has_header(const
 char*key)const{return ReplacementFor_detail::ReplacementFor_has_header(
ReplacementFor_headers,key);}std::string ReplacementFor_Request::
ReplacementFor_get_header_value(const char*key,size_t id)const{return 
ReplacementFor_detail::ReplacementFor_get_header_value(ReplacementFor_headers,
key,id,"");}template<typename T>T ReplacementFor_Request::
ReplacementFor_get_header_value(const char*key,size_t id)const{return 
ReplacementFor_detail::ReplacementFor_get_header_value<T>(ReplacementFor_headers
,key,id,((0x15a7+1390-0x16c4)+8628-(0x2671+4338-0x115e)));}size_t 
ReplacementFor_Request::ReplacementFor_get_header_value_count(const char*key)
const{auto ReplacementFor_r=ReplacementFor_headers.equal_range(key);return 
static_cast<size_t>(std::distance(ReplacementFor_r.first,ReplacementFor_r.second
));}void ReplacementFor_Request::ReplacementFor_set_header(const char*key,const 
char*val){if(!ReplacementFor_detail::ReplacementFor_has_crlf(key)&&!
ReplacementFor_detail::ReplacementFor_has_crlf(val)){ReplacementFor_headers.
emplace(key,val);}}void ReplacementFor_Request::ReplacementFor_set_header(const 
char*key,const std::string&val){if(!ReplacementFor_detail::
ReplacementFor_has_crlf(key)&&!ReplacementFor_detail::ReplacementFor_has_crlf(
val.c_str())){ReplacementFor_headers.emplace(key,val);}}bool 
ReplacementFor_Request::ReplacementFor_has_param(const char*key)const{return 
ReplacementFor_params.find(key)!=ReplacementFor_params.end();}std::string 
ReplacementFor_Request::ReplacementFor_get_param_value(const char*key,size_t id)
const{auto ReplacementFor_rng=ReplacementFor_params.equal_range(key);auto 
ReplacementFor_it=ReplacementFor_rng.first;std::advance(ReplacementFor_it,
static_cast<ssize_t>(id));if(ReplacementFor_it!=ReplacementFor_rng.second){
return ReplacementFor_it->second;}return std::string();}size_t 
ReplacementFor_Request::ReplacementFor_get_param_value_count(const char*key)
const{auto ReplacementFor_r=ReplacementFor_params.equal_range(key);return 
static_cast<size_t>(std::distance(ReplacementFor_r.first,ReplacementFor_r.second
));}bool ReplacementFor_Request::ReplacementFor_is_multipart_form_data()const{
const auto&ReplacementFor_content_type=ReplacementFor_get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");return!
ReplacementFor_content_type.find(
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61");
}bool ReplacementFor_Request::ReplacementFor_has_file(const char*key)const{
return ReplacementFor_files.find(key)!=ReplacementFor_files.end();}
ReplacementFor_MultipartFormData ReplacementFor_Request::
ReplacementFor_get_file_value(const char*key)const{auto ReplacementFor_it=
ReplacementFor_files.find(key);if(ReplacementFor_it!=ReplacementFor_files.end())
{return ReplacementFor_it->second;}return ReplacementFor_MultipartFormData();}
bool ReplacementFor_Response::ReplacementFor_has_header(const char*key)const{
return ReplacementFor_headers.find(key)!=ReplacementFor_headers.end();}std::
string ReplacementFor_Response::ReplacementFor_get_header_value(const char*key,
size_t id)const{return ReplacementFor_detail::ReplacementFor_get_header_value(
ReplacementFor_headers,key,id,"");}template<typename T>T ReplacementFor_Response
::ReplacementFor_get_header_value(const char*key,size_t id)const{return 
ReplacementFor_detail::ReplacementFor_get_header_value<T>(ReplacementFor_headers
,key,id,(5330+(0x186a+3422-0x1dea)-7344));}size_t ReplacementFor_Response::
ReplacementFor_get_header_value_count(const char*key)const{auto ReplacementFor_r
=ReplacementFor_headers.equal_range(key);return static_cast<size_t>(std::
distance(ReplacementFor_r.first,ReplacementFor_r.second));}void 
ReplacementFor_Response::ReplacementFor_set_header(const char*key,const char*val
){if(!ReplacementFor_detail::ReplacementFor_has_crlf(key)&&!
ReplacementFor_detail::ReplacementFor_has_crlf(val)){ReplacementFor_headers.
emplace(key,val);}}void ReplacementFor_Response::ReplacementFor_set_header(const
 char*key,const std::string&val){if(!ReplacementFor_detail::
ReplacementFor_has_crlf(key)&&!ReplacementFor_detail::ReplacementFor_has_crlf(
val.c_str())){ReplacementFor_headers.emplace(key,val);}}void 
ReplacementFor_Response::ReplacementFor_set_redirect(const char*
ReplacementFor_url,int stat){if(!ReplacementFor_detail::ReplacementFor_has_crlf(
ReplacementFor_url)){ReplacementFor_set_header(
"\x4c\x6f\x63\x61\x74\x69\x6f\x6e",ReplacementFor_url);if(((0x1800+442-0x1818)+
(0x172a+5329-0x1a38)-(0x24e1+2957-0x1e35))<=stat&&stat<((0x25b5+3011-0x2274)+
(0x1ba0+7511-0x2160)-9483)){this->status=stat;}else{this->status=
(0x150+3061-0xc17);}}}void ReplacementFor_Response::ReplacementFor_set_redirect(
const std::string&ReplacementFor_url,int stat){ReplacementFor_set_redirect(
ReplacementFor_url.c_str(),stat);}void ReplacementFor_Response::
ReplacementFor_set_content(const char*s,size_t n,const char*
ReplacementFor_content_type){ReplacementFor_body.assign(s,n);auto 
ReplacementFor_rng=ReplacementFor_headers.equal_range(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");ReplacementFor_headers.erase
(ReplacementFor_rng.first,ReplacementFor_rng.second);ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
}void ReplacementFor_Response::ReplacementFor_set_content(const std::string&s,
const char*ReplacementFor_content_type){ReplacementFor_set_content(s.data(),s.
size(),ReplacementFor_content_type);}void ReplacementFor_Response::
ReplacementFor_set_content_provider(size_t ReplacementFor_in_length,const char*
ReplacementFor_content_type,ReplacementFor_ContentProvider 
ReplacementFor_provider,const std::function<void()>&
ReplacementFor_resource_releaser){assert(ReplacementFor_in_length>(
(0x21b4+168-0x16e7)+(0x1702+3680-0x1d1c)-5051));ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
ReplacementFor_content_length_=ReplacementFor_in_length;
ReplacementFor_content_provider_=std::move(ReplacementFor_provider);
ReplacementFor_content_provider_resource_releaser_=
ReplacementFor_resource_releaser;ReplacementFor_is_chunked_content_provider_=
false;}void ReplacementFor_Response::ReplacementFor_set_content_provider(const 
char*ReplacementFor_content_type,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_provider,const std::function<void()>&
ReplacementFor_resource_releaser){ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
ReplacementFor_content_length_=((0x254c+1872-0xc98)+(0x1c29+2354-0x23d5)-8586);
ReplacementFor_content_provider_=ReplacementFor_detail::
ReplacementFor_ContentProviderAdapter(std::move(ReplacementFor_provider));
ReplacementFor_content_provider_resource_releaser_=
ReplacementFor_resource_releaser;ReplacementFor_is_chunked_content_provider_=
false;}void ReplacementFor_Response::ReplacementFor_set_chunked_content_provider
(const char*ReplacementFor_content_type,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_provider,const std::
function<void()>&ReplacementFor_resource_releaser){ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
ReplacementFor_content_length_=((0x18d1+512-0x6a7)+(0x15dd+1183-0xe0e)-8344);
ReplacementFor_content_provider_=ReplacementFor_detail::
ReplacementFor_ContentProviderAdapter(std::move(ReplacementFor_provider));
ReplacementFor_content_provider_resource_releaser_=
ReplacementFor_resource_releaser;ReplacementFor_is_chunked_content_provider_=
true;}bool Result::ReplacementFor_has_request_header(const char*key)const{return
 ReplacementFor_request_headers_.find(key)!=ReplacementFor_request_headers_.end(
);}std::string Result::ReplacementFor_get_request_header_value(const char*key,
size_t id)const{return ReplacementFor_detail::ReplacementFor_get_header_value(
ReplacementFor_request_headers_,key,id,"");}template<typename T>T Result::
ReplacementFor_get_request_header_value(const char*key,size_t id)const{return 
ReplacementFor_detail::ReplacementFor_get_header_value<T>(
ReplacementFor_request_headers_,key,id,((0x1937+417-0xc98)+(0x10f8+6421-0x1e70)-
(0x204f+2115-0xeb5)));}size_t Result::
ReplacementFor_get_request_header_value_count(const char*key)const{auto 
ReplacementFor_r=ReplacementFor_request_headers_.equal_range(key);return 
static_cast<size_t>(std::distance(ReplacementFor_r.first,ReplacementFor_r.second
));}ssize_t ReplacementFor_Stream::write(const char*ReplacementFor_ptr){return 
write(ReplacementFor_ptr,strlen(ReplacementFor_ptr));}ssize_t 
ReplacementFor_Stream::write(const std::string&s){return write(s.data(),s.size()
);}template<typename...ReplacementFor_Args>ssize_t ReplacementFor_Stream::
ReplacementFor_write_format(const char*ReplacementFor_fmt,const 
ReplacementFor_Args&...ReplacementFor_args){const auto ReplacementFor_bufsiz=(
(0x2387+6411-0x1d13)+(0x1e60+1266-0x2159)-(0x1f15+2804-0x1091));std::array<char,
ReplacementFor_bufsiz>buf;
#if defined(_MSC_VER) && _MSC_VER < ((0x1e97+3897-0x1948)+5932-\
(0x25bd+1211-0x630))
auto ReplacementFor_sn=ReplacementFor__snprintf_s(buf.data(),
ReplacementFor_bufsiz-((0x23f6+2600-0x2485)+(0x730+5576-0x1c1c)-2676),buf.size()
-(7814+(0x1a36+1472-0x1b0e)-9069),ReplacementFor_fmt,ReplacementFor_args...);
#else
auto ReplacementFor_sn=snprintf(buf.data(),buf.size()-((0x26b3+389-0x1868)+
(0x966+6461-0x1c53)-(0x2567+5390-0x2456)),ReplacementFor_fmt,ReplacementFor_args
...);
#endif
if(ReplacementFor_sn<=((0x1a79+3703-0x1379)+(0xb90+7241-0x1ed2)-7806)){return 
ReplacementFor_sn;}auto n=static_cast<size_t>(ReplacementFor_sn);if(n>=buf.size(
)-((0x508+2187-0xb26)+9176-9796)){std::vector<char>ReplacementFor_glowable_buf(
buf.size());while(n>=ReplacementFor_glowable_buf.size()-((0x2595+3416-0x217d)+
(0x15a0+817-0x10cf)-(0x1ddf+1302-0x984))){ReplacementFor_glowable_buf.resize(
ReplacementFor_glowable_buf.size()*((0x20a4+3811-0x13dc)+(0xaf9+924-0xb91)-7853)
);
#if defined(_MSC_VER) && _MSC_VER < ((0x23e5+80-0x873)+(0x13d6+3743-0x1838)-7827\
)
n=static_cast<size_t>(ReplacementFor__snprintf_s(&ReplacementFor_glowable_buf[(
(0x20c9+3361-0x119f)+(0x14e9+305-0xbdf)-9862)],ReplacementFor_glowable_buf.size(
),ReplacementFor_glowable_buf.size()-((0xc8f+1481-0x11e6)+4965-
(0x1c65+2423-0x1206)),ReplacementFor_fmt,ReplacementFor_args...));
#else
n=static_cast<size_t>(snprintf(&ReplacementFor_glowable_buf[((0xa4f+4852-0x1cee)
+(0x226d+153-0x1a2)-8633)],ReplacementFor_glowable_buf.size()-(
(0x25bb+846-0x2161)+(0xd27+3377-0xeb9)-(0x25d9+3039-0x1e72)),ReplacementFor_fmt,
ReplacementFor_args...));
#endif
}return write(&ReplacementFor_glowable_buf[((0x1860+4062-0x226e)+
(0x1f53+589-0x1a44)-(0x1861+7044-0x26b9))],n);}else{return write(buf.data(),n);}
}namespace ReplacementFor_detail{ReplacementFor_SocketStream::
ReplacementFor_SocketStream(ReplacementFor_socket_t ReplacementFor_sock,time_t 
ReplacementFor_read_timeout_sec,time_t ReplacementFor_read_timeout_usec,time_t 
ReplacementFor_write_timeout_sec,time_t ReplacementFor_write_timeout_usec):
ReplacementFor_sock_(ReplacementFor_sock),ReplacementFor_read_timeout_sec_(
ReplacementFor_read_timeout_sec),ReplacementFor_read_timeout_usec_(
ReplacementFor_read_timeout_usec),ReplacementFor_write_timeout_sec_(
ReplacementFor_write_timeout_sec),ReplacementFor_write_timeout_usec_(
ReplacementFor_write_timeout_usec){}ReplacementFor_SocketStream::~
ReplacementFor_SocketStream(){}bool ReplacementFor_SocketStream::
ReplacementFor_is_readable()const{return ReplacementFor_select_read(
ReplacementFor_sock_,ReplacementFor_read_timeout_sec_,
ReplacementFor_read_timeout_usec_)>(5281+(0x1aa9+4620-0x1d78)-9182);}bool 
ReplacementFor_SocketStream::ReplacementFor_is_writable()const{return 
ReplacementFor_select_write(ReplacementFor_sock_,
ReplacementFor_write_timeout_sec_,ReplacementFor_write_timeout_usec_)>(
(0x1d70+8513-0x214b)+(0xb8b+4431-0x1477)-9673);}ssize_t 
ReplacementFor_SocketStream::read(char*ReplacementFor_ptr,size_t size){if(!
ReplacementFor_is_readable()){return-((0x18a4+1260-0x1a26)+(0x150a+310-0x722)-
(0x2328+5570-0x2663));}
#ifdef _WIN32
if(size>static_cast<size_t>((std::numeric_limits<int>::max)())){return-(
(0x21fb+2868-0x1ea7)+(0x1c77+2775-0x1f02)-(0x1f07+3132-0x1470));}return recv(
ReplacementFor_sock_,ReplacementFor_ptr,static_cast<int>(size),
ReplacementFor_CPPHTTPLIB_RECV_FLAGS);
#else
return ReplacementFor_handle_EINTR([&](){return recv(ReplacementFor_sock_,
ReplacementFor_ptr,size,ReplacementFor_CPPHTTPLIB_RECV_FLAGS);});
#endif
}ssize_t ReplacementFor_SocketStream::write(const char*ReplacementFor_ptr,size_t
 size){if(!ReplacementFor_is_writable()){return-(6563+(0x16bb+1107-0x14eb)-8133)
;}
#ifdef _WIN32
if(size>static_cast<size_t>((std::numeric_limits<int>::max)())){return-(
(0x15d1+2337-0x104c)+(0x1dbd+224-0x1c6d)-(0x1a70+1427-0xf2e));}return send(
ReplacementFor_sock_,ReplacementFor_ptr,static_cast<int>(size),
ReplacementFor_CPPHTTPLIB_SEND_FLAGS);
#else
return ReplacementFor_handle_EINTR([&](){return send(ReplacementFor_sock_,
ReplacementFor_ptr,size,ReplacementFor_CPPHTTPLIB_SEND_FLAGS);});
#endif
}void ReplacementFor_SocketStream::ReplacementFor_get_remote_ip_and_port(std::
string&ReplacementFor_ip,int&ReplacementFor_port)const{return 
ReplacementFor_detail::ReplacementFor_get_remote_ip_and_port(
ReplacementFor_sock_,ReplacementFor_ip,ReplacementFor_port);}
ReplacementFor_socket_t ReplacementFor_SocketStream::socket()const{return 
ReplacementFor_sock_;}bool ReplacementFor_BufferStream::
ReplacementFor_is_readable()const{return true;}bool ReplacementFor_BufferStream
::ReplacementFor_is_writable()const{return true;}ssize_t 
ReplacementFor_BufferStream::read(char*ReplacementFor_ptr,size_t size){
#if defined(_MSC_VER) && _MSC_VER <= ((0xf4c+563-0x29e)+(0x1508+1026-0x1400)-\
(0x1925+1775-0x1395))
auto ReplacementFor_len_read=ReplacementFor_buffer._Copy_s(ReplacementFor_ptr,
size,size,position);
#else
auto ReplacementFor_len_read=ReplacementFor_buffer.copy(ReplacementFor_ptr,size,
position);
#endif
position+=static_cast<size_t>(ReplacementFor_len_read);return static_cast<
ssize_t>(ReplacementFor_len_read);}ssize_t ReplacementFor_BufferStream::write(
const char*ReplacementFor_ptr,size_t size){ReplacementFor_buffer.append(
ReplacementFor_ptr,size);return static_cast<ssize_t>(size);}void 
ReplacementFor_BufferStream::ReplacementFor_get_remote_ip_and_port(std::string&,
int&)const{}ReplacementFor_socket_t ReplacementFor_BufferStream::socket()const{
return((0x1c86+1224-0x1be1)+(0x1ab8+5957-0x19fc)-(0x26e3+359-0xadc));}const std
::string&ReplacementFor_BufferStream::ReplacementFor_get_buffer()const{return 
ReplacementFor_buffer;}}ReplacementFor_Server::ReplacementFor_Server():
ReplacementFor_new_task_queue([]{return new ReplacementFor_ThreadPool(
ReplacementFor_CPPHTTPLIB_THREAD_POOL_COUNT);}),ReplacementFor_svr_sock_(
INVALID_SOCKET),ReplacementFor_is_running_(false){
#ifndef _WIN32
signal(SIGPIPE,SIG_IGN);
#endif
}ReplacementFor_Server::~ReplacementFor_Server(){}ReplacementFor_Server&
ReplacementFor_Server::Get(const char*pattern,ReplacementFor_Handler 
ReplacementFor_handler){return Get(pattern,strlen(pattern),
ReplacementFor_handler);}ReplacementFor_Server&ReplacementFor_Server::Get(const 
char*pattern,size_t ReplacementFor_pattern_len,ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_get_handlers_.push_back(std::make_pair(
std::regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)
));return*this;}ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_Post
(const char*pattern,ReplacementFor_Handler ReplacementFor_handler){return 
ReplacementFor_Post(pattern,strlen(pattern),ReplacementFor_handler);}
ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_Post(const char*
pattern,size_t ReplacementFor_pattern_len,ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_post_handlers_.push_back(std::make_pair(
std::regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)
));return*this;}ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_Post
(const char*pattern,ReplacementFor_HandlerWithContentReader 
ReplacementFor_handler){return ReplacementFor_Post(pattern,strlen(pattern),
ReplacementFor_handler);}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_Post(const char*pattern,size_t ReplacementFor_pattern_len,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler){
ReplacementFor_post_handlers_for_content_reader_.push_back(std::make_pair(std::
regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)));
return*this;}ReplacementFor_Server&ReplacementFor_Server::Put(const char*pattern
,ReplacementFor_Handler ReplacementFor_handler){return Put(pattern,strlen(
pattern),ReplacementFor_handler);}ReplacementFor_Server&ReplacementFor_Server::
Put(const char*pattern,size_t ReplacementFor_pattern_len,ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_put_handlers_.push_back(std::make_pair(
std::regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)
));return*this;}ReplacementFor_Server&ReplacementFor_Server::Put(const char*
pattern,ReplacementFor_HandlerWithContentReader ReplacementFor_handler){return 
Put(pattern,strlen(pattern),ReplacementFor_handler);}ReplacementFor_Server&
ReplacementFor_Server::Put(const char*pattern,size_t ReplacementFor_pattern_len,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler){
ReplacementFor_put_handlers_for_content_reader_.push_back(std::make_pair(std::
regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)));
return*this;}ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_Patch(
const char*pattern,ReplacementFor_Handler ReplacementFor_handler){return 
ReplacementFor_Patch(pattern,strlen(pattern),ReplacementFor_handler);}
ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_Patch(const char*
pattern,size_t ReplacementFor_pattern_len,ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_patch_handlers_.push_back(std::make_pair(
std::regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)
));return*this;}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_Patch(const char*pattern,ReplacementFor_HandlerWithContentReader 
ReplacementFor_handler){return ReplacementFor_Patch(pattern,strlen(pattern),
ReplacementFor_handler);}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_Patch(const char*pattern,size_t ReplacementFor_pattern_len,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler){
ReplacementFor_patch_handlers_for_content_reader_.push_back(std::make_pair(std::
regex(pattern,ReplacementFor_pattern_len),std::move(ReplacementFor_handler)));
return*this;}ReplacementFor_Server&ReplacementFor_Server::Delete(const char*
pattern,ReplacementFor_Handler ReplacementFor_handler){return Delete(pattern,
strlen(pattern),ReplacementFor_handler);}ReplacementFor_Server&
ReplacementFor_Server::Delete(const char*pattern,size_t 
ReplacementFor_pattern_len,ReplacementFor_Handler ReplacementFor_handler){
ReplacementFor_delete_handlers_.push_back(std::make_pair(std::regex(pattern,
ReplacementFor_pattern_len),std::move(ReplacementFor_handler)));return*this;}
ReplacementFor_Server&ReplacementFor_Server::Delete(const char*pattern,
ReplacementFor_HandlerWithContentReader ReplacementFor_handler){return Delete(
pattern,strlen(pattern),ReplacementFor_handler);}ReplacementFor_Server&
ReplacementFor_Server::Delete(const char*pattern,size_t 
ReplacementFor_pattern_len,ReplacementFor_HandlerWithContentReader 
ReplacementFor_handler){ReplacementFor_delete_handlers_for_content_reader_.
push_back(std::make_pair(std::regex(pattern,ReplacementFor_pattern_len),std::
move(ReplacementFor_handler)));return*this;}ReplacementFor_Server&
ReplacementFor_Server::Options(const char*pattern,ReplacementFor_Handler 
ReplacementFor_handler){return Options(pattern,strlen(pattern),
ReplacementFor_handler);}ReplacementFor_Server&ReplacementFor_Server::Options(
const char*pattern,size_t ReplacementFor_pattern_len,ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_options_handlers_.push_back(std::
make_pair(std::regex(pattern,ReplacementFor_pattern_len),std::move(
ReplacementFor_handler)));return*this;}bool ReplacementFor_Server::
ReplacementFor_set_base_dir(const char*ReplacementFor_dir,const char*
ReplacementFor_mount_point){return ReplacementFor_set_mount_point(
ReplacementFor_mount_point,ReplacementFor_dir);}bool ReplacementFor_Server::
ReplacementFor_set_mount_point(const char*ReplacementFor_mount_point,const char*
ReplacementFor_dir,ReplacementFor_Headers ReplacementFor_headers){if(
ReplacementFor_detail::ReplacementFor_is_dir(ReplacementFor_dir)){std::string 
ReplacementFor_mnt=ReplacementFor_mount_point?ReplacementFor_mount_point:"\x2f";
if(!ReplacementFor_mnt.empty()&&ReplacementFor_mnt[((0x12b3+5275-0x224a)+
(0x191f+2114-0x10f9)-(0x1ca8+4096-0x173c))]==((char)((0x1776+7877-0x2083)+
(0x431+6238-0x1c40)-(0x1ae4+7925-0x2401)))){ReplacementFor_base_dirs_.push_back(
{ReplacementFor_mnt,ReplacementFor_dir,std::move(ReplacementFor_headers)});
return true;}}return false;}bool ReplacementFor_Server::
ReplacementFor_remove_mount_point(const char*ReplacementFor_mount_point){for(
auto ReplacementFor_it=ReplacementFor_base_dirs_.begin();ReplacementFor_it!=
ReplacementFor_base_dirs_.end();++ReplacementFor_it){if(ReplacementFor_it->
ReplacementFor_mount_point==ReplacementFor_mount_point){
ReplacementFor_base_dirs_.erase(ReplacementFor_it);return true;}}return false;}
ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_file_extension_and_mimetype_mapping(const char*
ReplacementFor_ext,const char*ReplacementFor_mime){
ReplacementFor_file_extension_and_mimetype_map_[ReplacementFor_ext]=
ReplacementFor_mime;return*this;}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_file_request_handler(ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_file_request_handler_=std::move(
ReplacementFor_handler);return*this;}ReplacementFor_Server&ReplacementFor_Server
::ReplacementFor_set_error_handler(ReplacementFor_HandlerWithResponse 
ReplacementFor_handler){ReplacementFor_error_handler_=std::move(
ReplacementFor_handler);return*this;}ReplacementFor_Server&ReplacementFor_Server
::ReplacementFor_set_error_handler(ReplacementFor_Handler ReplacementFor_handler
){ReplacementFor_error_handler_=[ReplacementFor_handler](const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res){ReplacementFor_handler(ReplacementFor_req,ReplacementFor_res
);return ReplacementFor_HandlerResponse::ReplacementFor_Handled;};return*this;}
ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_exception_handler(ExceptionHandler ReplacementFor_handler){
ReplacementFor_exception_handler_=std::move(ReplacementFor_handler);return*this;
}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_pre_routing_handler(ReplacementFor_HandlerWithResponse 
ReplacementFor_handler){ReplacementFor_pre_routing_handler_=std::move(
ReplacementFor_handler);return*this;}ReplacementFor_Server&ReplacementFor_Server
::ReplacementFor_set_post_routing_handler(ReplacementFor_Handler 
ReplacementFor_handler){ReplacementFor_post_routing_handler_=std::move(
ReplacementFor_handler);return*this;}ReplacementFor_Server&ReplacementFor_Server
::ReplacementFor_set_logger(ReplacementFor_Logger ReplacementFor_logger){
ReplacementFor_logger_=std::move(ReplacementFor_logger);return*this;}
ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_expect_100_continue_handler(
ReplacementFor_Expect100ContinueHandler ReplacementFor_handler){
ReplacementFor_expect_100_continue_handler_=std::move(ReplacementFor_handler);
return*this;}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_tcp_nodelay(bool ReplacementFor_on){
ReplacementFor_tcp_nodelay_=ReplacementFor_on;return*this;}ReplacementFor_Server
&ReplacementFor_Server::ReplacementFor_set_socket_options(
ReplacementFor_SocketOptions ReplacementFor_socket_options){
ReplacementFor_socket_options_=std::move(ReplacementFor_socket_options);return*
this;}ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_keep_alive_max_count(size_t count){
ReplacementFor_keep_alive_max_count_=count;return*this;}ReplacementFor_Server&
ReplacementFor_Server::ReplacementFor_set_keep_alive_timeout(time_t sec){
ReplacementFor_keep_alive_timeout_sec_=sec;return*this;}ReplacementFor_Server&
ReplacementFor_Server::ReplacementFor_set_read_timeout(time_t sec,time_t 
ReplacementFor_usec){ReplacementFor_read_timeout_sec_=sec;
ReplacementFor_read_timeout_usec_=ReplacementFor_usec;return*this;}
ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_set_write_timeout(
time_t sec,time_t ReplacementFor_usec){ReplacementFor_write_timeout_sec_=sec;
ReplacementFor_write_timeout_usec_=ReplacementFor_usec;return*this;}
ReplacementFor_Server&ReplacementFor_Server::ReplacementFor_set_idle_interval(
time_t sec,time_t ReplacementFor_usec){ReplacementFor_idle_interval_sec_=sec;
ReplacementFor_idle_interval_usec_=ReplacementFor_usec;return*this;}
ReplacementFor_Server&ReplacementFor_Server::
ReplacementFor_set_payload_max_length(size_t length){
ReplacementFor_payload_max_length_=length;return*this;}bool 
ReplacementFor_Server::ReplacementFor_bind_to_port(const char*
ReplacementFor_host,int ReplacementFor_port,int ReplacementFor_socket_flags){if(
ReplacementFor_bind_internal(ReplacementFor_host,ReplacementFor_port,
ReplacementFor_socket_flags)<(5672+(0x1132+4238-0x1c70)-(0x1beb+3087-0xc82)))
return false;return true;}int ReplacementFor_Server::
ReplacementFor_bind_to_any_port(const char*ReplacementFor_host,int 
ReplacementFor_socket_flags){return ReplacementFor_bind_internal(
ReplacementFor_host,((0x249f+4509-0x20cc)+(0x3d2+1614-0xa14)-
(0x1d0a+7858-0x2640)),ReplacementFor_socket_flags);}bool ReplacementFor_Server::
ReplacementFor_listen_after_bind(){return ReplacementFor_listen_internal();}bool
 ReplacementFor_Server::listen(const char*ReplacementFor_host,int 
ReplacementFor_port,int ReplacementFor_socket_flags){return 
ReplacementFor_bind_to_port(ReplacementFor_host,ReplacementFor_port,
ReplacementFor_socket_flags)&&ReplacementFor_listen_internal();}bool 
ReplacementFor_Server::ReplacementFor_is_running()const{return 
ReplacementFor_is_running_;}void ReplacementFor_Server::ReplacementFor_stop(){if
(ReplacementFor_is_running_){assert(ReplacementFor_svr_sock_!=INVALID_SOCKET);
std::atomic<ReplacementFor_socket_t>ReplacementFor_sock(ReplacementFor_svr_sock_
.exchange(INVALID_SOCKET));ReplacementFor_detail::ReplacementFor_shutdown_socket
(ReplacementFor_sock);ReplacementFor_detail::ReplacementFor_close_socket(
ReplacementFor_sock);}}bool ReplacementFor_Server::
ReplacementFor_parse_request_line(const char*s,ReplacementFor_Request&
ReplacementFor_req){const static std::regex ReplacementFor_re(
"\x28\x47\x45\x54\x7c\x48\x45\x41\x44\x7c\x50\x4f\x53\x54\x7c\x50\x55\x54\x7c\x44\x45\x4c\x45\x54\x45\x7c\x43\x4f\x4e\x4e\x45\x43\x54\x7c\x4f\x50\x54\x49\x4f\x4e\x53\x7c\x54\x52\x41\x43\x45\x7c\x50\x41\x54\x43\x48\x7c\x50\x52\x49\x29\x20"
"\x28\x28\x5b\x5e\x3f\x20\x5d\x2b\x29\x28\x3f\x3a""\\"
"\x3f\x28\x5b\x5e\x20\x5d\x2a\x3f\x29\x29\x3f\x29\x20\x28\x48\x54\x54\x50\x2f\x31"
"\\""\x2e\x5b\x30\x31\x5d\x29""\r\n");std::cmatch m;if(std::regex_match(s,m,
ReplacementFor_re)){ReplacementFor_req.ReplacementFor_version=std::string(m[(
(0x1ec4+2890-0x1eef)+(0x16fc+1095-0x115a)-(0x1d28+1765-0xf0a))]);
ReplacementFor_req.ReplacementFor_method=std::string(m[((0x198a+3586-0x19e5)+
(0xd59+4308-0x1db9)-(0x107c+2260-0xb36))]);ReplacementFor_req.target=std::string
(m[((0x2d2+6160-0x1972)+(0x2079+3784-0x1424)-(0x250c+2770-0x1353))]);
ReplacementFor_req.ReplacementFor_path=ReplacementFor_detail::
ReplacementFor_decode_url(m[((0x20db+5178-0x15cb)+(0x15fd+2225-0x1bee)-8711)],
false);auto len=std::distance(m[((0xa45+1598-0x8bb)+4799-6787)].first,m[(5912+
(0x16f4+5619-0x256b)-7824)].second);if(len>((0x2077+2352-0x1ce4)+
(0x2613+127-0xeec)-9321)){ReplacementFor_detail::ReplacementFor_parse_query_text
(m[((0x1f3d+225-0x1dbc)+(0x249a+467-0x1ea1)-(0x1621+1278-0x10f5))],
ReplacementFor_req.ReplacementFor_params);}return true;}return false;}bool 
ReplacementFor_Server::ReplacementFor_write_response(ReplacementFor_Stream&
ReplacementFor_strm,bool ReplacementFor_close_connection,const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res){return ReplacementFor_write_response_core(
ReplacementFor_strm,ReplacementFor_close_connection,ReplacementFor_req,
ReplacementFor_res,false);}bool ReplacementFor_Server::
ReplacementFor_write_response_with_content(ReplacementFor_Stream&
ReplacementFor_strm,bool ReplacementFor_close_connection,const 
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res){return ReplacementFor_write_response_core(
ReplacementFor_strm,ReplacementFor_close_connection,ReplacementFor_req,
ReplacementFor_res,true);}bool ReplacementFor_Server::
ReplacementFor_write_response_core(ReplacementFor_Stream&ReplacementFor_strm,
bool ReplacementFor_close_connection,const ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res,bool 
ReplacementFor_need_apply_ranges){assert(ReplacementFor_res.status!=-(
(0x2338+2466-0x1978)+(0x1540+3359-0x1ba6)-6682));if((6615+(0x12e6+2898-0x14ec)-
8595)<=ReplacementFor_res.status&&ReplacementFor_error_handler_&&
ReplacementFor_error_handler_(ReplacementFor_req,ReplacementFor_res)==
ReplacementFor_HandlerResponse::ReplacementFor_Handled){
ReplacementFor_need_apply_ranges=true;}std::string ReplacementFor_content_type;
std::string ReplacementFor_boundary;if(ReplacementFor_need_apply_ranges){
ReplacementFor_apply_ranges(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_content_type,ReplacementFor_boundary);}if(
ReplacementFor_close_connection||ReplacementFor_req.
ReplacementFor_get_header_value("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")==
"\x63\x6c\x6f\x73\x65"){ReplacementFor_res.ReplacementFor_set_header(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e","\x63\x6c\x6f\x73\x65");}else{std::
stringstream ReplacementFor_ss;ReplacementFor_ss<<
"\x74\x69\x6d\x65\x6f\x75\x74\x3d"<<ReplacementFor_keep_alive_timeout_sec_<<
"\x2c\x20\x6d\x61\x78\x3d"<<ReplacementFor_keep_alive_max_count_;
ReplacementFor_res.ReplacementFor_set_header(
"\x4b\x65\x65\x70\x2d\x41\x6c\x69\x76\x65",ReplacementFor_ss.str());}if(!
ReplacementFor_res.ReplacementFor_has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65")&&(!ReplacementFor_res.
ReplacementFor_body.empty()||ReplacementFor_res.ReplacementFor_content_length_>(
4519+(0x1010+2349-0xe11)-(0x2449+5869-0x1e63))||ReplacementFor_res.
ReplacementFor_content_provider_)){ReplacementFor_res.ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e");}if(!ReplacementFor_res.
ReplacementFor_has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")&&ReplacementFor_res.
ReplacementFor_body.empty()&&!ReplacementFor_res.ReplacementFor_content_length_
&&!ReplacementFor_res.ReplacementFor_content_provider_){ReplacementFor_res.
ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68","\x30");}if(!
ReplacementFor_res.ReplacementFor_has_header(
"\x41\x63\x63\x65\x70\x74\x2d\x52\x61\x6e\x67\x65\x73")&&ReplacementFor_req.
ReplacementFor_method=="\x48\x45\x41\x44"){ReplacementFor_res.
ReplacementFor_set_header("\x41\x63\x63\x65\x70\x74\x2d\x52\x61\x6e\x67\x65\x73"
,"\x62\x79\x74\x65\x73");}if(ReplacementFor_post_routing_handler_){
ReplacementFor_post_routing_handler_(ReplacementFor_req,ReplacementFor_res);}{
ReplacementFor_detail::ReplacementFor_BufferStream ReplacementFor_bstrm;if(!
ReplacementFor_bstrm.ReplacementFor_write_format(
"\x48\x54\x54\x50\x2f\x31\x2e\x31\x20\x25\x64\x20\x25\x73""\r\n",
ReplacementFor_res.status,ReplacementFor_detail::ReplacementFor_status_message(
ReplacementFor_res.status))){return false;}if(!ReplacementFor_detail::
ReplacementFor_write_headers(ReplacementFor_bstrm,ReplacementFor_res.
ReplacementFor_headers)){return false;}auto&data=ReplacementFor_bstrm.
ReplacementFor_get_buffer();ReplacementFor_strm.write(data.data(),data.size());}
auto ReplacementFor_ret=true;if(ReplacementFor_req.ReplacementFor_method!=
"\x48\x45\x41\x44"){if(!ReplacementFor_res.ReplacementFor_body.empty()){if(!
ReplacementFor_strm.write(ReplacementFor_res.ReplacementFor_body)){
ReplacementFor_ret=false;}}else if(ReplacementFor_res.
ReplacementFor_content_provider_){if(!ReplacementFor_write_content_with_provider
(ReplacementFor_strm,ReplacementFor_req,ReplacementFor_res,
ReplacementFor_boundary,ReplacementFor_content_type)){ReplacementFor_ret=false;}
}}if(ReplacementFor_logger_){ReplacementFor_logger_(ReplacementFor_req,
ReplacementFor_res);}return ReplacementFor_ret;}bool ReplacementFor_Server::
ReplacementFor_write_content_with_provider(ReplacementFor_Stream&
ReplacementFor_strm,const ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,const std::string&
ReplacementFor_boundary,const std::string&ReplacementFor_content_type){auto 
ReplacementFor_is_shutting_down=[this](){return this->ReplacementFor_svr_sock_==
INVALID_SOCKET;};if(ReplacementFor_res.ReplacementFor_content_length_>(
(0x26eb+6495-0x26fb)+(0xa82+4609-0x1bb3)-6687)){if(ReplacementFor_req.ranges.
empty()){return ReplacementFor_detail::ReplacementFor_write_content(
ReplacementFor_strm,ReplacementFor_res.ReplacementFor_content_provider_,(
(0x1469+4762-0x143a)+(0x1d3c+398-0xddc)-9143),ReplacementFor_res.
ReplacementFor_content_length_,ReplacementFor_is_shutting_down);}else if(
ReplacementFor_req.ranges.size()==(5863+(0x1fd2+1852-0x1cdf)-8469)){auto 
ReplacementFor_offsets=ReplacementFor_detail::
ReplacementFor_get_range_offset_and_length(ReplacementFor_req,ReplacementFor_res
.ReplacementFor_content_length_,((0x1ba8+1567-0x218e)+9343-9400));auto offset=
ReplacementFor_offsets.first;auto length=ReplacementFor_offsets.second;return 
ReplacementFor_detail::ReplacementFor_write_content(ReplacementFor_strm,
ReplacementFor_res.ReplacementFor_content_provider_,offset,length,
ReplacementFor_is_shutting_down);}else{return ReplacementFor_detail::
ReplacementFor_write_multipart_ranges_data(ReplacementFor_strm,
ReplacementFor_req,ReplacementFor_res,ReplacementFor_boundary,
ReplacementFor_content_type,ReplacementFor_is_shutting_down);}}else{if(
ReplacementFor_res.ReplacementFor_is_chunked_content_provider_){auto type=
ReplacementFor_detail::ReplacementFor_encoding_type(ReplacementFor_req,
ReplacementFor_res);std::unique_ptr<ReplacementFor_detail::
ReplacementFor_compressor>ReplacementFor_compressor;if(type==
ReplacementFor_detail::ReplacementFor_EncodingType::ReplacementFor_Gzip){
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_gzip_compressor>();
#endif
}else if(type==ReplacementFor_detail::ReplacementFor_EncodingType::
ReplacementFor_Brotli){
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_brotli_compressor>();
#endif
}else{ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_nocompressor>();}assert(
ReplacementFor_compressor!=nullptr);return ReplacementFor_detail::
ReplacementFor_write_content_chunked(ReplacementFor_strm,ReplacementFor_res.
ReplacementFor_content_provider_,ReplacementFor_is_shutting_down,*
ReplacementFor_compressor);}else{return ReplacementFor_detail::
ReplacementFor_write_content_without_length(ReplacementFor_strm,
ReplacementFor_res.ReplacementFor_content_provider_,
ReplacementFor_is_shutting_down);}}}bool ReplacementFor_Server::
ReplacementFor_read_content(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res){ReplacementFor_MultipartFormDataMap::iterator cur;if(
ReplacementFor_read_content_core(ReplacementFor_strm,ReplacementFor_req,
ReplacementFor_res,[&](const char*buf,size_t n){if(ReplacementFor_req.
ReplacementFor_body.size()+n>ReplacementFor_req.ReplacementFor_body.max_size()){
return false;}ReplacementFor_req.ReplacementFor_body.append(buf,n);return true;}
,[&](const ReplacementFor_MultipartFormData&ReplacementFor_file){cur=
ReplacementFor_req.ReplacementFor_files.emplace(ReplacementFor_file.name,
ReplacementFor_file);return true;},[&](const char*buf,size_t n){auto&
ReplacementFor_content=cur->second.ReplacementFor_content;if(
ReplacementFor_content.size()+n>ReplacementFor_content.max_size()){return false;
}ReplacementFor_content.append(buf,n);return true;})){const auto&
ReplacementFor_content_type=ReplacementFor_req.ReplacementFor_get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");if(!
ReplacementFor_content_type.find(
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
)){ReplacementFor_detail::ReplacementFor_parse_query_text(ReplacementFor_req.
ReplacementFor_body,ReplacementFor_req.ReplacementFor_params);}return true;}
return false;}bool ReplacementFor_Server::
ReplacementFor_read_content_with_content_receiver(ReplacementFor_Stream&
ReplacementFor_strm,ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,ReplacementFor_ContentReceiver 
ReplacementFor_receiver,ReplacementFor_MultipartContentHeader 
ReplacementFor_multipart_header,ReplacementFor_ContentReceiver 
ReplacementFor_multipart_receiver){return ReplacementFor_read_content_core(
ReplacementFor_strm,ReplacementFor_req,ReplacementFor_res,std::move(
ReplacementFor_receiver),std::move(ReplacementFor_multipart_header),std::move(
ReplacementFor_multipart_receiver));}bool ReplacementFor_Server::
ReplacementFor_read_content_core(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,ReplacementFor_ContentReceiver ReplacementFor_receiver,
ReplacementFor_MultipartContentHeader ReplacementFor_mulitpart_header,
ReplacementFor_ContentReceiver ReplacementFor_multipart_receiver){
ReplacementFor_detail::ReplacementFor_MultipartFormDataParser 
ReplacementFor_multipart_form_data_parser;
ReplacementFor_ContentReceiverWithProgress out;if(ReplacementFor_req.
ReplacementFor_is_multipart_form_data()){const auto&ReplacementFor_content_type=
ReplacementFor_req.ReplacementFor_get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");std::string 
ReplacementFor_boundary;if(!ReplacementFor_detail::
ReplacementFor_parse_multipart_boundary(ReplacementFor_content_type,
ReplacementFor_boundary)){ReplacementFor_res.status=((0x16a3+5161-0x2516)+
(0x1990+2646-0x1c36)-(0x1029+8220-0x246f));return false;}
ReplacementFor_multipart_form_data_parser.ReplacementFor_set_boundary(std::move(
ReplacementFor_boundary));out=[&](const char*buf,size_t n,uint64_t,uint64_t){
return ReplacementFor_multipart_form_data_parser.ReplacementFor_parse(buf,n,
ReplacementFor_multipart_receiver,ReplacementFor_mulitpart_header);};}else{out=[
ReplacementFor_receiver](const char*buf,size_t n,uint64_t,uint64_t){return 
ReplacementFor_receiver(buf,n);};}if(ReplacementFor_req.ReplacementFor_method==
"\x44\x45\x4c\x45\x54\x45"&&!ReplacementFor_req.ReplacementFor_has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){return true;}if(!
ReplacementFor_detail::ReplacementFor_read_content(ReplacementFor_strm,
ReplacementFor_req,ReplacementFor_payload_max_length_,ReplacementFor_res.status,
nullptr,out,true)){return false;}if(ReplacementFor_req.
ReplacementFor_is_multipart_form_data()){if(!
ReplacementFor_multipart_form_data_parser.ReplacementFor_is_valid()){
ReplacementFor_res.status=((0x1e2c+4422-0x2175)+(0x1d67+5677-0x1d7c)-8837);
return false;}}return true;}bool ReplacementFor_Server::
ReplacementFor_handle_file_request(const ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res,bool 
ReplacementFor_head){for(const auto&entry:ReplacementFor_base_dirs_){if(!
ReplacementFor_req.ReplacementFor_path.compare(((0x1805+156-0x10ec)+
(0x13ea+6630-0x1f2e)-(0x1c75+1693-0xcbb)),entry.ReplacementFor_mount_point.size(
),entry.ReplacementFor_mount_point)){std::string ReplacementFor_sub_path="\x2f"+
ReplacementFor_req.ReplacementFor_path.substr(entry.ReplacementFor_mount_point.
size());if(ReplacementFor_detail::ReplacementFor_is_valid_path(
ReplacementFor_sub_path)){auto ReplacementFor_path=entry.ReplacementFor_base_dir
+ReplacementFor_sub_path;if(ReplacementFor_path.back()==((char)(
(0x24cd+772-0x2480)+(0x1208+2959-0x1845)-(0x1191+7111-0x24e4)))){
ReplacementFor_path+="\x69\x6e\x64\x65\x78\x2e\x68\x74\x6d\x6c";}if(
ReplacementFor_detail::ReplacementFor_is_file(ReplacementFor_path)){
ReplacementFor_detail::ReplacementFor_read_file(ReplacementFor_path,
ReplacementFor_res.ReplacementFor_body);auto type=ReplacementFor_detail::
ReplacementFor_find_content_type(ReplacementFor_path,
ReplacementFor_file_extension_and_mimetype_map_);if(type){ReplacementFor_res.
ReplacementFor_set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
type);}for(const auto&ReplacementFor_kv:entry.ReplacementFor_headers){
ReplacementFor_res.ReplacementFor_set_header(ReplacementFor_kv.first.c_str(),
ReplacementFor_kv.second);}ReplacementFor_res.status=ReplacementFor_req.
ReplacementFor_has_header("\x52\x61\x6e\x67\x65")?((0x1697+3924-0x1f5b)+
(0x118f+6163-0x1f99)-(0x236d+1362-0x18f4)):(9050+(0xb86+4359-0x1aa9)-9334);if(!
ReplacementFor_head&&ReplacementFor_file_request_handler_){
ReplacementFor_file_request_handler_(ReplacementFor_req,ReplacementFor_res);}
return true;}}}}return false;}ReplacementFor_socket_t ReplacementFor_Server::
ReplacementFor_create_server_socket(const char*ReplacementFor_host,int 
ReplacementFor_port,int ReplacementFor_socket_flags,ReplacementFor_SocketOptions
 ReplacementFor_socket_options)const{return ReplacementFor_detail::
ReplacementFor_create_socket(ReplacementFor_host,ReplacementFor_port,
ReplacementFor_socket_flags,ReplacementFor_tcp_nodelay_,std::move(
ReplacementFor_socket_options),[](ReplacementFor_socket_t ReplacementFor_sock,
struct addrinfo&ReplacementFor_ai)->bool{if(::bind(ReplacementFor_sock,
ReplacementFor_ai.ai_addr,static_cast<socklen_t>(ReplacementFor_ai.ai_addrlen)))
{return false;}if(::listen(ReplacementFor_sock,((0x17f3+517-0x1936)+
(0x1506+2796-0xc2d)-(0x1600+6256-0x19ee)))){return false;}return true;});}int 
ReplacementFor_Server::ReplacementFor_bind_internal(const char*
ReplacementFor_host,int ReplacementFor_port,int ReplacementFor_socket_flags){if(
!ReplacementFor_is_valid()){return-((0x1c65+2810-0x19dd)+(0x988+4379-0x11d3)-
(0x1707+2977-0xc57));}ReplacementFor_svr_sock_=
ReplacementFor_create_server_socket(ReplacementFor_host,ReplacementFor_port,
ReplacementFor_socket_flags,ReplacementFor_socket_options_);if(
ReplacementFor_svr_sock_==INVALID_SOCKET){return-(7437+(0x25d3+595-0x258e)-
(0x221c+3491-0x101b));}if(ReplacementFor_port==((0x4a5+2122-0x93e)+
(0x1717+4945-0x2227)-(0x1ada+6155-0x26f3))){struct sockaddr_storage addr;
socklen_t ReplacementFor_addr_len=sizeof(addr);if(getsockname(
ReplacementFor_svr_sock_,reinterpret_cast<struct sockaddr*>(&addr),&
ReplacementFor_addr_len)==-((0xe92+4486-0x1bc1)+8783-9893)){return-(4977+
(0x109c+1004-0x70c)-(0x2100+2423-0x98b));}if(addr.ss_family==AF_INET){return 
ntohs(reinterpret_cast<struct sockaddr_in*>(&addr)->sin_port);}else if(addr.
ss_family==AF_INET6){return ntohs(reinterpret_cast<struct sockaddr_in6*>(&addr)
->sin6_port);}else{return-((0x15f5+1627-0xedd)+(0x18e0+4835-0x2597)-5022);}}else
{return ReplacementFor_port;}}bool ReplacementFor_Server::
ReplacementFor_listen_internal(){auto ReplacementFor_ret=true;
ReplacementFor_is_running_=true;{std::unique_ptr<ReplacementFor_TaskQueue>
ReplacementFor_task_queue(ReplacementFor_new_task_queue());while(
ReplacementFor_svr_sock_!=INVALID_SOCKET){
#ifndef _WIN32
if(ReplacementFor_idle_interval_sec_>((0xe26+6727-0x26b4)+4996-
(0x21ca+1132-0x10f9))||ReplacementFor_idle_interval_usec_>((0x19c4+607-0x1921)+
(0x22f4+2190-0x1523)-6497)){
#endif
auto val=ReplacementFor_detail::ReplacementFor_select_read(
ReplacementFor_svr_sock_,ReplacementFor_idle_interval_sec_,
ReplacementFor_idle_interval_usec_);if(val==((0x10b3+5007-0x1573)+
(0x1166+8367-0x2326)-7614)){ReplacementFor_task_queue->ReplacementFor_on_idle();
continue;}
#ifndef _WIN32
}
#endif
ReplacementFor_socket_t ReplacementFor_sock=accept(ReplacementFor_svr_sock_,
nullptr,nullptr);if(ReplacementFor_sock==INVALID_SOCKET){if(errno==EMFILE){std::
this_thread::sleep_for(std::chrono::milliseconds(((0xbb2+5462-0x1c12)+7307-
(0x2236+7451-0x1dd1))));continue;}if(ReplacementFor_svr_sock_!=INVALID_SOCKET){
ReplacementFor_detail::ReplacementFor_close_socket(ReplacementFor_svr_sock_);
ReplacementFor_ret=false;}else{;}break;}
#if __cplusplus > 201703L
ReplacementFor_task_queue->ReplacementFor_enqueue([=,this](){
ReplacementFor_process_and_close_socket(ReplacementFor_sock);});
#else
ReplacementFor_task_queue->ReplacementFor_enqueue([=](){
ReplacementFor_process_and_close_socket(ReplacementFor_sock);});
#endif
}ReplacementFor_task_queue->shutdown();}ReplacementFor_is_running_=false;return 
ReplacementFor_ret;}bool ReplacementFor_Server::ReplacementFor_routing(
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,ReplacementFor_Stream&ReplacementFor_strm){if(
ReplacementFor_pre_routing_handler_&&ReplacementFor_pre_routing_handler_(
ReplacementFor_req,ReplacementFor_res)==ReplacementFor_HandlerResponse::
ReplacementFor_Handled){return true;}bool ReplacementFor_is_head_request=
ReplacementFor_req.ReplacementFor_method=="\x48\x45\x41\x44";if((
ReplacementFor_req.ReplacementFor_method=="\x47\x45\x54"||
ReplacementFor_is_head_request)&&ReplacementFor_handle_file_request(
ReplacementFor_req,ReplacementFor_res,ReplacementFor_is_head_request)){return 
true;}if(ReplacementFor_detail::ReplacementFor_expect_content(ReplacementFor_req
)){{ReplacementFor_ContentReader ReplacementFor_reader([&](
ReplacementFor_ContentReceiver ReplacementFor_receiver){return 
ReplacementFor_read_content_with_content_receiver(ReplacementFor_strm,
ReplacementFor_req,ReplacementFor_res,std::move(ReplacementFor_receiver),nullptr
,nullptr);},[&](ReplacementFor_MultipartContentHeader header,
ReplacementFor_ContentReceiver ReplacementFor_receiver){return 
ReplacementFor_read_content_with_content_receiver(ReplacementFor_strm,
ReplacementFor_req,ReplacementFor_res,nullptr,std::move(header),std::move(
ReplacementFor_receiver));});if(ReplacementFor_req.ReplacementFor_method==
"\x50\x4f\x53\x54"){if(ReplacementFor_dispatch_request_for_content_reader(
ReplacementFor_req,ReplacementFor_res,std::move(ReplacementFor_reader),
ReplacementFor_post_handlers_for_content_reader_)){return true;}}else if(
ReplacementFor_req.ReplacementFor_method=="\x50\x55\x54"){if(
ReplacementFor_dispatch_request_for_content_reader(ReplacementFor_req,
ReplacementFor_res,std::move(ReplacementFor_reader),
ReplacementFor_put_handlers_for_content_reader_)){return true;}}else if(
ReplacementFor_req.ReplacementFor_method=="\x50\x41\x54\x43\x48"){if(
ReplacementFor_dispatch_request_for_content_reader(ReplacementFor_req,
ReplacementFor_res,std::move(ReplacementFor_reader),
ReplacementFor_patch_handlers_for_content_reader_)){return true;}}else if(
ReplacementFor_req.ReplacementFor_method=="\x44\x45\x4c\x45\x54\x45"){if(
ReplacementFor_dispatch_request_for_content_reader(ReplacementFor_req,
ReplacementFor_res,std::move(ReplacementFor_reader),
ReplacementFor_delete_handlers_for_content_reader_)){return true;}}}if(!
ReplacementFor_read_content(ReplacementFor_strm,ReplacementFor_req,
ReplacementFor_res)){return false;}}if(ReplacementFor_req.ReplacementFor_method
=="\x47\x45\x54"||ReplacementFor_req.ReplacementFor_method=="\x48\x45\x41\x44"){
return ReplacementFor_dispatch_request(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_get_handlers_);}else if(ReplacementFor_req.ReplacementFor_method
=="\x50\x4f\x53\x54"){return ReplacementFor_dispatch_request(ReplacementFor_req,
ReplacementFor_res,ReplacementFor_post_handlers_);}else if(ReplacementFor_req.
ReplacementFor_method=="\x50\x55\x54"){return ReplacementFor_dispatch_request(
ReplacementFor_req,ReplacementFor_res,ReplacementFor_put_handlers_);}else if(
ReplacementFor_req.ReplacementFor_method=="\x44\x45\x4c\x45\x54\x45"){return 
ReplacementFor_dispatch_request(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_delete_handlers_);}else if(ReplacementFor_req.
ReplacementFor_method=="\x4f\x50\x54\x49\x4f\x4e\x53"){return 
ReplacementFor_dispatch_request(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_options_handlers_);}else if(ReplacementFor_req.
ReplacementFor_method=="\x50\x41\x54\x43\x48"){return 
ReplacementFor_dispatch_request(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_patch_handlers_);}ReplacementFor_res.status=(6299+
(0x1326+446-0x8b6)-9017);return false;}bool ReplacementFor_Server::
ReplacementFor_dispatch_request(ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,const ReplacementFor_Handlers&
ReplacementFor_handlers){for(const auto&x:ReplacementFor_handlers){const auto&
pattern=x.first;const auto&ReplacementFor_handler=x.second;if(std::regex_match(
ReplacementFor_req.ReplacementFor_path,ReplacementFor_req.ReplacementFor_matches
,pattern)){ReplacementFor_handler(ReplacementFor_req,ReplacementFor_res);return 
true;}}return false;}void ReplacementFor_Server::ReplacementFor_apply_ranges(
const ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,std::string&ReplacementFor_content_type,std::string&
ReplacementFor_boundary){if(ReplacementFor_req.ranges.size()>(
(0x696+8088-0x2295)+5968-(0x1cb9+5609-0x17ba))){ReplacementFor_boundary=
ReplacementFor_detail::ReplacementFor_make_multipart_data_boundary();auto 
ReplacementFor_it=ReplacementFor_res.ReplacementFor_headers.find(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");if(ReplacementFor_it!=
ReplacementFor_res.ReplacementFor_headers.end()){ReplacementFor_content_type=
ReplacementFor_it->second;ReplacementFor_res.ReplacementFor_headers.erase(
ReplacementFor_it);}ReplacementFor_res.ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x62\x79\x74\x65\x72\x61\x6e\x67\x65\x73\x3b\x20\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d"
+ReplacementFor_boundary);}auto type=ReplacementFor_detail::
ReplacementFor_encoding_type(ReplacementFor_req,ReplacementFor_res);if(
ReplacementFor_res.ReplacementFor_body.empty()){if(ReplacementFor_res.
ReplacementFor_content_length_>(2626+(0x837+7248-0x212f)-3482)){size_t length=(
(0x605+6441-0x1cbc)+(0x18a6+1927-0x1039)-(0x1c7a+6477-0x2361));if(
ReplacementFor_req.ranges.empty()){length=ReplacementFor_res.
ReplacementFor_content_length_;}else if(ReplacementFor_req.ranges.size()==(
(0x9c5+8133-0x2002)+(0xc76+1071-0xf81)-(0x154b+313-0xbd9))){auto 
ReplacementFor_offsets=ReplacementFor_detail::
ReplacementFor_get_range_offset_and_length(ReplacementFor_req,ReplacementFor_res
.ReplacementFor_content_length_,((0xaed+7318-0x1cb3)+(0x7f1+7792-0x23c5)-
(0xd75+8734-0x2227)));auto offset=ReplacementFor_offsets.first;length=
ReplacementFor_offsets.second;auto ReplacementFor_content_range=
ReplacementFor_detail::ReplacementFor_make_content_range_header_field(offset,
length,ReplacementFor_res.ReplacementFor_content_length_);ReplacementFor_res.
ReplacementFor_set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65"
,ReplacementFor_content_range);}else{length=ReplacementFor_detail::
ReplacementFor_get_multipart_ranges_data_length(ReplacementFor_req,
ReplacementFor_res,ReplacementFor_boundary,ReplacementFor_content_type);}
ReplacementFor_res.ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",std::to_string(length
));}else{if(ReplacementFor_res.ReplacementFor_content_provider_){if(
ReplacementFor_res.ReplacementFor_is_chunked_content_provider_){
ReplacementFor_res.ReplacementFor_set_header(
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x63\x68\x75\x6e\x6b\x65\x64");if(type==ReplacementFor_detail::
ReplacementFor_EncodingType::ReplacementFor_Gzip){ReplacementFor_res.
ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x67\x7a\x69\x70");}else if(type==ReplacementFor_detail::
ReplacementFor_EncodingType::ReplacementFor_Brotli){ReplacementFor_res.
ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67","\x62\x72");}
}}}}else{if(ReplacementFor_req.ranges.empty()){;}else if(ReplacementFor_req.
ranges.size()==((0xdff+5101-0x1c57)+(0x2409+5368-0x20ea)-7595)){auto 
ReplacementFor_offsets=ReplacementFor_detail::
ReplacementFor_get_range_offset_and_length(ReplacementFor_req,ReplacementFor_res
.ReplacementFor_body.size(),(3269+(0x9b2+3517-0x110e)-(0x1561+6272-0x1abb)));
auto offset=ReplacementFor_offsets.first;auto length=ReplacementFor_offsets.
second;auto ReplacementFor_content_range=ReplacementFor_detail::
ReplacementFor_make_content_range_header_field(offset,length,ReplacementFor_res.
ReplacementFor_body.size());ReplacementFor_res.ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65",
ReplacementFor_content_range);if(offset<ReplacementFor_res.ReplacementFor_body.
size()){ReplacementFor_res.ReplacementFor_body=ReplacementFor_res.
ReplacementFor_body.substr(offset,length);}else{ReplacementFor_res.
ReplacementFor_body.clear();ReplacementFor_res.status=(5899+(0x1b62+558-0x13d6)-
(0x22b8+514-0x595));}}else{std::string data;if(ReplacementFor_detail::
ReplacementFor_make_multipart_ranges_data(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_boundary,ReplacementFor_content_type,data)){ReplacementFor_res.
ReplacementFor_body.swap(data);}else{ReplacementFor_res.ReplacementFor_body.
clear();ReplacementFor_res.status=((0x1290+447-0xfac)+(0x25b7+5-0xb17)-7592);}}
if(type!=ReplacementFor_detail::ReplacementFor_EncodingType::None){std::
unique_ptr<ReplacementFor_detail::ReplacementFor_compressor>
ReplacementFor_compressor;std::string ReplacementFor_content_encoding;if(type==
ReplacementFor_detail::ReplacementFor_EncodingType::ReplacementFor_Gzip){
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_gzip_compressor>();
ReplacementFor_content_encoding="\x67\x7a\x69\x70";
#endif
}else if(type==ReplacementFor_detail::ReplacementFor_EncodingType::
ReplacementFor_Brotli){
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_brotli_compressor>();
ReplacementFor_content_encoding="\x62\x72";
#endif
}if(ReplacementFor_compressor){std::string ReplacementFor_compressed;if(
ReplacementFor_compressor->compress(ReplacementFor_res.ReplacementFor_body.data(
),ReplacementFor_res.ReplacementFor_body.size(),true,[&](const char*data,size_t 
ReplacementFor_data_len){ReplacementFor_compressed.append(data,
ReplacementFor_data_len);return true;})){ReplacementFor_res.ReplacementFor_body.
swap(ReplacementFor_compressed);ReplacementFor_res.ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
ReplacementFor_content_encoding);}}}auto length=std::to_string(
ReplacementFor_res.ReplacementFor_body.size());ReplacementFor_res.
ReplacementFor_set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}bool 
ReplacementFor_Server::ReplacementFor_dispatch_request_for_content_reader(
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,ReplacementFor_ContentReader ReplacementFor_content_reader,
const ReplacementFor_HandlersForContentReader&ReplacementFor_handlers){for(const
 auto&x:ReplacementFor_handlers){const auto&pattern=x.first;const auto&
ReplacementFor_handler=x.second;if(std::regex_match(ReplacementFor_req.
ReplacementFor_path,ReplacementFor_req.ReplacementFor_matches,pattern)){
ReplacementFor_handler(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_content_reader);return true;}}return false;}bool 
ReplacementFor_Server::ReplacementFor_process_request(ReplacementFor_Stream&
ReplacementFor_strm,bool ReplacementFor_close_connection,bool&
ReplacementFor_connection_closed,const std::function<void(ReplacementFor_Request
&)>&ReplacementFor_setup_request){std::array<char,((0x19e4+5070-0x1aa0)+3802-
6636)>buf{};ReplacementFor_detail::ReplacementFor_stream_line_reader 
ReplacementFor_line_reader(ReplacementFor_strm,buf.data(),buf.size());if(!
ReplacementFor_line_reader.getline()){return false;}ReplacementFor_Request 
ReplacementFor_req;ReplacementFor_Response ReplacementFor_res;ReplacementFor_res
.ReplacementFor_version="\x48\x54\x54\x50\x2f\x31\x2e\x31";
#ifdef _WIN32
#else
#ifndef ReplacementFor_CPPHTTPLIB_USE_POLL
if(ReplacementFor_strm.socket()>=FD_SETSIZE){ReplacementFor_Headers dummy;
ReplacementFor_detail::ReplacementFor_read_headers(ReplacementFor_strm,dummy);
ReplacementFor_res.status=(6409+(0xe82+8099-0x21cf)-9067);return 
ReplacementFor_write_response(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}
#endif
#endif
if(ReplacementFor_line_reader.size()>
ReplacementFor_CPPHTTPLIB_REQUEST_URI_MAX_LENGTH){ReplacementFor_Headers dummy;
ReplacementFor_detail::ReplacementFor_read_headers(ReplacementFor_strm,dummy);
ReplacementFor_res.status=((0x113d+1373-0x1429)+(0x11bc+2195-0x10ff)-
(0x10c0+308-0x7d1));return ReplacementFor_write_response(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}if(!
ReplacementFor_parse_request_line(ReplacementFor_line_reader.ReplacementFor_ptr(
),ReplacementFor_req)||!ReplacementFor_detail::ReplacementFor_read_headers(
ReplacementFor_strm,ReplacementFor_req.ReplacementFor_headers)){
ReplacementFor_res.status=((0x19e5+3060-0x2373)+7266-7480);return 
ReplacementFor_write_response(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}if(
ReplacementFor_req.ReplacementFor_get_header_value(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")=="\x63\x6c\x6f\x73\x65"){
ReplacementFor_connection_closed=true;}if(ReplacementFor_req.
ReplacementFor_version=="\x48\x54\x54\x50\x2f\x31\x2e\x30"&&ReplacementFor_req.
ReplacementFor_get_header_value("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")!=
"\x4b\x65\x65\x70\x2d\x41\x6c\x69\x76\x65"){ReplacementFor_connection_closed=
true;}ReplacementFor_strm.ReplacementFor_get_remote_ip_and_port(
ReplacementFor_req.ReplacementFor_remote_addr,ReplacementFor_req.
ReplacementFor_remote_port);ReplacementFor_req.ReplacementFor_set_header(
"\x52\x45\x4d\x4f\x54\x45\x5f\x41\x44\x44\x52",ReplacementFor_req.
ReplacementFor_remote_addr);ReplacementFor_req.ReplacementFor_set_header(
"\x52\x45\x4d\x4f\x54\x45\x5f\x50\x4f\x52\x54",std::to_string(ReplacementFor_req
.ReplacementFor_remote_port));if(ReplacementFor_req.ReplacementFor_has_header(
"\x52\x61\x6e\x67\x65")){const auto&ReplacementFor_range_header_value=
ReplacementFor_req.ReplacementFor_get_header_value("\x52\x61\x6e\x67\x65");if(!
ReplacementFor_detail::ReplacementFor_parse_range_header(
ReplacementFor_range_header_value,ReplacementFor_req.ranges)){ReplacementFor_res
.status=((0x766+8263-0x229a)+(0x2334+8896-0x262e)-9017);return 
ReplacementFor_write_response(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}}if(
ReplacementFor_setup_request){ReplacementFor_setup_request(ReplacementFor_req);}
if(ReplacementFor_req.ReplacementFor_get_header_value("\x45\x78\x70\x65\x63\x74"
)=="\x31\x30\x30\x2d\x63\x6f\x6e\x74\x69\x6e\x75\x65"){auto status=(
(0x1a46+1713-0x1e2e)+(0x12af+6461-0x1a5a)-5111);if(
ReplacementFor_expect_100_continue_handler_){status=
ReplacementFor_expect_100_continue_handler_(ReplacementFor_req,
ReplacementFor_res);}switch(status){case((0x1aa0+4650-0x1b94)+(0x96c+3158-0xced)
-6567):case((0x201b+6812-0x270e)+(0x1264+2268-0xab0)-8856):ReplacementFor_strm.
ReplacementFor_write_format(
"\x48\x54\x54\x50\x2f\x31\x2e\x31\x20\x25\x64\x20\x25\x73""\r\n\r\n",status,
ReplacementFor_detail::ReplacementFor_status_message(status));break;default:
return ReplacementFor_write_response(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}}bool 
ReplacementFor_routed=false;try{ReplacementFor_routed=ReplacementFor_routing(
ReplacementFor_req,ReplacementFor_res,ReplacementFor_strm);}catch(std::exception
&ReplacementFor_e){if(ReplacementFor_exception_handler_){
ReplacementFor_exception_handler_(ReplacementFor_req,ReplacementFor_res,
ReplacementFor_e);ReplacementFor_routed=true;}else{ReplacementFor_res.status=(
(0x193a+2221-0x1e7c)+(0x164d+5598-0x164b)-(0x1fa9+4618-0x1a5c));
ReplacementFor_res.ReplacementFor_set_header(
"\x45\x58\x43\x45\x50\x54\x49\x4f\x4e\x5f\x57\x48\x41\x54",ReplacementFor_e.what
());}}catch(...){ReplacementFor_res.status=((0x1952+4355-0x1a65)+
(0x507+1069-0x687)-(0x1aa7+6005-0x2173));ReplacementFor_res.
ReplacementFor_set_header(
"\x45\x58\x43\x45\x50\x54\x49\x4f\x4e\x5f\x57\x48\x41\x54",
"\x55\x4e\x4b\x4e\x4f\x57\x4e");}if(ReplacementFor_routed){if(ReplacementFor_res
.status==-((0x21d9+2935-0x15b6)+(0x12b4+1647-0x124f)-7789)){ReplacementFor_res.
status=ReplacementFor_req.ranges.empty()?((0xfcc+6361-0x1baa)+
(0x12d3+7445-0x230a)-(0x2307+4060-0x19d2)):((0x23e0+1304-0x2608)+7212-7758);}
return ReplacementFor_write_response_with_content(ReplacementFor_strm,
ReplacementFor_close_connection,ReplacementFor_req,ReplacementFor_res);}else{if(
ReplacementFor_res.status==-((0x1665+5309-0x166e)+(0x5a2+9154-0x2684)-
(0x1d52+6994-0x2111))){ReplacementFor_res.status=((0x19ef+4469-0x26b9)+
(0x15c0+2639-0x106b)-(0x162f+8385-0x2435));}return ReplacementFor_write_response
(ReplacementFor_strm,ReplacementFor_close_connection,ReplacementFor_req,
ReplacementFor_res);}}bool ReplacementFor_Server::ReplacementFor_is_valid()const
{return true;}bool ReplacementFor_Server::
ReplacementFor_process_and_close_socket(ReplacementFor_socket_t 
ReplacementFor_sock){auto ReplacementFor_ret=ReplacementFor_detail::
ReplacementFor_process_server_socket(ReplacementFor_sock,
ReplacementFor_keep_alive_max_count_,ReplacementFor_keep_alive_timeout_sec_,
ReplacementFor_read_timeout_sec_,ReplacementFor_read_timeout_usec_,
ReplacementFor_write_timeout_sec_,ReplacementFor_write_timeout_usec_,[this](
ReplacementFor_Stream&ReplacementFor_strm,bool ReplacementFor_close_connection,
bool&ReplacementFor_connection_closed){return ReplacementFor_process_request(
ReplacementFor_strm,ReplacementFor_close_connection,
ReplacementFor_connection_closed,nullptr);});ReplacementFor_detail::
ReplacementFor_shutdown_socket(ReplacementFor_sock);ReplacementFor_detail::
ReplacementFor_close_socket(ReplacementFor_sock);return ReplacementFor_ret;}
ReplacementFor_ClientImpl::ReplacementFor_ClientImpl(const std::string&
ReplacementFor_host):ReplacementFor_ClientImpl(ReplacementFor_host,(
(0x2699+2871-0x1c00)+(0x1928+1110-0x1548)-7606),std::string(),std::string()){}
ReplacementFor_ClientImpl::ReplacementFor_ClientImpl(const std::string&
ReplacementFor_host,int ReplacementFor_port):ReplacementFor_ClientImpl(
ReplacementFor_host,ReplacementFor_port,std::string(),std::string()){}
ReplacementFor_ClientImpl::ReplacementFor_ClientImpl(const std::string&
ReplacementFor_host,int ReplacementFor_port,const std::string&
ReplacementFor_client_cert_path,const std::string&ReplacementFor_client_key_path
):ReplacementFor_host_(ReplacementFor_host),ReplacementFor_port_(
ReplacementFor_port),ReplacementFor_host_and_port_(ReplacementFor_host_+"\x3a"+
std::to_string(ReplacementFor_port_)),ReplacementFor_client_cert_path_(
ReplacementFor_client_cert_path),ReplacementFor_client_key_path_(
ReplacementFor_client_key_path){}ReplacementFor_ClientImpl::~
ReplacementFor_ClientImpl(){ReplacementFor_lock_socket_and_shutdown_and_close();
}bool ReplacementFor_ClientImpl::ReplacementFor_is_valid()const{return true;}
void ReplacementFor_ClientImpl::ReplacementFor_copy_settings(const 
ReplacementFor_ClientImpl&ReplacementFor_rhs){ReplacementFor_client_cert_path_=
ReplacementFor_rhs.ReplacementFor_client_cert_path_;
ReplacementFor_client_key_path_=ReplacementFor_rhs.
ReplacementFor_client_key_path_;ReplacementFor_connection_timeout_sec_=
ReplacementFor_rhs.ReplacementFor_connection_timeout_sec_;
ReplacementFor_read_timeout_sec_=ReplacementFor_rhs.
ReplacementFor_read_timeout_sec_;ReplacementFor_read_timeout_usec_=
ReplacementFor_rhs.ReplacementFor_read_timeout_usec_;
ReplacementFor_write_timeout_sec_=ReplacementFor_rhs.
ReplacementFor_write_timeout_sec_;ReplacementFor_write_timeout_usec_=
ReplacementFor_rhs.ReplacementFor_write_timeout_usec_;
ReplacementFor_basic_auth_username_=ReplacementFor_rhs.
ReplacementFor_basic_auth_username_;ReplacementFor_basic_auth_password_=
ReplacementFor_rhs.ReplacementFor_basic_auth_password_;
ReplacementFor_bearer_token_auth_token_=ReplacementFor_rhs.
ReplacementFor_bearer_token_auth_token_;
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
ReplacementFor_digest_auth_username_=ReplacementFor_rhs.
ReplacementFor_digest_auth_username_;ReplacementFor_digest_auth_password_=
ReplacementFor_rhs.ReplacementFor_digest_auth_password_;
#endif
ReplacementFor_keep_alive_=ReplacementFor_rhs.ReplacementFor_keep_alive_;
ReplacementFor_follow_location_=ReplacementFor_rhs.
ReplacementFor_follow_location_;ReplacementFor_tcp_nodelay_=ReplacementFor_rhs.
ReplacementFor_tcp_nodelay_;ReplacementFor_socket_options_=ReplacementFor_rhs.
ReplacementFor_socket_options_;ReplacementFor_compress_=ReplacementFor_rhs.
ReplacementFor_compress_;ReplacementFor_decompress_=ReplacementFor_rhs.
ReplacementFor_decompress_;ReplacementFor_interface_=ReplacementFor_rhs.
ReplacementFor_interface_;ReplacementFor_proxy_host_=ReplacementFor_rhs.
ReplacementFor_proxy_host_;ReplacementFor_proxy_port_=ReplacementFor_rhs.
ReplacementFor_proxy_port_;ReplacementFor_proxy_basic_auth_username_=
ReplacementFor_rhs.ReplacementFor_proxy_basic_auth_username_;
ReplacementFor_proxy_basic_auth_password_=ReplacementFor_rhs.
ReplacementFor_proxy_basic_auth_password_;
ReplacementFor_proxy_bearer_token_auth_token_=ReplacementFor_rhs.
ReplacementFor_proxy_bearer_token_auth_token_;
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
ReplacementFor_proxy_digest_auth_username_=ReplacementFor_rhs.
ReplacementFor_proxy_digest_auth_username_;
ReplacementFor_proxy_digest_auth_password_=ReplacementFor_rhs.
ReplacementFor_proxy_digest_auth_password_;
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
ReplacementFor_server_certificate_verification_=ReplacementFor_rhs.
ReplacementFor_server_certificate_verification_;
#endif
ReplacementFor_logger_=ReplacementFor_rhs.ReplacementFor_logger_;}
ReplacementFor_socket_t ReplacementFor_ClientImpl::
ReplacementFor_create_client_socket(Error&error)const{if(!
ReplacementFor_proxy_host_.empty()&&ReplacementFor_proxy_port_!=-(6229+
(0xfda+5495-0x2498)-6413)){return ReplacementFor_detail::
ReplacementFor_create_client_socket(ReplacementFor_proxy_host_.c_str(),
ReplacementFor_proxy_port_,ReplacementFor_tcp_nodelay_,
ReplacementFor_socket_options_,ReplacementFor_connection_timeout_sec_,
ReplacementFor_connection_timeout_usec_,ReplacementFor_interface_,error);}return
 ReplacementFor_detail::ReplacementFor_create_client_socket(ReplacementFor_host_
.c_str(),ReplacementFor_port_,ReplacementFor_tcp_nodelay_,
ReplacementFor_socket_options_,ReplacementFor_connection_timeout_sec_,
ReplacementFor_connection_timeout_usec_,ReplacementFor_interface_,error);}bool 
ReplacementFor_ClientImpl::ReplacementFor_create_and_connect_socket(Socket&
socket,Error&error){auto ReplacementFor_sock=ReplacementFor_create_client_socket
(error);if(ReplacementFor_sock==INVALID_SOCKET){return false;}socket.
ReplacementFor_sock=ReplacementFor_sock;return true;}void 
ReplacementFor_ClientImpl::ReplacementFor_shutdown_ssl(Socket&,bool){assert(
ReplacementFor_socket_requests_in_flight_==((0x7a2+8729-0x23f8)+6875-8350)||
ReplacementFor_socket_requests_are_from_thread_==std::this_thread::get_id());}
void ReplacementFor_ClientImpl::ReplacementFor_shutdown_socket(Socket&socket){if
(socket.ReplacementFor_sock==INVALID_SOCKET){return;}ReplacementFor_detail::
ReplacementFor_shutdown_socket(socket.ReplacementFor_sock);}void 
ReplacementFor_ClientImpl::ReplacementFor_close_socket(Socket&socket){assert(
ReplacementFor_socket_requests_in_flight_==((0x1d19+1477-0xb3f)+
(0x10b3+2955-0x13a9)-(0x25e1+4045-0x157a))||
ReplacementFor_socket_requests_are_from_thread_==std::this_thread::get_id());
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
assert(socket.ReplacementFor_ssl==nullptr);
#endif
if(socket.ReplacementFor_sock==INVALID_SOCKET){return;}ReplacementFor_detail::
ReplacementFor_close_socket(socket.ReplacementFor_sock);socket.
ReplacementFor_sock=INVALID_SOCKET;}void ReplacementFor_ClientImpl::
ReplacementFor_lock_socket_and_shutdown_and_close(){std::lock_guard<std::mutex>
ReplacementFor_guard(ReplacementFor_socket_mutex_);ReplacementFor_shutdown_ssl(
ReplacementFor_socket_,true);ReplacementFor_shutdown_socket(
ReplacementFor_socket_);ReplacementFor_close_socket(ReplacementFor_socket_);}
bool ReplacementFor_ClientImpl::ReplacementFor_read_response_line(
ReplacementFor_Stream&ReplacementFor_strm,const ReplacementFor_Request&
ReplacementFor_req,ReplacementFor_Response&ReplacementFor_res){std::array<char,(
(0xd93+2146-0x99b)+(0x24cc+3265-0x1fc8)-5663)>buf;ReplacementFor_detail::
ReplacementFor_stream_line_reader ReplacementFor_line_reader(ReplacementFor_strm
,buf.data(),buf.size());if(!ReplacementFor_line_reader.getline()){return false;}
const static std::regex ReplacementFor_re("\x28\x48\x54\x54\x50\x2f\x31""\\"
"\x2e\x5b\x30\x31\x5d\x29\x20\x28""\\"
"\x64\x7b\x33\x7d\x29\x20\x28\x2e\x2a\x3f\x29""\r\n");std::cmatch m;if(!std::
regex_match(ReplacementFor_line_reader.ReplacementFor_ptr(),m,ReplacementFor_re)
){return ReplacementFor_req.ReplacementFor_method==
"\x43\x4f\x4e\x4e\x45\x43\x54";}ReplacementFor_res.ReplacementFor_version=std::
string(m[((0x2337+2645-0x1096)+(0xcc1+591-0xbe0)-(0x2508+2243-0xda6))]);
ReplacementFor_res.status=std::stoi(std::string(m[((0x2185+8395-0x234e)+
(0x15cc+2652-0x1d75)-(0x25e2+2957-0xfbc))]));ReplacementFor_res.
ReplacementFor_reason=std::string(m[((0x1498+3916-0x171d)+(0x10fa+6812-0x1f6c)-
6382)]);while(ReplacementFor_res.status==((0x21e5+364-0xeba)+
(0x10c5+3658-0x1844)-6910)){if(!ReplacementFor_line_reader.getline()){return 
false;}if(!ReplacementFor_line_reader.getline()){return false;}if(!std::
regex_match(ReplacementFor_line_reader.ReplacementFor_ptr(),m,ReplacementFor_re)
){return false;}ReplacementFor_res.ReplacementFor_version=std::string(m[(
(0x2083+2319-0x236e)+(0x1c9d+2712-0xfb0)-(0x2439+2486-0x1047))]);
ReplacementFor_res.status=std::stoi(std::string(m[((0x1fa4+1086-0x19d6)+
(0x1775+5920-0x1bbe)-(0x2703+3702-0x1898))]));ReplacementFor_res.
ReplacementFor_reason=std::string(m[((0xda6+6267-0x22e2)+(0x1aa3+3552-0x23e4)-
(0xf7c+3155-0x13f4))]);}return true;}bool ReplacementFor_ClientImpl::send(
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,Error&error){std::lock_guard<std::recursive_mutex>
ReplacementFor_request_mutex_guard(ReplacementFor_request_mutex_);{std::
lock_guard<std::mutex>ReplacementFor_guard(ReplacementFor_socket_mutex_);
ReplacementFor_socket_should_be_closed_when_request_is_done_=false;auto 
ReplacementFor_is_alive=false;if(ReplacementFor_socket_.is_open()){
ReplacementFor_is_alive=ReplacementFor_detail::ReplacementFor_select_write(
ReplacementFor_socket_.ReplacementFor_sock,((0xa9b+737-0x766)+
(0x1d1f+3027-0x12ad)-7259),((0xf95+3746-0x19e4)+(0x1939+1391-0x167d)-
(0x196d+1868-0x143b)))>((0x6c1+2775-0xf1c)+(0x1870+4770-0x1615)-
(0x1e04+5970-0x1ddd));if(!ReplacementFor_is_alive){const bool 
ReplacementFor_shutdown_gracefully=false;ReplacementFor_shutdown_ssl(
ReplacementFor_socket_,ReplacementFor_shutdown_gracefully);
ReplacementFor_shutdown_socket(ReplacementFor_socket_);
ReplacementFor_close_socket(ReplacementFor_socket_);}}if(!
ReplacementFor_is_alive){if(!ReplacementFor_create_and_connect_socket(
ReplacementFor_socket_,error)){return false;}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
if(ReplacementFor_is_ssl()){auto&ReplacementFor_scli=static_cast<
ReplacementFor_SSLClient&>(*this);if(!ReplacementFor_proxy_host_.empty()&&
ReplacementFor_proxy_port_!=-((0x13a1+1032-0x1088)+(0x16cc+4074-0x25a0)-
(0xdcc+8503-0x26cd))){bool ReplacementFor_success=false;if(!ReplacementFor_scli.
ReplacementFor_connect_with_proxy(ReplacementFor_socket_,ReplacementFor_res,
ReplacementFor_success,error)){return ReplacementFor_success;}}if(!
ReplacementFor_scli.ReplacementFor_initialize_ssl(ReplacementFor_socket_,error))
{return false;}}
#endif
}if(ReplacementFor_socket_requests_in_flight_>((0x118f+5454-0x1d08)+
(0x218f+843-0xa55)-9305)){assert(ReplacementFor_socket_requests_are_from_thread_
==std::this_thread::get_id());}ReplacementFor_socket_requests_in_flight_+=(
(0x1cab+5830-0x21c4)+(0x12d8+669-0x7a7)-8058);
ReplacementFor_socket_requests_are_from_thread_=std::this_thread::get_id();}for(
const auto&header:ReplacementFor_default_headers_){if(ReplacementFor_req.
ReplacementFor_headers.find(header.first)==ReplacementFor_req.
ReplacementFor_headers.end()){ReplacementFor_req.ReplacementFor_headers.insert(
header);}}auto ReplacementFor_close_connection=!ReplacementFor_keep_alive_;auto 
ReplacementFor_ret=ReplacementFor_process_socket(ReplacementFor_socket_,[&](
ReplacementFor_Stream&ReplacementFor_strm){return ReplacementFor_handle_request(
ReplacementFor_strm,ReplacementFor_req,ReplacementFor_res,
ReplacementFor_close_connection,error);});{std::lock_guard<std::mutex>
ReplacementFor_guard(ReplacementFor_socket_mutex_);
ReplacementFor_socket_requests_in_flight_-=((0x1593+6536-0x1bba)+
(0x1983+1511-0x1755)-(0x2379+667-0xa9f));if(
ReplacementFor_socket_requests_in_flight_<=((0xf37+3830-0x1a8b)+
(0x1419+4145-0x1103)-(0x26aa+4373-0x20d6))){assert(
ReplacementFor_socket_requests_in_flight_==((0x1bb7+3071-0x2336)+
(0x1415+7400-0x2560)-(0x1276+2228-0xb0d)));
ReplacementFor_socket_requests_are_from_thread_=std::thread::id();}if(
ReplacementFor_socket_should_be_closed_when_request_is_done_||
ReplacementFor_close_connection||!ReplacementFor_ret){
ReplacementFor_shutdown_ssl(ReplacementFor_socket_,true);
ReplacementFor_shutdown_socket(ReplacementFor_socket_);
ReplacementFor_close_socket(ReplacementFor_socket_);}}if(!ReplacementFor_ret){if
(error==Error::ReplacementFor_Success){error=Error::Unknown;}}return 
ReplacementFor_ret;}Result ReplacementFor_ClientImpl::send(const 
ReplacementFor_Request&ReplacementFor_req){auto ReplacementFor_req2=
ReplacementFor_req;return ReplacementFor_send_(std::move(ReplacementFor_req2));}
Result ReplacementFor_ClientImpl::ReplacementFor_send_(ReplacementFor_Request&&
ReplacementFor_req){auto ReplacementFor_res=ReplacementFor_detail::make_unique<
ReplacementFor_Response>();auto error=Error::ReplacementFor_Success;auto 
ReplacementFor_ret=send(ReplacementFor_req,*ReplacementFor_res,error);return 
Result{ReplacementFor_ret?std::move(ReplacementFor_res):nullptr,error,std::move(
ReplacementFor_req.ReplacementFor_headers)};}bool ReplacementFor_ClientImpl::
ReplacementFor_handle_request(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,bool ReplacementFor_close_connection,Error&error){if(
ReplacementFor_req.ReplacementFor_path.empty()){error=Error::
ReplacementFor_Connection;return false;}auto ReplacementFor_req_save=
ReplacementFor_req;bool ReplacementFor_ret;if(!ReplacementFor_is_ssl()&&!
ReplacementFor_proxy_host_.empty()&&ReplacementFor_proxy_port_!=-(
(0x194b+7685-0x1e79)+(0x77f+8863-0x22be)-8246)){auto ReplacementFor_req2=
ReplacementFor_req;ReplacementFor_req2.ReplacementFor_path=
"\x68\x74\x74\x70\x3a\x2f\x2f"+ReplacementFor_host_and_port_+ReplacementFor_req.
ReplacementFor_path;ReplacementFor_ret=ReplacementFor_process_request(
ReplacementFor_strm,ReplacementFor_req2,ReplacementFor_res,
ReplacementFor_close_connection,error);ReplacementFor_req=ReplacementFor_req2;
ReplacementFor_req.ReplacementFor_path=ReplacementFor_req_save.
ReplacementFor_path;}else{ReplacementFor_ret=ReplacementFor_process_request(
ReplacementFor_strm,ReplacementFor_req,ReplacementFor_res,
ReplacementFor_close_connection,error);}if(!ReplacementFor_ret){return false;}if
(((0x14ca+859-0xd35)+(0xe9c+7930-0x212b)-(0x2664+4115-0x2048))<
ReplacementFor_res.status&&ReplacementFor_res.status<((0x225d+4247-0x200b)+
(0x1ef6+3579-0x2274)-(0x2008+4724-0x16a6))&&ReplacementFor_follow_location_){
ReplacementFor_req=ReplacementFor_req_save;ReplacementFor_ret=
ReplacementFor_redirect(ReplacementFor_req,ReplacementFor_res,error);}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
if((ReplacementFor_res.status==((0x7c8+5359-0x15bb)+(0x1408+3273-0x1a0d)-
(0x23a1+1138-0x1be4))||ReplacementFor_res.status==((0xc61+2805-0x10ec)+
(0x10b9+4403-0x1332)-(0x1ff0+529-0xe74)))&&ReplacementFor_req.
ReplacementFor_authorization_count_<((0x1fed+368-0x17ba)+(0x1c73+1144-0xe12)-
7287)){auto ReplacementFor_is_proxy=ReplacementFor_res.status==(
(0x2696+1113-0xdf7)+(0x10bc+2191-0x174c)-7520);const auto&
ReplacementFor_username=ReplacementFor_is_proxy?
ReplacementFor_proxy_digest_auth_username_:ReplacementFor_digest_auth_username_;
const auto&ReplacementFor_password=ReplacementFor_is_proxy?
ReplacementFor_proxy_digest_auth_password_:ReplacementFor_digest_auth_password_;
if(!ReplacementFor_username.empty()&&!ReplacementFor_password.empty()){std::map<
std::string,std::string>ReplacementFor_auth;if(ReplacementFor_detail::
ReplacementFor_parse_www_authenticate(ReplacementFor_res,ReplacementFor_auth,
ReplacementFor_is_proxy)){ReplacementFor_Request ReplacementFor_new_req=
ReplacementFor_req;ReplacementFor_new_req.ReplacementFor_authorization_count_+=(
(0x1456+951-0x17dc)+(0x2237+2896-0x1953)-(0x2202+6170-0x25b8));auto key=
ReplacementFor_is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";ReplacementFor_new_req.
ReplacementFor_headers.erase(key);ReplacementFor_new_req.ReplacementFor_headers.
insert(ReplacementFor_detail::ReplacementFor_make_digest_authentication_header(
ReplacementFor_req,ReplacementFor_auth,ReplacementFor_new_req.
ReplacementFor_authorization_count_,ReplacementFor_detail::
ReplacementFor_random_string(((0x1ac6+435-0x73c)+(0x16f6+256-0x125a)-6863)),
ReplacementFor_username,ReplacementFor_password,ReplacementFor_is_proxy));
ReplacementFor_Response ReplacementFor_new_res;ReplacementFor_ret=send(
ReplacementFor_new_req,ReplacementFor_new_res,error);if(ReplacementFor_ret){
ReplacementFor_res=ReplacementFor_new_res;}}}}
#endif
return ReplacementFor_ret;}bool ReplacementFor_ClientImpl::
ReplacementFor_redirect(ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,Error&error){if(ReplacementFor_req.
ReplacementFor_redirect_count_==(2953+(0x1734+1748-0x1b30)-(0x2479+856-0x1970)))
{error=Error::ReplacementFor_ExceedRedirectCount;return false;}auto 
ReplacementFor_location=ReplacementFor_detail::ReplacementFor_decode_url(
ReplacementFor_res.ReplacementFor_get_header_value(
"\x6c\x6f\x63\x61\x74\x69\x6f\x6e"),true);if(ReplacementFor_location.empty()){
return false;}const static std::regex ReplacementFor_re(
R"(^(?:(https?):)?(?://([^:/?#]*)(?::(\d+))?)?([^?#]*(?:\?[^#]*)?)(?:#.*)?)");
std::smatch m;if(!std::regex_match(ReplacementFor_location,m,ReplacementFor_re))
{return false;}auto ReplacementFor_scheme=ReplacementFor_is_ssl()?
"\x68\x74\x74\x70\x73":"\x68\x74\x74\x70";auto ReplacementFor_next_scheme=m[(
(0x706+334-0x1d8)+(0xd8b+4057-0x14b5)-(0x1a97+6954-0x2697))].str();auto 
ReplacementFor_next_host=m[((0x2189+1786-0x1af3)+3615-(0x1e7d+1294-0x7de))].str(
);auto ReplacementFor_port_str=m[((0xd50+1682-0x114b)+6342-(0x1ed0+7711-0x2195))
].str();auto ReplacementFor_next_path=m[((0x1061+2928-0x18b4)+
(0x22ea+1372-0x1c12)-(0x1290+3586-0x1145))].str();auto ReplacementFor_next_port=
ReplacementFor_port_;if(!ReplacementFor_port_str.empty()){
ReplacementFor_next_port=std::stoi(ReplacementFor_port_str);}else if(!
ReplacementFor_next_scheme.empty()){ReplacementFor_next_port=
ReplacementFor_next_scheme=="\x68\x74\x74\x70\x73"?((0x2541+5283-0x21b7)+
(0xa10+4283-0x1503)-(0x25e4+3400-0x16f2)):(7554+(0xa44+4264-0x16aa)-
(0x2682+4646-0x1734));}if(ReplacementFor_next_scheme.empty()){
ReplacementFor_next_scheme=ReplacementFor_scheme;}if(ReplacementFor_next_host.
empty()){ReplacementFor_next_host=ReplacementFor_host_;}if(
ReplacementFor_next_path.empty()){ReplacementFor_next_path="\x2f";}if(
ReplacementFor_next_scheme==ReplacementFor_scheme&&ReplacementFor_next_host==
ReplacementFor_host_&&ReplacementFor_next_port==ReplacementFor_port_){return 
ReplacementFor_detail::ReplacementFor_redirect(*this,ReplacementFor_req,
ReplacementFor_res,ReplacementFor_next_path,ReplacementFor_location,error);}else
{if(ReplacementFor_next_scheme=="\x68\x74\x74\x70\x73"){
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
ReplacementFor_SSLClient ReplacementFor_cli(ReplacementFor_next_host.c_str(),
ReplacementFor_next_port);ReplacementFor_cli.ReplacementFor_copy_settings(*this)
;return ReplacementFor_detail::ReplacementFor_redirect(ReplacementFor_cli,
ReplacementFor_req,ReplacementFor_res,ReplacementFor_next_path,
ReplacementFor_location,error);
#else
return false;
#endif
}else{ReplacementFor_ClientImpl ReplacementFor_cli(ReplacementFor_next_host.
c_str(),ReplacementFor_next_port);ReplacementFor_cli.
ReplacementFor_copy_settings(*this);return ReplacementFor_detail::
ReplacementFor_redirect(ReplacementFor_cli,ReplacementFor_req,ReplacementFor_res
,ReplacementFor_next_path,ReplacementFor_location,error);}}}bool 
ReplacementFor_ClientImpl::ReplacementFor_write_content_with_provider(
ReplacementFor_Stream&ReplacementFor_strm,const ReplacementFor_Request&
ReplacementFor_req,Error&error){auto ReplacementFor_is_shutting_down=[](){return
 false;};if(ReplacementFor_req.ReplacementFor_is_chunked_content_provider_){std
::unique_ptr<ReplacementFor_detail::ReplacementFor_compressor>
ReplacementFor_compressor;
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
if(ReplacementFor_compress_){ReplacementFor_compressor=ReplacementFor_detail::
make_unique<ReplacementFor_detail::ReplacementFor_gzip_compressor>();}else
#endif
{ReplacementFor_compressor=ReplacementFor_detail::make_unique<
ReplacementFor_detail::ReplacementFor_nocompressor>();}return 
ReplacementFor_detail::ReplacementFor_write_content_chunked(ReplacementFor_strm,
ReplacementFor_req.ReplacementFor_content_provider_,
ReplacementFor_is_shutting_down,*ReplacementFor_compressor,error);}else{return 
ReplacementFor_detail::ReplacementFor_write_content(ReplacementFor_strm,
ReplacementFor_req.ReplacementFor_content_provider_,((0x16dc+4766-0x2416)+
(0x1002+291-0xce8)-(0xd06+3678-0x11c3)),ReplacementFor_req.
ReplacementFor_content_length_,ReplacementFor_is_shutting_down,error);}}bool 
ReplacementFor_ClientImpl::ReplacementFor_write_request(ReplacementFor_Stream&
ReplacementFor_strm,ReplacementFor_Request&ReplacementFor_req,bool 
ReplacementFor_close_connection,Error&error){if(ReplacementFor_close_connection)
{ReplacementFor_req.ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e","\x63\x6c\x6f\x73\x65");}if(!
ReplacementFor_req.ReplacementFor_has_header("\x48\x6f\x73\x74")){if(
ReplacementFor_is_ssl()){if(ReplacementFor_port_==((0x130a+4884-0x1b98)+
(0x10e5+6206-0x22d7)-(0x24cf+853-0x190d))){ReplacementFor_req.
ReplacementFor_headers.emplace("\x48\x6f\x73\x74",ReplacementFor_host_);}else{
ReplacementFor_req.ReplacementFor_headers.emplace("\x48\x6f\x73\x74",
ReplacementFor_host_and_port_);}}else{if(ReplacementFor_port_==(
(0xe2b+2580-0x14a5)+4447-5289)){ReplacementFor_req.ReplacementFor_headers.
emplace("\x48\x6f\x73\x74",ReplacementFor_host_);}else{ReplacementFor_req.
ReplacementFor_headers.emplace("\x48\x6f\x73\x74",ReplacementFor_host_and_port_)
;}}}if(!ReplacementFor_req.ReplacementFor_has_header("\x41\x63\x63\x65\x70\x74")
){ReplacementFor_req.ReplacementFor_headers.emplace("\x41\x63\x63\x65\x70\x74",
"\x2a\x2f\x2a");}if(!ReplacementFor_req.ReplacementFor_has_header(
"\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74")){ReplacementFor_req.
ReplacementFor_headers.emplace("\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74",
"\x63\x70\x70\x2d\x68\x74\x74\x70\x6c\x69\x62\x2f\x30\x2e\x37");}if(
ReplacementFor_req.ReplacementFor_body.empty()){if(ReplacementFor_req.
ReplacementFor_content_provider_){if(!ReplacementFor_req.
ReplacementFor_is_chunked_content_provider_){auto length=std::to_string(
ReplacementFor_req.ReplacementFor_content_length_);ReplacementFor_req.
ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}else{if(
ReplacementFor_req.ReplacementFor_method=="\x50\x4f\x53\x54"||ReplacementFor_req
.ReplacementFor_method=="\x50\x55\x54"||ReplacementFor_req.ReplacementFor_method
=="\x50\x41\x54\x43\x48"){ReplacementFor_req.ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68","\x30");}}}else{if(!
ReplacementFor_req.ReplacementFor_has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65")){ReplacementFor_req.
ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e");}if(!ReplacementFor_req.
ReplacementFor_has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){auto length=std::
to_string(ReplacementFor_req.ReplacementFor_body.size());ReplacementFor_req.
ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}if(!
ReplacementFor_basic_auth_password_.empty()){ReplacementFor_req.
ReplacementFor_headers.insert(ReplacementFor_make_basic_authentication_header(
ReplacementFor_basic_auth_username_,ReplacementFor_basic_auth_password_,false));
}if(!ReplacementFor_proxy_basic_auth_username_.empty()&&!
ReplacementFor_proxy_basic_auth_password_.empty()){ReplacementFor_req.
ReplacementFor_headers.insert(ReplacementFor_make_basic_authentication_header(
ReplacementFor_proxy_basic_auth_username_,
ReplacementFor_proxy_basic_auth_password_,true));}if(!
ReplacementFor_bearer_token_auth_token_.empty()){ReplacementFor_req.
ReplacementFor_headers.insert(
ReplacementFor_make_bearer_token_authentication_header(
ReplacementFor_bearer_token_auth_token_,false));}if(!
ReplacementFor_proxy_bearer_token_auth_token_.empty()){ReplacementFor_req.
ReplacementFor_headers.insert(
ReplacementFor_make_bearer_token_authentication_header(
ReplacementFor_proxy_bearer_token_auth_token_,true));}{ReplacementFor_detail::
ReplacementFor_BufferStream ReplacementFor_bstrm;const auto&ReplacementFor_path=
ReplacementFor_detail::ReplacementFor_encode_url(ReplacementFor_req.
ReplacementFor_path);ReplacementFor_bstrm.ReplacementFor_write_format(
"\x25\x73\x20\x25\x73\x20\x48\x54\x54\x50\x2f\x31\x2e\x31""\r\n",
ReplacementFor_req.ReplacementFor_method.c_str(),ReplacementFor_path.c_str());
ReplacementFor_detail::ReplacementFor_write_headers(ReplacementFor_bstrm,
ReplacementFor_req.ReplacementFor_headers);auto&data=ReplacementFor_bstrm.
ReplacementFor_get_buffer();if(!ReplacementFor_detail::ReplacementFor_write_data
(ReplacementFor_strm,data.data(),data.size())){error=Error::Write;return false;}
}if(ReplacementFor_req.ReplacementFor_body.empty()){return 
ReplacementFor_write_content_with_provider(ReplacementFor_strm,
ReplacementFor_req,error);}else{return ReplacementFor_detail::
ReplacementFor_write_data(ReplacementFor_strm,ReplacementFor_req.
ReplacementFor_body.data(),ReplacementFor_req.ReplacementFor_body.size());}
return true;}std::unique_ptr<ReplacementFor_Response>ReplacementFor_ClientImpl::
ReplacementFor_send_with_content_provider(ReplacementFor_Request&
ReplacementFor_req,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider_without_length,const char*
ReplacementFor_content_type,Error&error){if(ReplacementFor_content_type){
ReplacementFor_req.ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
}
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
if(ReplacementFor_compress_){ReplacementFor_req.ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x67\x7a\x69\x70");}
#endif
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
if(ReplacementFor_compress_&&!ReplacementFor_content_provider_without_length){
ReplacementFor_detail::ReplacementFor_gzip_compressor ReplacementFor_compressor;
if(ReplacementFor_content_provider){auto ok=true;size_t offset=(
(0x2339+7412-0x21de)+(0xa38+1561-0xe3c)-8292);ReplacementFor_DataSink 
ReplacementFor_data_sink;ReplacementFor_data_sink.write=[&](const char*data,
size_t ReplacementFor_data_len){if(ok){auto ReplacementFor_last=offset+
ReplacementFor_data_len==ReplacementFor_content_length;auto ReplacementFor_ret=
ReplacementFor_compressor.compress(data,ReplacementFor_data_len,
ReplacementFor_last,[&](const char*data,size_t ReplacementFor_data_len){
ReplacementFor_req.ReplacementFor_body.append(data,ReplacementFor_data_len);
return true;});if(ReplacementFor_ret){offset+=ReplacementFor_data_len;}else{ok=
false;}}};ReplacementFor_data_sink.ReplacementFor_is_writable=[&](void){return 
ok&&true;};while(ok&&offset<ReplacementFor_content_length){if(!
ReplacementFor_content_provider(offset,ReplacementFor_content_length-offset,
ReplacementFor_data_sink)){error=Error::ReplacementFor_Canceled;return nullptr;}
}}else{if(!ReplacementFor_compressor.compress(ReplacementFor_body,
ReplacementFor_content_length,true,[&](const char*data,size_t 
ReplacementFor_data_len){ReplacementFor_req.ReplacementFor_body.append(data,
ReplacementFor_data_len);return true;})){error=Error::Compression;return nullptr
;}}}else
#endif
{if(ReplacementFor_content_provider){ReplacementFor_req.
ReplacementFor_content_length_=ReplacementFor_content_length;ReplacementFor_req.
ReplacementFor_content_provider_=std::move(ReplacementFor_content_provider);
ReplacementFor_req.ReplacementFor_is_chunked_content_provider_=false;}else if(
ReplacementFor_content_provider_without_length){ReplacementFor_req.
ReplacementFor_content_length_=(6385+(0x70b+479-0x643)-7064);ReplacementFor_req.
ReplacementFor_content_provider_=ReplacementFor_detail::
ReplacementFor_ContentProviderAdapter(std::move(
ReplacementFor_content_provider_without_length));ReplacementFor_req.
ReplacementFor_is_chunked_content_provider_=true;ReplacementFor_req.
ReplacementFor_headers.emplace(
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x63\x68\x75\x6e\x6b\x65\x64");}else{ReplacementFor_req.ReplacementFor_body.
assign(ReplacementFor_body,ReplacementFor_content_length);;}}auto 
ReplacementFor_res=ReplacementFor_detail::make_unique<ReplacementFor_Response>()
;return send(ReplacementFor_req,*ReplacementFor_res,error)?std::move(
ReplacementFor_res):nullptr;}Result ReplacementFor_ClientImpl::
ReplacementFor_send_with_content_provider(const char*ReplacementFor_method,const
 char*ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
const char*ReplacementFor_body,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,
ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider_without_length,const char*
ReplacementFor_content_type){ReplacementFor_Request ReplacementFor_req;
ReplacementFor_req.ReplacementFor_method=ReplacementFor_method;
ReplacementFor_req.ReplacementFor_headers=ReplacementFor_headers;
ReplacementFor_req.ReplacementFor_path=ReplacementFor_path;auto error=Error::
ReplacementFor_Success;auto ReplacementFor_res=
ReplacementFor_send_with_content_provider(ReplacementFor_req,ReplacementFor_body
,ReplacementFor_content_length,std::move(ReplacementFor_content_provider),std::
move(ReplacementFor_content_provider_without_length),ReplacementFor_content_type
,error);return Result{std::move(ReplacementFor_res),error,std::move(
ReplacementFor_req.ReplacementFor_headers)};}bool ReplacementFor_ClientImpl::
ReplacementFor_process_request(ReplacementFor_Stream&ReplacementFor_strm,
ReplacementFor_Request&ReplacementFor_req,ReplacementFor_Response&
ReplacementFor_res,bool ReplacementFor_close_connection,Error&error){if(!
ReplacementFor_write_request(ReplacementFor_strm,ReplacementFor_req,
ReplacementFor_close_connection,error)){return false;}if(!
ReplacementFor_read_response_line(ReplacementFor_strm,ReplacementFor_req,
ReplacementFor_res)||!ReplacementFor_detail::ReplacementFor_read_headers(
ReplacementFor_strm,ReplacementFor_res.ReplacementFor_headers)){error=Error::
Read;return false;}if(ReplacementFor_req.ReplacementFor_response_handler){if(!
ReplacementFor_req.ReplacementFor_response_handler(ReplacementFor_res)){error=
Error::ReplacementFor_Canceled;return false;}}if((ReplacementFor_res.status!=(
(0x1f1d+4645-0x1350)+(0x506+2260-0xd25)-7643))&&ReplacementFor_req.
ReplacementFor_method!="\x48\x45\x41\x44"&&ReplacementFor_req.
ReplacementFor_method!="\x43\x4f\x4e\x4e\x45\x43\x54"){auto out=
ReplacementFor_req.ReplacementFor_content_receiver?static_cast<
ReplacementFor_ContentReceiverWithProgress>([&](const char*buf,size_t n,uint64_t
 ReplacementFor_off,uint64_t len){auto ReplacementFor_ret=ReplacementFor_req.
ReplacementFor_content_receiver(buf,n,ReplacementFor_off,len);if(!
ReplacementFor_ret){error=Error::ReplacementFor_Canceled;}return 
ReplacementFor_ret;}):static_cast<ReplacementFor_ContentReceiverWithProgress>([&
](const char*buf,size_t n,uint64_t,uint64_t){if(ReplacementFor_res.
ReplacementFor_body.size()+n>ReplacementFor_res.ReplacementFor_body.max_size()){
return false;}ReplacementFor_res.ReplacementFor_body.append(buf,n);return true;}
);auto ReplacementFor_progress=[&](uint64_t current,uint64_t 
ReplacementFor_total){if(!ReplacementFor_req.ReplacementFor_progress){return 
true;}auto ReplacementFor_ret=ReplacementFor_req.ReplacementFor_progress(current
,ReplacementFor_total);if(!ReplacementFor_ret){error=Error::
ReplacementFor_Canceled;}return ReplacementFor_ret;};int 
ReplacementFor_dummy_status;if(!ReplacementFor_detail::
ReplacementFor_read_content(ReplacementFor_strm,ReplacementFor_res,(std::
numeric_limits<size_t>::max)(),ReplacementFor_dummy_status,std::move(
ReplacementFor_progress),std::move(out),ReplacementFor_decompress_)){if(error!=
Error::ReplacementFor_Canceled){error=Error::Read;}return false;}}if(
ReplacementFor_res.ReplacementFor_get_header_value(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")=="\x63\x6c\x6f\x73\x65"||(
ReplacementFor_res.ReplacementFor_version=="\x48\x54\x54\x50\x2f\x31\x2e\x30"&&
ReplacementFor_res.ReplacementFor_reason!=
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x65\x73\x74\x61\x62\x6c\x69\x73\x68\x65\x64"
)){ReplacementFor_lock_socket_and_shutdown_and_close();}if(
ReplacementFor_logger_){ReplacementFor_logger_(ReplacementFor_req,
ReplacementFor_res);}return true;}bool ReplacementFor_ClientImpl::
ReplacementFor_process_socket(const Socket&socket,std::function<bool(
ReplacementFor_Stream&ReplacementFor_strm)>ReplacementFor_callback){return 
ReplacementFor_detail::ReplacementFor_process_client_socket(socket.
ReplacementFor_sock,ReplacementFor_read_timeout_sec_,
ReplacementFor_read_timeout_usec_,ReplacementFor_write_timeout_sec_,
ReplacementFor_write_timeout_usec_,std::move(ReplacementFor_callback));}bool 
ReplacementFor_ClientImpl::ReplacementFor_is_ssl()const{return false;}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path){return Get(
ReplacementFor_path,ReplacementFor_Headers(),ReplacementFor_Progress());}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,
ReplacementFor_Progress ReplacementFor_progress){return Get(ReplacementFor_path,
ReplacementFor_Headers(),std::move(ReplacementFor_progress));}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers){return Get(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_Progress());}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_Progress 
ReplacementFor_progress){ReplacementFor_Request ReplacementFor_req;
ReplacementFor_req.ReplacementFor_method="\x47\x45\x54";ReplacementFor_req.
ReplacementFor_path=ReplacementFor_path;ReplacementFor_req.
ReplacementFor_headers=ReplacementFor_headers;ReplacementFor_req.
ReplacementFor_progress=std::move(ReplacementFor_progress);return 
ReplacementFor_send_(std::move(ReplacementFor_req));}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver){return Get(
ReplacementFor_path,ReplacementFor_Headers(),nullptr,std::move(
ReplacementFor_content_receiver),nullptr);}Result ReplacementFor_ClientImpl::Get
(const char*ReplacementFor_path,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return Get(ReplacementFor_path,ReplacementFor_Headers(),nullptr,std::move(
ReplacementFor_content_receiver),std::move(ReplacementFor_progress));}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver){return Get(ReplacementFor_path,
ReplacementFor_headers,nullptr,std::move(ReplacementFor_content_receiver),
nullptr);}Result ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress){return Get(ReplacementFor_path,
ReplacementFor_headers,nullptr,std::move(ReplacementFor_content_receiver),std::
move(ReplacementFor_progress));}Result ReplacementFor_ClientImpl::Get(const char
*ReplacementFor_path,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver){return Get(ReplacementFor_path,
ReplacementFor_Headers(),std::move(ReplacementFor_response_handler),std::move(
ReplacementFor_content_receiver),nullptr);}Result ReplacementFor_ClientImpl::Get
(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver){return Get(ReplacementFor_path,
ReplacementFor_headers,std::move(ReplacementFor_response_handler),std::move(
ReplacementFor_content_receiver),nullptr);}Result ReplacementFor_ClientImpl::Get
(const char*ReplacementFor_path,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return Get(ReplacementFor_path,ReplacementFor_Headers(),std::move(
ReplacementFor_response_handler),std::move(ReplacementFor_content_receiver),std
::move(ReplacementFor_progress));}Result ReplacementFor_ClientImpl::Get(const 
char*ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ResponseHandler ReplacementFor_response_handler,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress){ReplacementFor_Request 
ReplacementFor_req;ReplacementFor_req.ReplacementFor_method="\x47\x45\x54";
ReplacementFor_req.ReplacementFor_path=ReplacementFor_path;ReplacementFor_req.
ReplacementFor_headers=ReplacementFor_headers;ReplacementFor_req.
ReplacementFor_response_handler=std::move(ReplacementFor_response_handler);
ReplacementFor_req.ReplacementFor_content_receiver=[
ReplacementFor_content_receiver](const char*data,size_t 
ReplacementFor_data_length,uint64_t,uint64_t){return 
ReplacementFor_content_receiver(data,ReplacementFor_data_length);};
ReplacementFor_req.ReplacementFor_progress=std::move(ReplacementFor_progress);
return ReplacementFor_send_(std::move(ReplacementFor_req));}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_Progress ReplacementFor_progress){if(
ReplacementFor_params.empty()){return Get(ReplacementFor_path,
ReplacementFor_headers);}std::string ReplacementFor_path_with_query=
ReplacementFor_detail::ReplacementFor_append_query_params(ReplacementFor_path,
ReplacementFor_params);return Get(ReplacementFor_path_with_query.c_str(),
ReplacementFor_headers,ReplacementFor_progress);}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return Get(ReplacementFor_path,ReplacementFor_params,ReplacementFor_headers,
nullptr,ReplacementFor_content_receiver,ReplacementFor_progress);}Result 
ReplacementFor_ClientImpl::Get(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{if(ReplacementFor_params.empty()){return Get(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_response_handler,
ReplacementFor_content_receiver,ReplacementFor_progress);}std::string 
ReplacementFor_path_with_query=ReplacementFor_detail::
ReplacementFor_append_query_params(ReplacementFor_path,ReplacementFor_params);
return Get(ReplacementFor_path_with_query.c_str(),ReplacementFor_params,
ReplacementFor_headers,ReplacementFor_response_handler,
ReplacementFor_content_receiver,ReplacementFor_progress);}Result 
ReplacementFor_ClientImpl::Head(const char*ReplacementFor_path){return Head(
ReplacementFor_path,ReplacementFor_Headers());}Result ReplacementFor_ClientImpl
::Head(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers){ReplacementFor_Request ReplacementFor_req;
ReplacementFor_req.ReplacementFor_method="\x48\x45\x41\x44";ReplacementFor_req.
ReplacementFor_headers=ReplacementFor_headers;ReplacementFor_req.
ReplacementFor_path=ReplacementFor_path;return ReplacementFor_send_(std::move(
ReplacementFor_req));}Result ReplacementFor_ClientImpl::ReplacementFor_Post(
const char*ReplacementFor_path){return ReplacementFor_Post(ReplacementFor_path,
std::string(),nullptr);}Result ReplacementFor_ClientImpl::ReplacementFor_Post(
const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_body,ReplacementFor_content_length,ReplacementFor_content_type);}
Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
char*ReplacementFor_body,size_t ReplacementFor_content_length,const char*
ReplacementFor_content_type){return ReplacementFor_send_with_content_provider(
"\x50\x4f\x53\x54",ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_length,nullptr,nullptr,
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
ReplacementFor_Post(const char*ReplacementFor_path,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_body,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Post(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x4f\x53\x54",ReplacementFor_path
,ReplacementFor_headers,ReplacementFor_body.data(),ReplacementFor_body.size(),
nullptr,nullptr,ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Params&
ReplacementFor_params){return ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_Headers(),ReplacementFor_params);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Post(const char*ReplacementFor_path,
size_t ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_content_length,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
ReplacementFor_Post(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_Post(
ReplacementFor_path,ReplacementFor_Headers(),std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Post(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x4f\x53\x54",ReplacementFor_path
,ReplacementFor_headers,nullptr,ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),nullptr,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Post(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x4f\x53\x54",ReplacementFor_path
,ReplacementFor_headers,nullptr,((0x1849+1007-0x14bc)+(0x126f+5441-0x241d)-
(0x220d+1723-0x1db9)),nullptr,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const ReplacementFor_Params&ReplacementFor_params){auto 
ReplacementFor_query=ReplacementFor_detail::ReplacementFor_params_to_query_str(
ReplacementFor_params);return ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_query,
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
);}Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char*
ReplacementFor_path,const ReplacementFor_MultipartFormDataItems&
ReplacementFor_items){return ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_Headers(),ReplacementFor_items);}Result ReplacementFor_ClientImpl
::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const 
ReplacementFor_MultipartFormDataItems&ReplacementFor_items){return 
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_items,ReplacementFor_detail::
ReplacementFor_make_multipart_data_boundary());}Result ReplacementFor_ClientImpl
::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const 
ReplacementFor_MultipartFormDataItems&ReplacementFor_items,const std::string&
ReplacementFor_boundary){for(size_t i=((0x1866+235-0x36e)+(0x1a64+1820-0x12dc)-
9351);i<ReplacementFor_boundary.size();i++){char c=ReplacementFor_boundary[i];if
(!std::isalnum(c)&&c!=((char)((0xd8b+3169-0x1230)+(0x2238+1769-0x22b4)-
(0x1d13+2302-0x1815)))&&c!=((char)((0x1ae4+2006-0x1f56)+(0x23e7+4455-0x1ab3)-
7584))){return Result{nullptr,Error::
ReplacementFor_UnsupportedMultipartBoundaryChars};}}std::string 
ReplacementFor_body;for(const auto&item:ReplacementFor_items){
ReplacementFor_body+="\x2d\x2d"+ReplacementFor_boundary+"\r\n";
ReplacementFor_body+=
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x44\x69\x73\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x20\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b\x20\x6e\x61\x6d\x65\x3d"
"\""+item.name+"\"";if(!item.ReplacementFor_filename.empty()){
ReplacementFor_body+="\x3b\x20\x66\x69\x6c\x65\x6e\x61\x6d\x65\x3d""\""+item.
ReplacementFor_filename+"\"";}ReplacementFor_body+="\r\n";if(!item.
ReplacementFor_content_type.empty()){ReplacementFor_body+=
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20"+item.
ReplacementFor_content_type+"\r\n";}ReplacementFor_body+="\r\n";
ReplacementFor_body+=item.ReplacementFor_content+"\r\n";}ReplacementFor_body+=
"\x2d\x2d"+ReplacementFor_boundary+"\x2d\x2d""\r\n";std::string 
ReplacementFor_content_type=
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b\x20\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d"
+ReplacementFor_boundary;return ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_body,ReplacementFor_content_type.c_str());
}Result ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path){return 
Put(ReplacementFor_path,std::string(),nullptr);}Result ReplacementFor_ClientImpl
::Put(const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return Put
(ReplacementFor_path,ReplacementFor_Headers(),ReplacementFor_body,
ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const char*ReplacementFor_body,
size_t ReplacementFor_content_length,const char*ReplacementFor_content_type){
return ReplacementFor_send_with_content_provider("\x50\x55\x54",
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_body,
ReplacementFor_content_length,nullptr,nullptr,ReplacementFor_content_type);}
Result ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,const std::
string&ReplacementFor_body,const char*ReplacementFor_content_type){return Put(
ReplacementFor_path,ReplacementFor_Headers(),ReplacementFor_body,
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::Put(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
std::string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x55\x54",ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_body.data(),ReplacementFor_body.size(),
nullptr,nullptr,ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
Put(const char*ReplacementFor_path,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type){return Put(ReplacementFor_path,
ReplacementFor_Headers(),ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return Put(ReplacementFor_path,
ReplacementFor_Headers(),std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::Put(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x55\x54",ReplacementFor_path,
ReplacementFor_headers,nullptr,ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),nullptr,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x55\x54",ReplacementFor_path,
ReplacementFor_headers,nullptr,((0x1d25+570-0x18ce)+7275-(0x26b4+2047-0xbb7)),
nullptr,std::move(ReplacementFor_content_provider),ReplacementFor_content_type);
}Result ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params){return Put(ReplacementFor_path,
ReplacementFor_Headers(),ReplacementFor_params);}Result 
ReplacementFor_ClientImpl::Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const ReplacementFor_Params&
ReplacementFor_params){auto ReplacementFor_query=ReplacementFor_detail::
ReplacementFor_params_to_query_str(ReplacementFor_params);return Put(
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_query,
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
);}Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*
ReplacementFor_path){return ReplacementFor_Patch(ReplacementFor_path,std::string
(),nullptr);}Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*
ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_Patch(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_body,ReplacementFor_content_length,ReplacementFor_content_type);}
Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
char*ReplacementFor_body,size_t ReplacementFor_content_length,const char*
ReplacementFor_content_type){return ReplacementFor_send_with_content_provider(
"\x50\x41\x54\x43\x48",ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_length,nullptr,nullptr,
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
ReplacementFor_Patch(const char*ReplacementFor_path,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_Patch(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_body,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x41\x54\x43\x48",
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_body.data(),
ReplacementFor_body.size(),nullptr,nullptr,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*ReplacementFor_path,
size_t ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_Patch(ReplacementFor_path,ReplacementFor_Headers(),
ReplacementFor_content_length,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::
ReplacementFor_Patch(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_Patch(
ReplacementFor_path,ReplacementFor_Headers(),std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*ReplacementFor_path,
const ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x41\x54\x43\x48",
ReplacementFor_path,ReplacementFor_headers,nullptr,ReplacementFor_content_length
,std::move(ReplacementFor_content_provider),nullptr,ReplacementFor_content_type)
;}Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return 
ReplacementFor_send_with_content_provider("\x50\x41\x54\x43\x48",
ReplacementFor_path,ReplacementFor_headers,nullptr,((0x16bd+4791-0x1732)+
(0x659+6646-0x1e93)-5118),nullptr,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::Delete(const 
char*ReplacementFor_path){return Delete(ReplacementFor_path,
ReplacementFor_Headers(),std::string(),nullptr);}Result 
ReplacementFor_ClientImpl::Delete(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers){return Delete(ReplacementFor_path
,ReplacementFor_headers,std::string(),nullptr);}Result ReplacementFor_ClientImpl
::Delete(const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
Delete(ReplacementFor_path,ReplacementFor_Headers(),ReplacementFor_body,
ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Delete(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const char*ReplacementFor_body,
size_t ReplacementFor_content_length,const char*ReplacementFor_content_type){
ReplacementFor_Request ReplacementFor_req;ReplacementFor_req.
ReplacementFor_method="\x44\x45\x4c\x45\x54\x45";ReplacementFor_req.
ReplacementFor_headers=ReplacementFor_headers;ReplacementFor_req.
ReplacementFor_path=ReplacementFor_path;if(ReplacementFor_content_type){
ReplacementFor_req.ReplacementFor_headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",ReplacementFor_content_type);
}ReplacementFor_req.ReplacementFor_body.assign(ReplacementFor_body,
ReplacementFor_content_length);return ReplacementFor_send_(std::move(
ReplacementFor_req));}Result ReplacementFor_ClientImpl::Delete(const char*
ReplacementFor_path,const std::string&ReplacementFor_body,const char*
ReplacementFor_content_type){return Delete(ReplacementFor_path,
ReplacementFor_Headers(),ReplacementFor_body.data(),ReplacementFor_body.size(),
ReplacementFor_content_type);}Result ReplacementFor_ClientImpl::Delete(const 
char*ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
const std::string&ReplacementFor_body,const char*ReplacementFor_content_type){
return Delete(ReplacementFor_path,ReplacementFor_headers,ReplacementFor_body.
data(),ReplacementFor_body.size(),ReplacementFor_content_type);}Result 
ReplacementFor_ClientImpl::Options(const char*ReplacementFor_path){return 
Options(ReplacementFor_path,ReplacementFor_Headers());}Result 
ReplacementFor_ClientImpl::Options(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers){ReplacementFor_Request 
ReplacementFor_req;ReplacementFor_req.ReplacementFor_method=
"\x4f\x50\x54\x49\x4f\x4e\x53";ReplacementFor_req.ReplacementFor_headers=
ReplacementFor_headers;ReplacementFor_req.ReplacementFor_path=
ReplacementFor_path;return ReplacementFor_send_(std::move(ReplacementFor_req));}
size_t ReplacementFor_ClientImpl::ReplacementFor_is_socket_open()const{std::
lock_guard<std::mutex>ReplacementFor_guard(ReplacementFor_socket_mutex_);return 
ReplacementFor_socket_.is_open();}void ReplacementFor_ClientImpl::
ReplacementFor_stop(){std::lock_guard<std::mutex>ReplacementFor_guard(
ReplacementFor_socket_mutex_);if(ReplacementFor_socket_requests_in_flight_>(
(0x2214+1523-0xb86)+(0x472+2127-0xa83)-(0x2554+8194-0x2697))){
ReplacementFor_shutdown_socket(ReplacementFor_socket_);
ReplacementFor_socket_should_be_closed_when_request_is_done_=true;return;}
ReplacementFor_shutdown_ssl(ReplacementFor_socket_,true);
ReplacementFor_shutdown_socket(ReplacementFor_socket_);
ReplacementFor_close_socket(ReplacementFor_socket_);}void 
ReplacementFor_ClientImpl::ReplacementFor_set_connection_timeout(time_t sec,
time_t ReplacementFor_usec){ReplacementFor_connection_timeout_sec_=sec;
ReplacementFor_connection_timeout_usec_=ReplacementFor_usec;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_read_timeout(time_t sec,time_t 
ReplacementFor_usec){ReplacementFor_read_timeout_sec_=sec;
ReplacementFor_read_timeout_usec_=ReplacementFor_usec;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_write_timeout(time_t sec,time_t 
ReplacementFor_usec){ReplacementFor_write_timeout_sec_=sec;
ReplacementFor_write_timeout_usec_=ReplacementFor_usec;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_basic_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){
ReplacementFor_basic_auth_username_=ReplacementFor_username;
ReplacementFor_basic_auth_password_=ReplacementFor_password;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_bearer_token_auth(const char*
ReplacementFor_token){ReplacementFor_bearer_token_auth_token_=
ReplacementFor_token;}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_ClientImpl::ReplacementFor_set_digest_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){
ReplacementFor_digest_auth_username_=ReplacementFor_username;
ReplacementFor_digest_auth_password_=ReplacementFor_password;}
#endif
void ReplacementFor_ClientImpl::ReplacementFor_set_keep_alive(bool 
ReplacementFor_on){ReplacementFor_keep_alive_=ReplacementFor_on;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_follow_location(bool 
ReplacementFor_on){ReplacementFor_follow_location_=ReplacementFor_on;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_default_headers(
ReplacementFor_Headers ReplacementFor_headers){ReplacementFor_default_headers_=
std::move(ReplacementFor_headers);}void ReplacementFor_ClientImpl::
ReplacementFor_set_tcp_nodelay(bool ReplacementFor_on){
ReplacementFor_tcp_nodelay_=ReplacementFor_on;}void ReplacementFor_ClientImpl::
ReplacementFor_set_socket_options(ReplacementFor_SocketOptions 
ReplacementFor_socket_options){ReplacementFor_socket_options_=std::move(
ReplacementFor_socket_options);}void ReplacementFor_ClientImpl::
ReplacementFor_set_compress(bool ReplacementFor_on){ReplacementFor_compress_=
ReplacementFor_on;}void ReplacementFor_ClientImpl::ReplacementFor_set_decompress
(bool ReplacementFor_on){ReplacementFor_decompress_=ReplacementFor_on;}void 
ReplacementFor_ClientImpl::ReplacementFor_set_interface(const char*intf){
ReplacementFor_interface_=intf;}void ReplacementFor_ClientImpl::
ReplacementFor_set_proxy(const char*ReplacementFor_host,int ReplacementFor_port)
{ReplacementFor_proxy_host_=ReplacementFor_host;ReplacementFor_proxy_port_=
ReplacementFor_port;}void ReplacementFor_ClientImpl::
ReplacementFor_set_proxy_basic_auth(const char*ReplacementFor_username,const 
char*ReplacementFor_password){ReplacementFor_proxy_basic_auth_username_=
ReplacementFor_username;ReplacementFor_proxy_basic_auth_password_=
ReplacementFor_password;}void ReplacementFor_ClientImpl::
ReplacementFor_set_proxy_bearer_token_auth(const char*ReplacementFor_token){
ReplacementFor_proxy_bearer_token_auth_token_=ReplacementFor_token;}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_ClientImpl::ReplacementFor_set_proxy_digest_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){
ReplacementFor_proxy_digest_auth_username_=ReplacementFor_username;
ReplacementFor_proxy_digest_auth_password_=ReplacementFor_password;}
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_ClientImpl::
ReplacementFor_enable_server_certificate_verification(bool 
ReplacementFor_enabled){ReplacementFor_server_certificate_verification_=
ReplacementFor_enabled;}
#endif
void ReplacementFor_ClientImpl::ReplacementFor_set_logger(ReplacementFor_Logger 
ReplacementFor_logger){ReplacementFor_logger_=std::move(ReplacementFor_logger);}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
namespace ReplacementFor_detail{template<typename U,typename ReplacementFor_V>
ReplacementFor_SSL*ReplacementFor_ssl_new(ReplacementFor_socket_t 
ReplacementFor_sock,ReplacementFor_SSL_CTX*ctx,std::mutex&
ReplacementFor_ctx_mutex,U ReplacementFor_SSL_connect_or_accept,ReplacementFor_V
 ReplacementFor_setup){ReplacementFor_SSL*ReplacementFor_ssl=nullptr;{std::
lock_guard<std::mutex>ReplacementFor_guard(ReplacementFor_ctx_mutex);
ReplacementFor_ssl=ReplacementFor_SSL_new(ctx);}if(ReplacementFor_ssl){
ReplacementFor_set_nonblocking(ReplacementFor_sock,true);auto ReplacementFor_bio
=ReplacementFor_BIO_new_socket(static_cast<int>(ReplacementFor_sock),
ReplacementFor_BIO_NOCLOSE);ReplacementFor_BIO_set_nbio(ReplacementFor_bio,(8602
+(0x284+2410-0xae5)-8866));ReplacementFor_SSL_set_bio(ReplacementFor_ssl,
ReplacementFor_bio,ReplacementFor_bio);if(!ReplacementFor_setup(
ReplacementFor_ssl)||ReplacementFor_SSL_connect_or_accept(ReplacementFor_ssl)!=(
(0x1f0b+2674-0x1b61)+(0xa7b+1766-0x109d)-(0x15cc+1468-0xca9))){
ReplacementFor_SSL_shutdown(ReplacementFor_ssl);{std::lock_guard<std::mutex>
ReplacementFor_guard(ReplacementFor_ctx_mutex);ReplacementFor_SSL_free(
ReplacementFor_ssl);}ReplacementFor_set_nonblocking(ReplacementFor_sock,false);
return nullptr;}ReplacementFor_BIO_set_nbio(ReplacementFor_bio,(
(0x1f58+8729-0x259c)+(0x998+1375-0x7d8)-8948));ReplacementFor_set_nonblocking(
ReplacementFor_sock,false);}return ReplacementFor_ssl;}void 
ReplacementFor_ssl_delete(std::mutex&ReplacementFor_ctx_mutex,ReplacementFor_SSL
*ReplacementFor_ssl,bool ReplacementFor_shutdown_gracefully){if(
ReplacementFor_shutdown_gracefully){ReplacementFor_SSL_shutdown(
ReplacementFor_ssl);}std::lock_guard<std::mutex>ReplacementFor_guard(
ReplacementFor_ctx_mutex);ReplacementFor_SSL_free(ReplacementFor_ssl);}template<
typename U>bool ReplacementFor_ssl_connect_or_accept_nonblocking(
ReplacementFor_socket_t ReplacementFor_sock,ReplacementFor_SSL*
ReplacementFor_ssl,U ReplacementFor_ssl_connect_or_accept,time_t 
ReplacementFor_timeout_sec,time_t ReplacementFor_timeout_usec){int 
ReplacementFor_res=(4310+(0x1291+4671-0x2473)-(0x2637+1347-0x1a47));while((
ReplacementFor_res=ReplacementFor_ssl_connect_or_accept(ReplacementFor_ssl))!=(
(0xdc9+8018-0x21db)+3892-6771)){auto err=ReplacementFor_SSL_get_error(
ReplacementFor_ssl,ReplacementFor_res);switch(err){case 
ReplacementFor_SSL_ERROR_WANT_READ:if(ReplacementFor_select_read(
ReplacementFor_sock,ReplacementFor_timeout_sec,ReplacementFor_timeout_usec)>(
(0x198c+2166-0x950)+(0xd88+2645-0x11b7)-7896)){continue;}break;case 
ReplacementFor_SSL_ERROR_WANT_WRITE:if(ReplacementFor_select_write(
ReplacementFor_sock,ReplacementFor_timeout_sec,ReplacementFor_timeout_usec)>(
(0x304+1496-0x8d2)+3926-(0x17dc+3130-0x14b6))){continue;}break;default:break;}
return false;}return true;}template<typename T>bool 
ReplacementFor_process_server_socket_ssl(ReplacementFor_SSL*ReplacementFor_ssl,
ReplacementFor_socket_t ReplacementFor_sock,size_t 
ReplacementFor_keep_alive_max_count,time_t ReplacementFor_keep_alive_timeout_sec
,time_t ReplacementFor_read_timeout_sec,time_t ReplacementFor_read_timeout_usec,
time_t ReplacementFor_write_timeout_sec,time_t ReplacementFor_write_timeout_usec
,T ReplacementFor_callback){return ReplacementFor_process_server_socket_core(
ReplacementFor_sock,ReplacementFor_keep_alive_max_count,
ReplacementFor_keep_alive_timeout_sec,[&](bool ReplacementFor_close_connection,
bool&ReplacementFor_connection_closed){ReplacementFor_SSLSocketStream 
ReplacementFor_strm(ReplacementFor_sock,ReplacementFor_ssl,
ReplacementFor_read_timeout_sec,ReplacementFor_read_timeout_usec,
ReplacementFor_write_timeout_sec,ReplacementFor_write_timeout_usec);return 
ReplacementFor_callback(ReplacementFor_strm,ReplacementFor_close_connection,
ReplacementFor_connection_closed);});}template<typename T>bool 
ReplacementFor_process_client_socket_ssl(ReplacementFor_SSL*ReplacementFor_ssl,
ReplacementFor_socket_t ReplacementFor_sock,time_t 
ReplacementFor_read_timeout_sec,time_t ReplacementFor_read_timeout_usec,time_t 
ReplacementFor_write_timeout_sec,time_t ReplacementFor_write_timeout_usec,T 
ReplacementFor_callback){ReplacementFor_SSLSocketStream ReplacementFor_strm(
ReplacementFor_sock,ReplacementFor_ssl,ReplacementFor_read_timeout_sec,
ReplacementFor_read_timeout_usec,ReplacementFor_write_timeout_sec,
ReplacementFor_write_timeout_usec);return ReplacementFor_callback(
ReplacementFor_strm);}
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x10100000L
static std::shared_ptr<std::vector<std::mutex>>ReplacementFor_openSSL_locks_;
class ReplacementFor_SSLThreadLocks{public:ReplacementFor_SSLThreadLocks(){
ReplacementFor_openSSL_locks_=std::make_shared<std::vector<std::mutex>>(
ReplacementFor_CRYPTO_num_locks());ReplacementFor_CRYPTO_set_locking_callback(
ReplacementFor_locking_callback);}~ReplacementFor_SSLThreadLocks(){
ReplacementFor_CRYPTO_set_locking_callback(nullptr);}private:static void 
ReplacementFor_locking_callback(int ReplacementFor_mode,int type,const char*,int
){auto&ReplacementFor_lk=(*ReplacementFor_openSSL_locks_)[static_cast<size_t>(
type)];if(ReplacementFor_mode&ReplacementFor_CRYPTO_LOCK){ReplacementFor_lk.lock
();}else{ReplacementFor_lk.unlock();}}};
#endif
class ReplacementFor_SSLInit{public:ReplacementFor_SSLInit(){
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x1010001fL
ReplacementFor_SSL_load_error_strings();ReplacementFor_SSL_library_init();
#else
ReplacementFor_OPENSSL_init_ssl(ReplacementFor_OPENSSL_INIT_LOAD_SSL_STRINGS|
ReplacementFor_OPENSSL_INIT_LOAD_CRYPTO_STRINGS,NULL);
#endif
}~ReplacementFor_SSLInit(){
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x1010001fL
ReplacementFor_ERR_free_strings();
#endif
}private:
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x10100000L
ReplacementFor_SSLThreadLocks ReplacementFor_thread_init_;
#endif
};ReplacementFor_SSLSocketStream::ReplacementFor_SSLSocketStream(
ReplacementFor_socket_t ReplacementFor_sock,ReplacementFor_SSL*
ReplacementFor_ssl,time_t ReplacementFor_read_timeout_sec,time_t 
ReplacementFor_read_timeout_usec,time_t ReplacementFor_write_timeout_sec,time_t 
ReplacementFor_write_timeout_usec):ReplacementFor_sock_(ReplacementFor_sock),
ReplacementFor_ssl_(ReplacementFor_ssl),ReplacementFor_read_timeout_sec_(
ReplacementFor_read_timeout_sec),ReplacementFor_read_timeout_usec_(
ReplacementFor_read_timeout_usec),ReplacementFor_write_timeout_sec_(
ReplacementFor_write_timeout_sec),ReplacementFor_write_timeout_usec_(
ReplacementFor_write_timeout_usec){ReplacementFor_SSL_clear_mode(
ReplacementFor_ssl,ReplacementFor_SSL_MODE_AUTO_RETRY);}
ReplacementFor_SSLSocketStream::~ReplacementFor_SSLSocketStream(){}bool 
ReplacementFor_SSLSocketStream::ReplacementFor_is_readable()const{return 
ReplacementFor_detail::ReplacementFor_select_read(ReplacementFor_sock_,
ReplacementFor_read_timeout_sec_,ReplacementFor_read_timeout_usec_)>(
(0x221f+1149-0x1c3d)+(0x2223+4920-0x263b)-6527);}bool 
ReplacementFor_SSLSocketStream::ReplacementFor_is_writable()const{return 
ReplacementFor_detail::ReplacementFor_select_write(ReplacementFor_sock_,
ReplacementFor_write_timeout_sec_,ReplacementFor_write_timeout_usec_)>(
(0x1bea+3478-0x2531)+(0x18bf+3786-0x1244)-6548);}ssize_t 
ReplacementFor_SSLSocketStream::read(char*ReplacementFor_ptr,size_t size){if(
ReplacementFor_SSL_pending(ReplacementFor_ssl_)>((0x856+3997-0x163f)+
(0x1b77+4158-0x1ba4)-4549)){return ReplacementFor_SSL_read(ReplacementFor_ssl_,
ReplacementFor_ptr,static_cast<int>(size));}else if(ReplacementFor_is_readable()
){auto ReplacementFor_ret=ReplacementFor_SSL_read(ReplacementFor_ssl_,
ReplacementFor_ptr,static_cast<int>(size));if(ReplacementFor_ret<(5423+
(0x11dd+3968-0x1d66)-(0x222b+63-0x944))){auto err=ReplacementFor_SSL_get_error(
ReplacementFor_ssl_,ReplacementFor_ret);while(err==
ReplacementFor_SSL_ERROR_WANT_READ){if(ReplacementFor_SSL_pending(
ReplacementFor_ssl_)>((0x2002+2557-0x26b7)+(0x20b5+1109-0x6f9)-
(0x240d+4398-0x13e2))){return ReplacementFor_SSL_read(ReplacementFor_ssl_,
ReplacementFor_ptr,static_cast<int>(size));}else if(ReplacementFor_is_readable()
){ReplacementFor_ret=ReplacementFor_SSL_read(ReplacementFor_ssl_,
ReplacementFor_ptr,static_cast<int>(size));if(ReplacementFor_ret>=(8448+
(0x109c+3621-0x1dad)-8724)){return ReplacementFor_ret;}err=
ReplacementFor_SSL_get_error(ReplacementFor_ssl_,ReplacementFor_ret);}else{
return-((0x1326+6404-0x25c0)+(0x20a0+292-0x1a05)-(0x220a+230-0x14c8));}}}return 
ReplacementFor_ret;}return-((0x1696+4069-0x1ac1)+(0x1838+3166-0x1dbc)-
(0x13cc+7135-0x1d18));}ssize_t ReplacementFor_SSLSocketStream::write(const char*
ReplacementFor_ptr,size_t size){if(ReplacementFor_is_writable()){return 
ReplacementFor_SSL_write(ReplacementFor_ssl_,ReplacementFor_ptr,static_cast<int>
(size));}return-((0x1c47+3658-0x1dcf)+(0x24d8+4237-0x1e61)-(0x252a+5979-0x18c0))
;}void ReplacementFor_SSLSocketStream::ReplacementFor_get_remote_ip_and_port(std
::string&ReplacementFor_ip,int&ReplacementFor_port)const{ReplacementFor_detail::
ReplacementFor_get_remote_ip_and_port(ReplacementFor_sock_,ReplacementFor_ip,
ReplacementFor_port);}ReplacementFor_socket_t ReplacementFor_SSLSocketStream::
socket()const{return ReplacementFor_sock_;}static ReplacementFor_SSLInit 
ReplacementFor_sslinit_;}ReplacementFor_SSLServer::ReplacementFor_SSLServer(
const char*ReplacementFor_cert_path,const char*ReplacementFor_private_key_path,
const char*ReplacementFor_client_ca_cert_file_path,const char*
ReplacementFor_client_ca_cert_dir_path){ReplacementFor_ctx_=
ReplacementFor_SSL_CTX_new(ReplacementFor_SSLv23_server_method());if(
ReplacementFor_ctx_){ReplacementFor_SSL_CTX_set_options(ReplacementFor_ctx_,
ReplacementFor_SSL_OP_ALL|ReplacementFor_SSL_OP_NO_SSLv2|
ReplacementFor_SSL_OP_NO_SSLv3|ReplacementFor_SSL_OP_NO_COMPRESSION|
ReplacementFor_SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION);if(
ReplacementFor_SSL_CTX_use_certificate_chain_file(ReplacementFor_ctx_,
ReplacementFor_cert_path)!=((0x12e9+5509-0x23de)+4184-5351)||
ReplacementFor_SSL_CTX_use_PrivateKey_file(ReplacementFor_ctx_,
ReplacementFor_private_key_path,ReplacementFor_SSL_FILETYPE_PEM)!=(2184+3346-
(0x1fb8+4060-0x19fb))){ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);
ReplacementFor_ctx_=nullptr;}else if(ReplacementFor_client_ca_cert_file_path||
ReplacementFor_client_ca_cert_dir_path){
ReplacementFor_SSL_CTX_load_verify_locations(ReplacementFor_ctx_,
ReplacementFor_client_ca_cert_file_path,ReplacementFor_client_ca_cert_dir_path);
ReplacementFor_SSL_CTX_set_verify(ReplacementFor_ctx_,
ReplacementFor_SSL_VERIFY_PEER|ReplacementFor_SSL_VERIFY_FAIL_IF_NO_PEER_CERT,
nullptr);}}}ReplacementFor_SSLServer::ReplacementFor_SSLServer(
ReplacementFor_X509*ReplacementFor_cert,ReplacementFor_EVP_PKEY*
ReplacementFor_private_key,ReplacementFor_X509_STORE*
ReplacementFor_client_ca_cert_store){ReplacementFor_ctx_=
ReplacementFor_SSL_CTX_new(ReplacementFor_SSLv23_server_method());if(
ReplacementFor_ctx_){ReplacementFor_SSL_CTX_set_options(ReplacementFor_ctx_,
ReplacementFor_SSL_OP_ALL|ReplacementFor_SSL_OP_NO_SSLv2|
ReplacementFor_SSL_OP_NO_SSLv3|ReplacementFor_SSL_OP_NO_COMPRESSION|
ReplacementFor_SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION);if(
ReplacementFor_SSL_CTX_use_certificate(ReplacementFor_ctx_,ReplacementFor_cert)
!=((0xc68+4056-0x1289)+(0x22a9+5883-0x26be)-(0x211c+4683-0x16cb))||
ReplacementFor_SSL_CTX_use_PrivateKey(ReplacementFor_ctx_,
ReplacementFor_private_key)!=((0x194d+1011-0x1981)+(0x1ef0+3450-0x1ebf)-
(0x1acc+6335-0x2222))){ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);
ReplacementFor_ctx_=nullptr;}else if(ReplacementFor_client_ca_cert_store){
ReplacementFor_SSL_CTX_set_cert_store(ReplacementFor_ctx_,
ReplacementFor_client_ca_cert_store);ReplacementFor_SSL_CTX_set_verify(
ReplacementFor_ctx_,ReplacementFor_SSL_VERIFY_PEER|
ReplacementFor_SSL_VERIFY_FAIL_IF_NO_PEER_CERT,nullptr);}}}
ReplacementFor_SSLServer::~ReplacementFor_SSLServer(){if(ReplacementFor_ctx_){
ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);}}bool ReplacementFor_SSLServer
::ReplacementFor_is_valid()const{return ReplacementFor_ctx_;}bool 
ReplacementFor_SSLServer::ReplacementFor_process_and_close_socket(
ReplacementFor_socket_t ReplacementFor_sock){auto ReplacementFor_ssl=
ReplacementFor_detail::ReplacementFor_ssl_new(ReplacementFor_sock,
ReplacementFor_ctx_,ReplacementFor_ctx_mutex_,[&](ReplacementFor_SSL*
ReplacementFor_ssl){return ReplacementFor_detail::
ReplacementFor_ssl_connect_or_accept_nonblocking(ReplacementFor_sock,
ReplacementFor_ssl,ReplacementFor_SSL_accept,ReplacementFor_read_timeout_sec_,
ReplacementFor_read_timeout_usec_);},[](ReplacementFor_SSL*){return true;});bool
 ReplacementFor_ret=false;if(ReplacementFor_ssl){ReplacementFor_ret=
ReplacementFor_detail::ReplacementFor_process_server_socket_ssl(
ReplacementFor_ssl,ReplacementFor_sock,ReplacementFor_keep_alive_max_count_,
ReplacementFor_keep_alive_timeout_sec_,ReplacementFor_read_timeout_sec_,
ReplacementFor_read_timeout_usec_,ReplacementFor_write_timeout_sec_,
ReplacementFor_write_timeout_usec_,[this,ReplacementFor_ssl](
ReplacementFor_Stream&ReplacementFor_strm,bool ReplacementFor_close_connection,
bool&ReplacementFor_connection_closed){return ReplacementFor_process_request(
ReplacementFor_strm,ReplacementFor_close_connection,
ReplacementFor_connection_closed,[&](ReplacementFor_Request&ReplacementFor_req){
ReplacementFor_req.ReplacementFor_ssl=ReplacementFor_ssl;});});const bool 
ReplacementFor_shutdown_gracefully=ReplacementFor_ret;ReplacementFor_detail::
ReplacementFor_ssl_delete(ReplacementFor_ctx_mutex_,ReplacementFor_ssl,
ReplacementFor_shutdown_gracefully);}ReplacementFor_detail::
ReplacementFor_shutdown_socket(ReplacementFor_sock);ReplacementFor_detail::
ReplacementFor_close_socket(ReplacementFor_sock);return ReplacementFor_ret;}
ReplacementFor_SSLClient::ReplacementFor_SSLClient(const std::string&
ReplacementFor_host):ReplacementFor_SSLClient(ReplacementFor_host,(9116+
(0x2287+85-0x20ae)-9231),std::string(),std::string()){}ReplacementFor_SSLClient
::ReplacementFor_SSLClient(const std::string&ReplacementFor_host,int 
ReplacementFor_port):ReplacementFor_SSLClient(ReplacementFor_host,
ReplacementFor_port,std::string(),std::string()){}ReplacementFor_SSLClient::
ReplacementFor_SSLClient(const std::string&ReplacementFor_host,int 
ReplacementFor_port,const std::string&ReplacementFor_client_cert_path,const std
::string&ReplacementFor_client_key_path):ReplacementFor_ClientImpl(
ReplacementFor_host,ReplacementFor_port,ReplacementFor_client_cert_path,
ReplacementFor_client_key_path){ReplacementFor_ctx_=ReplacementFor_SSL_CTX_new(
ReplacementFor_SSLv23_client_method());ReplacementFor_detail::
ReplacementFor_split(&ReplacementFor_host_[((0x1d1d+2855-0x1394)+
(0x1ff1+3084-0x25ef)-6846)],&ReplacementFor_host_[ReplacementFor_host_.size()],(
(char)((0x2195+1038-0x215c)+(0x20d+4741-0x147c)-(0x1dd9+2066-0x21bc))),[&](const
 char*b,const char*ReplacementFor_e){ReplacementFor_host_components_.
emplace_back(std::string(b,ReplacementFor_e));});if(!
ReplacementFor_client_cert_path.empty()&&!ReplacementFor_client_key_path.empty()
){if(ReplacementFor_SSL_CTX_use_certificate_file(ReplacementFor_ctx_,
ReplacementFor_client_cert_path.c_str(),ReplacementFor_SSL_FILETYPE_PEM)!=(
(0x1d01+39-0x4f8)+3201-9392)||ReplacementFor_SSL_CTX_use_PrivateKey_file(
ReplacementFor_ctx_,ReplacementFor_client_key_path.c_str(),
ReplacementFor_SSL_FILETYPE_PEM)!=((0x188c+7123-0x21f2)+(0xa52+1597-0x107c)-4735
)){ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);ReplacementFor_ctx_=nullptr;
}}}ReplacementFor_SSLClient::ReplacementFor_SSLClient(const std::string&
ReplacementFor_host,int ReplacementFor_port,ReplacementFor_X509*
ReplacementFor_client_cert,ReplacementFor_EVP_PKEY*ReplacementFor_client_key):
ReplacementFor_ClientImpl(ReplacementFor_host,ReplacementFor_port){
ReplacementFor_ctx_=ReplacementFor_SSL_CTX_new(
ReplacementFor_SSLv23_client_method());ReplacementFor_detail::
ReplacementFor_split(&ReplacementFor_host_[((0x2702+272-0x26a7)+
(0x17e8+9308-0x26f3)-(0x22f0+4563-0x1e07))],&ReplacementFor_host_[
ReplacementFor_host_.size()],((char)((0x2489+510-0x1420)+(0x1d47+6317-0x2507)-
8998)),[&](const char*b,const char*ReplacementFor_e){
ReplacementFor_host_components_.emplace_back(std::string(b,ReplacementFor_e));})
;if(ReplacementFor_client_cert!=nullptr&&ReplacementFor_client_key!=nullptr){if(
ReplacementFor_SSL_CTX_use_certificate(ReplacementFor_ctx_,
ReplacementFor_client_cert)!=((0xd24+9370-0x24c2)+(0x1d38+1291-0x1712)-6188)||
ReplacementFor_SSL_CTX_use_PrivateKey(ReplacementFor_ctx_,
ReplacementFor_client_key)!=((0xd43+7054-0x1d21)+(0xafc+4990-0x19ad)-
(0x2390+3889-0x2245))){ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);
ReplacementFor_ctx_=nullptr;}}}ReplacementFor_SSLClient::~
ReplacementFor_SSLClient(){if(ReplacementFor_ctx_){ReplacementFor_SSL_CTX_free(
ReplacementFor_ctx_);}ReplacementFor_SSLClient::ReplacementFor_shutdown_ssl(
ReplacementFor_socket_,true);}bool ReplacementFor_SSLClient::
ReplacementFor_is_valid()const{return ReplacementFor_ctx_;}void 
ReplacementFor_SSLClient::ReplacementFor_set_ca_cert_path(const char*
ReplacementFor_ca_cert_file_path,const char*ReplacementFor_ca_cert_dir_path){if(
ReplacementFor_ca_cert_file_path){ReplacementFor_ca_cert_file_path_=
ReplacementFor_ca_cert_file_path;}if(ReplacementFor_ca_cert_dir_path){
ReplacementFor_ca_cert_dir_path_=ReplacementFor_ca_cert_dir_path;}}void 
ReplacementFor_SSLClient::ReplacementFor_set_ca_cert_store(
ReplacementFor_X509_STORE*ReplacementFor_ca_cert_store){if(
ReplacementFor_ca_cert_store){if(ReplacementFor_ctx_){if(
ReplacementFor_SSL_CTX_get_cert_store(ReplacementFor_ctx_)!=
ReplacementFor_ca_cert_store){ReplacementFor_SSL_CTX_set_cert_store(
ReplacementFor_ctx_,ReplacementFor_ca_cert_store);}}else{
ReplacementFor_X509_STORE_free(ReplacementFor_ca_cert_store);}}}long 
ReplacementFor_SSLClient::ReplacementFor_get_openssl_verify_result()const{return
 ReplacementFor_verify_result_;}ReplacementFor_SSL_CTX*ReplacementFor_SSLClient
::ReplacementFor_ssl_context()const{return ReplacementFor_ctx_;}bool 
ReplacementFor_SSLClient::ReplacementFor_create_and_connect_socket(Socket&socket
,Error&error){return ReplacementFor_is_valid()&&ReplacementFor_ClientImpl::
ReplacementFor_create_and_connect_socket(socket,error);}bool 
ReplacementFor_SSLClient::ReplacementFor_connect_with_proxy(Socket&socket,
ReplacementFor_Response&ReplacementFor_res,bool&ReplacementFor_success,Error&
error){ReplacementFor_success=true;ReplacementFor_Response ReplacementFor_res2;
if(!ReplacementFor_detail::ReplacementFor_process_client_socket(socket.
ReplacementFor_sock,ReplacementFor_read_timeout_sec_,
ReplacementFor_read_timeout_usec_,ReplacementFor_write_timeout_sec_,
ReplacementFor_write_timeout_usec_,[&](ReplacementFor_Stream&ReplacementFor_strm
){ReplacementFor_Request ReplacementFor_req2;ReplacementFor_req2.
ReplacementFor_method="\x43\x4f\x4e\x4e\x45\x43\x54";ReplacementFor_req2.
ReplacementFor_path=ReplacementFor_host_and_port_;return 
ReplacementFor_process_request(ReplacementFor_strm,ReplacementFor_req2,
ReplacementFor_res2,false,error);})){ReplacementFor_shutdown_ssl(socket,true);
ReplacementFor_shutdown_socket(socket);ReplacementFor_close_socket(socket);
ReplacementFor_success=false;return false;}if(ReplacementFor_res2.status==(
(0x1e1b+447-0x12d5)+1554-(0x1965+1698-0xe87))){if(!
ReplacementFor_proxy_digest_auth_username_.empty()&&!
ReplacementFor_proxy_digest_auth_password_.empty()){std::map<std::string,std::
string>ReplacementFor_auth;if(ReplacementFor_detail::
ReplacementFor_parse_www_authenticate(ReplacementFor_res2,ReplacementFor_auth,
true)){ReplacementFor_Response ReplacementFor_res3;if(!ReplacementFor_detail::
ReplacementFor_process_client_socket(socket.ReplacementFor_sock,
ReplacementFor_read_timeout_sec_,ReplacementFor_read_timeout_usec_,
ReplacementFor_write_timeout_sec_,ReplacementFor_write_timeout_usec_,[&](
ReplacementFor_Stream&ReplacementFor_strm){ReplacementFor_Request 
ReplacementFor_req3;ReplacementFor_req3.ReplacementFor_method=
"\x43\x4f\x4e\x4e\x45\x43\x54";ReplacementFor_req3.ReplacementFor_path=
ReplacementFor_host_and_port_;ReplacementFor_req3.ReplacementFor_headers.insert(
ReplacementFor_detail::ReplacementFor_make_digest_authentication_header(
ReplacementFor_req3,ReplacementFor_auth,((0x1aaf+1851-0x1b44)+(0x41b+2785-0xb3b)
-(0xe5a+2770-0xec6)),ReplacementFor_detail::ReplacementFor_random_string((
(0x1ea8+1986-0x17fa)+(0x228b+302-0x224c)-(0x2065+4510-0x2230))),
ReplacementFor_proxy_digest_auth_username_,
ReplacementFor_proxy_digest_auth_password_,true));return 
ReplacementFor_process_request(ReplacementFor_strm,ReplacementFor_req3,
ReplacementFor_res3,false,error);})){ReplacementFor_shutdown_ssl(socket,true);
ReplacementFor_shutdown_socket(socket);ReplacementFor_close_socket(socket);
ReplacementFor_success=false;return false;}}}else{ReplacementFor_res=
ReplacementFor_res2;return false;}}return true;}bool ReplacementFor_SSLClient::
ReplacementFor_load_certs(){bool ReplacementFor_ret=true;std::call_once(
ReplacementFor_initialize_cert_,[&](){std::lock_guard<std::mutex>
ReplacementFor_guard(ReplacementFor_ctx_mutex_);if(!
ReplacementFor_ca_cert_file_path_.empty()){if(!
ReplacementFor_SSL_CTX_load_verify_locations(ReplacementFor_ctx_,
ReplacementFor_ca_cert_file_path_.c_str(),nullptr)){ReplacementFor_ret=false;}}
else if(!ReplacementFor_ca_cert_dir_path_.empty()){if(!
ReplacementFor_SSL_CTX_load_verify_locations(ReplacementFor_ctx_,nullptr,
ReplacementFor_ca_cert_dir_path_.c_str())){ReplacementFor_ret=false;}}else{
#ifdef _WIN32
ReplacementFor_detail::ReplacementFor_load_system_certs_on_windows(
ReplacementFor_SSL_CTX_get_cert_store(ReplacementFor_ctx_));
#else
ReplacementFor_SSL_CTX_set_default_verify_paths(ReplacementFor_ctx_);
#endif
}});return ReplacementFor_ret;}bool ReplacementFor_SSLClient::
ReplacementFor_initialize_ssl(Socket&socket,Error&error){auto ReplacementFor_ssl
=ReplacementFor_detail::ReplacementFor_ssl_new(socket.ReplacementFor_sock,
ReplacementFor_ctx_,ReplacementFor_ctx_mutex_,[&](ReplacementFor_SSL*
ReplacementFor_ssl){if(ReplacementFor_server_certificate_verification_){if(!
ReplacementFor_load_certs()){error=Error::ReplacementFor_SSLLoadingCerts;return 
false;}ReplacementFor_SSL_set_verify(ReplacementFor_ssl,
ReplacementFor_SSL_VERIFY_NONE,nullptr);}if(!ReplacementFor_detail::
ReplacementFor_ssl_connect_or_accept_nonblocking(socket.ReplacementFor_sock,
ReplacementFor_ssl,ReplacementFor_SSL_connect,
ReplacementFor_connection_timeout_sec_,ReplacementFor_connection_timeout_usec_))
{error=Error::ReplacementFor_SSLConnection;return false;}if(
ReplacementFor_server_certificate_verification_){ReplacementFor_verify_result_=
ReplacementFor_SSL_get_verify_result(ReplacementFor_ssl);if(
ReplacementFor_verify_result_!=ReplacementFor_X509_V_OK){error=Error::
ReplacementFor_SSLServerVerification;return false;}auto 
ReplacementFor_server_cert=ReplacementFor_SSL_get_peer_certificate(
ReplacementFor_ssl);if(ReplacementFor_server_cert==nullptr){error=Error::
ReplacementFor_SSLServerVerification;return false;}if(!
ReplacementFor_verify_host(ReplacementFor_server_cert)){ReplacementFor_X509_free
(ReplacementFor_server_cert);error=Error::ReplacementFor_SSLServerVerification;
return false;}ReplacementFor_X509_free(ReplacementFor_server_cert);}return true;
},[&](ReplacementFor_SSL*ReplacementFor_ssl){
ReplacementFor_SSL_set_tlsext_host_name(ReplacementFor_ssl,ReplacementFor_host_.
c_str());return true;});if(ReplacementFor_ssl){socket.ReplacementFor_ssl=
ReplacementFor_ssl;return true;}ReplacementFor_shutdown_socket(socket);
ReplacementFor_close_socket(socket);return false;}void ReplacementFor_SSLClient
::ReplacementFor_shutdown_ssl(Socket&socket,bool 
ReplacementFor_shutdown_gracefully){if(socket.ReplacementFor_sock==
INVALID_SOCKET){assert(socket.ReplacementFor_ssl==nullptr);return;}if(socket.
ReplacementFor_ssl){ReplacementFor_detail::ReplacementFor_ssl_delete(
ReplacementFor_ctx_mutex_,socket.ReplacementFor_ssl,
ReplacementFor_shutdown_gracefully);socket.ReplacementFor_ssl=nullptr;}assert(
socket.ReplacementFor_ssl==nullptr);}bool ReplacementFor_SSLClient::
ReplacementFor_process_socket(const Socket&socket,std::function<bool(
ReplacementFor_Stream&ReplacementFor_strm)>ReplacementFor_callback){assert(
socket.ReplacementFor_ssl);return ReplacementFor_detail::
ReplacementFor_process_client_socket_ssl(socket.ReplacementFor_ssl,socket.
ReplacementFor_sock,ReplacementFor_read_timeout_sec_,
ReplacementFor_read_timeout_usec_,ReplacementFor_write_timeout_sec_,
ReplacementFor_write_timeout_usec_,std::move(ReplacementFor_callback));}bool 
ReplacementFor_SSLClient::ReplacementFor_is_ssl()const{return true;}bool 
ReplacementFor_SSLClient::ReplacementFor_verify_host(ReplacementFor_X509*
ReplacementFor_server_cert)const{return 
ReplacementFor_verify_host_with_subject_alt_name(ReplacementFor_server_cert)||
ReplacementFor_verify_host_with_common_name(ReplacementFor_server_cert);}bool 
ReplacementFor_SSLClient::ReplacementFor_verify_host_with_subject_alt_name(
ReplacementFor_X509*ReplacementFor_server_cert)const{auto ReplacementFor_ret=
false;auto type=ReplacementFor_GEN_DNS;struct in6_addr ReplacementFor_addr6;
struct in_addr addr;size_t ReplacementFor_addr_len=((0x1915+3435-0x1d7f)+
(0x1aef+1184-0x741)-8527);
#ifndef __MINGW32__
if(ReplacementFor_inet_pton(AF_INET6,ReplacementFor_host_.c_str(),&
ReplacementFor_addr6)){type=ReplacementFor_GEN_IPADD;ReplacementFor_addr_len=
sizeof(struct in6_addr);}else if(ReplacementFor_inet_pton(AF_INET,
ReplacementFor_host_.c_str(),&addr)){type=ReplacementFor_GEN_IPADD;
ReplacementFor_addr_len=sizeof(struct in_addr);}
#endif
auto ReplacementFor_alt_names=static_cast<const struct 
ReplacementFor_stack_st_GENERAL_NAME*>(ReplacementFor_X509_get_ext_d2i(
ReplacementFor_server_cert,ReplacementFor_NID_subject_alt_name,nullptr,nullptr))
;if(ReplacementFor_alt_names){auto ReplacementFor_dsn_matched=false;auto 
ReplacementFor_ip_mached=false;auto count=ReplacementFor_sk_GENERAL_NAME_num(
ReplacementFor_alt_names);for(decltype(count)i=((0xa97+1862-0x861)+
(0x116f+1617-0x1324)-3608);i<count&&!ReplacementFor_dsn_matched;i++){auto val=
ReplacementFor_sk_GENERAL_NAME_value(ReplacementFor_alt_names,i);if(val->type==
type){auto name=(const char*)ReplacementFor_ASN1_STRING_get0_data(val->
ReplacementFor_d.ReplacementFor_ia5);auto ReplacementFor_name_len=(size_t)
ReplacementFor_ASN1_STRING_length(val->ReplacementFor_d.ReplacementFor_ia5);
switch(type){case ReplacementFor_GEN_DNS:ReplacementFor_dsn_matched=
ReplacementFor_check_host_name(name,ReplacementFor_name_len);break;case 
ReplacementFor_GEN_IPADD:if(!memcmp(&ReplacementFor_addr6,name,
ReplacementFor_addr_len)||!memcmp(&addr,name,ReplacementFor_addr_len)){
ReplacementFor_ip_mached=true;}break;}}}if(ReplacementFor_dsn_matched||
ReplacementFor_ip_mached){ReplacementFor_ret=true;}}
ReplacementFor_GENERAL_NAMES_free((ReplacementFor_STACK_OF(
ReplacementFor_GENERAL_NAME)*)ReplacementFor_alt_names);return 
ReplacementFor_ret;}bool ReplacementFor_SSLClient::
ReplacementFor_verify_host_with_common_name(ReplacementFor_X509*
ReplacementFor_server_cert)const{const auto ReplacementFor_subject_name=
ReplacementFor_X509_get_subject_name(ReplacementFor_server_cert);if(
ReplacementFor_subject_name!=nullptr){char name[BUFSIZ];auto 
ReplacementFor_name_len=ReplacementFor_X509_NAME_get_text_by_NID(
ReplacementFor_subject_name,ReplacementFor_NID_commonName,name,sizeof(name));if(
ReplacementFor_name_len!=-((0xbad+146-0x8f8)+(0x8f9+6484-0x1b1a)-
(0x2644+1356-0x2117))){return ReplacementFor_check_host_name(name,static_cast<
size_t>(ReplacementFor_name_len));}}return false;}bool ReplacementFor_SSLClient
::ReplacementFor_check_host_name(const char*pattern,size_t 
ReplacementFor_pattern_len)const{if(ReplacementFor_host_.size()==
ReplacementFor_pattern_len&&ReplacementFor_host_==pattern){return true;}std::
vector<std::string>ReplacementFor_pattern_components;ReplacementFor_detail::
ReplacementFor_split(&pattern[((0x1a90+2958-0x16ef)+(0x1889+2594-0x1afd)-
(0x19b1+2662-0xd3a))],&pattern[ReplacementFor_pattern_len],((char)(
(0xd30+8239-0x258b)+(0x1ba4+6716-0x25d3)-(0x1b98+154-0x47f))),[&](const char*b,
const char*ReplacementFor_e){ReplacementFor_pattern_components.emplace_back(std
::string(b,ReplacementFor_e));});if(ReplacementFor_host_components_.size()!=
ReplacementFor_pattern_components.size()){return false;}auto ReplacementFor_itr=
ReplacementFor_pattern_components.begin();for(const auto&ReplacementFor_h:
ReplacementFor_host_components_){auto&p=*ReplacementFor_itr;if(p!=
ReplacementFor_h&&p!="\x2a"){auto ReplacementFor_partial_match=(p.size()>(
(0x21f5+649-0x1ba8)+6516-8778)&&p[p.size()-((0x7ba+4052-0x10ac)+
(0x207f+1202-0x1c65)-(0x1ae6+4115-0x1b4c))]==((char)((0x24d1+4555-0x1689)+
(0xd19+1254-0x11d7)-8209))&&!p.compare(((0xb26+3790-0x166e)+(0x232d+337-0x335)-
9423),p.size()-((0x685+2887-0xe57)+8925-(0x26bf+9095-0x23f5)),ReplacementFor_h))
;if(!ReplacementFor_partial_match){return false;}}++ReplacementFor_itr;}return 
true;}
#endif
ReplacementFor_Client::ReplacementFor_Client(const char*
ReplacementFor_scheme_host_port):ReplacementFor_Client(
ReplacementFor_scheme_host_port,std::string(),std::string()){}
ReplacementFor_Client::ReplacementFor_Client(const char*
ReplacementFor_scheme_host_port,const std::string&
ReplacementFor_client_cert_path,const std::string&ReplacementFor_client_key_path
){const static std::regex ReplacementFor_re(
R"(^(?:([a-z]+)://)?([^:/?#]+)(?::(\d+))?)");std::cmatch m;if(std::regex_match(
ReplacementFor_scheme_host_port,m,ReplacementFor_re)){auto ReplacementFor_scheme
=m[((0x226d+1198-0x107e)+1349-7137)].str();
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
if(!ReplacementFor_scheme.empty()&&(ReplacementFor_scheme!="\x68\x74\x74\x70"&&
ReplacementFor_scheme!="\x68\x74\x74\x70\x73")){
#else
if(!ReplacementFor_scheme.empty()&&ReplacementFor_scheme!="\x68\x74\x74\x70"){
#endif
std::string msg="\x27"+ReplacementFor_scheme+
"\x27\x20\x73\x63\x68\x65\x6d\x65\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x2e"
;throw std::invalid_argument(msg);return;}auto ReplacementFor_is_ssl=
ReplacementFor_scheme=="\x68\x74\x74\x70\x73";auto ReplacementFor_host=m[(
(0xe43+167-0x7a4)+(0x1ec3+6679-0x1eaa)-8564)].str();auto ReplacementFor_port_str
=m[((0x10fa+1885-0xf8a)+(0xfb8+7627-0x1dee)-6239)].str();auto 
ReplacementFor_port=!ReplacementFor_port_str.empty()?std::stoi(
ReplacementFor_port_str):(ReplacementFor_is_ssl?(6259+(0x1527+310-0x1433)-
(0x1d4f+737-0x74e)):((0xc8+9812-0x2672)+(0x20f8+1889-0x925)-8078));if(
ReplacementFor_is_ssl){
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
ReplacementFor_cli_=ReplacementFor_detail::make_unique<ReplacementFor_SSLClient>
(ReplacementFor_host.c_str(),ReplacementFor_port,ReplacementFor_client_cert_path
,ReplacementFor_client_key_path);ReplacementFor_is_ssl_=ReplacementFor_is_ssl;
#endif
}else{ReplacementFor_cli_=ReplacementFor_detail::make_unique<
ReplacementFor_ClientImpl>(ReplacementFor_host.c_str(),ReplacementFor_port,
ReplacementFor_client_cert_path,ReplacementFor_client_key_path);}}else{
ReplacementFor_cli_=ReplacementFor_detail::make_unique<ReplacementFor_ClientImpl
>(ReplacementFor_scheme_host_port,(5226+(0x1271+1657-0x1658)-
(0x1b84+8487-0x25ff)),ReplacementFor_client_cert_path,
ReplacementFor_client_key_path);}}ReplacementFor_Client::ReplacementFor_Client(
const std::string&ReplacementFor_host,int ReplacementFor_port):
ReplacementFor_cli_(ReplacementFor_detail::make_unique<ReplacementFor_ClientImpl
>(ReplacementFor_host,ReplacementFor_port)){}ReplacementFor_Client::
ReplacementFor_Client(const std::string&ReplacementFor_host,int 
ReplacementFor_port,const std::string&ReplacementFor_client_cert_path,const std
::string&ReplacementFor_client_key_path):ReplacementFor_cli_(
ReplacementFor_detail::make_unique<ReplacementFor_ClientImpl>(
ReplacementFor_host,ReplacementFor_port,ReplacementFor_client_cert_path,
ReplacementFor_client_key_path)){}ReplacementFor_Client::~ReplacementFor_Client(
){}bool ReplacementFor_Client::ReplacementFor_is_valid()const{return 
ReplacementFor_cli_!=nullptr&&ReplacementFor_cli_->ReplacementFor_is_valid();}
Result ReplacementFor_Client::Get(const char*ReplacementFor_path){return 
ReplacementFor_cli_->Get(ReplacementFor_path);}Result ReplacementFor_Client::Get
(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers){return ReplacementFor_cli_->Get(ReplacementFor_path,
ReplacementFor_headers);}Result ReplacementFor_Client::Get(const char*
ReplacementFor_path,ReplacementFor_Progress ReplacementFor_progress){return 
ReplacementFor_cli_->Get(ReplacementFor_path,std::move(ReplacementFor_progress))
;}Result ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_Progress 
ReplacementFor_progress){return ReplacementFor_cli_->Get(ReplacementFor_path,
ReplacementFor_headers,std::move(ReplacementFor_progress));}Result 
ReplacementFor_Client::Get(const char*ReplacementFor_path,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver){return 
ReplacementFor_cli_->Get(ReplacementFor_path,std::move(
ReplacementFor_content_receiver));}Result ReplacementFor_Client::Get(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver){return 
ReplacementFor_cli_->Get(ReplacementFor_path,ReplacementFor_headers,std::move(
ReplacementFor_content_receiver));}Result ReplacementFor_Client::Get(const char*
ReplacementFor_path,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return ReplacementFor_cli_->Get(ReplacementFor_path,std::move(
ReplacementFor_content_receiver),std::move(ReplacementFor_progress));}Result 
ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return ReplacementFor_cli_->Get(ReplacementFor_path,ReplacementFor_headers,std
::move(ReplacementFor_content_receiver),std::move(ReplacementFor_progress));}
Result ReplacementFor_Client::Get(const char*ReplacementFor_path,
ReplacementFor_ResponseHandler ReplacementFor_response_handler,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver){return 
ReplacementFor_cli_->Get(ReplacementFor_path,std::move(
ReplacementFor_response_handler),std::move(ReplacementFor_content_receiver));}
Result ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver){return ReplacementFor_cli_->Get(
ReplacementFor_path,ReplacementFor_headers,std::move(
ReplacementFor_response_handler),std::move(ReplacementFor_content_receiver));}
Result ReplacementFor_Client::Get(const char*ReplacementFor_path,
ReplacementFor_ResponseHandler ReplacementFor_response_handler,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress){return ReplacementFor_cli_->Get
(ReplacementFor_path,std::move(ReplacementFor_response_handler),std::move(
ReplacementFor_content_receiver),std::move(ReplacementFor_progress));}Result 
ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return ReplacementFor_cli_->Get(ReplacementFor_path,ReplacementFor_headers,std
::move(ReplacementFor_response_handler),std::move(
ReplacementFor_content_receiver),std::move(ReplacementFor_progress));}Result 
ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_Progress ReplacementFor_progress){return 
ReplacementFor_cli_->Get(ReplacementFor_path,ReplacementFor_params,
ReplacementFor_headers,ReplacementFor_progress);}Result ReplacementFor_Client::
Get(const char*ReplacementFor_path,const ReplacementFor_Params&
ReplacementFor_params,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
ReplacementFor_Progress ReplacementFor_progress){return ReplacementFor_cli_->Get
(ReplacementFor_path,ReplacementFor_params,ReplacementFor_headers,
ReplacementFor_content_receiver,ReplacementFor_progress);}Result 
ReplacementFor_Client::Get(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params,const ReplacementFor_Headers&
ReplacementFor_headers,ReplacementFor_ResponseHandler 
ReplacementFor_response_handler,ReplacementFor_ContentReceiver 
ReplacementFor_content_receiver,ReplacementFor_Progress ReplacementFor_progress)
{return ReplacementFor_cli_->Get(ReplacementFor_path,ReplacementFor_params,
ReplacementFor_headers,ReplacementFor_response_handler,
ReplacementFor_content_receiver,ReplacementFor_progress);}Result 
ReplacementFor_Client::Head(const char*ReplacementFor_path){return 
ReplacementFor_cli_->Head(ReplacementFor_path);}Result ReplacementFor_Client::
Head(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers){return ReplacementFor_cli_->Head(ReplacementFor_path,
ReplacementFor_headers);}Result ReplacementFor_Client::ReplacementFor_Post(const
 char*ReplacementFor_path){return ReplacementFor_cli_->ReplacementFor_Post(
ReplacementFor_path);}Result ReplacementFor_Client::ReplacementFor_Post(const 
char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,ReplacementFor_body
,ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const char*ReplacementFor_body,
size_t ReplacementFor_content_length,const char*ReplacementFor_content_type){
return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_body,ReplacementFor_content_length,
ReplacementFor_content_type);}Result ReplacementFor_Client::ReplacementFor_Post(
const char*ReplacementFor_path,const std::string&ReplacementFor_body,const char*
ReplacementFor_content_type){return ReplacementFor_cli_->ReplacementFor_Post(
ReplacementFor_path,ReplacementFor_body,ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const std::string&
ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_body,ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,size_t
 ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_content_length,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_Client::ReplacementFor_Post(
const char*ReplacementFor_path,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_cli_->
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_headers,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params){return ReplacementFor_cli_->
ReplacementFor_Post(ReplacementFor_path,ReplacementFor_params);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const ReplacementFor_Params&
ReplacementFor_params){return ReplacementFor_cli_->ReplacementFor_Post(
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_params);}Result 
ReplacementFor_Client::ReplacementFor_Post(const char*ReplacementFor_path,const 
ReplacementFor_MultipartFormDataItems&ReplacementFor_items){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_items);}Result ReplacementFor_Client::ReplacementFor_Post(const 
char*ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
const ReplacementFor_MultipartFormDataItems&ReplacementFor_items){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_items);}Result ReplacementFor_Client::
ReplacementFor_Post(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const ReplacementFor_MultipartFormDataItems&
ReplacementFor_items,const std::string&ReplacementFor_boundary){return 
ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_items,ReplacementFor_boundary);}Result 
ReplacementFor_Client::Put(const char*ReplacementFor_path){return 
ReplacementFor_cli_->Put(ReplacementFor_path);}Result ReplacementFor_Client::Put
(const char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_body,
ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_Client::Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const char*ReplacementFor_body,
size_t ReplacementFor_content_length,const char*ReplacementFor_content_type){
return ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_length,ReplacementFor_content_type);}
Result ReplacementFor_Client::Put(const char*ReplacementFor_path,const std::
string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_body,
ReplacementFor_content_type);}Result ReplacementFor_Client::Put(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
std::string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_type);}Result ReplacementFor_Client::
Put(const char*ReplacementFor_path,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type){return ReplacementFor_cli_->Put(ReplacementFor_path
,ReplacementFor_content_length,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_Client::Put(const char*
ReplacementFor_path,ReplacementFor_ContentProviderWithoutLength 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Put(ReplacementFor_path,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::Put(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_content_length,std::move(ReplacementFor_content_provider),
ReplacementFor_content_type);}Result ReplacementFor_Client::Put(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_cli_->Put(
ReplacementFor_path,ReplacementFor_headers,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::Put(const char*ReplacementFor_path,const 
ReplacementFor_Params&ReplacementFor_params){return ReplacementFor_cli_->Put(
ReplacementFor_path,ReplacementFor_params);}Result ReplacementFor_Client::Put(
const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers,const ReplacementFor_Params&ReplacementFor_params){return
 ReplacementFor_cli_->Put(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_params);}Result ReplacementFor_Client::ReplacementFor_Patch(const
 char*ReplacementFor_path){return ReplacementFor_cli_->ReplacementFor_Patch(
ReplacementFor_path);}Result ReplacementFor_Client::ReplacementFor_Patch(const 
char*ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path,
ReplacementFor_body,ReplacementFor_content_length,ReplacementFor_content_type);}
Result ReplacementFor_Client::ReplacementFor_Patch(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
char*ReplacementFor_body,size_t ReplacementFor_content_length,const char*
ReplacementFor_content_type){return ReplacementFor_cli_->ReplacementFor_Patch(
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_body,
ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Patch(const char*ReplacementFor_path,const
 std::string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path,
ReplacementFor_body,ReplacementFor_content_type);}Result ReplacementFor_Client::
ReplacementFor_Patch(const char*ReplacementFor_path,const ReplacementFor_Headers
&ReplacementFor_headers,const std::string&ReplacementFor_body,const char*
ReplacementFor_content_type){return ReplacementFor_cli_->ReplacementFor_Patch(
ReplacementFor_path,ReplacementFor_headers,ReplacementFor_body,
ReplacementFor_content_type);}Result ReplacementFor_Client::ReplacementFor_Patch
(const char*ReplacementFor_path,size_t ReplacementFor_content_length,
ReplacementFor_ContentProvider ReplacementFor_content_provider,const char*
ReplacementFor_content_type){return ReplacementFor_cli_->ReplacementFor_Patch(
ReplacementFor_path,ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Patch(const char*ReplacementFor_path,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_cli_->
ReplacementFor_Patch(ReplacementFor_path,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Patch(const char*ReplacementFor_path,const
 ReplacementFor_Headers&ReplacementFor_headers,size_t 
ReplacementFor_content_length,ReplacementFor_ContentProvider 
ReplacementFor_content_provider,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path,
ReplacementFor_headers,ReplacementFor_content_length,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::ReplacementFor_Patch(const char*ReplacementFor_path,const
 ReplacementFor_Headers&ReplacementFor_headers,
ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
const char*ReplacementFor_content_type){return ReplacementFor_cli_->
ReplacementFor_Patch(ReplacementFor_path,ReplacementFor_headers,std::move(
ReplacementFor_content_provider),ReplacementFor_content_type);}Result 
ReplacementFor_Client::Delete(const char*ReplacementFor_path){return 
ReplacementFor_cli_->Delete(ReplacementFor_path);}Result ReplacementFor_Client::
Delete(const char*ReplacementFor_path,const ReplacementFor_Headers&
ReplacementFor_headers){return ReplacementFor_cli_->Delete(ReplacementFor_path,
ReplacementFor_headers);}Result ReplacementFor_Client::Delete(const char*
ReplacementFor_path,const char*ReplacementFor_body,size_t 
ReplacementFor_content_length,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Delete(ReplacementFor_path,ReplacementFor_body,
ReplacementFor_content_length,ReplacementFor_content_type);}Result 
ReplacementFor_Client::Delete(const char*ReplacementFor_path,const 
ReplacementFor_Headers&ReplacementFor_headers,const char*ReplacementFor_body,
size_t ReplacementFor_content_length,const char*ReplacementFor_content_type){
return ReplacementFor_cli_->Delete(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_length,ReplacementFor_content_type);}
Result ReplacementFor_Client::Delete(const char*ReplacementFor_path,const std::
string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Delete(ReplacementFor_path,ReplacementFor_body,
ReplacementFor_content_type);}Result ReplacementFor_Client::Delete(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers,const 
std::string&ReplacementFor_body,const char*ReplacementFor_content_type){return 
ReplacementFor_cli_->Delete(ReplacementFor_path,ReplacementFor_headers,
ReplacementFor_body,ReplacementFor_content_type);}Result ReplacementFor_Client::
Options(const char*ReplacementFor_path){return ReplacementFor_cli_->Options(
ReplacementFor_path);}Result ReplacementFor_Client::Options(const char*
ReplacementFor_path,const ReplacementFor_Headers&ReplacementFor_headers){return 
ReplacementFor_cli_->Options(ReplacementFor_path,ReplacementFor_headers);}bool 
ReplacementFor_Client::send(ReplacementFor_Request&ReplacementFor_req,
ReplacementFor_Response&ReplacementFor_res,Error&error){return 
ReplacementFor_cli_->send(ReplacementFor_req,ReplacementFor_res,error);}Result 
ReplacementFor_Client::send(const ReplacementFor_Request&ReplacementFor_req){
return ReplacementFor_cli_->send(ReplacementFor_req);}size_t 
ReplacementFor_Client::ReplacementFor_is_socket_open()const{return 
ReplacementFor_cli_->ReplacementFor_is_socket_open();}void ReplacementFor_Client
::ReplacementFor_stop(){ReplacementFor_cli_->ReplacementFor_stop();}void 
ReplacementFor_Client::ReplacementFor_set_default_headers(ReplacementFor_Headers
 ReplacementFor_headers){ReplacementFor_cli_->ReplacementFor_set_default_headers
(std::move(ReplacementFor_headers));}void ReplacementFor_Client::
ReplacementFor_set_tcp_nodelay(bool ReplacementFor_on){ReplacementFor_cli_->
ReplacementFor_set_tcp_nodelay(ReplacementFor_on);}void ReplacementFor_Client::
ReplacementFor_set_socket_options(ReplacementFor_SocketOptions 
ReplacementFor_socket_options){ReplacementFor_cli_->
ReplacementFor_set_socket_options(std::move(ReplacementFor_socket_options));}
void ReplacementFor_Client::ReplacementFor_set_connection_timeout(time_t sec,
time_t ReplacementFor_usec){ReplacementFor_cli_->
ReplacementFor_set_connection_timeout(sec,ReplacementFor_usec);}void 
ReplacementFor_Client::ReplacementFor_set_read_timeout(time_t sec,time_t 
ReplacementFor_usec){ReplacementFor_cli_->ReplacementFor_set_read_timeout(sec,
ReplacementFor_usec);}void ReplacementFor_Client::
ReplacementFor_set_write_timeout(time_t sec,time_t ReplacementFor_usec){
ReplacementFor_cli_->ReplacementFor_set_write_timeout(sec,ReplacementFor_usec);}
void ReplacementFor_Client::ReplacementFor_set_basic_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){ReplacementFor_cli_
->ReplacementFor_set_basic_auth(ReplacementFor_username,ReplacementFor_password)
;}void ReplacementFor_Client::ReplacementFor_set_bearer_token_auth(const char*
ReplacementFor_token){ReplacementFor_cli_->ReplacementFor_set_bearer_token_auth(
ReplacementFor_token);}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::ReplacementFor_set_digest_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){ReplacementFor_cli_
->ReplacementFor_set_digest_auth(ReplacementFor_username,ReplacementFor_password
);}
#endif
void ReplacementFor_Client::ReplacementFor_set_keep_alive(bool ReplacementFor_on
){ReplacementFor_cli_->ReplacementFor_set_keep_alive(ReplacementFor_on);}void 
ReplacementFor_Client::ReplacementFor_set_follow_location(bool ReplacementFor_on
){ReplacementFor_cli_->ReplacementFor_set_follow_location(ReplacementFor_on);}
void ReplacementFor_Client::ReplacementFor_set_compress(bool ReplacementFor_on){
ReplacementFor_cli_->ReplacementFor_set_compress(ReplacementFor_on);}void 
ReplacementFor_Client::ReplacementFor_set_decompress(bool ReplacementFor_on){
ReplacementFor_cli_->ReplacementFor_set_decompress(ReplacementFor_on);}void 
ReplacementFor_Client::ReplacementFor_set_interface(const char*intf){
ReplacementFor_cli_->ReplacementFor_set_interface(intf);}void 
ReplacementFor_Client::ReplacementFor_set_proxy(const char*ReplacementFor_host,
int ReplacementFor_port){ReplacementFor_cli_->ReplacementFor_set_proxy(
ReplacementFor_host,ReplacementFor_port);}void ReplacementFor_Client::
ReplacementFor_set_proxy_basic_auth(const char*ReplacementFor_username,const 
char*ReplacementFor_password){ReplacementFor_cli_->
ReplacementFor_set_proxy_basic_auth(ReplacementFor_username,
ReplacementFor_password);}void ReplacementFor_Client::
ReplacementFor_set_proxy_bearer_token_auth(const char*ReplacementFor_token){
ReplacementFor_cli_->ReplacementFor_set_proxy_bearer_token_auth(
ReplacementFor_token);}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::ReplacementFor_set_proxy_digest_auth(const char*
ReplacementFor_username,const char*ReplacementFor_password){ReplacementFor_cli_
->ReplacementFor_set_proxy_digest_auth(ReplacementFor_username,
ReplacementFor_password);}
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::
ReplacementFor_enable_server_certificate_verification(bool 
ReplacementFor_enabled){ReplacementFor_cli_->
ReplacementFor_enable_server_certificate_verification(ReplacementFor_enabled);}
#endif
void ReplacementFor_Client::ReplacementFor_set_logger(ReplacementFor_Logger 
ReplacementFor_logger){ReplacementFor_cli_->ReplacementFor_set_logger(
ReplacementFor_logger);}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::ReplacementFor_set_ca_cert_path(const char*
ReplacementFor_ca_cert_file_path,const char*ReplacementFor_ca_cert_dir_path){if(
ReplacementFor_is_ssl_){static_cast<ReplacementFor_SSLClient&>(*
ReplacementFor_cli_).ReplacementFor_set_ca_cert_path(
ReplacementFor_ca_cert_file_path,ReplacementFor_ca_cert_dir_path);}}void 
ReplacementFor_Client::ReplacementFor_set_ca_cert_store(
ReplacementFor_X509_STORE*ReplacementFor_ca_cert_store){if(
ReplacementFor_is_ssl_){static_cast<ReplacementFor_SSLClient&>(*
ReplacementFor_cli_).ReplacementFor_set_ca_cert_store(
ReplacementFor_ca_cert_store);}}long ReplacementFor_Client::
ReplacementFor_get_openssl_verify_result()const{if(ReplacementFor_is_ssl_){
return static_cast<ReplacementFor_SSLClient&>(*ReplacementFor_cli_).
ReplacementFor_get_openssl_verify_result();}return-((0x1856+2402-0x1abc)+4414-
(0x1cd3+7013-0x1fff));}ReplacementFor_SSL_CTX*ReplacementFor_Client::
ReplacementFor_ssl_context()const{if(ReplacementFor_is_ssl_){return static_cast<
ReplacementFor_SSLClient&>(*ReplacementFor_cli_).ReplacementFor_ssl_context();}
return nullptr;}
#endif
}

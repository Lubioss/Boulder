
#include "../include/ReplacementFor_jsmn.h"
static ReplacementFor_jsmntok_t*ReplacementFor_jsmn_alloc_token(
ReplacementFor_jsmn_parser*ReplacementFor_parser,ReplacementFor_jsmntok_t*
ReplacementFor_tokens,size_t ReplacementFor_num_tokens){ReplacementFor_jsmntok_t
*ReplacementFor_tok;if(ReplacementFor_parser->ReplacementFor_toknext>=
ReplacementFor_num_tokens){return NULL;}ReplacementFor_tok=&
ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toknext++];
ReplacementFor_tok->ReplacementFor_start=ReplacementFor_tok->end=-(
(0x1c50+3224-0x2590)+(0x232c+4867-0x1d1b)-7275);ReplacementFor_tok->size=(
(0x64a+8452-0x220d)+4979-6324);
#ifdef ReplacementFor_JSMN_PARENT_LINKS
ReplacementFor_tok->ReplacementFor_parent=-((0x1304+1544-0x14a4)+5511-6638);
#endif
return ReplacementFor_tok;}static void ReplacementFor_jsmn_fill_token(
ReplacementFor_jsmntok_t*ReplacementFor_token,ReplacementFor_jsmntype_t type,int
 ReplacementFor_start,int end){ReplacementFor_token->type=type;
ReplacementFor_token->ReplacementFor_start=ReplacementFor_start;
ReplacementFor_token->end=end;ReplacementFor_token->size=(2810+
(0x1ab9+134-0x1a8b)-(0x2688+2320-0x23ea));}static int 
ReplacementFor_jsmn_parse_primitive(ReplacementFor_jsmn_parser*
ReplacementFor_parser,const char*ReplacementFor_js,size_t len,
ReplacementFor_jsmntok_t*ReplacementFor_tokens,size_t ReplacementFor_num_tokens)
{ReplacementFor_jsmntok_t*ReplacementFor_token;int ReplacementFor_start;
ReplacementFor_start=ReplacementFor_parser->pos;for(;ReplacementFor_parser->pos<
len&&ReplacementFor_js[ReplacementFor_parser->pos]!='\0';ReplacementFor_parser->
pos++){switch(ReplacementFor_js[ReplacementFor_parser->pos]){
#ifndef ReplacementFor_JSMN_STRICT
case((char)(3860+(0x1a87+10-0x36e)-9725)):
#endif
case'\t':case'\r':case'\n':case((char)((0x1ba1+761-0xe61)+(0xd4f+2963-0x13e6)-
(0x1ba5+6785-0x2111))):case((char)(3563+(0x1e47+221-0xf9d)-7494)):case((char)(
(0x21e7+5610-0x1d11)+(0x1467+165-0x1139)-7734)):case((char)(8697+
(0x1cd2+78-0x194d)-9551)):goto ReplacementFor_found;}if(ReplacementFor_js[
ReplacementFor_parser->pos]<((0x2316+6113-0x20c2)+(0xe40+7409-0x2424)-8482)||
ReplacementFor_js[ReplacementFor_parser->pos]>=((0x168f+4760-0x1cd2)+5367-
(0x2365+6273-0x1b19))){ReplacementFor_parser->pos=ReplacementFor_start;return 
ReplacementFor_JSMN_ERROR_INVAL;}}
#ifdef ReplacementFor_JSMN_STRICT
ReplacementFor_parser->pos=ReplacementFor_start;return 
ReplacementFor_JSMN_ERROR_PART;
#endif
ReplacementFor_found:if(ReplacementFor_tokens==NULL){ReplacementFor_parser->pos
--;return((0xe56+1998-0x11da)+(0x1509+4355-0x24e6)-(0x13cd+3655-0x1ca4));}
ReplacementFor_token=ReplacementFor_jsmn_alloc_token(ReplacementFor_parser,
ReplacementFor_tokens,ReplacementFor_num_tokens);if(ReplacementFor_token==NULL){
ReplacementFor_parser->pos=ReplacementFor_start;return 
ReplacementFor_JSMN_ERROR_NOMEM;}ReplacementFor_jsmn_fill_token(
ReplacementFor_token,ReplacementFor_JSMN_PRIMITIVE,ReplacementFor_start,
ReplacementFor_parser->pos);
#ifdef ReplacementFor_JSMN_PARENT_LINKS
ReplacementFor_token->ReplacementFor_parent=ReplacementFor_parser->
ReplacementFor_toksuper;
#endif
ReplacementFor_parser->pos--;return((0x2048+3540-0x2234)+(0x1713+2430-0xac4)-
8629);}static int ReplacementFor_jsmn_parse_string(ReplacementFor_jsmn_parser*
ReplacementFor_parser,const char*ReplacementFor_js,size_t len,
ReplacementFor_jsmntok_t*ReplacementFor_tokens,size_t ReplacementFor_num_tokens)
{ReplacementFor_jsmntok_t*ReplacementFor_token;int ReplacementFor_start=
ReplacementFor_parser->pos;ReplacementFor_parser->pos++;for(;
ReplacementFor_parser->pos<len&&ReplacementFor_js[ReplacementFor_parser->pos]!=
'\0';ReplacementFor_parser->pos++){char c=ReplacementFor_js[
ReplacementFor_parser->pos];if(c=='\"'){if(ReplacementFor_tokens==NULL){return(
(0x1b2c+1819-0x1721)+(0x162f+6295-0x1eb5)-(0x2200+1055-0xae8));}
ReplacementFor_token=ReplacementFor_jsmn_alloc_token(ReplacementFor_parser,
ReplacementFor_tokens,ReplacementFor_num_tokens);if(ReplacementFor_token==NULL){
ReplacementFor_parser->pos=ReplacementFor_start;return 
ReplacementFor_JSMN_ERROR_NOMEM;}ReplacementFor_jsmn_fill_token(
ReplacementFor_token,ReplacementFor_JSMN_STRING,ReplacementFor_start+(
(0x11c1+4226-0x1ebc)+(0x1500+1780-0xd42)-(0x20b0+5632-0x2478)),
ReplacementFor_parser->pos);
#ifdef ReplacementFor_JSMN_PARENT_LINKS
ReplacementFor_token->ReplacementFor_parent=ReplacementFor_parser->
ReplacementFor_toksuper;
#endif
return((0x580+8618-0x22f2)+(0x23a8+1728-0xd62)-(0x2657+1542-0xb1f));}if(c=='\\'
&&ReplacementFor_parser->pos+((0x9f0+8365-0x258d)+(0x1baa+1131-0x7c1)-7523)<len)
{int i;ReplacementFor_parser->pos++;switch(ReplacementFor_js[
ReplacementFor_parser->pos]){case'\"':case((char)((0x257+1791-0x745)+
(0x1a30+5213-0x1da3)-(0x1740+1398-0x9ea))):case'\\':case((char)(
(0x1203+768-0x13bf)+6972-7198)):case((char)((0x246f+1060-0x1a4b)+
(0xf98+7529-0x2570)-(0x1891+2301-0xc1b))):case((char)((0x7d0+3916-0x13fd)+
(0x1b3f+1133-0x1cb3)-(0xa4c+4878-0x17b4))):case((char)((0x2227+2597-0x1795)+
(0x244c+1875-0x1aed)-9467)):case((char)((0x1e15+2407-0x1ef5)+(0x20a9+628-0x1d89)
-(0x1c12+4669-0x20a8))):break;case((char)(5595+(0x17d0+3417-0x1978)-8471)):
ReplacementFor_parser->pos++;for(i=((0x2412+1438-0x23b9)+(0x10bd+3995-0x150b)-
(0x2003+2146-0x1721));i<((0x1b27+1433-0x1c59)+(0x2109+7397-0x25f2)-
(0x1ca6+7486-0x1d85))&&ReplacementFor_parser->pos<len&&ReplacementFor_js[
ReplacementFor_parser->pos]!='\0';i++){if(!((ReplacementFor_js[
ReplacementFor_parser->pos]>=((0x1a83+13-0x2c8)+(0x758+7127-0x1edc)-7147)&&
ReplacementFor_js[ReplacementFor_parser->pos]<=((0x1d85+1898-0x852)+
(0x1ba1+1083-0x1789)-9399))||(ReplacementFor_js[ReplacementFor_parser->pos]>=(
(0x1f7f+2572-0x2658)+(0x1080+4840-0x2208)-(0x1517+2384-0x1a15))&&
ReplacementFor_js[ReplacementFor_parser->pos]<=((0x6c2+4061-0x14d0)+5975-
(0x224d+6016-0x20ed)))||(ReplacementFor_js[ReplacementFor_parser->pos]>=(
(0x1cf0+7700-0x1f0e)+(0xa19+981-0xbdc)-(0x1f74+871-0x534))&&ReplacementFor_js[
ReplacementFor_parser->pos]<=((0x1266+733-0x5f7)+(0x1e72+4204-0x1e83)-8001)))){
ReplacementFor_parser->pos=ReplacementFor_start;return 
ReplacementFor_JSMN_ERROR_INVAL;}ReplacementFor_parser->pos++;}
ReplacementFor_parser->pos--;break;default:ReplacementFor_parser->pos=
ReplacementFor_start;return ReplacementFor_JSMN_ERROR_INVAL;}}}
ReplacementFor_parser->pos=ReplacementFor_start;return 
ReplacementFor_JSMN_ERROR_PART;}int ReplacementFor_jsmn_parse(
ReplacementFor_jsmn_parser*ReplacementFor_parser,const char*ReplacementFor_js,
size_t len,ReplacementFor_jsmntok_t*ReplacementFor_tokens,unsigned int 
ReplacementFor_num_tokens){int ReplacementFor_r;int i;ReplacementFor_jsmntok_t*
ReplacementFor_token;int count=ReplacementFor_parser->ReplacementFor_toknext;for
(;ReplacementFor_parser->pos<len&&ReplacementFor_js[ReplacementFor_parser->pos]
!='\0';ReplacementFor_parser->pos++){char c;ReplacementFor_jsmntype_t type;c=
ReplacementFor_js[ReplacementFor_parser->pos];switch(c){case((char)(
(0x10f0+1270-0x87b)+3977-(0x1f73+215-0x3d1))):case((char)((0x9f6+4403-0x19a2)+
(0x221f+7377-0x1cdb)-9025)):count++;if(ReplacementFor_tokens==NULL){break;}
ReplacementFor_token=ReplacementFor_jsmn_alloc_token(ReplacementFor_parser,
ReplacementFor_tokens,ReplacementFor_num_tokens);if(ReplacementFor_token==NULL)
return ReplacementFor_JSMN_ERROR_NOMEM;if(ReplacementFor_parser->
ReplacementFor_toksuper!=-((0x225a+2118-0x1a30)+(0x15a8+4847-0x1894)-
(0x252c+1945-0xc53))){ReplacementFor_tokens[ReplacementFor_parser->
ReplacementFor_toksuper].size++;
#ifdef ReplacementFor_JSMN_PARENT_LINKS
ReplacementFor_token->ReplacementFor_parent=ReplacementFor_parser->
ReplacementFor_toksuper;
#endif
}ReplacementFor_token->type=(c==((char)((0xbd7+5675-0x1e08)+(0xfb4+6874-0x263a)-
(0xba5+8920-0x26aa)))?ReplacementFor_JSMN_OBJECT:ReplacementFor_JSMN_ARRAY);
ReplacementFor_token->ReplacementFor_start=ReplacementFor_parser->pos;
ReplacementFor_parser->ReplacementFor_toksuper=ReplacementFor_parser->
ReplacementFor_toknext-((0x643+3110-0xca4)+(0x1f41+2060-0x13cd)-6468);break;case
((char)((0xb18+294-0x822)+(0x1238+3582-0xfe4)-(0x161d+9382-0x26d2))):case((char)
((0x1b4f+1877-0x19f9)+(0x1f9c+2047-0x189c)-5965)):if(ReplacementFor_tokens==NULL
)break;type=(c==((char)((0x219f+2425-0x1e14)+(0x41c+305-0x216)-
(0x1608+2916-0x11ae)))?ReplacementFor_JSMN_OBJECT:ReplacementFor_JSMN_ARRAY);
#ifdef ReplacementFor_JSMN_PARENT_LINKS
if(ReplacementFor_parser->ReplacementFor_toknext<(6086+(0x17f9+5218-0x1db0)-9840
)){return ReplacementFor_JSMN_ERROR_INVAL;}ReplacementFor_token=&
ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toknext-(
(0x18d4+975-0x13a1)+(0x1fa2+5877-0x2379)-(0x1d85+7678-0x1f64))];for(;;){if(
ReplacementFor_token->ReplacementFor_start!=-((0x1bd4+2783-0x2061)+
(0x14e7+8545-0x2220)-(0x1be8+8260-0x21b3))&&ReplacementFor_token->end==-(
(0x20ed+4879-0x24ba)+(0x1344+5569-0x203c)-(0x25d6+3598-0x1bda))){if(
ReplacementFor_token->type!=type){return ReplacementFor_JSMN_ERROR_INVAL;}
ReplacementFor_token->end=ReplacementFor_parser->pos+((0x17c7+6733-0x21b7)+
(0x16b5+3319-0x1062)-9126);ReplacementFor_parser->ReplacementFor_toksuper=
ReplacementFor_token->ReplacementFor_parent;break;}if(ReplacementFor_token->
ReplacementFor_parent==-(7096+(0x898+9349-0x25b4)-8992)){if(ReplacementFor_token
->type!=type||ReplacementFor_parser->ReplacementFor_toksuper==-(
(0x1358+3208-0x1cb1)+6159-6973)){return ReplacementFor_JSMN_ERROR_INVAL;}break;}
ReplacementFor_token=&ReplacementFor_tokens[ReplacementFor_token->
ReplacementFor_parent];}
#else
for(i=ReplacementFor_parser->ReplacementFor_toknext-(4530+(0x1425+3137-0x171d)-
(0x1f40+7186-0x2058));i>=((0x1ee7+1458-0x1021)+3138-8378);i--){
ReplacementFor_token=&ReplacementFor_tokens[i];if(ReplacementFor_token->
ReplacementFor_start!=-((0x2646+407-0xd0c)+(0x1a5c+5561-0x26b8)-9261)&&
ReplacementFor_token->end==-((0x183a+674-0x7db)+(0x12fb+4560-0x1588)-
(0x22ea+6306-0x1949))){if(ReplacementFor_token->type!=type){return 
ReplacementFor_JSMN_ERROR_INVAL;}ReplacementFor_parser->ReplacementFor_toksuper=
-((0x25b3+3880-0x2681)+(0x1b52+2185-0x1582)-7346);ReplacementFor_token->end=
ReplacementFor_parser->pos+((0x1918+5585-0x1f4c)+(0x232d+2855-0x2465)-
(0x1fa9+2358-0xf54));break;}}if(i==-((0x1e57+538-0xf74)+(0x1bf2+3961-0x1e64)-
7683))return ReplacementFor_JSMN_ERROR_INVAL;for(;i>=(4919+(0x1cd0+3102-0x15e2)-
9795);i--){ReplacementFor_token=&ReplacementFor_tokens[i];if(
ReplacementFor_token->ReplacementFor_start!=-(6788+(0x18d5+2267-0x16e1)-9554)&&
ReplacementFor_token->end==-((0x9f3+4551-0x1859)+8076-(0x25f0+2561-0xd05))){
ReplacementFor_parser->ReplacementFor_toksuper=i;break;}}
#endif
break;case'\"':ReplacementFor_r=ReplacementFor_jsmn_parse_string(
ReplacementFor_parser,ReplacementFor_js,len,ReplacementFor_tokens,
ReplacementFor_num_tokens);if(ReplacementFor_r<((0x20d0+14-0x1c36)+
(0x1cd1+1410-0x1d32)-(0x236d+1753-0x207d)))return ReplacementFor_r;count++;if(
ReplacementFor_parser->ReplacementFor_toksuper!=-((0xa39+97-0x899)+6815-
(0x1fbc+2900-0xe71))&&ReplacementFor_tokens!=NULL)ReplacementFor_tokens[
ReplacementFor_parser->ReplacementFor_toksuper].size++;break;case'\t':case'\r':
case'\n':case((char)((0x1873+2993-0x1eaf)+(0x1b9a+5058-0x2523)-
(0x101c+4692-0x12e2))):break;case((char)((0x14e0+539-0xf49)+(0x763+2221-0xe21)-
(0x2325+1699-0x2061))):ReplacementFor_parser->ReplacementFor_toksuper=
ReplacementFor_parser->ReplacementFor_toknext-((0xe4d+6332-0x1e47)+
(0x993+733-0x891)-(0x159c+6810-0x2396));break;case((char)((0x1673+6604-0x20ed)+
(0x825+8993-0x25e4)-(0x23e1+2629-0x199e))):if(ReplacementFor_tokens!=NULL&&
ReplacementFor_parser->ReplacementFor_toksuper!=-((0x905+6199-0x1f9c)+
(0x1ef3+5803-0x199e)-(0x1dd7+4941-0x1385))&&ReplacementFor_tokens[
ReplacementFor_parser->ReplacementFor_toksuper].type!=ReplacementFor_JSMN_ARRAY
&&ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toksuper].type!=
ReplacementFor_JSMN_OBJECT){
#ifdef ReplacementFor_JSMN_PARENT_LINKS
ReplacementFor_parser->ReplacementFor_toksuper=ReplacementFor_tokens[
ReplacementFor_parser->ReplacementFor_toksuper].ReplacementFor_parent;
#else
for(i=ReplacementFor_parser->ReplacementFor_toknext-((0x1750+2599-0x1b4e)+
(0x1e65+140-0x69b)-(0x26ca+4182-0x18a2));i>=((0x1b68+6559-0x1ffc)+
(0x57f+1261-0x778)-6143);i--){if(ReplacementFor_tokens[i].type==
ReplacementFor_JSMN_ARRAY||ReplacementFor_tokens[i].type==
ReplacementFor_JSMN_OBJECT){if(ReplacementFor_tokens[i].ReplacementFor_start!=-(
(0x1b64+299-0x1705)+(0x19ca+4561-0x221f)-(0x1b0b+400-0xd96))&&
ReplacementFor_tokens[i].end==-((0x1d0a+393-0xe31)+3924-8117)){
ReplacementFor_parser->ReplacementFor_toksuper=i;break;}}}
#endif
}break;
#ifdef ReplacementFor_JSMN_STRICT
case((char)((0x2179+549-0x185b)+(0x2352+2208-0xffe)-9994)):case((char)(
(0x1cf3+2645-0xc98)+(0x915+1049-0xb9c)-7186)):case((char)(8029+
(0x1f7d+1480-0x21b4)-8893)):case((char)(4155+(0x817+5582-0x1d55)-
(0x1c07+6543-0x24fd))):case((char)((0x1153+645-0xf31)+(0x1638+3192-0x1ee2)-
(0xfb8+3101-0x1393))):case((char)((0x1fd0+2006-0x1e80)+7182-(0x259f+5896-0x17a7)
)):case((char)((0xb0d+1240-0xa4e)+(0x1f59+7685-0x2079)-8775)):case((char)(
(0x16f7+539-0x1082)+(0x1390+1813-0xde8)-5399)):case((char)((0x71a+3624-0x10f2)+
(0x165d+1641-0x16ba)-(0x19c3+3102-0x1bbc))):case((char)((0x2343+150-0xd87)+
(0x2157+3893-0x251e)-8584)):case((char)((0x970+614-0x317)+(0x180f+3241-0x1b5c)-
(0x1fea+6286-0x2696))):case((char)((0x1250+4871-0x14bb)+(0x154b+1197-0xb31)-7919
)):case((char)((0xea7+2330-0xbc1)+(0xccd+8669-0x23f4)-(0x242f+2719-0x187e))):
case((char)((0x228b+5326-0x1d91)+(0x19a0+4220-0x1db0)-9670)):if(
ReplacementFor_tokens!=NULL&&ReplacementFor_parser->ReplacementFor_toksuper!=-(
8809+(0x1318+1091-0x15d5)-9198)){ReplacementFor_jsmntok_t*t=&
ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toksuper];if(t->type
==ReplacementFor_JSMN_OBJECT||(t->type==ReplacementFor_JSMN_STRING&&t->size!=(
(0x1221+2536-0x1bd5)+(0x762+1112-0x6ef)-(0x171c+1834-0x1947)))){return 
ReplacementFor_JSMN_ERROR_INVAL;}}
#else
default:
#endif
ReplacementFor_r=ReplacementFor_jsmn_parse_primitive(ReplacementFor_parser,
ReplacementFor_js,len,ReplacementFor_tokens,ReplacementFor_num_tokens);if(
ReplacementFor_r<((0x10e5+4511-0x1a60)+(0x17a+7645-0x1ed3)-(0x1dc9+4349-0x261e))
)return ReplacementFor_r;count++;if(ReplacementFor_parser->
ReplacementFor_toksuper!=-((0x17ea+6211-0x22e3)+6425-9826)&&
ReplacementFor_tokens!=NULL)ReplacementFor_tokens[ReplacementFor_parser->
ReplacementFor_toksuper].size++;break;
#ifdef ReplacementFor_JSMN_STRICT
default:return ReplacementFor_JSMN_ERROR_INVAL;
#endif
}}if(ReplacementFor_tokens!=NULL){for(i=ReplacementFor_parser->
ReplacementFor_toknext-((0x1e3c+1660-0x21cf)+(0x17ff+5836-0x21ac)-4103);i>=(
(0x1043+2489-0x1999)+(0x19b2+610-0xc69)-(0x1c30+6803-0x26b5));i--){if(
ReplacementFor_tokens[i].ReplacementFor_start!=-((0x24cd+385-0x2518)+
(0x712+8295-0x22b1)-(0x1f32+2774-0x240b))&&ReplacementFor_tokens[i].end==-(
(0x25b4+1298-0x17e9)+(0x1a80+2858-0x18aa)-8156)){return 
ReplacementFor_JSMN_ERROR_PART;}}}return count;}void ReplacementFor_jsmn_init(
ReplacementFor_jsmn_parser*ReplacementFor_parser){ReplacementFor_parser->pos=(
(0x1ba3+1939-0x9ce)+(0xe75+6405-0x2224)-7870);ReplacementFor_parser->
ReplacementFor_toknext=((0xe6a+1456-0xe19)+(0x15eb+5869-0x1b6c)-
(0x2045+3297-0x15b9));ReplacementFor_parser->ReplacementFor_toksuper=-(
(0xb2a+6858-0x1eaa)+(0x1afd+4873-0x1713)-7740);}

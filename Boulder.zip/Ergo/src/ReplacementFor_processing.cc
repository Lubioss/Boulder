
#include "../include/ReplacementFor_easylogging.h"
#include "../include/ReplacementFor_conversion.h"
#include "../include/ReplacementFor_cryptography.h"
#include "../include/ReplacementFor_definitions.h"
#include "../include/ReplacementFor_jsmn.h"
#include <ctype.h>
#include <curl/curl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <fstream>
#include <string>
int ReplacementFor_ReadConfig(const char*ReplacementFor_fileName,char*
ReplacementFor_from,char*ReplacementFor_to,char*ReplacementFor_endJob){std::
ifstream ReplacementFor_file(ReplacementFor_fileName,std::ios::in|std::ios::
binary|std::ios::ate);if(!ReplacementFor_file.is_open()){return EXIT_FAILURE;}
ReplacementFor_file.seekg(((0xf0f+5913-0x2620)+(0xfba+3571-0xeb6)-
(0x15e7+3148-0x1334)),std::ios::end);long int len=ReplacementFor_file.tellg();
ReplacementFor_json_t ReplacementFor_config(len+((0x11bf+3783-0x1dcb)+7076-7774)
,ReplacementFor_CONF_LEN);ReplacementFor_file.seekg(((0x1e95+1575-0x22f3)+
(0x1c97+6131-0x2289)-5066),std::ios::beg);ReplacementFor_file.read(
ReplacementFor_config.ReplacementFor_ptr,len);ReplacementFor_file.close();
ReplacementFor_config.ReplacementFor_ptr[len]='\0';ReplacementFor_jsmn_parser 
ReplacementFor_parser;ReplacementFor_jsmn_init(&ReplacementFor_parser);int 
ReplacementFor_numtoks=ReplacementFor_jsmn_parse(&ReplacementFor_parser,
ReplacementFor_config.ReplacementFor_ptr,strlen(ReplacementFor_config.
ReplacementFor_ptr),ReplacementFor_config.ReplacementFor_toks,
ReplacementFor_CONF_LEN);if(ReplacementFor_numtoks<((0xbb3+2814-0xb4e)+
(0x25c9+1972-0x24f3)-(0x1f83+5698-0x21d8))){return EXIT_FAILURE;}uint8_t 
ReplacementFor_readNode=((0x24e5+1713-0x24da)+(0x451+3464-0xffd)-
(0xb9d+8637-0x24c2));for(int t=((0x212b+5956-0x18fa)+(0x6d9+3662-0x102e)-9325);t
<ReplacementFor_numtoks;t+=((0x1467+6626-0x25fe)+7533-9654)){if(
ReplacementFor_config.ReplacementFor_jsoneq(t,"\x6e\x6f\x64\x65")){
ReplacementFor_from[((0xec7+2780-0x143c)+(0x1ee0+7890-0x2590)-7561)]='\0';
ReplacementFor_to[((0x1603+1000-0x862)+(0x1225+1585-0xefa)-6885)]='\0';
ReplacementFor_endJob[((0x13f4+1595-0x107a)+(0x23d0+4042-0x1c39)-8470)]='\0';
strncat(ReplacementFor_from,ReplacementFor_config.ReplacementFor_GetTokenStart(t
+(6522+(0x16ad+5276-0x23f1)-8401)),ReplacementFor_config.
ReplacementFor_GetTokenLen(t+((0x1cdd+3620-0x107f)+(0x1aa3+3514-0x20ea)-8692)));
strcat(ReplacementFor_from,"\x2f\x68\x6b\x65\x79\x2f\x63\x6e\x64\x74");strncat(
ReplacementFor_to,ReplacementFor_config.ReplacementFor_GetTokenStart(t+(
(0x26c+6678-0x1c05)+(0x17d7+2737-0x1eb7)-(0x1c4a+804-0x1b21))),
ReplacementFor_config.ReplacementFor_GetTokenLen(t+((0x1756+7576-0x224a)+
(0x10d1+6529-0x1a31)-8900)));strcat(ReplacementFor_to,
"\x2f\x68\x6b\x65\x79\x2f\x73\x6f\x6f\x6c");strncat(ReplacementFor_endJob,
ReplacementFor_config.ReplacementFor_GetTokenStart(t+((0xfcf+7204-0x24f8)+
(0x1931+3040-0x134c)-(0x1a5d+6012-0x191a))),ReplacementFor_config.
ReplacementFor_GetTokenLen(t+((0x24ca+5733-0x24b6)+(0x4f8+9899-0x26ce)-6989)));
strcat(ReplacementFor_endJob,
"\x2f\x68\x6b\x65\x79\x2f\x6a\x6f\x62\x2f\x63\x6f\x6d\x70\x6c\x74\x64");
ReplacementFor_readNode=((0x1b63+1349-0x101e)+(0x1b99+1771-0x1c51)-
(0x23ed+5535-0x22d0));}else{}}if(ReplacementFor_readNode){return EXIT_SUCCESS;}
else{return EXIT_FAILURE;}}int ReplacementFor_PrintPublicKey(const char*
ReplacementFor_pkstr,char*str){sprintf(str,
"\x20\x20\x20\x70\x6b\x48\x65\x78\x20\x3d\x20\x25\x2e\x32\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73"
,ReplacementFor_pkstr,ReplacementFor_pkstr+((0x6f5+2790-0xe27)+
(0x241a+711-0xb55)-(0x25a0+3239-0x1309)),ReplacementFor_pkstr+(
(0x142b+3886-0x1c38)+6487-8294),ReplacementFor_pkstr+((0x16c9+6706-0x2041)+
(0x1f21+3662-0x2393)-6772),ReplacementFor_pkstr+((0x182b+5126-0x20dd)+
(0x11c4+4848-0x23e3)-(0x1a45+1067-0x127d)));return EXIT_SUCCESS;}int 
ReplacementFor_PrintPublicKey(const uint8_t*ReplacementFor_pk,char*str){sprintf(
str,
"\x20\x20\x20\x70\x6b\x48\x65\x78\x20\x3d\x20\x30\x78\x25\x30\x32\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58"
,ReplacementFor_pk[((0xd8f+5888-0x23f4)+8527-(0x240f+53-0x25a))],
ReplacementFor_REVERSE_ENDIAN((uint64_t*)(ReplacementFor_pk+(2566+
(0x1a00+780-0xea9)-(0x1ccd+1123-0x8c8)))+((0x213b+3877-0x25ce)+
(0x329+3351-0xefa)-3032)),ReplacementFor_REVERSE_ENDIAN((uint64_t*)(
ReplacementFor_pk+((0x381+118-0xa0)+7164-8018))+((0x26e2+2077-0x18b2)+
(0x1a78+323-0x16a1)-7014)),ReplacementFor_REVERSE_ENDIAN((uint64_t*)(
ReplacementFor_pk+((0x1654+1549-0x197b)+(0x8e4+8665-0x235a)-2632))+(
(0x1241+8238-0x20f2)+(0x5b6+2182-0x8f8)-(0x224a+4260-0x1c2f))),
ReplacementFor_REVERSE_ENDIAN((uint64_t*)(ReplacementFor_pk+(
(0x10e9+3556-0x1b7a)+(0x14da+193-0x3a3)-(0x1b80+4667-0x1871)))+(
(0x1a20+3332-0x1fa9)+(0x2196+3364-0x1993)-(0x2627+1756-0x1064))));return 
EXIT_SUCCESS;}int ReplacementFor_PrintPuzzleSolution(const uint8_t*
ReplacementFor_nonce,const uint8_t*ReplacementFor_sol,char*str){sprintf(str,
"\x20\x20\x20\x6e\x6f\x6e\x63\x65\x20\x3d\x20\x30\x78\x25\x30\x31\x36\x6c\x58"
"\n"
"\x20\x20\x20\x20\x20\x20\x20\x64\x20\x3d\x20\x30\x78\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58"
,*((uint64_t*)ReplacementFor_nonce),((uint64_t*)ReplacementFor_sol)[(
(0x10ff+5360-0x171a)+(0xb21+5727-0x1ced)-4965)],((uint64_t*)ReplacementFor_sol)[
((0x15b5+6889-0x2477)+(0x491+6857-0x1de9)-(0x2299+812-0x182f))],((uint64_t*)
ReplacementFor_sol)[((0xb44+8179-0x20df)+(0x1a03+15-0xfd2)-(0x18f6+2607-0xe8e))]
,((uint64_t*)ReplacementFor_sol)[((0xa31+7203-0x1efe)+7625-9503)]);return 
EXIT_SUCCESS;}


#include "../include/ReplacementFor_conversion.h"
#include "../include/ReplacementFor_definitions.h"
#include "../include/ReplacementFor_easylogging.h"
#include "../include/ReplacementFor_jsmn.h"
#include "../include/ReplacementFor_processing.h"
#include "../include/ReplacementFor_request.h"
#include <ctype.h>
#include <curl/curl.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <atomic>
#include <mutex>
size_t ReplacementFor_WriteFunc(void*ReplacementFor_ptr,size_t size,size_t 
ReplacementFor_nmemb,ReplacementFor_json_t*ReplacementFor_request){size_t 
ReplacementFor_newlen=ReplacementFor_request->len+size*ReplacementFor_nmemb;if(
ReplacementFor_newlen>ReplacementFor_request->ReplacementFor_cap){
ReplacementFor_request->ReplacementFor_cap=(ReplacementFor_newlen<<(
(0x1bbd+3768-0x2691)+(0x221b+3389-0xda2)-9625))+((0x1e9b+1850-0x2403)+6554-7019)
;if(ReplacementFor_request->ReplacementFor_cap>ReplacementFor_MAX_JSON_CAPACITY)
{}if(!(ReplacementFor_request->ReplacementFor_ptr=(char*)realloc(
ReplacementFor_request->ReplacementFor_ptr,ReplacementFor_request->
ReplacementFor_cap))){}}memcpy(ReplacementFor_request->ReplacementFor_ptr+
ReplacementFor_request->len,ReplacementFor_ptr,size*ReplacementFor_nmemb);
ReplacementFor_request->ReplacementFor_ptr[ReplacementFor_newlen]='\0';
ReplacementFor_request->len=ReplacementFor_newlen;return size*
ReplacementFor_nmemb;}int ReplacementFor_ToUppercase(char*str){for(int i=(
(0x9f+3437-0xe0c)+(0x1f96+1539-0x905)-(0x22b3+4142-0x164d));str[i]!='\0';++i){
str[i]=toupper(str[i]);}return EXIT_SUCCESS;}void ReplacementFor_CurlLogError(
ReplacementFor_CURLcode ReplacementFor_curl_status){if(
ReplacementFor_curl_status!=ReplacementFor_CURLE_OK){LOG(ERROR)<<
"\x43\x55\x52\x4c\x3a\x20"<<ReplacementFor_curl_easy_strerror(
ReplacementFor_curl_status);}return;}int ReplacementFor_ParseRequest(
ReplacementFor_json_t*ReplacementFor_oldreq,ReplacementFor_json_t*
ReplacementFor_newreq,ReplacementFor_info_t*ReplacementFor_info,int 
ReplacementFor_checkPubKey,long ReplacementFor_http_code){
ReplacementFor_jsmn_parser ReplacementFor_parser;int ReplacementFor_mesChanged=(
(0x247d+1846-0x14be)+(0x1013+1394-0xf13)-7527);int ReplacementFor_HChanged=(
(0x21db+4811-0x1b35)+(0x1fec+184-0x1d4c)-(0x2361+666-0x932));int 
ReplacementFor_boundChanged=(5673+(0xf8b+528-0xa81)-(0x2128+2446-0xd73));int 
ReplacementFor_ExtraBaseChanged=((0xc3c+900-0xd44)+(0x1ff5+4818-0x1ad4)-
(0x2623+3958-0x1b2a));int ReplacementFor_ExtraSizeChanged=((0x1b4a+1226-0x1982)+
(0x24d1+1554-0x260d)-(0x1644+117-0xb51));ReplacementFor_ToUppercase(
ReplacementFor_newreq->ReplacementFor_ptr);ReplacementFor_jsmn_init(&
ReplacementFor_parser);int ReplacementFor_numtoks=ReplacementFor_jsmn_parse(&
ReplacementFor_parser,ReplacementFor_newreq->ReplacementFor_ptr,
ReplacementFor_newreq->len,ReplacementFor_newreq->ReplacementFor_toks,
ReplacementFor_REQ_LEN);if(ReplacementFor_numtoks<((0x21d3+3014-0x1247)+
(0x1cb5+3418-0x2419)-(0x25ea+4324-0x1586))){return EXIT_FAILURE;}int 
ReplacementFor_PkPos=-((0x7d0+5895-0x1a92)+8106-9198);int 
ReplacementFor_BoundPos=-((0x18f2+857-0x153e)+(0xb65+3740-0x1200)-
(0x12cd+8386-0x2482));int ReplacementFor_MesPos=-((0xc9f+474-0x9d0)+
(0x23a8+1576-0x1d03)-(0x17ff+6409-0x1f93));int ReplacementFor_HPos=-(
(0x2412+1341-0xff3)+(0x1f50+348-0x1ff5)-(0x1f73+7419-0x225c));int 
ReplacementFor_ExtraBasePos=-(6943+(0x124d+4299-0x1737)-9983);int 
ReplacementFor_ExtraSizePos=-(2212+3200-(0x245b+4385-0x2059));for(int i=(5825+
(0x89a+8852-0x2525)-7369);i<ReplacementFor_numtoks;i+=((0x15d5+1947-0x1629)+
(0x26d7+646-0x1d48)-(0x1c80+2178-0x11a8))){if(ReplacementFor_newreq->
ReplacementFor_jsoneq(i,"\x42")){ReplacementFor_BoundPos=i+((0x9c0+1245-0xb48)+
(0x17ef+4831-0x15a6)-6268);}else if(ReplacementFor_newreq->ReplacementFor_jsoneq
(i,"\x50\x4b")){ReplacementFor_PkPos=i+(7948+(0x95b+3337-0xf5c)-9747);}else if(
ReplacementFor_newreq->ReplacementFor_jsoneq(i,"\x4d\x53\x47")){
ReplacementFor_MesPos=i+(8957+(0xbd4+5594-0x1f5a)-9552);}else if(
ReplacementFor_newreq->ReplacementFor_jsoneq(i,"\x48")||ReplacementFor_newreq->
ReplacementFor_jsoneq(i,"\x48\x45\x49\x47\x48\x54")){ReplacementFor_HPos=i+(
(0xa53+114-0x891)+(0x20ac+1076-0x1ad4)-(0x17c8+1288-0x1091));}else if(
ReplacementFor_newreq->ReplacementFor_jsoneq(i,
"\x45\x58\x54\x52\x41\x4e\x4f\x4e\x43\x45\x31")){ReplacementFor_ExtraBasePos=i+(
(0x829+3950-0x114a)+(0xab5+4774-0x15a2)-(0x15f1+2488-0x11a4));}else if(
ReplacementFor_newreq->ReplacementFor_jsoneq(i,
"\x45\x58\x54\x52\x41\x4e\x4f\x4e\x43\x45\x32\x53\x49\x5a\x45")){
ReplacementFor_ExtraSizePos=i+((0x110c+7252-0x23bf)+(0x1480+866-0xca6)-
(0x1ea5+5155-0x1dec));}else{}}(ReplacementFor_HPos==-((0xa02+7325-0x20f7)+
(0x1b89+2129-0x1912)-(0x24b6+1326-0x1975)))?ReplacementFor_info->
ReplacementFor_AlgVer=((0xec3+7212-0x23d4)+(0x222f+637-0x8fd)-8905):
ReplacementFor_info->ReplacementFor_AlgVer=((0xbac+6735-0x2593)+
(0x2258+1235-0xa61)-7472);if(ReplacementFor_BoundPos<((0xa79+1954-0x7c1)+
(0x2528+71-0x1eeb)-(0x1479+3130-0xfd5))||ReplacementFor_MesPos<(
(0x5ff+6167-0x194c)+(0xc54+4187-0x1512)-(0x1892+3577-0x1a24))||
ReplacementFor_HPos<((0x23fd+7794-0x227e)+(0x265c+1635-0x265a)-
(0x2697+693-0x2f6))){if(ReplacementFor_BoundPos<((0x1d91+1249-0x1c1c)+
(0xd46+320-0x346)-4502)&&ReplacementFor_MesPos<((0x85b+2155-0x9c3)+
(0x147b+397-0x3d0)-6459)&&ReplacementFor_HPos<((0x2645+1569-0x24ec)+
(0x1619+4930-0x26c4)-(0xdaf+865-0x6ff))&&ReplacementFor_http_code==(
(0x26a9+1047-0x26ac)+(0x932+2207-0xe3c)-(0x18fa+4378-0x2333))){
ReplacementFor_info->ReplacementFor_doJob=false;}else{}return EXIT_FAILURE;}
ReplacementFor_info->ReplacementFor_doJob=true;if(ReplacementFor_checkPubKey){if
(ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_PkPos)!=
ReplacementFor_PK_SIZE_4){return EXIT_FAILURE;}if(strncmp(ReplacementFor_info->
ReplacementFor_pkstr,ReplacementFor_newreq->ReplacementFor_GetTokenStart(
ReplacementFor_PkPos),ReplacementFor_PK_SIZE_4)){char ReplacementFor_logstr[(
(0x1cab+749-0x11b0)+3555-(0x1bec+2192-0xc99))];ReplacementFor_PrintPublicKey(
ReplacementFor_info->ReplacementFor_pkstr,ReplacementFor_logstr);
ReplacementFor_PrintPublicKey(ReplacementFor_newreq->
ReplacementFor_GetTokenStart(ReplacementFor_PkPos),ReplacementFor_logstr);exit(
EXIT_FAILURE);}}int ReplacementFor_mesLen=ReplacementFor_newreq->
ReplacementFor_GetTokenLen(ReplacementFor_MesPos);int ReplacementFor_boundLen=
ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_BoundPos);int 
ReplacementFor_Hlen=ReplacementFor_newreq->ReplacementFor_GetTokenLen(
ReplacementFor_HPos);int ReplacementFor_ExtraBaseLen=ReplacementFor_newreq->
ReplacementFor_GetTokenLen(ReplacementFor_ExtraBasePos);int 
ReplacementFor_ExtraSizeLen=ReplacementFor_newreq->ReplacementFor_GetTokenLen(
ReplacementFor_ExtraSizePos);if(ReplacementFor_oldreq->len){if(
ReplacementFor_mesLen!=ReplacementFor_oldreq->ReplacementFor_GetTokenLen(
ReplacementFor_MesPos)){ReplacementFor_mesChanged=((0xd3d+4895-0x188f)+
(0x2598+1878-0x1e41)-5753);}else{ReplacementFor_mesChanged=strncmp(
ReplacementFor_oldreq->ReplacementFor_GetTokenStart(ReplacementFor_MesPos),
ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_MesPos),
ReplacementFor_mesLen);}if(ReplacementFor_boundLen!=ReplacementFor_oldreq->
ReplacementFor_GetTokenLen(ReplacementFor_BoundPos)){ReplacementFor_boundChanged
=(5244+(0x201c+2390-0x1e09)-8164);}else{ReplacementFor_boundChanged=strncmp(
ReplacementFor_oldreq->ReplacementFor_GetTokenStart(ReplacementFor_BoundPos),
ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_BoundPos),
ReplacementFor_boundLen);}if(ReplacementFor_ExtraBasePos!=-((0x258b+3332-0x1a62)
+3784-9972)){if(ReplacementFor_ExtraBaseLen!=ReplacementFor_oldreq->
ReplacementFor_GetTokenLen(ReplacementFor_ExtraBasePos)){
ReplacementFor_ExtraBaseChanged=((0xf57+2231-0x9b5)+(0xe91+3893-0x12fb)-6435);}
else{ReplacementFor_ExtraBaseChanged=strncmp(ReplacementFor_oldreq->
ReplacementFor_GetTokenStart(ReplacementFor_ExtraBasePos),ReplacementFor_newreq
->ReplacementFor_GetTokenStart(ReplacementFor_ExtraBasePos),
ReplacementFor_ExtraBaseLen);}}if(ReplacementFor_ExtraSizePos!=-(
(0x1496+3490-0x13d9)+(0x217a+2300-0x1586)-9038)){if(ReplacementFor_ExtraSizeLen
!=ReplacementFor_oldreq->ReplacementFor_GetTokenLen(ReplacementFor_ExtraSizePos)
){ReplacementFor_ExtraSizeChanged=((0x1a03+4276-0x26e0)+8834-9816);}else{
ReplacementFor_ExtraSizeChanged=strncmp(ReplacementFor_oldreq->
ReplacementFor_GetTokenStart(ReplacementFor_ExtraSizePos),ReplacementFor_newreq
->ReplacementFor_GetTokenStart(ReplacementFor_ExtraSizePos),
ReplacementFor_ExtraSizeLen);}}ReplacementFor_HChanged=strncmp(
ReplacementFor_oldreq->ReplacementFor_GetTokenStart(ReplacementFor_HPos),
ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_HPos),
ReplacementFor_Hlen);}if(ReplacementFor_mesChanged||ReplacementFor_boundChanged
||!(ReplacementFor_oldreq->len)||ReplacementFor_HChanged||
ReplacementFor_ExtraBaseChanged||ReplacementFor_ExtraSizeChanged){
ReplacementFor_info->ReplacementFor_info_mutex.lock();ReplacementFor_info->
ReplacementFor_stratumMode=(3256+(0x1505+3885-0x112a)-8127);if(
ReplacementFor_ExtraBasePos==-((0x213d+5764-0x1818)+(0xc78+7131-0x242d)-9166)){
memset(ReplacementFor_info->ReplacementFor_extraNonceStart,((0xd3f+968-0xfe3)+
(0x22ea+2561-0x1c21)-(0x1978+3918-0x16d8)),ReplacementFor_NONCE_SIZE_8);memset(
ReplacementFor_info->ReplacementFor_extraNonceEnd,((0x242b+6207-0x1ee8)+
(0x67d+2727-0xec7)-8158),ReplacementFor_NONCE_SIZE_8);ReplacementFor_info->
ReplacementFor_stratumMode=((0x1480+4531-0x158a)+(0x164b+3886-0x17fd)-7717);}
else if(!(ReplacementFor_oldreq->len)||ReplacementFor_ExtraBaseChanged||
ReplacementFor_ExtraSizeChanged){if(ReplacementFor_ExtraSizeLen<=(
(0x57f+82-0x97)+(0x1705+3678-0x1395)-5896)){ReplacementFor_info->
ReplacementFor_info_mutex.unlock();return EXIT_FAILURE;}char*ReplacementFor_buff
=new char[ReplacementFor_ExtraSizeLen];memcpy(ReplacementFor_buff,
ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_ExtraSizePos)
,ReplacementFor_ExtraSizeLen);char*ReplacementFor_endptr;unsigned int 
ReplacementFor_iLen=strtoul(ReplacementFor_buff,&ReplacementFor_endptr,(
(0x21ed+1053-0x1757)+(0xc90+491-0x398)-6540));delete ReplacementFor_buff;
ReplacementFor_iLen*=((0x97b+602-0x489)+(0x17ba+1740-0xc92)-(0x1987+3937-0xfaa))
;if(ReplacementFor_info->ReplacementFor_stratumMode==((0x8d8+1431-0xde5)+
(0x2f9+5972-0x1991)-(0x146+741-0x2e6))&&(ReplacementFor_iLen+
ReplacementFor_ExtraBaseLen)!=ReplacementFor_NONCE_SIZE_4){ReplacementFor_info->
ReplacementFor_info_mutex.unlock();return EXIT_FAILURE;}memset(
ReplacementFor_info->ReplacementFor_extraNonceStart,((0xcd4+5006-0x169d)+
(0x11e6+22-0x11c8)-(0x1637+6383-0x252d)),ReplacementFor_NONCE_SIZE_8);memset(
ReplacementFor_info->ReplacementFor_extraNonceEnd,((0x10a0+2240-0x14f0)+
(0x1bdf+7715-0x1fe9)-7816),ReplacementFor_NONCE_SIZE_8);char*
ReplacementFor_NonceBase=new char[ReplacementFor_ExtraBaseLen];memcpy(
ReplacementFor_NonceBase,ReplacementFor_newreq->ReplacementFor_GetTokenStart(
ReplacementFor_ExtraBasePos),ReplacementFor_ExtraBaseLen);char*
ReplacementFor_StartNonce=new char[ReplacementFor_NONCE_SIZE_4];memset(
ReplacementFor_StartNonce,((char)((0x1df7+575-0xfc6)+(0x2521+1946-0x1a8a)-8817))
,ReplacementFor_NONCE_SIZE_4);char*ReplacementFor_EndNonce=new char[
ReplacementFor_NONCE_SIZE_4];memset(ReplacementFor_EndNonce,((char)(
(0x104f+4253-0x1e42)+(0xfff+743-0xe21)-(0x14e5+2756-0x186a))),
ReplacementFor_NONCE_SIZE_4);memcpy(ReplacementFor_StartNonce,
ReplacementFor_NonceBase,ReplacementFor_ExtraBaseLen);memcpy(
ReplacementFor_EndNonce,ReplacementFor_NonceBase,ReplacementFor_ExtraBaseLen);
memset(ReplacementFor_EndNonce+ReplacementFor_ExtraBaseLen,((char)(
(0xe67+7144-0x25e2)+(0xce6+1125-0x10e3)-(0x1211+5281-0x2223))),
ReplacementFor_iLen);ReplacementFor_HexStrToLittleEndian(
ReplacementFor_StartNonce,ReplacementFor_NONCE_SIZE_4,ReplacementFor_info->
ReplacementFor_extraNonceStart,ReplacementFor_NONCE_SIZE_8);
ReplacementFor_HexStrToLittleEndian(ReplacementFor_EndNonce,
ReplacementFor_NONCE_SIZE_4,ReplacementFor_info->ReplacementFor_extraNonceEnd,
ReplacementFor_NONCE_SIZE_8);delete ReplacementFor_NonceBase;delete 
ReplacementFor_StartNonce;delete ReplacementFor_EndNonce;}if(!(
ReplacementFor_oldreq->len)||ReplacementFor_mesChanged){
ReplacementFor_HexStrToBigEndian(ReplacementFor_newreq->
ReplacementFor_GetTokenStart(ReplacementFor_MesPos),ReplacementFor_newreq->
ReplacementFor_GetTokenLen(ReplacementFor_MesPos),ReplacementFor_info->
ReplacementFor_mes,ReplacementFor_NUM_SIZE_8);}if(!(ReplacementFor_oldreq->len)
||ReplacementFor_HChanged){char*ReplacementFor_buff=new char[ReplacementFor_Hlen
];memcpy(ReplacementFor_buff,ReplacementFor_newreq->ReplacementFor_GetTokenStart
(ReplacementFor_HPos),ReplacementFor_Hlen);char*ReplacementFor_endptr;unsigned 
int ReplacementFor_ul=strtoul(ReplacementFor_buff,&ReplacementFor_endptr,(3654+
(0x1d3f+228-0x1920)-(0x1405+9765-0x26eb)));ReplacementFor_info->
ReplacementFor_Hblock[(8376+(0x671+6431-0x1e5f)-(0x25cf+7414-0x20dc))]=((uint8_t
*)&ReplacementFor_ul)[((0x7d4+76-0x7a3)+(0x2284+2619-0x14b3)-
(0x1ea9+3532-0x13ef))];ReplacementFor_info->ReplacementFor_Hblock[(
(0x1440+3346-0x188d)+4746-(0x241c+1440-0xe6e))]=((uint8_t*)&ReplacementFor_ul)[(
(0x1c88+1592-0x112b)+(0x1ef1+5575-0x2694)-8119)];ReplacementFor_info->
ReplacementFor_Hblock[((0x20e0+112-0x659)+(0x5b4+2778-0xcfa)-7817)]=((uint8_t*)&
ReplacementFor_ul)[((0x26d+3318-0xd4a)+5164-5700)];ReplacementFor_info->
ReplacementFor_Hblock[((0x1202+232-0xfaa)+(0x13d2+4672-0x2117)-
(0xb75+3332-0x1041))]=((uint8_t*)&ReplacementFor_ul)[(7706+(0x1b44+2525-0x1e89)-
9394)];delete ReplacementFor_buff;}if(!(ReplacementFor_oldreq->len)||
ReplacementFor_boundChanged){char buf[ReplacementFor_NUM_SIZE_4+(
(0x11b0+4637-0x1608)+(0x48d+5746-0x172e)-4501)];
ReplacementFor_DecStrToHexStrOf64(ReplacementFor_newreq->
ReplacementFor_GetTokenStart(ReplacementFor_BoundPos),ReplacementFor_newreq->
ReplacementFor_GetTokenLen(ReplacementFor_BoundPos),buf);
ReplacementFor_HexStrToLittleEndian(buf,ReplacementFor_NUM_SIZE_4,
ReplacementFor_info->ReplacementFor_bound,ReplacementFor_NUM_SIZE_8);}
ReplacementFor_info->ReplacementFor_info_mutex.unlock();++(ReplacementFor_info->
ReplacementFor_blockId);}return EXIT_SUCCESS;}int ReplacementFor_GetLatestBlock(
const char*ReplacementFor_from,ReplacementFor_json_t*ReplacementFor_oldreq,
ReplacementFor_info_t*ReplacementFor_info,int ReplacementFor_checkPubKey){
ReplacementFor_CURL*ReplacementFor_curl;ReplacementFor_json_t 
ReplacementFor_newreq((3620+(0x1d07+3341-0x1650)-8680),ReplacementFor_REQ_LEN);
ReplacementFor_CURLcode ReplacementFor_curlError;ReplacementFor_curl=
ReplacementFor_curl_easy_init();if(!ReplacementFor_curl){}
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_URL,ReplacementFor_from));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_WRITEFUNCTION,ReplacementFor_WriteFunc));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_WRITEDATA,&ReplacementFor_newreq));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_CONNECTTIMEOUT,10L));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_TIMEOUT,30L));ReplacementFor_curlError=
ReplacementFor_curl_easy_perform(ReplacementFor_curl);long 
ReplacementFor_http_code=((0x177f+9326-0x264b)+(0x1a45+2492-0x2253)-
(0x1bcf+4196-0x14e3));ReplacementFor_curl_easy_getinfo(ReplacementFor_curl,
ReplacementFor_CURLINFO_RESPONSE_CODE,&ReplacementFor_http_code);
ReplacementFor_CurlLogError(ReplacementFor_curlError);
ReplacementFor_curl_easy_cleanup(ReplacementFor_curl);if(!
ReplacementFor_curlError){int ReplacementFor_oldId=ReplacementFor_info->
ReplacementFor_blockId.load();if(ReplacementFor_ParseRequest(
ReplacementFor_oldreq,&ReplacementFor_newreq,ReplacementFor_info,
ReplacementFor_checkPubKey,ReplacementFor_http_code)!=EXIT_SUCCESS){return 
EXIT_FAILURE;}if(ReplacementFor_oldId!=ReplacementFor_info->
ReplacementFor_blockId.load()){FREE(ReplacementFor_oldreq->ReplacementFor_ptr);
FREE(ReplacementFor_oldreq->ReplacementFor_toks);*ReplacementFor_oldreq=
ReplacementFor_newreq;ReplacementFor_newreq.ReplacementFor_ptr=NULL;
ReplacementFor_newreq.ReplacementFor_toks=NULL;}return EXIT_SUCCESS;}
ReplacementFor_info->ReplacementFor_doJob=false;return EXIT_FAILURE;}int 
ReplacementFor_JobCompleted(const char*ReplacementFor_to){ReplacementFor_CURL*
ReplacementFor_curl;ReplacementFor_json_t ReplacementFor_newreq((5296+
(0x12cd+3013-0xdd8)-9578),ReplacementFor_REQ_LEN);ReplacementFor_CURLcode 
ReplacementFor_curlError;ReplacementFor_curl=ReplacementFor_curl_easy_init();if(
!ReplacementFor_curl){}ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,ReplacementFor_CURLOPT_URL,
ReplacementFor_to));ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(
ReplacementFor_curl,ReplacementFor_CURLOPT_WRITEFUNCTION,
ReplacementFor_WriteFunc));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_WRITEDATA,&ReplacementFor_newreq));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_CONNECTTIMEOUT,10L));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_TIMEOUT,30L));ReplacementFor_curlError=
ReplacementFor_curl_easy_perform(ReplacementFor_curl);
ReplacementFor_CurlLogError(ReplacementFor_curlError);
ReplacementFor_curl_easy_cleanup(ReplacementFor_curl);if(!
ReplacementFor_curlError){}return EXIT_SUCCESS;}int 
ReplacementFor_PostPuzzleSolution(const char*ReplacementFor_to,const uint8_t*
ReplacementFor_nonce){uint32_t len;uint32_t pos=((0xc6a+6753-0x1cb0)+
(0x94c+1050-0xb9e)-3043);char ReplacementFor_request[
ReplacementFor_JSON_CAPACITY];strcpy(ReplacementFor_request+pos,"\x7b""\"""\x6e"
"\"""\x3a""\"");pos+=(2114+(0x1ff3+2332-0x1598)-(0x2293+1085-0xb1d));
ReplacementFor_LittleEndianToHexStr(ReplacementFor_nonce,
ReplacementFor_NONCE_SIZE_8,ReplacementFor_request+pos);pos+=
ReplacementFor_NONCE_SIZE_4;strcpy(ReplacementFor_request+pos,"\"}\0");
ReplacementFor_CURL*ReplacementFor_curl;ReplacementFor_curl=
ReplacementFor_curl_easy_init();if(!ReplacementFor_curl){}ReplacementFor_json_t 
ReplacementFor_respond(((0x1f88+1248-0x2319)+6206-(0x1c6c+7011-0x1e42)),
ReplacementFor_REQ_LEN);ReplacementFor_curl_slist*ReplacementFor_headers=NULL;
ReplacementFor_curl_slist*ReplacementFor_tmp;ReplacementFor_CURLcode 
ReplacementFor_curlError;ReplacementFor_tmp=ReplacementFor_curl_slist_append(
ReplacementFor_headers,
"\x41\x63\x63\x65\x70\x74\x3a\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"
);ReplacementFor_headers=ReplacementFor_curl_slist_append(ReplacementFor_tmp,
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"
);ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(
ReplacementFor_curl,ReplacementFor_CURLOPT_URL,ReplacementFor_to));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_HTTPHEADER,ReplacementFor_headers));;
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_POSTFIELDS,ReplacementFor_request));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_CONNECTTIMEOUT,30L));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_TIMEOUT,30L));ReplacementFor_CurlLogError(
ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_WRITEFUNCTION,ReplacementFor_WriteFunc));
ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl,
ReplacementFor_CURLOPT_WRITEDATA,&ReplacementFor_respond));int 
ReplacementFor_retries=((0x2107+443-0x31a)+(0xa98+7160-0x21c8)-9328);do{
ReplacementFor_curlError=ReplacementFor_curl_easy_perform(ReplacementFor_curl);
++ReplacementFor_retries;}while(ReplacementFor_retries<
ReplacementFor_MAX_POST_RETRIES&&ReplacementFor_curlError!=
ReplacementFor_CURLE_OK);ReplacementFor_CurlLogError(ReplacementFor_curlError);
ReplacementFor_curl_easy_cleanup(ReplacementFor_curl);
ReplacementFor_curl_slist_free_all(ReplacementFor_headers);return EXIT_SUCCESS;}

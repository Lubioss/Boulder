
#ifndef COMPACTION_H
#define COMPACTION_H
#include "definitions.h"
__device__ uint32_t WarpInc(uint32_t*len);__global__ void Compactify(const 
uint32_t*in,const uint32_t inlen,uint32_t*out,uint32_t*outlen);
#endif 


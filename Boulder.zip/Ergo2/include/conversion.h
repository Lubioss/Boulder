
#ifndef CONVERSION_H
#define CONVERSION_H
#include <stdint.h>
int DecStrToHexStrOf64(const char*in,const uint32_t inlen,char*out);void 
HexStrToBigEndian(const char*in,const uint32_t inlen,uint8_t*out,const uint32_t 
outlen);void HexStrToLittleEndian(const char*in,const uint32_t inlen,uint8_t*out
,const uint32_t outlen);void LittleEndianOf256ToDecStr(const uint8_t*in,char*out
,uint32_t*outlen);void LittleEndianToHexStr(const uint8_t*in,const uint32_t 
inlen,char*out);void BigEndianToHexStr(const uint8_t*in,const uint32_t inlen,
char*out);
#endif 



#ifndef CRYPTOGRAPHY_H
#define CRYPTOGRAPHY_H
#include "conversion.h"
int GenerateSecKey(const char*in,const int len,uint8_t*sk,char*skstr);int 
GenerateSecKeyNew(const char*in,const int len,uint8_t*sk,char*skstr,char*message
);int GenerateKeyPair(uint8_t*sk,uint8_t*pk);int GeneratePublicKey(const char*
skstr,char*pkstr,uint8_t*pk);int checkRandomDevice();
#endif 



#ifndef DEFINITIONS_H
#define DEFINITIONS_H
#include "jsmn.h" 
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <time.h>
#include <atomic>
#include <mutex>
#include <string.h>
#define CONST_MES_SIZE_8   8192 
#define CONTINUE_POS       (0x2aa+64-0x2c6)
#define K_LEN              (0x8df+3946-0x1829)
#define N_LEN              67108864 
#define MAX_SOLS (0x124a+4124-0x2256)
#define NONCES_PER_THREAD  (0x1b1a+1136-0x1f89)
#define MIN_FREE_MEMORY    2200000000
#define MIN_FREE_MEMORY_PREHASH 7300000000
#define NUM_SIZE_8         (0x223+8107-0x21ae)
#define PK_SIZE_8          (0x8df+7097-0x2477)
#define NONCE_SIZE_8       (0xa4f+1277-0xf44)
#define HEIGHT_SIZE       (0x896+3827-0x1785)
#define INDEX_SIZE_8       (0x64+159-0xff)
#define BUF_SIZE_8         (0xf74+5214-0x2352)
#define qhi_s              "\x30\x78\x46\x46\x46\x46\x46\x46\x46\x46"
#define q4_s               "\x30\x78\x46\x46\x46\x46\x46\x46\x46\x45"
#define q3_s               "\x30\x78\x42\x41\x41\x45\x44\x43\x45\x36"
#define q2_s               "\x30\x78\x41\x46\x34\x38\x41\x30\x33\x42"
#define q1_s               "\x30\x78\x42\x46\x44\x32\x35\x45\x38\x43"
#define q0_s               "\x30\x78\x44\x30\x33\x36\x34\x31\x34\x31"
#define Q3                 0xffffffffffffffff
#define Q2                 0xfffffffffffffffe
#define Q1                 0xbaaedce6af48a03b
#define Q0                 0xbfd25e8cd0364141
#define MAX_POST_RETRIES   (0x18d4+1942-0x2065)
#define MAX_URL_SIZE       (0x21f2+851-0x2145)
#define JSON_CAPACITY      (0x26a+2364-0xaa6)
#define MAX_JSON_CAPACITY  8192
#define REQ_LEN           (0x1a44+1611-0x2084)
#define MES_POS            (0x1206+2311-0x1b0b)
#define BOUND_POS          (0x1286+4101-0x2287)
#define PK_POS             (0xbe8+2879-0x1721)
#define CONF_LEN           (0x7fd+683-0xa93)
#define SEED_POS           (0x1089+2542-0x1a75)
#define NODE_POS           (0x383+2986-0xf29)
#define KEEP_POS           (0x377+5193-0x17ba)
#define ERROR_STAT         "\x73\x74\x61\x74"
#define ERROR_ALLOC        \
"\x48\x6f\x73\x74\x20\x6d\x65\x6d\x6f\x72\x79\x20\x61\x6c\x6c\x6f\x63\x61\x74\x69\x6f\x6e"
#define ERROR_IO           "\x49\x2f\x4f"
#define ERROR_CURL         "\x43\x75\x72\x6c"
#define ERROR_OPENSSL      "\x4f\x70\x65\x6e\x53\x53\x4c"
#define NUM_SIZE_4         (NUM_SIZE_8 << (0x14d4+1854-0x1c11))
#define NUM_SIZE_32        (NUM_SIZE_8 >> (0x14da+1628-0x1b34))
#define NUM_SIZE_64        (NUM_SIZE_8 >> (0x184b+965-0x1c0d))
#define NUM_SIZE_32_BLOCK  ((0x3f+570-0x278) + (NUM_SIZE_32 - \
(0xab2+6844-0x256d)) / BLOCK_DIM)
#define NUM_SIZE_8_BLOCK   (NUM_SIZE_32_BLOCK << (0x2ef+2840-0xe05))
#define ROUND_NUM_SIZE_32  (NUM_SIZE_32_BLOCK * BLOCK_DIM)
#define PK_SIZE_4          (PK_SIZE_8 << (0x14c7+1405-0x1a43))
#define PK_SIZE_32_BLOCK   ((0x672+1335-0xba8) + NUM_SIZE_32 / BLOCK_DIM)
#define PK_SIZE_8_BLOCK    (PK_SIZE_32_BLOCK << (0x43b+1895-0xba0))
#define ROUND_PK_SIZE_32   (PK_SIZE_32_BLOCK * BLOCK_DIM)
#define COUPLED_PK_SIZE_32 (((PK_SIZE_8 << (0x1c8a+368-0x1df9)) + \
(0x9a7+3850-0x18ae)) >> (0x151+6928-0x1c5f))
#define NONCE_SIZE_4       (NONCE_SIZE_8 << (0xebf+4452-0x2022))
#define NONCE_SIZE_32      (NONCE_SIZE_8 >> (0xb14+590-0xd60))
struct ctx_t;
#define DATA_SIZE_8                                                            \
(                                                                              \
    ((0x15e4+3104-0x2203) + ((0x1a8d+3178-0x26f5) * PK_SIZE_8 + \
(0x115f+1744-0x182d) + (0x1ca9+2457-0x263f) * NUM_SIZE_8 + sizeof(ctx_t) - \
(0x6db+2985-0x1283)) / BLOCK_DIM) \
    * BLOCK_DIM                                                                \
)
#define WORKSPACE_SIZE_8                                                       \
(                                                                              \
    (                                                                          \
        (uint32_t)((N_LEN << (0xde5+2062-0x15f2)) + (0xd4c+1209-0x1204)) * \
INDEX_SIZE_8                            \
        > NONCES_PER_ITER * (NUM_SIZE_8  + (INDEX_SIZE_8 << (0x336+2036-0xb29)))\
 + INDEX_SIZE_8 \
    )?                                                                         \
    (uint32_t)((N_LEN << (0xe3a+5248-0x22b9)) + (0xbb2+4672-0x1df1)) * \
INDEX_SIZE_8:                               \
    NONCES_PER_ITER * (NUM_SIZE_8  + (INDEX_SIZE_8 << (0x8cc+2385-0x121c))) + \
INDEX_SIZE_8       \
)
#define NP_SIZE_32_BLOCK   ((0x216f+1424-0x26fe) + (NUM_SIZE_32 << \
(0x17ff+99-0x1861)) / BLOCK_DIM)
#define NP_SIZE_8_BLOCK    (NP_SIZE_32_BLOCK << (0x11fd+2545-0x1bec))
#define ROUND_NP_SIZE_32   (NP_SIZE_32_BLOCK * BLOCK_DIM)
#define PNP_SIZE_32_BLOCK                                                      \
((0xd93+894-0x1110) + (COUPLED_PK_SIZE_32 + NUM_SIZE_32 - (0x718+3046-0x12fd)) /\
 BLOCK_DIM)
#define PNP_SIZE_8_BLOCK   (PNP_SIZE_32_BLOCK << (0x1c44+333-0x1d8f))
#define ROUND_PNP_SIZE_32  (PNP_SIZE_32_BLOCK * BLOCK_DIM)
#define NC_SIZE_32_BLOCK                                                       \
((0xcaf+821-0xfe3) + (NUM_SIZE_32 + sizeof(ctx_t) - (0x457+8264-0x249e)) / \
BLOCK_DIM)
#define NC_SIZE_8_BLOCK    (NC_SIZE_32_BLOCK << (0x126a+304-0x1398))
#define ROUND_NC_SIZE_32   (NC_SIZE_32_BLOCK * BLOCK_DIM)
#define N_MASK             (N_LEN - (0x8f+8863-0x232d))
#define THREADS_PER_ITER   (NONCES_PER_ITER / NONCES_PER_THREAD)
typedef unsigned int uint_t;typedef enum{STATE_CONTINUE=(0xd4f+2434-0x16d1),
STATE_KEYGEN=(0x1523+1015-0x1919),STATE_REHASH=(0xeb9+5707-0x2502),
STATE_INTERRUPT=(0x607+3334-0x130a)}state_t;struct info_t{std::mutex info_mutex;
uint8_t AlgVer;uint8_t bound[NUM_SIZE_8];uint8_t mes[NUM_SIZE_8];uint8_t sk[
NUM_SIZE_8];uint8_t pk[PK_SIZE_8];char skstr[NUM_SIZE_4];char pkstr[PK_SIZE_4+
(0x1a16+3008-0x25d5)];int keepPrehash;char to[MAX_URL_SIZE];char endJob[
MAX_URL_SIZE];bool doJob;char pool[MAX_URL_SIZE];uint8_t Hblock[HEIGHT_SIZE];
char stratumMode;uint8_t extraNonceStart[NONCE_SIZE_8];uint8_t extraNonceEnd[
NONCE_SIZE_8];std::atomic<uint_t>blockId;};struct json_t{size_t cap;size_t len;
char*ptr;jsmntok_t*toks;json_t(const int strlen,const int toklen);json_t(const 
json_t&newjson);~json_t(void);void Reset(void){len=(0x328+8119-0x22df);return;}
int GetTokenStartPos(const int pos){return toks[pos].start;}int GetTokenEndPos(
const int pos){return toks[pos].end;}int GetTokenLen(const int pos){return toks[
pos].end-toks[pos].start;}char*GetTokenStart(const int pos){return ptr+toks[pos]
.start;}char*GetTokenEnd(const int pos){return ptr+toks[pos].end;}int jsoneq(
const int pos,const char*str);};struct ctx_t{uint8_t b[BUF_SIZE_8];uint64_t h[
(0x1b62+1119-0x1fb9)];uint64_t t[(0x2+3846-0xf06)];uint32_t c;};struct uctx_t{
uint64_t h[(0xe3b+1419-0x13be)];uint64_t t[(0x2250+510-0x244c)];};
#define CTX_SIZE sizeof(ctx_t)
#define B2B_IV(v)                                                              \
do                                                                             \
{                                                                              \
    ((uint64_t *)(v))[(0xe92+5287-0x2339)] = 0x6a09e667f3bcc908;\
                                 \
    ((uint64_t *)(v))[(0x22eb+1041-0x26fb)] = 0xbb67ae8584caa73b;\
                                 \
    ((uint64_t *)(v))[(0x176d+1358-0x1cb9)] = 0x3c6ef372fe94f82b;\
                                 \
    ((uint64_t *)(v))[(0x1020+1287-0x1524)] = 0xa54ff53a5f1d36f1;\
                                 \
    ((uint64_t *)(v))[(0x637+4397-0x1760)] = 0x510e527fade682d1;\
                                 \
    ((uint64_t *)(v))[(0x16a+7194-0x1d7f)] = 0x9b05688c2b3e6c1f;\
                                 \
    ((uint64_t *)(v))[(0x19df+2583-0x23f0)] = 0x1f83d9abfb41bd6b;\
                                 \
    ((uint64_t *)(v))[(0x48f+4916-0x17bc)] = 0x5be0cd19137e2179;\
                                 \
}                                                                              \
while ((0x124d+79-0x129c))
#define ROTR64(x, y) (((x) >> (y)) ^ ((x) << ((0x15c1+4364-0x268d) - (y))))
#define B2B_G(v, a, b, c, d, x, y)                                             \
do                                                                             \
{                                                                              \
    ((uint64_t *)(v))[a] += ((uint64_t *)(v))[b] + x;                          \
    ((uint64_t *)(v))[d]                                                       \
        = ROTR64(((uint64_t *)(v))[d] ^ ((uint64_t *)(v))[a], (0x476+2967-0xfed)\
);             \
    ((uint64_t *)(v))[c] += ((uint64_t *)(v))[d];                              \
    ((uint64_t *)(v))[b]                                                       \
        = ROTR64(((uint64_t *)(v))[b] ^ ((uint64_t *)(v))[c], (0x20f+873-0x560))\
;             \
    ((uint64_t *)(v))[a] += ((uint64_t *)(v))[b] + y;                          \
    ((uint64_t *)(v))[d]                                                       \
        = ROTR64(((uint64_t *)(v))[d] ^ ((uint64_t *)(v))[a], \
(0x1054+325-0x1189));             \
    ((uint64_t *)(v))[c] += ((uint64_t *)(v))[d];                              \
    ((uint64_t *)(v))[b]                                                       \
        = ROTR64(((uint64_t *)(v))[b] ^ ((uint64_t *)(v))[c], (0xf38+107-0xf64))\
;             \
}                                                                              \
while ((0x208+5317-0x16cd))
#define B2B_MIX(v, m)                                                          \
do                                                                             \
{                                                                              \
    B2B_G(v, (0x6c9+438-0x87f), (0x4ed+8307-0x255c),  (0x5d7+5889-0x1cd0), \
(0x18a9+1180-0x1d39), ((uint64_t *)(m))[ (0x44+124-0xc0)], ((uint64_t *)(m))[ \
(0x1093+3524-0x1e56)]);      \
    B2B_G(v, (0xe13+4745-0x209b), (0x1c7+5796-0x1866),  (0x527+1004-0x90a), \
(0x28+4979-0x138e), ((uint64_t *)(m))[ (0xa2b+4561-0x1bfa)], ((uint64_t *)(m))[ \
(0x1c2+4864-0x14bf)]);      \
    B2B_G(v, (0x1b39+866-0x1e99), (0x13d+22-0x14d), (0xd26+4665-0x1f55), \
(0x3e9+1763-0xabe), ((uint64_t *)(m))[ (0x1060+171-0x1107)], ((uint64_t *)(m))[ \
(0x4f4+7725-0x231c)]);      \
    B2B_G(v, (0x296+5506-0x1815), (0x38f+5133-0x1795), (0x186c+3678-0x26bf), \
(0x3ad+7343-0x204d), ((uint64_t *)(m))[ (0x23+4399-0x114c)], ((uint64_t *)(m))[ \
(0xfd3+2156-0x1838)]);      \
    B2B_G(v, (0xd34+2547-0x1727), (0x1727+2412-0x208e), (0x483+1840-0xba9), \
(0x7f6+1210-0xca1), ((uint64_t *)(m))[ (0x4a0+2141-0xcf5)], ((uint64_t *)(m))[ \
(0x208+6538-0x1b89)]);      \
    B2B_G(v, (0x1f8c+897-0x230c), (0xa81+5812-0x212f), (0x3f6+1109-0x840), \
(0x9b5+4099-0x19ac), ((uint64_t *)(m))[(0xed8+1201-0x137f)], ((uint64_t *)(m))[\
(0x55c+248-0x649)]);      \
    B2B_G(v, (0xda3+6430-0x26bf), (0x7b6+1223-0xc76),  (0x780+4587-0x1963), \
(0x206+1199-0x6a8), ((uint64_t *)(m))[(0x76d+4397-0x188e)], ((uint64_t *)(m))[\
(0x4d9+2560-0xecc)]);      \
    B2B_G(v, (0x5ab+2559-0xfa7), (0x116c+1104-0x15b8),  (0x1856+2250-0x2117), \
(0xc0d+5515-0x218a), ((uint64_t *)(m))[(0x160+9422-0x2620)], ((uint64_t *)(m))[\
(0x11d5+4975-0x2535)]);      \
                                                                               \
    B2B_G(v, (0x2a5+6142-0x1aa3), (0xe9d+259-0xf9c),  (0xb96+4482-0x1d10), \
(0x12e1+3969-0x2256), ((uint64_t *)(m))[(0x1845+2604-0x2263)], ((uint64_t *)(m))\
[(0xf31+3228-0x1bc3)]);      \
    B2B_G(v, (0xad2+955-0xe8c), (0x1e34+359-0x1f96),  (0xed+1518-0x6d2), \
(0x1a2+5604-0x1779), ((uint64_t *)(m))[ (0x1a7f+1968-0x222b)], ((uint64_t *)(m))\
[ (0x159+7306-0x1ddb)]);      \
    B2B_G(v, (0xd39+404-0xecb), (0x229b+810-0x25bf), (0x250+7158-0x1e3c), \
(0x686+1684-0xd0c), ((uint64_t *)(m))[ (0x1a5+3771-0x1057)], ((uint64_t *)(m))[\
(0x479+7596-0x2216)]);      \
    B2B_G(v, (0x1a28+1100-0x1e71), (0x686+5158-0x1aa5), (0x3a6+4622-0x15a9), \
(0x14f3+2602-0x1f0e), ((uint64_t *)(m))[(0x178c+3735-0x2616)], ((uint64_t *)(m))\
[ (0xc3d+5996-0x23a3)]);      \
    B2B_G(v, (0x1fba+941-0x2367), (0x2dd+1654-0x94e), (0x864+7593-0x2603), \
(0x1d47+851-0x208b), ((uint64_t *)(m))[ (0xb51+7035-0x26cb)], ((uint64_t *)(m))[\
(0x4ea+7125-0x20b3)]);      \
    B2B_G(v, (0x162+2193-0x9f2), (0x94f+916-0xcdd), (0xbc+4488-0x1239), \
(0x1d3a+1945-0x24c7), ((uint64_t *)(m))[ (0x218+1648-0x888)], ((uint64_t *)(m))[\
 (0x212+1582-0x83e)]);      \
    B2B_G(v, (0x18cf+916-0x1c61), (0x197+1358-0x6de),  (0x15cc+4328-0x26ac), \
(0xbc6+5165-0x1fe6), ((uint64_t *)(m))[(0xbb2+1594-0x11e1)], ((uint64_t *)(m))[ \
(0x1972+2505-0x2334)]);      \
    B2B_G(v, (0x1bfd+2259-0x24cd), (0x1904+1155-0x1d83),  (0x164b+1641-0x1cab), \
(0xfb5+803-0x12ca), ((uint64_t *)(m))[ (0x210d+303-0x2237)], ((uint64_t *)(m))[ \
(0x1c+873-0x382)]);      \
                                                                               \
    B2B_G(v, (0x14c5+1650-0x1b37), (0x518+8252-0x2550),  (0x5a+3235-0xcf5), \
(0xe2f+6108-0x25ff), ((uint64_t *)(m))[(0x206+7509-0x1f50)], ((uint64_t *)(m))[ \
(0xd16+1043-0x1121)]);      \
    B2B_G(v, (0x4b5+3655-0x12fb), (0x15e7+3229-0x227f),  (0x1790+3009-0x2348), \
(0x15c4+827-0x18f2), ((uint64_t *)(m))[(0x7f5+4461-0x1956)], ((uint64_t *)(m))[ \
(0x854+1814-0xf6a)]);      \
    B2B_G(v, (0xc6+6868-0x1b98), (0x9d6+1785-0x10c9), (0x2d0+2013-0xaa3), \
(0x174c+2306-0x2040), ((uint64_t *)(m))[ (0x1efa+74-0x1f3f)], ((uint64_t *)(m))[\
 (0x500+168-0x5a6)]);      \
    B2B_G(v, (0x114f+5116-0x2548), (0xd6b+1384-0x12cc), (0x52d+3034-0x10fc), \
(0x3f6+7784-0x224f), ((uint64_t *)(m))[(0x7cf+4330-0x18aa)], ((uint64_t *)(m))[\
(0xa62+2458-0x13ef)]);      \
    B2B_G(v, (0x1b1+6600-0x1b79), (0x105b+2171-0x18d1), (0x7b4+7518-0x2508), \
(0xfc5+1531-0x15b1), ((uint64_t *)(m))[(0x768+3951-0x16cd)], ((uint64_t *)(m))[\
(0x598+3360-0x12aa)]);      \
    B2B_G(v, (0x1480+3161-0x20d8), (0x904+1227-0xdc9), (0x9e1+4480-0x1b56), \
(0x41d+5588-0x19e5), ((uint64_t *)(m))[ (0x892+3945-0x17f8)], ((uint64_t *)(m))[\
 (0x11e0+2398-0x1b38)]);      \
    B2B_G(v, (0x17d9+41-0x1800), (0x5c0+7512-0x2311),  (0xb77+4636-0x1d8b), \
(0x1ec1+1102-0x2302), ((uint64_t *)(m))[ (0x1221+1373-0x1777)], ((uint64_t *)(m)\
)[ (0x7ea+5355-0x1cd4)]);      \
    B2B_G(v, (0x6bb+1810-0xdca), (0x1d2+6569-0x1b77),  (0x1aec+1793-0x21e4), \
(0x1046+1317-0x155d), ((uint64_t *)(m))[ (0x781+452-0x93c)], ((uint64_t *)(m))[ \
(0x1026+5135-0x2431)]);      \
                                                                               \
    B2B_G(v, (0xd6+8793-0x232f), (0x528+805-0x849),  (0x8bc+5320-0x1d7c), \
(0x1ac3+598-0x1d0d), ((uint64_t *)(m))[ (0x6e5+4433-0x182f)], ((uint64_t *)(m))[\
 (0x3b5+3211-0x1037)]);      \
    B2B_G(v, (0x17a8+3882-0x26d1), (0xd4a+6349-0x2612),  (0x2cb+988-0x69e), \
(0x398+1009-0x77c), ((uint64_t *)(m))[ (0x911+3545-0x16e7)], ((uint64_t *)(m))[ \
(0x1fb6+889-0x232e)]);      \
    B2B_G(v, (0x16fb+3530-0x24c3), (0x321+6895-0x1e0a), (0x1104+397-0x1287), \
(0x194d+2892-0x248b), ((uint64_t *)(m))[(0x486+4368-0x1589)], ((uint64_t *)(m))[\
(0x12dc+5013-0x2665)]);      \
    B2B_G(v, (0x23a+1818-0x951), (0x58c+4345-0x167e), (0x4c3+4137-0x14e1), \
(0x1205+13-0x1203), ((uint64_t *)(m))[(0x1c91+2363-0x25c1)], ((uint64_t *)(m))[\
(0xff3+2679-0x1a5c)]);      \
    B2B_G(v, (0x799+1424-0xd29), (0x8e1+2976-0x147c), (0x137b+333-0x14be), \
(0x1156+105-0x11b0), ((uint64_t *)(m))[ (0x9c4+6280-0x224a)], ((uint64_t *)(m))[\
 (0x818+7811-0x2695)]);      \
    B2B_G(v, (0x109b+1995-0x1865), (0x149+4036-0x1107), (0x8f+8785-0x22d5), \
(0x2231+411-0x23c0), ((uint64_t *)(m))[ (0x6e6+3575-0x14d8)], ((uint64_t *)(m))[\
(0x38c+2345-0xcab)]);      \
    B2B_G(v, (0x1b2a+1594-0x2162), (0xb42+2857-0x1664),  (0x6cd+4801-0x1986), \
(0x140b+3173-0x2063), ((uint64_t *)(m))[ (0x4d7+8529-0x2624)], ((uint64_t *)(m))\
[ (0x2143+801-0x2464)]);      \
    B2B_G(v, (0x215+6174-0x1a30), (0x6e7+3-0x6e6),  (0xd6a+3416-0x1ab9), \
(0x1860+3482-0x25ec), ((uint64_t *)(m))[(0xc5d+4577-0x1e2f)], ((uint64_t *)(m))[\
 (0x2270+1152-0x26e8)]);      \
                                                                               \
    B2B_G(v, (0x152b+1988-0x1cef), (0x9b0+3540-0x1780),  (0xc8f+1578-0x12b1), \
(0x5af+2720-0x1043), ((uint64_t *)(m))[ (0x2e1+1591-0x90f)], ((uint64_t *)(m))[ \
(0xccc+3102-0x18ea)]);      \
    B2B_G(v, (0xb6a+3673-0x19c2), (0x1423+4525-0x25cb),  (0xb84+3242-0x1825), \
(0x516+424-0x6b1), ((uint64_t *)(m))[ (0xbfa+143-0xc84)], ((uint64_t *)(m))[ \
(0x817+7015-0x2377)]);      \
    B2B_G(v, (0x61c+6425-0x1f33), (0x6e0+6396-0x1fd6), (0x191b+1341-0x1e4e), \
(0xb0f+4670-0x1d3f), ((uint64_t *)(m))[ (0x3b7+5234-0x1827)], ((uint64_t *)(m))[\
 (0x273+4140-0x129b)]);      \
    B2B_G(v, (0x525+4400-0x1652), (0x4f2+1175-0x982), (0xf12+2751-0x19c6), \
(0x134+887-0x49c), ((uint64_t *)(m))[(0x1be4+2430-0x2558)], ((uint64_t *)(m))[\
(0xaaf+5008-0x1e30)]);      \
    B2B_G(v, (0x243+1670-0x8c9), (0x217a+936-0x251d), (0x14c9+225-0x15a0), \
(0xb90+1181-0x101e), ((uint64_t *)(m))[(0x8bd+4420-0x19f3)], ((uint64_t *)(m))[ \
(0x8d8+6767-0x2346)]);      \
    B2B_G(v, (0xe8a+789-0x119e), (0x168f+2990-0x2237), (0x608+5315-0x1ac0), \
(0x3ca+7453-0x20db), ((uint64_t *)(m))[(0xfd5+3284-0x1c9e)], ((uint64_t *)(m))[\
(0x1383+2906-0x1ed1)]);      \
    B2B_G(v, (0x3a8+6037-0x1b3b), (0x206+4931-0x1542),  (0x1ffa+445-0x21af), \
(0x167f+1846-0x1da8), ((uint64_t *)(m))[ (0x66d+6398-0x1f65)], ((uint64_t *)(m))\
[ (0x1250+1651-0x18bb)]);      \
    B2B_G(v, (0x1377+2868-0x1ea8), (0xc49+1683-0x12d8),  (0xc50+1830-0x136d), \
(0x251+8021-0x2198), ((uint64_t *)(m))[ (0x8eb+2133-0x113d)], ((uint64_t *)(m))[\
(0xfb9+5788-0x2648)]);      \
                                                                               \
    B2B_G(v, (0x1d8f+480-0x1f6f), (0xd02+898-0x1080),  (0x935+7289-0x25a6), \
(0x1a8c+1443-0x2023), ((uint64_t *)(m))[ (0x81d+5207-0x1c72)], ((uint64_t *)(m))\
[(0x207+5213-0x1658)]);      \
    B2B_G(v, (0x1069+2533-0x1a4d), (0xa92+1194-0xf37),  (0x13e3+4030-0x2398), \
(0x16a1+1877-0x1de9), ((uint64_t *)(m))[ (0x1b01+1039-0x1f0a)], ((uint64_t *)(m)\
)[(0xc65+243-0xd4e)]);      \
    B2B_G(v, (0x1c98+2377-0x25df), (0x44f+2579-0xe5c), (0xb9f+491-0xd80), \
(0x555+7342-0x21f5), ((uint64_t *)(m))[ (0x3f1+1651-0xa64)], ((uint64_t *)(m))[\
(0x139+883-0x4a1)]);      \
    B2B_G(v, (0x1b19+385-0x1c97), (0x12cb+1116-0x1720), (0x1264+2934-0x1dcf), \
(0x337+9110-0x26be), ((uint64_t *)(m))[ (0x179b+2971-0x232e)], ((uint64_t *)(m))\
[ (0x845+5660-0x1e5e)]);      \
    B2B_G(v, (0x19f8+1052-0x1e14), (0xf5a+5295-0x2404), (0x1289+3405-0x1fcc), \
(0x17a5+548-0x19ba), ((uint64_t *)(m))[ (0x361+7050-0x1ee7)], ((uint64_t *)(m))[\
(0xde9+613-0x1041)]);      \
    B2B_G(v, (0x5bc+134-0x641), (0x636+4283-0x16eb), (0x23d7+137-0x2455), \
(0x20d0+488-0x22ac), ((uint64_t *)(m))[ (0x1af+2531-0xb8b)], ((uint64_t *)(m))[ \
(0xec+9417-0x25b0)]);      \
    B2B_G(v, (0x150+4763-0x13e9), (0x13bc+1763-0x1a98),  (0x159d+4182-0x25eb), \
(0xa9a+7181-0x269a), ((uint64_t *)(m))[(0x126d+2908-0x1dba)], ((uint64_t *)(m))[\
(0x1515+1853-0x1c44)]);      \
    B2B_G(v, (0x1be9+769-0x1ee7), (0x2157+1150-0x25d1),  (0x1ab4+2902-0x2601), \
(0x10e8+305-0x120b), ((uint64_t *)(m))[ (0x698+4874-0x19a1)], ((uint64_t *)(m))[\
 (0x1ae3+1508-0x20be)]);      \
                                                                               \
    B2B_G(v, (0xd5c+6310-0x2602), (0x1314+3230-0x1fae),  (0xa89+5305-0x1f3a), \
(0x670+8127-0x2623), ((uint64_t *)(m))[(0x33+4768-0x12c7)], ((uint64_t *)(m))[ \
(0x1b+1885-0x773)]);      \
    B2B_G(v, (0x190+6886-0x1c75), (0x234+8786-0x2481),  (0x593+4596-0x177e), \
(0xaed+4938-0x1e2a), ((uint64_t *)(m))[ (0x1093+1873-0x17e3)], ((uint64_t *)(m))\
[(0x1ea1+1671-0x2519)]);      \
    B2B_G(v, (0x189b+248-0x1991), (0xca7+3860-0x1bb5), (0xb9d+3833-0x1a8c), \
(0xd22+2883-0x1857), ((uint64_t *)(m))[(0x201c+1358-0x255c)], ((uint64_t *)(m))[\
(0x10da+1122-0x152f)]);      \
    B2B_G(v, (0x4c3+8222-0x24de), (0xfdc+4748-0x2261), (0x1175+1287-0x1671), \
(0xd86+4775-0x201e), ((uint64_t *)(m))[ (0x263b+32-0x2657)], ((uint64_t *)(m))[\
(0x94f+28-0x961)]);      \
    B2B_G(v, (0x1c4a+1626-0x22a4), (0x1e43+516-0x2042), (0x132b+214-0x13f7), \
(0xb55+3867-0x1a61), ((uint64_t *)(m))[ (0x1b66+2532-0x254a)], ((uint64_t *)(m))\
[ (0x130+2826-0xc33)]);      \
    B2B_G(v, (0xf58+150-0xfed), (0xb92+5253-0x2011), (0xe45+5041-0x21eb), \
(0x67d+3664-0x14c1), ((uint64_t *)(m))[ (0x484+3483-0x1219)], ((uint64_t *)(m))[\
 (0x3bc+808-0x6e1)]);      \
    B2B_G(v, (0x1a38+2569-0x243f), (0xd91+4061-0x1d67),  (0xb94+6560-0x252c), \
(0x1800+2760-0x22bb), ((uint64_t *)(m))[ (0x1660+125-0x16d4)], ((uint64_t *)(m))\
[ (0x907+3071-0x1504)]);      \
    B2B_G(v, (0x100c+4282-0x20c3), (0x885+7095-0x2438),  (0x46+1466-0x5f7), \
(0xe42+3746-0x1cd6), ((uint64_t *)(m))[ (0x10a6+2901-0x1bf3)], ((uint64_t *)(m))\
[(0xba+348-0x20b)]);      \
                                                                               \
    B2B_G(v, (0xa8d+6344-0x2355), (0xdd2+1162-0x1258),  (0xb3f+3558-0x191d), \
(0xc25+860-0xf75), ((uint64_t *)(m))[(0x4af+603-0x6fd)], ((uint64_t *)(m))[\
(0xba9+2886-0x16e4)]);      \
    B2B_G(v, (0x1393+1591-0x19c9), (0x6b5+4703-0x190f),  (0xfdf+2960-0x1b66), \
(0x7bc+7156-0x23a3), ((uint64_t *)(m))[ (0xbd0+1481-0x1192)], ((uint64_t *)(m))[\
(0xf02+2417-0x1865)]);      \
    B2B_G(v, (0x192+2996-0xd44), (0x1a1f+2627-0x245c), (0x68+5586-0x1630), \
(0xd18+3661-0x1b57), ((uint64_t *)(m))[(0x900+917-0xc89)], ((uint64_t *)(m))[ \
(0x211+7682-0x2012)]);      \
    B2B_G(v, (0xca5+1627-0x12fd), (0xcf3+1268-0x11e0), (0x73+9010-0x239a), \
(0x2020+1327-0x2540), ((uint64_t *)(m))[ (0x1df+9043-0x252f)], ((uint64_t *)(m))\
[ (0xc6a+4598-0x1e57)]);      \
    B2B_G(v, (0xa6d+945-0xe1e), (0xd06+4445-0x1e5e), (0x1fd+8152-0x21cb), \
(0x1587+1213-0x1a35), ((uint64_t *)(m))[ (0xea7+5942-0x25d8)], ((uint64_t *)(m))\
[ (0x4b3+8168-0x249b)]);      \
    B2B_G(v, (0x6d3+7774-0x2530), (0x85f+7349-0x250e), (0x1e28+2013-0x25fa), \
(0x1812+773-0x1b0b), ((uint64_t *)(m))[(0x18f2+692-0x1b97)], ((uint64_t *)(m))[ \
(0xb8d+680-0xe31)]);      \
    B2B_G(v, (0xdaa+166-0xe4e), (0x9ca+4659-0x1bf6),  (0x1bf7+681-0x1e98), \
(0x44c+7504-0x218f), ((uint64_t *)(m))[ (0xd74+6363-0x2647)], ((uint64_t *)(m))[\
 (0x1c4+1109-0x613)]);      \
    B2B_G(v, (0x1a41+2415-0x23ad), (0x13b0+3841-0x22ad),  (0x5f6+2096-0xe1d), \
(0x1ed6+628-0x213c), ((uint64_t *)(m))[ (0xa7d+7069-0x2618)], ((uint64_t *)(m))[\
(0x1e2a+44-0x1e4c)]);      \
                                                                               \
    B2B_G(v, (0x1d10+877-0x207d), (0x118f+1974-0x1941),  (0x1783+1892-0x1edf), \
(0x113c+4806-0x23f6), ((uint64_t *)(m))[ (0x1d2a+951-0x20db)], ((uint64_t *)(m))\
[(0x7ea+4289-0x189c)]);      \
    B2B_G(v, (0x83+9690-0x265c), (0x34d+653-0x5d5),  (0x36b+5698-0x19a4), \
(0x1119+1916-0x1888), ((uint64_t *)(m))[(0xd8f+963-0x1144)], ((uint64_t *)(m))[ \
(0x1b4b+466-0x1d14)]);      \
    B2B_G(v, (0xc5f+1870-0x13ab), (0x176c+181-0x181b), (0x5a6+199-0x663), \
(0xa97+3043-0x166c), ((uint64_t *)(m))[(0x560+7943-0x245c)], ((uint64_t *)(m))[ \
(0x296+8683-0x247e)]);      \
    B2B_G(v, (0xb50+3963-0x1ac8), (0x152+6406-0x1a51), (0xb1f+415-0xcb3), \
(0xabc+1264-0xf9d), ((uint64_t *)(m))[ (0x649+5137-0x1a5a)], ((uint64_t *)(m))[ \
(0x11c7+1325-0x16ec)]);      \
    B2B_G(v, (0xe5c+2784-0x193c), (0x1e51+1704-0x24f4), (0x3a5+3208-0x1023), \
(0x94b+317-0xa79), ((uint64_t *)(m))[(0x9cd+6862-0x248f)], ((uint64_t *)(m))[ \
(0x985+6496-0x22e3)]);      \
    B2B_G(v, (0x1d29+1411-0x22ab), (0x314+3946-0x1278), (0x924+2321-0x122a), \
(0x258+3180-0xeb8), ((uint64_t *)(m))[(0xc41+4899-0x1f57)], ((uint64_t *)(m))[ \
(0x1755+1368-0x1ca6)]);      \
    B2B_G(v, (0x759+5033-0x1b00), (0x1dd+3428-0xf3a),  (0x724+6816-0x21bc), \
(0x1355+3473-0x20d9), ((uint64_t *)(m))[ (0xca5+26-0xcbe)], ((uint64_t *)(m))[ \
(0x171+7093-0x1d22)]);      \
    B2B_G(v, (0x171c+2581-0x212e), (0x148+428-0x2f0),  (0xaad+6671-0x24b3), \
(0x8d4+4006-0x186c), ((uint64_t *)(m))[(0x10c1+78-0x1105)], ((uint64_t *)(m))[ \
(0xb3a+120-0xbad)]);      \
                                                                               \
    B2B_G(v, (0x741+4022-0x16f7), (0x1392+3985-0x231f),  (0x6bd+7852-0x2561), \
(0xa9b+1182-0xf2d), ((uint64_t *)(m))[(0x237+1053-0x64a)], ((uint64_t *)(m))[ \
(0x19a8+2352-0x22d6)]);      \
    B2B_G(v, (0x49f+3671-0x12f5), (0x2325+77-0x236d),  (0x313+833-0x64b), \
(0xa15+2767-0x14d7), ((uint64_t *)(m))[ (0xcb2+6349-0x2577)], ((uint64_t *)(m))[\
 (0x128c+1001-0x1671)]);      \
    B2B_G(v, (0xa35+3641-0x186c), (0xc2b+2566-0x162b), (0x1028+4512-0x21be), \
(0x15c2+2718-0x2052), ((uint64_t *)(m))[ (0xc9+7574-0x1e58)], ((uint64_t *)(m))[\
 (0xd54+5990-0x24b4)]);      \
    B2B_G(v, (0xa58+1203-0xf08), (0xc33+5161-0x2055), (0x23d+4410-0x136c), \
(0xb6b+1607-0x11a3), ((uint64_t *)(m))[ (0x50+4637-0x126c)], ((uint64_t *)(m))[ \
(0x481+220-0x558)]);      \
    B2B_G(v, (0x1ff7+351-0x2156), (0xb24+3065-0x1718), (0x1140+2485-0x1aeb), \
(0xa2f+1996-0x11ec), ((uint64_t *)(m))[(0x1e2a+2022-0x2601)], ((uint64_t *)(m))[\
(0x1995+1861-0x20cf)]);      \
    B2B_G(v, (0xc18+6518-0x258d), (0xf7f+193-0x103a), (0x46+3256-0xcf3), \
(0xa24+1781-0x110d), ((uint64_t *)(m))[ (0x1cb9+1868-0x23fc)], ((uint64_t *)(m))\
[(0xda9+3449-0x1b14)]);      \
    B2B_G(v, (0x294+5140-0x16a6), (0xbff+886-0xf6e),  (0x1bec+2143-0x2443), \
(0x22a3+936-0x263e), ((uint64_t *)(m))[ (0x57+8682-0x223e)], ((uint64_t *)(m))[\
(0x7db+444-0x98b)]);      \
    B2B_G(v, (0x1c7d+93-0x1cd7), (0x298+126-0x312),  (0x2f8+2931-0xe62), \
(0x223+7921-0x2106), ((uint64_t *)(m))[(0x1586+1702-0x1c1f)], ((uint64_t *)(m))[\
 (0x16b3+2028-0x1e9f)]);      \
                                                                               \
    B2B_G(v, (0x81a+3637-0x164f), (0xb13+6048-0x22af),  (0x7b+8402-0x2145), \
(0x1fd+4894-0x150f), ((uint64_t *)(m))[ (0xb5f+4849-0x1e50)], ((uint64_t *)(m))[\
 (0xf61+5464-0x24b8)]);      \
    B2B_G(v, (0x13e1+2439-0x1d67), (0x13da+1543-0x19dc),  (0x864+1747-0xf2e), \
(0x13a8+83-0x13ee), ((uint64_t *)(m))[ (0x14ec+1424-0x1a7a)], ((uint64_t *)(m))[\
 (0x98d+4550-0x1b50)]);      \
    B2B_G(v, (0xa45+1942-0x11d9), (0x23d5+774-0x26d5), (0xe41+596-0x108b), \
(0xfc6+78-0x1006), ((uint64_t *)(m))[ (0x59c+6578-0x1f4a)], ((uint64_t *)(m))[ \
(0x1737+2066-0x1f44)]);      \
    B2B_G(v, (0x23b3+568-0x25e8), (0xd18+759-0x1008), (0xfa8+1849-0x16d6), \
(0x19cf+1255-0x1ea7), ((uint64_t *)(m))[ (0x5c7+8350-0x265f)], ((uint64_t *)(m))\
[ (0x1b44+911-0x1ecc)]);      \
    B2B_G(v, (0x1b8c+1236-0x2060), (0x1218+2441-0x1b9c), (0x1140+2588-0x1b52), \
(0x274+8979-0x2578), ((uint64_t *)(m))[ (0x5dd+4718-0x1843)], ((uint64_t *)(m))[\
 (0x12d1+2982-0x1e6e)]);      \
    B2B_G(v, (0xfaa+2682-0x1a23), (0x1c4c+2405-0x25ab), (0x542+420-0x6db), \
(0x635+1528-0xc21), ((uint64_t *)(m))[(0x61b+2333-0xf2e)], ((uint64_t *)(m))[\
(0x194f+1423-0x1ed3)]);      \
    B2B_G(v, (0x16d+1613-0x7b8), (0x103c+3143-0x1c7c),  (0x156+676-0x3f2), \
(0x183d+1641-0x1e99), ((uint64_t *)(m))[(0xc11+386-0xd87)], ((uint64_t *)(m))[\
(0x1dd+9079-0x2547)]);      \
    B2B_G(v, (0xbc4+2650-0x161b), (0xca4+6564-0x2644),  (0xf5a+5771-0x25dc), \
(0x1922+1168-0x1da4), ((uint64_t *)(m))[(0x1c5+309-0x2ec)], ((uint64_t *)(m))[\
(0x2a6+3809-0x1178)]);      \
                                                                               \
    B2B_G(v, (0x408+3985-0x1399), (0x17f8+924-0x1b90),  (0x1708+885-0x1a75), \
(0xa29+3910-0x1963), ((uint64_t *)(m))[(0xc2+5774-0x1742)], ((uint64_t *)(m))[\
(0x396+8691-0x257f)]);      \
    B2B_G(v, (0x416+8753-0x2646), (0x1393+4456-0x24f6),  (0x23f6+305-0x251e), \
(0x1eb4+1062-0x22cd), ((uint64_t *)(m))[ (0xc6+8558-0x2230)], ((uint64_t *)(m))[\
 (0x800+976-0xbc8)]);      \
    B2B_G(v, (0x7aa+7423-0x24a7), (0x1580+1671-0x1c01), (0x7fd+567-0xa2a), \
(0xe6d+2327-0x1776), ((uint64_t *)(m))[ (0x971+7353-0x2621)], ((uint64_t *)(m))[\
(0xaf0+2946-0x1663)]);      \
    B2B_G(v, (0x7a9+2599-0x11cd), (0x80b+6501-0x2169), (0x91f+372-0xa88), \
(0xcd5+4702-0x1f24), ((uint64_t *)(m))[(0xb8a+2220-0x1429)], ((uint64_t *)(m))[ \
(0x9bc+4369-0x1ac7)]);      \
    B2B_G(v, (0x427+88-0x47f), (0x6ea+5516-0x1c71), (0xe5f+1982-0x1613), \
(0x58c+7242-0x21c7), ((uint64_t *)(m))[ (0x1442+4406-0x2577)], ((uint64_t *)(m))\
[(0x126b+4103-0x2266)]);      \
    B2B_G(v, (0x1ddf+189-0x1e9b), (0x23c+9260-0x2662), (0x971+5366-0x1e5c), \
(0x468+6966-0x1f92), ((uint64_t *)(m))[ (0x68+3566-0xe56)], ((uint64_t *)(m))[ \
(0xf3d+2067-0x174e)]);      \
    B2B_G(v, (0x1e09+2189-0x2694), (0x3e5+8790-0x2634),  (0x65f+3988-0x15eb), \
(0x1e48+211-0x1f0e), ((uint64_t *)(m))[(0xe1c+3291-0x1aec)], ((uint64_t *)(m))[ \
(0xe10+408-0xfa1)]);      \
    B2B_G(v, (0x5b2+3340-0x12bb), (0x1de6+857-0x213b),  (0x1c47+2709-0x26d3), \
(0x1ef3+30-0x1f03), ((uint64_t *)(m))[ (0x157+6849-0x1c13)], ((uint64_t *)(m))[ \
(0x1070+3078-0x1c73)]);      \
}                                                                              \
while ((0xf0d+470-0x10e3))
#define B2B_INIT(ctx, aux)                                                     \
do                                                                             \
{                                                                              \
    ((uint64_t *)(aux))[(0xbbd+2125-0x140a)] = ((ctx_t *)(ctx))->h[\
(0xf9c+2590-0x19ba)];                           \
    ((uint64_t *)(aux))[(0x15fd+937-0x19a5)] = ((ctx_t *)(ctx))->h[\
(0xa9a+6286-0x2327)];                           \
    ((uint64_t *)(aux))[(0xcc0+4067-0x1ca1)] = ((ctx_t *)(ctx))->h[\
(0x291+423-0x436)];                           \
    ((uint64_t *)(aux))[(0x1a0f+2991-0x25bb)] = ((ctx_t *)(ctx))->h[\
(0x1fed+1152-0x246a)];                           \
    ((uint64_t *)(aux))[(0x75f+1803-0xe66)] = ((ctx_t *)(ctx))->h[\
(0x9f7+791-0xd0a)];                           \
    ((uint64_t *)(aux))[(0x14f6+432-0x16a1)] = ((ctx_t *)(ctx))->h[\
(0x430+1236-0x8ff)];                           \
    ((uint64_t *)(aux))[(0x1067+5558-0x2617)] = ((ctx_t *)(ctx))->h[\
(0xd9a+4629-0x1fa9)];                           \
    ((uint64_t *)(aux))[(0x11e5+4490-0x2368)] = ((ctx_t *)(ctx))->h[\
(0xe17+5411-0x2333)];                           \
                                                                               \
    B2B_IV(aux + (0x1371+2526-0x1d47));\
                                                           \
                                                                               \
    ((uint64_t *)(aux))[(0xe42+17-0xe47)] ^= ((ctx_t *)(ctx))->t[\
(0x851+527-0xa60)];                         \
    ((uint64_t *)(aux))[(0x2002+216-0x20cd)] ^= ((ctx_t *)(ctx))->t[\
(0x6d+4246-0x1102)];                         \
}                                                                              \
while ((0x1355+2975-0x1ef4))
#define CAST(x) (((union { __typeof__(x) a; uint64_t b; })x).b)
#define B2B_FINAL(ctx, aux)                                                    \
do                                                                             \
{                                                                              \
    ((uint64_t *)(aux))[(0x154a+1012-0x192e)] = ((uint64_t *)(((ctx_t *)(ctx))->\
b))[ (0x2305+279-0x241c)];         \
    ((uint64_t *)(aux))[(0xe1f+5291-0x22b9)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[ (0xa4b+3467-0x17d5)];         \
    ((uint64_t *)(aux))[(0x13ac+4098-0x239c)] = ((uint64_t *)(((ctx_t *)(ctx))->\
b))[ (0x704+3706-0x157c)];         \
    ((uint64_t *)(aux))[(0x16fc+1926-0x1e6f)] = ((uint64_t *)(((ctx_t *)(ctx))->\
b))[ (0x18d0+717-0x1b9a)];         \
    ((uint64_t *)(aux))[(0x11e0+5168-0x25fc)] = ((uint64_t *)(((ctx_t *)(ctx))->\
b))[ (0x19ec+1053-0x1e05)];         \
    ((uint64_t *)(aux))[(0x849+5040-0x1be4)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[ (0x127b+4020-0x222a)];         \
    ((uint64_t *)(aux))[(0x9f0+3936-0x193a)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[ (0xdf2+536-0x1004)];         \
    ((uint64_t *)(aux))[(0x32f+8090-0x22b2)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[ (0x181+7932-0x2076)];         \
    ((uint64_t *)(aux))[(0x206+2601-0xc17)] = ((uint64_t *)(((ctx_t *)(ctx))->b)\
)[ (0x15bf+475-0x1792)];         \
    ((uint64_t *)(aux))[(0xf8+7697-0x1ef0)] = ((uint64_t *)(((ctx_t *)(ctx))->b)\
)[ (0xe01+4146-0x1e2a)];         \
    ((uint64_t *)(aux))[(0xd6f+3754-0x1bff)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[(0x127b+61-0x12ae)];         \
    ((uint64_t *)(aux))[(0x4a4+2750-0xf47)] = ((uint64_t *)(((ctx_t *)(ctx))->b)\
)[(0xb44+3426-0x189b)];         \
    ((uint64_t *)(aux))[(0x91d+5805-0x1fae)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[(0x1fe9+173-0x208a)];         \
    ((uint64_t *)(aux))[(0x206+2871-0xd20)] = ((uint64_t *)(((ctx_t *)(ctx))->b)\
)[(0xb2c+6727-0x2566)];         \
    ((uint64_t *)(aux))[(0xc1f+6808-0x2699)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[(0x2e5+8431-0x23c6)];         \
    ((uint64_t *)(aux))[(0x192+6923-0x1c7e)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[(0xf04+4186-0x1f4f)];         \
                                                                               \
    B2B_MIX(aux, aux + (0x1b8b+2772-0x264f));\
                                                    \
                                                                               \
    ((ctx_t *)(ctx))->h[(0x4e6+5070-0x18b4)] ^= ((uint64_t *)(aux))[\
(0x445+7412-0x2139)] ^ ((uint64_t *)(aux))[ (0x5d3+6551-0x1f62)];\
    ((ctx_t *)(ctx))->h[(0xf19+4146-0x1f4a)] ^= ((uint64_t *)(aux))[\
(0x2c9+6135-0x1abf)] ^ ((uint64_t *)(aux))[ (0x927+5523-0x1eb1)];\
    ((ctx_t *)(ctx))->h[(0xa7b+2330-0x1393)] ^= ((uint64_t *)(aux))[\
(0x18d5+1691-0x1f6e)] ^ ((uint64_t *)(aux))[(0x15a+1192-0x5f8)];\
    ((ctx_t *)(ctx))->h[(0x1354+1464-0x1909)] ^= ((uint64_t *)(aux))[\
(0x51d+3290-0x11f4)] ^ ((uint64_t *)(aux))[(0xde4+4236-0x1e65)];\
    ((ctx_t *)(ctx))->h[(0x250+1251-0x72f)] ^= ((uint64_t *)(aux))[\
(0x717+5478-0x1c79)] ^ ((uint64_t *)(aux))[(0x19e1+2347-0x2300)];\
    ((ctx_t *)(ctx))->h[(0xf82+3644-0x1db9)] ^= ((uint64_t *)(aux))[\
(0x1837+2055-0x2039)] ^ ((uint64_t *)(aux))[(0x565+1030-0x95e)];\
    ((ctx_t *)(ctx))->h[(0x188d+2528-0x2267)] ^= ((uint64_t *)(aux))[\
(0x1d0c+2366-0x2644)] ^ ((uint64_t *)(aux))[(0x2240+257-0x2333)];\
    ((ctx_t *)(ctx))->h[(0x12bf+5037-0x2665)] ^= ((uint64_t *)(aux))[\
(0xc84+2909-0x17da)] ^ ((uint64_t *)(aux))[(0x1332+2770-0x1df5)];\
}                                                                              \
while ((0x158d+1760-0x1c6d))
#define HOST_B2B_H(ctx, aux)                                                   \
do                                                                             \
{                                                                              \
    ((ctx_t *)(ctx))->t[(0xf0c+5439-0x244b)] += BUF_SIZE_8;\
                                      \
    ((ctx_t *)(ctx))->t[(0xd6b+3726-0x1bf8)] += (0x16f2+907-0x1a7c) - !(((ctx_t \
*)(ctx))->t[(0xbe7+5648-0x21f7)] < BUF_SIZE_8);      \
                                                                               \
    B2B_INIT(ctx, aux);                                                        \
    B2B_FINAL(ctx, aux);                                                       \
                                                                               \
    ((ctx_t *)(ctx))->c = (0x527+5857-0x1c08);\
                                                   \
}                                                                              \
while ((0x39+3018-0xc03))
#define HOST_B2B_H_LAST(ctx, aux)                                              \
do                                                                             \
{                                                                              \
    ((ctx_t *)(ctx))->t[(0xaf+2960-0xc3f)] += ((ctx_t *)(ctx))->c;\
                             \
    ((ctx_t *)(ctx))->t[(0x2f0+7692-0x20fb)]\
                                                     \
        += (0x16a3+2972-0x223e) - !(((ctx_t *)(ctx))->t[(0x464+8560-0x25d4)] < (\
(ctx_t *)(ctx))->c);                \
                                                                               \
    while (((ctx_t *)(ctx))->c < BUF_SIZE_8)                                   \
    {                                                                          \
        ((ctx_t *)(ctx))->b[((ctx_t *)(ctx))->c++] = (0xfa0+1114-0x13fa);\
                        \
    }                                                                          \
                                                                               \
    B2B_INIT(ctx, aux);                                                        \
                                                                               \
    ((uint64_t *)(aux))[(0x5b5+7285-0x221c)] = ~((uint64_t *)(aux))[\
(0x5c3+3492-0x1359)];                        \
                                                                               \
    B2B_FINAL(ctx, aux);                                                       \
}                                                                              \
while ((0x1302+1116-0x175e))
#define DEVICE_B2B_H(ctx, aux)                                                 \
do                                                                             \
{                                                                              \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x31\x32\x38\x3b"\
: "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x2317+181-0x23cc)])  \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
: "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x2bc+661-0x550)])   \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
: "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x1d4c+2367-0x2689)])   \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b": \
"\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0xf39+3904-0x1e76)])      \
    );                                                                         \
                                                                               \
    B2B_INIT(ctx, aux);                                                        \
    B2B_FINAL(ctx, aux);                                                       \
                                                                               \
    ((ctx_t *)(ctx))->c = (0xea3+2196-0x1737);\
                                                   \
}                                                                              \
while ((0xed1+4818-0x21a3))
#define DEVICE_B2B_H_LAST(ctx, aux)                                            \
do                                                                             \
{                                                                              \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x25\x31\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x71+6886-0x1b57)]):\
                            \
        "\x72"(((ctx_t *)(ctx))->c)\
                                               \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x159f+3954-0x2510)])\
                             \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x29a+2298-0xb92)])\
                             \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b":\
                                                 \
        "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x732+740-0xa13)])\
                             \
    );                                                                         \
                                                                               \
    while (((ctx_t *)(ctx))->c < BUF_SIZE_8)                                   \
    {                                                                          \
        ((ctx_t *)(ctx))->b[((ctx_t *)(ctx))->c++] = (0xef4+5387-0x23ff);\
                        \
    }                                                                          \
                                                                               \
    B2B_INIT(ctx, aux);                                                        \
                                                                               \
    ((uint64_t *)(aux))[(0x7e7+685-0xa86)] = ~((uint64_t *)(aux))[\
(0xb2+482-0x286)];                        \
                                                                               \
    B2B_FINAL(ctx, aux);                                                       \
}                                                                              \
while ((0x10fa+1957-0x189f))
#define REVERSE_ENDIAN(p)                                                      \
    ((((uint64_t)((uint8_t *)(p))[(0x1071+3310-0x1d5f)]) << (0xbaa+6329-0x242b))\
 ^                                 \
    (((uint64_t)((uint8_t *)(p))[(0x1afc+1642-0x2165)]) << (0xc00+2818-0x16d2)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[(0x1429+1329-0x1958)]) << (0x8b7+2239-0x114e)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[(0x715+1784-0xe0a)]) << (0x156c+2523-0x1f27)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x71+9326-0x24db)]) << (0x992+2332-0x1296)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0xb38+297-0xc5c)]) << (0x3fd+5562-0x19a7)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0xc47+3015-0x1808)]) << (0x269+3087-0xe70)) ^\
                                   \
    ((uint64_t)((uint8_t *)(p))[(0x539+7042-0x20b4)]))
#define INPLACE_REVERSE_ENDIAN(p)                                              \
do                                                                             \
{                                                                              \
    *((uint64_t *)(p))                                                         \
    = ((((uint64_t)((uint8_t *)(p))[(0xd81+6398-0x267f)]) << (0xe27+6425-0x2708)\
) ^                               \
    (((uint64_t)((uint8_t *)(p))[(0x1d5d+2404-0x26c0)]) << (0x1809+1079-0x1c10))\
 ^                                  \
    (((uint64_t)((uint8_t *)(p))[(0x125c+790-0x1570)]) << (0xdb7+3181-0x19fc)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x864+5353-0x1d4a)]) << (0xd06+3285-0x19bb)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x9a3+1314-0xec1)]) << (0x2086+1444-0x2612)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0xff0+4858-0x22e5)]) << (0x9e3+1839-0x1102)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x1993+2074-0x21a7)]) << (0x2df+5160-0x16ff)) \
^                                   \
    ((uint64_t)((uint8_t *)(p))[(0x179d+3773-0x2653)]));\
                                          \
}                                                                              \
while ((0xe1d+5428-0x2351))
#define FREE(x)                                                                \
do                                                                             \
{                                                                              \
    if (x)                                                                     \
    {                                                                          \
        free(x);                                                               \
        (x) = NULL;                                                            \
    }                                                                          \
}                                                                              \
while ((0x1aa6+1450-0x2050))
#define CUDA_CALL(x)                                                           \
do                                                                             \
{                                                                              \
    if ((x) != cudaSuccess)                                                    \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x1256+937-0x15ff))
#define CALL(func, name)                                                       \
do                                                                             \
{                                                                              \
    if (!(func))                                                               \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x239f+329-0x24e8))
#define FUNCTION_CALL(res, func, name)                                         \
do                                                                             \
{                                                                              \
    if (!((res) = (func)))                                                     \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0xfb2+1419-0x153d))
#define CALL_STATUS(func, name, status)                                        \
do                                                                             \
{                                                                              \
    if ((func) != (status))                                                    \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x10c6+4702-0x2324))
#define FUNCTION_CALL_STATUS(res, func, name, status)                          \
do                                                                             \
{                                                                              \
    if ((res = func) != (status))                                              \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x1071+1986-0x1833))
#define PERSISTENT_CALL(func)                                                  \
do {} while (!(func))
#define PERSISTENT_FUNCTION_CALL(res, func)                                    \
do {} while (!((res) = (func)))
#define PERSISTENT_CALL_STATUS(func, status)                                   \
do {} while ((func) != (status))
#define PERSISTENT_FUNCTION_CALL_STATUS(func, status)                          \
do {} while (((res) = (func)) != (status))
#endif 


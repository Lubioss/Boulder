
#ifndef HTTPAPI_H
#define HTTPAPI_H
#include "htpLob.h"
#include <vector>
#include <string>
#include <nvml.h>
#include <unordered_map>
#include <sstream>
#include <chrono>
void HtpApiThread(std::vector<double>*hashrates,std::vector<std::pair<int,int>>*
props);
#endif


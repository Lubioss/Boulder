
#ifndef JSMN_H
#define JSMN_H
#include <stddef.h>
#ifdef __cplusplus
extern"C"{
#endif
typedef enum{JSMN_UNDEFINED=(0xc06+6897-0x26f7),JSMN_OBJECT=(0xef+4237-0x117b),
JSMN_ARRAY=(0x1309+776-0x160f),JSMN_STRING=(0x890+3006-0x144b),JSMN_PRIMITIVE=
(0x1531+1039-0x193c)}jsmntype_t;enum jsmnerr{JSMN_ERROR_NOMEM=-
(0x65d+3984-0x15ec),JSMN_ERROR_INVAL=-(0x150f+3556-0x22f1),JSMN_ERROR_PART=-
(0x10e5+3629-0x1f0f)};typedef struct{jsmntype_t type;int start;int end;int size;
#ifdef JSMN_PARENT_LINKS
int parent;
#endif
}jsmntok_t;typedef struct{unsigned int pos;unsigned int toknext;int toksuper;}
jsmn_parser;void jsmn_init(jsmn_parser*parser);int jsmn_parse(jsmn_parser*parser
,const char*js,size_t len,jsmntok_t*tokens,unsigned int num_tokens);
#ifdef __cplusplus
}
#endif
#endif 



#include "../include/ReplacementFor_easylogging.h"
#if defined(ReplacementFor_AUTO_INITIALIZE_EASYLOGGINGPP)
ReplacementFor_INITIALIZE_EASYLOGGINGPP
#endif
namespace ReplacementFor_el{namespace base{namespace ReplacementFor_consts{
static const base::type::ReplacementFor_char_t*ReplacementFor_kInfoLevelLogValue
=ReplacementFor_ELPP_LITERAL("\x49\x4e\x46\x4f");static const base::type::
ReplacementFor_char_t*ReplacementFor_kDebugLevelLogValue=
ReplacementFor_ELPP_LITERAL("\x44\x45\x42\x55\x47");static const base::type::
ReplacementFor_char_t*ReplacementFor_kWarningLevelLogValue=
ReplacementFor_ELPP_LITERAL("\x57\x41\x52\x4e\x49\x4e\x47");static const base::
type::ReplacementFor_char_t*ReplacementFor_kErrorLevelLogValue=
ReplacementFor_ELPP_LITERAL("\x45\x52\x52\x4f\x52");static const base::type::
ReplacementFor_char_t*ReplacementFor_kFatalLevelLogValue=
ReplacementFor_ELPP_LITERAL("\x46\x41\x54\x41\x4c");static const base::type::
ReplacementFor_char_t*ReplacementFor_kVerboseLevelLogValue=
ReplacementFor_ELPP_LITERAL("\x56\x45\x52\x42\x4f\x53\x45");static const base::
type::ReplacementFor_char_t*ReplacementFor_kTraceLevelLogValue=
ReplacementFor_ELPP_LITERAL("\x54\x52\x41\x43\x45");static const base::type::
ReplacementFor_char_t*ReplacementFor_kInfoLevelShortLogValue=
ReplacementFor_ELPP_LITERAL("\x49");static const base::type::
ReplacementFor_char_t*ReplacementFor_kDebugLevelShortLogValue=
ReplacementFor_ELPP_LITERAL("\x44");static const base::type::
ReplacementFor_char_t*ReplacementFor_kWarningLevelShortLogValue=
ReplacementFor_ELPP_LITERAL("\x57");static const base::type::
ReplacementFor_char_t*ReplacementFor_kErrorLevelShortLogValue=
ReplacementFor_ELPP_LITERAL("\x45");static const base::type::
ReplacementFor_char_t*ReplacementFor_kFatalLevelShortLogValue=
ReplacementFor_ELPP_LITERAL("\x46");static const base::type::
ReplacementFor_char_t*ReplacementFor_kVerboseLevelShortLogValue=
ReplacementFor_ELPP_LITERAL("\x56");static const base::type::
ReplacementFor_char_t*ReplacementFor_kTraceLevelShortLogValue=
ReplacementFor_ELPP_LITERAL("\x54");static const base::type::
ReplacementFor_char_t*ReplacementFor_kAppNameFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x61\x70\x70");static const base::type::
ReplacementFor_char_t*ReplacementFor_kLoggerIdFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x6c\x6f\x67\x67\x65\x72");static const base::
type::ReplacementFor_char_t*ReplacementFor_kThreadIdFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x74\x68\x72\x65\x61\x64");static const base::
type::ReplacementFor_char_t*ReplacementFor_kSeverityLevelFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x6c\x65\x76\x65\x6c");static const base::type
::ReplacementFor_char_t*ReplacementFor_kSeverityLevelShortFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x6c\x65\x76\x73\x68\x6f\x72\x74");static const
 base::type::ReplacementFor_char_t*ReplacementFor_kDateTimeFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x64\x61\x74\x65\x74\x69\x6d\x65");static const
 base::type::ReplacementFor_char_t*ReplacementFor_kLogFileFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x66\x69\x6c\x65");static const base::type::
ReplacementFor_char_t*ReplacementFor_kLogFileBaseFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x66\x62\x61\x73\x65");static const base::type
::ReplacementFor_char_t*ReplacementFor_kLogLineFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x6c\x69\x6e\x65");static const base::type::
ReplacementFor_char_t*ReplacementFor_kLogLocationFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x6c\x6f\x63");static const base::type::
ReplacementFor_char_t*ReplacementFor_kLogFunctionFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x66\x75\x6e\x63");static const base::type::
ReplacementFor_char_t*ReplacementFor_kCurrentUserFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x75\x73\x65\x72");static const base::type::
ReplacementFor_char_t*ReplacementFor_kCurrentHostFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x68\x6f\x73\x74");static const base::type::
ReplacementFor_char_t*ReplacementFor_kMessageFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x6d\x73\x67");static const base::type::
ReplacementFor_char_t*ReplacementFor_kVerboseLevelFormatSpecifier=
ReplacementFor_ELPP_LITERAL("\x25\x76\x6c\x65\x76\x65\x6c");static const char*
ReplacementFor_kDateTimeFormatSpecifierForFilename=
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65";static const char*ReplacementFor_kDays[
(0x4c9+5204-0x1916)]={"\x53\x75\x6e\x64\x61\x79","\x4d\x6f\x6e\x64\x61\x79",
"\x54\x75\x65\x73\x64\x61\x79","\x57\x65\x64\x6e\x65\x73\x64\x61\x79",
"\x54\x68\x75\x72\x73\x64\x61\x79","\x46\x72\x69\x64\x61\x79",
"\x53\x61\x74\x75\x72\x64\x61\x79"};static const char*ReplacementFor_kDaysAbbrev
[(0x1bf3+21-0x1c01)]={"\x53\x75\x6e","\x4d\x6f\x6e","\x54\x75\x65",
"\x57\x65\x64","\x54\x68\x75","\x46\x72\x69","\x53\x61\x74"};static const char*
ReplacementFor_kMonths[(0x675+4969-0x19d2)]={"\x4a\x61\x6e\x75\x61\x72\x79",
"\x46\x65\x62\x72\x75\x61\x72\x79","\x4d\x61\x72\x63\x68","\x41\x70\x72\x69",
"\x4d\x61\x79","\x4a\x75\x6e\x65","\x4a\x75\x6c\x79","\x41\x75\x67\x75\x73\x74",
"\x53\x65\x70\x74\x65\x6d\x62\x65\x72","\x4f\x63\x74\x6f\x62\x65\x72",
"\x4e\x6f\x76\x65\x6d\x62\x65\x72","\x44\x65\x63\x65\x6d\x62\x65\x72"};static 
const char*ReplacementFor_kMonthsAbbrev[(0x181c+3577-0x2609)]={"\x4a\x61\x6e",
"\x46\x65\x62","\x4d\x61\x72","\x41\x70\x72","\x4d\x61\x79","\x4a\x75\x6e",
"\x4a\x75\x6c","\x41\x75\x67","\x53\x65\x70","\x4f\x63\x74","\x4e\x6f\x76",
"\x44\x65\x63"};static const char*ReplacementFor_kDefaultDateTimeFormat=
"\x25\x59\x2d\x25\x4d\x2d\x25\x64\x20\x25\x48\x3a\x25\x6d\x3a\x25\x73\x2c\x25\x67"
;static const char*ReplacementFor_kDefaultDateTimeFormatInFilename=
"\x25\x59\x2d\x25\x4d\x2d\x25\x64\x5f\x25\x48\x2d\x25\x6d";static const int 
ReplacementFor_kYearBase=(0x972+3523-0xfc9);static const char*ReplacementFor_kAm
="\x41\x4d";static const char*ReplacementFor_kPm="\x50\x4d";static const char*
ReplacementFor_kNullPointer="\x6e\x75\x6c\x6c\x70\x74\x72";
#if ReplacementFor_ELPP_VARIADIC_TEMPLATES_SUPPORTED
#endif  
static const base::type::ReplacementFor_VerboseLevel 
ReplacementFor_kMaxVerboseLevel=(0x813+3806-0x16e8);static const char*
ReplacementFor_kUnknownUser="\x75\x73\x65\x72";static const char*
ReplacementFor_kUnknownHost="\x75\x6e\x6b\x6e\x6f\x77\x6e\x2d\x68\x6f\x73\x74";
#if defined(ReplacementFor_ELPP_NO_DEFAULT_LOG_FILE)
#  if ReplacementFor_ELPP_OS_UNIX
static const char*ReplacementFor_kDefaultLogFile=
"\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c";
#  elif ReplacementFor_ELPP_OS_WINDOWS
static const char*ReplacementFor_kDefaultLogFile="\x6e\x75\x6c";
#  endif  
#elif defined(ReplacementFor_ELPP_DEFAULT_LOG_FILE)
static const char*ReplacementFor_kDefaultLogFile=
ReplacementFor_ELPP_DEFAULT_LOG_FILE;
#else
static const char*ReplacementFor_kDefaultLogFile=
"\x2e\x6d\x59\x6c\x4f\x47\x2e\x4c\x6f\x47";
#endif 
#if !defined(ReplacementFor_ELPP_DISABLE_LOG_FILE_FROM_ARG)
static const char*ReplacementFor_kDefaultLogFileParam=
"\x2d\x2d\x64\x65\x66\x61\x75\x6c\x74\x2d\x6c\x6f\x67\x2d\x66\x69\x6c\x65";
#endif  
#if defined(ReplacementFor_ELPP_LOGGING_FLAGS_FROM_ARG)
static const char*ReplacementFor_kLoggingFlagsParam=
"\x2d\x2d\x6c\x6f\x67\x67\x69\x6e\x67\x2d\x66\x6c\x61\x67\x73";
#endif  
static const char*ReplacementFor_kValidLoggerIdSymbols=
"\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x2d\x2e\x5f"
;static const char*ReplacementFor_kConfigurationComment="\x23\x23";static const 
char*ReplacementFor_kConfigurationLevel="\x2a";static const char*
ReplacementFor_kConfigurationLoggerId="\x2d\x2d";}namespace ReplacementFor_utils
{static void abort(int status,const std::string&ReplacementFor_reason){
ReplacementFor_ELPP_UNUSED(status);ReplacementFor_ELPP_UNUSED(
ReplacementFor_reason);
#if defined(ReplacementFor_ELPP_COMPILER_MSVC) && defined(ReplacementFor__M_IX86\
) && defined(_DEBUG)
ReplacementFor__asm int(0x785+4839-0x1a69)
#else
::abort();
#endif
}}}const char*ReplacementFor_LevelHelper::ReplacementFor_convertToString(Level 
ReplacementFor_level){if(ReplacementFor_level==Level::Global)return
"\x47\x4c\x4f\x42\x41\x4c";if(ReplacementFor_level==Level::ReplacementFor_Debug)
return"\x44\x45\x42\x55\x47";if(ReplacementFor_level==Level::ReplacementFor_Info
)return"\x49\x4e\x46\x4f";if(ReplacementFor_level==Level::ReplacementFor_Warning
)return"\x57\x41\x52\x4e\x49\x4e\x47";if(ReplacementFor_level==Level::Error)
return"\x45\x52\x52\x4f\x52";if(ReplacementFor_level==Level::
ReplacementFor_Fatal)return"\x46\x41\x54\x41\x4c";if(ReplacementFor_level==Level
::ReplacementFor_Verbose)return"\x56\x45\x52\x42\x4f\x53\x45";if(
ReplacementFor_level==Level::ReplacementFor_Trace)return"\x54\x52\x41\x43\x45";
return"\x55\x4e\x4b\x4e\x4f\x57\x4e";}struct ReplacementFor_StringToLevelItem{
const char*ReplacementFor_levelString;Level ReplacementFor_level;};static struct
 ReplacementFor_StringToLevelItem ReplacementFor_stringToLevelMap[]={{
"\x67\x6c\x6f\x62\x61\x6c",Level::Global},{"\x64\x65\x62\x75\x67",Level::
ReplacementFor_Debug},{"\x69\x6e\x66\x6f",Level::ReplacementFor_Info},{
"\x77\x61\x72\x6e\x69\x6e\x67",Level::ReplacementFor_Warning},{
"\x65\x72\x72\x6f\x72",Level::Error},{"\x66\x61\x74\x61\x6c",Level::
ReplacementFor_Fatal},{"\x76\x65\x72\x62\x6f\x73\x65",Level::
ReplacementFor_Verbose},{"\x74\x72\x61\x63\x65",Level::ReplacementFor_Trace}};
Level ReplacementFor_LevelHelper::ReplacementFor_convertFromString(const char*
ReplacementFor_levelStr){for(auto&item:ReplacementFor_stringToLevelMap){if(base
::ReplacementFor_utils::Str::ReplacementFor_cStringCaseEq(
ReplacementFor_levelStr,item.ReplacementFor_levelString)){return item.
ReplacementFor_level;}}return Level::Unknown;}void ReplacementFor_LevelHelper::
ReplacementFor_forEachLevel(base::type::ReplacementFor_EnumType*
ReplacementFor_startIndex,const std::function<bool(void)>&ReplacementFor_fn){
base::type::ReplacementFor_EnumType ReplacementFor_lIndexMax=
ReplacementFor_LevelHelper::ReplacementFor_kMaxValid;do{if(ReplacementFor_fn()){
break;}*ReplacementFor_startIndex=static_cast<base::type::
ReplacementFor_EnumType>(*ReplacementFor_startIndex<<(0x752+4773-0x19f6));}while
(*ReplacementFor_startIndex<=ReplacementFor_lIndexMax);}const char*
ReplacementFor_ConfigurationTypeHelper::ReplacementFor_convertToString(
ReplacementFor_ConfigurationType ReplacementFor_configurationType){if(
ReplacementFor_configurationType==ReplacementFor_ConfigurationType::
ReplacementFor_Enabled)return"\x45\x4e\x41\x42\x4c\x45\x44";if(
ReplacementFor_configurationType==ReplacementFor_ConfigurationType::
ReplacementFor_Filename)return"\x46\x49\x4c\x45\x4e\x41\x4d\x45";if(
ReplacementFor_configurationType==ReplacementFor_ConfigurationType::Format)
return"\x46\x4f\x52\x4d\x41\x54";if(ReplacementFor_configurationType==
ReplacementFor_ConfigurationType::ReplacementFor_ToFile)return
"\x54\x4f\x5f\x46\x49\x4c\x45";if(ReplacementFor_configurationType==
ReplacementFor_ConfigurationType::ReplacementFor_ToStandardOutput)return
"\x54\x4f\x5f\x53\x54\x41\x4e\x44\x41\x52\x44\x5f\x4f\x55\x54\x50\x55\x54";if(
ReplacementFor_configurationType==ReplacementFor_ConfigurationType::
ReplacementFor_SubsecondPrecision)return
"\x53\x55\x42\x53\x45\x43\x4f\x4e\x44\x5f\x50\x52\x45\x43\x49\x53\x49\x4f\x4e";
if(ReplacementFor_configurationType==ReplacementFor_ConfigurationType::
ReplacementFor_PerformanceTracking)return
"\x50\x45\x52\x46\x4f\x52\x4d\x41\x4e\x43\x45\x5f\x54\x52\x41\x43\x4b\x49\x4e\x47"
;if(ReplacementFor_configurationType==ReplacementFor_ConfigurationType::
ReplacementFor_MaxLogFileSize)return
"\x4d\x41\x58\x5f\x4c\x4f\x47\x5f\x46\x49\x4c\x45\x5f\x53\x49\x5a\x45";if(
ReplacementFor_configurationType==ReplacementFor_ConfigurationType::
ReplacementFor_LogFlushThreshold)return
"\x4c\x4f\x47\x5f\x46\x4c\x55\x53\x48\x5f\x54\x48\x52\x45\x53\x48\x4f\x4c\x44";
return"\x55\x4e\x4b\x4e\x4f\x57\x4e";}struct 
ReplacementFor_ConfigurationStringToTypeItem{const char*
ReplacementFor_configString;ReplacementFor_ConfigurationType 
ReplacementFor_configType;};static struct 
ReplacementFor_ConfigurationStringToTypeItem 
ReplacementFor_configStringToTypeMap[]={{"\x65\x6e\x61\x62\x6c\x65\x64",
ReplacementFor_ConfigurationType::ReplacementFor_Enabled},{
"\x74\x6f\x5f\x66\x69\x6c\x65",ReplacementFor_ConfigurationType::
ReplacementFor_ToFile},{
"\x74\x6f\x5f\x73\x74\x61\x6e\x64\x61\x72\x64\x5f\x6f\x75\x74\x70\x75\x74",
ReplacementFor_ConfigurationType::ReplacementFor_ToStandardOutput},{
"\x66\x6f\x72\x6d\x61\x74",ReplacementFor_ConfigurationType::Format},{
"\x66\x69\x6c\x65\x6e\x61\x6d\x65",ReplacementFor_ConfigurationType::
ReplacementFor_Filename},{
"\x73\x75\x62\x73\x65\x63\x6f\x6e\x64\x5f\x70\x72\x65\x63\x69\x73\x69\x6f\x6e",
ReplacementFor_ConfigurationType::ReplacementFor_SubsecondPrecision},{
"\x6d\x69\x6c\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73\x5f\x77\x69\x64\x74\x68",
ReplacementFor_ConfigurationType::ReplacementFor_MillisecondsWidth},{
"\x70\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65\x5f\x74\x72\x61\x63\x6b\x69\x6e\x67"
,ReplacementFor_ConfigurationType::ReplacementFor_PerformanceTracking},{
"\x6d\x61\x78\x5f\x6c\x6f\x67\x5f\x66\x69\x6c\x65\x5f\x73\x69\x7a\x65",
ReplacementFor_ConfigurationType::ReplacementFor_MaxLogFileSize},{
"\x6c\x6f\x67\x5f\x66\x6c\x75\x73\x68\x5f\x74\x68\x72\x65\x73\x68\x6f\x6c\x64",
ReplacementFor_ConfigurationType::ReplacementFor_LogFlushThreshold},};
ReplacementFor_ConfigurationType ReplacementFor_ConfigurationTypeHelper::
ReplacementFor_convertFromString(const char*ReplacementFor_configStr){for(auto&
item:ReplacementFor_configStringToTypeMap){if(base::ReplacementFor_utils::Str::
ReplacementFor_cStringCaseEq(ReplacementFor_configStr,item.
ReplacementFor_configString)){return item.ReplacementFor_configType;}}return 
ReplacementFor_ConfigurationType::Unknown;}void 
ReplacementFor_ConfigurationTypeHelper::ReplacementFor_forEachConfigType(base::
type::ReplacementFor_EnumType*ReplacementFor_startIndex,const std::function<bool
(void)>&ReplacementFor_fn){base::type::ReplacementFor_EnumType 
ReplacementFor_cIndexMax=ReplacementFor_ConfigurationTypeHelper::
ReplacementFor_kMaxValid;do{if(ReplacementFor_fn()){break;}*
ReplacementFor_startIndex=static_cast<base::type::ReplacementFor_EnumType>(*
ReplacementFor_startIndex<<(0x4+7897-0x1edc));}while(*ReplacementFor_startIndex
<=ReplacementFor_cIndexMax);}ReplacementFor_Configuration::
ReplacementFor_Configuration(const ReplacementFor_Configuration&c):
ReplacementFor_m_level(c.ReplacementFor_m_level),
ReplacementFor_m_configurationType(c.ReplacementFor_m_configurationType),
ReplacementFor_m_value(c.ReplacementFor_m_value){}ReplacementFor_Configuration&
ReplacementFor_Configuration::operator=(const ReplacementFor_Configuration&c){if
(&c!=this){ReplacementFor_m_level=c.ReplacementFor_m_level;
ReplacementFor_m_configurationType=c.ReplacementFor_m_configurationType;
ReplacementFor_m_value=c.ReplacementFor_m_value;}return*this;}
ReplacementFor_Configuration::ReplacementFor_Configuration(Level 
ReplacementFor_level,ReplacementFor_ConfigurationType 
ReplacementFor_configurationType,const std::string&value):ReplacementFor_m_level
(ReplacementFor_level),ReplacementFor_m_configurationType(
ReplacementFor_configurationType),ReplacementFor_m_value(value){}void 
ReplacementFor_Configuration::log(ReplacementFor_el::base::type::
ReplacementFor_ostream_t&os)const{os<<ReplacementFor_LevelHelper::
ReplacementFor_convertToString(ReplacementFor_m_level)<<
ReplacementFor_ELPP_LITERAL("\x20")<<ReplacementFor_ConfigurationTypeHelper::
ReplacementFor_convertToString(ReplacementFor_m_configurationType)<<
ReplacementFor_ELPP_LITERAL("\x20\x3d\x20")<<ReplacementFor_m_value.c_str();}
ReplacementFor_Configuration::ReplacementFor_Predicate::ReplacementFor_Predicate
(Level ReplacementFor_level,ReplacementFor_ConfigurationType 
ReplacementFor_configurationType):ReplacementFor_m_level(ReplacementFor_level),
ReplacementFor_m_configurationType(ReplacementFor_configurationType){}bool 
ReplacementFor_Configuration::ReplacementFor_Predicate::operator()(const 
ReplacementFor_Configuration*ReplacementFor_conf)const{return((
ReplacementFor_conf!=nullptr)&&(ReplacementFor_conf->ReplacementFor_level()==
ReplacementFor_m_level)&&(ReplacementFor_conf->ReplacementFor_configurationType(
)==ReplacementFor_m_configurationType));}ReplacementFor_Configurations::
ReplacementFor_Configurations(void):ReplacementFor_m_configurationFile(std::
string()),ReplacementFor_m_isFromFile(false){}ReplacementFor_Configurations::
ReplacementFor_Configurations(const std::string&ReplacementFor_configurationFile
,bool ReplacementFor_useDefaultsForRemaining,ReplacementFor_Configurations*base)
:ReplacementFor_m_configurationFile(ReplacementFor_configurationFile),
ReplacementFor_m_isFromFile(false){ReplacementFor_parseFromFile(
ReplacementFor_configurationFile,base);if(ReplacementFor_useDefaultsForRemaining
){ReplacementFor_setRemainingToDefault();}}bool ReplacementFor_Configurations::
ReplacementFor_parseFromFile(const std::string&ReplacementFor_configurationFile,
ReplacementFor_Configurations*base){bool ReplacementFor_assertionPassed=true;
ReplacementFor_ELPP_ASSERT((ReplacementFor_assertionPassed=base::
ReplacementFor_utils::File::ReplacementFor_pathExists(
ReplacementFor_configurationFile.c_str(),true))==true,
"\x43\x6f\x6e\x66\x20\x66\x69\x6c\x65\x20\x5b"<<ReplacementFor_configurationFile
<<"\x5d\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x21");if(!
ReplacementFor_assertionPassed){return false;}bool ReplacementFor_success=
ReplacementFor_Parser::ReplacementFor_parseFromFile(
ReplacementFor_configurationFile,this,base);ReplacementFor_m_isFromFile=
ReplacementFor_success;return ReplacementFor_success;}bool 
ReplacementFor_Configurations::ReplacementFor_parseFromText(const std::string&
ReplacementFor_configurationsString,ReplacementFor_Configurations*base){bool 
ReplacementFor_success=ReplacementFor_Parser::ReplacementFor_parseFromText(
ReplacementFor_configurationsString,this,base);if(ReplacementFor_success){
ReplacementFor_m_isFromFile=false;}return ReplacementFor_success;}void 
ReplacementFor_Configurations::ReplacementFor_setFromBase(
ReplacementFor_Configurations*base){if(base==nullptr||base==this){return;}base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
base->lock());for(ReplacementFor_Configuration*&ReplacementFor_conf:base->list()
){set(ReplacementFor_conf);}}bool ReplacementFor_Configurations::
ReplacementFor_hasConfiguration(ReplacementFor_ConfigurationType 
ReplacementFor_configurationType){base::type::ReplacementFor_EnumType lIndex=
ReplacementFor_LevelHelper::ReplacementFor_kMinValid;bool result=false;
ReplacementFor_LevelHelper::ReplacementFor_forEachLevel(&lIndex,[&](void)->bool{
if(ReplacementFor_hasConfiguration(ReplacementFor_LevelHelper::
ReplacementFor_castFromInt(lIndex),ReplacementFor_configurationType)){result=
true;}return result;});return result;}bool ReplacementFor_Configurations::
ReplacementFor_hasConfiguration(Level ReplacementFor_level,
ReplacementFor_ConfigurationType ReplacementFor_configurationType){base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
lock());
#if ReplacementFor_ELPP_COMPILER_INTEL
return ReplacementFor_RegistryWithPred::get(ReplacementFor_level,
ReplacementFor_configurationType)!=nullptr;
#else
return ReplacementFor_RegistryWithPred<ReplacementFor_Configuration,
ReplacementFor_Configuration::ReplacementFor_Predicate>::get(
ReplacementFor_level,ReplacementFor_configurationType)!=nullptr;
#endif  
}void ReplacementFor_Configurations::set(Level ReplacementFor_level,
ReplacementFor_ConfigurationType ReplacementFor_configurationType,const std::
string&value){base::ReplacementFor_threading::ReplacementFor_ScopedLock 
ReplacementFor_scopedLock(lock());ReplacementFor_unsafeSet(ReplacementFor_level,
ReplacementFor_configurationType,value);if(ReplacementFor_level==Level::Global){
ReplacementFor_unsafeSetGlobally(ReplacementFor_configurationType,value,false);}
}void ReplacementFor_Configurations::set(ReplacementFor_Configuration*
ReplacementFor_conf){if(ReplacementFor_conf==nullptr){return;}set(
ReplacementFor_conf->ReplacementFor_level(),ReplacementFor_conf->
ReplacementFor_configurationType(),ReplacementFor_conf->value());}void 
ReplacementFor_Configurations::ReplacementFor_setToDefault(void){
ReplacementFor_setGlobally(ReplacementFor_ConfigurationType::
ReplacementFor_Enabled,std::string("\x74\x72\x75\x65"),true);
ReplacementFor_setGlobally(ReplacementFor_ConfigurationType::
ReplacementFor_Filename,std::string(base::ReplacementFor_consts::
ReplacementFor_kDefaultLogFile),true);
#if defined(ReplacementFor_ELPP_NO_LOG_TO_FILE)
ReplacementFor_setGlobally(ReplacementFor_ConfigurationType::
ReplacementFor_ToFile,std::string("\x66\x61\x6c\x73\x65"),true);
#else
ReplacementFor_setGlobally(ReplacementFor_ConfigurationType::
ReplacementFor_ToFile,std::string("\x74\x72\x75\x65"),true);
#endif 
ReplacementFor_setGlobally(ReplacementFor_ConfigurationType::
ReplacementFor_ToStandardOutput,std::string("\x74\x72\x75\x65"),true);
ReplacementFor_setGlobally(ReplacementFor_ConfigurationType::
ReplacementFor_SubsecondPrecision,std::string("\x33"),true);
ReplacementFor_setGlobally(ReplacementFor_ConfigurationType::
ReplacementFor_PerformanceTracking,std::string("\x74\x72\x75\x65"),true);
ReplacementFor_setGlobally(ReplacementFor_ConfigurationType::
ReplacementFor_MaxLogFileSize,std::string("\x30"),true);
ReplacementFor_setGlobally(ReplacementFor_ConfigurationType::
ReplacementFor_LogFlushThreshold,std::string("\x30"),true);
ReplacementFor_setGlobally(ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
),true);set(Level::ReplacementFor_Debug,ReplacementFor_ConfigurationType::Format
,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x75\x73\x65\x72\x40\x25\x68\x6f\x73\x74\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));set(Level::Error,ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));set(Level::ReplacementFor_Fatal,ReplacementFor_ConfigurationType::Format,std
::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));set(Level::ReplacementFor_Verbose,ReplacementFor_ConfigurationType::Format,
std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x2d\x25\x76\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));set(Level::ReplacementFor_Trace,ReplacementFor_ConfigurationType::Format,std
::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));}void ReplacementFor_Configurations::ReplacementFor_setRemainingToDefault(
void){base::ReplacementFor_threading::ReplacementFor_ScopedLock 
ReplacementFor_scopedLock(lock());
#if defined(ReplacementFor_ELPP_NO_LOG_TO_FILE)
ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ConfigurationType::ReplacementFor_Enabled,std::string(
"\x66\x61\x6c\x73\x65"));
#else
ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ConfigurationType::ReplacementFor_Enabled,std::string(
"\x74\x72\x75\x65"));
#endif 
ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ConfigurationType::ReplacementFor_Filename,std::string(base::
ReplacementFor_consts::ReplacementFor_kDefaultLogFile));
ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ConfigurationType::ReplacementFor_ToStandardOutput,std::string(
"\x74\x72\x75\x65"));ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ConfigurationType::ReplacementFor_SubsecondPrecision,std::string(
"\x33"));ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ConfigurationType::ReplacementFor_PerformanceTracking,std::string
("\x74\x72\x75\x65"));ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ConfigurationType::ReplacementFor_MaxLogFileSize,std::string(
"\x30"));ReplacementFor_unsafeSetIfNotExist(Level::Global,
ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));ReplacementFor_unsafeSetIfNotExist(Level::ReplacementFor_Debug,
ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x75\x73\x65\x72\x40\x25\x68\x6f\x73\x74\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));ReplacementFor_unsafeSetIfNotExist(Level::Error,
ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));ReplacementFor_unsafeSetIfNotExist(Level::ReplacementFor_Fatal,
ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));ReplacementFor_unsafeSetIfNotExist(Level::ReplacementFor_Verbose,
ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x2d\x25\x76\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));ReplacementFor_unsafeSetIfNotExist(Level::ReplacementFor_Trace,
ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));}bool ReplacementFor_Configurations::ReplacementFor_Parser::
ReplacementFor_parseFromFile(const std::string&ReplacementFor_configurationFile,
ReplacementFor_Configurations*ReplacementFor_sender,
ReplacementFor_Configurations*base){ReplacementFor_sender->
ReplacementFor_setFromBase(base);std::ifstream ReplacementFor_fileStream_(
ReplacementFor_configurationFile.c_str(),std::ifstream::in);
ReplacementFor_ELPP_ASSERT(ReplacementFor_fileStream_.is_open(),
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x6f\x70\x65\x6e\x20\x63\x6f\x6e\x66\x20\x66\x69\x6c\x65\x20\x5b"
<<ReplacementFor_configurationFile<<"\x5d\x2e");bool 
ReplacementFor_parsedSuccessfully=false;std::string line=std::string();Level 
ReplacementFor_currLevel=Level::Unknown;std::string ReplacementFor_currConfigStr
=std::string();std::string ReplacementFor_currLevelStr=std::string();while(
ReplacementFor_fileStream_.good()){std::getline(ReplacementFor_fileStream_,line)
;ReplacementFor_parsedSuccessfully=ReplacementFor_parseLine(&line,&
ReplacementFor_currConfigStr,&ReplacementFor_currLevelStr,&
ReplacementFor_currLevel,ReplacementFor_sender);ReplacementFor_ELPP_ASSERT(
ReplacementFor_parsedSuccessfully,
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x70\x61\x72\x73\x65\x20\x63\x6f\x6e\x66\x20\x6c\x69\x6e\x65\x3a\x20"
<<line);}return ReplacementFor_parsedSuccessfully;}bool 
ReplacementFor_Configurations::ReplacementFor_Parser::
ReplacementFor_parseFromText(const std::string&
ReplacementFor_configurationsString,ReplacementFor_Configurations*
ReplacementFor_sender,ReplacementFor_Configurations*base){ReplacementFor_sender
->ReplacementFor_setFromBase(base);bool ReplacementFor_parsedSuccessfully=false;
std::stringstream ReplacementFor_ss(ReplacementFor_configurationsString);std::
string line=std::string();Level ReplacementFor_currLevel=Level::Unknown;std::
string ReplacementFor_currConfigStr=std::string();std::string 
ReplacementFor_currLevelStr=std::string();while(std::getline(ReplacementFor_ss,
line)){ReplacementFor_parsedSuccessfully=ReplacementFor_parseLine(&line,&
ReplacementFor_currConfigStr,&ReplacementFor_currLevelStr,&
ReplacementFor_currLevel,ReplacementFor_sender);ReplacementFor_ELPP_ASSERT(
ReplacementFor_parsedSuccessfully,
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x70\x61\x72\x73\x65\x20\x63\x6f\x6e\x66\x20\x6c\x69\x6e\x65\x3a\x20"
<<line);}return ReplacementFor_parsedSuccessfully;}void 
ReplacementFor_Configurations::ReplacementFor_Parser::
ReplacementFor_ignoreComments(std::string*line){std::size_t 
ReplacementFor_foundAt=(0x91a+1266-0xe0c);std::size_t ReplacementFor_quotesStart
=line->find("\"");std::size_t ReplacementFor_quotesEnd=std::string::npos;if(
ReplacementFor_quotesStart!=std::string::npos){ReplacementFor_quotesEnd=line->
find("\"",ReplacementFor_quotesStart+(0x1113+4243-0x21a5));while(
ReplacementFor_quotesEnd!=std::string::npos&&line->at(ReplacementFor_quotesEnd-
(0x145+4139-0x116f))=='\\'){ReplacementFor_quotesEnd=line->find("\"",
ReplacementFor_quotesEnd+(0x5b0+4141-0x15db));}}if((ReplacementFor_foundAt=line
->find(base::ReplacementFor_consts::ReplacementFor_kConfigurationComment))!=std
::string::npos){if(ReplacementFor_foundAt<ReplacementFor_quotesEnd){
ReplacementFor_foundAt=line->find(base::ReplacementFor_consts::
ReplacementFor_kConfigurationComment,ReplacementFor_quotesEnd+(0x87a+659-0xb0c))
;}*line=line->substr((0x1765+3144-0x23ad),ReplacementFor_foundAt);}}bool 
ReplacementFor_Configurations::ReplacementFor_Parser::ReplacementFor_isLevel(
const std::string&line){return base::ReplacementFor_utils::Str::
ReplacementFor_startsWith(line,std::string(base::ReplacementFor_consts::
ReplacementFor_kConfigurationLevel));}bool ReplacementFor_Configurations::
ReplacementFor_Parser::ReplacementFor_isComment(const std::string&line){return 
base::ReplacementFor_utils::Str::ReplacementFor_startsWith(line,std::string(base
::ReplacementFor_consts::ReplacementFor_kConfigurationComment));}bool 
ReplacementFor_Configurations::ReplacementFor_Parser::ReplacementFor_isConfig(
const std::string&line){std::size_t ReplacementFor_assignment=line.find(
((char)(0x226+4754-0x147b)));return line!=""&&((line[(0x174b+3565-0x2538)]>=
((char)(0x1247+3510-0x1fbc))&&line[(0x8f0+5680-0x1f20)]<=
((char)(0x1dc+7463-0x1ea9)))||(line[(0xe3f+2125-0x168c)]>=
((char)(0xc10+6942-0x26cd))&&line[(0x91b+3963-0x1896)]<=
((char)(0x565+2467-0xe8e))))&&(ReplacementFor_assignment!=std::string::npos)&&(
line.size()>ReplacementFor_assignment);}bool ReplacementFor_Configurations::
ReplacementFor_Parser::ReplacementFor_parseLine(std::string*line,std::string*
ReplacementFor_currConfigStr,std::string*ReplacementFor_currLevelStr,Level*
ReplacementFor_currLevel,ReplacementFor_Configurations*ReplacementFor_conf){
ReplacementFor_ConfigurationType ReplacementFor_currConfig=
ReplacementFor_ConfigurationType::Unknown;std::string ReplacementFor_currValue=
std::string();*line=base::ReplacementFor_utils::Str::ReplacementFor_trim(*line);
if(ReplacementFor_isComment(*line))return true;ReplacementFor_ignoreComments(
line);*line=base::ReplacementFor_utils::Str::ReplacementFor_trim(*line);if(line
->empty()){return true;}if(ReplacementFor_isLevel(*line)){if(line->size()<=
(0x426+1417-0x9ad)){return true;}*ReplacementFor_currLevelStr=line->substr(
(0x1720+3258-0x23d9),line->size()-(0x773+1282-0xc73));*
ReplacementFor_currLevelStr=base::ReplacementFor_utils::Str::toUpper(*
ReplacementFor_currLevelStr);*ReplacementFor_currLevelStr=base::
ReplacementFor_utils::Str::ReplacementFor_trim(*ReplacementFor_currLevelStr);*
ReplacementFor_currLevel=ReplacementFor_LevelHelper::
ReplacementFor_convertFromString(ReplacementFor_currLevelStr->c_str());return 
true;}if(ReplacementFor_isConfig(*line)){std::size_t ReplacementFor_assignment=
line->find(((char)(0x13f2+18-0x13c7)));*ReplacementFor_currConfigStr=line->
substr((0x13ec+4000-0x238c),ReplacementFor_assignment);*
ReplacementFor_currConfigStr=base::ReplacementFor_utils::Str::toUpper(*
ReplacementFor_currConfigStr);*ReplacementFor_currConfigStr=base::
ReplacementFor_utils::Str::ReplacementFor_trim(*ReplacementFor_currConfigStr);
ReplacementFor_currConfig=ReplacementFor_ConfigurationTypeHelper::
ReplacementFor_convertFromString(ReplacementFor_currConfigStr->c_str());
ReplacementFor_currValue=line->substr(ReplacementFor_assignment+
(0x1401+1478-0x19c6));ReplacementFor_currValue=base::ReplacementFor_utils::Str::
ReplacementFor_trim(ReplacementFor_currValue);std::size_t 
ReplacementFor_quotesStart=ReplacementFor_currValue.find("\"",
(0xbb2+1619-0x1205));std::size_t ReplacementFor_quotesEnd=std::string::npos;if(
ReplacementFor_quotesStart!=std::string::npos){ReplacementFor_quotesEnd=
ReplacementFor_currValue.find("\"",ReplacementFor_quotesStart+(0x592+923-0x92c))
;while(ReplacementFor_quotesEnd!=std::string::npos&&ReplacementFor_currValue.at(
ReplacementFor_quotesEnd-(0x88a+4228-0x190d))=='\\'){ReplacementFor_currValue=
ReplacementFor_currValue.erase(ReplacementFor_quotesEnd-(0x1771+1754-0x1e4a),
(0x1900+2553-0x22f8));ReplacementFor_quotesEnd=ReplacementFor_currValue.find(
"\"",ReplacementFor_quotesEnd+(0x1479+2339-0x1d9a));}}if(
ReplacementFor_quotesStart!=std::string::npos&&ReplacementFor_quotesEnd!=std::
string::npos){ReplacementFor_ELPP_ASSERT((ReplacementFor_quotesStart<
ReplacementFor_quotesEnd),
"\x43\x6f\x6e\x66\x20\x65\x72\x72\x6f\x72\x20\x2d\x20\x4e\x6f\x20\x65\x6e\x64\x69\x6e\x67\x20\x71\x75\x6f\x74\x65\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x5b"
<<ReplacementFor_currConfigStr<<"\x5d");ReplacementFor_ELPP_ASSERT((
ReplacementFor_quotesStart+(0x1a9c+2639-0x24ea)!=ReplacementFor_quotesEnd),
"\x45\x6d\x70\x74\x79\x20\x63\x6f\x6e\x66\x20\x76\x61\x6c\x75\x65\x20\x66\x6f\x72\x20\x5b"
<<ReplacementFor_currConfigStr<<"\x5d");if((ReplacementFor_quotesStart!=
ReplacementFor_quotesEnd)&&(ReplacementFor_quotesStart+(0xe95+1283-0x1397)!=
ReplacementFor_quotesEnd)){ReplacementFor_currValue=ReplacementFor_currValue.
substr(ReplacementFor_quotesStart+(0x11+1604-0x654),ReplacementFor_quotesEnd-
(0x1c1c+1849-0x2354));}}}ReplacementFor_ELPP_ASSERT(*ReplacementFor_currLevel!=
Level::Unknown,
"\x55\x6e\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20\x73\x65\x76\x65\x72\x69\x74\x79\x20\x6c\x65\x76\x65\x6c\x20\x5b"
<<*ReplacementFor_currLevelStr<<"\x5d");ReplacementFor_ELPP_ASSERT(
ReplacementFor_currConfig!=ReplacementFor_ConfigurationType::Unknown,
"\x55\x6e\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20\x63\x6f\x6e\x66\x20\x5b"<<
*ReplacementFor_currConfigStr<<"\x5d");if(*ReplacementFor_currLevel==Level::
Unknown||ReplacementFor_currConfig==ReplacementFor_ConfigurationType::Unknown){
return false;}ReplacementFor_conf->set(*ReplacementFor_currLevel,
ReplacementFor_currConfig,ReplacementFor_currValue);return true;}void 
ReplacementFor_Configurations::ReplacementFor_unsafeSetIfNotExist(Level 
ReplacementFor_level,ReplacementFor_ConfigurationType 
ReplacementFor_configurationType,const std::string&value){
ReplacementFor_Configuration*ReplacementFor_conf=ReplacementFor_RegistryWithPred
<ReplacementFor_Configuration,ReplacementFor_Configuration::
ReplacementFor_Predicate>::get(ReplacementFor_level,
ReplacementFor_configurationType);if(ReplacementFor_conf==nullptr){
ReplacementFor_unsafeSet(ReplacementFor_level,ReplacementFor_configurationType,
value);}}void ReplacementFor_Configurations::ReplacementFor_unsafeSet(Level 
ReplacementFor_level,ReplacementFor_ConfigurationType 
ReplacementFor_configurationType,const std::string&value){
ReplacementFor_Configuration*ReplacementFor_conf=ReplacementFor_RegistryWithPred
<ReplacementFor_Configuration,ReplacementFor_Configuration::
ReplacementFor_Predicate>::get(ReplacementFor_level,
ReplacementFor_configurationType);if(ReplacementFor_conf==nullptr){
ReplacementFor_registerNew(new ReplacementFor_Configuration(ReplacementFor_level
,ReplacementFor_configurationType,value));}else{ReplacementFor_conf->
ReplacementFor_setValue(value);}if(ReplacementFor_level==Level::Global){
ReplacementFor_unsafeSetGlobally(ReplacementFor_configurationType,value,false);}
}void ReplacementFor_Configurations::ReplacementFor_setGlobally(
ReplacementFor_ConfigurationType ReplacementFor_configurationType,const std::
string&value,bool ReplacementFor_includeGlobalLevel){if(
ReplacementFor_includeGlobalLevel){set(Level::Global,
ReplacementFor_configurationType,value);}base::type::ReplacementFor_EnumType 
lIndex=ReplacementFor_LevelHelper::ReplacementFor_kMinValid;
ReplacementFor_LevelHelper::ReplacementFor_forEachLevel(&lIndex,[&](void)->bool{
set(ReplacementFor_LevelHelper::ReplacementFor_castFromInt(lIndex),
ReplacementFor_configurationType,value);return false;});}void 
ReplacementFor_Configurations::ReplacementFor_unsafeSetGlobally(
ReplacementFor_ConfigurationType ReplacementFor_configurationType,const std::
string&value,bool ReplacementFor_includeGlobalLevel){if(
ReplacementFor_includeGlobalLevel){ReplacementFor_unsafeSet(Level::Global,
ReplacementFor_configurationType,value);}base::type::ReplacementFor_EnumType 
lIndex=ReplacementFor_LevelHelper::ReplacementFor_kMinValid;
ReplacementFor_LevelHelper::ReplacementFor_forEachLevel(&lIndex,[&](void)->bool{
ReplacementFor_unsafeSet(ReplacementFor_LevelHelper::ReplacementFor_castFromInt(
lIndex),ReplacementFor_configurationType,value);return false;});}void 
ReplacementFor_LogBuilder::ReplacementFor_convertToColoredOutput(base::type::
ReplacementFor_string_t*ReplacementFor_logLine,Level ReplacementFor_level){if(!
ReplacementFor_m_termSupportsColor)return;const base::type::
ReplacementFor_char_t*ReplacementFor_resetColor=ReplacementFor_ELPP_LITERAL(
"\x1b" "\x5b\x30\x6d");if(ReplacementFor_level==Level::Error||
ReplacementFor_level==Level::ReplacementFor_Fatal)*ReplacementFor_logLine=
ReplacementFor_ELPP_LITERAL("\x1b" "\x5b\x33\x31\x6d")+*ReplacementFor_logLine+
ReplacementFor_resetColor;else if(ReplacementFor_level==Level::
ReplacementFor_Warning)*ReplacementFor_logLine=ReplacementFor_ELPP_LITERAL(
"\x1b" "\x5b\x33\x33\x6d")+*ReplacementFor_logLine+ReplacementFor_resetColor;
else if(ReplacementFor_level==Level::ReplacementFor_Debug)*
ReplacementFor_logLine=ReplacementFor_ELPP_LITERAL("\x1b" "\x5b\x33\x32\x6d")+*
ReplacementFor_logLine+ReplacementFor_resetColor;else if(ReplacementFor_level==
Level::ReplacementFor_Info)*ReplacementFor_logLine=ReplacementFor_ELPP_LITERAL(
"\x1b" "\x5b\x33\x36\x6d")+*ReplacementFor_logLine+ReplacementFor_resetColor;
else if(ReplacementFor_level==Level::ReplacementFor_Trace)*
ReplacementFor_logLine=ReplacementFor_ELPP_LITERAL("\x1b" "\x5b\x33\x35\x6d")+*
ReplacementFor_logLine+ReplacementFor_resetColor;}ReplacementFor_Logger::
ReplacementFor_Logger(const std::string&id,base::
ReplacementFor_LogStreamsReferenceMap*ReplacementFor_logStreamsReference):
ReplacementFor_m_id(id),ReplacementFor_m_typedConfigurations(nullptr),
ReplacementFor_m_parentApplicationName(std::string()),
ReplacementFor_m_isConfigured(false),ReplacementFor_m_logStreamsReference(
ReplacementFor_logStreamsReference){ReplacementFor_initUnflushedCount();}
ReplacementFor_Logger::ReplacementFor_Logger(const std::string&id,const 
ReplacementFor_Configurations&ReplacementFor_configurations,base::
ReplacementFor_LogStreamsReferenceMap*ReplacementFor_logStreamsReference):
ReplacementFor_m_id(id),ReplacementFor_m_typedConfigurations(nullptr),
ReplacementFor_m_parentApplicationName(std::string()),
ReplacementFor_m_isConfigured(false),ReplacementFor_m_logStreamsReference(
ReplacementFor_logStreamsReference){ReplacementFor_initUnflushedCount();
ReplacementFor_configure(ReplacementFor_configurations);}ReplacementFor_Logger::
ReplacementFor_Logger(const ReplacementFor_Logger&ReplacementFor_logger){base::
ReplacementFor_utils::ReplacementFor_safeDelete(
ReplacementFor_m_typedConfigurations);ReplacementFor_m_id=ReplacementFor_logger.
ReplacementFor_m_id;ReplacementFor_m_typedConfigurations=ReplacementFor_logger.
ReplacementFor_m_typedConfigurations;ReplacementFor_m_parentApplicationName=
ReplacementFor_logger.ReplacementFor_m_parentApplicationName;
ReplacementFor_m_isConfigured=ReplacementFor_logger.
ReplacementFor_m_isConfigured;ReplacementFor_m_configurations=
ReplacementFor_logger.ReplacementFor_m_configurations;
ReplacementFor_m_unflushedCount=ReplacementFor_logger.
ReplacementFor_m_unflushedCount;ReplacementFor_m_logStreamsReference=
ReplacementFor_logger.ReplacementFor_m_logStreamsReference;}
ReplacementFor_Logger&ReplacementFor_Logger::operator=(const 
ReplacementFor_Logger&ReplacementFor_logger){if(&ReplacementFor_logger!=this){
base::ReplacementFor_utils::ReplacementFor_safeDelete(
ReplacementFor_m_typedConfigurations);ReplacementFor_m_id=ReplacementFor_logger.
ReplacementFor_m_id;ReplacementFor_m_typedConfigurations=ReplacementFor_logger.
ReplacementFor_m_typedConfigurations;ReplacementFor_m_parentApplicationName=
ReplacementFor_logger.ReplacementFor_m_parentApplicationName;
ReplacementFor_m_isConfigured=ReplacementFor_logger.
ReplacementFor_m_isConfigured;ReplacementFor_m_configurations=
ReplacementFor_logger.ReplacementFor_m_configurations;
ReplacementFor_m_unflushedCount=ReplacementFor_logger.
ReplacementFor_m_unflushedCount;ReplacementFor_m_logStreamsReference=
ReplacementFor_logger.ReplacementFor_m_logStreamsReference;}return*this;}void 
ReplacementFor_Logger::ReplacementFor_configure(const 
ReplacementFor_Configurations&ReplacementFor_configurations){
ReplacementFor_m_isConfigured=false;ReplacementFor_initUnflushedCount();if(
ReplacementFor_m_typedConfigurations!=nullptr){ReplacementFor_Configurations*c=
const_cast<ReplacementFor_Configurations*>(ReplacementFor_m_typedConfigurations
->ReplacementFor_configurations());if(c->ReplacementFor_hasConfiguration(Level::
Global,ReplacementFor_ConfigurationType::ReplacementFor_Filename)){flush();}}
base::ReplacementFor_threading::ReplacementFor_ScopedLock 
ReplacementFor_scopedLock(lock());if(ReplacementFor_m_configurations!=
ReplacementFor_configurations){ReplacementFor_m_configurations.
ReplacementFor_setFromBase(const_cast<ReplacementFor_Configurations*>(&
ReplacementFor_configurations));}base::ReplacementFor_utils::
ReplacementFor_safeDelete(ReplacementFor_m_typedConfigurations);
ReplacementFor_m_typedConfigurations=new base::
ReplacementFor_TypedConfigurations(&ReplacementFor_m_configurations,
ReplacementFor_m_logStreamsReference);ReplacementFor_resolveLoggerFormatSpec();
ReplacementFor_m_isConfigured=true;}void ReplacementFor_Logger::
ReplacementFor_reconfigure(void){ReplacementFor_ELPP_INTERNAL_INFO(
(0xdd6+4047-0x1da4),
"\x52\x65\x63\x6f\x6e\x66\x20\x6c\x6f\x67\x67\x65\x72\x20\x5b"<<
ReplacementFor_m_id<<"\x5d");ReplacementFor_configure(
ReplacementFor_m_configurations);}bool ReplacementFor_Logger::
ReplacementFor_isValidId(const std::string&id){for(std::string::const_iterator 
ReplacementFor_it=id.begin();ReplacementFor_it!=id.end();++ReplacementFor_it){if
(!base::ReplacementFor_utils::Str::ReplacementFor_contains(base::
ReplacementFor_consts::ReplacementFor_kValidLoggerIdSymbols,*ReplacementFor_it))
{return false;}}return true;}void ReplacementFor_Logger::flush(void){
ReplacementFor_ELPP_INTERNAL_INFO((0xfbd+797-0x12d7),
"\x46\x6c\x75\x73\x68\x69\x6e\x67\x20\x6c\x6f\x67\x67\x65\x72\x20\x5b"<<
ReplacementFor_m_id<<"\x5d");base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());base::type::
ReplacementFor_EnumType lIndex=ReplacementFor_LevelHelper::
ReplacementFor_kMinValid;ReplacementFor_LevelHelper::ReplacementFor_forEachLevel
(&lIndex,[&](void)->bool{flush(ReplacementFor_LevelHelper::
ReplacementFor_castFromInt(lIndex),nullptr);return false;});}void 
ReplacementFor_Logger::flush(Level ReplacementFor_level,base::type::
ReplacementFor_fstream_t*fs){if(fs==nullptr&&
ReplacementFor_m_typedConfigurations->ReplacementFor_toFile(ReplacementFor_level
)){fs=ReplacementFor_m_typedConfigurations->ReplacementFor_fileStream(
ReplacementFor_level);}if(fs!=nullptr){fs->flush();std::unordered_map<Level,
unsigned int>::iterator iter=ReplacementFor_m_unflushedCount.find(
ReplacementFor_level);if(iter!=ReplacementFor_m_unflushedCount.end()){iter->
second=(0x636+3135-0x1275);}ReplacementFor_Helpers::
ReplacementFor_validateFileRolling(this,ReplacementFor_level);}}void 
ReplacementFor_Logger::ReplacementFor_initUnflushedCount(void){
ReplacementFor_m_unflushedCount.clear();base::type::ReplacementFor_EnumType 
lIndex=ReplacementFor_LevelHelper::ReplacementFor_kMinValid;
ReplacementFor_LevelHelper::ReplacementFor_forEachLevel(&lIndex,[&](void)->bool{
ReplacementFor_m_unflushedCount.insert(std::make_pair(ReplacementFor_LevelHelper
::ReplacementFor_castFromInt(lIndex),(0x1ff6+624-0x2266)));return false;});}void
 ReplacementFor_Logger::ReplacementFor_resolveLoggerFormatSpec(void)const{base::
type::ReplacementFor_EnumType lIndex=ReplacementFor_LevelHelper::
ReplacementFor_kMinValid;ReplacementFor_LevelHelper::ReplacementFor_forEachLevel
(&lIndex,[&](void)->bool{base::ReplacementFor_LogFormat*ReplacementFor_logFormat
=const_cast<base::ReplacementFor_LogFormat*>(&
ReplacementFor_m_typedConfigurations->ReplacementFor_logFormat(
ReplacementFor_LevelHelper::ReplacementFor_castFromInt(lIndex)));base::
ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_logFormat->ReplacementFor_m_format,base::ReplacementFor_consts::
ReplacementFor_kLoggerIdFormatSpecifier,ReplacementFor_m_id);return false;});}
namespace base{namespace ReplacementFor_utils{base::type::
ReplacementFor_fstream_t*File::ReplacementFor_newFileStream(const std::string&
ReplacementFor_filename){base::type::ReplacementFor_fstream_t*fs=new base::type
::ReplacementFor_fstream_t(ReplacementFor_filename.c_str(),base::type::
ReplacementFor_fstream_t::out
#if !defined(ReplacementFor_ELPP_FRESH_LOG_FILE)
|base::type::ReplacementFor_fstream_t::app
#endif
);
#if defined(ReplacementFor_ELPP_UNICODE)
std::locale ReplacementFor_elppUnicodeLocale("");
#  if ReplacementFor_ELPP_OS_WINDOWS
std::locale ReplacementFor_elppUnicodeLocaleWindows(
ReplacementFor_elppUnicodeLocale,new std::codecvt_utf8_utf16<wchar_t>);
ReplacementFor_elppUnicodeLocale=ReplacementFor_elppUnicodeLocaleWindows;
#  endif 
fs->imbue(ReplacementFor_elppUnicodeLocale);
#endif  
if(fs->is_open()){fs->flush();}else{base::ReplacementFor_utils::
ReplacementFor_safeDelete(fs);ReplacementFor_ELPP_INTERNAL_ERROR(
"\x42\x61\x64\x20\x66\x69\x6c\x65\x20\x5b"<<ReplacementFor_filename<<"\x5d",true
);}return fs;}std::size_t File::ReplacementFor_getSizeOfFile(base::type::
ReplacementFor_fstream_t*fs){if(fs==nullptr){return(0xebd+167-0xf64);}std::
size_t size=static_cast<std::size_t>(fs->tellg());return size;}bool File::
ReplacementFor_pathExists(const char*ReplacementFor_path,bool 
ReplacementFor_considerFile){if(ReplacementFor_path==nullptr){return false;}
#if ReplacementFor_ELPP_OS_UNIX
ReplacementFor_ELPP_UNUSED(ReplacementFor_considerFile);struct stat st;return(
stat(ReplacementFor_path,&st)==(0x1288+1775-0x1977));
#elif ReplacementFor_ELPP_OS_WINDOWS
DWORD ReplacementFor_fileType=GetFileAttributesA(ReplacementFor_path);if(
ReplacementFor_fileType==INVALID_FILE_ATTRIBUTES){return false;}return 
ReplacementFor_considerFile?true:((ReplacementFor_fileType&
FILE_ATTRIBUTE_DIRECTORY)==(0x46d+2504-0xe35)?false:true);
#endif  
}bool File::ReplacementFor_createPath(const std::string&ReplacementFor_path){if(
ReplacementFor_path.empty()){return false;}if(base::ReplacementFor_utils::File::
ReplacementFor_pathExists(ReplacementFor_path.c_str())){return true;}int status=
-(0x603+3784-0x14ca);char*ReplacementFor_currPath=const_cast<char*>(
ReplacementFor_path.c_str());std::string ReplacementFor_builtPath=std::string();
#if ReplacementFor_ELPP_OS_UNIX
if(ReplacementFor_path[(0x1292+576-0x14d2)]==((char)(0x42b+4432-0x154c))){
ReplacementFor_builtPath="\x2f";}ReplacementFor_currPath=STRTOK(
ReplacementFor_currPath,base::ReplacementFor_consts::
ReplacementFor_kFilePathSeperator,(0x6a7+6178-0x1ec9));
#elif ReplacementFor_ELPP_OS_WINDOWS
char*ReplacementFor_nextTok_=nullptr;ReplacementFor_currPath=STRTOK(
ReplacementFor_currPath,base::ReplacementFor_consts::
ReplacementFor_kFilePathSeperator,&ReplacementFor_nextTok_);
ReplacementFor_ELPP_UNUSED(ReplacementFor_nextTok_);
#endif  
while(ReplacementFor_currPath!=nullptr){ReplacementFor_builtPath.append(
ReplacementFor_currPath);ReplacementFor_builtPath.append(base::
ReplacementFor_consts::ReplacementFor_kFilePathSeperator);
#if ReplacementFor_ELPP_OS_UNIX
status=mkdir(ReplacementFor_builtPath.c_str(),ReplacementFor_ELPP_LOG_PERMS);
ReplacementFor_currPath=STRTOK(nullptr,base::ReplacementFor_consts::
ReplacementFor_kFilePathSeperator,(0x2288+760-0x2580));
#elif ReplacementFor_ELPP_OS_WINDOWS
status=_mkdir(ReplacementFor_builtPath.c_str());ReplacementFor_currPath=STRTOK(
nullptr,base::ReplacementFor_consts::ReplacementFor_kFilePathSeperator,&
ReplacementFor_nextTok_);
#endif  
}if(status==-(0x157d+83-0x15cf)){ReplacementFor_ELPP_INTERNAL_ERROR(
"\x45\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x63\x72\x65\x61\x74\x69\x6e\x67\x20\x70\x61\x74\x68\x20\x5b"
<<ReplacementFor_path<<"\x5d",true);return false;}return true;}std::string File
::ReplacementFor_extractPathFromFilename(const std::string&
ReplacementFor_fullPath,const char*ReplacementFor_separator){if((
ReplacementFor_fullPath=="")||(ReplacementFor_fullPath.find(
ReplacementFor_separator)==std::string::npos)){return ReplacementFor_fullPath;}
std::size_t ReplacementFor_lastSlashAt=ReplacementFor_fullPath.find_last_of(
ReplacementFor_separator);if(ReplacementFor_lastSlashAt==(0x19e6+2379-0x2331)){
return std::string(ReplacementFor_separator);}return ReplacementFor_fullPath.
substr((0x10e3+2423-0x1a5a),ReplacementFor_lastSlashAt+(0x8b9+6736-0x2308));}
void File::ReplacementFor_buildStrippedFilename(const char*
ReplacementFor_filename,char ReplacementFor_buff[],std::size_t 
ReplacementFor_limit){std::size_t ReplacementFor_sizeOfFilename=strlen(
ReplacementFor_filename);if(ReplacementFor_sizeOfFilename>=ReplacementFor_limit)
{ReplacementFor_filename+=(ReplacementFor_sizeOfFilename-ReplacementFor_limit);
if(ReplacementFor_filename[(0x1ca3+2467-0x2646)]!=((char)(0x124+2977-0xc97))&&
ReplacementFor_filename[(0x33+9310-0x2490)]!=((char)(0xae1+6465-0x23f4))){
ReplacementFor_filename+=(0x8df+2532-0x12c0);STRCAT(ReplacementFor_buff,
"\x2e\x2e",ReplacementFor_limit);}}STRCAT(ReplacementFor_buff,
ReplacementFor_filename,ReplacementFor_limit);}void File::
ReplacementFor_buildBaseFilename(const std::string&ReplacementFor_fullPath,char 
ReplacementFor_buff[],std::size_t ReplacementFor_limit,const char*
ReplacementFor_separator){const char*ReplacementFor_filename=
ReplacementFor_fullPath.c_str();std::size_t ReplacementFor_lastSlashAt=
ReplacementFor_fullPath.find_last_of(ReplacementFor_separator);
ReplacementFor_filename+=ReplacementFor_lastSlashAt?ReplacementFor_lastSlashAt+
(0x112f+3112-0x1d56):(0x14f8+2747-0x1fb3);std::size_t 
ReplacementFor_sizeOfFilename=strlen(ReplacementFor_filename);if(
ReplacementFor_sizeOfFilename>=ReplacementFor_limit){ReplacementFor_filename+=(
ReplacementFor_sizeOfFilename-ReplacementFor_limit);if(ReplacementFor_filename[
(0x892+1949-0x102f)]!=((char)(0x4bd+6128-0x1c7f))&&ReplacementFor_filename[
(0xe07+3562-0x1bf0)]!=((char)(0xb5+6541-0x1a14))){ReplacementFor_filename+=
(0x17cd+3133-0x2407);STRCAT(ReplacementFor_buff,"\x2e\x2e",ReplacementFor_limit)
;}}STRCAT(ReplacementFor_buff,ReplacementFor_filename,ReplacementFor_limit);}
bool Str::ReplacementFor_wildCardMatch(const char*str,const char*pattern){while(
*pattern){switch(*pattern){case((char)(0x14aa+2196-0x1cff)):if(!*str)return 
false;++str;++pattern;break;case((char)(0xb15+3158-0x1741)):if(
ReplacementFor_wildCardMatch(str,pattern+(0x8b9+4380-0x19d4)))return true;if(*
str&&ReplacementFor_wildCardMatch(str+(0x22b0+370-0x2421),pattern))return true;
return false;default:if(*str++!=*pattern++)return false;break;}}return!*str&&!*
pattern;}std::string&Str::ReplacementFor_ltrim(std::string&str){str.erase(str.
begin(),std::find_if(str.begin(),str.end(),[](char c){return!std::isspace(c);}))
;return str;}std::string&Str::ReplacementFor_rtrim(std::string&str){str.erase(
std::find_if(str.rbegin(),str.rend(),[](char c){return!std::isspace(c);}).base()
,str.end());return str;}std::string&Str::ReplacementFor_trim(std::string&str){
return ReplacementFor_ltrim(ReplacementFor_rtrim(str));}bool Str::
ReplacementFor_startsWith(const std::string&str,const std::string&
ReplacementFor_start){return(str.length()>=ReplacementFor_start.length())&&(str.
compare((0x4d0+8457-0x25d9),ReplacementFor_start.length(),ReplacementFor_start)
==(0x1dc+8286-0x223a));}bool Str::ReplacementFor_endsWith(const std::string&str,
const std::string&end){return(str.length()>=end.length())&&(str.compare(str.
length()-end.length(),end.length(),end)==(0x1b0b+1029-0x1f10));}std::string&Str
::ReplacementFor_replaceAll(std::string&str,char ReplacementFor_replaceWhat,char
 ReplacementFor_replaceWith){std::replace(str.begin(),str.end(),
ReplacementFor_replaceWhat,ReplacementFor_replaceWith);return str;}std::string&
Str::ReplacementFor_replaceAll(std::string&str,const std::string&
ReplacementFor_replaceWhat,const std::string&ReplacementFor_replaceWith){if(
ReplacementFor_replaceWhat==ReplacementFor_replaceWith)return str;std::size_t 
ReplacementFor_foundAt=std::string::npos;while((ReplacementFor_foundAt=str.find(
ReplacementFor_replaceWhat,ReplacementFor_foundAt+(0x923+6990-0x2470)))!=std::
string::npos){str.replace(ReplacementFor_foundAt,ReplacementFor_replaceWhat.
length(),ReplacementFor_replaceWith);}return str;}void Str::
ReplacementFor_replaceFirstWithEscape(base::type::ReplacementFor_string_t&str,
const base::type::ReplacementFor_string_t&ReplacementFor_replaceWhat,const base
::type::ReplacementFor_string_t&ReplacementFor_replaceWith){std::size_t 
ReplacementFor_foundAt=base::type::ReplacementFor_string_t::npos;while((
ReplacementFor_foundAt=str.find(ReplacementFor_replaceWhat,
ReplacementFor_foundAt+(0xc15+2001-0x13e5)))!=base::type::
ReplacementFor_string_t::npos){if(ReplacementFor_foundAt>(0x1241+4126-0x225f)&&
str[ReplacementFor_foundAt-(0x847+2994-0x13f8)]==base::ReplacementFor_consts::
ReplacementFor_kFormatSpecifierChar){str.erase(ReplacementFor_foundAt-
(0x23c+3001-0xdf4),(0xd0a+2731-0x17b4));++ReplacementFor_foundAt;}else{str.
replace(ReplacementFor_foundAt,ReplacementFor_replaceWhat.length(),
ReplacementFor_replaceWith);return;}}}
#if defined(ReplacementFor_ELPP_UNICODE)
void Str::ReplacementFor_replaceFirstWithEscape(base::type::
ReplacementFor_string_t&str,const base::type::ReplacementFor_string_t&
ReplacementFor_replaceWhat,const std::string&ReplacementFor_replaceWith){
ReplacementFor_replaceFirstWithEscape(str,ReplacementFor_replaceWhat,base::type
::ReplacementFor_string_t(ReplacementFor_replaceWith.begin(),
ReplacementFor_replaceWith.end()));}
#endif  
std::string&Str::toUpper(std::string&str){std::transform(str.begin(),str.end(),
str.begin(),[](char c){return static_cast<char>(::toupper(c));});return str;}
bool Str::ReplacementFor_cStringEq(const char*ReplacementFor_s1,const char*
ReplacementFor_s2){if(ReplacementFor_s1==nullptr&&ReplacementFor_s2==nullptr)
return true;if(ReplacementFor_s1==nullptr||ReplacementFor_s2==nullptr)return 
false;return strcmp(ReplacementFor_s1,ReplacementFor_s2)==(0xb0b+5736-0x2173);}
bool Str::ReplacementFor_cStringCaseEq(const char*ReplacementFor_s1,const char*
ReplacementFor_s2){if(ReplacementFor_s1==nullptr&&ReplacementFor_s2==nullptr)
return true;if(ReplacementFor_s1==nullptr||ReplacementFor_s2==nullptr)return 
false;int ReplacementFor_d=(0x163d+3454-0x23bb);while(true){const int 
ReplacementFor_c1=toupper(*ReplacementFor_s1++);const int ReplacementFor_c2=
toupper(*ReplacementFor_s2++);if(((ReplacementFor_d=ReplacementFor_c1-
ReplacementFor_c2)!=(0x161a+642-0x189c))||(ReplacementFor_c2=='\0')){break;}}
return ReplacementFor_d==(0x1942+391-0x1ac9);}bool Str::ReplacementFor_contains(
const char*str,char c){for(;*str;++str){if(*str==c)return true;}return false;}
char*Str::ReplacementFor_convertAndAddToBuff(std::size_t n,int len,char*buf,
const char*ReplacementFor_bufLim,bool ReplacementFor_zeroPadded){char 
ReplacementFor_localBuff[(0x1986+2949-0x2501)]="";char*p=
ReplacementFor_localBuff+sizeof(ReplacementFor_localBuff)-(0x18e2+2300-0x21dc);
if(n>(0x1c16+55-0x1c4d)){for(;n>(0x8d7+7281-0x2548)&&p>ReplacementFor_localBuff
&&len>(0x1745+3285-0x241a);n/=(0x21ec+816-0x2512),--len)*--p=static_cast<char>(n
%(0x9b5+2735-0x145a)+((char)(0xbd7+600-0xdff)));}else{*--p=
((char)(0x1530+4099-0x2503));--len;}if(ReplacementFor_zeroPadded)while(p>
ReplacementFor_localBuff&&len-- >(0x7af+7251-0x2402))*--p=static_cast<char>(
((char)(0x18c2+1117-0x1cef)));return ReplacementFor_addToBuff(p,buf,
ReplacementFor_bufLim);}char*Str::ReplacementFor_addToBuff(const char*str,char*
buf,const char*ReplacementFor_bufLim){while((buf<ReplacementFor_bufLim)&&((*buf=
*str++)!='\0'))++buf;return buf;}char*Str::ReplacementFor_clearBuff(char 
ReplacementFor_buff[],std::size_t ReplacementFor_lim){STRCPY(ReplacementFor_buff
,"",ReplacementFor_lim);ReplacementFor_ELPP_UNUSED(ReplacementFor_lim);return 
ReplacementFor_buff;}char*Str::ReplacementFor_wcharPtrToCharPtr(const wchar_t*
line){std::size_t ReplacementFor_len_=wcslen(line)+(0xcc6+5422-0x21f3);char*
ReplacementFor_buff_=static_cast<char*>(malloc(ReplacementFor_len_+
(0x1509+1242-0x19e2)));
#      if ReplacementFor_ELPP_OS_UNIX || (ReplacementFor_ELPP_OS_WINDOWS && !\
ReplacementFor_ELPP_CRT_DBG_WARNINGS)
std::wcstombs(ReplacementFor_buff_,line,ReplacementFor_len_);
#      elif ReplacementFor_ELPP_OS_WINDOWS
std::size_t ReplacementFor_convCount_=(0x38b+4580-0x156f);mbstate_t 
ReplacementFor_mbState_;::memset(static_cast<void*>(&ReplacementFor_mbState_),
(0x820+1612-0xe6c),sizeof(ReplacementFor_mbState_));wcsrtombs_s(&
ReplacementFor_convCount_,ReplacementFor_buff_,ReplacementFor_len_,&line,
ReplacementFor_len_,&ReplacementFor_mbState_);
#      endif  
return ReplacementFor_buff_;}
#if ReplacementFor_ELPP_OS_WINDOWS
const char*OS::ReplacementFor_getWindowsEnvironmentVariable(const char*
ReplacementFor_varname){const DWORD ReplacementFor_bufferLen=
(0x1276+1703-0x18eb);static char ReplacementFor_buffer[ReplacementFor_bufferLen]
;if(GetEnvironmentVariableA(ReplacementFor_varname,ReplacementFor_buffer,
ReplacementFor_bufferLen)){return ReplacementFor_buffer;}return nullptr;}
#endif  
#if ReplacementFor_ELPP_OS_ANDROID
std::string OS::ReplacementFor_getProperty(const char*ReplacementFor_prop){char 
ReplacementFor_propVal[ReplacementFor_PROP_VALUE_MAX+(0x989+5015-0x1d1f)];int 
ReplacementFor_ret=ReplacementFor___system_property_get(ReplacementFor_prop,
ReplacementFor_propVal);return ReplacementFor_ret==(0xe76+3766-0x1d2c)?std::
string():std::string(ReplacementFor_propVal);}std::string OS::
ReplacementFor_getDeviceName(void){std::stringstream ReplacementFor_ss;std::
string ReplacementFor_manufacturer=ReplacementFor_getProperty(
"\x72\x6f\x2e\x70\x72\x6f\x64\x75\x63\x74\x2e\x6d\x61\x6e\x75\x66\x61\x63\x74\x75\x72\x65\x72"
);std::string ReplacementFor_model=ReplacementFor_getProperty(
"\x72\x6f\x2e\x70\x72\x6f\x64\x75\x63\x74\x2e\x6d\x6f\x64\x65\x6c");if(
ReplacementFor_manufacturer.empty()||ReplacementFor_model.empty()){return std::
string();}ReplacementFor_ss<<ReplacementFor_manufacturer<<"\x2d"<<
ReplacementFor_model;return ReplacementFor_ss.str();}
#endif  
const std::string OS::ReplacementFor_getBashOutput(const char*
ReplacementFor_command){
#if (ReplacementFor_ELPP_OS_UNIX && !ReplacementFor_ELPP_OS_ANDROID && !\
ReplacementFor_ELPP_CYGWIN)
if(ReplacementFor_command==nullptr){return std::string();}FILE*
ReplacementFor_proc=nullptr;if((ReplacementFor_proc=popen(ReplacementFor_command
,"\x72"))==nullptr){ReplacementFor_ELPP_INTERNAL_ERROR(
"\n" "\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x72\x75\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x5b"
<<ReplacementFor_command<<"\x5d",true);return std::string();}char 
ReplacementFor_hBuff[(0x2196+1333-0x16cb)];if(fgets(ReplacementFor_hBuff,sizeof(
ReplacementFor_hBuff),ReplacementFor_proc)!=nullptr){pclose(ReplacementFor_proc)
;const std::size_t ReplacementFor_buffLen=strlen(ReplacementFor_hBuff);if(
ReplacementFor_buffLen>(0xee8+3408-0x1c38)&&ReplacementFor_hBuff[
ReplacementFor_buffLen-(0x175d+49-0x178d)]=='\n'){ReplacementFor_hBuff[
ReplacementFor_buffLen-(0x1057+1864-0x179e)]='\0';}return std::string(
ReplacementFor_hBuff);}else{pclose(ReplacementFor_proc);}return std::string();
#else
ReplacementFor_ELPP_UNUSED(ReplacementFor_command);return std::string();
#endif
}std::string OS::ReplacementFor_getEnvironmentVariable(const char*
ReplacementFor_variableName,const char*ReplacementFor_defaultVal,const char*
ReplacementFor_alternativeBashCommand){
#if ReplacementFor_ELPP_OS_UNIX
const char*val=getenv(ReplacementFor_variableName);
#elif ReplacementFor_ELPP_OS_WINDOWS
const char*val=ReplacementFor_getWindowsEnvironmentVariable(
ReplacementFor_variableName);
#endif  
if((val==nullptr)||((strcmp(val,"")==(0xaf9+3680-0x1959)))){
#if ReplacementFor_ELPP_OS_UNIX && defined(\
ReplacementFor_ELPP_FORCE_ENV_VAR_FROM_BASH)
std::string ReplacementFor_valBash=base::ReplacementFor_utils::OS::
ReplacementFor_getBashOutput(ReplacementFor_alternativeBashCommand);if(
ReplacementFor_valBash.empty()){return std::string(ReplacementFor_defaultVal);}
else{return ReplacementFor_valBash;}
#elif ReplacementFor_ELPP_OS_WINDOWS || ReplacementFor_ELPP_OS_UNIX
ReplacementFor_ELPP_UNUSED(ReplacementFor_alternativeBashCommand);return std::
string(ReplacementFor_defaultVal);
#endif  
}return std::string(val);}std::string OS::ReplacementFor_currentUser(void){
#if ReplacementFor_ELPP_OS_UNIX && !ReplacementFor_ELPP_OS_ANDROID
return ReplacementFor_getEnvironmentVariable("\x55\x53\x45\x52",base::
ReplacementFor_consts::ReplacementFor_kUnknownUser,"\x77\x68\x6f\x61\x6d\x69");
#elif ReplacementFor_ELPP_OS_WINDOWS
return ReplacementFor_getEnvironmentVariable("\x55\x53\x45\x52\x4e\x41\x4d\x45",
base::ReplacementFor_consts::ReplacementFor_kUnknownUser);
#elif ReplacementFor_ELPP_OS_ANDROID
ReplacementFor_ELPP_UNUSED(base::ReplacementFor_consts::
ReplacementFor_kUnknownUser);return std::string("\x61\x6e\x64\x72\x6f\x69\x64");
#else
return std::string();
#endif  
}std::string OS::ReplacementFor_currentHost(void){
#if ReplacementFor_ELPP_OS_UNIX && !ReplacementFor_ELPP_OS_ANDROID
return ReplacementFor_getEnvironmentVariable("\x48\x4f\x53\x54\x4e\x41\x4d\x45",
base::ReplacementFor_consts::ReplacementFor_kUnknownHost,
"\x68\x6f\x73\x74\x6e\x61\x6d\x65");
#elif ReplacementFor_ELPP_OS_WINDOWS
return ReplacementFor_getEnvironmentVariable(
"\x43\x4f\x4d\x50\x55\x54\x45\x52\x4e\x41\x4d\x45",base::ReplacementFor_consts::
ReplacementFor_kUnknownHost);
#elif ReplacementFor_ELPP_OS_ANDROID
ReplacementFor_ELPP_UNUSED(base::ReplacementFor_consts::
ReplacementFor_kUnknownHost);return ReplacementFor_getDeviceName();
#else
return std::string();
#endif  
}bool OS::ReplacementFor_termSupportsColor(void){std::string ReplacementFor_term
=ReplacementFor_getEnvironmentVariable("\x54\x45\x52\x4d","");return 
ReplacementFor_term=="\x78\x74\x65\x72\x6d"||ReplacementFor_term==
"\x78\x74\x65\x72\x6d\x2d\x63\x6f\x6c\x6f\x72"||ReplacementFor_term==
"\x78\x74\x65\x72\x6d\x2d\x32\x35\x36\x63\x6f\x6c\x6f\x72"||ReplacementFor_term
=="\x73\x63\x72\x65\x65\x6e"||ReplacementFor_term=="\x6c\x69\x6e\x75\x78"||
ReplacementFor_term=="\x63\x79\x67\x77\x69\x6e"||ReplacementFor_term==
"\x73\x63\x72\x65\x65\x6e\x2d\x32\x35\x36\x63\x6f\x6c\x6f\x72";}void 
ReplacementFor_DateTime::gettimeofday(struct timeval*ReplacementFor_tv){
#if ReplacementFor_ELPP_OS_WINDOWS
if(ReplacementFor_tv!=nullptr){
#  if ReplacementFor_ELPP_COMPILER_MSVC || defined(\
ReplacementFor__MSC_EXTENSIONS)
const unsigned __int64 ReplacementFor_delta_=11644473600000000Ui64;
#  else
const unsigned __int64 ReplacementFor_delta_=11644473600000000ULL;
#  endif  
const double ReplacementFor_secOffSet=0.000001;const unsigned long 
ReplacementFor_usecOffSet=1000000;FILETIME fileTime;GetSystemTimeAsFileTime(&
fileTime);unsigned __int64 ReplacementFor_present=(0x79+8341-0x210e);
ReplacementFor_present|=fileTime.dwHighDateTime;ReplacementFor_present=
ReplacementFor_present<<(0x953+2637-0x1380);ReplacementFor_present|=fileTime.
dwLowDateTime;ReplacementFor_present/=(0x1733+266-0x1833);ReplacementFor_present
-=ReplacementFor_delta_;ReplacementFor_tv->tv_sec=static_cast<long>(
ReplacementFor_present*ReplacementFor_secOffSet);ReplacementFor_tv->tv_usec=
static_cast<long>(ReplacementFor_present%ReplacementFor_usecOffSet);}
#else
::gettimeofday(ReplacementFor_tv,nullptr);
#endif  
}std::string ReplacementFor_DateTime::ReplacementFor_getDateTime(const char*
format,const base::ReplacementFor_SubsecondPrecision*ReplacementFor_ssPrec){
struct timeval ReplacementFor_currTime;gettimeofday(&ReplacementFor_currTime);
return ReplacementFor_timevalToString(ReplacementFor_currTime,format,
ReplacementFor_ssPrec);}std::string ReplacementFor_DateTime::
ReplacementFor_timevalToString(struct timeval ReplacementFor_tval,const char*
format,const ReplacementFor_el::base::ReplacementFor_SubsecondPrecision*
ReplacementFor_ssPrec){struct::tm ReplacementFor_timeInfo;
ReplacementFor_buildTimeInfo(&ReplacementFor_tval,&ReplacementFor_timeInfo);
const int ReplacementFor_kBuffSize=(0x915+7621-0x26bc);char ReplacementFor_buff_
[ReplacementFor_kBuffSize]="";ReplacementFor_parseFormat(ReplacementFor_buff_,
ReplacementFor_kBuffSize,format,&ReplacementFor_timeInfo,static_cast<std::size_t
>(ReplacementFor_tval.tv_usec/ReplacementFor_ssPrec->ReplacementFor_m_offset),
ReplacementFor_ssPrec);return std::string(ReplacementFor_buff_);}base::type::
ReplacementFor_string_t ReplacementFor_DateTime::formatTime(unsigned long long 
time,base::ReplacementFor_TimestampUnit ReplacementFor_timestampUnit){base::type
::ReplacementFor_EnumType ReplacementFor_start=static_cast<base::type::
ReplacementFor_EnumType>(ReplacementFor_timestampUnit);const base::type::
ReplacementFor_char_t*ReplacementFor_unit=base::ReplacementFor_consts::
ReplacementFor_kTimeFormats[ReplacementFor_start].ReplacementFor_unit;for(base::
type::ReplacementFor_EnumType i=ReplacementFor_start;i<base::
ReplacementFor_consts::ReplacementFor_kTimeFormatsCount-(0x115a+3803-0x2034);++i
){if(time<=base::ReplacementFor_consts::ReplacementFor_kTimeFormats[i].value){
break;}if(base::ReplacementFor_consts::ReplacementFor_kTimeFormats[i].value==
1000.0f&&time/1000.0f<1.9f){break;}time/=static_cast<decltype(time)>(base::
ReplacementFor_consts::ReplacementFor_kTimeFormats[i].value);ReplacementFor_unit
=base::ReplacementFor_consts::ReplacementFor_kTimeFormats[i+(0x432+4713-0x169a)]
.ReplacementFor_unit;}base::type::ReplacementFor_stringstream_t 
ReplacementFor_ss;ReplacementFor_ss<<time<<"\x20"<<ReplacementFor_unit;return 
ReplacementFor_ss.str();}unsigned long long ReplacementFor_DateTime::
ReplacementFor_getTimeDifference(const struct timeval&ReplacementFor_endTime,
const struct timeval&ReplacementFor_startTime,base::ReplacementFor_TimestampUnit
 ReplacementFor_timestampUnit){if(ReplacementFor_timestampUnit==base::
ReplacementFor_TimestampUnit::ReplacementFor_Microsecond){return static_cast<
unsigned long long>(static_cast<unsigned long long>(1000000*
ReplacementFor_endTime.tv_sec+ReplacementFor_endTime.tv_usec)-static_cast<
unsigned long long>(1000000*ReplacementFor_startTime.tv_sec+
ReplacementFor_startTime.tv_usec));}auto ReplacementFor_conv=[](const struct 
timeval&ReplacementFor_tim){return static_cast<unsigned long long>((
ReplacementFor_tim.tv_sec*(0xc43+2115-0x109e))+(ReplacementFor_tim.tv_usec/
(0x78d+7330-0x2047)));};return static_cast<unsigned long long>(
ReplacementFor_conv(ReplacementFor_endTime)-ReplacementFor_conv(
ReplacementFor_startTime));}struct::tm*ReplacementFor_DateTime::
ReplacementFor_buildTimeInfo(struct timeval*ReplacementFor_currTime,struct::tm*
ReplacementFor_timeInfo){
#if ReplacementFor_ELPP_OS_UNIX
time_t ReplacementFor_rawTime=ReplacementFor_currTime->tv_sec;::
ReplacementFor_elpptime_r(&ReplacementFor_rawTime,ReplacementFor_timeInfo);
return ReplacementFor_timeInfo;
#else
#  if ReplacementFor_ELPP_COMPILER_MSVC
ReplacementFor_ELPP_UNUSED(ReplacementFor_currTime);time_t t;
#    if defined(_USE_32BIT_TIME_T)
_time32(&t);
#    else
_time64(&t);
#    endif
ReplacementFor_elpptime_s(ReplacementFor_timeInfo,&t);return 
ReplacementFor_timeInfo;
#  else
time_t ReplacementFor_rawTime=ReplacementFor_currTime->tv_sec;struct tm*
ReplacementFor_tmInf=ReplacementFor_elpptime(&ReplacementFor_rawTime);*
ReplacementFor_timeInfo=*ReplacementFor_tmInf;return ReplacementFor_timeInfo;
#  endif  
#endif  
}char*ReplacementFor_DateTime::ReplacementFor_parseFormat(char*buf,std::size_t 
ReplacementFor_bufSz,const char*format,const struct tm*ReplacementFor_tInfo,std
::size_t ReplacementFor_msec,const base::ReplacementFor_SubsecondPrecision*
ReplacementFor_ssPrec){const char*ReplacementFor_bufLim=buf+ReplacementFor_bufSz
;for(;*format;++format){if(*format==base::ReplacementFor_consts::
ReplacementFor_kFormatSpecifierChar){switch(*++format){case base::
ReplacementFor_consts::ReplacementFor_kFormatSpecifierChar:break;case'\0':--
format;break;case((char)(0x290+6009-0x19a5)):buf=base::ReplacementFor_utils::Str
::ReplacementFor_convertAndAddToBuff(ReplacementFor_tInfo->tm_mday,
(0x1572+797-0x188d),buf,ReplacementFor_bufLim);continue;case
((char)(0x55b+1924-0xc7e)):buf=base::ReplacementFor_utils::Str::
ReplacementFor_addToBuff(base::ReplacementFor_consts::ReplacementFor_kDaysAbbrev
[ReplacementFor_tInfo->tm_wday],buf,ReplacementFor_bufLim);continue;case
((char)(0x912+5854-0x1faf)):buf=base::ReplacementFor_utils::Str::
ReplacementFor_addToBuff(base::ReplacementFor_consts::ReplacementFor_kDays[
ReplacementFor_tInfo->tm_wday],buf,ReplacementFor_bufLim);continue;case
((char)(0x826+7923-0x26cc)):buf=base::ReplacementFor_utils::Str::
ReplacementFor_convertAndAddToBuff(ReplacementFor_tInfo->tm_mon+
(0x13b+2387-0xa8d),(0x7bb+6780-0x2235),buf,ReplacementFor_bufLim);continue;case
((char)(0x1e57+157-0x1e92)):buf=base::ReplacementFor_utils::Str::
ReplacementFor_addToBuff(base::ReplacementFor_consts::
ReplacementFor_kMonthsAbbrev[ReplacementFor_tInfo->tm_mon],buf,
ReplacementFor_bufLim);continue;case((char)(0x1151+1764-0x17f3)):buf=base::
ReplacementFor_utils::Str::ReplacementFor_addToBuff(base::ReplacementFor_consts
::ReplacementFor_kMonths[ReplacementFor_tInfo->tm_mon],buf,ReplacementFor_bufLim
);continue;case((char)(0x470+4326-0x14dd)):buf=base::ReplacementFor_utils::Str::
ReplacementFor_convertAndAddToBuff(ReplacementFor_tInfo->tm_year+base::
ReplacementFor_consts::ReplacementFor_kYearBase,(0x162+9201-0x2551),buf,
ReplacementFor_bufLim);continue;case((char)(0x841+5582-0x1db6)):buf=base::
ReplacementFor_utils::Str::ReplacementFor_convertAndAddToBuff(
ReplacementFor_tInfo->tm_year+base::ReplacementFor_consts::
ReplacementFor_kYearBase,(0x24d6+403-0x2665),buf,ReplacementFor_bufLim);continue
;case((char)(0x1698+2357-0x1f65)):buf=base::ReplacementFor_utils::Str::
ReplacementFor_convertAndAddToBuff(ReplacementFor_tInfo->tm_hour%
(0x129+4695-0x1374),(0x943+4677-0x1b86),buf,ReplacementFor_bufLim);continue;case
((char)(0x657+5357-0x1afc)):buf=base::ReplacementFor_utils::Str::
ReplacementFor_convertAndAddToBuff(ReplacementFor_tInfo->tm_hour,
(0xbcc+5486-0x2138),buf,ReplacementFor_bufLim);continue;case
((char)(0x1126+4006-0x205f)):buf=base::ReplacementFor_utils::Str::
ReplacementFor_convertAndAddToBuff(ReplacementFor_tInfo->tm_min,
(0x4ff+5818-0x1bb7),buf,ReplacementFor_bufLim);continue;case
((char)(0x3ab+3643-0x1173)):buf=base::ReplacementFor_utils::Str::
ReplacementFor_convertAndAddToBuff(ReplacementFor_tInfo->tm_sec,
(0x127c+4198-0x22e0),buf,ReplacementFor_bufLim);continue;case
((char)(0x4d8+7550-0x21dc)):case((char)(0x4ac+2770-0xf17)):buf=base::
ReplacementFor_utils::Str::ReplacementFor_convertAndAddToBuff(
ReplacementFor_msec,ReplacementFor_ssPrec->ReplacementFor_m_width,buf,
ReplacementFor_bufLim);continue;case((char)(0x1ed6+653-0x211d)):buf=base::
ReplacementFor_utils::Str::ReplacementFor_addToBuff((ReplacementFor_tInfo->
tm_hour>=(0xf8b+5346-0x2461))?base::ReplacementFor_consts::ReplacementFor_kPm:
base::ReplacementFor_consts::ReplacementFor_kAm,buf,ReplacementFor_bufLim);
continue;default:continue;}}if(buf==ReplacementFor_bufLim)break;*buf++=*format;}
return buf;}void ReplacementFor_CommandLineArgs::ReplacementFor_setArgs(int 
ReplacementFor_argc,char**ReplacementFor_argv){ReplacementFor_m_params.clear();
ReplacementFor_m_paramsWithValue.clear();if(ReplacementFor_argc==
(0x119d+4258-0x223f)||ReplacementFor_argv==nullptr){return;}
ReplacementFor_m_argc=ReplacementFor_argc;ReplacementFor_m_argv=
ReplacementFor_argv;for(int i=(0xb6c+2249-0x1434);i<ReplacementFor_m_argc;++i){
const char*ReplacementFor_v=(strstr(ReplacementFor_m_argv[i],"\x3d"));if(
ReplacementFor_v!=nullptr&&strlen(ReplacementFor_v)>(0x100+6813-0x1b9d)){std::
string key=std::string(ReplacementFor_m_argv[i]);key=key.substr(
(0xdb5+5086-0x2193),key.find_first_of(((char)(0x614+8462-0x26e5))));if(
ReplacementFor_hasParamWithValue(key.c_str())){ReplacementFor_ELPP_INTERNAL_INFO
((0x694+6876-0x216f),"\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x5b"<<key<<
"\x5d\x20\x5b"<<ReplacementFor_getParamValue(key.c_str())<<"\x5d");}else{
ReplacementFor_m_paramsWithValue.insert(std::make_pair(key,std::string(
ReplacementFor_v+(0x11eb+1725-0x18a7))));}}if(ReplacementFor_v==nullptr){if(
ReplacementFor_hasParam(ReplacementFor_m_argv[i])){
ReplacementFor_ELPP_INTERNAL_INFO((0x575+4413-0x16b1),
"\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x5b"<<ReplacementFor_m_argv[i]<<"\x5d");}
else{ReplacementFor_m_params.push_back(std::string(ReplacementFor_m_argv[i]));}}
}}bool ReplacementFor_CommandLineArgs::ReplacementFor_hasParamWithValue(const 
char*ReplacementFor_paramKey)const{return ReplacementFor_m_paramsWithValue.find(
std::string(ReplacementFor_paramKey))!=ReplacementFor_m_paramsWithValue.end();}
const char*ReplacementFor_CommandLineArgs::ReplacementFor_getParamValue(const 
char*ReplacementFor_paramKey)const{std::unordered_map<std::string,std::string>::
const_iterator iter=ReplacementFor_m_paramsWithValue.find(std::string(
ReplacementFor_paramKey));return iter!=ReplacementFor_m_paramsWithValue.end()?
iter->second.c_str():"";}bool ReplacementFor_CommandLineArgs::
ReplacementFor_hasParam(const char*ReplacementFor_paramKey)const{return std::
find(ReplacementFor_m_params.begin(),ReplacementFor_m_params.end(),std::string(
ReplacementFor_paramKey))!=ReplacementFor_m_params.end();}bool 
ReplacementFor_CommandLineArgs::empty(void)const{return ReplacementFor_m_params.
empty()&&ReplacementFor_m_paramsWithValue.empty();}std::size_t 
ReplacementFor_CommandLineArgs::size(void)const{return ReplacementFor_m_params.
size()+ReplacementFor_m_paramsWithValue.size();}base::type::
ReplacementFor_ostream_t&operator<<(base::type::ReplacementFor_ostream_t&os,
const ReplacementFor_CommandLineArgs&c){for(int i=(0x1889+3399-0x25cf);i<c.
ReplacementFor_m_argc;++i){os<<ReplacementFor_ELPP_LITERAL("\x5b")<<c.
ReplacementFor_m_argv[i]<<ReplacementFor_ELPP_LITERAL("\x5d");if(i<c.
ReplacementFor_m_argc-(0x215+6856-0x1cdc)){os<<ReplacementFor_ELPP_LITERAL(
"\x20");}}return os;}}namespace ReplacementFor_threading{
#if ReplacementFor_ELPP_THREADING_ENABLED
#  if ReplacementFor_ELPP_USE_STD_THREADING
#      if ReplacementFor_ELPP_ASYNC_LOGGING
static void ReplacementFor_msleep(int ms){
#         if defined(ReplacementFor_ELPP_NO_SLEEP_FOR)
usleep(ms*(0xc05+7037-0x239a));
#         else
std::this_thread::sleep_for(std::chrono::milliseconds(ms));
#         endif  
}
#      endif  
#  endif  
#endif  
}void ReplacementFor_SubsecondPrecision::init(int width){if(width<
(0x5e4+2299-0xede)||width>(0x20a+9312-0x2664)){width=base::ReplacementFor_consts
::ReplacementFor_kDefaultSubsecondPrecision;}ReplacementFor_m_width=width;switch
(ReplacementFor_m_width){case(0x2684+50-0x26b3):ReplacementFor_m_offset=
(0x1fbb+367-0x1d42);break;case(0xb15+562-0xd43):ReplacementFor_m_offset=
(0xdea+5159-0x21ad);break;case(0xd5f+1945-0x14f3):ReplacementFor_m_offset=
(0x1203+4835-0x24dc);break;case(0x5dd+3985-0x1568):ReplacementFor_m_offset=
(0x1611+557-0x183d);break;default:ReplacementFor_m_offset=(0xc9f+5602-0x1e99);
break;}}ReplacementFor_LogFormat::ReplacementFor_LogFormat(void):
ReplacementFor_m_level(Level::Unknown),ReplacementFor_m_userFormat(base::type::
ReplacementFor_string_t()),ReplacementFor_m_format(base::type::
ReplacementFor_string_t()),ReplacementFor_m_dateTimeFormat(std::string()),
ReplacementFor_m_flags((0x1dc7+2195-0x265a)),ReplacementFor_m_currentUser(base::
ReplacementFor_utils::OS::ReplacementFor_currentUser()),
ReplacementFor_m_currentHost(base::ReplacementFor_utils::OS::
ReplacementFor_currentHost()){}ReplacementFor_LogFormat::
ReplacementFor_LogFormat(Level ReplacementFor_level,const base::type::
ReplacementFor_string_t&format):ReplacementFor_m_level(ReplacementFor_level),
ReplacementFor_m_userFormat(format),ReplacementFor_m_currentUser(base::
ReplacementFor_utils::OS::ReplacementFor_currentUser()),
ReplacementFor_m_currentHost(base::ReplacementFor_utils::OS::
ReplacementFor_currentHost()){ReplacementFor_parseFromFormat(
ReplacementFor_m_userFormat);}ReplacementFor_LogFormat::ReplacementFor_LogFormat
(const ReplacementFor_LogFormat&ReplacementFor_logFormat):ReplacementFor_m_level
(ReplacementFor_logFormat.ReplacementFor_m_level),ReplacementFor_m_userFormat(
ReplacementFor_logFormat.ReplacementFor_m_userFormat),ReplacementFor_m_format(
ReplacementFor_logFormat.ReplacementFor_m_format),
ReplacementFor_m_dateTimeFormat(ReplacementFor_logFormat.
ReplacementFor_m_dateTimeFormat),ReplacementFor_m_flags(ReplacementFor_logFormat
.ReplacementFor_m_flags),ReplacementFor_m_currentUser(ReplacementFor_logFormat.
ReplacementFor_m_currentUser),ReplacementFor_m_currentHost(
ReplacementFor_logFormat.ReplacementFor_m_currentHost){}ReplacementFor_LogFormat
::ReplacementFor_LogFormat(ReplacementFor_LogFormat&&ReplacementFor_logFormat){
ReplacementFor_m_level=std::move(ReplacementFor_logFormat.ReplacementFor_m_level
);ReplacementFor_m_userFormat=std::move(ReplacementFor_logFormat.
ReplacementFor_m_userFormat);ReplacementFor_m_format=std::move(
ReplacementFor_logFormat.ReplacementFor_m_format);
ReplacementFor_m_dateTimeFormat=std::move(ReplacementFor_logFormat.
ReplacementFor_m_dateTimeFormat);ReplacementFor_m_flags=std::move(
ReplacementFor_logFormat.ReplacementFor_m_flags);ReplacementFor_m_currentUser=
std::move(ReplacementFor_logFormat.ReplacementFor_m_currentUser);
ReplacementFor_m_currentHost=std::move(ReplacementFor_logFormat.
ReplacementFor_m_currentHost);}ReplacementFor_LogFormat&ReplacementFor_LogFormat
::operator=(const ReplacementFor_LogFormat&ReplacementFor_logFormat){if(&
ReplacementFor_logFormat!=this){ReplacementFor_m_level=ReplacementFor_logFormat.
ReplacementFor_m_level;ReplacementFor_m_userFormat=ReplacementFor_logFormat.
ReplacementFor_m_userFormat;ReplacementFor_m_dateTimeFormat=
ReplacementFor_logFormat.ReplacementFor_m_dateTimeFormat;ReplacementFor_m_flags=
ReplacementFor_logFormat.ReplacementFor_m_flags;ReplacementFor_m_currentUser=
ReplacementFor_logFormat.ReplacementFor_m_currentUser;
ReplacementFor_m_currentHost=ReplacementFor_logFormat.
ReplacementFor_m_currentHost;}return*this;}bool ReplacementFor_LogFormat::
operator==(const ReplacementFor_LogFormat&other){return ReplacementFor_m_level==
other.ReplacementFor_m_level&&ReplacementFor_m_userFormat==other.
ReplacementFor_m_userFormat&&ReplacementFor_m_format==other.
ReplacementFor_m_format&&ReplacementFor_m_dateTimeFormat==other.
ReplacementFor_m_dateTimeFormat&&ReplacementFor_m_flags==other.
ReplacementFor_m_flags;}void ReplacementFor_LogFormat::
ReplacementFor_parseFromFormat(const base::type::ReplacementFor_string_t&
ReplacementFor_userFormat){base::type::ReplacementFor_string_t 
ReplacementFor_formatCopy=ReplacementFor_userFormat;ReplacementFor_m_flags=
(0x161+4832-0x1441);auto ReplacementFor_conditionalAddFlag=[&](const base::type
::ReplacementFor_char_t*ReplacementFor_specifier,base::
ReplacementFor_FormatFlags flag){std::size_t ReplacementFor_foundAt=base::type::
ReplacementFor_string_t::npos;while((ReplacementFor_foundAt=
ReplacementFor_formatCopy.find(ReplacementFor_specifier,ReplacementFor_foundAt+
(0x1245+1666-0x18c6)))!=base::type::ReplacementFor_string_t::npos){if(
ReplacementFor_foundAt>(0x50+9626-0x25ea)&&ReplacementFor_formatCopy[
ReplacementFor_foundAt-(0x87d+1983-0x103b)]==base::ReplacementFor_consts::
ReplacementFor_kFormatSpecifierChar){if(ReplacementFor_hasFlag(flag)){
ReplacementFor_formatCopy.erase(ReplacementFor_foundAt-(0xe3b+1189-0x12df),
(0x1834+2966-0x23c9));++ReplacementFor_foundAt;}}else{if(!ReplacementFor_hasFlag
(flag))ReplacementFor_addFlag(flag);}}};ReplacementFor_conditionalAddFlag(base::
ReplacementFor_consts::ReplacementFor_kAppNameFormatSpecifier,base::
ReplacementFor_FormatFlags::ReplacementFor_AppName);
ReplacementFor_conditionalAddFlag(base::ReplacementFor_consts::
ReplacementFor_kSeverityLevelFormatSpecifier,base::ReplacementFor_FormatFlags::
Level);ReplacementFor_conditionalAddFlag(base::ReplacementFor_consts::
ReplacementFor_kSeverityLevelShortFormatSpecifier,base::
ReplacementFor_FormatFlags::ReplacementFor_LevelShort);
ReplacementFor_conditionalAddFlag(base::ReplacementFor_consts::
ReplacementFor_kLoggerIdFormatSpecifier,base::ReplacementFor_FormatFlags::
ReplacementFor_LoggerId);ReplacementFor_conditionalAddFlag(base::
ReplacementFor_consts::ReplacementFor_kThreadIdFormatSpecifier,base::
ReplacementFor_FormatFlags::ReplacementFor_ThreadId);
ReplacementFor_conditionalAddFlag(base::ReplacementFor_consts::
ReplacementFor_kLogFileFormatSpecifier,base::ReplacementFor_FormatFlags::File);
ReplacementFor_conditionalAddFlag(base::ReplacementFor_consts::
ReplacementFor_kLogFileBaseFormatSpecifier,base::ReplacementFor_FormatFlags::
ReplacementFor_FileBase);ReplacementFor_conditionalAddFlag(base::
ReplacementFor_consts::ReplacementFor_kLogLineFormatSpecifier,base::
ReplacementFor_FormatFlags::Line);ReplacementFor_conditionalAddFlag(base::
ReplacementFor_consts::ReplacementFor_kLogLocationFormatSpecifier,base::
ReplacementFor_FormatFlags::ReplacementFor_Location);
ReplacementFor_conditionalAddFlag(base::ReplacementFor_consts::
ReplacementFor_kLogFunctionFormatSpecifier,base::ReplacementFor_FormatFlags::
Function);ReplacementFor_conditionalAddFlag(base::ReplacementFor_consts::
ReplacementFor_kCurrentUserFormatSpecifier,base::ReplacementFor_FormatFlags::
User);ReplacementFor_conditionalAddFlag(base::ReplacementFor_consts::
ReplacementFor_kCurrentHostFormatSpecifier,base::ReplacementFor_FormatFlags::
ReplacementFor_Host);ReplacementFor_conditionalAddFlag(base::
ReplacementFor_consts::ReplacementFor_kMessageFormatSpecifier,base::
ReplacementFor_FormatFlags::ReplacementFor_LogMessage);
ReplacementFor_conditionalAddFlag(base::ReplacementFor_consts::
ReplacementFor_kVerboseLevelFormatSpecifier,base::ReplacementFor_FormatFlags::
ReplacementFor_VerboseLevel);std::size_t ReplacementFor_dateIndex=std::string::
npos;if((ReplacementFor_dateIndex=ReplacementFor_formatCopy.find(base::
ReplacementFor_consts::ReplacementFor_kDateTimeFormatSpecifier))!=std::string::
npos){while(ReplacementFor_dateIndex>(0xfc9+2883-0x1b0c)&&
ReplacementFor_formatCopy[ReplacementFor_dateIndex-(0xe89+518-0x108e)]==base::
ReplacementFor_consts::ReplacementFor_kFormatSpecifierChar){
ReplacementFor_dateIndex=ReplacementFor_formatCopy.find(base::
ReplacementFor_consts::ReplacementFor_kDateTimeFormatSpecifier,
ReplacementFor_dateIndex+(0x1a8+7649-0x1f88));}if(ReplacementFor_dateIndex!=std
::string::npos){ReplacementFor_addFlag(base::ReplacementFor_FormatFlags::
ReplacementFor_DateTime);ReplacementFor_updateDateFormat(
ReplacementFor_dateIndex,ReplacementFor_formatCopy);}}ReplacementFor_m_format=
ReplacementFor_formatCopy;ReplacementFor_updateFormatSpec();}void 
ReplacementFor_LogFormat::ReplacementFor_updateDateFormat(std::size_t index,base
::type::ReplacementFor_string_t&ReplacementFor_currFormat){if(
ReplacementFor_hasFlag(base::ReplacementFor_FormatFlags::ReplacementFor_DateTime
)){index+=ReplacementFor_ELPP_STRLEN(base::ReplacementFor_consts::
ReplacementFor_kDateTimeFormatSpecifier);}const base::type::
ReplacementFor_char_t*ReplacementFor_ptr=ReplacementFor_currFormat.c_str()+index
;if((ReplacementFor_currFormat.size()>index)&&(ReplacementFor_ptr[
(0x2e5+1168-0x775)]==((char)(0x116f+3003-0x1caf)))){++ReplacementFor_ptr;int 
count=(0x704+961-0xac4);std::stringstream ReplacementFor_ss;for(;*
ReplacementFor_ptr;++ReplacementFor_ptr,++count){if(*ReplacementFor_ptr==
((char)(0x252+399-0x364))){++count;break;}ReplacementFor_ss<<static_cast<char>(*
ReplacementFor_ptr);}ReplacementFor_currFormat.erase(index,count);
ReplacementFor_m_dateTimeFormat=ReplacementFor_ss.str();}else{if(
ReplacementFor_hasFlag(base::ReplacementFor_FormatFlags::ReplacementFor_DateTime
)){ReplacementFor_m_dateTimeFormat=std::string(base::ReplacementFor_consts::
ReplacementFor_kDefaultDateTimeFormat);}}}void ReplacementFor_LogFormat::
ReplacementFor_updateFormatSpec(void){if(ReplacementFor_m_level==Level::
ReplacementFor_Debug){base::ReplacementFor_utils::Str::
ReplacementFor_replaceFirstWithEscape(ReplacementFor_m_format,base::
ReplacementFor_consts::ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_consts::ReplacementFor_kDebugLevelLogValue);base::
ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_m_format,base::ReplacementFor_consts::
ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_consts::
ReplacementFor_kDebugLevelShortLogValue);}else if(ReplacementFor_m_level==Level
::ReplacementFor_Info){base::ReplacementFor_utils::Str::
ReplacementFor_replaceFirstWithEscape(ReplacementFor_m_format,base::
ReplacementFor_consts::ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_consts::ReplacementFor_kInfoLevelLogValue);base::
ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_m_format,base::ReplacementFor_consts::
ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_consts::
ReplacementFor_kInfoLevelShortLogValue);}else if(ReplacementFor_m_level==Level::
ReplacementFor_Warning){base::ReplacementFor_utils::Str::
ReplacementFor_replaceFirstWithEscape(ReplacementFor_m_format,base::
ReplacementFor_consts::ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_consts::ReplacementFor_kWarningLevelLogValue);base::
ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_m_format,base::ReplacementFor_consts::
ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_consts::
ReplacementFor_kWarningLevelShortLogValue);}else if(ReplacementFor_m_level==
Level::Error){base::ReplacementFor_utils::Str::
ReplacementFor_replaceFirstWithEscape(ReplacementFor_m_format,base::
ReplacementFor_consts::ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_consts::ReplacementFor_kErrorLevelLogValue);base::
ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_m_format,base::ReplacementFor_consts::
ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_consts::
ReplacementFor_kErrorLevelShortLogValue);}else if(ReplacementFor_m_level==Level
::ReplacementFor_Fatal){base::ReplacementFor_utils::Str::
ReplacementFor_replaceFirstWithEscape(ReplacementFor_m_format,base::
ReplacementFor_consts::ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_consts::ReplacementFor_kFatalLevelLogValue);base::
ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_m_format,base::ReplacementFor_consts::
ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_consts::
ReplacementFor_kFatalLevelShortLogValue);}else if(ReplacementFor_m_level==Level
::ReplacementFor_Verbose){base::ReplacementFor_utils::Str::
ReplacementFor_replaceFirstWithEscape(ReplacementFor_m_format,base::
ReplacementFor_consts::ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_consts::ReplacementFor_kVerboseLevelLogValue);base::
ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_m_format,base::ReplacementFor_consts::
ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_consts::
ReplacementFor_kVerboseLevelShortLogValue);}else if(ReplacementFor_m_level==
Level::ReplacementFor_Trace){base::ReplacementFor_utils::Str::
ReplacementFor_replaceFirstWithEscape(ReplacementFor_m_format,base::
ReplacementFor_consts::ReplacementFor_kSeverityLevelFormatSpecifier,base::
ReplacementFor_consts::ReplacementFor_kTraceLevelLogValue);base::
ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_m_format,base::ReplacementFor_consts::
ReplacementFor_kSeverityLevelShortFormatSpecifier,base::ReplacementFor_consts::
ReplacementFor_kTraceLevelShortLogValue);}if(ReplacementFor_hasFlag(base::
ReplacementFor_FormatFlags::User)){base::ReplacementFor_utils::Str::
ReplacementFor_replaceFirstWithEscape(ReplacementFor_m_format,base::
ReplacementFor_consts::ReplacementFor_kCurrentUserFormatSpecifier,
ReplacementFor_m_currentUser);}if(ReplacementFor_hasFlag(base::
ReplacementFor_FormatFlags::ReplacementFor_Host)){base::ReplacementFor_utils::
Str::ReplacementFor_replaceFirstWithEscape(ReplacementFor_m_format,base::
ReplacementFor_consts::ReplacementFor_kCurrentHostFormatSpecifier,
ReplacementFor_m_currentHost);}}ReplacementFor_TypedConfigurations::
ReplacementFor_TypedConfigurations(ReplacementFor_Configurations*
ReplacementFor_configurations,base::ReplacementFor_LogStreamsReferenceMap*
ReplacementFor_logStreamsReference){ReplacementFor_m_configurations=
ReplacementFor_configurations;ReplacementFor_m_logStreamsReference=
ReplacementFor_logStreamsReference;ReplacementFor_build(
ReplacementFor_m_configurations);}ReplacementFor_TypedConfigurations::
ReplacementFor_TypedConfigurations(const ReplacementFor_TypedConfigurations&
other){this->ReplacementFor_m_configurations=other.
ReplacementFor_m_configurations;this->ReplacementFor_m_logStreamsReference=other
.ReplacementFor_m_logStreamsReference;ReplacementFor_build(
ReplacementFor_m_configurations);}bool ReplacementFor_TypedConfigurations::
ReplacementFor_enabled(Level ReplacementFor_level){return 
ReplacementFor_getConfigByVal<bool>(ReplacementFor_level,&
ReplacementFor_m_enabledMap,"\x65\x6e\x61\x62\x6c\x65\x64");}bool 
ReplacementFor_TypedConfigurations::ReplacementFor_toFile(Level 
ReplacementFor_level){return ReplacementFor_getConfigByVal<bool>(
ReplacementFor_level,&ReplacementFor_m_toFileMap,"\x74\x6f\x46\x69\x6c\x65");}
const std::string&ReplacementFor_TypedConfigurations::ReplacementFor_filename(
Level ReplacementFor_level){return ReplacementFor_getConfigByRef<std::string>(
ReplacementFor_level,&ReplacementFor_m_filenameMap,
"\x66\x69\x6c\x65\x6e\x61\x6d\x65");}bool ReplacementFor_TypedConfigurations::
ReplacementFor_toStandardOutput(Level ReplacementFor_level){return 
ReplacementFor_getConfigByVal<bool>(ReplacementFor_level,&
ReplacementFor_m_toStandardOutputMap,
"\x74\x6f\x53\x74\x61\x6e\x64\x61\x72\x64\x4f\x75\x74\x70\x75\x74");}const base
::ReplacementFor_LogFormat&ReplacementFor_TypedConfigurations::
ReplacementFor_logFormat(Level ReplacementFor_level){return 
ReplacementFor_getConfigByRef<base::ReplacementFor_LogFormat>(
ReplacementFor_level,&ReplacementFor_m_logFormatMap,
"\x6c\x6f\x67\x46\x6f\x72\x6d\x61\x74");}const base::
ReplacementFor_SubsecondPrecision&ReplacementFor_TypedConfigurations::
ReplacementFor_subsecondPrecision(Level ReplacementFor_level){return 
ReplacementFor_getConfigByRef<base::ReplacementFor_SubsecondPrecision>(
ReplacementFor_level,&ReplacementFor_m_subsecondPrecisionMap,
"\x73\x75\x62\x73\x65\x63\x6f\x6e\x64\x50\x72\x65\x63\x69\x73\x69\x6f\x6e");}
const base::ReplacementFor_MillisecondsWidth&ReplacementFor_TypedConfigurations
::ReplacementFor_millisecondsWidth(Level ReplacementFor_level){return 
ReplacementFor_getConfigByRef<base::ReplacementFor_MillisecondsWidth>(
ReplacementFor_level,&ReplacementFor_m_subsecondPrecisionMap,
"\x6d\x69\x6c\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73\x57\x69\x64\x74\x68");}bool 
ReplacementFor_TypedConfigurations::ReplacementFor_performanceTracking(Level 
ReplacementFor_level){return ReplacementFor_getConfigByVal<bool>(
ReplacementFor_level,&ReplacementFor_m_performanceTrackingMap,
"\x70\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65\x54\x72\x61\x63\x6b\x69\x6e\x67");
}base::type::ReplacementFor_fstream_t*ReplacementFor_TypedConfigurations::
ReplacementFor_fileStream(Level ReplacementFor_level){return 
ReplacementFor_getConfigByRef<base::ReplacementFor_FileStreamPtr>(
ReplacementFor_level,&ReplacementFor_m_fileStreamMap,
"\x66\x69\x6c\x65\x53\x74\x72\x65\x61\x6d").get();}std::size_t 
ReplacementFor_TypedConfigurations::ReplacementFor_maxLogFileSize(Level 
ReplacementFor_level){return ReplacementFor_getConfigByVal<std::size_t>(
ReplacementFor_level,&ReplacementFor_m_maxLogFileSizeMap,
"\x6d\x61\x78\x4c\x6f\x67\x46\x69\x6c\x65\x53\x69\x7a\x65");}std::size_t 
ReplacementFor_TypedConfigurations::ReplacementFor_logFlushThreshold(Level 
ReplacementFor_level){return ReplacementFor_getConfigByVal<std::size_t>(
ReplacementFor_level,&ReplacementFor_m_logFlushThresholdMap,
"\x6c\x6f\x67\x46\x6c\x75\x73\x68\x54\x68\x72\x65\x73\x68\x6f\x6c\x64");}void 
ReplacementFor_TypedConfigurations::ReplacementFor_build(
ReplacementFor_Configurations*ReplacementFor_configurations){base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
lock());auto ReplacementFor_getBool=[](std::string ReplacementFor_boolStr)->bool
{base::ReplacementFor_utils::Str::ReplacementFor_trim(ReplacementFor_boolStr);
return(ReplacementFor_boolStr=="\x54\x52\x55\x45"||ReplacementFor_boolStr==
"\x74\x72\x75\x65"||ReplacementFor_boolStr=="\x31");};std::vector<
ReplacementFor_Configuration*>ReplacementFor_withFileSizeLimit;for(
ReplacementFor_Configurations::const_iterator ReplacementFor_it=
ReplacementFor_configurations->begin();ReplacementFor_it!=
ReplacementFor_configurations->end();++ReplacementFor_it){
ReplacementFor_Configuration*ReplacementFor_conf=*ReplacementFor_it;if(
ReplacementFor_conf->ReplacementFor_configurationType()==
ReplacementFor_ConfigurationType::ReplacementFor_Enabled){
ReplacementFor_setValue(ReplacementFor_conf->ReplacementFor_level(),
ReplacementFor_getBool(ReplacementFor_conf->value()),&
ReplacementFor_m_enabledMap);}else if(ReplacementFor_conf->
ReplacementFor_configurationType()==ReplacementFor_ConfigurationType::
ReplacementFor_ToFile){ReplacementFor_setValue(ReplacementFor_conf->
ReplacementFor_level(),ReplacementFor_getBool(ReplacementFor_conf->value()),&
ReplacementFor_m_toFileMap);}else if(ReplacementFor_conf->
ReplacementFor_configurationType()==ReplacementFor_ConfigurationType::
ReplacementFor_ToStandardOutput){ReplacementFor_setValue(ReplacementFor_conf->
ReplacementFor_level(),ReplacementFor_getBool(ReplacementFor_conf->value()),&
ReplacementFor_m_toStandardOutputMap);}else if(ReplacementFor_conf->
ReplacementFor_configurationType()==ReplacementFor_ConfigurationType::
ReplacementFor_Filename){}else if(ReplacementFor_conf->
ReplacementFor_configurationType()==ReplacementFor_ConfigurationType::Format){
ReplacementFor_setValue(ReplacementFor_conf->ReplacementFor_level(),base::
ReplacementFor_LogFormat(ReplacementFor_conf->ReplacementFor_level(),base::type
::ReplacementFor_string_t(ReplacementFor_conf->value().begin(),
ReplacementFor_conf->value().end())),&ReplacementFor_m_logFormatMap);}else if(
ReplacementFor_conf->ReplacementFor_configurationType()==
ReplacementFor_ConfigurationType::ReplacementFor_SubsecondPrecision){
ReplacementFor_setValue(Level::Global,base::ReplacementFor_SubsecondPrecision(
static_cast<int>(ReplacementFor_getULong(ReplacementFor_conf->value()))),&
ReplacementFor_m_subsecondPrecisionMap);}else if(ReplacementFor_conf->
ReplacementFor_configurationType()==ReplacementFor_ConfigurationType::
ReplacementFor_PerformanceTracking){ReplacementFor_setValue(Level::Global,
ReplacementFor_getBool(ReplacementFor_conf->value()),&
ReplacementFor_m_performanceTrackingMap);}else if(ReplacementFor_conf->
ReplacementFor_configurationType()==ReplacementFor_ConfigurationType::
ReplacementFor_MaxLogFileSize){auto ReplacementFor_v=ReplacementFor_getULong(
ReplacementFor_conf->value());ReplacementFor_setValue(ReplacementFor_conf->
ReplacementFor_level(),static_cast<std::size_t>(ReplacementFor_v),&
ReplacementFor_m_maxLogFileSizeMap);if(ReplacementFor_v!=(0x894+6704-0x22c4)){
ReplacementFor_withFileSizeLimit.push_back(ReplacementFor_conf);}}else if(
ReplacementFor_conf->ReplacementFor_configurationType()==
ReplacementFor_ConfigurationType::ReplacementFor_LogFlushThreshold){
ReplacementFor_setValue(ReplacementFor_conf->ReplacementFor_level(),static_cast<
std::size_t>(ReplacementFor_getULong(ReplacementFor_conf->value())),&
ReplacementFor_m_logFlushThresholdMap);}}for(ReplacementFor_Configurations::
const_iterator ReplacementFor_it=ReplacementFor_configurations->begin();
ReplacementFor_it!=ReplacementFor_configurations->end();++ReplacementFor_it){
ReplacementFor_Configuration*ReplacementFor_conf=*ReplacementFor_it;if(
ReplacementFor_conf->ReplacementFor_configurationType()==
ReplacementFor_ConfigurationType::ReplacementFor_Filename){
ReplacementFor_insertFile(ReplacementFor_conf->ReplacementFor_level(),
ReplacementFor_conf->value());}}for(std::vector<ReplacementFor_Configuration*>::
iterator ReplacementFor_conf=ReplacementFor_withFileSizeLimit.begin();
ReplacementFor_conf!=ReplacementFor_withFileSizeLimit.end();++
ReplacementFor_conf){ReplacementFor_unsafeValidateFileRolling((*
ReplacementFor_conf)->ReplacementFor_level(),base::
ReplacementFor_defaultPreRollOutCallback);}}unsigned long 
ReplacementFor_TypedConfigurations::ReplacementFor_getULong(std::string 
ReplacementFor_confVal){bool valid=true;base::ReplacementFor_utils::Str::
ReplacementFor_trim(ReplacementFor_confVal);valid=!ReplacementFor_confVal.empty(
)&&std::find_if(ReplacementFor_confVal.begin(),ReplacementFor_confVal.end(),[](
char c){return!base::ReplacementFor_utils::Str::isDigit(c);})==
ReplacementFor_confVal.end();if(!valid){valid=false;ReplacementFor_ELPP_ASSERT(
valid,
"\x43\x6f\x6e\x66\x20\x76\x61\x6c\x20\x6e\x6f\x74\x20\x61\x20\x76\x61\x6c\x69\x64\x20\x69\x6e\x74\x65\x67\x65\x72\x20\x5b"
<<ReplacementFor_confVal<<"\x5d");return(0x16b+4966-0x14d1);}return atol(
ReplacementFor_confVal.c_str());}std::string ReplacementFor_TypedConfigurations
::ReplacementFor_resolveFilename(const std::string&ReplacementFor_filename){std
::string ReplacementFor_resultingFilename=ReplacementFor_filename;std::size_t 
ReplacementFor_dateIndex=std::string::npos;std::string 
ReplacementFor_dateTimeFormatSpecifierStr=std::string(base::
ReplacementFor_consts::ReplacementFor_kDateTimeFormatSpecifierForFilename);if((
ReplacementFor_dateIndex=ReplacementFor_resultingFilename.find(
ReplacementFor_dateTimeFormatSpecifierStr.c_str()))!=std::string::npos){while(
ReplacementFor_dateIndex>(0x16f9+602-0x1953)&&ReplacementFor_resultingFilename[
ReplacementFor_dateIndex-(0x141a+2623-0x1e58)]==base::ReplacementFor_consts::
ReplacementFor_kFormatSpecifierChar){ReplacementFor_dateIndex=
ReplacementFor_resultingFilename.find(ReplacementFor_dateTimeFormatSpecifierStr.
c_str(),ReplacementFor_dateIndex+(0x676+3635-0x14a8));}if(
ReplacementFor_dateIndex!=std::string::npos){const char*ReplacementFor_ptr=
ReplacementFor_resultingFilename.c_str()+ReplacementFor_dateIndex;
ReplacementFor_ptr+=ReplacementFor_dateTimeFormatSpecifierStr.size();std::string
 ReplacementFor_fmt;if((ReplacementFor_resultingFilename.size()>
ReplacementFor_dateIndex)&&(ReplacementFor_ptr[(0x385+4613-0x158a)]==
((char)(0x5a9+1484-0xafa)))){++ReplacementFor_ptr;int count=(0x1d72+913-0x2102);
std::stringstream ReplacementFor_ss;for(;*ReplacementFor_ptr;++
ReplacementFor_ptr,++count){if(*ReplacementFor_ptr==((char)(0x1de3+1007-0x2155))
){++count;break;}ReplacementFor_ss<<*ReplacementFor_ptr;}
ReplacementFor_resultingFilename.erase(ReplacementFor_dateIndex+
ReplacementFor_dateTimeFormatSpecifierStr.size(),count);ReplacementFor_fmt=
ReplacementFor_ss.str();}else{ReplacementFor_fmt=std::string(base::
ReplacementFor_consts::ReplacementFor_kDefaultDateTimeFormatInFilename);}base::
ReplacementFor_SubsecondPrecision ReplacementFor_ssPrec((0x636+3159-0x128a));std
::string now=base::ReplacementFor_utils::ReplacementFor_DateTime::
ReplacementFor_getDateTime(ReplacementFor_fmt.c_str(),&ReplacementFor_ssPrec);
base::ReplacementFor_utils::Str::ReplacementFor_replaceAll(now,
((char)(0x92+5966-0x17b1)),((char)(0xb3b+3188-0x1782)));base::
ReplacementFor_utils::Str::ReplacementFor_replaceAll(
ReplacementFor_resultingFilename,ReplacementFor_dateTimeFormatSpecifierStr,now);
}}return ReplacementFor_resultingFilename;}void 
ReplacementFor_TypedConfigurations::ReplacementFor_insertFile(Level 
ReplacementFor_level,const std::string&ReplacementFor_fullFilename){std::string 
ReplacementFor_resolvedFilename=ReplacementFor_resolveFilename(
ReplacementFor_fullFilename);if(ReplacementFor_resolvedFilename.empty()){std::
cerr<<
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6c\x6f\x61\x64\x20\x65\x6d\x70\x74\x79\x20\x66\x69\x6c\x65\x2c\x20\x72\x65\x2d\x63\x68\x65\x63\x6b\x20\x79\x6f\x75\x72\x20\x63\x6f\x6e\x66\x20\x66\x6f\x72\x20\x6c\x65\x76\x65\x6c\x20\x5b"
<<ReplacementFor_LevelHelper::ReplacementFor_convertToString(
ReplacementFor_level)<<"\x5d";}std::string ReplacementFor_filePath=base::
ReplacementFor_utils::File::ReplacementFor_extractPathFromFilename(
ReplacementFor_resolvedFilename,base::ReplacementFor_consts::
ReplacementFor_kFilePathSeperator);if(ReplacementFor_filePath.size()<
ReplacementFor_resolvedFilename.size()){base::ReplacementFor_utils::File::
ReplacementFor_createPath(ReplacementFor_filePath);}auto ReplacementFor_create=[
&](Level ReplacementFor_level){base::ReplacementFor_LogStreamsReferenceMap::
iterator ReplacementFor_filestreamIter=ReplacementFor_m_logStreamsReference->
find(ReplacementFor_resolvedFilename);base::type::ReplacementFor_fstream_t*fs=
nullptr;if(ReplacementFor_filestreamIter==ReplacementFor_m_logStreamsReference->
end()){fs=base::ReplacementFor_utils::File::ReplacementFor_newFileStream(
ReplacementFor_resolvedFilename);ReplacementFor_m_filenameMap.insert(std::
make_pair(ReplacementFor_level,ReplacementFor_resolvedFilename));
ReplacementFor_m_fileStreamMap.insert(std::make_pair(ReplacementFor_level,base::
ReplacementFor_FileStreamPtr(fs)));ReplacementFor_m_logStreamsReference->insert(
std::make_pair(ReplacementFor_resolvedFilename,base::
ReplacementFor_FileStreamPtr(ReplacementFor_m_fileStreamMap.at(
ReplacementFor_level))));}else{ReplacementFor_m_filenameMap.insert(std::
make_pair(ReplacementFor_level,ReplacementFor_filestreamIter->first));
ReplacementFor_m_fileStreamMap.insert(std::make_pair(ReplacementFor_level,base::
ReplacementFor_FileStreamPtr(ReplacementFor_filestreamIter->second)));fs=
ReplacementFor_filestreamIter->second.get();}if(fs==nullptr){
ReplacementFor_ELPP_INTERNAL_ERROR(
"\x53\x65\x74\x20\x5b\x54\x4f\x5f\x46\x49\x4c\x45\x5d\x20\x6f\x66\x20\x5b"<<
ReplacementFor_LevelHelper::ReplacementFor_convertToString(ReplacementFor_level)
<<"\x5d\x20\x74\x6f\x20\x46\x41\x4c\x53\x45",false);ReplacementFor_setValue(
ReplacementFor_level,false,&ReplacementFor_m_toFileMap);}};ReplacementFor_create
(ReplacementFor_m_filenameMap.empty()&&ReplacementFor_m_fileStreamMap.empty()?
Level::Global:ReplacementFor_level);}bool ReplacementFor_TypedConfigurations::
ReplacementFor_unsafeValidateFileRolling(Level ReplacementFor_level,const 
ReplacementFor_PreRollOutCallback&ReplacementFor_preRollOutCallback){base::type
::ReplacementFor_fstream_t*fs=ReplacementFor_unsafeGetConfigByRef(
ReplacementFor_level,&ReplacementFor_m_fileStreamMap,
"\x66\x69\x6c\x65\x53\x74\x72\x65\x61\x6d").get();if(fs==nullptr){return true;}
std::size_t ReplacementFor_maxLogFileSize=ReplacementFor_unsafeGetConfigByVal(
ReplacementFor_level,&ReplacementFor_m_maxLogFileSizeMap,
"\x6d\x61\x78\x4c\x6f\x67\x46\x69\x6c\x65\x53\x69\x7a\x65");std::size_t 
ReplacementFor_currFileSize=base::ReplacementFor_utils::File::
ReplacementFor_getSizeOfFile(fs);if(ReplacementFor_maxLogFileSize!=
(0x708+6779-0x2183)&&ReplacementFor_currFileSize>=ReplacementFor_maxLogFileSize)
{std::string ReplacementFor_fname=ReplacementFor_unsafeGetConfigByRef(
ReplacementFor_level,&ReplacementFor_m_filenameMap,
"\x66\x69\x6c\x65\x6e\x61\x6d\x65");ReplacementFor_ELPP_INTERNAL_INFO(
(0xa1d+1808-0x112c),
"\x54\x72\x75\x6e\x63\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x5b"<<
ReplacementFor_fname<<
"\x5d\x20\x61\x73\x20\x61\x20\x72\x65\x73\x75\x6c\x74\x20\x6f\x66\x20\x63\x6f\x6e\x66\x20\x66\x6f\x72\x20\x6c\x65\x76\x65\x6c\x20\x5b"
<<ReplacementFor_LevelHelper::ReplacementFor_convertToString(
ReplacementFor_level)<<"\x5d");fs->close();ReplacementFor_preRollOutCallback(
ReplacementFor_fname.c_str(),ReplacementFor_currFileSize);fs->open(
ReplacementFor_fname,std::fstream::out|std::fstream::trunc);return true;}return 
false;}bool ReplacementFor_RegisteredHitCounters::ReplacementFor_validateEveryN(
const char*ReplacementFor_filename,base::type::ReplacementFor_LineNumber 
ReplacementFor_lineNumber,std::size_t n){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());base::
ReplacementFor_HitCounter*counter=get(ReplacementFor_filename,
ReplacementFor_lineNumber);if(counter==nullptr){ReplacementFor_registerNew(
counter=new base::ReplacementFor_HitCounter(ReplacementFor_filename,
ReplacementFor_lineNumber));}counter->ReplacementFor_validateHitCounts(n);bool 
result=(n>=(0x1317+491-0x1501)&&counter->ReplacementFor_hitCounts()!=
(0xf48+1691-0x15e3)&&counter->ReplacementFor_hitCounts()%n==(0x69a+4133-0x16bf))
;return result;}bool ReplacementFor_RegisteredHitCounters::
ReplacementFor_validateAfterN(const char*ReplacementFor_filename,base::type::
ReplacementFor_LineNumber ReplacementFor_lineNumber,std::size_t n){base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
lock());base::ReplacementFor_HitCounter*counter=get(ReplacementFor_filename,
ReplacementFor_lineNumber);if(counter==nullptr){ReplacementFor_registerNew(
counter=new base::ReplacementFor_HitCounter(ReplacementFor_filename,
ReplacementFor_lineNumber));}if(counter->ReplacementFor_hitCounts()>=n)return 
true;counter->increment();return false;}bool 
ReplacementFor_RegisteredHitCounters::ReplacementFor_validateNTimes(const char*
ReplacementFor_filename,base::type::ReplacementFor_LineNumber 
ReplacementFor_lineNumber,std::size_t n){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());base::
ReplacementFor_HitCounter*counter=get(ReplacementFor_filename,
ReplacementFor_lineNumber);if(counter==nullptr){ReplacementFor_registerNew(
counter=new base::ReplacementFor_HitCounter(ReplacementFor_filename,
ReplacementFor_lineNumber));}counter->increment();if(counter->
ReplacementFor_hitCounts()<=n)return true;return false;}
ReplacementFor_RegisteredLoggers::ReplacementFor_RegisteredLoggers(const 
ReplacementFor_LogBuilderPtr&ReplacementFor_defaultLogBuilder):
ReplacementFor_m_defaultLogBuilder(ReplacementFor_defaultLogBuilder){
ReplacementFor_m_defaultConfigurations.ReplacementFor_setToDefault();}
ReplacementFor_Logger*ReplacementFor_RegisteredLoggers::get(const std::string&id
,bool ReplacementFor_forceCreation){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());
ReplacementFor_Logger*ReplacementFor_logger_=base::ReplacementFor_utils::
ReplacementFor_Registry<ReplacementFor_Logger,std::string>::get(id);if(
ReplacementFor_logger_==nullptr&&ReplacementFor_forceCreation){bool 
ReplacementFor_validId=ReplacementFor_Logger::ReplacementFor_isValidId(id);if(!
ReplacementFor_validId){ReplacementFor_ELPP_ASSERT(ReplacementFor_validId,
"\x49\x6e\x76\x20\x6c\x6f\x67\x67\x65\x72\x20\x49\x44\x20\x5b"<<id<<"\x5d\x2e");
return nullptr;}ReplacementFor_logger_=new ReplacementFor_Logger(id,
ReplacementFor_m_defaultConfigurations,&ReplacementFor_m_logStreamsReference);
ReplacementFor_logger_->ReplacementFor_m_logBuilder=
ReplacementFor_m_defaultLogBuilder;ReplacementFor_registerNew(id,
ReplacementFor_logger_);ReplacementFor_LoggerRegistrationCallback*
ReplacementFor_callback=nullptr;for(const std::pair<std::string,base::type::
ReplacementFor_LoggerRegistrationCallbackPtr>&ReplacementFor_h:
ReplacementFor_m_loggerRegistrationCallbacks){ReplacementFor_callback=
ReplacementFor_h.second.get();if(ReplacementFor_callback!=nullptr&&
ReplacementFor_callback->ReplacementFor_enabled()){ReplacementFor_callback->
ReplacementFor_handle(ReplacementFor_logger_);}}}return ReplacementFor_logger_;}
bool ReplacementFor_RegisteredLoggers::remove(const std::string&id){if(id==base
::ReplacementFor_consts::ReplacementFor_kDefaultLoggerId){return false;}
ReplacementFor_Logger*ReplacementFor_logger=base::ReplacementFor_utils::
ReplacementFor_Registry<ReplacementFor_Logger,std::string>::get(id);if(
ReplacementFor_logger!=nullptr){ReplacementFor_unregister(ReplacementFor_logger)
;}return true;}void ReplacementFor_RegisteredLoggers::
ReplacementFor_unsafeFlushAll(void){ReplacementFor_ELPP_INTERNAL_INFO(
(0x9cc+1113-0xe24),
"\x46\x6c\x75\x73\x68\x69\x6e\x67\x20\x61\x6c\x6c\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x73"
);for(base::ReplacementFor_LogStreamsReferenceMap::iterator ReplacementFor_it=
ReplacementFor_m_logStreamsReference.begin();ReplacementFor_it!=
ReplacementFor_m_logStreamsReference.end();++ReplacementFor_it){if(
ReplacementFor_it->second.get()==nullptr)continue;ReplacementFor_it->second->
flush();}}ReplacementFor_VRegistry::ReplacementFor_VRegistry(base::type::
ReplacementFor_VerboseLevel ReplacementFor_level,base::type::
ReplacementFor_EnumType*ReplacementFor_pFlags):ReplacementFor_m_level(
ReplacementFor_level),ReplacementFor_m_pFlags(ReplacementFor_pFlags){}void 
ReplacementFor_VRegistry::ReplacementFor_setLevel(base::type::
ReplacementFor_VerboseLevel ReplacementFor_level){base::ReplacementFor_threading
::ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());if(
ReplacementFor_level>(0xedc+1618-0x1525))ReplacementFor_m_level=base::
ReplacementFor_consts::ReplacementFor_kMaxVerboseLevel;else 
ReplacementFor_m_level=ReplacementFor_level;}void ReplacementFor_VRegistry::
ReplacementFor_setModules(const char*ReplacementFor_modules){base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
lock());auto ReplacementFor_addSuffix=[](std::stringstream&ReplacementFor_ss,
const char*ReplacementFor_sfx,const char*prev){if(prev!=nullptr&&base::
ReplacementFor_utils::Str::ReplacementFor_endsWith(ReplacementFor_ss.str(),std::
string(prev))){std::string ReplacementFor_chr(ReplacementFor_ss.str().substr(
(0x1277+227-0x135a),ReplacementFor_ss.str().size()-strlen(prev)));
ReplacementFor_ss.str(std::string(""));ReplacementFor_ss<<ReplacementFor_chr;}if
(base::ReplacementFor_utils::Str::ReplacementFor_endsWith(ReplacementFor_ss.str(
),std::string(ReplacementFor_sfx))){std::string ReplacementFor_chr(
ReplacementFor_ss.str().substr((0x104a+4848-0x233a),ReplacementFor_ss.str().size
()-strlen(ReplacementFor_sfx)));ReplacementFor_ss.str(std::string(""));
ReplacementFor_ss<<ReplacementFor_chr;}ReplacementFor_ss<<ReplacementFor_sfx;};
auto insert=[&](std::stringstream&ReplacementFor_ss,base::type::
ReplacementFor_VerboseLevel ReplacementFor_level){if(!base::ReplacementFor_utils
::ReplacementFor_hasFlag(ReplacementFor_LoggingFlag::
ReplacementFor_DisableVModulesExtensions,*ReplacementFor_m_pFlags)){
ReplacementFor_addSuffix(ReplacementFor_ss,"\x2e\x68",nullptr);
ReplacementFor_m_modules.insert(std::make_pair(ReplacementFor_ss.str(),
ReplacementFor_level));ReplacementFor_addSuffix(ReplacementFor_ss,"\x2e\x63",
"\x2e\x68");ReplacementFor_m_modules.insert(std::make_pair(ReplacementFor_ss.str
(),ReplacementFor_level));ReplacementFor_addSuffix(ReplacementFor_ss,
"\x2e\x63\x70\x70","\x2e\x63");ReplacementFor_m_modules.insert(std::make_pair(
ReplacementFor_ss.str(),ReplacementFor_level));ReplacementFor_addSuffix(
ReplacementFor_ss,"\x2e\x63\x63","\x2e\x63\x70\x70");ReplacementFor_m_modules.
insert(std::make_pair(ReplacementFor_ss.str(),ReplacementFor_level));
ReplacementFor_addSuffix(ReplacementFor_ss,"\x2e\x63\x78\x78","\x2e\x63\x63");
ReplacementFor_m_modules.insert(std::make_pair(ReplacementFor_ss.str(),
ReplacementFor_level));ReplacementFor_addSuffix(ReplacementFor_ss,
"\x2e\x2d\x69\x6e\x6c\x2e\x68","\x2e\x63\x78\x78");ReplacementFor_m_modules.
insert(std::make_pair(ReplacementFor_ss.str(),ReplacementFor_level));
ReplacementFor_addSuffix(ReplacementFor_ss,"\x2e\x68\x78\x78",
"\x2e\x2d\x69\x6e\x6c\x2e\x68");ReplacementFor_m_modules.insert(std::make_pair(
ReplacementFor_ss.str(),ReplacementFor_level));ReplacementFor_addSuffix(
ReplacementFor_ss,"\x2e\x68\x70\x70","\x2e\x68\x78\x78");
ReplacementFor_m_modules.insert(std::make_pair(ReplacementFor_ss.str(),
ReplacementFor_level));ReplacementFor_addSuffix(ReplacementFor_ss,"\x2e\x68\x68"
,"\x2e\x68\x70\x70");}ReplacementFor_m_modules.insert(std::make_pair(
ReplacementFor_ss.str(),ReplacementFor_level));};bool ReplacementFor_isMod=true;
bool ReplacementFor_isLevel=false;std::stringstream ReplacementFor_ss;int 
ReplacementFor_level=-(0x604+6453-0x1f38);for(;*ReplacementFor_modules;++
ReplacementFor_modules){switch(*ReplacementFor_modules){case
((char)(0x1787+985-0x1b23)):ReplacementFor_isLevel=true;ReplacementFor_isMod=
false;break;case((char)(0xe63+2990-0x19e5)):ReplacementFor_isLevel=false;
ReplacementFor_isMod=true;if(!ReplacementFor_ss.str().empty()&&
ReplacementFor_level!=-(0xe94+3708-0x1d0f)){insert(ReplacementFor_ss,static_cast
<base::type::ReplacementFor_VerboseLevel>(ReplacementFor_level));
ReplacementFor_ss.str(std::string(""));ReplacementFor_level=-(0x305+8735-0x2523)
;}break;default:if(ReplacementFor_isMod){ReplacementFor_ss<<*
ReplacementFor_modules;}else if(ReplacementFor_isLevel){if(isdigit(*
ReplacementFor_modules)){ReplacementFor_level=static_cast<base::type::
ReplacementFor_VerboseLevel>(*ReplacementFor_modules)-(0x130f+4809-0x25a8);}}
break;}}if(!ReplacementFor_ss.str().empty()&&ReplacementFor_level!=-
(0xcf2+4050-0x1cc3)){insert(ReplacementFor_ss,static_cast<base::type::
ReplacementFor_VerboseLevel>(ReplacementFor_level));}}bool 
ReplacementFor_VRegistry::ReplacementFor_allowed(base::type::
ReplacementFor_VerboseLevel ReplacementFor_vlevel,const char*ReplacementFor_file
){base::ReplacementFor_threading::ReplacementFor_ScopedLock 
ReplacementFor_scopedLock(lock());if(ReplacementFor_m_modules.empty()||
ReplacementFor_file==nullptr){return ReplacementFor_vlevel<=
ReplacementFor_m_level;}else{char ReplacementFor_baseFilename[base::
ReplacementFor_consts::ReplacementFor_kSourceFilenameMaxLength]="";base::
ReplacementFor_utils::File::ReplacementFor_buildBaseFilename(ReplacementFor_file
,ReplacementFor_baseFilename);std::unordered_map<std::string,base::type::
ReplacementFor_VerboseLevel>::iterator ReplacementFor_it=
ReplacementFor_m_modules.begin();for(;ReplacementFor_it!=
ReplacementFor_m_modules.end();++ReplacementFor_it){if(base::
ReplacementFor_utils::Str::ReplacementFor_wildCardMatch(
ReplacementFor_baseFilename,ReplacementFor_it->first.c_str())){return 
ReplacementFor_vlevel<=ReplacementFor_it->second;}}if(base::ReplacementFor_utils
::ReplacementFor_hasFlag(ReplacementFor_LoggingFlag::
ReplacementFor_AllowVerboseIfModuleNotSpecified,*ReplacementFor_m_pFlags)){
return true;}return false;}}void ReplacementFor_VRegistry::
ReplacementFor_setFromArgs(const base::ReplacementFor_utils::
ReplacementFor_CommandLineArgs*ReplacementFor_commandLineArgs){if(
ReplacementFor_commandLineArgs->ReplacementFor_hasParam("\x2d\x76")||
ReplacementFor_commandLineArgs->ReplacementFor_hasParam(
"\x2d\x2d\x76\x65\x72\x62\x6f\x73\x65")||ReplacementFor_commandLineArgs->
ReplacementFor_hasParam("\x2d\x56")||ReplacementFor_commandLineArgs->
ReplacementFor_hasParam("\x2d\x2d\x56\x45\x52\x42\x4f\x53\x45")){
ReplacementFor_setLevel(base::ReplacementFor_consts::
ReplacementFor_kMaxVerboseLevel);}else if(ReplacementFor_commandLineArgs->
ReplacementFor_hasParamWithValue("\x2d\x2d\x76")){ReplacementFor_setLevel(
static_cast<base::type::ReplacementFor_VerboseLevel>(atoi(
ReplacementFor_commandLineArgs->ReplacementFor_getParamValue("\x2d\x2d\x76"))));
}else if(ReplacementFor_commandLineArgs->ReplacementFor_hasParamWithValue(
"\x2d\x2d\x56")){ReplacementFor_setLevel(static_cast<base::type::
ReplacementFor_VerboseLevel>(atoi(ReplacementFor_commandLineArgs->
ReplacementFor_getParamValue("\x2d\x2d\x56"))));}else if((
ReplacementFor_commandLineArgs->ReplacementFor_hasParamWithValue(
"\x2d\x76\x6d\x6f\x64\x75\x6c\x65"))&&ReplacementFor_vModulesEnabled()){
ReplacementFor_setModules(ReplacementFor_commandLineArgs->
ReplacementFor_getParamValue("\x2d\x76\x6d\x6f\x64\x75\x6c\x65"));}else if(
ReplacementFor_commandLineArgs->ReplacementFor_hasParamWithValue(
"\x2d\x56\x4d\x4f\x44\x55\x4c\x45")&&ReplacementFor_vModulesEnabled()){
ReplacementFor_setModules(ReplacementFor_commandLineArgs->
ReplacementFor_getParamValue("\x2d\x56\x4d\x4f\x44\x55\x4c\x45"));}}
#if !defined(ReplacementFor_ELPP_DEFAULT_LOGGING_FLAGS)
#   define ReplacementFor_ELPP_DEFAULT_LOGGING_FLAGS (0x1a6b+2039-0x2262)
#endif 
#if ReplacementFor_ELPP_ASYNC_LOGGING
ReplacementFor_Storage::ReplacementFor_Storage(const 
ReplacementFor_LogBuilderPtr&ReplacementFor_defaultLogBuilder,base::
ReplacementFor_IWorker*ReplacementFor_asyncDispatchWorker):
#else
ReplacementFor_Storage::ReplacementFor_Storage(const 
ReplacementFor_LogBuilderPtr&ReplacementFor_defaultLogBuilder):
#endif  
ReplacementFor_m_registeredHitCounters(new base::
ReplacementFor_RegisteredHitCounters()),ReplacementFor_m_registeredLoggers(new 
base::ReplacementFor_RegisteredLoggers(ReplacementFor_defaultLogBuilder)),
ReplacementFor_m_flags(ReplacementFor_ELPP_DEFAULT_LOGGING_FLAGS),
ReplacementFor_m_vRegistry(new base::ReplacementFor_VRegistry(
(0x8e4+4887-0x1bfb),&ReplacementFor_m_flags)),
#if ReplacementFor_ELPP_ASYNC_LOGGING
ReplacementFor_m_asyncLogQueue(new base::ReplacementFor_AsyncLogQueue()),
ReplacementFor_m_asyncDispatchWorker(ReplacementFor_asyncDispatchWorker),
#endif  
ReplacementFor_m_preRollOutCallback(base::
ReplacementFor_defaultPreRollOutCallback){ReplacementFor_m_registeredLoggers->
get(std::string(base::ReplacementFor_consts::ReplacementFor_kDefaultLoggerId));
ReplacementFor_m_registeredLoggers->get("\x64\x65\x66\x61\x75\x6c\x74");
#if defined(ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ELPP_FEATURE_PERFORMANCE_TRACKING)
ReplacementFor_Logger*ReplacementFor_performanceLogger=
ReplacementFor_m_registeredLoggers->get(std::string(base::ReplacementFor_consts
::ReplacementFor_kPerformanceLoggerId));ReplacementFor_m_registeredLoggers->get(
"\x70\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65");ReplacementFor_performanceLogger
->ReplacementFor_configurations()->ReplacementFor_setGlobally(
ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x25\x6d\x73\x67"
));ReplacementFor_performanceLogger->ReplacementFor_reconfigure();
#endif 
#if defined(ReplacementFor_ELPP_SYSLOG)
ReplacementFor_Logger*ReplacementFor_sysLogLogger=
ReplacementFor_m_registeredLoggers->get(std::string(base::ReplacementFor_consts
::ReplacementFor_kSysLogLoggerId));ReplacementFor_sysLogLogger->
ReplacementFor_configurations()->ReplacementFor_setGlobally(
ReplacementFor_ConfigurationType::Format,std::string(
"\x25\x6c\x65\x76\x65\x6c\x3a\x20\x25\x6d\x73\x67"));ReplacementFor_sysLogLogger
->ReplacementFor_reconfigure();
#endif 
ReplacementFor_addFlag(ReplacementFor_LoggingFlag::
ReplacementFor_AllowVerboseIfModuleNotSpecified);
#if ReplacementFor_ELPP_ASYNC_LOGGING
ReplacementFor_installLogDispatchCallback<base::
ReplacementFor_AsyncLogDispatchCallback>(std::string(
"\x41\x73\x79\x6e\x63\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));
#else
ReplacementFor_installLogDispatchCallback<base::
ReplacementFor_DefaultLogDispatchCallback>(std::string(
"\x44\x65\x66\x61\x75\x6c\x74\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));
#endif  
#if defined(ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ELPP_FEATURE_PERFORMANCE_TRACKING)
ReplacementFor_installPerformanceTrackingCallback<base::
ReplacementFor_DefaultPerformanceTrackingCallback>(std::string(
"\x44\x65\x66\x61\x75\x6c\x74\x50\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65\x54\x72\x61\x63\x6b\x69\x6e\x67\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));
#endif 
ReplacementFor_ELPP_INTERNAL_INFO((0x2301+385-0x2481),
"\x45\x61\x73\x79\x6c\x6f\x67\x67\x69\x6e\x67\x2b\x2b\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64"
);
#if ReplacementFor_ELPP_ASYNC_LOGGING
ReplacementFor_m_asyncDispatchWorker->ReplacementFor_start();
#endif  
}ReplacementFor_Storage::~ReplacementFor_Storage(void){
ReplacementFor_ELPP_INTERNAL_INFO((0x129d+1782-0x198f),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x73\x74\x6f\x72\x61\x67\x65");
#if ReplacementFor_ELPP_ASYNC_LOGGING
ReplacementFor_ELPP_INTERNAL_INFO((0x23a2+84-0x23f1),
"\x52\x65\x70\x6c\x61\x63\x69\x6e\x67\x20\x6c\x6f\x67\x20\x64\x69\x73\x70\x61\x74\x63\x68\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x74\x6f\x20\x73\x79\x6e\x63\x68\x72\x6f\x6e\x6f\x75\x73"
);ReplacementFor_uninstallLogDispatchCallback<base::
ReplacementFor_AsyncLogDispatchCallback>(std::string(
"\x41\x73\x79\x6e\x63\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));ReplacementFor_installLogDispatchCallback<base::
ReplacementFor_DefaultLogDispatchCallback>(std::string(
"\x44\x65\x66\x61\x75\x6c\x74\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));ReplacementFor_ELPP_INTERNAL_INFO((0x720+5014-0x1ab1),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x61\x73\x79\x6e\x63\x44\x69\x73\x70\x61\x74\x63\x68\x57\x6f\x72\x6b\x65\x72"
);base::ReplacementFor_utils::ReplacementFor_safeDelete(
ReplacementFor_m_asyncDispatchWorker);ReplacementFor_ELPP_INTERNAL_INFO(
(0x73b+1762-0xe18),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x61\x73\x79\x6e\x63\x4c\x6f\x67\x51\x75\x65\x75\x65"
);base::ReplacementFor_utils::ReplacementFor_safeDelete(
ReplacementFor_m_asyncLogQueue);
#endif  
ReplacementFor_ELPP_INTERNAL_INFO((0xc7b+2521-0x164f),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x48\x69\x74\x43\x6f\x75\x6e\x74\x65\x72\x73"
);base::ReplacementFor_utils::ReplacementFor_safeDelete(
ReplacementFor_m_registeredHitCounters);ReplacementFor_ELPP_INTERNAL_INFO(
(0x452+6603-0x1e18),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x4c\x6f\x67\x67\x65\x72\x73"
);base::ReplacementFor_utils::ReplacementFor_safeDelete(
ReplacementFor_m_registeredLoggers);ReplacementFor_ELPP_INTERNAL_INFO(
(0x1f6+7249-0x1e42),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x76\x52\x65\x67\x69\x73\x74\x72\x79"
);base::ReplacementFor_utils::ReplacementFor_safeDelete(
ReplacementFor_m_vRegistry);}bool ReplacementFor_Storage::
ReplacementFor_hasCustomFormatSpecifier(const char*
ReplacementFor_formatSpecifier){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(
ReplacementFor_customFormatSpecifiersLock());return std::find(
ReplacementFor_m_customFormatSpecifiers.begin(),
ReplacementFor_m_customFormatSpecifiers.end(),ReplacementFor_formatSpecifier)!=
ReplacementFor_m_customFormatSpecifiers.end();}void ReplacementFor_Storage::
ReplacementFor_installCustomFormatSpecifier(const 
ReplacementFor_CustomFormatSpecifier&ReplacementFor_customFormatSpecifier){if(
ReplacementFor_hasCustomFormatSpecifier(ReplacementFor_customFormatSpecifier.
ReplacementFor_formatSpecifier())){return;}base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(
ReplacementFor_customFormatSpecifiersLock());
ReplacementFor_m_customFormatSpecifiers.push_back(
ReplacementFor_customFormatSpecifier);}bool ReplacementFor_Storage::
ReplacementFor_uninstallCustomFormatSpecifier(const char*
ReplacementFor_formatSpecifier){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(
ReplacementFor_customFormatSpecifiersLock());std::vector<
ReplacementFor_CustomFormatSpecifier>::iterator ReplacementFor_it=std::find(
ReplacementFor_m_customFormatSpecifiers.begin(),
ReplacementFor_m_customFormatSpecifiers.end(),ReplacementFor_formatSpecifier);if
(ReplacementFor_it!=ReplacementFor_m_customFormatSpecifiers.end()&&strcmp(
ReplacementFor_formatSpecifier,ReplacementFor_it->ReplacementFor_formatSpecifier
())==(0x519+2331-0xe34)){ReplacementFor_m_customFormatSpecifiers.erase(
ReplacementFor_it);return true;}return false;}void ReplacementFor_Storage::
ReplacementFor_setApplicationArguments(int ReplacementFor_argc,char**
ReplacementFor_argv){ReplacementFor_m_commandLineArgs.ReplacementFor_setArgs(
ReplacementFor_argc,ReplacementFor_argv);ReplacementFor_m_vRegistry->
ReplacementFor_setFromArgs(ReplacementFor_commandLineArgs());
#if !defined(ReplacementFor_ELPP_DISABLE_LOG_FILE_FROM_ARG)
if(ReplacementFor_m_commandLineArgs.ReplacementFor_hasParamWithValue(base::
ReplacementFor_consts::ReplacementFor_kDefaultLogFileParam)){
ReplacementFor_Configurations c;c.ReplacementFor_setGlobally(
ReplacementFor_ConfigurationType::ReplacementFor_Filename,std::string(
ReplacementFor_m_commandLineArgs.ReplacementFor_getParamValue(base::
ReplacementFor_consts::ReplacementFor_kDefaultLogFileParam)));
ReplacementFor_registeredLoggers()->ReplacementFor_setDefaultConfigurations(c);
for(base::ReplacementFor_RegisteredLoggers::iterator ReplacementFor_it=
ReplacementFor_registeredLoggers()->begin();ReplacementFor_it!=
ReplacementFor_registeredLoggers()->end();++ReplacementFor_it){ReplacementFor_it
->second->ReplacementFor_configure(c);}}
#endif  
#if defined(ReplacementFor_ELPP_LOGGING_FLAGS_FROM_ARG)
if(ReplacementFor_m_commandLineArgs.ReplacementFor_hasParamWithValue(base::
ReplacementFor_consts::ReplacementFor_kLoggingFlagsParam)){int 
ReplacementFor_userInput=atoi(ReplacementFor_m_commandLineArgs.
ReplacementFor_getParamValue(base::ReplacementFor_consts::
ReplacementFor_kLoggingFlagsParam));if(ReplacementFor_ELPP_DEFAULT_LOGGING_FLAGS
==(0x10f+1314-0x631)){ReplacementFor_m_flags=ReplacementFor_userInput;}else{base
::ReplacementFor_utils::ReplacementFor_addFlag<base::type::
ReplacementFor_EnumType>(ReplacementFor_userInput,&ReplacementFor_m_flags);}}
#endif  
}}void ReplacementFor_LogDispatchCallback::ReplacementFor_handle(const 
ReplacementFor_LogDispatchData*data){
#if defined(ReplacementFor_ELPP_THREAD_SAFE)
base::ReplacementFor_threading::ReplacementFor_ScopedLock 
ReplacementFor_scopedLock(ReplacementFor_m_fileLocksMapLock);std::string 
ReplacementFor_filename=data->ReplacementFor_logMessage()->ReplacementFor_logger
()->ReplacementFor_typedConfigurations()->ReplacementFor_filename(data->
ReplacementFor_logMessage()->ReplacementFor_level());auto lock=
ReplacementFor_m_fileLocks.find(ReplacementFor_filename);if(lock==
ReplacementFor_m_fileLocks.end()){ReplacementFor_m_fileLocks.emplace(std::
make_pair(ReplacementFor_filename,std::unique_ptr<base::ReplacementFor_threading
::Mutex>(new base::ReplacementFor_threading::Mutex)));}
#endif
}base::ReplacementFor_threading::Mutex&ReplacementFor_LogDispatchCallback::
ReplacementFor_fileHandle(const ReplacementFor_LogDispatchData*data){auto 
ReplacementFor_it=ReplacementFor_m_fileLocks.find(data->
ReplacementFor_logMessage()->ReplacementFor_logger()->
ReplacementFor_typedConfigurations()->ReplacementFor_filename(data->
ReplacementFor_logMessage()->ReplacementFor_level()));return*(ReplacementFor_it
->second.get());}namespace base{void ReplacementFor_DefaultLogDispatchCallback::
ReplacementFor_handle(const ReplacementFor_LogDispatchData*data){
#if defined(ReplacementFor_ELPP_THREAD_SAFE)
ReplacementFor_LogDispatchCallback::ReplacementFor_handle(data);base::
ReplacementFor_threading::ReplacementFor_ScopedLock ReplacementFor_scopedLock(
ReplacementFor_fileHandle(data));
#endif
ReplacementFor_m_data=data;ReplacementFor_dispatch(ReplacementFor_m_data->
ReplacementFor_logMessage()->ReplacementFor_logger()->ReplacementFor_logBuilder(
)->ReplacementFor_build(ReplacementFor_m_data->ReplacementFor_logMessage(),
ReplacementFor_m_data->ReplacementFor_dispatchAction()==base::
ReplacementFor_DispatchAction::ReplacementFor_NormalLog));}void 
ReplacementFor_DefaultLogDispatchCallback::ReplacementFor_dispatch(base::type::
ReplacementFor_string_t&&ReplacementFor_logLine){if(ReplacementFor_m_data->
ReplacementFor_dispatchAction()==base::ReplacementFor_DispatchAction::
ReplacementFor_NormalLog){if(ReplacementFor_m_data->ReplacementFor_logMessage()
->ReplacementFor_logger()->ReplacementFor_m_typedConfigurations->
ReplacementFor_toFile(ReplacementFor_m_data->ReplacementFor_logMessage()->
ReplacementFor_level())){base::type::ReplacementFor_fstream_t*fs=
ReplacementFor_m_data->ReplacementFor_logMessage()->ReplacementFor_logger()->
ReplacementFor_m_typedConfigurations->ReplacementFor_fileStream(
ReplacementFor_m_data->ReplacementFor_logMessage()->ReplacementFor_level());if(
fs!=nullptr){fs->write(ReplacementFor_logLine.c_str(),ReplacementFor_logLine.
size());if(fs->fail()){ReplacementFor_ELPP_INTERNAL_ERROR(
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x6c\x6f\x67\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x5b"
<<ReplacementFor_m_data->ReplacementFor_logMessage()->ReplacementFor_logger()->
ReplacementFor_m_typedConfigurations->ReplacementFor_filename(
ReplacementFor_m_data->ReplacementFor_logMessage()->ReplacementFor_level())<<
"\x5d\x2e" "\n"<<
"\x46\x65\x77\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x72\x65\x61\x73\x6f\x6e\x73\x20\x28\x63\x6f\x75\x6c\x64\x20\x62\x65\x20\x73\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x65\x6c\x73\x65\x29\x3a" "\n"
<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x20\x64\x65\x6e\x69\x65\x64" "\n"
<<"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x66\x75\x6c\x6c" "\n"<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x69\x73\x20\x6e\x6f\x74\x20\x77\x72\x69\x74\x61\x62\x6c\x65"
,true);}else{if(ReplacementFor_ELPP->ReplacementFor_hasFlag(
ReplacementFor_LoggingFlag::ReplacementFor_ImmediateFlush)||(
ReplacementFor_m_data->ReplacementFor_logMessage()->ReplacementFor_logger()->
ReplacementFor_isFlushNeeded(ReplacementFor_m_data->ReplacementFor_logMessage()
->ReplacementFor_level()))){ReplacementFor_m_data->ReplacementFor_logMessage()->
ReplacementFor_logger()->flush(ReplacementFor_m_data->ReplacementFor_logMessage(
)->ReplacementFor_level(),fs);}}}else{ReplacementFor_ELPP_INTERNAL_ERROR(
"\x4c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x5b"<<
ReplacementFor_LevelHelper::ReplacementFor_convertToString(ReplacementFor_m_data
->ReplacementFor_logMessage()->ReplacementFor_level())<<"\x5d\x20"<<
"\x68\x61\x73\x20\x6e\x6f\x74\x20\x62\x65\x65\x6e\x20\x63\x6f\x6e\x66\x20\x62\x75\x74\x20\x5b\x54\x4f\x5f\x46\x49\x4c\x45\x5d\x20\x69\x73\x20\x63\x6f\x6e\x66\x64\x20\x74\x6f\x20\x54\x52\x55\x45\x2e\x20\x5b\x4c\x6f\x67\x67\x65\x72\x20\x49\x44\x3a\x20"
<<ReplacementFor_m_data->ReplacementFor_logMessage()->ReplacementFor_logger()->
id()<<"\x5d",false);}}if(ReplacementFor_m_data->ReplacementFor_logMessage()->
ReplacementFor_logger()->ReplacementFor_m_typedConfigurations->
ReplacementFor_toStandardOutput(ReplacementFor_m_data->ReplacementFor_logMessage
()->ReplacementFor_level())){if(ReplacementFor_ELPP->ReplacementFor_hasFlag(
ReplacementFor_LoggingFlag::ReplacementFor_ColoredTerminalOutput))
ReplacementFor_m_data->ReplacementFor_logMessage()->ReplacementFor_logger()->
ReplacementFor_logBuilder()->ReplacementFor_convertToColoredOutput(&
ReplacementFor_logLine,ReplacementFor_m_data->ReplacementFor_logMessage()->
ReplacementFor_level());ReplacementFor_ELPP_COUT<<ReplacementFor_ELPP_COUT_LINE(
ReplacementFor_logLine);}}
#if defined(ReplacementFor_ELPP_SYSLOG)
else if(ReplacementFor_m_data->ReplacementFor_dispatchAction()==base::
ReplacementFor_DispatchAction::SysLog){int ReplacementFor_sysLogPriority=
(0x7ba+7561-0x2543);if(ReplacementFor_m_data->ReplacementFor_logMessage()->
ReplacementFor_level()==Level::ReplacementFor_Fatal)
ReplacementFor_sysLogPriority=LOG_EMERG;else if(ReplacementFor_m_data->
ReplacementFor_logMessage()->ReplacementFor_level()==Level::Error)
ReplacementFor_sysLogPriority=LOG_ERR;else if(ReplacementFor_m_data->
ReplacementFor_logMessage()->ReplacementFor_level()==Level::
ReplacementFor_Warning)ReplacementFor_sysLogPriority=LOG_WARNING;else if(
ReplacementFor_m_data->ReplacementFor_logMessage()->ReplacementFor_level()==
Level::ReplacementFor_Info)ReplacementFor_sysLogPriority=LOG_INFO;else if(
ReplacementFor_m_data->ReplacementFor_logMessage()->ReplacementFor_level()==
Level::ReplacementFor_Debug)ReplacementFor_sysLogPriority=LOG_DEBUG;else 
ReplacementFor_sysLogPriority=LOG_NOTICE;
#  if defined(ReplacementFor_ELPP_UNICODE)
char*line=base::ReplacementFor_utils::Str::ReplacementFor_wcharPtrToCharPtr(
ReplacementFor_logLine.c_str());syslog(ReplacementFor_sysLogPriority,"\x25\x73",
line);free(line);
#  else
syslog(ReplacementFor_sysLogPriority,"\x25\x73",ReplacementFor_logLine.c_str());
#  endif
}
#endif  
}
#if ReplacementFor_ELPP_ASYNC_LOGGING
void ReplacementFor_AsyncLogDispatchCallback::ReplacementFor_handle(const 
ReplacementFor_LogDispatchData*data){base::type::ReplacementFor_string_t 
ReplacementFor_logLine=data->ReplacementFor_logMessage()->ReplacementFor_logger(
)->ReplacementFor_logBuilder()->ReplacementFor_build(data->
ReplacementFor_logMessage(),data->ReplacementFor_dispatchAction()==base::
ReplacementFor_DispatchAction::ReplacementFor_NormalLog);if(data->
ReplacementFor_dispatchAction()==base::ReplacementFor_DispatchAction::
ReplacementFor_NormalLog&&data->ReplacementFor_logMessage()->
ReplacementFor_logger()->ReplacementFor_typedConfigurations()->
ReplacementFor_toStandardOutput(data->ReplacementFor_logMessage()->
ReplacementFor_level())){if(ReplacementFor_ELPP->ReplacementFor_hasFlag(
ReplacementFor_LoggingFlag::ReplacementFor_ColoredTerminalOutput))data->
ReplacementFor_logMessage()->ReplacementFor_logger()->ReplacementFor_logBuilder(
)->ReplacementFor_convertToColoredOutput(&ReplacementFor_logLine,data->
ReplacementFor_logMessage()->ReplacementFor_level());ReplacementFor_ELPP_COUT<<
ReplacementFor_ELPP_COUT_LINE(ReplacementFor_logLine);}if(data->
ReplacementFor_logMessage()->ReplacementFor_logger()->
ReplacementFor_typedConfigurations()->ReplacementFor_toFile(data->
ReplacementFor_logMessage()->ReplacementFor_level())){ReplacementFor_ELPP->
ReplacementFor_asyncLogQueue()->push(ReplacementFor_AsyncLogItem(*(data->
ReplacementFor_logMessage()),*data,ReplacementFor_logLine));}}
ReplacementFor_AsyncDispatchWorker::ReplacementFor_AsyncDispatchWorker(){
ReplacementFor_setContinueRunning(false);}ReplacementFor_AsyncDispatchWorker::~
ReplacementFor_AsyncDispatchWorker(){ReplacementFor_setContinueRunning(false);
ReplacementFor_ELPP_INTERNAL_INFO((0x104+4429-0x124b),
"\x53\x74\x6f\x70\x70\x69\x6e\x67\x20\x64\x69\x73\x70\x61\x74\x63\x68\x20\x77\x6f\x72\x6b\x65\x72\x20\x2d\x20\x43\x6c\x65\x61\x6e\x69\x6e\x67\x20\x6c\x6f\x67\x20\x71\x75\x65\x75\x65"
);ReplacementFor_clean();ReplacementFor_ELPP_INTERNAL_INFO((0x21c+9300-0x266a),
"\x4c\x6f\x67\x20\x71\x75\x65\x75\x65\x20\x63\x6c\x65\x61\x6e\x65\x64");}bool 
ReplacementFor_AsyncDispatchWorker::ReplacementFor_clean(void){std::mutex m;std
::unique_lock<std::mutex>ReplacementFor_lk(m);ReplacementFor_cv.wait(
ReplacementFor_lk,[]{return!ReplacementFor_ELPP->ReplacementFor_asyncLogQueue()
->empty();});ReplacementFor_emptyQueue();ReplacementFor_lk.unlock();
ReplacementFor_cv.notify_one();return ReplacementFor_ELPP->
ReplacementFor_asyncLogQueue()->empty();}void ReplacementFor_AsyncDispatchWorker
::ReplacementFor_emptyQueue(void){while(!ReplacementFor_ELPP->
ReplacementFor_asyncLogQueue()->empty()){ReplacementFor_AsyncLogItem data=
ReplacementFor_ELPP->ReplacementFor_asyncLogQueue()->next();
ReplacementFor_handle(&data);base::ReplacementFor_threading::
ReplacementFor_msleep((0xe4a+2405-0x174b));}}void 
ReplacementFor_AsyncDispatchWorker::ReplacementFor_start(void){base::
ReplacementFor_threading::ReplacementFor_msleep((0x1aeb+5772-0x1def));
ReplacementFor_setContinueRunning(true);std::thread ReplacementFor_t1(&
ReplacementFor_AsyncDispatchWorker::ReplacementFor_run,this);ReplacementFor_t1.
join();}void ReplacementFor_AsyncDispatchWorker::ReplacementFor_handle(
ReplacementFor_AsyncLogItem*ReplacementFor_logItem){
ReplacementFor_LogDispatchData*data=ReplacementFor_logItem->data();
ReplacementFor_LogMessage*ReplacementFor_logMessage=ReplacementFor_logItem->
ReplacementFor_logMessage();ReplacementFor_Logger*ReplacementFor_logger=
ReplacementFor_logMessage->ReplacementFor_logger();base::
ReplacementFor_TypedConfigurations*ReplacementFor_conf=ReplacementFor_logger->
ReplacementFor_typedConfigurations();base::type::ReplacementFor_string_t 
ReplacementFor_logLine=ReplacementFor_logItem->ReplacementFor_logLine();if(data
->ReplacementFor_dispatchAction()==base::ReplacementFor_DispatchAction::
ReplacementFor_NormalLog){if(ReplacementFor_conf->ReplacementFor_toFile(
ReplacementFor_logMessage->ReplacementFor_level())){base::type::
ReplacementFor_fstream_t*fs=ReplacementFor_conf->ReplacementFor_fileStream(
ReplacementFor_logMessage->ReplacementFor_level());if(fs!=nullptr){fs->write(
ReplacementFor_logLine.c_str(),ReplacementFor_logLine.size());if(fs->fail()){
ReplacementFor_ELPP_INTERNAL_ERROR(
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x6c\x6f\x67\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x5b"
<<ReplacementFor_conf->ReplacementFor_filename(ReplacementFor_logMessage->
ReplacementFor_level())<<"\x5d\x2e" "\n"<<
"\x46\x65\x77\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x72\x65\x61\x73\x6f\x6e\x73\x20\x28\x63\x6f\x75\x6c\x64\x20\x62\x65\x20\x73\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x65\x6c\x73\x65\x29\x3a" "\n"
<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x20\x64\x65\x6e\x69\x65\x64" "\n"
<<"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x66\x75\x6c\x6c" "\n"<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x69\x73\x20\x6e\x6f\x74\x20\x77\x72\x69\x74\x61\x62\x6c\x65"
,true);}else{if(ReplacementFor_ELPP->ReplacementFor_hasFlag(
ReplacementFor_LoggingFlag::ReplacementFor_ImmediateFlush)||(
ReplacementFor_logger->ReplacementFor_isFlushNeeded(ReplacementFor_logMessage->
ReplacementFor_level()))){ReplacementFor_logger->flush(ReplacementFor_logMessage
->ReplacementFor_level(),fs);}}}else{ReplacementFor_ELPP_INTERNAL_ERROR(
"\x4c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x5b"<<
ReplacementFor_LevelHelper::ReplacementFor_convertToString(
ReplacementFor_logMessage->ReplacementFor_level())<<"\x5d\x20"<<
"\x68\x61\x73\x20\x6e\x6f\x74\x20\x62\x65\x65\x6e\x20\x63\x6f\x6e\x66\x20\x62\x75\x74\x20\x5b\x54\x4f\x5f\x46\x49\x4c\x45\x5d\x20\x69\x73\x20\x63\x6f\x6e\x66\x64\x20\x74\x6f\x20\x54\x52\x55\x45\x2e\x20\x5b\x4c\x6f\x67\x67\x65\x72\x20\x49\x44\x3a\x20"
<<ReplacementFor_logger->id()<<"\x5d",false);}}}
#  if defined(ReplacementFor_ELPP_SYSLOG)
else if(data->ReplacementFor_dispatchAction()==base::
ReplacementFor_DispatchAction::SysLog){int ReplacementFor_sysLogPriority=
(0x1eab+163-0x1f4e);if(ReplacementFor_logMessage->ReplacementFor_level()==Level
::ReplacementFor_Fatal)ReplacementFor_sysLogPriority=LOG_EMERG;else if(
ReplacementFor_logMessage->ReplacementFor_level()==Level::Error)
ReplacementFor_sysLogPriority=LOG_ERR;else if(ReplacementFor_logMessage->
ReplacementFor_level()==Level::ReplacementFor_Warning)
ReplacementFor_sysLogPriority=LOG_WARNING;else if(ReplacementFor_logMessage->
ReplacementFor_level()==Level::ReplacementFor_Info)ReplacementFor_sysLogPriority
=LOG_INFO;else if(ReplacementFor_logMessage->ReplacementFor_level()==Level::
ReplacementFor_Debug)ReplacementFor_sysLogPriority=LOG_DEBUG;else 
ReplacementFor_sysLogPriority=LOG_NOTICE;
#      if defined(ReplacementFor_ELPP_UNICODE)
char*line=base::ReplacementFor_utils::Str::ReplacementFor_wcharPtrToCharPtr(
ReplacementFor_logLine.c_str());syslog(ReplacementFor_sysLogPriority,"\x25\x73",
line);free(line);
#      else
syslog(ReplacementFor_sysLogPriority,"\x25\x73",ReplacementFor_logLine.c_str());
#      endif
}
#  endif  
}void ReplacementFor_AsyncDispatchWorker::ReplacementFor_run(void){while(
ReplacementFor_continueRunning()){ReplacementFor_emptyQueue();base::
ReplacementFor_threading::ReplacementFor_msleep((0x12f4+1134-0x1758));}}
#endif  
base::type::ReplacementFor_string_t ReplacementFor_DefaultLogBuilder::
ReplacementFor_build(const ReplacementFor_LogMessage*ReplacementFor_logMessage,
bool ReplacementFor_appendNewLine)const{base::ReplacementFor_TypedConfigurations
*tc=ReplacementFor_logMessage->ReplacementFor_logger()->
ReplacementFor_typedConfigurations();const base::ReplacementFor_LogFormat*
ReplacementFor_logFormat=&tc->ReplacementFor_logFormat(ReplacementFor_logMessage
->ReplacementFor_level());base::type::ReplacementFor_string_t 
ReplacementFor_logLine=ReplacementFor_logFormat->format();char 
ReplacementFor_buff[base::ReplacementFor_consts::
ReplacementFor_kSourceFilenameMaxLength+base::ReplacementFor_consts::
ReplacementFor_kSourceLineMaxLength]="";const char*ReplacementFor_bufLim=
ReplacementFor_buff+sizeof(ReplacementFor_buff);if(ReplacementFor_logFormat->
ReplacementFor_hasFlag(base::ReplacementFor_FormatFlags::ReplacementFor_AppName)
){base::ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_logLine,base::ReplacementFor_consts::
ReplacementFor_kAppNameFormatSpecifier,ReplacementFor_logMessage->
ReplacementFor_logger()->ReplacementFor_parentApplicationName());}if(
ReplacementFor_logFormat->ReplacementFor_hasFlag(base::
ReplacementFor_FormatFlags::ReplacementFor_ThreadId)){base::ReplacementFor_utils
::Str::ReplacementFor_replaceFirstWithEscape(ReplacementFor_logLine,base::
ReplacementFor_consts::ReplacementFor_kThreadIdFormatSpecifier,
ReplacementFor_ELPP->ReplacementFor_getThreadName(base::ReplacementFor_threading
::ReplacementFor_getCurrentThreadId()));}if(ReplacementFor_logFormat->
ReplacementFor_hasFlag(base::ReplacementFor_FormatFlags::ReplacementFor_DateTime
)){base::ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_logLine,base::ReplacementFor_consts::
ReplacementFor_kDateTimeFormatSpecifier,base::ReplacementFor_utils::
ReplacementFor_DateTime::ReplacementFor_getDateTime(ReplacementFor_logFormat->
ReplacementFor_dateTimeFormat().c_str(),&tc->ReplacementFor_subsecondPrecision(
ReplacementFor_logMessage->ReplacementFor_level())));}if(
ReplacementFor_logFormat->ReplacementFor_hasFlag(base::
ReplacementFor_FormatFlags::Function)){base::ReplacementFor_utils::Str::
ReplacementFor_replaceFirstWithEscape(ReplacementFor_logLine,base::
ReplacementFor_consts::ReplacementFor_kLogFunctionFormatSpecifier,
ReplacementFor_logMessage->ReplacementFor_func());}if(ReplacementFor_logFormat->
ReplacementFor_hasFlag(base::ReplacementFor_FormatFlags::File)){base::
ReplacementFor_utils::Str::ReplacementFor_clearBuff(ReplacementFor_buff,base::
ReplacementFor_consts::ReplacementFor_kSourceFilenameMaxLength);base::
ReplacementFor_utils::File::ReplacementFor_buildStrippedFilename(
ReplacementFor_logMessage->ReplacementFor_file().c_str(),ReplacementFor_buff);
base::ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_logLine,base::ReplacementFor_consts::
ReplacementFor_kLogFileFormatSpecifier,std::string(ReplacementFor_buff));}if(
ReplacementFor_logFormat->ReplacementFor_hasFlag(base::
ReplacementFor_FormatFlags::ReplacementFor_FileBase)){base::ReplacementFor_utils
::Str::ReplacementFor_clearBuff(ReplacementFor_buff,base::ReplacementFor_consts
::ReplacementFor_kSourceFilenameMaxLength);base::ReplacementFor_utils::File::
ReplacementFor_buildBaseFilename(ReplacementFor_logMessage->ReplacementFor_file(
),ReplacementFor_buff);base::ReplacementFor_utils::Str::
ReplacementFor_replaceFirstWithEscape(ReplacementFor_logLine,base::
ReplacementFor_consts::ReplacementFor_kLogFileBaseFormatSpecifier,std::string(
ReplacementFor_buff));}if(ReplacementFor_logFormat->ReplacementFor_hasFlag(base
::ReplacementFor_FormatFlags::Line)){char*buf=base::ReplacementFor_utils::Str::
ReplacementFor_clearBuff(ReplacementFor_buff,base::ReplacementFor_consts::
ReplacementFor_kSourceLineMaxLength);buf=base::ReplacementFor_utils::Str::
ReplacementFor_convertAndAddToBuff(ReplacementFor_logMessage->line(),base::
ReplacementFor_consts::ReplacementFor_kSourceLineMaxLength,buf,
ReplacementFor_bufLim,false);base::ReplacementFor_utils::Str::
ReplacementFor_replaceFirstWithEscape(ReplacementFor_logLine,base::
ReplacementFor_consts::ReplacementFor_kLogLineFormatSpecifier,std::string(
ReplacementFor_buff));}if(ReplacementFor_logFormat->ReplacementFor_hasFlag(base
::ReplacementFor_FormatFlags::ReplacementFor_Location)){char*buf=base::
ReplacementFor_utils::Str::ReplacementFor_clearBuff(ReplacementFor_buff,base::
ReplacementFor_consts::ReplacementFor_kSourceFilenameMaxLength+base::
ReplacementFor_consts::ReplacementFor_kSourceLineMaxLength);base::
ReplacementFor_utils::File::ReplacementFor_buildStrippedFilename(
ReplacementFor_logMessage->ReplacementFor_file().c_str(),ReplacementFor_buff);
buf=base::ReplacementFor_utils::Str::ReplacementFor_addToBuff(
ReplacementFor_buff,buf,ReplacementFor_bufLim);buf=base::ReplacementFor_utils::
Str::ReplacementFor_addToBuff("\x3a",buf,ReplacementFor_bufLim);buf=base::
ReplacementFor_utils::Str::ReplacementFor_convertAndAddToBuff(
ReplacementFor_logMessage->line(),base::ReplacementFor_consts::
ReplacementFor_kSourceLineMaxLength,buf,ReplacementFor_bufLim,false);base::
ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_logLine,base::ReplacementFor_consts::
ReplacementFor_kLogLocationFormatSpecifier,std::string(ReplacementFor_buff));}if
(ReplacementFor_logMessage->ReplacementFor_level()==Level::
ReplacementFor_Verbose&&ReplacementFor_logFormat->ReplacementFor_hasFlag(base::
ReplacementFor_FormatFlags::ReplacementFor_VerboseLevel)){char*buf=base::
ReplacementFor_utils::Str::ReplacementFor_clearBuff(ReplacementFor_buff,
(0x1907+1763-0x1fe9));buf=base::ReplacementFor_utils::Str::
ReplacementFor_convertAndAddToBuff(ReplacementFor_logMessage->
ReplacementFor_verboseLevel(),(0x13dd+3562-0x21c6),buf,ReplacementFor_bufLim,
false);base::ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_logLine,base::ReplacementFor_consts::
ReplacementFor_kVerboseLevelFormatSpecifier,std::string(ReplacementFor_buff));}
if(ReplacementFor_logFormat->ReplacementFor_hasFlag(base::
ReplacementFor_FormatFlags::ReplacementFor_LogMessage)){base::
ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_logLine,base::ReplacementFor_consts::
ReplacementFor_kMessageFormatSpecifier,ReplacementFor_logMessage->message());}
#if !defined(ReplacementFor_ELPP_DISABLE_CUSTOM_FORMAT_SPECIFIERS)
ReplacementFor_el::base::ReplacementFor_threading::ReplacementFor_ScopedLock 
ReplacementFor_lock_(ReplacementFor_ELPP->
ReplacementFor_customFormatSpecifiersLock());ReplacementFor_ELPP_UNUSED(
ReplacementFor_lock_);for(std::vector<ReplacementFor_CustomFormatSpecifier>::
const_iterator ReplacementFor_it=ReplacementFor_ELPP->
ReplacementFor_customFormatSpecifiers()->begin();ReplacementFor_it!=
ReplacementFor_ELPP->ReplacementFor_customFormatSpecifiers()->end();++
ReplacementFor_it){std::string fs(ReplacementFor_it->
ReplacementFor_formatSpecifier());base::type::ReplacementFor_string_t 
ReplacementFor_wcsFormatSpecifier(fs.begin(),fs.end());base::
ReplacementFor_utils::Str::ReplacementFor_replaceFirstWithEscape(
ReplacementFor_logLine,ReplacementFor_wcsFormatSpecifier,ReplacementFor_it->
ReplacementFor_resolver()(ReplacementFor_logMessage));}
#endif  
if(ReplacementFor_appendNewLine)ReplacementFor_logLine+=
ReplacementFor_ELPP_LITERAL("\n");return ReplacementFor_logLine;}void 
ReplacementFor_LogDispatcher::ReplacementFor_dispatch(void){if(
ReplacementFor_m_proceed&&ReplacementFor_m_dispatchAction==base::
ReplacementFor_DispatchAction::None){ReplacementFor_m_proceed=false;}if(!
ReplacementFor_m_proceed){return;}
#ifndef ReplacementFor_ELPP_NO_GLOBAL_LOCK
base::ReplacementFor_threading::ReplacementFor_ScopedLock 
ReplacementFor_scopedLock(ReplacementFor_ELPP->lock());
#endif
base::ReplacementFor_TypedConfigurations*tc=ReplacementFor_m_logMessage->
ReplacementFor_logger()->ReplacementFor_m_typedConfigurations;if(
ReplacementFor_ELPP->ReplacementFor_hasFlag(ReplacementFor_LoggingFlag::
ReplacementFor_StrictLogFileSizeCheck)){tc->ReplacementFor_validateFileRolling(
ReplacementFor_m_logMessage->ReplacementFor_level(),ReplacementFor_ELPP->
ReplacementFor_preRollOutCallback());}ReplacementFor_LogDispatchCallback*
ReplacementFor_callback=nullptr;ReplacementFor_LogDispatchData data;for(const 
std::pair<std::string,base::type::ReplacementFor_LogDispatchCallbackPtr>&
ReplacementFor_h:ReplacementFor_ELPP->ReplacementFor_m_logDispatchCallbacks){
ReplacementFor_callback=ReplacementFor_h.second.get();if(ReplacementFor_callback
!=nullptr&&ReplacementFor_callback->ReplacementFor_enabled()){data.
ReplacementFor_setLogMessage(ReplacementFor_m_logMessage);data.
ReplacementFor_setDispatchAction(ReplacementFor_m_dispatchAction);
ReplacementFor_callback->ReplacementFor_handle(&data);}}}void 
ReplacementFor_MessageBuilder::ReplacementFor_initialize(ReplacementFor_Logger*
ReplacementFor_logger){ReplacementFor_m_logger=ReplacementFor_logger;
ReplacementFor_m_containerLogSeperator=ReplacementFor_ELPP->
ReplacementFor_hasFlag(ReplacementFor_LoggingFlag::
ReplacementFor_NewLineForContainer)?ReplacementFor_ELPP_LITERAL(
"\n" "\x20\x20\x20\x20"):ReplacementFor_ELPP_LITERAL("\x2c\x20");}
ReplacementFor_MessageBuilder&ReplacementFor_MessageBuilder::operator<<(const 
wchar_t*msg){if(msg==nullptr){ReplacementFor_m_logger->ReplacementFor_stream()<<
base::ReplacementFor_consts::ReplacementFor_kNullPointer;return*this;}
#  if defined(ReplacementFor_ELPP_UNICODE)
ReplacementFor_m_logger->ReplacementFor_stream()<<msg;
#  else
char*ReplacementFor_buff_=base::ReplacementFor_utils::Str::
ReplacementFor_wcharPtrToCharPtr(msg);ReplacementFor_m_logger->
ReplacementFor_stream()<<ReplacementFor_buff_;free(ReplacementFor_buff_);
#  endif
if(ReplacementFor_ELPP->ReplacementFor_hasFlag(ReplacementFor_LoggingFlag::
ReplacementFor_AutoSpacing)){ReplacementFor_m_logger->ReplacementFor_stream()<<
"\x20";}return*this;}ReplacementFor_Writer&ReplacementFor_Writer::construct(
ReplacementFor_Logger*ReplacementFor_logger,bool ReplacementFor_needLock){
ReplacementFor_m_logger=ReplacementFor_logger;ReplacementFor_initializeLogger(
ReplacementFor_logger->id(),false,ReplacementFor_needLock);
ReplacementFor_m_messageBuilder.ReplacementFor_initialize(
ReplacementFor_m_logger);return*this;}ReplacementFor_Writer&
ReplacementFor_Writer::construct(int count,const char*ReplacementFor_loggerIds,
...){if(ReplacementFor_ELPP->ReplacementFor_hasFlag(ReplacementFor_LoggingFlag::
ReplacementFor_MultiLoggerSupport)){va_list ReplacementFor_loggersList;va_start(
ReplacementFor_loggersList,ReplacementFor_loggerIds);const char*id=
ReplacementFor_loggerIds;ReplacementFor_m_loggerIds.reserve(count);for(int i=
(0x610+5743-0x1c7f);i<count;++i){ReplacementFor_m_loggerIds.push_back(std::
string(id));id=va_arg(ReplacementFor_loggersList,const char*);}va_end(
ReplacementFor_loggersList);ReplacementFor_initializeLogger(
ReplacementFor_m_loggerIds.at((0x92d+6174-0x214b)));}else{
ReplacementFor_initializeLogger(std::string(ReplacementFor_loggerIds));}
ReplacementFor_m_messageBuilder.ReplacementFor_initialize(
ReplacementFor_m_logger);return*this;}void ReplacementFor_Writer::
ReplacementFor_initializeLogger(const std::string&ReplacementFor_loggerId,bool 
ReplacementFor_lookup,bool ReplacementFor_needLock){if(ReplacementFor_lookup){
ReplacementFor_m_logger=ReplacementFor_ELPP->ReplacementFor_registeredLoggers()
->get(ReplacementFor_loggerId,ReplacementFor_ELPP->ReplacementFor_hasFlag(
ReplacementFor_LoggingFlag::ReplacementFor_CreateLoggerAutomatically));}if(
ReplacementFor_m_logger==nullptr){{if(!ReplacementFor_ELPP->
ReplacementFor_registeredLoggers()->ReplacementFor_has(std::string(base::
ReplacementFor_consts::ReplacementFor_kDefaultLoggerId))){ReplacementFor_ELPP->
ReplacementFor_registeredLoggers()->get(std::string(base::ReplacementFor_consts
::ReplacementFor_kDefaultLoggerId));}}ReplacementFor_Writer(Level::
ReplacementFor_Debug,ReplacementFor_m_file,ReplacementFor_m_line,
ReplacementFor_m_func).construct((0x1923+3338-0x262c),base::
ReplacementFor_consts::ReplacementFor_kDefaultLoggerId)<<
"\x4c\x6f\x67\x67\x65\x72\x20\x5b"<<ReplacementFor_loggerId<<
"\x5d\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x20\x79\x65\x74\x21"
;ReplacementFor_m_proceed=false;}else{if(ReplacementFor_needLock){
ReplacementFor_m_logger->ReplacementFor_acquireLock();}if(ReplacementFor_ELPP->
ReplacementFor_hasFlag(ReplacementFor_LoggingFlag::
ReplacementFor_HierarchicalLogging)){ReplacementFor_m_proceed=
ReplacementFor_m_level==Level::ReplacementFor_Verbose?ReplacementFor_m_logger->
ReplacementFor_enabled(ReplacementFor_m_level):ReplacementFor_LevelHelper::
ReplacementFor_castToInt(ReplacementFor_m_level)>=ReplacementFor_LevelHelper::
ReplacementFor_castToInt(ReplacementFor_ELPP->ReplacementFor_m_loggingLevel);}
else{ReplacementFor_m_proceed=ReplacementFor_m_logger->ReplacementFor_enabled(
ReplacementFor_m_level);}}}void ReplacementFor_Writer::
ReplacementFor_processDispatch(){
#if ReplacementFor_ELPP_LOGGING_ENABLED
if(ReplacementFor_ELPP->ReplacementFor_hasFlag(ReplacementFor_LoggingFlag::
ReplacementFor_MultiLoggerSupport)){bool ReplacementFor_firstDispatched=false;
base::type::ReplacementFor_string_t ReplacementFor_logMessage;std::size_t i=
(0x2d9+7007-0x1e38);do{if(ReplacementFor_m_proceed){if(
ReplacementFor_firstDispatched){ReplacementFor_m_logger->ReplacementFor_stream()
<<ReplacementFor_logMessage;}else{ReplacementFor_firstDispatched=true;if(
ReplacementFor_m_loggerIds.size()>(0xeca+1540-0x14cd)){ReplacementFor_logMessage
=ReplacementFor_m_logger->ReplacementFor_stream().str();}}
ReplacementFor_triggerDispatch();}else if(ReplacementFor_m_logger!=nullptr){
ReplacementFor_m_logger->ReplacementFor_stream().str(ReplacementFor_ELPP_LITERAL
(""));ReplacementFor_m_logger->ReplacementFor_releaseLock();}if(i+
(0xc4d+499-0xe3f)<ReplacementFor_m_loggerIds.size()){
ReplacementFor_initializeLogger(ReplacementFor_m_loggerIds.at(i+
(0x538+1118-0x995)));}}while(++i<ReplacementFor_m_loggerIds.size());}else{if(
ReplacementFor_m_proceed){ReplacementFor_triggerDispatch();}else if(
ReplacementFor_m_logger!=nullptr){ReplacementFor_m_logger->ReplacementFor_stream
().str(ReplacementFor_ELPP_LITERAL(""));ReplacementFor_m_logger->
ReplacementFor_releaseLock();}}
#else
if(ReplacementFor_m_logger!=nullptr){ReplacementFor_m_logger->
ReplacementFor_stream().str(ReplacementFor_ELPP_LITERAL(""));
ReplacementFor_m_logger->ReplacementFor_releaseLock();}
#endif 
}void ReplacementFor_Writer::ReplacementFor_triggerDispatch(void){if(
ReplacementFor_m_proceed){if(ReplacementFor_m_msg==nullptr){
ReplacementFor_LogMessage msg(ReplacementFor_m_level,ReplacementFor_m_file,
ReplacementFor_m_line,ReplacementFor_m_func,ReplacementFor_m_verboseLevel,
ReplacementFor_m_logger);base::ReplacementFor_LogDispatcher(
ReplacementFor_m_proceed,&msg,ReplacementFor_m_dispatchAction).
ReplacementFor_dispatch();}else{base::ReplacementFor_LogDispatcher(
ReplacementFor_m_proceed,ReplacementFor_m_msg,ReplacementFor_m_dispatchAction).
ReplacementFor_dispatch();}}if(ReplacementFor_m_logger!=nullptr){
ReplacementFor_m_logger->ReplacementFor_stream().str(ReplacementFor_ELPP_LITERAL
(""));ReplacementFor_m_logger->ReplacementFor_releaseLock();}if(
ReplacementFor_m_proceed&&ReplacementFor_m_level==Level::ReplacementFor_Fatal&&!
ReplacementFor_ELPP->ReplacementFor_hasFlag(ReplacementFor_LoggingFlag::
ReplacementFor_DisableApplicationAbortOnFatalLog)){base::ReplacementFor_Writer(
Level::ReplacementFor_Warning,ReplacementFor_m_file,ReplacementFor_m_line,
ReplacementFor_m_func).construct((0x18d6+2108-0x2111),base::
ReplacementFor_consts::ReplacementFor_kDefaultLoggerId)<<
"\x41\x62\x6f\x72\x74\x69\x6e\x67\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2e\x20\x52\x65\x61\x73\x6f\x6e\x3a\x20\x46\x61\x74\x61\x6c\x20\x6c\x6f\x67\x20\x61\x74\x20\x5b"
<<ReplacementFor_m_file<<"\x3a"<<ReplacementFor_m_line<<"\x5d";std::stringstream
 ReplacementFor_reasonStream;ReplacementFor_reasonStream<<
"\x46\x61\x74\x61\x6c\x20\x6c\x6f\x67\x20\x61\x74\x20\x5b"<<
ReplacementFor_m_file<<"\x3a"<<ReplacementFor_m_line<<"\x5d"<<
"\x20\x49\x66\x20\x79\x6f\x75\x20\x77\x69\x73\x68\x20\x74\x6f\x20\x64\x69\x73\x61\x62\x6c\x65\x20\x27\x61\x62\x6f\x72\x74\x20\x6f\x6e\x20\x66\x61\x74\x61\x6c\x20\x6c\x6f\x67\x27\x20\x70\x6c\x65\x61\x73\x65\x20\x75\x73\x65\x20"
<<
"\x65\x6c\x3a\x3a\x4c\x6f\x67\x67\x65\x72\x73\x3a\x3a\x61\x64\x64\x46\x6c\x61\x67\x28\x65\x6c\x3a\x3a\x4c\x6f\x67\x67\x69\x6e\x67\x46\x6c\x61\x67\x3a\x3a\x44\x69\x73\x61\x62\x6c\x65\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x41\x62\x6f\x72\x74\x4f\x6e\x46\x61\x74\x61\x6c\x4c\x6f\x67\x29"
;base::ReplacementFor_utils::abort((0x1e9a+1043-0x22ac),
ReplacementFor_reasonStream.str());}ReplacementFor_m_proceed=false;}
ReplacementFor_PErrorWriter::~ReplacementFor_PErrorWriter(void){if(
ReplacementFor_m_proceed){
#if ReplacementFor_ELPP_COMPILER_MSVC
char ReplacementFor_buff[(0x114f+4989-0x23cc)];ReplacementFor_strerror_s(
ReplacementFor_buff,(0x824+4388-0x1848),errno);ReplacementFor_m_logger->
ReplacementFor_stream()<<"\x3a\x20"<<ReplacementFor_buff<<"\x20\x5b"<<errno<<
"\x5d";
#else
ReplacementFor_m_logger->ReplacementFor_stream()<<"\x3a\x20"<<strerror(errno)<<
"\x20\x5b"<<errno<<"\x5d";
#endif
}}
#if defined(ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ELPP_FEATURE_PERFORMANCE_TRACKING)
ReplacementFor_PerformanceTracker::ReplacementFor_PerformanceTracker(const std::
string&ReplacementFor_blockName,base::ReplacementFor_TimestampUnit 
ReplacementFor_timestampUnit,const std::string&ReplacementFor_loggerId,bool 
ReplacementFor_scopedLog,Level ReplacementFor_level):ReplacementFor_m_blockName(
ReplacementFor_blockName),ReplacementFor_m_timestampUnit(
ReplacementFor_timestampUnit),ReplacementFor_m_loggerId(ReplacementFor_loggerId)
,ReplacementFor_m_scopedLog(ReplacementFor_scopedLog),ReplacementFor_m_level(
ReplacementFor_level),ReplacementFor_m_hasChecked(false),
ReplacementFor_m_lastCheckpointId(std::string()),ReplacementFor_m_enabled(false)
{
#if !defined(ReplacementFor_ELPP_DISABLE_PERFORMANCE_TRACKING) && \
ReplacementFor_ELPP_LOGGING_ENABLED
ReplacementFor_el::ReplacementFor_Logger*ReplacementFor_loggerPtr=
ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->get(
ReplacementFor_loggerId,false);ReplacementFor_m_enabled=ReplacementFor_loggerPtr
!=nullptr&&ReplacementFor_loggerPtr->ReplacementFor_m_typedConfigurations->
ReplacementFor_performanceTracking(ReplacementFor_m_level);if(
ReplacementFor_m_enabled){base::ReplacementFor_utils::ReplacementFor_DateTime::
gettimeofday(&ReplacementFor_m_startTime);}
#endif  
}ReplacementFor_PerformanceTracker::~ReplacementFor_PerformanceTracker(void){
#if !defined(ReplacementFor_ELPP_DISABLE_PERFORMANCE_TRACKING) && \
ReplacementFor_ELPP_LOGGING_ENABLED
if(ReplacementFor_m_enabled){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());if(
ReplacementFor_m_scopedLog){base::ReplacementFor_utils::ReplacementFor_DateTime
::gettimeofday(&ReplacementFor_m_endTime);base::type::ReplacementFor_string_t 
ReplacementFor_formattedTime=ReplacementFor_getFormattedTimeTaken();
ReplacementFor_PerformanceTrackingData data(
ReplacementFor_PerformanceTrackingData::DataType::ReplacementFor_Complete);data.
init(this);data.ReplacementFor_m_formattedTimeTaken=ReplacementFor_formattedTime
;ReplacementFor_PerformanceTrackingCallback*ReplacementFor_callback=nullptr;for(
const std::pair<std::string,base::type::
ReplacementFor_PerformanceTrackingCallbackPtr>&ReplacementFor_h:
ReplacementFor_ELPP->ReplacementFor_m_performanceTrackingCallbacks){
ReplacementFor_callback=ReplacementFor_h.second.get();if(ReplacementFor_callback
!=nullptr&&ReplacementFor_callback->ReplacementFor_enabled()){
ReplacementFor_callback->ReplacementFor_handle(&data);}}}}
#endif  
}void ReplacementFor_PerformanceTracker::ReplacementFor_checkpoint(const std::
string&id,const char*ReplacementFor_file,base::type::ReplacementFor_LineNumber 
line,const char*ReplacementFor_func){
#if !defined(ReplacementFor_ELPP_DISABLE_PERFORMANCE_TRACKING) && \
ReplacementFor_ELPP_LOGGING_ENABLED
if(ReplacementFor_m_enabled){base::ReplacementFor_threading::
ReplacementFor_ScopedLock ReplacementFor_scopedLock(lock());base::
ReplacementFor_utils::ReplacementFor_DateTime::gettimeofday(&
ReplacementFor_m_endTime);base::type::ReplacementFor_string_t 
ReplacementFor_formattedTime=ReplacementFor_m_hasChecked?
ReplacementFor_getFormattedTimeTaken(ReplacementFor_m_lastCheckpointTime):
ReplacementFor_ELPP_LITERAL("");ReplacementFor_PerformanceTrackingData data(
ReplacementFor_PerformanceTrackingData::DataType::ReplacementFor_Checkpoint);
data.init(this);data.ReplacementFor_m_checkpointId=id;data.ReplacementFor_m_file
=ReplacementFor_file;data.ReplacementFor_m_line=line;data.ReplacementFor_m_func=
ReplacementFor_func;data.ReplacementFor_m_formattedTimeTaken=
ReplacementFor_formattedTime;ReplacementFor_PerformanceTrackingCallback*
ReplacementFor_callback=nullptr;for(const std::pair<std::string,base::type::
ReplacementFor_PerformanceTrackingCallbackPtr>&ReplacementFor_h:
ReplacementFor_ELPP->ReplacementFor_m_performanceTrackingCallbacks){
ReplacementFor_callback=ReplacementFor_h.second.get();if(ReplacementFor_callback
!=nullptr&&ReplacementFor_callback->ReplacementFor_enabled()){
ReplacementFor_callback->ReplacementFor_handle(&data);}}base::
ReplacementFor_utils::ReplacementFor_DateTime::gettimeofday(&
ReplacementFor_m_lastCheckpointTime);ReplacementFor_m_hasChecked=true;
ReplacementFor_m_lastCheckpointId=id;}
#endif  
ReplacementFor_ELPP_UNUSED(id);ReplacementFor_ELPP_UNUSED(ReplacementFor_file);
ReplacementFor_ELPP_UNUSED(line);ReplacementFor_ELPP_UNUSED(ReplacementFor_func)
;}const base::type::ReplacementFor_string_t ReplacementFor_PerformanceTracker::
ReplacementFor_getFormattedTimeTaken(struct timeval ReplacementFor_startTime)
const{if(ReplacementFor_ELPP->ReplacementFor_hasFlag(ReplacementFor_LoggingFlag
::ReplacementFor_FixedTimeFormat)){base::type::ReplacementFor_stringstream_t 
ReplacementFor_ss;ReplacementFor_ss<<base::ReplacementFor_utils::
ReplacementFor_DateTime::ReplacementFor_getTimeDifference(
ReplacementFor_m_endTime,ReplacementFor_startTime,ReplacementFor_m_timestampUnit
)<<"\x20"<<base::ReplacementFor_consts::ReplacementFor_kTimeFormats[static_cast<
base::type::ReplacementFor_EnumType>(ReplacementFor_m_timestampUnit)].
ReplacementFor_unit;return ReplacementFor_ss.str();}return base::
ReplacementFor_utils::ReplacementFor_DateTime::formatTime(base::
ReplacementFor_utils::ReplacementFor_DateTime::ReplacementFor_getTimeDifference(
ReplacementFor_m_endTime,ReplacementFor_startTime,ReplacementFor_m_timestampUnit
),ReplacementFor_m_timestampUnit);}
#endif 
namespace ReplacementFor_debug{
#if defined(ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ELPP_FEATURE_CRASH_LOG)
ReplacementFor_StackTrace::ReplacementFor_StackTraceEntry::
ReplacementFor_StackTraceEntry(std::size_t index,const std::string&
ReplacementFor_loc,const std::string&ReplacementFor_demang,const std::string&hex
,const std::string&addr):ReplacementFor_m_index(index),ReplacementFor_m_location
(ReplacementFor_loc),ReplacementFor_m_demangled(ReplacementFor_demang),
ReplacementFor_m_hex(hex),ReplacementFor_m_addr(addr){}std::ostream&operator<<(
std::ostream&ReplacementFor_ss,const ReplacementFor_StackTrace::
ReplacementFor_StackTraceEntry&ReplacementFor_si){ReplacementFor_ss<<"\x5b"<<
ReplacementFor_si.ReplacementFor_m_index<<"\x5d\x20"<<ReplacementFor_si.
ReplacementFor_m_location<<(ReplacementFor_si.ReplacementFor_m_hex.empty()?"":
"\x2b")<<ReplacementFor_si.ReplacementFor_m_hex<<"\x20"<<ReplacementFor_si.
ReplacementFor_m_addr<<(ReplacementFor_si.ReplacementFor_m_demangled.empty()?"":
"\x3a")<<ReplacementFor_si.ReplacementFor_m_demangled;return ReplacementFor_ss;}
std::ostream&operator<<(std::ostream&os,const ReplacementFor_StackTrace&st){std
::vector<ReplacementFor_StackTrace::ReplacementFor_StackTraceEntry>::
const_iterator ReplacementFor_it=st.ReplacementFor_m_stack.begin();while(
ReplacementFor_it!=st.ReplacementFor_m_stack.end()){os<<"\x20\x20\x20\x20"<<*
ReplacementFor_it++<<"\n";}return os;}void ReplacementFor_StackTrace::
ReplacementFor_generateNew(void){
#if ReplacementFor_ELPP_STACKTRACE
ReplacementFor_m_stack.clear();void*stack[ReplacementFor_kMaxStack];unsigned int
 size=backtrace(stack,ReplacementFor_kMaxStack);char**ReplacementFor_strings=
backtrace_symbols(stack,size);if(size>ReplacementFor_kStackStart){for(std::
size_t i=ReplacementFor_kStackStart;i<size;++i){std::string 
ReplacementFor_mangName;std::string ReplacementFor_location;std::string hex;std
::string addr;const std::string line(ReplacementFor_strings[i]);auto p=line.find
("\x5f");if(p!=std::string::npos){ReplacementFor_mangName=line.substr(p);
ReplacementFor_mangName=ReplacementFor_mangName.substr((0x4bb+8642-0x267d),
ReplacementFor_mangName.find("\x20\x2b"));}p=line.find("\x30\x78");if(p!=std::
string::npos){addr=line.substr(p);addr=addr.substr((0x8aa+7028-0x241e),addr.find
("\x5f"));}if(!ReplacementFor_mangName.empty()){int status=(0xed3+446-0x1091);
char*ReplacementFor_demangName=ReplacementFor_abi::ReplacementFor___cxa_demangle
(ReplacementFor_mangName.data(),(0xa5f+4420-0x1ba3),(0xbfb+4557-0x1dc8),&status)
;if(status==(0x1ea+4379-0x1305)){ReplacementFor_StackTraceEntry entry(i-
(0x24+2924-0xb8f),ReplacementFor_location,ReplacementFor_demangName,hex,addr);
ReplacementFor_m_stack.push_back(entry);}else{ReplacementFor_StackTraceEntry 
entry(i-(0x75f+2026-0xf48),ReplacementFor_location,ReplacementFor_mangName,hex,
addr);ReplacementFor_m_stack.push_back(entry);}free(ReplacementFor_demangName);}
else{ReplacementFor_StackTraceEntry entry(i-(0x1a8+7149-0x1d94),line);
ReplacementFor_m_stack.push_back(entry);}}}free(ReplacementFor_strings);
#else
ReplacementFor_ELPP_INTERNAL_INFO((0x1d+2421-0x991),
"\x53\x74\x61\x63\x6b\x74\x72\x61\x63\x65\x20\x67\x65\x6e\x65\x72\x61\x74\x69\x6f\x6e\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x66\x6f\x72\x20\x73\x65\x6c\x65\x63\x74\x65\x64\x20\x63\x6f\x6d\x70\x69\x6c\x65\x72"
);
#endif  
}static std::string ReplacementFor_crashReason(int sig){std::stringstream 
ReplacementFor_ss;bool ReplacementFor_foundReason=false;for(int i=
(0x828+22-0x83e);i<base::ReplacementFor_consts::
ReplacementFor_kCrashSignalsCount;++i){if(base::ReplacementFor_consts::
ReplacementFor_kCrashSignals[i].ReplacementFor_numb==sig){ReplacementFor_ss<<
"\x43\x72\x61\x73\x68\x65\x64\x20\x64\x75\x65\x20\x74\x6f\x20\x5b"<<base::
ReplacementFor_consts::ReplacementFor_kCrashSignals[i].name<<
"\x5d\x20\x73\x69\x67\x6e\x61\x6c";if(ReplacementFor_ELPP->
ReplacementFor_hasFlag(ReplacementFor_el::ReplacementFor_LoggingFlag::
ReplacementFor_LogDetailedCrashReason)){ReplacementFor_ss<<std::endl<<
"\x20\x20\x20\x20"<<base::ReplacementFor_consts::ReplacementFor_kCrashSignals[i]
.ReplacementFor_brief<<std::endl<<"\x20\x20\x20\x20"<<base::
ReplacementFor_consts::ReplacementFor_kCrashSignals[i].ReplacementFor_detail;}
ReplacementFor_foundReason=true;}}if(!ReplacementFor_foundReason){
ReplacementFor_ss<<
"\x43\x72\x61\x73\x68\x65\x64\x20\x64\x75\x65\x20\x74\x6f\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x73\x69\x67\x6e\x61\x6c\x20\x5b"
<<sig<<"\x5d";}return ReplacementFor_ss.str();}static void 
ReplacementFor_logCrashReason(int sig,bool ReplacementFor_stackTraceIfAvailable,
Level ReplacementFor_level,const char*ReplacementFor_logger){if(sig==SIGINT&&
ReplacementFor_ELPP->ReplacementFor_hasFlag(ReplacementFor_el::
ReplacementFor_LoggingFlag::ReplacementFor_IgnoreSigInt)){return;}std::
stringstream ReplacementFor_ss;ReplacementFor_ss<<
"\x43\x52\x41\x53\x48\x20\x48\x41\x4e\x44\x4c\x45\x44\x3b\x20";ReplacementFor_ss
<<ReplacementFor_crashReason(sig);
#if ReplacementFor_ELPP_STACKTRACE
if(ReplacementFor_stackTraceIfAvailable){ReplacementFor_ss<<std::endl<<
"\x20\x20\x20\x20\x3d\x3d\x3d\x3d\x3d\x3d\x3d\x20\x42\x61\x63\x6b\x74\x72\x61\x63\x65\x3a\x20\x3d\x3d\x3d\x3d\x3d\x3d\x3d\x3d\x3d"
<<std::endl<<base::ReplacementFor_debug::ReplacementFor_StackTrace();}
#else
ReplacementFor_ELPP_UNUSED(ReplacementFor_stackTraceIfAvailable);
#endif  
ReplacementFor_ELPP_WRITE_LOG(ReplacementFor_el::base::ReplacementFor_Writer,
ReplacementFor_level,base::ReplacementFor_DispatchAction::
ReplacementFor_NormalLog,ReplacementFor_logger)<<ReplacementFor_ss.str();}static
 inline void ReplacementFor_crashAbort(int sig){base::ReplacementFor_utils::
abort(sig,std::string());}static inline void ReplacementFor_defaultCrashHandler(
int sig){base::ReplacementFor_debug::ReplacementFor_logCrashReason(sig,true,
Level::ReplacementFor_Fatal,base::ReplacementFor_consts::
ReplacementFor_kDefaultLoggerId);base::ReplacementFor_debug::
ReplacementFor_crashAbort(sig);}ReplacementFor_CrashHandler::
ReplacementFor_CrashHandler(bool ReplacementFor_useDefault){if(
ReplacementFor_useDefault){ReplacementFor_setHandler(
ReplacementFor_defaultCrashHandler);}}void ReplacementFor_CrashHandler::
ReplacementFor_setHandler(const ReplacementFor_Handler&ReplacementFor_cHandler){
ReplacementFor_m_handler=ReplacementFor_cHandler;
#if defined(ReplacementFor_ELPP_HANDLE_SIGABRT)
int i=(0x1928+191-0x19e7);
#else
int i=(0xbab+5129-0x1fb3);
#endif  
for(;i<base::ReplacementFor_consts::ReplacementFor_kCrashSignalsCount;++i){
ReplacementFor_m_handler=signal(base::ReplacementFor_consts::
ReplacementFor_kCrashSignals[i].ReplacementFor_numb,ReplacementFor_cHandler);}}
#endif 
}}
#if defined(ReplacementFor_ELPP_FEATURE_ALL) || defined(\
ReplacementFor_ELPP_FEATURE_CRASH_LOG)
void ReplacementFor_Helpers::ReplacementFor_crashAbort(int sig,const char*
ReplacementFor_sourceFile,unsigned int long line){std::stringstream 
ReplacementFor_ss;ReplacementFor_ss<<base::ReplacementFor_debug::
ReplacementFor_crashReason(sig).c_str();ReplacementFor_ss<<
"\x20\x2d\x20\x5b\x43\x61\x6c\x6c\x65\x64\x20\x65\x6c\x3a\x3a\x48\x65\x6c\x70\x65\x72\x73\x3a\x3a\x63\x72\x61\x73\x68\x41\x62\x6f\x72\x74\x28"
<<sig<<"\x29\x5d";if(ReplacementFor_sourceFile!=nullptr&&strlen(
ReplacementFor_sourceFile)>(0xdd+5981-0x183a)){ReplacementFor_ss<<
"\x20\x2d\x20\x53\x6f\x75\x72\x63\x65\x3a\x20"<<ReplacementFor_sourceFile;if(
line>(0x7e9+4252-0x1885))ReplacementFor_ss<<"\x3a"<<line;else ReplacementFor_ss
<<
"\x20\x28\x6c\x69\x6e\x65\x20\x6e\x75\x6d\x62\x65\x72\x20\x6e\x6f\x74\x20\x73\x70\x65\x63\x69\x66\x69\x65\x64\x29"
;}base::ReplacementFor_utils::abort(sig,ReplacementFor_ss.str());}void 
ReplacementFor_Helpers::ReplacementFor_logCrashReason(int sig,bool 
ReplacementFor_stackTraceIfAvailable,Level ReplacementFor_level,const char*
ReplacementFor_logger){ReplacementFor_el::base::ReplacementFor_debug::
ReplacementFor_logCrashReason(sig,ReplacementFor_stackTraceIfAvailable,
ReplacementFor_level,ReplacementFor_logger);}
#endif 
ReplacementFor_Logger*ReplacementFor_Loggers::ReplacementFor_getLogger(const std
::string&ReplacementFor_identity,bool ReplacementFor_registerIfNotAvailable){
return ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->get(
ReplacementFor_identity,ReplacementFor_registerIfNotAvailable);}void 
ReplacementFor_Loggers::ReplacementFor_setDefaultLogBuilder(ReplacementFor_el::
ReplacementFor_LogBuilderPtr&ReplacementFor_logBuilderPtr){ReplacementFor_ELPP->
ReplacementFor_registeredLoggers()->ReplacementFor_setDefaultLogBuilder(
ReplacementFor_logBuilderPtr);}bool ReplacementFor_Loggers::
ReplacementFor_unregisterLogger(const std::string&ReplacementFor_identity){
return ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->remove(
ReplacementFor_identity);}bool ReplacementFor_Loggers::ReplacementFor_hasLogger(
const std::string&ReplacementFor_identity){return ReplacementFor_ELPP->
ReplacementFor_registeredLoggers()->ReplacementFor_has(ReplacementFor_identity);
}ReplacementFor_Logger*ReplacementFor_Loggers::ReplacementFor_reconfigureLogger(
ReplacementFor_Logger*ReplacementFor_logger,const ReplacementFor_Configurations&
ReplacementFor_configurations){if(!ReplacementFor_logger)return nullptr;
ReplacementFor_logger->ReplacementFor_configure(ReplacementFor_configurations);
return ReplacementFor_logger;}ReplacementFor_Logger*ReplacementFor_Loggers::
ReplacementFor_reconfigureLogger(const std::string&ReplacementFor_identity,const
 ReplacementFor_Configurations&ReplacementFor_configurations){return 
ReplacementFor_Loggers::ReplacementFor_reconfigureLogger(ReplacementFor_Loggers
::ReplacementFor_getLogger(ReplacementFor_identity),
ReplacementFor_configurations);}ReplacementFor_Logger*ReplacementFor_Loggers::
ReplacementFor_reconfigureLogger(const std::string&ReplacementFor_identity,
ReplacementFor_ConfigurationType ReplacementFor_configurationType,const std::
string&value){ReplacementFor_Logger*ReplacementFor_logger=ReplacementFor_Loggers
::ReplacementFor_getLogger(ReplacementFor_identity);if(ReplacementFor_logger==
nullptr){return nullptr;}ReplacementFor_logger->ReplacementFor_configurations()
->set(Level::Global,ReplacementFor_configurationType,value);
ReplacementFor_logger->ReplacementFor_reconfigure();return ReplacementFor_logger
;}void ReplacementFor_Loggers::ReplacementFor_reconfigureAllLoggers(const 
ReplacementFor_Configurations&ReplacementFor_configurations){for(base::
ReplacementFor_RegisteredLoggers::iterator ReplacementFor_it=ReplacementFor_ELPP
->ReplacementFor_registeredLoggers()->begin();ReplacementFor_it!=
ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->end();++
ReplacementFor_it){ReplacementFor_Loggers::ReplacementFor_reconfigureLogger(
ReplacementFor_it->second,ReplacementFor_configurations);}}void 
ReplacementFor_Loggers::ReplacementFor_reconfigureAllLoggers(Level 
ReplacementFor_level,ReplacementFor_ConfigurationType 
ReplacementFor_configurationType,const std::string&value){for(base::
ReplacementFor_RegisteredLoggers::iterator ReplacementFor_it=ReplacementFor_ELPP
->ReplacementFor_registeredLoggers()->begin();ReplacementFor_it!=
ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->end();++
ReplacementFor_it){ReplacementFor_Logger*ReplacementFor_logger=ReplacementFor_it
->second;ReplacementFor_logger->ReplacementFor_configurations()->set(
ReplacementFor_level,ReplacementFor_configurationType,value);
ReplacementFor_logger->ReplacementFor_reconfigure();}}void 
ReplacementFor_Loggers::ReplacementFor_setDefaultConfigurations(const 
ReplacementFor_Configurations&ReplacementFor_configurations,bool 
ReplacementFor_reconfigureExistingLoggers){ReplacementFor_ELPP->
ReplacementFor_registeredLoggers()->ReplacementFor_setDefaultConfigurations(
ReplacementFor_configurations);if(ReplacementFor_reconfigureExistingLoggers){
ReplacementFor_Loggers::ReplacementFor_reconfigureAllLoggers(
ReplacementFor_configurations);}}const ReplacementFor_Configurations*
ReplacementFor_Loggers::ReplacementFor_defaultConfigurations(void){return 
ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->
ReplacementFor_defaultConfigurations();}const base::
ReplacementFor_LogStreamsReferenceMap*ReplacementFor_Loggers::
ReplacementFor_logStreamsReference(void){return ReplacementFor_ELPP->
ReplacementFor_registeredLoggers()->ReplacementFor_logStreamsReference();}base::
ReplacementFor_TypedConfigurations ReplacementFor_Loggers::
ReplacementFor_defaultTypedConfigurations(void){return base::
ReplacementFor_TypedConfigurations(ReplacementFor_ELPP->
ReplacementFor_registeredLoggers()->ReplacementFor_defaultConfigurations(),
ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->
ReplacementFor_logStreamsReference());}std::vector<std::string>*
ReplacementFor_Loggers::ReplacementFor_populateAllLoggerIds(std::vector<std::
string>*ReplacementFor_targetList){ReplacementFor_targetList->clear();for(base::
ReplacementFor_RegisteredLoggers::iterator ReplacementFor_it=ReplacementFor_ELPP
->ReplacementFor_registeredLoggers()->list().begin();ReplacementFor_it!=
ReplacementFor_ELPP->ReplacementFor_registeredLoggers()->list().end();++
ReplacementFor_it){ReplacementFor_targetList->push_back(ReplacementFor_it->first
);}return ReplacementFor_targetList;}void ReplacementFor_Loggers::
ReplacementFor_configureFromGlobal(const char*
ReplacementFor_globalConfigurationFilePath){std::ifstream 
ReplacementFor_gcfStream(ReplacementFor_globalConfigurationFilePath,std::
ifstream::in);ReplacementFor_ELPP_ASSERT(ReplacementFor_gcfStream.is_open(),
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x6f\x70\x65\x6e\x20\x67\x6c\x6f\x62\x61\x6c\x20\x63\x6f\x6e\x66\x20\x66\x69\x6c\x65\x20\x5b"
<<ReplacementFor_globalConfigurationFilePath<<
"\x5d\x20\x66\x6f\x72\x20\x70\x61\x72\x73\x69\x6e\x67\x2e");std::string line=std
::string();std::stringstream ReplacementFor_ss;ReplacementFor_Logger*
ReplacementFor_logger=nullptr;auto ReplacementFor_configure=[&](void){
ReplacementFor_ELPP_INTERNAL_INFO((0x10cf+827-0x1402),
"\x43\x6f\x6e\x66\x20\x6c\x6f\x67\x67\x65\x72\x3a\x20\x27"<<
ReplacementFor_logger->id()<<
"\x27\x20\x77\x69\x74\x68\x20\x63\x6f\x6e\x66\x20" "\n"<<ReplacementFor_ss.str()
<<"\n" "\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d");
ReplacementFor_Configurations c;c.ReplacementFor_parseFromText(ReplacementFor_ss
.str());ReplacementFor_logger->ReplacementFor_configure(c);};while(
ReplacementFor_gcfStream.good()){std::getline(ReplacementFor_gcfStream,line);
ReplacementFor_ELPP_INTERNAL_INFO((0x464+274-0x575),
"\x50\x61\x72\x73\x6e\x67\x20\x6c\x69\x6e\x65\x3a\x20"<<line);base::
ReplacementFor_utils::Str::ReplacementFor_trim(line);if(
ReplacementFor_Configurations::ReplacementFor_Parser::ReplacementFor_isComment(
line))continue;ReplacementFor_Configurations::ReplacementFor_Parser::
ReplacementFor_ignoreComments(&line);base::ReplacementFor_utils::Str::
ReplacementFor_trim(line);if(line.size()>(0x1ab3+1578-0x20db)&&base::
ReplacementFor_utils::Str::ReplacementFor_startsWith(line,std::string(base::
ReplacementFor_consts::ReplacementFor_kConfigurationLoggerId))){if(!
ReplacementFor_ss.str().empty()&&ReplacementFor_logger!=nullptr){
ReplacementFor_configure();}ReplacementFor_ss.str(std::string(""));line=line.
substr((0x97b+2081-0x119a));base::ReplacementFor_utils::Str::ReplacementFor_trim
(line);if(line.size()>(0xa36+7185-0x2646)){ReplacementFor_ELPP_INTERNAL_INFO(
(0xc87+774-0xf8c),"\x47\x65\x74\x6e\x67\x20\x6c\x6f\x67\x67\x65\x72\x3a\x20\x27"
<<line<<"\x27");ReplacementFor_logger=ReplacementFor_getLogger(line);}}else{
ReplacementFor_ss<<line<<"\n";}}if(!ReplacementFor_ss.str().empty()&&
ReplacementFor_logger!=nullptr){ReplacementFor_configure();}}bool 
ReplacementFor_Loggers::ReplacementFor_configureFromArg(const char*
ReplacementFor_argKey){
#if defined(ReplacementFor_ELPP_DISABLE_CONFIGURATION_FROM_PROGRAM_ARGS)
ReplacementFor_ELPP_UNUSED(ReplacementFor_argKey);
#else
if(!ReplacementFor_Helpers::ReplacementFor_commandLineArgs()->
ReplacementFor_hasParamWithValue(ReplacementFor_argKey)){return false;}
ReplacementFor_configureFromGlobal(ReplacementFor_Helpers::
ReplacementFor_commandLineArgs()->ReplacementFor_getParamValue(
ReplacementFor_argKey));
#endif  
return true;}void ReplacementFor_Loggers::flushAll(void){ReplacementFor_ELPP->
ReplacementFor_registeredLoggers()->flushAll();}void ReplacementFor_Loggers::
ReplacementFor_setVerboseLevel(base::type::ReplacementFor_VerboseLevel 
ReplacementFor_level){ReplacementFor_ELPP->ReplacementFor_vRegistry()->
ReplacementFor_setLevel(ReplacementFor_level);}base::type::
ReplacementFor_VerboseLevel ReplacementFor_Loggers::ReplacementFor_verboseLevel(
void){return ReplacementFor_ELPP->ReplacementFor_vRegistry()->
ReplacementFor_level();}void ReplacementFor_Loggers::ReplacementFor_setVModules(
const char*ReplacementFor_modules){if(ReplacementFor_ELPP->
ReplacementFor_vRegistry()->ReplacementFor_vModulesEnabled()){
ReplacementFor_ELPP->ReplacementFor_vRegistry()->ReplacementFor_setModules(
ReplacementFor_modules);}}void ReplacementFor_Loggers::
ReplacementFor_clearVModules(void){ReplacementFor_ELPP->ReplacementFor_vRegistry
()->ReplacementFor_clearModules();}const std::string ReplacementFor_VersionInfo
::ReplacementFor_version(void){return std::string("\x39\x2e\x39\x36\x2e\x37");}
const std::string ReplacementFor_VersionInfo::ReplacementFor_releaseDate(void){
return std::string(
"\x32\x34\x2d\x31\x31\x2d\x32\x30\x31\x38\x20\x30\x37\x32\x38\x68\x72\x73");}}

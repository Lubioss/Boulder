
#include "../include/ReplacementFor_jsmn.h"
static ReplacementFor_jsmntok_t*ReplacementFor_jsmn_alloc_token(
ReplacementFor_jsmn_parser*ReplacementFor_parser,ReplacementFor_jsmntok_t*
ReplacementFor_tokens,size_t ReplacementFor_num_tokens){ReplacementFor_jsmntok_t
*ReplacementFor_tok;if(ReplacementFor_parser->ReplacementFor_toknext>=
ReplacementFor_num_tokens){return NULL;}ReplacementFor_tok=&
ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toknext++];
ReplacementFor_tok->ReplacementFor_start=ReplacementFor_tok->end=-
(0x358+6420-0x1c6b);ReplacementFor_tok->size=(0x541+4979-0x18b4);
#ifdef ReplacementFor_JSMN_PARENT_LINKS
ReplacementFor_tok->ReplacementFor_parent=-(0x468+5511-0x19ee);
#endif
return ReplacementFor_tok;}static void ReplacementFor_jsmn_fill_token(
ReplacementFor_jsmntok_t*ReplacementFor_token,ReplacementFor_jsmntype_t type,int
 ReplacementFor_start,int end){ReplacementFor_token->type=type;
ReplacementFor_token->ReplacementFor_start=ReplacementFor_start;
ReplacementFor_token->end=end;ReplacementFor_token->size=(0xafa+180-0xbae);}
static int ReplacementFor_jsmn_parse_primitive(ReplacementFor_jsmn_parser*
ReplacementFor_parser,const char*ReplacementFor_js,size_t len,
ReplacementFor_jsmntok_t*ReplacementFor_tokens,size_t ReplacementFor_num_tokens)
{ReplacementFor_jsmntok_t*ReplacementFor_token;int ReplacementFor_start;
ReplacementFor_start=ReplacementFor_parser->pos;for(;ReplacementFor_parser->pos<
len&&ReplacementFor_js[ReplacementFor_parser->pos]!='\0';ReplacementFor_parser->
pos++){switch(ReplacementFor_js[ReplacementFor_parser->pos]){
#ifndef ReplacementFor_JSMN_STRICT
case((char)(0xf14+5923-0x25fd)):
#endif
case'\t':case'\r':case'\n':case((char)(0x1039+1276-0x1515)):case
((char)(0xdeb+3975-0x1d46)):case((char)(0x1ac0+979-0x1e36)):case
((char)(0x21f9+979-0x254f)):goto ReplacementFor_found;}if(ReplacementFor_js[
ReplacementFor_parser->pos]<(0x1a35+1805-0x2122)||ReplacementFor_js[
ReplacementFor_parser->pos]>=(0xc55+5367-0x20cd)){ReplacementFor_parser->pos=
ReplacementFor_start;return ReplacementFor_JSMN_ERROR_INVAL;}}
#ifdef ReplacementFor_JSMN_STRICT
ReplacementFor_parser->pos=ReplacementFor_start;return 
ReplacementFor_JSMN_ERROR_PART;
#endif
ReplacementFor_found:if(ReplacementFor_tokens==NULL){ReplacementFor_parser->pos
--;return(0x44a+294-0x570);}ReplacementFor_token=ReplacementFor_jsmn_alloc_token
(ReplacementFor_parser,ReplacementFor_tokens,ReplacementFor_num_tokens);if(
ReplacementFor_token==NULL){ReplacementFor_parser->pos=ReplacementFor_start;
return ReplacementFor_JSMN_ERROR_NOMEM;}ReplacementFor_jsmn_fill_token(
ReplacementFor_token,ReplacementFor_JSMN_PRIMITIVE,ReplacementFor_start,
ReplacementFor_parser->pos);
#ifdef ReplacementFor_JSMN_PARENT_LINKS
ReplacementFor_token->ReplacementFor_parent=ReplacementFor_parser->
ReplacementFor_toksuper;
#endif
ReplacementFor_parser->pos--;return(0xbe8+5581-0x21b5);}static int 
ReplacementFor_jsmn_parse_string(ReplacementFor_jsmn_parser*
ReplacementFor_parser,const char*ReplacementFor_js,size_t len,
ReplacementFor_jsmntok_t*ReplacementFor_tokens,size_t ReplacementFor_num_tokens)
{ReplacementFor_jsmntok_t*ReplacementFor_token;int ReplacementFor_start=
ReplacementFor_parser->pos;ReplacementFor_parser->pos++;for(;
ReplacementFor_parser->pos<len&&ReplacementFor_js[ReplacementFor_parser->pos]!=
'\0';ReplacementFor_parser->pos++){char c=ReplacementFor_js[
ReplacementFor_parser->pos];if(c=='\"'){if(ReplacementFor_tokens==NULL){return
(0xb26+4113-0x1b37);}ReplacementFor_token=ReplacementFor_jsmn_alloc_token(
ReplacementFor_parser,ReplacementFor_tokens,ReplacementFor_num_tokens);if(
ReplacementFor_token==NULL){ReplacementFor_parser->pos=ReplacementFor_start;
return ReplacementFor_JSMN_ERROR_NOMEM;}ReplacementFor_jsmn_fill_token(
ReplacementFor_token,ReplacementFor_JSMN_STRING,ReplacementFor_start+
(0x387+3762-0x1238),ReplacementFor_parser->pos);
#ifdef ReplacementFor_JSMN_PARENT_LINKS
ReplacementFor_token->ReplacementFor_parent=ReplacementFor_parser->
ReplacementFor_toksuper;
#endif
return(0x438+7430-0x213e);}if(c=='\\'&&ReplacementFor_parser->pos+
(0x510+6228-0x1d63)<len){int i;ReplacementFor_parser->pos++;switch(
ReplacementFor_js[ReplacementFor_parser->pos]){case'\"':case
((char)(0x211+4330-0x12cc)):case'\\':case((char)(0x144+6972-0x1c1e)):case
((char)(0xe48+1937-0x1573)):case((char)(0x31f+761-0x5a6)):case
((char)(0x14b7+4274-0x24fb)):case((char)(0x887+1428-0xda7)):break;case
((char)(0x15db+2993-0x2117)):ReplacementFor_parser->pos++;for(i=
(0x5f7+2893-0x1144);i<(0x467+6140-0x1c5f)&&ReplacementFor_parser->pos<len&&
ReplacementFor_js[ReplacementFor_parser->pos]!='\0';i++){if(!((ReplacementFor_js
[ReplacementFor_parser->pos]>=(0x17c8+1107-0x1beb)&&ReplacementFor_js[
ReplacementFor_parser->pos]<=(0x1c9d+2131-0x24b7))||(ReplacementFor_js[
ReplacementFor_parser->pos]>=(0x333+352-0x452)&&ReplacementFor_js[
ReplacementFor_parser->pos]<=(0x1cf+5975-0x18e0))||(ReplacementFor_js[
ReplacementFor_parser->pos]>=(0x1bf6+530-0x1da7)&&ReplacementFor_js[
ReplacementFor_parser->pos]<=(0xf4c+4187-0x1f41)))){ReplacementFor_parser->pos=
ReplacementFor_start;return ReplacementFor_JSMN_ERROR_INVAL;}
ReplacementFor_parser->pos++;}ReplacementFor_parser->pos--;break;default:
ReplacementFor_parser->pos=ReplacementFor_start;return 
ReplacementFor_JSMN_ERROR_INVAL;}}}ReplacementFor_parser->pos=
ReplacementFor_start;return ReplacementFor_JSMN_ERROR_PART;}int 
ReplacementFor_jsmn_parse(ReplacementFor_jsmn_parser*ReplacementFor_parser,const
 char*ReplacementFor_js,size_t len,ReplacementFor_jsmntok_t*
ReplacementFor_tokens,unsigned int ReplacementFor_num_tokens){int 
ReplacementFor_r;int i;ReplacementFor_jsmntok_t*ReplacementFor_token;int count=
ReplacementFor_parser->ReplacementFor_toknext;for(;ReplacementFor_parser->pos<
len&&ReplacementFor_js[ReplacementFor_parser->pos]!='\0';ReplacementFor_parser->
pos++){char c;ReplacementFor_jsmntype_t type;c=ReplacementFor_js[
ReplacementFor_parser->pos];switch(c){case((char)(0xd6b+3977-0x1c79)):case
((char)(0x187+8725-0x2341)):count++;if(ReplacementFor_tokens==NULL){break;}
ReplacementFor_token=ReplacementFor_jsmn_alloc_token(ReplacementFor_parser,
ReplacementFor_tokens,ReplacementFor_num_tokens);if(ReplacementFor_token==NULL)
return ReplacementFor_JSMN_ERROR_NOMEM;if(ReplacementFor_parser->
ReplacementFor_toksuper!=-(0x1070+4099-0x2072)){ReplacementFor_tokens[
ReplacementFor_parser->ReplacementFor_toksuper].size++;
#ifdef ReplacementFor_JSMN_PARENT_LINKS
ReplacementFor_token->ReplacementFor_parent=ReplacementFor_parser->
ReplacementFor_toksuper;
#endif
}ReplacementFor_token->type=(c==((char)(0x3fa+1108-0x7d3))?
ReplacementFor_JSMN_OBJECT:ReplacementFor_JSMN_ARRAY);ReplacementFor_token->
ReplacementFor_start=ReplacementFor_parser->pos;ReplacementFor_parser->
ReplacementFor_toksuper=ReplacementFor_parser->ReplacementFor_toknext-
(0x5c5+4992-0x1944);break;case((char)(0x41c+4178-0x13f1)):case
((char)(0x8ab+3839-0x174d)):if(ReplacementFor_tokens==NULL)break;type=(c==
((char)(0xd04+823-0xfbe))?ReplacementFor_JSMN_OBJECT:ReplacementFor_JSMN_ARRAY);
#ifdef ReplacementFor_JSMN_PARENT_LINKS
if(ReplacementFor_parser->ReplacementFor_toknext<(0x17c6+3755-0x2670)){return 
ReplacementFor_JSMN_ERROR_INVAL;}ReplacementFor_token=&ReplacementFor_tokens[
ReplacementFor_parser->ReplacementFor_toknext-(0x902+4894-0x1c1f)];for(;;){if(
ReplacementFor_token->ReplacementFor_start!=-(0x652+5160-0x1a79)&&
ReplacementFor_token->end==-(0xf42+2249-0x180a)){if(ReplacementFor_token->type!=
type){return ReplacementFor_JSMN_ERROR_INVAL;}ReplacementFor_token->end=
ReplacementFor_parser->pos+(0x105d+4938-0x23a6);ReplacementFor_parser->
ReplacementFor_toksuper=ReplacementFor_token->ReplacementFor_parent;break;}if(
ReplacementFor_token->ReplacementFor_parent==-(0x1bb8+1897-0x2320)){if(
ReplacementFor_token->type!=type||ReplacementFor_parser->ReplacementFor_toksuper
==-(0x32f+6159-0x1b3d)){return ReplacementFor_JSMN_ERROR_INVAL;}break;}
ReplacementFor_token=&ReplacementFor_tokens[ReplacementFor_token->
ReplacementFor_parent];}
#else
for(i=ReplacementFor_parser->ReplacementFor_toknext-(0x11b2+2377-0x1afa);i>=
(0x1478+3138-0x20ba);i--){ReplacementFor_token=&ReplacementFor_tokens[i];if(
ReplacementFor_token->ReplacementFor_start!=-(0x1ad1+2397-0x242d)&&
ReplacementFor_token->end==-(0x1301+3907-0x2243)){if(ReplacementFor_token->type
!=type){return ReplacementFor_JSMN_ERROR_INVAL;}ReplacementFor_parser->
ReplacementFor_toksuper=-(0xe5a+3673-0x1cb2);ReplacementFor_token->end=
ReplacementFor_parser->pos+(0xf9d+2543-0x198b);break;}}if(i==-
(0x10fd+3335-0x1e03))return ReplacementFor_JSMN_ERROR_INVAL;for(;i>=
(0x1337+4876-0x2643);i--){ReplacementFor_token=&ReplacementFor_tokens[i];if(
ReplacementFor_token->ReplacementFor_start!=-(0x1a84+2767-0x2552)&&
ReplacementFor_token->end==-(0x361+8076-0x22ec)){ReplacementFor_parser->
ReplacementFor_toksuper=i;break;}}
#endif
break;case'\"':ReplacementFor_r=ReplacementFor_jsmn_parse_string(
ReplacementFor_parser,ReplacementFor_js,len,ReplacementFor_tokens,
ReplacementFor_num_tokens);if(ReplacementFor_r<(0x4a8+1313-0x9c9))return 
ReplacementFor_r;count++;if(ReplacementFor_parser->ReplacementFor_toksuper!=-
(0x201+6815-0x1c9f)&&ReplacementFor_tokens!=NULL)ReplacementFor_tokens[
ReplacementFor_parser->ReplacementFor_toksuper].size++;break;case'\t':case'\r':
case'\n':case((char)(0x575+2617-0xf8e)):break;case((char)(0x7b2+495-0x967)):
ReplacementFor_parser->ReplacementFor_toksuper=ReplacementFor_parser->
ReplacementFor_toknext-(0x8c2+991-0xca0);break;case((char)(0xf52+1378-0x1488)):
if(ReplacementFor_tokens!=NULL&&ReplacementFor_parser->ReplacementFor_toksuper!=
-(0x1a0+7168-0x1d9f)&&ReplacementFor_tokens[ReplacementFor_parser->
ReplacementFor_toksuper].type!=ReplacementFor_JSMN_ARRAY&&ReplacementFor_tokens[
ReplacementFor_parser->ReplacementFor_toksuper].type!=ReplacementFor_JSMN_OBJECT
){
#ifdef ReplacementFor_JSMN_PARENT_LINKS
ReplacementFor_parser->ReplacementFor_toksuper=ReplacementFor_tokens[
ReplacementFor_parser->ReplacementFor_toksuper].ReplacementFor_parent;
#else
for(i=ReplacementFor_parser->ReplacementFor_toknext-(0x629+6230-0x1e7e);i>=
(0x150b+756-0x17ff);i--){if(ReplacementFor_tokens[i].type==
ReplacementFor_JSMN_ARRAY||ReplacementFor_tokens[i].type==
ReplacementFor_JSMN_OBJECT){if(ReplacementFor_tokens[i].ReplacementFor_start!=-
(0x58a+2428-0xf05)&&ReplacementFor_tokens[i].end==-(0x1062+3924-0x1fb5)){
ReplacementFor_parser->ReplacementFor_toksuper=i;break;}}}
#endif
}break;
#ifdef ReplacementFor_JSMN_STRICT
case((char)(0xb43+7156-0x270a)):case((char)(0x1ab0+402-0x1c12)):case
((char)(0x1f5d+913-0x22bd)):case((char)(0x103b+144-0x1099)):case
((char)(0x4a7+974-0x842)):case((char)(0x926+7182-0x2500)):case
((char)(0x597+7397-0x2247)):case((char)(0x890+3261-0x1517)):case
((char)(0x450+1548-0xa25)):case((char)(0x1652+2926-0x2188)):case
((char)(0x8bf+2396-0x11e2)):case((char)(0x109c+3783-0x1eef)):case
((char)(0xc00+2742-0x1650)):case((char)(0x19c8+3180-0x25c6)):if(
ReplacementFor_tokens!=NULL&&ReplacementFor_parser->ReplacementFor_toksuper!=-
(0x2269+390-0x23ee)){ReplacementFor_jsmntok_t*t=&ReplacementFor_tokens[
ReplacementFor_parser->ReplacementFor_toksuper];if(t->type==
ReplacementFor_JSMN_OBJECT||(t->type==ReplacementFor_JSMN_STRING&&t->size!=
(0x34+1227-0x4ff))){return ReplacementFor_JSMN_ERROR_INVAL;}}
#else
default:
#endif
ReplacementFor_r=ReplacementFor_jsmn_parse_primitive(ReplacementFor_parser,
ReplacementFor_js,len,ReplacementFor_tokens,ReplacementFor_num_tokens);if(
ReplacementFor_r<(0x824+132-0x8a8))return ReplacementFor_r;count++;if(
ReplacementFor_parser->ReplacementFor_toksuper!=-(0xd4a+6425-0x2662)&&
ReplacementFor_tokens!=NULL)ReplacementFor_tokens[ReplacementFor_parser->
ReplacementFor_toksuper].size++;break;
#ifdef ReplacementFor_JSMN_STRICT
default:return ReplacementFor_JSMN_ERROR_INVAL;
#endif
}}if(ReplacementFor_tokens!=NULL){for(i=ReplacementFor_parser->
ReplacementFor_toknext-(0x2e9+3359-0x1007);i>=(0x63+4011-0x100e);i--){if(
ReplacementFor_tokens[i].ReplacementFor_start!=-(0x136+1224-0x5fd)&&
ReplacementFor_tokens[i].end==-(0x12dd+3328-0x1fdc)){return 
ReplacementFor_JSMN_ERROR_PART;}}}return count;}void ReplacementFor_jsmn_init(
ReplacementFor_jsmn_parser*ReplacementFor_parser){ReplacementFor_parser->pos=
(0x1968+1366-0x1ebe);ReplacementFor_parser->ReplacementFor_toknext=
(0x601+4460-0x176d);ReplacementFor_parser->ReplacementFor_toksuper=-
(0x74a+5875-0x1e3c);}

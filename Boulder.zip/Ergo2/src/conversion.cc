
#include "../include/conversion.h"
#include "../include/definitions.h"
#include "../include/easylogging.h"
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int DecStrToHexStrOf64(const char*in,const uint32_t inlen,char*out){
#ifndef _WIN32
uint32_t fs[inlen];
#else
uint32_t fs[(0x1317+1356-0x1463)];
#endif
uint32_t tmp;uint32_t rem;uint32_t ip;for(int i=inlen-(0x1fc0+716-0x228b),k=
(0x13e8+3763-0x229b);i>=(0x482+4589-0x166f);--i){if(in[i]>=
((char)(0xe9d+2199-0x1704))&&in[i]<=((char)(0x26a+8538-0x238b))){fs[k++]=(
uint32_t)(in[i]-((char)(0x4d5+220-0x581)));}else{char errbuf[
(0x19a9+1929-0x1d32)];errbuf[(0x1d85+650-0x200f)]='\0';strncat(errbuf,in,inlen);
LOG(ERROR)<<
"\x44\x65\x63\x53\x74\x72\x54\x6f\x48\x65\x78\x53\x74\x72\x4f\x66\x36\x34\x20\x66\x61\x69\x6c\x65\x64\x20\x6f\x6e\x20\x73\x74\x72\x69\x6e\x67\x20"
<<errbuf;CALL((0x219b+1254-0x2681),ERROR_IO);}}uint32_t ts[(0xb94+5589-0x211f)]=
{(0x1d08+1642-0x2371)};uint32_t accs[(0x1a5a+562-0x1c42)]={(0x1dff+667-0x209a)};
for(uint_t i=(0x9b+8687-0x228a);i<inlen;++i){for(int j=(0x290+8160-0x2270);j<
(0xe5+5060-0x1469);++j){accs[j]+=ts[j]*fs[i];tmp=accs[j];rem=(0x1e0d+479-0x1fec)
;ip=j;do{rem=tmp>>(0x8a1+2508-0x1269);accs[ip++]=tmp-(rem<<(0x14df+2767-0x1faa))
;accs[ip]+=rem;tmp=accs[ip];}while(tmp>=(0xe09+4145-0x1e2a));}for(int j=
(0x33b+2179-0xbbe);j<(0x396+932-0x6fa);++j){ts[j]*=(0xc1a+3421-0x196d);}for(int 
j=(0xb79+1228-0x1045);j<(0x140f+460-0x159b);++j){tmp=ts[j];rem=
(0x1e1c+1066-0x2246);ip=j;do{rem=tmp>>(0x90c+4785-0x1bb9);ts[ip++]=tmp-(rem<<
(0xdcd+3605-0x1bde));ts[ip]+=rem;tmp=ts[ip];}while(tmp>=(0xe9f+3082-0x1a99));}}
for(int i=(0x1d09+527-0x1ed9);i>=(0x417+6692-0x1e3b);--i){out[(0x266+197-0x2ec)-
i]=(accs[i]<(0x148f+2816-0x1f85))?(char)(accs[i]+((char)(0xa51+7284-0x2695))):(
char)(accs[i]+((char)(0x5f7+5735-0x1c1d))-(0xeb8+1551-0x14bd));}out[
(0x1447+4096-0x2407)]='\0';return(0x30f+8624-0x24bf);}void HexStrToBigEndian(
const char*in,const uint32_t inlen,uint8_t*out,const uint32_t outlen){memset(out
,(0x72c+6604-0x20f8),outlen);for(uint_t i=(outlen<<(0x16a5+2787-0x2187))-inlen;i
<(outlen<<(0x137f+3866-0x2298));++i){out[i>>(0x919+5090-0x1cfa)]|=(((in[i]>=
((char)(0x7f2+109-0x81e)))?in[i]-((char)(0xcd7+1450-0x1240))+(0xafa+1808-0x1200)
:in[i]-((char)(0x1db+4293-0x1270)))&(0x8c7+1670-0xf3e))<<((!(i&
(0x415+6880-0x1ef4)))<<(0xbed+33-0xc0c));}return;}void HexStrToLittleEndian(
const char*in,const uint32_t inlen,uint8_t*out,const uint32_t outlen){memset(out
,(0xcc6+4595-0x1eb9),outlen);for(uint_t i=(0x1010+2349-0x193d);i<inlen;++i){out[
i>>(0x207+3588-0x100a)]|=(((in[inlen-i-(0x588+3972-0x150b)]>=
((char)(0xf0d+3486-0x1c6a)))?in[inlen-i-(0x7a6+4670-0x19e3)]-
((char)(0xa05+685-0xc71))+(0x1ff+4444-0x1351):in[inlen-i-(0x970+1743-0x103e)]-
((char)(0x739+7471-0x2438)))&(0x616+2060-0xe13))<<(((i&(0x1812+265-0x191a)))<<
(0x1c7d+135-0x1d02));}return;}void LittleEndianOf256ToDecStr(const uint8_t*in,
char*out,uint32_t*outlen){uint32_t fs[(0x12cc+3118-0x1eba)];uint32_t tmp;
uint32_t rem;uint32_t ip;for(int i=(0x6c4+559-0x8f3);i<(0x934+1393-0xe65);++i){
fs[i]=(uint32_t)(in[i>>(0x17ed+322-0x192e)]>>(((i&(0x13d3+2788-0x1eb6)))<<
(0x17e6+2486-0x219a)))&(0xc22+4635-0x1e2e);}uint32_t ts[(0xadf+3940-0x19e9)]={
(0x1af6+2104-0x232d)};uint32_t accs[(0x208+1017-0x5a7)]={(0x737+3815-0x161e)};
for(int i=(0x180+5151-0x159f);i<(0x89a+1739-0xf25);++i){for(int j=
(0x1370+793-0x1689);j<(0x1b9f+2890-0x269b);++j){accs[j]+=ts[j]*fs[i];tmp=accs[j]
;rem=(0x1128+3342-0x1e36);ip=j;do{rem=tmp/(0xb59+6564-0x24f3);accs[ip++]=tmp-rem
*(0x16a6+1458-0x1c4e);accs[ip]+=rem;tmp=accs[ip];}while(tmp>=(0xcdc+4617-0x1edb)
);}for(int j=(0xf1a+2385-0x186b);j<(0x686+7093-0x21ed);++j){ts[j]<<=
(0x136+2379-0xa7d);}for(int j=(0x9eb+6801-0x247c);j<(0xb5b+3906-0x1a4f);++j){tmp
=ts[j];rem=(0x172f+2817-0x2230);ip=j;do{rem=tmp/(0x18d0+2949-0x244b);ts[ip++]=
tmp-rem*(0xb17+2533-0x14f2);ts[ip]+=rem;tmp=ts[ip];}while(tmp>=(0x7b+2293-0x966)
);}}int k=(0x155+6836-0x1c09);int lead=(0x1e0a+339-0x1f5c);for(int i=
(0xb21+826-0xe0e);i>=(0xc02+200-0xcca);--i){if(lead){if(!(accs[i])){continue;}
else{lead=(0x19c5+1729-0x2086);}}out[k++]=(char)(accs[i]+
((char)(0x781+3475-0x14e4)));}out[k]='\0';*outlen=k;return;}void 
LittleEndianToHexStr(const uint8_t*in,const uint32_t inlen,char*out){uint8_t dig
;for(int i=(inlen<<(0x3f3+7540-0x2166))-(0x1cfd+610-0x1f5e);i>=
(0xcba+4799-0x1f79);--i){dig=(uint8_t)(in[i>>(0x1095+4965-0x23f9)]>>((i&
(0x9a6+4969-0x1d0e))<<(0x11eb+1065-0x1612)))&(0xcf1+3632-0x1b12);out[(inlen<<
(0x801+702-0xabe))-i-(0x11+8138-0x1fda)]=(dig<=(0x4f9+1080-0x928))?(char)dig+
((char)(0xb59+6953-0x2652)):(char)dig+((char)(0x15fa+2809-0x20b2))-
(0x1f5+3978-0x1175);}out[inlen<<(0xd98+6026-0x2521)]='\0';return;}void 
BigEndianToHexStr(const uint8_t*in,const uint32_t inlen,char*out){uint8_t dig;
for(uint_t i=(0x16d3+2989-0x2280);i<inlen<<(0x278+384-0x3f7);++i){dig=(uint8_t)(
in[i>>(0xcd7+5649-0x22e7)]>>(!(i&(0x13a+1091-0x57c))<<(0xbcd+2934-0x1741)))&
(0x643+4795-0x18ef);out[i]=(dig<=(0xb52+3201-0x17ca))?(char)dig+
((char)(0x751+1359-0xc70)):(char)dig+((char)(0x815+7671-0x25cb))-
(0x131+7181-0x1d34);}out[inlen<<(0x87f+1364-0xdd2)]='\0';return;}

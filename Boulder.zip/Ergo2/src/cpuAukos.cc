
#include "../include/cpuAukos.h"
AukosAlg::AukosAlg(){m_str=new char[(0xf16+5638-0x24dc)];bound_str=new char[
(0xde7+1012-0x1177)];m_n=new uint8_t[NUM_SIZE_8+NONCE_SIZE_8];p_w_m_n=new 
uint8_t[PK_SIZE_8+PK_SIZE_8+NUM_SIZE_8+NONCE_SIZE_8];Hinput=new uint8_t[sizeof(
uint32_t)+CONST_MES_SIZE_8+PK_SIZE_8+NUM_SIZE_8+PK_SIZE_8];n_str=new char[
NONCE_SIZE_4];h_str=new char[HEIGHT_SIZE];int tr=sizeof(unsigned long long);for(
size_t i=(0x744+2288-0x1034);i<CONST_MES_SIZE_8/tr;i++){unsigned long long tmp=i
;uint8_t tmp2[(0x9db+2840-0x14eb)];uint8_t tmp1[(0x82a+6624-0x2202)];memcpy(tmp1
,&tmp,tr);tmp2[(0x1591+718-0x185f)]=tmp1[(0xbff+529-0xe09)];tmp2[
(0x10b2+465-0x1282)]=tmp1[(0x13a8+2152-0x1c0a)];tmp2[(0x3ba+3897-0x12f1)]=tmp1[
(0x6d+2810-0xb62)];tmp2[(0x12e7+2566-0x1cea)]=tmp1[(0x6da+5007-0x1a65)];tmp2[
(0x2460+164-0x2500)]=tmp1[(0x165f+3179-0x22c7)];tmp2[(0x121+5161-0x1545)]=tmp1[
(0x1a53+902-0x1dd7)];tmp2[(0x10c+2163-0x979)]=tmp1[(0xafb+2315-0x1405)];tmp2[
(0x1e7+3902-0x111e)]=tmp1[(0x5c3+122-0x63d)];memcpy(&CONST_MESS[i],tmp2,tr);}}
AukosAlg::~AukosAlg(){}void AukosAlg::Blake2b256(const char*in,const int len,
uint8_t*output,char*outstr){ctx_t ctx;uint64_t aux[(0x1f1c+669-0x2199)];memset(
ctx.b,(0x197b+1289-0x1e84),(0xa23+6803-0x2436));B2B_IV(ctx.h);ctx.h[
(0x11a2+897-0x1523)]^=16842752^NUM_SIZE_8;memset(ctx.t,(0x1fab+1550-0x25b9),
(0x8e1+723-0xba4));ctx.c=(0x19b6+2858-0x24e0);for(int i=(0x11f+3050-0xd09);i<len
;++i){if(ctx.c==(0x1ce2+271-0x1d71)){HOST_B2B_H(&ctx,aux);}ctx.b[ctx.c++]=(
uint8_t)(in[i]);}HOST_B2B_H_LAST(&ctx,aux);for(int i=(0x51c+174-0x5ca);i<
NUM_SIZE_8;++i){output[NUM_SIZE_8-i-(0xc21+6584-0x25d8)]=(ctx.h[i>>
(0x1464+1707-0x1b0c)]>>((i&(0x97a+906-0xcfd))<<(0x508+558-0x733)))&
(0x1ba1+34-0x1ac4);}LittleEndianToHexStr(output,NUM_SIZE_8,outstr);}void 
AukosAlg::GenIdex(const char*in,const int len,uint32_t*index){int a=INDEX_SIZE_8
;int b=K_LEN;int c=NUM_SIZE_8;int d=NUM_SIZE_4;uint8_t sk[NUM_SIZE_8*
(0x84c+4735-0x1ac9)];char skstr[NUM_SIZE_4+(0xfbf+5587-0x2588)];memset(sk,
(0x139f+4700-0x25fb),NUM_SIZE_8*(0x1852+2512-0x2220));memset(skstr,
(0x313+7899-0x21ee),NUM_SIZE_4);Blake2b256(in,len,sk,skstr);uint8_t beH[
PK_SIZE_8];HexStrToBigEndian(skstr,NUM_SIZE_4,beH,NUM_SIZE_8);uint32_t*ind=index
;memcpy(sk,beH,NUM_SIZE_8);memcpy(sk+NUM_SIZE_8,beH,NUM_SIZE_8);uint32_t tmpInd[
(0x1b9+3050-0xd83)];int sliceIndex=(0x11a2+3363-0x1ec5);for(int k=
(0x6eb+658-0x97d);k<K_LEN;k++){uint8_t tmp[(0x15c1+3889-0x24ee)];memcpy(tmp,sk+
sliceIndex,(0x10e8+2686-0x1b62));memcpy(&tmpInd[k],sk+sliceIndex,
(0x118a+2063-0x1995));uint8_t tmp2[(0x466+3761-0x1313)];tmp2[
(0x1ada+2045-0x22d7)]=tmp[(0xc0+4605-0x12ba)];tmp2[(0x212a+391-0x22b0)]=tmp[
(0x909+824-0xc3f)];tmp2[(0xb47+5229-0x1fb2)]=tmp[(0x6ac+6543-0x203a)];tmp2[
(0x77a+4967-0x1ade)]=tmp[(0x229+7788-0x2095)];memcpy(&ind[k],tmp2,
(0x7ef+2534-0x11d1));ind[k]=ind[k]%N_LEN;sliceIndex++;}}void AukosAlg::hashFn(
const char*in,const int len,uint8_t*output){char*skstr=new char[len*
(0x1c40+2744-0x26f5)];Blake2b256(in,len,output,skstr);uint8_t beHash[PK_SIZE_8];
HexStrToBigEndian(skstr,NUM_SIZE_4,beHash,NUM_SIZE_8);memcpy(output,beHash,
NUM_SIZE_8);delete skstr;}bool AukosAlg::RunAlg(uint8_t*message,uint8_t*nonce,
uint8_t*bPool,uint8_t*height){BigEndianToHexStr(message,NUM_SIZE_8,m_str);
uint32_t ilen=(0xbc3+6367-0x24a2);LittleEndianOf256ToDecStr((uint8_t*)bPool,
bound_str,&ilen);uint32_t index[K_LEN];LittleEndianToHexStr(nonce,NONCE_SIZE_8,
n_str);BigEndianToHexStr(height,HEIGHT_SIZE,h_str);uint8_t beN[NONCE_SIZE_8];
HexStrToBigEndian(n_str,NONCE_SIZE_8*(0x3e0+8528-0x252e),beN,NONCE_SIZE_8);
uint8_t beH[HEIGHT_SIZE];HexStrToBigEndian(h_str,HEIGHT_SIZE*(0x91a+5912-0x2030)
,beH,HEIGHT_SIZE);uint8_t h1[NUM_SIZE_8];memcpy(m_n,message,NUM_SIZE_8);memcpy(
m_n+NUM_SIZE_8,beN,NONCE_SIZE_8);hashFn((const char*)m_n,NUM_SIZE_8+NONCE_SIZE_8
,(uint8_t*)h1);uint64_t h2;char tmpL1[(0x99c+1452-0xf40)];tmpL1[
(0x1f2b+1536-0x252b)]=h1[(0x2a0+4147-0x12b4)];tmpL1[(0x26b+186-0x324)]=h1[
(0x796+2827-0x1283)];tmpL1[(0x443+2484-0xdf5)]=h1[(0x1093+547-0x1299)];tmpL1[
(0x1376+797-0x1690)]=h1[(0x174a+2210-0x1fd0)];tmpL1[(0x3b+1361-0x588)]=h1[
(0x2471+195-0x2519)];tmpL1[(0x1bed+2652-0x2644)]=h1[(0x568+1327-0xa7d)];tmpL1[
(0x1347+2273-0x1c22)]=h1[(0x1d66+364-0x1eb9)];tmpL1[(0xa2+6500-0x19ff)]=h1[
(0x603+3929-0x1544)];memcpy(&h2,tmpL1,(0x20a4+1582-0x26ca));unsigned int h3=h2%
N_LEN;uint8_t iii[(0xea1+2445-0x182a)];iii[(0xb1a+6275-0x239d)]=((char*)(&h3))[
(0xdaa+1676-0x1433)];iii[(0x221+5970-0x1972)]=((char*)(&h3))[(0x780+885-0xaf3)];
iii[(0x143c+3709-0x22b7)]=((char*)(&h3))[(0x1706+470-0x18db)];iii[
(0xc3d+728-0xf12)]=((char*)(&h3))[(0x1e88+1789-0x2585)];uint8_t i_h_M[
HEIGHT_SIZE+HEIGHT_SIZE+CONST_MES_SIZE_8];memcpy(i_h_M,iii,HEIGHT_SIZE);memcpy(
i_h_M+HEIGHT_SIZE,beH,HEIGHT_SIZE);memcpy(i_h_M+HEIGHT_SIZE+HEIGHT_SIZE,
CONST_MESS,CONST_MES_SIZE_8);hashFn((const char*)i_h_M,HEIGHT_SIZE+HEIGHT_SIZE+
CONST_MES_SIZE_8,(uint8_t*)h1);uint8_t ff[NUM_SIZE_8-(0xfe1+1894-0x1746)];memcpy
(ff,h1+(0x20f+3007-0xdcd),NUM_SIZE_8-(0x3a6+6002-0x1b17));uint8_t seed[
NUM_SIZE_8-(0x1d90+537-0x1fa8)+NUM_SIZE_8+NONCE_SIZE_8];memcpy(seed,ff,
NUM_SIZE_8-(0x16c9+1482-0x1c92));memcpy(seed+NUM_SIZE_8-(0x133+4924-0x146e),
message,NUM_SIZE_8);memcpy(seed+NUM_SIZE_8-(0x1415+2072-0x1c2c)+NUM_SIZE_8,beN,
NONCE_SIZE_8);GenIdex((const char*)seed,NUM_SIZE_8-(0x87f+854-0xbd4)+NUM_SIZE_8+
NONCE_SIZE_8,index);uint8_t ret[(0x782+3600-0x1572)][NUM_SIZE_8];int ll=sizeof(
uint32_t)+CONST_MES_SIZE_8+PK_SIZE_8+NUM_SIZE_8+PK_SIZE_8;BIGNUM*bigsum=BN_new()
;CALL(BN_dec2bn(&bigsum,"\x30"),ERROR_OPENSSL);BIGNUM*bigres=BN_new();CALL(
BN_dec2bn(&bigres,"\x30"),ERROR_OPENSSL);int rep=(0x1175+4329-0x225e);int off=
(0x769+5726-0x1dc7);uint8_t tmp[NUM_SIZE_8-(0x1d1a+1414-0x229f)];char hesStr[
(0x720+316-0x81c)+(0xa6+8780-0x22f1)];uint8_t tmp2[(0x16bf+976-0x1a8b)];uint8_t 
tmp1[(0x23b+6665-0x1c40)];unsigned char f[(0x1c9+8117-0x215e)];memset(f,
(0x771+2421-0x10e6),(0xd2a+1317-0x122f));char*LSUMM;char*LB;for(rep=
(0x118c+2202-0x1a26);rep<(0x2e6+3811-0x11a9);rep++){memset(Hinput,
(0x1682+1565-0x1c9f),ll);memcpy(tmp1,&index[rep],(0xeb3+2438-0x1835));tmp2[
(0x4b6+2063-0xcc5)]=tmp1[(0x76c+2573-0x1176)];tmp2[(0x78c+1738-0xe55)]=tmp1[
(0x631+5929-0x1d58)];tmp2[(0x21f+7996-0x2159)]=tmp1[(0xc8+9538-0x2609)];tmp2[
(0x1a6c+1895-0x21d0)]=tmp1[(0x1233+3340-0x1f3f)];off=(0xf08+3632-0x1d38);memcpy(
Hinput+off,tmp2,sizeof(uint32_t));off+=sizeof(uint32_t);memcpy(Hinput+off,beH,
HEIGHT_SIZE);off+=HEIGHT_SIZE;memcpy(Hinput+off,CONST_MESS,CONST_MES_SIZE_8);off
+=CONST_MES_SIZE_8;hashFn((const char*)Hinput,off,(uint8_t*)ret[rep]);memcpy(tmp
,&(ret[rep][(0x15a1+1703-0x1c47)]),(0xcdd+6151-0x24c5));CALL(BN_bin2bn((const 
unsigned char*)tmp,(0xfb+8721-0x22ed),bigres),ERROR_OPENSSL);CALL(BN_add(bigsum,
bigsum,bigres),ERROR_OPENSSL);LB=BN_bn2dec(bigres);BN_bn2bin(bigsum,f);}const 
char*SUMMbigEndian=BN_bn2dec(bigsum);BN_bn2bin(bigsum,f);char bigendian2littl[
(0x1954+1058-0x1d56)];for(size_t i=(0xc5+3965-0x1042);i<(0x96a+1454-0xef8);i++){
bigendian2littl[i]=f[(0xe66+3190-0x1abc)-i-(0x1a91+1505-0x2071)];}BIGNUM*littleF
=BN_new();CALL(BN_bin2bn((const unsigned char*)bigendian2littl,
(0x3c0+5794-0x1a42),littleF),ERROR_OPENSSL);const char*SUMMLittleEndian=
BN_bn2dec(littleF);char hf[(0xc83+4962-0x1fc5)];hashFn((const char*)f,
(0xcea+4996-0x204e),(uint8_t*)hf);BIGNUM*bigHF=BN_new();CALL(BN_bin2bn((const 
unsigned char*)hf,(0x1469+4368-0x2559),bigHF),ERROR_OPENSSL);char littl2big[
(0xb30+1804-0x121c)];for(size_t i=(0x1b87+822-0x1ebd);i<(0x18b+6550-0x1b01);i++)
{littl2big[i]=bPool[(0xdac+1827-0x14af)-i-(0x18c9+3654-0x270e)];}BIGNUM*bigB=
BN_new();CALL(BN_bin2bn((const unsigned char*)littl2big,(0x2178+296-0x2280),bigB
),ERROR_OPENSSL);int cmp=BN_cmp(bigHF,bigB);const char*chD=BN_bn2dec(bigHF);
const char*chB=BN_bn2dec(bigB);BN_free(bigsum);BN_free(bigres);BN_free(littleF);
BN_free(bigHF);BN_free(bigB);if(cmp<(0x1070+1911-0x17e7)){return true;}else{
return false;}}

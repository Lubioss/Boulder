
#include "../include/cryptography.h"
#include "../include/conversion.h"
#include "../include/definitions.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/bn.h>
#include <openssl/ec.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/opensslv.h>
#include <random>
int GenerateSecKey(const char*in,const int len,uint8_t*sk,char*skstr){ctx_t ctx;
uint64_t aux[(0x730+1120-0xb70)];memset(ctx.b,(0x112b+3457-0x1eac),
(0x198a+906-0x1c94));B2B_IV(ctx.h);ctx.h[(0xfcd+1866-0x1717)]^=16842752^
NUM_SIZE_8;memset(ctx.t,(0x8d2+3025-0x14a3),(0x622+5975-0x1d69));ctx.c=
(0x1553+2568-0x1f5b);for(int i=(0x74+7627-0x1e3f);i<len;++i){if(ctx.c==
(0x5ed+6316-0x1e19)){HOST_B2B_H(&ctx,aux);}ctx.b[ctx.c++]=(uint8_t)(in[i]);}
HOST_B2B_H_LAST(&ctx,aux);for(int i=(0x1100+5268-0x2594);i<NUM_SIZE_8;++i){sk[
NUM_SIZE_8-i-(0x1160+2357-0x1a94)]=(ctx.h[i>>(0x116a+4596-0x235b)]>>((i&
(0xcf3+2797-0x17d9))<<(0x20e3+513-0x22e1)))&(0x7f0+6829-0x219e);}uint8_t borrow[
(0x148a+38-0x14ae)];borrow[(0xf9b+2013-0x1778)]=((uint64_t*)sk)[
(0x5ff+5277-0x1a9c)]<Q0;aux[(0x90c+4406-0x1a42)]=((uint64_t*)sk)[
(0xd8d+4234-0x1e17)]-Q0;borrow[(0x7a+3343-0xd88)]=((uint64_t*)sk)[
(0x14dd+2750-0x1f9a)]<Q1+borrow[(0x4c3+6459-0x1dfe)];aux[(0x4d6+365-0x642)]=((
uint64_t*)sk)[(0x4d8+5988-0x1c3b)]-Q1-borrow[(0x20c3+455-0x228a)];borrow[
(0x72f+6592-0x20ef)]=((uint64_t*)sk)[(0x2bd+4295-0x1382)]<Q2+borrow[
(0x1308+2278-0x1bed)];aux[(0x889+6557-0x2224)]=((uint64_t*)sk)[
(0x2135+335-0x2282)]-Q2-borrow[(0xac2+4153-0x1afa)];borrow[(0x1c0f+295-0x1d35)]=
((uint64_t*)sk)[(0x94d+3328-0x164a)]<Q3+borrow[(0x186+84-0x1da)];aux[
(0x5d0+6085-0x1d92)]=((uint64_t*)sk)[(0x69c+7950-0x25a7)]-Q3-borrow[
(0x946+3301-0x162b)];if(!(borrow[(0x1287+5213-0x26e3)]||borrow[
(0x2c0+9077-0x2635)])){memcpy(sk,aux,NUM_SIZE_8);}LittleEndianToHexStr(sk,
NUM_SIZE_8,skstr);return EXIT_SUCCESS;}int GenerateSecKeyNew(const char*in,const
 int len,uint8_t*sk,char*skstr,char*passphrase){unsigned char digest[NUM_SIZE_4]
;char salt[(0xf45+1001-0xf2e)]="\x6d\x6e\x65\x6d\x6f\x6e\x69\x63";strcat(salt,
passphrase);PKCS5_PBKDF2_HMAC(in,len,(unsigned char*)salt,strlen(salt),
(0xbcf+370-0x541),EVP_sha512(),NUM_SIZE_4,digest);uint_t hmaclen=NUM_SIZE_4;char
 key[]="\x42\x69\x74\x63\x6f\x69\x6e\x20\x73\x65\x65\x64";unsigned char result[
NUM_SIZE_4];
#if OPENSSL_VERSION_NUMBER < 0x10100000L
HMAC_CTX ctx;HMAC_CTX_init(&ctx);HMAC_Init_ex(&ctx,key,strlen(key),EVP_sha512(),
NULL);HMAC_Update(&ctx,digest,NUM_SIZE_4);HMAC_Final(&ctx,result,&hmaclen);
HMAC_CTX_cleanup(&ctx);memcpy(sk,result,sizeof(uint8_t)*NUM_SIZE_8);
LittleEndianToHexStr(sk,NUM_SIZE_8,skstr);HexStrToBigEndian(skstr,NUM_SIZE_4,sk,
NUM_SIZE_8);LittleEndianToHexStr(sk,NUM_SIZE_8,skstr);
#else 
HMAC_CTX*ctx=HMAC_CTX_new();HMAC_Init_ex(ctx,key,strlen(key),EVP_sha512(),NULL);
HMAC_Update(ctx,digest,NUM_SIZE_4);HMAC_Final(ctx,result,&hmaclen);memcpy(sk,
result,sizeof(uint8_t)*NUM_SIZE_8);HMAC_CTX_free(ctx);LittleEndianToHexStr(sk,
NUM_SIZE_8,skstr);HexStrToBigEndian(skstr,NUM_SIZE_4,sk,NUM_SIZE_8);
LittleEndianToHexStr(sk,NUM_SIZE_8,skstr);
#endif
return EXIT_SUCCESS;}int GenerateKeyPair(uint8_t*sk,uint8_t*pk){EC_KEY*eck=NULL;
EVP_PKEY*evpk=NULL;FUNCTION_CALL(eck,EC_KEY_new_by_curve_name(NID_secp256k1),
ERROR_OPENSSL);EC_KEY_set_asn1_flag(eck,OPENSSL_EC_NAMED_CURVE);CALL(
EC_KEY_generate_key(eck),ERROR_OPENSSL);evpk=EVP_PKEY_new();CALL(
EVP_PKEY_assign_EC_KEY(evpk,eck),ERROR_OPENSSL);FUNCTION_CALL(eck,
EVP_PKEY_get1_EC_KEY(evpk),ERROR_OPENSSL);const EC_GROUP*group=EC_KEY_get0_group
(eck);const EC_POINT*ecp=EC_KEY_get0_public_key(eck);CALL(group,ERROR_OPENSSL);
CALL(ecp,ERROR_OPENSSL);char*str;FUNCTION_CALL(str,EC_POINT_point2hex(group,ecp,
POINT_CONVERSION_COMPRESSED,NULL),ERROR_OPENSSL);int len=(0x11f8+4314-0x22d2);
for(;str[len]!='\0';++len){}HexStrToBigEndian(str,len,pk,PK_SIZE_8);OPENSSL_free
(str);str=NULL;const BIGNUM*bn=EC_KEY_get0_private_key(eck);CALL(bn,
ERROR_OPENSSL);FUNCTION_CALL(str,BN_bn2hex(bn),ERROR_OPENSSL);len=
(0xd47+3782-0x1c0d);for(;str[len]!='\0';++len){}HexStrToLittleEndian(str,len,sk,
NUM_SIZE_8);OPENSSL_free(str);EVP_PKEY_free(evpk);EC_KEY_free(eck);return 
EXIT_SUCCESS;}int GeneratePublicKey(const char*skstr,char*pkstr,uint8_t*pk){
EC_KEY*eck=NULL;EC_POINT*sec=NULL;BIGNUM*res;BN_CTX*ctx;FUNCTION_CALL(ctx,
BN_CTX_new(),ERROR_OPENSSL);res=BN_new();CALL(BN_hex2bn(&res,skstr),
ERROR_OPENSSL);FUNCTION_CALL(eck,EC_KEY_new_by_curve_name(NID_secp256k1),
ERROR_OPENSSL);const EC_GROUP*group=EC_KEY_get0_group(eck);CALL(group,
ERROR_OPENSSL);FUNCTION_CALL(sec,EC_POINT_new(group),ERROR_OPENSSL);CALL(
EC_KEY_set_private_key(eck,res),ERROR_OPENSSL);CALL(EC_POINT_mul(group,sec,res,
NULL,NULL,ctx),ERROR_OPENSSL);CALL(EC_KEY_set_public_key(eck,sec),ERROR_OPENSSL)
;const EC_POINT*pub=EC_KEY_get0_public_key(eck);CALL(pub,ERROR_OPENSSL);char*str
;FUNCTION_CALL(str,EC_POINT_point2hex(group,pub,POINT_CONVERSION_COMPRESSED,NULL
),ERROR_OPENSSL);strcpy(pkstr,str);int len=(0x975+340-0xac9);for(;str[len]!='\0'
;++len){}HexStrToBigEndian(str,len,pk,PK_SIZE_8);OPENSSL_free(str);BN_CTX_free(
ctx);BN_free(res);EC_KEY_free(eck);return EXIT_SUCCESS;}int checkRandomDevice(){
std::random_device rd1;std::random_device rd2;if(rd1()==rd2())return 
EXIT_FAILURE;if(rd1()==rd2())return EXIT_FAILURE;return EXIT_SUCCESS;}

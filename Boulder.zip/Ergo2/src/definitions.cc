
#include "../include/definitions.h"
#include "../include/jsmn.h"
#include <stddef.h>
json_t::json_t(const int strlen,const int toklen){cap=strlen?strlen+
(0x173+6362-0x1a4c):JSON_CAPACITY+(0x2358+701-0x2614);len=strlen;FUNCTION_CALL(
ptr,(char*)malloc(cap),ERROR_ALLOC);ptr[len]='\0';FUNCTION_CALL(toks,(jsmntok_t*
)malloc(toklen*sizeof(jsmntok_t)),ERROR_ALLOC);return;}json_t::json_t(const 
json_t&newjson){cap=newjson.cap;len=newjson.len;FREE(ptr);ptr=newjson.ptr;FREE(
toks);toks=newjson.toks;return;}json_t::~json_t(void){FREE(ptr);FREE(toks);
return;}int json_t::jsoneq(const int pos,const char*str){if(toks[pos].type==
JSMN_STRING&&(int)strlen(str)==GetTokenLen(pos)&&!strncmp(GetTokenStart(pos),str
,GetTokenLen(pos))){return(0x7fc+3890-0x172d);}return(0x8e4+3870-0x1802);}

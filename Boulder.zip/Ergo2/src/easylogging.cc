
#include "../include/easylogging.h"
#if defined(AUTO_INITIALIZE_EASYLOGGINGPP)
INITIALIZE_EASYLOGGINGPP
#endif
namespace el{namespace base{namespace consts{static const base::type::char_t*
kInfoLevelLogValue=ELPP_LITERAL("\x49\x4e\x46\x4f");static const base::type::
char_t*kDebugLevelLogValue=ELPP_LITERAL("\x44\x45\x42\x55\x47");static const 
base::type::char_t*kWarningLevelLogValue=ELPP_LITERAL(
"\x57\x41\x52\x4e\x49\x4e\x47");static const base::type::char_t*
kErrorLevelLogValue=ELPP_LITERAL("\x45\x52\x52\x4f\x52");static const base::type
::char_t*kFatalLevelLogValue=ELPP_LITERAL("\x46\x41\x54\x41\x4c");static const 
base::type::char_t*kVerboseLevelLogValue=ELPP_LITERAL(
"\x56\x45\x52\x42\x4f\x53\x45");static const base::type::char_t*
kTraceLevelLogValue=ELPP_LITERAL("\x54\x52\x41\x43\x45");static const base::type
::char_t*kInfoLevelShortLogValue=ELPP_LITERAL("\x49");static const base::type::
char_t*kDebugLevelShortLogValue=ELPP_LITERAL("\x44");static const base::type::
char_t*kWarningLevelShortLogValue=ELPP_LITERAL("\x57");static const base::type::
char_t*kErrorLevelShortLogValue=ELPP_LITERAL("\x45");static const base::type::
char_t*kFatalLevelShortLogValue=ELPP_LITERAL("\x46");static const base::type::
char_t*kVerboseLevelShortLogValue=ELPP_LITERAL("\x56");static const base::type::
char_t*kTraceLevelShortLogValue=ELPP_LITERAL("\x54");static const base::type::
char_t*kAppNameFormatSpecifier=ELPP_LITERAL("\x25\x61\x70\x70");static const 
base::type::char_t*kLoggerIdFormatSpecifier=ELPP_LITERAL(
"\x25\x6c\x6f\x67\x67\x65\x72");static const base::type::char_t*
kThreadIdFormatSpecifier=ELPP_LITERAL("\x25\x74\x68\x72\x65\x61\x64");static 
const base::type::char_t*kSeverityLevelFormatSpecifier=ELPP_LITERAL(
"\x25\x6c\x65\x76\x65\x6c");static const base::type::char_t*
kSeverityLevelShortFormatSpecifier=ELPP_LITERAL(
"\x25\x6c\x65\x76\x73\x68\x6f\x72\x74");static const base::type::char_t*
kDateTimeFormatSpecifier=ELPP_LITERAL("\x25\x64\x61\x74\x65\x74\x69\x6d\x65");
static const base::type::char_t*kLogFileFormatSpecifier=ELPP_LITERAL(
"\x25\x66\x69\x6c\x65");static const base::type::char_t*
kLogFileBaseFormatSpecifier=ELPP_LITERAL("\x25\x66\x62\x61\x73\x65");static 
const base::type::char_t*kLogLineFormatSpecifier=ELPP_LITERAL(
"\x25\x6c\x69\x6e\x65");static const base::type::char_t*
kLogLocationFormatSpecifier=ELPP_LITERAL("\x25\x6c\x6f\x63");static const base::
type::char_t*kLogFunctionFormatSpecifier=ELPP_LITERAL("\x25\x66\x75\x6e\x63");
static const base::type::char_t*kCurrentUserFormatSpecifier=ELPP_LITERAL(
"\x25\x75\x73\x65\x72");static const base::type::char_t*
kCurrentHostFormatSpecifier=ELPP_LITERAL("\x25\x68\x6f\x73\x74");static const 
base::type::char_t*kMessageFormatSpecifier=ELPP_LITERAL("\x25\x6d\x73\x67");
static const base::type::char_t*kVerboseLevelFormatSpecifier=ELPP_LITERAL(
"\x25\x76\x6c\x65\x76\x65\x6c");static const char*
kDateTimeFormatSpecifierForFilename="\x25\x64\x61\x74\x65\x74\x69\x6d\x65";
static const char*kDays[(0x7c1+5938-0x1eec)]={"\x53\x75\x6e\x64\x61\x79",
"\x4d\x6f\x6e\x64\x61\x79","\x54\x75\x65\x73\x64\x61\x79",
"\x57\x65\x64\x6e\x65\x73\x64\x61\x79","\x54\x68\x75\x72\x73\x64\x61\x79",
"\x46\x72\x69\x64\x61\x79","\x53\x61\x74\x75\x72\x64\x61\x79"};static const char
*kDaysAbbrev[(0x37c+6325-0x1c2a)]={"\x53\x75\x6e","\x4d\x6f\x6e","\x54\x75\x65",
"\x57\x65\x64","\x54\x68\x75","\x46\x72\x69","\x53\x61\x74"};static const char*
kMonths[(0x1f6+1054-0x608)]={"\x4a\x61\x6e\x75\x61\x72\x79",
"\x46\x65\x62\x72\x75\x61\x72\x79","\x4d\x61\x72\x63\x68","\x41\x70\x72\x69",
"\x4d\x61\x79","\x4a\x75\x6e\x65","\x4a\x75\x6c\x79","\x41\x75\x67\x75\x73\x74",
"\x53\x65\x70\x74\x65\x6d\x62\x65\x72","\x4f\x63\x74\x6f\x62\x65\x72",
"\x4e\x6f\x76\x65\x6d\x62\x65\x72","\x44\x65\x63\x65\x6d\x62\x65\x72"};static 
const char*kMonthsAbbrev[(0x18e6+1599-0x1f19)]={"\x4a\x61\x6e","\x46\x65\x62",
"\x4d\x61\x72","\x41\x70\x72","\x4d\x61\x79","\x4a\x75\x6e","\x4a\x75\x6c",
"\x41\x75\x67","\x53\x65\x70","\x4f\x63\x74","\x4e\x6f\x76","\x44\x65\x63"};
static const char*kDefaultDateTimeFormat=
"\x25\x59\x2d\x25\x4d\x2d\x25\x64\x20\x25\x48\x3a\x25\x6d\x3a\x25\x73\x2c\x25\x67"
;static const char*kDefaultDateTimeFormatInFilename=
"\x25\x59\x2d\x25\x4d\x2d\x25\x64\x5f\x25\x48\x2d\x25\x6d";static const int 
kYearBase=(0x111c+1393-0xf21);static const char*kAm="\x41\x4d";static const char
*kPm="\x50\x4d";static const char*kNullPointer="\x6e\x75\x6c\x6c\x70\x74\x72";
#if ELPP_VARIADIC_TEMPLATES_SUPPORTED
#endif  
static const base::type::VerboseLevel kMaxVerboseLevel=(0x94a+1968-0x10f1);
static const char*kUnknownUser="\x75\x73\x65\x72";static const char*kUnknownHost
="\x75\x6e\x6b\x6e\x6f\x77\x6e\x2d\x68\x6f\x73\x74";
#if defined(ELPP_NO_DEFAULT_LOG_FILE)
#  if ELPP_OS_UNIX
static const char*kDefaultLogFile="\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c";
#  elif ELPP_OS_WINDOWS
static const char*kDefaultLogFile="\x6e\x75\x6c";
#  endif  
#elif defined(ELPP_DEFAULT_LOG_FILE)
static const char*kDefaultLogFile=ELPP_DEFAULT_LOG_FILE;
#else
static const char*kDefaultLogFile="\x2e\x6d\x59\x6c\x4f\x47\x2e\x4c\x6f\x47";
#endif 
#if !defined(ELPP_DISABLE_LOG_FILE_FROM_ARG)
static const char*kDefaultLogFileParam=
"\x2d\x2d\x64\x65\x66\x61\x75\x6c\x74\x2d\x6c\x6f\x67\x2d\x66\x69\x6c\x65";
#endif  
#if defined(ELPP_LOGGING_FLAGS_FROM_ARG)
static const char*kLoggingFlagsParam=
"\x2d\x2d\x6c\x6f\x67\x67\x69\x6e\x67\x2d\x66\x6c\x61\x67\x73";
#endif  
static const char*kValidLoggerIdSymbols=
"\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x2d\x2e\x5f"
;static const char*kConfigurationComment="\x23\x23";static const char*
kConfigurationLevel="\x2a";static const char*kConfigurationLoggerId="\x2d\x2d";}
namespace utils{static void abort(int status,const std::string&reason){
ELPP_UNUSED(status);ELPP_UNUSED(reason);
#if defined(ELPP_COMPILER_MSVC) && defined(_M_IX86) && defined(_DEBUG)
_asm int(0x1349+2516-0x1d1a)
#else
::abort();
#endif
}}}const char*LevelHelper::convertToString(Level level){if(level==Level::Global)
return"\x47\x4c\x4f\x42\x41\x4c";if(level==Level::Debug)return
"\x44\x45\x42\x55\x47";if(level==Level::Info)return"\x49\x4e\x46\x4f";if(level==
Level::Warning)return"\x57\x41\x52\x4e\x49\x4e\x47";if(level==Level::Error)
return"\x45\x52\x52\x4f\x52";if(level==Level::Fatal)return"\x46\x41\x54\x41\x4c"
;if(level==Level::Verbose)return"\x56\x45\x52\x42\x4f\x53\x45";if(level==Level::
Trace)return"\x54\x52\x41\x43\x45";return"\x55\x4e\x4b\x4e\x4f\x57\x4e";}struct 
StringToLevelItem{const char*levelString;Level level;};static struct 
StringToLevelItem stringToLevelMap[]={{"\x67\x6c\x6f\x62\x61\x6c",Level::Global}
,{"\x64\x65\x62\x75\x67",Level::Debug},{"\x69\x6e\x66\x6f",Level::Info},{
"\x77\x61\x72\x6e\x69\x6e\x67",Level::Warning},{"\x65\x72\x72\x6f\x72",Level::
Error},{"\x66\x61\x74\x61\x6c",Level::Fatal},{"\x76\x65\x72\x62\x6f\x73\x65",
Level::Verbose},{"\x74\x72\x61\x63\x65",Level::Trace}};Level LevelHelper::
convertFromString(const char*levelStr){for(auto&item:stringToLevelMap){if(base::
utils::Str::cStringCaseEq(levelStr,item.levelString)){return item.level;}}return
 Level::Unknown;}void LevelHelper::forEachLevel(base::type::EnumType*startIndex,
const std::function<bool(void)>&fn){base::type::EnumType lIndexMax=LevelHelper::
kMaxValid;do{if(fn()){break;}*startIndex=static_cast<base::type::EnumType>(*
startIndex<<(0xe71+1596-0x14ac));}while(*startIndex<=lIndexMax);}const char*
ConfigurationTypeHelper::convertToString(ConfigurationType configurationType){if
(configurationType==ConfigurationType::Enabled)return
"\x45\x4e\x41\x42\x4c\x45\x44";if(configurationType==ConfigurationType::Filename
)return"\x46\x49\x4c\x45\x4e\x41\x4d\x45";if(configurationType==
ConfigurationType::Format)return"\x46\x4f\x52\x4d\x41\x54";if(configurationType
==ConfigurationType::ToFile)return"\x54\x4f\x5f\x46\x49\x4c\x45";if(
configurationType==ConfigurationType::ToStandardOutput)return
"\x54\x4f\x5f\x53\x54\x41\x4e\x44\x41\x52\x44\x5f\x4f\x55\x54\x50\x55\x54";if(
configurationType==ConfigurationType::SubsecondPrecision)return
"\x53\x55\x42\x53\x45\x43\x4f\x4e\x44\x5f\x50\x52\x45\x43\x49\x53\x49\x4f\x4e";
if(configurationType==ConfigurationType::PerformanceTracking)return
"\x50\x45\x52\x46\x4f\x52\x4d\x41\x4e\x43\x45\x5f\x54\x52\x41\x43\x4b\x49\x4e\x47"
;if(configurationType==ConfigurationType::MaxLogFileSize)return
"\x4d\x41\x58\x5f\x4c\x4f\x47\x5f\x46\x49\x4c\x45\x5f\x53\x49\x5a\x45";if(
configurationType==ConfigurationType::LogFlushThreshold)return
"\x4c\x4f\x47\x5f\x46\x4c\x55\x53\x48\x5f\x54\x48\x52\x45\x53\x48\x4f\x4c\x44";
return"\x55\x4e\x4b\x4e\x4f\x57\x4e";}struct ConfigurationStringToTypeItem{const
 char*configString;ConfigurationType configType;};static struct 
ConfigurationStringToTypeItem configStringToTypeMap[]={{
"\x65\x6e\x61\x62\x6c\x65\x64",ConfigurationType::Enabled},{
"\x74\x6f\x5f\x66\x69\x6c\x65",ConfigurationType::ToFile},{
"\x74\x6f\x5f\x73\x74\x61\x6e\x64\x61\x72\x64\x5f\x6f\x75\x74\x70\x75\x74",
ConfigurationType::ToStandardOutput},{"\x66\x6f\x72\x6d\x61\x74",
ConfigurationType::Format},{"\x66\x69\x6c\x65\x6e\x61\x6d\x65",ConfigurationType
::Filename},{
"\x73\x75\x62\x73\x65\x63\x6f\x6e\x64\x5f\x70\x72\x65\x63\x69\x73\x69\x6f\x6e",
ConfigurationType::SubsecondPrecision},{
"\x6d\x69\x6c\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73\x5f\x77\x69\x64\x74\x68",
ConfigurationType::MillisecondsWidth},{
"\x70\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65\x5f\x74\x72\x61\x63\x6b\x69\x6e\x67"
,ConfigurationType::PerformanceTracking},{
"\x6d\x61\x78\x5f\x6c\x6f\x67\x5f\x66\x69\x6c\x65\x5f\x73\x69\x7a\x65",
ConfigurationType::MaxLogFileSize},{
"\x6c\x6f\x67\x5f\x66\x6c\x75\x73\x68\x5f\x74\x68\x72\x65\x73\x68\x6f\x6c\x64",
ConfigurationType::LogFlushThreshold},};ConfigurationType 
ConfigurationTypeHelper::convertFromString(const char*configStr){for(auto&item:
configStringToTypeMap){if(base::utils::Str::cStringCaseEq(configStr,item.
configString)){return item.configType;}}return ConfigurationType::Unknown;}void 
ConfigurationTypeHelper::forEachConfigType(base::type::EnumType*startIndex,const
 std::function<bool(void)>&fn){base::type::EnumType cIndexMax=
ConfigurationTypeHelper::kMaxValid;do{if(fn()){break;}*startIndex=static_cast<
base::type::EnumType>(*startIndex<<(0x178b+3331-0x248d));}while(*startIndex<=
cIndexMax);}Configuration::Configuration(const Configuration&c):m_level(c.
m_level),m_configurationType(c.m_configurationType),m_value(c.m_value){}
Configuration&Configuration::operator=(const Configuration&c){if(&c!=this){
m_level=c.m_level;m_configurationType=c.m_configurationType;m_value=c.m_value;}
return*this;}Configuration::Configuration(Level level,ConfigurationType 
configurationType,const std::string&value):m_level(level),m_configurationType(
configurationType),m_value(value){}void Configuration::log(el::base::type::
ostream_t&os)const{os<<LevelHelper::convertToString(m_level)<<ELPP_LITERAL(
"\x20")<<ConfigurationTypeHelper::convertToString(m_configurationType)<<
ELPP_LITERAL("\x20\x3d\x20")<<m_value.c_str();}Configuration::Predicate::
Predicate(Level level,ConfigurationType configurationType):m_level(level),
m_configurationType(configurationType){}bool Configuration::Predicate::operator(
)(const Configuration*conf)const{return((conf!=nullptr)&&(conf->level()==m_level
)&&(conf->configurationType()==m_configurationType));}Configurations::
Configurations(void):m_configurationFile(std::string()),m_isFromFile(false){}
Configurations::Configurations(const std::string&configurationFile,bool 
useDefaultsForRemaining,Configurations*base):m_configurationFile(
configurationFile),m_isFromFile(false){parseFromFile(configurationFile,base);if(
useDefaultsForRemaining){setRemainingToDefault();}}bool Configurations::
parseFromFile(const std::string&configurationFile,Configurations*base){bool 
assertionPassed=true;ELPP_ASSERT((assertionPassed=base::utils::File::pathExists(
configurationFile.c_str(),true))==true,
"\x43\x6f\x6e\x66\x20\x66\x69\x6c\x65\x20\x5b"<<configurationFile<<
"\x5d\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x21");if(!assertionPassed){return 
false;}bool success=Parser::parseFromFile(configurationFile,this,base);
m_isFromFile=success;return success;}bool Configurations::parseFromText(const 
std::string&configurationsString,Configurations*base){bool success=Parser::
parseFromText(configurationsString,this,base);if(success){m_isFromFile=false;}
return success;}void Configurations::setFromBase(Configurations*base){if(base==
nullptr||base==this){return;}base::threading::ScopedLock scopedLock(base->lock()
);for(Configuration*&conf:base->list()){set(conf);}}bool Configurations::
hasConfiguration(ConfigurationType configurationType){base::type::EnumType 
lIndex=LevelHelper::kMinValid;bool result=false;LevelHelper::forEachLevel(&
lIndex,[&](void)->bool{if(hasConfiguration(LevelHelper::castFromInt(lIndex),
configurationType)){result=true;}return result;});return result;}bool 
Configurations::hasConfiguration(Level level,ConfigurationType configurationType
){base::threading::ScopedLock scopedLock(lock());
#if ELPP_COMPILER_INTEL
return RegistryWithPred::get(level,configurationType)!=nullptr;
#else
return RegistryWithPred<Configuration,Configuration::Predicate>::get(level,
configurationType)!=nullptr;
#endif  
}void Configurations::set(Level level,ConfigurationType configurationType,const 
std::string&value){base::threading::ScopedLock scopedLock(lock());unsafeSet(
level,configurationType,value);if(level==Level::Global){unsafeSetGlobally(
configurationType,value,false);}}void Configurations::set(Configuration*conf){if
(conf==nullptr){return;}set(conf->level(),conf->configurationType(),conf->value(
));}void Configurations::setToDefault(void){setGlobally(ConfigurationType::
Enabled,std::string("\x74\x72\x75\x65"),true);setGlobally(ConfigurationType::
Filename,std::string(base::consts::kDefaultLogFile),true);
#if defined(ELPP_NO_LOG_TO_FILE)
setGlobally(ConfigurationType::ToFile,std::string("\x66\x61\x6c\x73\x65"),true);
#else
setGlobally(ConfigurationType::ToFile,std::string("\x74\x72\x75\x65"),true);
#endif 
setGlobally(ConfigurationType::ToStandardOutput,std::string("\x74\x72\x75\x65"),
true);setGlobally(ConfigurationType::SubsecondPrecision,std::string("\x33"),true
);setGlobally(ConfigurationType::PerformanceTracking,std::string(
"\x74\x72\x75\x65"),true);setGlobally(ConfigurationType::MaxLogFileSize,std::
string("\x30"),true);setGlobally(ConfigurationType::LogFlushThreshold,std::
string("\x30"),true);setGlobally(ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
),true);set(Level::Debug,ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x75\x73\x65\x72\x40\x25\x68\x6f\x73\x74\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));set(Level::Error,ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));set(Level::Fatal,ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));set(Level::Verbose,ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x2d\x25\x76\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));set(Level::Trace,ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));}void Configurations::setRemainingToDefault(void){base::threading::ScopedLock
 scopedLock(lock());
#if defined(ELPP_NO_LOG_TO_FILE)
unsafeSetIfNotExist(Level::Global,ConfigurationType::Enabled,std::string(
"\x66\x61\x6c\x73\x65"));
#else
unsafeSetIfNotExist(Level::Global,ConfigurationType::Enabled,std::string(
"\x74\x72\x75\x65"));
#endif 
unsafeSetIfNotExist(Level::Global,ConfigurationType::Filename,std::string(base::
consts::kDefaultLogFile));unsafeSetIfNotExist(Level::Global,ConfigurationType::
ToStandardOutput,std::string("\x74\x72\x75\x65"));unsafeSetIfNotExist(Level::
Global,ConfigurationType::SubsecondPrecision,std::string("\x33"));
unsafeSetIfNotExist(Level::Global,ConfigurationType::PerformanceTracking,std::
string("\x74\x72\x75\x65"));unsafeSetIfNotExist(Level::Global,ConfigurationType
::MaxLogFileSize,std::string("\x30"));unsafeSetIfNotExist(Level::Global,
ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));unsafeSetIfNotExist(Level::Debug,ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x75\x73\x65\x72\x40\x25\x68\x6f\x73\x74\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));unsafeSetIfNotExist(Level::Error,ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));unsafeSetIfNotExist(Level::Fatal,ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));unsafeSetIfNotExist(Level::Verbose,ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x2d\x25\x76\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x25\x6d\x73\x67"
));unsafeSetIfNotExist(Level::Trace,ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x5b\x25\x6c\x6f\x67\x67\x65\x72\x5d\x20\x5b\x25\x66\x75\x6e\x63\x5d\x20\x5b\x25\x6c\x6f\x63\x5d\x20\x25\x6d\x73\x67"
));}bool Configurations::Parser::parseFromFile(const std::string&
configurationFile,Configurations*sender,Configurations*base){sender->setFromBase
(base);std::ifstream fileStream_(configurationFile.c_str(),std::ifstream::in);
ELPP_ASSERT(fileStream_.is_open(),
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x6f\x70\x65\x6e\x20\x63\x6f\x6e\x66\x20\x66\x69\x6c\x65\x20\x5b"
<<configurationFile<<"\x5d\x2e");bool parsedSuccessfully=false;std::string line=
std::string();Level currLevel=Level::Unknown;std::string currConfigStr=std::
string();std::string currLevelStr=std::string();while(fileStream_.good()){std::
getline(fileStream_,line);parsedSuccessfully=parseLine(&line,&currConfigStr,&
currLevelStr,&currLevel,sender);ELPP_ASSERT(parsedSuccessfully,
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x70\x61\x72\x73\x65\x20\x63\x6f\x6e\x66\x20\x6c\x69\x6e\x65\x3a\x20"
<<line);}return parsedSuccessfully;}bool Configurations::Parser::parseFromText(
const std::string&configurationsString,Configurations*sender,Configurations*base
){sender->setFromBase(base);bool parsedSuccessfully=false;std::stringstream ss(
configurationsString);std::string line=std::string();Level currLevel=Level::
Unknown;std::string currConfigStr=std::string();std::string currLevelStr=std::
string();while(std::getline(ss,line)){parsedSuccessfully=parseLine(&line,&
currConfigStr,&currLevelStr,&currLevel,sender);ELPP_ASSERT(parsedSuccessfully,
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x70\x61\x72\x73\x65\x20\x63\x6f\x6e\x66\x20\x6c\x69\x6e\x65\x3a\x20"
<<line);}return parsedSuccessfully;}void Configurations::Parser::ignoreComments(
std::string*line){std::size_t foundAt=(0x106b+3949-0x1fd8);std::size_t 
quotesStart=line->find("\"");std::size_t quotesEnd=std::string::npos;if(
quotesStart!=std::string::npos){quotesEnd=line->find("\"",quotesStart+
(0xe82+3578-0x1c7b));while(quotesEnd!=std::string::npos&&line->at(quotesEnd-
(0x1044+4185-0x209c))=='\\'){quotesEnd=line->find("\"",quotesEnd+
(0x90+3713-0xf0f));}}if((foundAt=line->find(base::consts::kConfigurationComment)
)!=std::string::npos){if(foundAt<quotesEnd){foundAt=line->find(base::consts::
kConfigurationComment,quotesEnd+(0xfa9+4948-0x22fc));}*line=line->substr(
(0x1390+2787-0x1e73),foundAt);}}bool Configurations::Parser::isLevel(const std::
string&line){return base::utils::Str::startsWith(line,std::string(base::consts::
kConfigurationLevel));}bool Configurations::Parser::isComment(const std::string&
line){return base::utils::Str::startsWith(line,std::string(base::consts::
kConfigurationComment));}bool Configurations::Parser::isConfig(const std::string
&line){std::size_t assignment=line.find(((char)(0x2e3+54-0x2dc)));return line!=
""&&((line[(0x137+1310-0x655)]>=((char)(0xbcc+137-0xc14))&&line[
(0x11a2+4945-0x24f3)]<=((char)(0x897+4559-0x1a0c)))||(line[(0xfcc+5058-0x238e)]
>=((char)(0x1544+1539-0x1ae6))&&line[(0xc2f+162-0xcd1)]<=
((char)(0x1b80+962-0x1ec8))))&&(assignment!=std::string::npos)&&(line.size()>
assignment);}bool Configurations::Parser::parseLine(std::string*line,std::string
*currConfigStr,std::string*currLevelStr,Level*currLevel,Configurations*conf){
ConfigurationType currConfig=ConfigurationType::Unknown;std::string currValue=
std::string();*line=base::utils::Str::trim(*line);if(isComment(*line))return 
true;ignoreComments(line);*line=base::utils::Str::trim(*line);if(line->empty()){
return true;}if(isLevel(*line)){if(line->size()<=(0x1780+3238-0x2424)){return 
true;}*currLevelStr=line->substr((0x13a3+4498-0x2534),line->size()-
(0x1650+2941-0x21cb));*currLevelStr=base::utils::Str::toUpper(*currLevelStr);*
currLevelStr=base::utils::Str::trim(*currLevelStr);*currLevel=LevelHelper::
convertFromString(currLevelStr->c_str());return true;}if(isConfig(*line)){std::
size_t assignment=line->find(((char)(0xf2+3369-0xdde)));*currConfigStr=line->
substr((0x11e8+2928-0x1d58),assignment);*currConfigStr=base::utils::Str::toUpper
(*currConfigStr);*currConfigStr=base::utils::Str::trim(*currConfigStr);
currConfig=ConfigurationTypeHelper::convertFromString(currConfigStr->c_str());
currValue=line->substr(assignment+(0x112f+3595-0x1f39));currValue=base::utils::
Str::trim(currValue);std::size_t quotesStart=currValue.find("\"",
(0x224b+593-0x249c));std::size_t quotesEnd=std::string::npos;if(quotesStart!=std
::string::npos){quotesEnd=currValue.find("\"",quotesStart+(0xa66+5134-0x1e73));
while(quotesEnd!=std::string::npos&&currValue.at(quotesEnd-(0x1c4+6103-0x199a))
=='\\'){currValue=currValue.erase(quotesEnd-(0x133a+4592-0x2529),
(0x319+1698-0x9ba));quotesEnd=currValue.find("\"",quotesEnd+(0xf5a+2784-0x1a38))
;}}if(quotesStart!=std::string::npos&&quotesEnd!=std::string::npos){ELPP_ASSERT(
(quotesStart<quotesEnd),
"\x43\x6f\x6e\x66\x20\x65\x72\x72\x6f\x72\x20\x2d\x20\x4e\x6f\x20\x65\x6e\x64\x69\x6e\x67\x20\x71\x75\x6f\x74\x65\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x5b"
<<currConfigStr<<"\x5d");ELPP_ASSERT((quotesStart+(0x16df+4122-0x26f8)!=
quotesEnd),
"\x45\x6d\x70\x74\x79\x20\x63\x6f\x6e\x66\x20\x76\x61\x6c\x75\x65\x20\x66\x6f\x72\x20\x5b"
<<currConfigStr<<"\x5d");if((quotesStart!=quotesEnd)&&(quotesStart+
(0x1b52+2840-0x2669)!=quotesEnd)){currValue=currValue.substr(quotesStart+
(0x57c+4577-0x175c),quotesEnd-(0x19f7+795-0x1d11));}}}ELPP_ASSERT(*currLevel!=
Level::Unknown,
"\x55\x6e\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20\x73\x65\x76\x65\x72\x69\x74\x79\x20\x6c\x65\x76\x65\x6c\x20\x5b"
<<*currLevelStr<<"\x5d");ELPP_ASSERT(currConfig!=ConfigurationType::Unknown,
"\x55\x6e\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20\x63\x6f\x6e\x66\x20\x5b"<<
*currConfigStr<<"\x5d");if(*currLevel==Level::Unknown||currConfig==
ConfigurationType::Unknown){return false;}conf->set(*currLevel,currConfig,
currValue);return true;}void Configurations::unsafeSetIfNotExist(Level level,
ConfigurationType configurationType,const std::string&value){Configuration*conf=
RegistryWithPred<Configuration,Configuration::Predicate>::get(level,
configurationType);if(conf==nullptr){unsafeSet(level,configurationType,value);}}
void Configurations::unsafeSet(Level level,ConfigurationType configurationType,
const std::string&value){Configuration*conf=RegistryWithPred<Configuration,
Configuration::Predicate>::get(level,configurationType);if(conf==nullptr){
registerNew(new Configuration(level,configurationType,value));}else{conf->
setValue(value);}if(level==Level::Global){unsafeSetGlobally(configurationType,
value,false);}}void Configurations::setGlobally(ConfigurationType 
configurationType,const std::string&value,bool includeGlobalLevel){if(
includeGlobalLevel){set(Level::Global,configurationType,value);}base::type::
EnumType lIndex=LevelHelper::kMinValid;LevelHelper::forEachLevel(&lIndex,[&](
void)->bool{set(LevelHelper::castFromInt(lIndex),configurationType,value);return
 false;});}void Configurations::unsafeSetGlobally(ConfigurationType 
configurationType,const std::string&value,bool includeGlobalLevel){if(
includeGlobalLevel){unsafeSet(Level::Global,configurationType,value);}base::type
::EnumType lIndex=LevelHelper::kMinValid;LevelHelper::forEachLevel(&lIndex,[&](
void)->bool{unsafeSet(LevelHelper::castFromInt(lIndex),configurationType,value);
return false;});}void LogBuilder::convertToColoredOutput(base::type::string_t*
logLine,Level level){if(!m_termSupportsColor)return;const base::type::char_t*
resetColor=ELPP_LITERAL("\x1b" "\x5b\x30\x6d");if(level==Level::Error||level==
Level::Fatal)*logLine=ELPP_LITERAL("\x1b" "\x5b\x33\x31\x6d")+*logLine+
resetColor;else if(level==Level::Warning)*logLine=ELPP_LITERAL(
"\x1b" "\x5b\x33\x33\x6d")+*logLine+resetColor;else if(level==Level::Debug)*
logLine=ELPP_LITERAL("\x1b" "\x5b\x33\x32\x6d")+*logLine+resetColor;else if(
level==Level::Info)*logLine=ELPP_LITERAL("\x1b" "\x5b\x33\x36\x6d")+*logLine+
resetColor;else if(level==Level::Trace)*logLine=ELPP_LITERAL(
"\x1b" "\x5b\x33\x35\x6d")+*logLine+resetColor;}Logger::Logger(const std::string
&id,base::LogStreamsReferenceMap*logStreamsReference):m_id(id),
m_typedConfigurations(nullptr),m_parentApplicationName(std::string()),
m_isConfigured(false),m_logStreamsReference(logStreamsReference){
initUnflushedCount();}Logger::Logger(const std::string&id,const Configurations&
configurations,base::LogStreamsReferenceMap*logStreamsReference):m_id(id),
m_typedConfigurations(nullptr),m_parentApplicationName(std::string()),
m_isConfigured(false),m_logStreamsReference(logStreamsReference){
initUnflushedCount();configure(configurations);}Logger::Logger(const Logger&
logger){base::utils::safeDelete(m_typedConfigurations);m_id=logger.m_id;
m_typedConfigurations=logger.m_typedConfigurations;m_parentApplicationName=
logger.m_parentApplicationName;m_isConfigured=logger.m_isConfigured;
m_configurations=logger.m_configurations;m_unflushedCount=logger.
m_unflushedCount;m_logStreamsReference=logger.m_logStreamsReference;}Logger&
Logger::operator=(const Logger&logger){if(&logger!=this){base::utils::safeDelete
(m_typedConfigurations);m_id=logger.m_id;m_typedConfigurations=logger.
m_typedConfigurations;m_parentApplicationName=logger.m_parentApplicationName;
m_isConfigured=logger.m_isConfigured;m_configurations=logger.m_configurations;
m_unflushedCount=logger.m_unflushedCount;m_logStreamsReference=logger.
m_logStreamsReference;}return*this;}void Logger::configure(const Configurations&
configurations){m_isConfigured=false;initUnflushedCount();if(
m_typedConfigurations!=nullptr){Configurations*c=const_cast<Configurations*>(
m_typedConfigurations->configurations());if(c->hasConfiguration(Level::Global,
ConfigurationType::Filename)){flush();}}base::threading::ScopedLock scopedLock(
lock());if(m_configurations!=configurations){m_configurations.setFromBase(
const_cast<Configurations*>(&configurations));}base::utils::safeDelete(
m_typedConfigurations);m_typedConfigurations=new base::TypedConfigurations(&
m_configurations,m_logStreamsReference);resolveLoggerFormatSpec();m_isConfigured
=true;}void Logger::reconfigure(void){ELPP_INTERNAL_INFO((0x397+4821-0x166b),
"\x52\x65\x63\x6f\x6e\x66\x20\x6c\x6f\x67\x67\x65\x72\x20\x5b"<<m_id<<"\x5d");
configure(m_configurations);}bool Logger::isValidId(const std::string&id){for(
std::string::const_iterator it=id.begin();it!=id.end();++it){if(!base::utils::
Str::contains(base::consts::kValidLoggerIdSymbols,*it)){return false;}}return 
true;}void Logger::flush(void){ELPP_INTERNAL_INFO((0x14aa+330-0x15f1),
"\x46\x6c\x75\x73\x68\x69\x6e\x67\x20\x6c\x6f\x67\x67\x65\x72\x20\x5b"<<m_id<<
"\x5d");base::threading::ScopedLock scopedLock(lock());base::type::EnumType 
lIndex=LevelHelper::kMinValid;LevelHelper::forEachLevel(&lIndex,[&](void)->bool{
flush(LevelHelper::castFromInt(lIndex),nullptr);return false;});}void Logger::
flush(Level level,base::type::fstream_t*fs){if(fs==nullptr&&
m_typedConfigurations->toFile(level)){fs=m_typedConfigurations->fileStream(level
);}if(fs!=nullptr){fs->flush();std::unordered_map<Level,unsigned int>::iterator 
iter=m_unflushedCount.find(level);if(iter!=m_unflushedCount.end()){iter->second=
(0x266b+154-0x2705);}Helpers::validateFileRolling(this,level);}}void Logger::
initUnflushedCount(void){m_unflushedCount.clear();base::type::EnumType lIndex=
LevelHelper::kMinValid;LevelHelper::forEachLevel(&lIndex,[&](void)->bool{
m_unflushedCount.insert(std::make_pair(LevelHelper::castFromInt(lIndex),
(0x1a5+383-0x324)));return false;});}void Logger::resolveLoggerFormatSpec(void)
const{base::type::EnumType lIndex=LevelHelper::kMinValid;LevelHelper::
forEachLevel(&lIndex,[&](void)->bool{base::LogFormat*logFormat=const_cast<base::
LogFormat*>(&m_typedConfigurations->logFormat(LevelHelper::castFromInt(lIndex)))
;base::utils::Str::replaceFirstWithEscape(logFormat->m_format,base::consts::
kLoggerIdFormatSpecifier,m_id);return false;});}namespace base{namespace utils{
base::type::fstream_t*File::newFileStream(const std::string&filename){base::type
::fstream_t*fs=new base::type::fstream_t(filename.c_str(),base::type::fstream_t
::out
#if !defined(ELPP_FRESH_LOG_FILE)
|base::type::fstream_t::app
#endif
);
#if defined(ELPP_UNICODE)
std::locale elppUnicodeLocale("");
#  if ELPP_OS_WINDOWS
std::locale elppUnicodeLocaleWindows(elppUnicodeLocale,new std::
codecvt_utf8_utf16<wchar_t>);elppUnicodeLocale=elppUnicodeLocaleWindows;
#  endif 
fs->imbue(elppUnicodeLocale);
#endif  
if(fs->is_open()){fs->flush();}else{base::utils::safeDelete(fs);
ELPP_INTERNAL_ERROR("\x42\x61\x64\x20\x66\x69\x6c\x65\x20\x5b"<<filename<<"\x5d"
,true);}return fs;}std::size_t File::getSizeOfFile(base::type::fstream_t*fs){if(
fs==nullptr){return(0xa98+2744-0x1550);}std::size_t size=static_cast<std::size_t
>(fs->tellg());return size;}bool File::pathExists(const char*path,bool 
considerFile){if(path==nullptr){return false;}
#if ELPP_OS_UNIX
ELPP_UNUSED(considerFile);struct stat st;return(stat(path,&st)==
(0x1058+63-0x1097));
#elif ELPP_OS_WINDOWS
DWORD fileType=GetFileAttributesA(path);if(fileType==INVALID_FILE_ATTRIBUTES){
return false;}return considerFile?true:((fileType&FILE_ATTRIBUTE_DIRECTORY)==
(0x204+7794-0x2076)?false:true);
#endif  
}bool File::createPath(const std::string&path){if(path.empty()){return false;}if
(base::utils::File::pathExists(path.c_str())){return true;}int status=-
(0x478+4800-0x1737);char*currPath=const_cast<char*>(path.c_str());std::string 
builtPath=std::string();
#if ELPP_OS_UNIX
if(path[(0x8c9+1014-0xcbf)]==((char)(0x1617+3113-0x2211))){builtPath="\x2f";}
currPath=STRTOK(currPath,base::consts::kFilePathSeperator,(0xc8f+6365-0x256c));
#elif ELPP_OS_WINDOWS
char*nextTok_=nullptr;currPath=STRTOK(currPath,base::consts::kFilePathSeperator,
&nextTok_);ELPP_UNUSED(nextTok_);
#endif  
while(currPath!=nullptr){builtPath.append(currPath);builtPath.append(base::
consts::kFilePathSeperator);
#if ELPP_OS_UNIX
status=mkdir(builtPath.c_str(),ELPP_LOG_PERMS);currPath=STRTOK(nullptr,base::
consts::kFilePathSeperator,(0x1da+2712-0xc72));
#elif ELPP_OS_WINDOWS
status=_mkdir(builtPath.c_str());currPath=STRTOK(nullptr,base::consts::
kFilePathSeperator,&nextTok_);
#endif  
}if(status==-(0x1c6b+2375-0x25b1)){ELPP_INTERNAL_ERROR(
"\x45\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x63\x72\x65\x61\x74\x69\x6e\x67\x20\x70\x61\x74\x68\x20\x5b"
<<path<<"\x5d",true);return false;}return true;}std::string File::
extractPathFromFilename(const std::string&fullPath,const char*separator){if((
fullPath=="")||(fullPath.find(separator)==std::string::npos)){return fullPath;}
std::size_t lastSlashAt=fullPath.find_last_of(separator);if(lastSlashAt==
(0xb1b+3061-0x1710)){return std::string(separator);}return fullPath.substr(
(0x197f+1501-0x1f5c),lastSlashAt+(0xa98+2839-0x15ae));}void File::
buildStrippedFilename(const char*filename,char buff[],std::size_t limit){std::
size_t sizeOfFilename=strlen(filename);if(sizeOfFilename>=limit){filename+=(
sizeOfFilename-limit);if(filename[(0x1dd4+392-0x1f5c)]!=
((char)(0xa48+4136-0x1a42))&&filename[(0x11d5+4879-0x24e3)]!=
((char)(0x1cad+1776-0x236f))){filename+=(0x17bc+282-0x18d3);STRCAT(buff,
"\x2e\x2e",limit);}}STRCAT(buff,filename,limit);}void File::buildBaseFilename(
const std::string&fullPath,char buff[],std::size_t limit,const char*separator){
const char*filename=fullPath.c_str();std::size_t lastSlashAt=fullPath.
find_last_of(separator);filename+=lastSlashAt?lastSlashAt+(0x3e3+824-0x71a):
(0x87c+6146-0x207e);std::size_t sizeOfFilename=strlen(filename);if(
sizeOfFilename>=limit){filename+=(sizeOfFilename-limit);if(filename[
(0x1b37+13-0x1b44)]!=((char)(0x580+6968-0x208a))&&filename[(0x295+1628-0x8f0)]!=
((char)(0x853+1392-0xd95))){filename+=(0x1415+2379-0x1d5d);STRCAT(buff,
"\x2e\x2e",limit);}}STRCAT(buff,filename,limit);}bool Str::wildCardMatch(const 
char*str,const char*pattern){while(*pattern){switch(*pattern){case
((char)(0x9cb+6792-0x2414)):if(!*str)return false;++str;++pattern;break;case
((char)(0x451+4061-0x1404)):if(wildCardMatch(str,pattern+(0x666+181-0x71a)))
return true;if(*str&&wildCardMatch(str+(0x165+6105-0x193d),pattern))return true;
return false;default:if(*str++!=*pattern++)return false;break;}}return!*str&&!*
pattern;}std::string&Str::ltrim(std::string&str){str.erase(str.begin(),std::
find_if(str.begin(),str.end(),[](char c){return!std::isspace(c);}));return str;}
std::string&Str::rtrim(std::string&str){str.erase(std::find_if(str.rbegin(),str.
rend(),[](char c){return!std::isspace(c);}).base(),str.end());return str;}std::
string&Str::trim(std::string&str){return ltrim(rtrim(str));}bool Str::startsWith
(const std::string&str,const std::string&start){return(str.length()>=start.
length())&&(str.compare((0x13af+942-0x175d),start.length(),start)==
(0x1646+930-0x19e8));}bool Str::endsWith(const std::string&str,const std::string
&end){return(str.length()>=end.length())&&(str.compare(str.length()-end.length()
,end.length(),end)==(0x5cf+5024-0x196f));}std::string&Str::replaceAll(std::
string&str,char replaceWhat,char replaceWith){std::replace(str.begin(),str.end()
,replaceWhat,replaceWith);return str;}std::string&Str::replaceAll(std::string&
str,const std::string&replaceWhat,const std::string&replaceWith){if(replaceWhat
==replaceWith)return str;std::size_t foundAt=std::string::npos;while((foundAt=
str.find(replaceWhat,foundAt+(0x13+5200-0x1462)))!=std::string::npos){str.
replace(foundAt,replaceWhat.length(),replaceWith);}return str;}void Str::
replaceFirstWithEscape(base::type::string_t&str,const base::type::string_t&
replaceWhat,const base::type::string_t&replaceWith){std::size_t foundAt=base::
type::string_t::npos;while((foundAt=str.find(replaceWhat,foundAt+
(0x437+796-0x752)))!=base::type::string_t::npos){if(foundAt>(0x5e6+8138-0x25b0)
&&str[foundAt-(0xfea+5657-0x2602)]==base::consts::kFormatSpecifierChar){str.
erase(foundAt-(0x1ecd+155-0x1f67),(0xe0b+6339-0x26cd));++foundAt;}else{str.
replace(foundAt,replaceWhat.length(),replaceWith);return;}}}
#if defined(ELPP_UNICODE)
void Str::replaceFirstWithEscape(base::type::string_t&str,const base::type::
string_t&replaceWhat,const std::string&replaceWith){replaceFirstWithEscape(str,
replaceWhat,base::type::string_t(replaceWith.begin(),replaceWith.end()));}
#endif  
std::string&Str::toUpper(std::string&str){std::transform(str.begin(),str.end(),
str.begin(),[](char c){return static_cast<char>(::toupper(c));});return str;}
bool Str::cStringEq(const char*s1,const char*s2){if(s1==nullptr&&s2==nullptr)
return true;if(s1==nullptr||s2==nullptr)return false;return strcmp(s1,s2)==
(0x118b+2763-0x1c56);}bool Str::cStringCaseEq(const char*s1,const char*s2){if(s1
==nullptr&&s2==nullptr)return true;if(s1==nullptr||s2==nullptr)return false;int 
d=(0x10ef+2444-0x1a7b);while(true){const int c1=toupper(*s1++);const int c2=
toupper(*s2++);if(((d=c1-c2)!=(0xf96+2939-0x1b11))||(c2=='\0')){break;}}return d
==(0x12c6+69-0x130b);}bool Str::contains(const char*str,char c){for(;*str;++str)
{if(*str==c)return true;}return false;}char*Str::convertAndAddToBuff(std::size_t
 n,int len,char*buf,const char*bufLim,bool zeroPadded){char localBuff[
(0x19df+601-0x1c2e)]="";char*p=localBuff+sizeof(localBuff)-(0x391+6352-0x1c5f);
if(n>(0x850+2328-0x1168)){for(;n>(0x93b+1567-0xf5a)&&p>localBuff&&len>
(0x423+272-0x533);n/=(0x41a+5338-0x18ea),--len)*--p=static_cast<char>(n%
(0xa2f+5185-0x1e66)+((char)(0x156c+926-0x18da)));}else{*--p=
((char)(0x181+6778-0x1bcb));--len;}if(zeroPadded)while(p>localBuff&&len-- >
(0x178d+1454-0x1d3b))*--p=static_cast<char>(((char)(0x2233+1009-0x25f4)));return
 addToBuff(p,buf,bufLim);}char*Str::addToBuff(const char*str,char*buf,const char
*bufLim){while((buf<bufLim)&&((*buf=*str++)!='\0'))++buf;return buf;}char*Str::
clearBuff(char buff[],std::size_t lim){STRCPY(buff,"",lim);ELPP_UNUSED(lim);
return buff;}char*Str::wcharPtrToCharPtr(const wchar_t*line){std::size_t len_=
wcslen(line)+(0xd00+2224-0x15af);char*buff_=static_cast<char*>(malloc(len_+
(0x369+4946-0x16ba)));
#      if ELPP_OS_UNIX || (ELPP_OS_WINDOWS && !ELPP_CRT_DBG_WARNINGS)
std::wcstombs(buff_,line,len_);
#      elif ELPP_OS_WINDOWS
std::size_t convCount_=(0xc37+1061-0x105c);mbstate_t mbState_;::memset(
static_cast<void*>(&mbState_),(0x901+2405-0x1266),sizeof(mbState_));wcsrtombs_s(
&convCount_,buff_,len_,&line,len_,&mbState_);
#      endif  
return buff_;}
#if ELPP_OS_WINDOWS
const char*OS::getWindowsEnvironmentVariable(const char*varname){const DWORD 
bufferLen=(0x12b+1051-0x514);static char buffer[bufferLen];if(
GetEnvironmentVariableA(varname,buffer,bufferLen)){return buffer;}return nullptr
;}
#endif  
#if ELPP_OS_ANDROID
std::string OS::getProperty(const char*prop){char propVal[PROP_VALUE_MAX+
(0x18+2320-0x927)];int ret=__system_property_get(prop,propVal);return ret==
(0x1229+4732-0x24a5)?std::string():std::string(propVal);}std::string OS::
getDeviceName(void){std::stringstream ss;std::string manufacturer=getProperty(
"\x72\x6f\x2e\x70\x72\x6f\x64\x75\x63\x74\x2e\x6d\x61\x6e\x75\x66\x61\x63\x74\x75\x72\x65\x72"
);std::string model=getProperty(
"\x72\x6f\x2e\x70\x72\x6f\x64\x75\x63\x74\x2e\x6d\x6f\x64\x65\x6c");if(
manufacturer.empty()||model.empty()){return std::string();}ss<<manufacturer<<
"\x2d"<<model;return ss.str();}
#endif  
const std::string OS::getBashOutput(const char*command){
#if (ELPP_OS_UNIX && !ELPP_OS_ANDROID && !ELPP_CYGWIN)
if(command==nullptr){return std::string();}FILE*proc=nullptr;if((proc=popen(
command,"\x72"))==nullptr){ELPP_INTERNAL_ERROR(
"\n" "\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x72\x75\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x5b"
<<command<<"\x5d",true);return std::string();}char hBuff[(0x1888+2257-0x1159)];
if(fgets(hBuff,sizeof(hBuff),proc)!=nullptr){pclose(proc);const std::size_t 
buffLen=strlen(hBuff);if(buffLen>(0xb9f+477-0xd7c)&&hBuff[buffLen-
(0x1b94+980-0x1f67)]=='\n'){hBuff[buffLen-(0x80d+4965-0x1b71)]='\0';}return std
::string(hBuff);}else{pclose(proc);}return std::string();
#else
ELPP_UNUSED(command);return std::string();
#endif
}std::string OS::getEnvironmentVariable(const char*variableName,const char*
defaultVal,const char*alternativeBashCommand){
#if ELPP_OS_UNIX
const char*val=getenv(variableName);
#elif ELPP_OS_WINDOWS
const char*val=getWindowsEnvironmentVariable(variableName);
#endif  
if((val==nullptr)||((strcmp(val,"")==(0x158d+3608-0x23a5)))){
#if ELPP_OS_UNIX && defined(ELPP_FORCE_ENV_VAR_FROM_BASH)
std::string valBash=base::utils::OS::getBashOutput(alternativeBashCommand);if(
valBash.empty()){return std::string(defaultVal);}else{return valBash;}
#elif ELPP_OS_WINDOWS || ELPP_OS_UNIX
ELPP_UNUSED(alternativeBashCommand);return std::string(defaultVal);
#endif  
}return std::string(val);}std::string OS::currentUser(void){
#if ELPP_OS_UNIX && !ELPP_OS_ANDROID
return getEnvironmentVariable("\x55\x53\x45\x52",base::consts::kUnknownUser,
"\x77\x68\x6f\x61\x6d\x69");
#elif ELPP_OS_WINDOWS
return getEnvironmentVariable("\x55\x53\x45\x52\x4e\x41\x4d\x45",base::consts::
kUnknownUser);
#elif ELPP_OS_ANDROID
ELPP_UNUSED(base::consts::kUnknownUser);return std::string(
"\x61\x6e\x64\x72\x6f\x69\x64");
#else
return std::string();
#endif  
}std::string OS::currentHost(void){
#if ELPP_OS_UNIX && !ELPP_OS_ANDROID
return getEnvironmentVariable("\x48\x4f\x53\x54\x4e\x41\x4d\x45",base::consts::
kUnknownHost,"\x68\x6f\x73\x74\x6e\x61\x6d\x65");
#elif ELPP_OS_WINDOWS
return getEnvironmentVariable("\x43\x4f\x4d\x50\x55\x54\x45\x52\x4e\x41\x4d\x45"
,base::consts::kUnknownHost);
#elif ELPP_OS_ANDROID
ELPP_UNUSED(base::consts::kUnknownHost);return getDeviceName();
#else
return std::string();
#endif  
}bool OS::termSupportsColor(void){std::string term=getEnvironmentVariable(
"\x54\x45\x52\x4d","");return term=="\x78\x74\x65\x72\x6d"||term==
"\x78\x74\x65\x72\x6d\x2d\x63\x6f\x6c\x6f\x72"||term==
"\x78\x74\x65\x72\x6d\x2d\x32\x35\x36\x63\x6f\x6c\x6f\x72"||term==
"\x73\x63\x72\x65\x65\x6e"||term=="\x6c\x69\x6e\x75\x78"||term==
"\x63\x79\x67\x77\x69\x6e"||term==
"\x73\x63\x72\x65\x65\x6e\x2d\x32\x35\x36\x63\x6f\x6c\x6f\x72";}void DateTime::
gettimeofday(struct timeval*tv){
#if ELPP_OS_WINDOWS
if(tv!=nullptr){
#  if ELPP_COMPILER_MSVC || defined(_MSC_EXTENSIONS)
const unsigned __int64 delta_=11644473600000000Ui64;
#  else
const unsigned __int64 delta_=11644473600000000ULL;
#  endif  
const double secOffSet=0.000001;const unsigned long usecOffSet=1000000;FILETIME 
fileTime;GetSystemTimeAsFileTime(&fileTime);unsigned __int64 present=
(0x150b+4575-0x26ea);present|=fileTime.dwHighDateTime;present=present<<
(0x870+7212-0x247c);present|=fileTime.dwLowDateTime;present/=(0x3cb+3678-0x121f)
;present-=delta_;tv->tv_sec=static_cast<long>(present*secOffSet);tv->tv_usec=
static_cast<long>(present%usecOffSet);}
#else
::gettimeofday(tv,nullptr);
#endif  
}std::string DateTime::getDateTime(const char*format,const base::
SubsecondPrecision*ssPrec){struct timeval currTime;gettimeofday(&currTime);
return timevalToString(currTime,format,ssPrec);}std::string DateTime::
timevalToString(struct timeval tval,const char*format,const el::base::
SubsecondPrecision*ssPrec){struct::tm timeInfo;buildTimeInfo(&tval,&timeInfo);
const int kBuffSize=(0x1f8b+1298-0x247f);char buff_[kBuffSize]="";parseFormat(
buff_,kBuffSize,format,&timeInfo,static_cast<std::size_t>(tval.tv_usec/ssPrec->
m_offset),ssPrec);return std::string(buff_);}base::type::string_t DateTime::
formatTime(unsigned long long time,base::TimestampUnit timestampUnit){base::type
::EnumType start=static_cast<base::type::EnumType>(timestampUnit);const base::
type::char_t*unit=base::consts::kTimeFormats[start].unit;for(base::type::
EnumType i=start;i<base::consts::kTimeFormatsCount-(0x405+351-0x563);++i){if(
time<=base::consts::kTimeFormats[i].value){break;}if(base::consts::kTimeFormats[
i].value==1000.0f&&time/1000.0f<1.9f){break;}time/=static_cast<decltype(time)>(
base::consts::kTimeFormats[i].value);unit=base::consts::kTimeFormats[i+
(0x1540+3729-0x23d0)].unit;}base::type::stringstream_t ss;ss<<time<<"\x20"<<unit
;return ss.str();}unsigned long long DateTime::getTimeDifference(const struct 
timeval&endTime,const struct timeval&startTime,base::TimestampUnit timestampUnit
){if(timestampUnit==base::TimestampUnit::Microsecond){return static_cast<
unsigned long long>(static_cast<unsigned long long>(1000000*endTime.tv_sec+
endTime.tv_usec)-static_cast<unsigned long long>(1000000*startTime.tv_sec+
startTime.tv_usec));}auto conv=[](const struct timeval&tim){return static_cast<
unsigned long long>((tim.tv_sec*(0x1eaf+1004-0x1eb3))+(tim.tv_usec/
(0x47b+3798-0xf69)));};return static_cast<unsigned long long>(conv(endTime)-conv
(startTime));}struct::tm*DateTime::buildTimeInfo(struct timeval*currTime,struct
::tm*timeInfo){
#if ELPP_OS_UNIX
time_t rawTime=currTime->tv_sec;::elpptime_r(&rawTime,timeInfo);return timeInfo;
#else
#  if ELPP_COMPILER_MSVC
ELPP_UNUSED(currTime);time_t t;
#    if defined(_USE_32BIT_TIME_T)
_time32(&t);
#    else
_time64(&t);
#    endif
elpptime_s(timeInfo,&t);return timeInfo;
#  else
time_t rawTime=currTime->tv_sec;struct tm*tmInf=elpptime(&rawTime);*timeInfo=*
tmInf;return timeInfo;
#  endif  
#endif  
}char*DateTime::parseFormat(char*buf,std::size_t bufSz,const char*format,const 
struct tm*tInfo,std::size_t msec,const base::SubsecondPrecision*ssPrec){const 
char*bufLim=buf+bufSz;for(;*format;++format){if(*format==base::consts::
kFormatSpecifierChar){switch(*++format){case base::consts::kFormatSpecifierChar:
break;case'\0':--format;break;case((char)(0x59b+6566-0x1edd)):buf=base::utils::
Str::convertAndAddToBuff(tInfo->tm_mday,(0x1772+2618-0x21aa),buf,bufLim);
continue;case((char)(0x612+3741-0x144e)):buf=base::utils::Str::addToBuff(base::
consts::kDaysAbbrev[tInfo->tm_wday],buf,bufLim);continue;case
((char)(0x46f+1393-0x99f)):buf=base::utils::Str::addToBuff(base::consts::kDays[
tInfo->tm_wday],buf,bufLim);continue;case((char)(0x1056+124-0x1085)):buf=base::
utils::Str::convertAndAddToBuff(tInfo->tm_mon+(0xd97+349-0xef3),
(0xdea+5566-0x23a6),buf,bufLim);continue;case((char)(0x2056+86-0x204a)):buf=base
::utils::Str::addToBuff(base::consts::kMonthsAbbrev[tInfo->tm_mon],buf,bufLim);
continue;case((char)(0x65b+3284-0x12ed)):buf=base::utils::Str::addToBuff(base::
consts::kMonths[tInfo->tm_mon],buf,bufLim);continue;case
((char)(0x22e5+209-0x233d)):buf=base::utils::Str::convertAndAddToBuff(tInfo->
tm_year+base::consts::kYearBase,(0xc1b+3441-0x198a),buf,bufLim);continue;case
((char)(0x1c97+465-0x1e0f)):buf=base::utils::Str::convertAndAddToBuff(tInfo->
tm_year+base::consts::kYearBase,(0x5c6+8354-0x2664),buf,bufLim);continue;case
((char)(0x65b+2549-0xfe8)):buf=base::utils::Str::convertAndAddToBuff(tInfo->
tm_hour%(0x18d+8046-0x20ef),(0x6d8+7427-0x23d9),buf,bufLim);continue;case
((char)(0x217+3284-0xea3)):buf=base::utils::Str::convertAndAddToBuff(tInfo->
tm_hour,(0xf24+60-0xf5e),buf,bufLim);continue;case((char)(0x40c+4760-0x1637)):
buf=base::utils::Str::convertAndAddToBuff(tInfo->tm_min,(0x59a+49-0x5c9),buf,
bufLim);continue;case((char)(0x42c+4787-0x166c)):buf=base::utils::Str::
convertAndAddToBuff(tInfo->tm_sec,(0x23c+6527-0x1bb9),buf,bufLim);continue;case
((char)(0xae6+1026-0xe6e)):case((char)(0xa69+5568-0x1fc2)):buf=base::utils::Str
::convertAndAddToBuff(msec,ssPrec->m_width,buf,bufLim);continue;case
((char)(0x85c+1506-0xdf8)):buf=base::utils::Str::addToBuff((tInfo->tm_hour>=
(0x528+1936-0xcac))?base::consts::kPm:base::consts::kAm,buf,bufLim);continue;
default:continue;}}if(buf==bufLim)break;*buf++=*format;}return buf;}void 
CommandLineArgs::setArgs(int argc,char**argv){m_params.clear();m_paramsWithValue
.clear();if(argc==(0xa79+3210-0x1703)||argv==nullptr){return;}m_argc=argc;m_argv
=argv;for(int i=(0x126a+524-0x1475);i<m_argc;++i){const char*v=(strstr(m_argv[i]
,"\x3d"));if(v!=nullptr&&strlen(v)>(0xaf8+5134-0x1f06)){std::string key=std::
string(m_argv[i]);key=key.substr((0x3c7+2997-0xf7c),key.find_first_of(
((char)(0x195+6382-0x1a46))));if(hasParamWithValue(key.c_str())){
ELPP_INTERNAL_INFO((0x454+1000-0x83b),"\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x5b"
<<key<<"\x5d\x20\x5b"<<getParamValue(key.c_str())<<"\x5d");}else{
m_paramsWithValue.insert(std::make_pair(key,std::string(v+(0x1d5d+1035-0x2167)))
);}}if(v==nullptr){if(hasParam(m_argv[i])){ELPP_INTERNAL_INFO(
(0x491+7438-0x219e),"\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x5b"<<m_argv[i]<<
"\x5d");}else{m_params.push_back(std::string(m_argv[i]));}}}}bool 
CommandLineArgs::hasParamWithValue(const char*paramKey)const{return 
m_paramsWithValue.find(std::string(paramKey))!=m_paramsWithValue.end();}const 
char*CommandLineArgs::getParamValue(const char*paramKey)const{std::unordered_map
<std::string,std::string>::const_iterator iter=m_paramsWithValue.find(std::
string(paramKey));return iter!=m_paramsWithValue.end()?iter->second.c_str():"";}
bool CommandLineArgs::hasParam(const char*paramKey)const{return std::find(
m_params.begin(),m_params.end(),std::string(paramKey))!=m_params.end();}bool 
CommandLineArgs::empty(void)const{return m_params.empty()&&m_paramsWithValue.
empty();}std::size_t CommandLineArgs::size(void)const{return m_params.size()+
m_paramsWithValue.size();}base::type::ostream_t&operator<<(base::type::ostream_t
&os,const CommandLineArgs&c){for(int i=(0x195f+1565-0x1f7b);i<c.m_argc;++i){os<<
ELPP_LITERAL("\x5b")<<c.m_argv[i]<<ELPP_LITERAL("\x5d");if(i<c.m_argc-
(0x1196+4996-0x2519)){os<<ELPP_LITERAL("\x20");}}return os;}}namespace threading
{
#if ELPP_THREADING_ENABLED
#  if ELPP_USE_STD_THREADING
#      if ELPP_ASYNC_LOGGING
static void msleep(int ms){
#         if defined(ELPP_NO_SLEEP_FOR)
usleep(ms*(0x14ba+1321-0x15fb));
#         else
std::this_thread::sleep_for(std::chrono::milliseconds(ms));
#         endif  
}
#      endif  
#  endif  
#endif  
}void SubsecondPrecision::init(int width){if(width<(0xd30+2330-0x1649)||width>
(0x15bf+2445-0x1f46)){width=base::consts::kDefaultSubsecondPrecision;}m_width=
width;switch(m_width){case(0x79f+7121-0x236d):m_offset=(0x111d+185-0xdee);break;
case(0x18cc+1931-0x2053):m_offset=(0x16c7+2867-0x2196);break;case
(0x4fd+7035-0x2073):m_offset=(0x1c0d+286-0x1d21);break;case(0x1e0c+1082-0x2240):
m_offset=(0x1eac+135-0x1f32);break;default:m_offset=(0x207b+2145-0x24f4);break;}
}LogFormat::LogFormat(void):m_level(Level::Unknown),m_userFormat(base::type::
string_t()),m_format(base::type::string_t()),m_dateTimeFormat(std::string()),
m_flags((0xc9d+6412-0x25a9)),m_currentUser(base::utils::OS::currentUser()),
m_currentHost(base::utils::OS::currentHost()){}LogFormat::LogFormat(Level level,
const base::type::string_t&format):m_level(level),m_userFormat(format),
m_currentUser(base::utils::OS::currentUser()),m_currentHost(base::utils::OS::
currentHost()){parseFromFormat(m_userFormat);}LogFormat::LogFormat(const 
LogFormat&logFormat):m_level(logFormat.m_level),m_userFormat(logFormat.
m_userFormat),m_format(logFormat.m_format),m_dateTimeFormat(logFormat.
m_dateTimeFormat),m_flags(logFormat.m_flags),m_currentUser(logFormat.
m_currentUser),m_currentHost(logFormat.m_currentHost){}LogFormat::LogFormat(
LogFormat&&logFormat){m_level=std::move(logFormat.m_level);m_userFormat=std::
move(logFormat.m_userFormat);m_format=std::move(logFormat.m_format);
m_dateTimeFormat=std::move(logFormat.m_dateTimeFormat);m_flags=std::move(
logFormat.m_flags);m_currentUser=std::move(logFormat.m_currentUser);
m_currentHost=std::move(logFormat.m_currentHost);}LogFormat&LogFormat::operator=
(const LogFormat&logFormat){if(&logFormat!=this){m_level=logFormat.m_level;
m_userFormat=logFormat.m_userFormat;m_dateTimeFormat=logFormat.m_dateTimeFormat;
m_flags=logFormat.m_flags;m_currentUser=logFormat.m_currentUser;m_currentHost=
logFormat.m_currentHost;}return*this;}bool LogFormat::operator==(const LogFormat
&other){return m_level==other.m_level&&m_userFormat==other.m_userFormat&&
m_format==other.m_format&&m_dateTimeFormat==other.m_dateTimeFormat&&m_flags==
other.m_flags;}void LogFormat::parseFromFormat(const base::type::string_t&
userFormat){base::type::string_t formatCopy=userFormat;m_flags=
(0x90a+6279-0x2191);auto conditionalAddFlag=[&](const base::type::char_t*
specifier,base::FormatFlags flag){std::size_t foundAt=base::type::string_t::npos
;while((foundAt=formatCopy.find(specifier,foundAt+(0xda0+3567-0x1b8e)))!=base::
type::string_t::npos){if(foundAt>(0xf63+4324-0x2047)&&formatCopy[foundAt-
(0xd0b+5566-0x22c8)]==base::consts::kFormatSpecifierChar){if(hasFlag(flag)){
formatCopy.erase(foundAt-(0x463+1164-0x8ee),(0x1b20+1495-0x20f6));++foundAt;}}
else{if(!hasFlag(flag))addFlag(flag);}}};conditionalAddFlag(base::consts::
kAppNameFormatSpecifier,base::FormatFlags::AppName);conditionalAddFlag(base::
consts::kSeverityLevelFormatSpecifier,base::FormatFlags::Level);
conditionalAddFlag(base::consts::kSeverityLevelShortFormatSpecifier,base::
FormatFlags::LevelShort);conditionalAddFlag(base::consts::
kLoggerIdFormatSpecifier,base::FormatFlags::LoggerId);conditionalAddFlag(base::
consts::kThreadIdFormatSpecifier,base::FormatFlags::ThreadId);conditionalAddFlag
(base::consts::kLogFileFormatSpecifier,base::FormatFlags::File);
conditionalAddFlag(base::consts::kLogFileBaseFormatSpecifier,base::FormatFlags::
FileBase);conditionalAddFlag(base::consts::kLogLineFormatSpecifier,base::
FormatFlags::Line);conditionalAddFlag(base::consts::kLogLocationFormatSpecifier,
base::FormatFlags::Location);conditionalAddFlag(base::consts::
kLogFunctionFormatSpecifier,base::FormatFlags::Function);conditionalAddFlag(base
::consts::kCurrentUserFormatSpecifier,base::FormatFlags::User);
conditionalAddFlag(base::consts::kCurrentHostFormatSpecifier,base::FormatFlags::
Host);conditionalAddFlag(base::consts::kMessageFormatSpecifier,base::FormatFlags
::LogMessage);conditionalAddFlag(base::consts::kVerboseLevelFormatSpecifier,base
::FormatFlags::VerboseLevel);std::size_t dateIndex=std::string::npos;if((
dateIndex=formatCopy.find(base::consts::kDateTimeFormatSpecifier))!=std::string
::npos){while(dateIndex>(0x966+398-0xaf4)&&formatCopy[dateIndex-
(0xab7+4846-0x1da4)]==base::consts::kFormatSpecifierChar){dateIndex=formatCopy.
find(base::consts::kDateTimeFormatSpecifier,dateIndex+(0x296+7432-0x1f9d));}if(
dateIndex!=std::string::npos){addFlag(base::FormatFlags::DateTime);
updateDateFormat(dateIndex,formatCopy);}}m_format=formatCopy;updateFormatSpec();
}void LogFormat::updateDateFormat(std::size_t index,base::type::string_t&
currFormat){if(hasFlag(base::FormatFlags::DateTime)){index+=ELPP_STRLEN(base::
consts::kDateTimeFormatSpecifier);}const base::type::char_t*ptr=currFormat.c_str
()+index;if((currFormat.size()>index)&&(ptr[(0x94d+2765-0x141a)]==
((char)(0x219+8396-0x226a)))){++ptr;int count=(0x1c98+76-0x1ce3);std::
stringstream ss;for(;*ptr;++ptr,++count){if(*ptr==((char)(0x53a+3526-0x1283))){
++count;break;}ss<<static_cast<char>(*ptr);}currFormat.erase(index,count);
m_dateTimeFormat=ss.str();}else{if(hasFlag(base::FormatFlags::DateTime)){
m_dateTimeFormat=std::string(base::consts::kDefaultDateTimeFormat);}}}void 
LogFormat::updateFormatSpec(void){if(m_level==Level::Debug){base::utils::Str::
replaceFirstWithEscape(m_format,base::consts::kSeverityLevelFormatSpecifier,base
::consts::kDebugLevelLogValue);base::utils::Str::replaceFirstWithEscape(m_format
,base::consts::kSeverityLevelShortFormatSpecifier,base::consts::
kDebugLevelShortLogValue);}else if(m_level==Level::Info){base::utils::Str::
replaceFirstWithEscape(m_format,base::consts::kSeverityLevelFormatSpecifier,base
::consts::kInfoLevelLogValue);base::utils::Str::replaceFirstWithEscape(m_format,
base::consts::kSeverityLevelShortFormatSpecifier,base::consts::
kInfoLevelShortLogValue);}else if(m_level==Level::Warning){base::utils::Str::
replaceFirstWithEscape(m_format,base::consts::kSeverityLevelFormatSpecifier,base
::consts::kWarningLevelLogValue);base::utils::Str::replaceFirstWithEscape(
m_format,base::consts::kSeverityLevelShortFormatSpecifier,base::consts::
kWarningLevelShortLogValue);}else if(m_level==Level::Error){base::utils::Str::
replaceFirstWithEscape(m_format,base::consts::kSeverityLevelFormatSpecifier,base
::consts::kErrorLevelLogValue);base::utils::Str::replaceFirstWithEscape(m_format
,base::consts::kSeverityLevelShortFormatSpecifier,base::consts::
kErrorLevelShortLogValue);}else if(m_level==Level::Fatal){base::utils::Str::
replaceFirstWithEscape(m_format,base::consts::kSeverityLevelFormatSpecifier,base
::consts::kFatalLevelLogValue);base::utils::Str::replaceFirstWithEscape(m_format
,base::consts::kSeverityLevelShortFormatSpecifier,base::consts::
kFatalLevelShortLogValue);}else if(m_level==Level::Verbose){base::utils::Str::
replaceFirstWithEscape(m_format,base::consts::kSeverityLevelFormatSpecifier,base
::consts::kVerboseLevelLogValue);base::utils::Str::replaceFirstWithEscape(
m_format,base::consts::kSeverityLevelShortFormatSpecifier,base::consts::
kVerboseLevelShortLogValue);}else if(m_level==Level::Trace){base::utils::Str::
replaceFirstWithEscape(m_format,base::consts::kSeverityLevelFormatSpecifier,base
::consts::kTraceLevelLogValue);base::utils::Str::replaceFirstWithEscape(m_format
,base::consts::kSeverityLevelShortFormatSpecifier,base::consts::
kTraceLevelShortLogValue);}if(hasFlag(base::FormatFlags::User)){base::utils::Str
::replaceFirstWithEscape(m_format,base::consts::kCurrentUserFormatSpecifier,
m_currentUser);}if(hasFlag(base::FormatFlags::Host)){base::utils::Str::
replaceFirstWithEscape(m_format,base::consts::kCurrentHostFormatSpecifier,
m_currentHost);}}TypedConfigurations::TypedConfigurations(Configurations*
configurations,base::LogStreamsReferenceMap*logStreamsReference){
m_configurations=configurations;m_logStreamsReference=logStreamsReference;build(
m_configurations);}TypedConfigurations::TypedConfigurations(const 
TypedConfigurations&other){this->m_configurations=other.m_configurations;this->
m_logStreamsReference=other.m_logStreamsReference;build(m_configurations);}bool 
TypedConfigurations::enabled(Level level){return getConfigByVal<bool>(level,&
m_enabledMap,"\x65\x6e\x61\x62\x6c\x65\x64");}bool TypedConfigurations::toFile(
Level level){return getConfigByVal<bool>(level,&m_toFileMap,
"\x74\x6f\x46\x69\x6c\x65");}const std::string&TypedConfigurations::filename(
Level level){return getConfigByRef<std::string>(level,&m_filenameMap,
"\x66\x69\x6c\x65\x6e\x61\x6d\x65");}bool TypedConfigurations::toStandardOutput(
Level level){return getConfigByVal<bool>(level,&m_toStandardOutputMap,
"\x74\x6f\x53\x74\x61\x6e\x64\x61\x72\x64\x4f\x75\x74\x70\x75\x74");}const base
::LogFormat&TypedConfigurations::logFormat(Level level){return getConfigByRef<
base::LogFormat>(level,&m_logFormatMap,"\x6c\x6f\x67\x46\x6f\x72\x6d\x61\x74");}
const base::SubsecondPrecision&TypedConfigurations::subsecondPrecision(Level 
level){return getConfigByRef<base::SubsecondPrecision>(level,&
m_subsecondPrecisionMap,
"\x73\x75\x62\x73\x65\x63\x6f\x6e\x64\x50\x72\x65\x63\x69\x73\x69\x6f\x6e");}
const base::MillisecondsWidth&TypedConfigurations::millisecondsWidth(Level level
){return getConfigByRef<base::MillisecondsWidth>(level,&m_subsecondPrecisionMap,
"\x6d\x69\x6c\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73\x57\x69\x64\x74\x68");}bool 
TypedConfigurations::performanceTracking(Level level){return getConfigByVal<bool
>(level,&m_performanceTrackingMap,
"\x70\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65\x54\x72\x61\x63\x6b\x69\x6e\x67");
}base::type::fstream_t*TypedConfigurations::fileStream(Level level){return 
getConfigByRef<base::FileStreamPtr>(level,&m_fileStreamMap,
"\x66\x69\x6c\x65\x53\x74\x72\x65\x61\x6d").get();}std::size_t 
TypedConfigurations::maxLogFileSize(Level level){return getConfigByVal<std::
size_t>(level,&m_maxLogFileSizeMap,
"\x6d\x61\x78\x4c\x6f\x67\x46\x69\x6c\x65\x53\x69\x7a\x65");}std::size_t 
TypedConfigurations::logFlushThreshold(Level level){return getConfigByVal<std::
size_t>(level,&m_logFlushThresholdMap,
"\x6c\x6f\x67\x46\x6c\x75\x73\x68\x54\x68\x72\x65\x73\x68\x6f\x6c\x64");}void 
TypedConfigurations::build(Configurations*configurations){base::threading::
ScopedLock scopedLock(lock());auto getBool=[](std::string boolStr)->bool{base::
utils::Str::trim(boolStr);return(boolStr=="\x54\x52\x55\x45"||boolStr==
"\x74\x72\x75\x65"||boolStr=="\x31");};std::vector<Configuration*>
withFileSizeLimit;for(Configurations::const_iterator it=configurations->begin();
it!=configurations->end();++it){Configuration*conf=*it;if(conf->
configurationType()==ConfigurationType::Enabled){setValue(conf->level(),getBool(
conf->value()),&m_enabledMap);}else if(conf->configurationType()==
ConfigurationType::ToFile){setValue(conf->level(),getBool(conf->value()),&
m_toFileMap);}else if(conf->configurationType()==ConfigurationType::
ToStandardOutput){setValue(conf->level(),getBool(conf->value()),&
m_toStandardOutputMap);}else if(conf->configurationType()==ConfigurationType::
Filename){}else if(conf->configurationType()==ConfigurationType::Format){
setValue(conf->level(),base::LogFormat(conf->level(),base::type::string_t(conf->
value().begin(),conf->value().end())),&m_logFormatMap);}else if(conf->
configurationType()==ConfigurationType::SubsecondPrecision){setValue(Level::
Global,base::SubsecondPrecision(static_cast<int>(getULong(conf->value()))),&
m_subsecondPrecisionMap);}else if(conf->configurationType()==ConfigurationType::
PerformanceTracking){setValue(Level::Global,getBool(conf->value()),&
m_performanceTrackingMap);}else if(conf->configurationType()==ConfigurationType
::MaxLogFileSize){auto v=getULong(conf->value());setValue(conf->level(),
static_cast<std::size_t>(v),&m_maxLogFileSizeMap);if(v!=(0x1337+3038-0x1f15)){
withFileSizeLimit.push_back(conf);}}else if(conf->configurationType()==
ConfigurationType::LogFlushThreshold){setValue(conf->level(),static_cast<std::
size_t>(getULong(conf->value())),&m_logFlushThresholdMap);}}for(Configurations::
const_iterator it=configurations->begin();it!=configurations->end();++it){
Configuration*conf=*it;if(conf->configurationType()==ConfigurationType::Filename
){insertFile(conf->level(),conf->value());}}for(std::vector<Configuration*>::
iterator conf=withFileSizeLimit.begin();conf!=withFileSizeLimit.end();++conf){
unsafeValidateFileRolling((*conf)->level(),base::defaultPreRollOutCallback);}}
unsigned long TypedConfigurations::getULong(std::string confVal){bool valid=true
;base::utils::Str::trim(confVal);valid=!confVal.empty()&&std::find_if(confVal.
begin(),confVal.end(),[](char c){return!base::utils::Str::isDigit(c);})==confVal
.end();if(!valid){valid=false;ELPP_ASSERT(valid,
"\x43\x6f\x6e\x66\x20\x76\x61\x6c\x20\x6e\x6f\x74\x20\x61\x20\x76\x61\x6c\x69\x64\x20\x69\x6e\x74\x65\x67\x65\x72\x20\x5b"
<<confVal<<"\x5d");return(0x14fc+172-0x15a8);}return atol(confVal.c_str());}std
::string TypedConfigurations::resolveFilename(const std::string&filename){std::
string resultingFilename=filename;std::size_t dateIndex=std::string::npos;std::
string dateTimeFormatSpecifierStr=std::string(base::consts::
kDateTimeFormatSpecifierForFilename);if((dateIndex=resultingFilename.find(
dateTimeFormatSpecifierStr.c_str()))!=std::string::npos){while(dateIndex>
(0xaa4+2330-0x13be)&&resultingFilename[dateIndex-(0x78a+3663-0x15d8)]==base::
consts::kFormatSpecifierChar){dateIndex=resultingFilename.find(
dateTimeFormatSpecifierStr.c_str(),dateIndex+(0x7a5+35-0x7c7));}if(dateIndex!=
std::string::npos){const char*ptr=resultingFilename.c_str()+dateIndex;ptr+=
dateTimeFormatSpecifierStr.size();std::string fmt;if((resultingFilename.size()>
dateIndex)&&(ptr[(0x15e8+306-0x171a)]==((char)(0x257+7058-0x1d6e)))){++ptr;int 
count=(0x1da2+806-0x20c7);std::stringstream ss;for(;*ptr;++ptr,++count){if(*ptr
==((char)(0x105f+98-0x1044))){++count;break;}ss<<*ptr;}resultingFilename.erase(
dateIndex+dateTimeFormatSpecifierStr.size(),count);fmt=ss.str();}else{fmt=std::
string(base::consts::kDefaultDateTimeFormatInFilename);}base::SubsecondPrecision
 ssPrec((0x1d0c+2257-0x25da));std::string now=base::utils::DateTime::getDateTime
(fmt.c_str(),&ssPrec);base::utils::Str::replaceAll(now,
((char)(0x4fa+5366-0x19c1)),((char)(0x1ae7+374-0x1c30)));base::utils::Str::
replaceAll(resultingFilename,dateTimeFormatSpecifierStr,now);}}return 
resultingFilename;}void TypedConfigurations::insertFile(Level level,const std::
string&fullFilename){std::string resolvedFilename=resolveFilename(fullFilename);
if(resolvedFilename.empty()){std::cerr<<
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6c\x6f\x61\x64\x20\x65\x6d\x70\x74\x79\x20\x66\x69\x6c\x65\x2c\x20\x72\x65\x2d\x63\x68\x65\x63\x6b\x20\x79\x6f\x75\x72\x20\x63\x6f\x6e\x66\x20\x66\x6f\x72\x20\x6c\x65\x76\x65\x6c\x20\x5b"
<<LevelHelper::convertToString(level)<<"\x5d";}std::string filePath=base::utils
::File::extractPathFromFilename(resolvedFilename,base::consts::
kFilePathSeperator);if(filePath.size()<resolvedFilename.size()){base::utils::
File::createPath(filePath);}auto create=[&](Level level){base::
LogStreamsReferenceMap::iterator filestreamIter=m_logStreamsReference->find(
resolvedFilename);base::type::fstream_t*fs=nullptr;if(filestreamIter==
m_logStreamsReference->end()){fs=base::utils::File::newFileStream(
resolvedFilename);m_filenameMap.insert(std::make_pair(level,resolvedFilename));
m_fileStreamMap.insert(std::make_pair(level,base::FileStreamPtr(fs)));
m_logStreamsReference->insert(std::make_pair(resolvedFilename,base::
FileStreamPtr(m_fileStreamMap.at(level))));}else{m_filenameMap.insert(std::
make_pair(level,filestreamIter->first));m_fileStreamMap.insert(std::make_pair(
level,base::FileStreamPtr(filestreamIter->second)));fs=filestreamIter->second.
get();}if(fs==nullptr){ELPP_INTERNAL_ERROR(
"\x53\x65\x74\x20\x5b\x54\x4f\x5f\x46\x49\x4c\x45\x5d\x20\x6f\x66\x20\x5b"<<
LevelHelper::convertToString(level)<<"\x5d\x20\x74\x6f\x20\x46\x41\x4c\x53\x45",
false);setValue(level,false,&m_toFileMap);}};create(m_filenameMap.empty()&&
m_fileStreamMap.empty()?Level::Global:level);}bool TypedConfigurations::
unsafeValidateFileRolling(Level level,const PreRollOutCallback&
preRollOutCallback){base::type::fstream_t*fs=unsafeGetConfigByRef(level,&
m_fileStreamMap,"\x66\x69\x6c\x65\x53\x74\x72\x65\x61\x6d").get();if(fs==nullptr
){return true;}std::size_t maxLogFileSize=unsafeGetConfigByVal(level,&
m_maxLogFileSizeMap,"\x6d\x61\x78\x4c\x6f\x67\x46\x69\x6c\x65\x53\x69\x7a\x65");
std::size_t currFileSize=base::utils::File::getSizeOfFile(fs);if(maxLogFileSize
!=(0x1e6d+606-0x20cb)&&currFileSize>=maxLogFileSize){std::string fname=
unsafeGetConfigByRef(level,&m_filenameMap,"\x66\x69\x6c\x65\x6e\x61\x6d\x65");
ELPP_INTERNAL_INFO((0x190d+1838-0x203a),
"\x54\x72\x75\x6e\x63\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x5b"<<fname<<
"\x5d\x20\x61\x73\x20\x61\x20\x72\x65\x73\x75\x6c\x74\x20\x6f\x66\x20\x63\x6f\x6e\x66\x20\x66\x6f\x72\x20\x6c\x65\x76\x65\x6c\x20\x5b"
<<LevelHelper::convertToString(level)<<"\x5d");fs->close();preRollOutCallback(
fname.c_str(),currFileSize);fs->open(fname,std::fstream::out|std::fstream::trunc
);return true;}return false;}bool RegisteredHitCounters::validateEveryN(const 
char*filename,base::type::LineNumber lineNumber,std::size_t n){base::threading::
ScopedLock scopedLock(lock());base::HitCounter*counter=get(filename,lineNumber);
if(counter==nullptr){registerNew(counter=new base::HitCounter(filename,
lineNumber));}counter->validateHitCounts(n);bool result=(n>=(0x101+4502-0x1296)
&&counter->hitCounts()!=(0x1548+3065-0x2141)&&counter->hitCounts()%n==
(0x1158+1285-0x165d));return result;}bool RegisteredHitCounters::validateAfterN(
const char*filename,base::type::LineNumber lineNumber,std::size_t n){base::
threading::ScopedLock scopedLock(lock());base::HitCounter*counter=get(filename,
lineNumber);if(counter==nullptr){registerNew(counter=new base::HitCounter(
filename,lineNumber));}if(counter->hitCounts()>=n)return true;counter->increment
();return false;}bool RegisteredHitCounters::validateNTimes(const char*filename,
base::type::LineNumber lineNumber,std::size_t n){base::threading::ScopedLock 
scopedLock(lock());base::HitCounter*counter=get(filename,lineNumber);if(counter
==nullptr){registerNew(counter=new base::HitCounter(filename,lineNumber));}
counter->increment();if(counter->hitCounts()<=n)return true;return false;}
RegisteredLoggers::RegisteredLoggers(const LogBuilderPtr&defaultLogBuilder):
m_defaultLogBuilder(defaultLogBuilder){m_defaultConfigurations.setToDefault();}
Logger*RegisteredLoggers::get(const std::string&id,bool forceCreation){base::
threading::ScopedLock scopedLock(lock());Logger*logger_=base::utils::Registry<
Logger,std::string>::get(id);if(logger_==nullptr&&forceCreation){bool validId=
Logger::isValidId(id);if(!validId){ELPP_ASSERT(validId,
"\x49\x6e\x76\x20\x6c\x6f\x67\x67\x65\x72\x20\x49\x44\x20\x5b"<<id<<"\x5d\x2e");
return nullptr;}logger_=new Logger(id,m_defaultConfigurations,&
m_logStreamsReference);logger_->m_logBuilder=m_defaultLogBuilder;registerNew(id,
logger_);LoggerRegistrationCallback*callback=nullptr;for(const std::pair<std::
string,base::type::LoggerRegistrationCallbackPtr>&h:
m_loggerRegistrationCallbacks){callback=h.second.get();if(callback!=nullptr&&
callback->enabled()){callback->handle(logger_);}}}return logger_;}bool 
RegisteredLoggers::remove(const std::string&id){if(id==base::consts::
kDefaultLoggerId){return false;}Logger*logger=base::utils::Registry<Logger,std::
string>::get(id);if(logger!=nullptr){unregister(logger);}return true;}void 
RegisteredLoggers::unsafeFlushAll(void){ELPP_INTERNAL_INFO((0xddd+3006-0x199a),
"\x46\x6c\x75\x73\x68\x69\x6e\x67\x20\x61\x6c\x6c\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x73"
);for(base::LogStreamsReferenceMap::iterator it=m_logStreamsReference.begin();it
!=m_logStreamsReference.end();++it){if(it->second.get()==nullptr)continue;it->
second->flush();}}VRegistry::VRegistry(base::type::VerboseLevel level,base::type
::EnumType*pFlags):m_level(level),m_pFlags(pFlags){}void VRegistry::setLevel(
base::type::VerboseLevel level){base::threading::ScopedLock scopedLock(lock());
if(level>(0x2c6+2574-0xccb))m_level=base::consts::kMaxVerboseLevel;else m_level=
level;}void VRegistry::setModules(const char*modules){base::threading::
ScopedLock scopedLock(lock());auto addSuffix=[](std::stringstream&ss,const char*
sfx,const char*prev){if(prev!=nullptr&&base::utils::Str::endsWith(ss.str(),std::
string(prev))){std::string chr(ss.str().substr((0x1875+3001-0x242e),ss.str().
size()-strlen(prev)));ss.str(std::string(""));ss<<chr;}if(base::utils::Str::
endsWith(ss.str(),std::string(sfx))){std::string chr(ss.str().substr(
(0x10a9+2351-0x19d8),ss.str().size()-strlen(sfx)));ss.str(std::string(""));ss<<
chr;}ss<<sfx;};auto insert=[&](std::stringstream&ss,base::type::VerboseLevel 
level){if(!base::utils::hasFlag(LoggingFlag::DisableVModulesExtensions,*m_pFlags
)){addSuffix(ss,"\x2e\x68",nullptr);m_modules.insert(std::make_pair(ss.str(),
level));addSuffix(ss,"\x2e\x63","\x2e\x68");m_modules.insert(std::make_pair(ss.
str(),level));addSuffix(ss,"\x2e\x63\x70\x70","\x2e\x63");m_modules.insert(std::
make_pair(ss.str(),level));addSuffix(ss,"\x2e\x63\x63","\x2e\x63\x70\x70");
m_modules.insert(std::make_pair(ss.str(),level));addSuffix(ss,"\x2e\x63\x78\x78"
,"\x2e\x63\x63");m_modules.insert(std::make_pair(ss.str(),level));addSuffix(ss,
"\x2e\x2d\x69\x6e\x6c\x2e\x68","\x2e\x63\x78\x78");m_modules.insert(std::
make_pair(ss.str(),level));addSuffix(ss,"\x2e\x68\x78\x78",
"\x2e\x2d\x69\x6e\x6c\x2e\x68");m_modules.insert(std::make_pair(ss.str(),level))
;addSuffix(ss,"\x2e\x68\x70\x70","\x2e\x68\x78\x78");m_modules.insert(std::
make_pair(ss.str(),level));addSuffix(ss,"\x2e\x68\x68","\x2e\x68\x70\x70");}
m_modules.insert(std::make_pair(ss.str(),level));};bool isMod=true;bool isLevel=
false;std::stringstream ss;int level=-(0x342+808-0x669);for(;*modules;++modules)
{switch(*modules){case((char)(0x15c2+1035-0x1990)):isLevel=true;isMod=false;
break;case((char)(0xeea+2195-0x1751)):isLevel=false;isMod=true;if(!ss.str().
empty()&&level!=-(0x12ca+1310-0x17e7)){insert(ss,static_cast<base::type::
VerboseLevel>(level));ss.str(std::string(""));level=-(0x1d80+2361-0x26b8);}break
;default:if(isMod){ss<<*modules;}else if(isLevel){if(isdigit(*modules)){level=
static_cast<base::type::VerboseLevel>(*modules)-(0x13aa+1547-0x1985);}}break;}}
if(!ss.str().empty()&&level!=-(0x14+6858-0x1add)){insert(ss,static_cast<base::
type::VerboseLevel>(level));}}bool VRegistry::allowed(base::type::VerboseLevel 
vlevel,const char*file){base::threading::ScopedLock scopedLock(lock());if(
m_modules.empty()||file==nullptr){return vlevel<=m_level;}else{char baseFilename
[base::consts::kSourceFilenameMaxLength]="";base::utils::File::buildBaseFilename
(file,baseFilename);std::unordered_map<std::string,base::type::VerboseLevel>::
iterator it=m_modules.begin();for(;it!=m_modules.end();++it){if(base::utils::Str
::wildCardMatch(baseFilename,it->first.c_str())){return vlevel<=it->second;}}if(
base::utils::hasFlag(LoggingFlag::AllowVerboseIfModuleNotSpecified,*m_pFlags)){
return true;}return false;}}void VRegistry::setFromArgs(const base::utils::
CommandLineArgs*commandLineArgs){if(commandLineArgs->hasParam("\x2d\x76")||
commandLineArgs->hasParam("\x2d\x2d\x76\x65\x72\x62\x6f\x73\x65")||
commandLineArgs->hasParam("\x2d\x56")||commandLineArgs->hasParam(
"\x2d\x2d\x56\x45\x52\x42\x4f\x53\x45")){setLevel(base::consts::kMaxVerboseLevel
);}else if(commandLineArgs->hasParamWithValue("\x2d\x2d\x76")){setLevel(
static_cast<base::type::VerboseLevel>(atoi(commandLineArgs->getParamValue(
"\x2d\x2d\x76"))));}else if(commandLineArgs->hasParamWithValue("\x2d\x2d\x56")){
setLevel(static_cast<base::type::VerboseLevel>(atoi(commandLineArgs->
getParamValue("\x2d\x2d\x56"))));}else if((commandLineArgs->hasParamWithValue(
"\x2d\x76\x6d\x6f\x64\x75\x6c\x65"))&&vModulesEnabled()){setModules(
commandLineArgs->getParamValue("\x2d\x76\x6d\x6f\x64\x75\x6c\x65"));}else if(
commandLineArgs->hasParamWithValue("\x2d\x56\x4d\x4f\x44\x55\x4c\x45")&&
vModulesEnabled()){setModules(commandLineArgs->getParamValue(
"\x2d\x56\x4d\x4f\x44\x55\x4c\x45"));}}
#if !defined(ELPP_DEFAULT_LOGGING_FLAGS)
#   define ELPP_DEFAULT_LOGGING_FLAGS (0x1628+28-0x1644)
#endif 
#if ELPP_ASYNC_LOGGING
Storage::Storage(const LogBuilderPtr&defaultLogBuilder,base::IWorker*
asyncDispatchWorker):
#else
Storage::Storage(const LogBuilderPtr&defaultLogBuilder):
#endif  
m_registeredHitCounters(new base::RegisteredHitCounters()),m_registeredLoggers(
new base::RegisteredLoggers(defaultLogBuilder)),m_flags(
ELPP_DEFAULT_LOGGING_FLAGS),m_vRegistry(new base::VRegistry((0xba5+6063-0x2354),
&m_flags)),
#if ELPP_ASYNC_LOGGING
m_asyncLogQueue(new base::AsyncLogQueue()),m_asyncDispatchWorker(
asyncDispatchWorker),
#endif  
m_preRollOutCallback(base::defaultPreRollOutCallback){m_registeredLoggers->get(
std::string(base::consts::kDefaultLoggerId));m_registeredLoggers->get(
"\x64\x65\x66\x61\x75\x6c\x74");
#if defined(ELPP_FEATURE_ALL) || defined(ELPP_FEATURE_PERFORMANCE_TRACKING)
Logger*performanceLogger=m_registeredLoggers->get(std::string(base::consts::
kPerformanceLoggerId));m_registeredLoggers->get(
"\x70\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65");performanceLogger->
configurations()->setGlobally(ConfigurationType::Format,std::string(
"\x25\x64\x61\x74\x65\x74\x69\x6d\x65\x20\x25\x6c\x65\x76\x65\x6c\x20\x25\x6d\x73\x67"
));performanceLogger->reconfigure();
#endif 
#if defined(ELPP_SYSLOG)
Logger*sysLogLogger=m_registeredLoggers->get(std::string(base::consts::
kSysLogLoggerId));sysLogLogger->configurations()->setGlobally(ConfigurationType
::Format,std::string("\x25\x6c\x65\x76\x65\x6c\x3a\x20\x25\x6d\x73\x67"));
sysLogLogger->reconfigure();
#endif 
addFlag(LoggingFlag::AllowVerboseIfModuleNotSpecified);
#if ELPP_ASYNC_LOGGING
installLogDispatchCallback<base::AsyncLogDispatchCallback>(std::string(
"\x41\x73\x79\x6e\x63\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));
#else
installLogDispatchCallback<base::DefaultLogDispatchCallback>(std::string(
"\x44\x65\x66\x61\x75\x6c\x74\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));
#endif  
#if defined(ELPP_FEATURE_ALL) || defined(ELPP_FEATURE_PERFORMANCE_TRACKING)
installPerformanceTrackingCallback<base::DefaultPerformanceTrackingCallback>(std
::string(
"\x44\x65\x66\x61\x75\x6c\x74\x50\x65\x72\x66\x6f\x72\x6d\x61\x6e\x63\x65\x54\x72\x61\x63\x6b\x69\x6e\x67\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));
#endif 
ELPP_INTERNAL_INFO((0x869+6743-0x22bf),
"\x45\x61\x73\x79\x6c\x6f\x67\x67\x69\x6e\x67\x2b\x2b\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64"
);
#if ELPP_ASYNC_LOGGING
m_asyncDispatchWorker->start();
#endif  
}Storage::~Storage(void){ELPP_INTERNAL_INFO((0x10c9+1304-0x15dd),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x73\x74\x6f\x72\x61\x67\x65");
#if ELPP_ASYNC_LOGGING
ELPP_INTERNAL_INFO((0xfaa+3981-0x1f32),
"\x52\x65\x70\x6c\x61\x63\x69\x6e\x67\x20\x6c\x6f\x67\x20\x64\x69\x73\x70\x61\x74\x63\x68\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x74\x6f\x20\x73\x79\x6e\x63\x68\x72\x6f\x6e\x6f\x75\x73"
);uninstallLogDispatchCallback<base::AsyncLogDispatchCallback>(std::string(
"\x41\x73\x79\x6e\x63\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));installLogDispatchCallback<base::DefaultLogDispatchCallback>(std::string(
"\x44\x65\x66\x61\x75\x6c\x74\x4c\x6f\x67\x44\x69\x73\x70\x61\x74\x63\x68\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));ELPP_INTERNAL_INFO((0x155+5815-0x1807),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x61\x73\x79\x6e\x63\x44\x69\x73\x70\x61\x74\x63\x68\x57\x6f\x72\x6b\x65\x72"
);base::utils::safeDelete(m_asyncDispatchWorker);ELPP_INTERNAL_INFO(
(0x150f+3926-0x2460),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x61\x73\x79\x6e\x63\x4c\x6f\x67\x51\x75\x65\x75\x65"
);base::utils::safeDelete(m_asyncLogQueue);
#endif  
ELPP_INTERNAL_INFO((0x9d5+107-0xa3b),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x48\x69\x74\x43\x6f\x75\x6e\x74\x65\x72\x73"
);base::utils::safeDelete(m_registeredHitCounters);ELPP_INTERNAL_INFO(
(0xc6b+2655-0x16c5),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x4c\x6f\x67\x67\x65\x72\x73"
);base::utils::safeDelete(m_registeredLoggers);ELPP_INTERNAL_INFO(
(0x7af+242-0x89c),
"\x44\x65\x73\x74\x72\x6f\x79\x69\x6e\x67\x20\x76\x52\x65\x67\x69\x73\x74\x72\x79"
);base::utils::safeDelete(m_vRegistry);}bool Storage::hasCustomFormatSpecifier(
const char*formatSpecifier){base::threading::ScopedLock scopedLock(
customFormatSpecifiersLock());return std::find(m_customFormatSpecifiers.begin(),
m_customFormatSpecifiers.end(),formatSpecifier)!=m_customFormatSpecifiers.end();
}void Storage::installCustomFormatSpecifier(const CustomFormatSpecifier&
customFormatSpecifier){if(hasCustomFormatSpecifier(customFormatSpecifier.
formatSpecifier())){return;}base::threading::ScopedLock scopedLock(
customFormatSpecifiersLock());m_customFormatSpecifiers.push_back(
customFormatSpecifier);}bool Storage::uninstallCustomFormatSpecifier(const char*
formatSpecifier){base::threading::ScopedLock scopedLock(
customFormatSpecifiersLock());std::vector<CustomFormatSpecifier>::iterator it=
std::find(m_customFormatSpecifiers.begin(),m_customFormatSpecifiers.end(),
formatSpecifier);if(it!=m_customFormatSpecifiers.end()&&strcmp(formatSpecifier,
it->formatSpecifier())==(0x28b+7105-0x1e4c)){m_customFormatSpecifiers.erase(it);
return true;}return false;}void Storage::setApplicationArguments(int argc,char**
argv){m_commandLineArgs.setArgs(argc,argv);m_vRegistry->setFromArgs(
commandLineArgs());
#if !defined(ELPP_DISABLE_LOG_FILE_FROM_ARG)
if(m_commandLineArgs.hasParamWithValue(base::consts::kDefaultLogFileParam)){
Configurations c;c.setGlobally(ConfigurationType::Filename,std::string(
m_commandLineArgs.getParamValue(base::consts::kDefaultLogFileParam)));
registeredLoggers()->setDefaultConfigurations(c);for(base::RegisteredLoggers::
iterator it=registeredLoggers()->begin();it!=registeredLoggers()->end();++it){it
->second->configure(c);}}
#endif  
#if defined(ELPP_LOGGING_FLAGS_FROM_ARG)
if(m_commandLineArgs.hasParamWithValue(base::consts::kLoggingFlagsParam)){int 
userInput=atoi(m_commandLineArgs.getParamValue(base::consts::kLoggingFlagsParam)
);if(ELPP_DEFAULT_LOGGING_FLAGS==(0xc3c+4608-0x1e3c)){m_flags=userInput;}else{
base::utils::addFlag<base::type::EnumType>(userInput,&m_flags);}}
#endif  
}}void LogDispatchCallback::handle(const LogDispatchData*data){
#if defined(ELPP_THREAD_SAFE)
base::threading::ScopedLock scopedLock(m_fileLocksMapLock);std::string filename=
data->logMessage()->logger()->typedConfigurations()->filename(data->logMessage()
->level());auto lock=m_fileLocks.find(filename);if(lock==m_fileLocks.end()){
m_fileLocks.emplace(std::make_pair(filename,std::unique_ptr<base::threading::
Mutex>(new base::threading::Mutex)));}
#endif
}base::threading::Mutex&LogDispatchCallback::fileHandle(const LogDispatchData*
data){auto it=m_fileLocks.find(data->logMessage()->logger()->typedConfigurations
()->filename(data->logMessage()->level()));return*(it->second.get());}namespace 
base{void DefaultLogDispatchCallback::handle(const LogDispatchData*data){
#if defined(ELPP_THREAD_SAFE)
LogDispatchCallback::handle(data);base::threading::ScopedLock scopedLock(
fileHandle(data));
#endif
m_data=data;dispatch(m_data->logMessage()->logger()->logBuilder()->build(m_data
->logMessage(),m_data->dispatchAction()==base::DispatchAction::NormalLog));}void
 DefaultLogDispatchCallback::dispatch(base::type::string_t&&logLine){if(m_data->
dispatchAction()==base::DispatchAction::NormalLog){if(m_data->logMessage()->
logger()->m_typedConfigurations->toFile(m_data->logMessage()->level())){base::
type::fstream_t*fs=m_data->logMessage()->logger()->m_typedConfigurations->
fileStream(m_data->logMessage()->level());if(fs!=nullptr){fs->write(logLine.
c_str(),logLine.size());if(fs->fail()){ELPP_INTERNAL_ERROR(
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x6c\x6f\x67\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x5b"
<<m_data->logMessage()->logger()->m_typedConfigurations->filename(m_data->
logMessage()->level())<<"\x5d\x2e" "\n"<<
"\x46\x65\x77\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x72\x65\x61\x73\x6f\x6e\x73\x20\x28\x63\x6f\x75\x6c\x64\x20\x62\x65\x20\x73\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x65\x6c\x73\x65\x29\x3a" "\n"
<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x20\x64\x65\x6e\x69\x65\x64" "\n"
<<"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x66\x75\x6c\x6c" "\n"<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x69\x73\x20\x6e\x6f\x74\x20\x77\x72\x69\x74\x61\x62\x6c\x65"
,true);}else{if(ELPP->hasFlag(LoggingFlag::ImmediateFlush)||(m_data->logMessage(
)->logger()->isFlushNeeded(m_data->logMessage()->level()))){m_data->logMessage()
->logger()->flush(m_data->logMessage()->level(),fs);}}}else{ELPP_INTERNAL_ERROR(
"\x4c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x5b"<<LevelHelper::
convertToString(m_data->logMessage()->level())<<"\x5d\x20"<<
"\x68\x61\x73\x20\x6e\x6f\x74\x20\x62\x65\x65\x6e\x20\x63\x6f\x6e\x66\x20\x62\x75\x74\x20\x5b\x54\x4f\x5f\x46\x49\x4c\x45\x5d\x20\x69\x73\x20\x63\x6f\x6e\x66\x64\x20\x74\x6f\x20\x54\x52\x55\x45\x2e\x20\x5b\x4c\x6f\x67\x67\x65\x72\x20\x49\x44\x3a\x20"
<<m_data->logMessage()->logger()->id()<<"\x5d",false);}}if(m_data->logMessage()
->logger()->m_typedConfigurations->toStandardOutput(m_data->logMessage()->level(
))){if(ELPP->hasFlag(LoggingFlag::ColoredTerminalOutput))m_data->logMessage()->
logger()->logBuilder()->convertToColoredOutput(&logLine,m_data->logMessage()->
level());ELPP_COUT<<ELPP_COUT_LINE(logLine);}}
#if defined(ELPP_SYSLOG)
else if(m_data->dispatchAction()==base::DispatchAction::SysLog){int 
sysLogPriority=(0x104a+1964-0x17f6);if(m_data->logMessage()->level()==Level::
Fatal)sysLogPriority=LOG_EMERG;else if(m_data->logMessage()->level()==Level::
Error)sysLogPriority=LOG_ERR;else if(m_data->logMessage()->level()==Level::
Warning)sysLogPriority=LOG_WARNING;else if(m_data->logMessage()->level()==Level
::Info)sysLogPriority=LOG_INFO;else if(m_data->logMessage()->level()==Level::
Debug)sysLogPriority=LOG_DEBUG;else sysLogPriority=LOG_NOTICE;
#  if defined(ELPP_UNICODE)
char*line=base::utils::Str::wcharPtrToCharPtr(logLine.c_str());syslog(
sysLogPriority,"\x25\x73",line);free(line);
#  else
syslog(sysLogPriority,"\x25\x73",logLine.c_str());
#  endif
}
#endif  
}
#if ELPP_ASYNC_LOGGING
void AsyncLogDispatchCallback::handle(const LogDispatchData*data){base::type::
string_t logLine=data->logMessage()->logger()->logBuilder()->build(data->
logMessage(),data->dispatchAction()==base::DispatchAction::NormalLog);if(data->
dispatchAction()==base::DispatchAction::NormalLog&&data->logMessage()->logger()
->typedConfigurations()->toStandardOutput(data->logMessage()->level())){if(ELPP
->hasFlag(LoggingFlag::ColoredTerminalOutput))data->logMessage()->logger()->
logBuilder()->convertToColoredOutput(&logLine,data->logMessage()->level());
ELPP_COUT<<ELPP_COUT_LINE(logLine);}if(data->logMessage()->logger()->
typedConfigurations()->toFile(data->logMessage()->level())){ELPP->asyncLogQueue(
)->push(AsyncLogItem(*(data->logMessage()),*data,logLine));}}AsyncDispatchWorker
::AsyncDispatchWorker(){setContinueRunning(false);}AsyncDispatchWorker::~
AsyncDispatchWorker(){setContinueRunning(false);ELPP_INTERNAL_INFO(
(0xa88+3092-0x1696),
"\x53\x74\x6f\x70\x70\x69\x6e\x67\x20\x64\x69\x73\x70\x61\x74\x63\x68\x20\x77\x6f\x72\x6b\x65\x72\x20\x2d\x20\x43\x6c\x65\x61\x6e\x69\x6e\x67\x20\x6c\x6f\x67\x20\x71\x75\x65\x75\x65"
);clean();ELPP_INTERNAL_INFO((0x13aa+3910-0x22ea),
"\x4c\x6f\x67\x20\x71\x75\x65\x75\x65\x20\x63\x6c\x65\x61\x6e\x65\x64");}bool 
AsyncDispatchWorker::clean(void){std::mutex m;std::unique_lock<std::mutex>lk(m);
cv.wait(lk,[]{return!ELPP->asyncLogQueue()->empty();});emptyQueue();lk.unlock();
cv.notify_one();return ELPP->asyncLogQueue()->empty();}void AsyncDispatchWorker
::emptyQueue(void){while(!ELPP->asyncLogQueue()->empty()){AsyncLogItem data=ELPP
->asyncLogQueue()->next();handle(&data);base::threading::msleep(
(0xffb+5100-0x2383));}}void AsyncDispatchWorker::start(void){base::threading::
msleep((0x1f50+2170-0x1442));setContinueRunning(true);std::thread t1(&
AsyncDispatchWorker::run,this);t1.join();}void AsyncDispatchWorker::handle(
AsyncLogItem*logItem){LogDispatchData*data=logItem->data();LogMessage*logMessage
=logItem->logMessage();Logger*logger=logMessage->logger();base::
TypedConfigurations*conf=logger->typedConfigurations();base::type::string_t 
logLine=logItem->logLine();if(data->dispatchAction()==base::DispatchAction::
NormalLog){if(conf->toFile(logMessage->level())){base::type::fstream_t*fs=conf->
fileStream(logMessage->level());if(fs!=nullptr){fs->write(logLine.c_str(),
logLine.size());if(fs->fail()){ELPP_INTERNAL_ERROR(
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x6c\x6f\x67\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x5b"
<<conf->filename(logMessage->level())<<"\x5d\x2e" "\n"<<
"\x46\x65\x77\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x72\x65\x61\x73\x6f\x6e\x73\x20\x28\x63\x6f\x75\x6c\x64\x20\x62\x65\x20\x73\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x65\x6c\x73\x65\x29\x3a" "\n"
<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x20\x64\x65\x6e\x69\x65\x64" "\n"
<<"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x66\x75\x6c\x6c" "\n"<<
"\x20\x20\x20\x20\x20\x20\x2a\x20\x44\x69\x73\x6b\x20\x69\x73\x20\x6e\x6f\x74\x20\x77\x72\x69\x74\x61\x62\x6c\x65"
,true);}else{if(ELPP->hasFlag(LoggingFlag::ImmediateFlush)||(logger->
isFlushNeeded(logMessage->level()))){logger->flush(logMessage->level(),fs);}}}
else{ELPP_INTERNAL_ERROR(
"\x4c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x5b"<<LevelHelper::
convertToString(logMessage->level())<<"\x5d\x20"<<
"\x68\x61\x73\x20\x6e\x6f\x74\x20\x62\x65\x65\x6e\x20\x63\x6f\x6e\x66\x20\x62\x75\x74\x20\x5b\x54\x4f\x5f\x46\x49\x4c\x45\x5d\x20\x69\x73\x20\x63\x6f\x6e\x66\x64\x20\x74\x6f\x20\x54\x52\x55\x45\x2e\x20\x5b\x4c\x6f\x67\x67\x65\x72\x20\x49\x44\x3a\x20"
<<logger->id()<<"\x5d",false);}}}
#  if defined(ELPP_SYSLOG)
else if(data->dispatchAction()==base::DispatchAction::SysLog){int sysLogPriority
=(0xbb2+1534-0x11b0);if(logMessage->level()==Level::Fatal)sysLogPriority=
LOG_EMERG;else if(logMessage->level()==Level::Error)sysLogPriority=LOG_ERR;else 
if(logMessage->level()==Level::Warning)sysLogPriority=LOG_WARNING;else if(
logMessage->level()==Level::Info)sysLogPriority=LOG_INFO;else if(logMessage->
level()==Level::Debug)sysLogPriority=LOG_DEBUG;else sysLogPriority=LOG_NOTICE;
#      if defined(ELPP_UNICODE)
char*line=base::utils::Str::wcharPtrToCharPtr(logLine.c_str());syslog(
sysLogPriority,"\x25\x73",line);free(line);
#      else
syslog(sysLogPriority,"\x25\x73",logLine.c_str());
#      endif
}
#  endif  
}void AsyncDispatchWorker::run(void){while(continueRunning()){emptyQueue();base
::threading::msleep((0x1342+670-0x15d6));}}
#endif  
base::type::string_t DefaultLogBuilder::build(const LogMessage*logMessage,bool 
appendNewLine)const{base::TypedConfigurations*tc=logMessage->logger()->
typedConfigurations();const base::LogFormat*logFormat=&tc->logFormat(logMessage
->level());base::type::string_t logLine=logFormat->format();char buff[base::
consts::kSourceFilenameMaxLength+base::consts::kSourceLineMaxLength]="";const 
char*bufLim=buff+sizeof(buff);if(logFormat->hasFlag(base::FormatFlags::AppName))
{base::utils::Str::replaceFirstWithEscape(logLine,base::consts::
kAppNameFormatSpecifier,logMessage->logger()->parentApplicationName());}if(
logFormat->hasFlag(base::FormatFlags::ThreadId)){base::utils::Str::
replaceFirstWithEscape(logLine,base::consts::kThreadIdFormatSpecifier,ELPP->
getThreadName(base::threading::getCurrentThreadId()));}if(logFormat->hasFlag(
base::FormatFlags::DateTime)){base::utils::Str::replaceFirstWithEscape(logLine,
base::consts::kDateTimeFormatSpecifier,base::utils::DateTime::getDateTime(
logFormat->dateTimeFormat().c_str(),&tc->subsecondPrecision(logMessage->level())
));}if(logFormat->hasFlag(base::FormatFlags::Function)){base::utils::Str::
replaceFirstWithEscape(logLine,base::consts::kLogFunctionFormatSpecifier,
logMessage->func());}if(logFormat->hasFlag(base::FormatFlags::File)){base::utils
::Str::clearBuff(buff,base::consts::kSourceFilenameMaxLength);base::utils::File
::buildStrippedFilename(logMessage->file().c_str(),buff);base::utils::Str::
replaceFirstWithEscape(logLine,base::consts::kLogFileFormatSpecifier,std::string
(buff));}if(logFormat->hasFlag(base::FormatFlags::FileBase)){base::utils::Str::
clearBuff(buff,base::consts::kSourceFilenameMaxLength);base::utils::File::
buildBaseFilename(logMessage->file(),buff);base::utils::Str::
replaceFirstWithEscape(logLine,base::consts::kLogFileBaseFormatSpecifier,std::
string(buff));}if(logFormat->hasFlag(base::FormatFlags::Line)){char*buf=base::
utils::Str::clearBuff(buff,base::consts::kSourceLineMaxLength);buf=base::utils::
Str::convertAndAddToBuff(logMessage->line(),base::consts::kSourceLineMaxLength,
buf,bufLim,false);base::utils::Str::replaceFirstWithEscape(logLine,base::consts
::kLogLineFormatSpecifier,std::string(buff));}if(logFormat->hasFlag(base::
FormatFlags::Location)){char*buf=base::utils::Str::clearBuff(buff,base::consts::
kSourceFilenameMaxLength+base::consts::kSourceLineMaxLength);base::utils::File::
buildStrippedFilename(logMessage->file().c_str(),buff);buf=base::utils::Str::
addToBuff(buff,buf,bufLim);buf=base::utils::Str::addToBuff("\x3a",buf,bufLim);
buf=base::utils::Str::convertAndAddToBuff(logMessage->line(),base::consts::
kSourceLineMaxLength,buf,bufLim,false);base::utils::Str::replaceFirstWithEscape(
logLine,base::consts::kLogLocationFormatSpecifier,std::string(buff));}if(
logMessage->level()==Level::Verbose&&logFormat->hasFlag(base::FormatFlags::
VerboseLevel)){char*buf=base::utils::Str::clearBuff(buff,(0x9f3+3711-0x1871));
buf=base::utils::Str::convertAndAddToBuff(logMessage->verboseLevel(),
(0x79f+5752-0x1e16),buf,bufLim,false);base::utils::Str::replaceFirstWithEscape(
logLine,base::consts::kVerboseLevelFormatSpecifier,std::string(buff));}if(
logFormat->hasFlag(base::FormatFlags::LogMessage)){base::utils::Str::
replaceFirstWithEscape(logLine,base::consts::kMessageFormatSpecifier,logMessage
->message());}
#if !defined(ELPP_DISABLE_CUSTOM_FORMAT_SPECIFIERS)
el::base::threading::ScopedLock lock_(ELPP->customFormatSpecifiersLock());
ELPP_UNUSED(lock_);for(std::vector<CustomFormatSpecifier>::const_iterator it=
ELPP->customFormatSpecifiers()->begin();it!=ELPP->customFormatSpecifiers()->end(
);++it){std::string fs(it->formatSpecifier());base::type::string_t 
wcsFormatSpecifier(fs.begin(),fs.end());base::utils::Str::replaceFirstWithEscape
(logLine,wcsFormatSpecifier,it->resolver()(logMessage));}
#endif  
if(appendNewLine)logLine+=ELPP_LITERAL("\n");return logLine;}void LogDispatcher
::dispatch(void){if(m_proceed&&m_dispatchAction==base::DispatchAction::None){
m_proceed=false;}if(!m_proceed){return;}
#ifndef ELPP_NO_GLOBAL_LOCK
base::threading::ScopedLock scopedLock(ELPP->lock());
#endif
base::TypedConfigurations*tc=m_logMessage->logger()->m_typedConfigurations;if(
ELPP->hasFlag(LoggingFlag::StrictLogFileSizeCheck)){tc->validateFileRolling(
m_logMessage->level(),ELPP->preRollOutCallback());}LogDispatchCallback*callback=
nullptr;LogDispatchData data;for(const std::pair<std::string,base::type::
LogDispatchCallbackPtr>&h:ELPP->m_logDispatchCallbacks){callback=h.second.get();
if(callback!=nullptr&&callback->enabled()){data.setLogMessage(m_logMessage);data
.setDispatchAction(m_dispatchAction);callback->handle(&data);}}}void 
MessageBuilder::initialize(Logger*logger){m_logger=logger;
m_containerLogSeperator=ELPP->hasFlag(LoggingFlag::NewLineForContainer)?
ELPP_LITERAL("\n" "\x20\x20\x20\x20"):ELPP_LITERAL("\x2c\x20");}MessageBuilder&
MessageBuilder::operator<<(const wchar_t*msg){if(msg==nullptr){m_logger->stream(
)<<base::consts::kNullPointer;return*this;}
#  if defined(ELPP_UNICODE)
m_logger->stream()<<msg;
#  else
char*buff_=base::utils::Str::wcharPtrToCharPtr(msg);m_logger->stream()<<buff_;
free(buff_);
#  endif
if(ELPP->hasFlag(LoggingFlag::AutoSpacing)){m_logger->stream()<<"\x20";}return*
this;}Writer&Writer::construct(Logger*logger,bool needLock){m_logger=logger;
initializeLogger(logger->id(),false,needLock);m_messageBuilder.initialize(
m_logger);return*this;}Writer&Writer::construct(int count,const char*loggerIds,
...){if(ELPP->hasFlag(LoggingFlag::MultiLoggerSupport)){va_list loggersList;
va_start(loggersList,loggerIds);const char*id=loggerIds;m_loggerIds.reserve(
count);for(int i=(0x1b61+2223-0x2410);i<count;++i){m_loggerIds.push_back(std::
string(id));id=va_arg(loggersList,const char*);}va_end(loggersList);
initializeLogger(m_loggerIds.at((0x16fb+1728-0x1dbb)));}else{initializeLogger(
std::string(loggerIds));}m_messageBuilder.initialize(m_logger);return*this;}void
 Writer::initializeLogger(const std::string&loggerId,bool lookup,bool needLock){
if(lookup){m_logger=ELPP->registeredLoggers()->get(loggerId,ELPP->hasFlag(
LoggingFlag::CreateLoggerAutomatically));}if(m_logger==nullptr){{if(!ELPP->
registeredLoggers()->has(std::string(base::consts::kDefaultLoggerId))){ELPP->
registeredLoggers()->get(std::string(base::consts::kDefaultLoggerId));}}Writer(
Level::Debug,m_file,m_line,m_func).construct((0xc9+6604-0x1a94),base::consts::
kDefaultLoggerId)<<"\x4c\x6f\x67\x67\x65\x72\x20\x5b"<<loggerId<<
"\x5d\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x20\x79\x65\x74\x21"
;m_proceed=false;}else{if(needLock){m_logger->acquireLock();}if(ELPP->hasFlag(
LoggingFlag::HierarchicalLogging)){m_proceed=m_level==Level::Verbose?m_logger->
enabled(m_level):LevelHelper::castToInt(m_level)>=LevelHelper::castToInt(ELPP->
m_loggingLevel);}else{m_proceed=m_logger->enabled(m_level);}}}void Writer::
processDispatch(){
#if ELPP_LOGGING_ENABLED
if(ELPP->hasFlag(LoggingFlag::MultiLoggerSupport)){bool firstDispatched=false;
base::type::string_t logMessage;std::size_t i=(0x5e3+975-0x9b2);do{if(m_proceed)
{if(firstDispatched){m_logger->stream()<<logMessage;}else{firstDispatched=true;
if(m_loggerIds.size()>(0x91c+1328-0xe4b)){logMessage=m_logger->stream().str();}}
triggerDispatch();}else if(m_logger!=nullptr){m_logger->stream().str(
ELPP_LITERAL(""));m_logger->releaseLock();}if(i+(0xe65+3820-0x1d50)<m_loggerIds.
size()){initializeLogger(m_loggerIds.at(i+(0x1e1c+1531-0x2416)));}}while(++i<
m_loggerIds.size());}else{if(m_proceed){triggerDispatch();}else if(m_logger!=
nullptr){m_logger->stream().str(ELPP_LITERAL(""));m_logger->releaseLock();}}
#else
if(m_logger!=nullptr){m_logger->stream().str(ELPP_LITERAL(""));m_logger->
releaseLock();}
#endif 
}void Writer::triggerDispatch(void){if(m_proceed){if(m_msg==nullptr){LogMessage 
msg(m_level,m_file,m_line,m_func,m_verboseLevel,m_logger);base::LogDispatcher(
m_proceed,&msg,m_dispatchAction).dispatch();}else{base::LogDispatcher(m_proceed,
m_msg,m_dispatchAction).dispatch();}}if(m_logger!=nullptr){m_logger->stream().
str(ELPP_LITERAL(""));m_logger->releaseLock();}if(m_proceed&&m_level==Level::
Fatal&&!ELPP->hasFlag(LoggingFlag::DisableApplicationAbortOnFatalLog)){base::
Writer(Level::Warning,m_file,m_line,m_func).construct((0x2139+1150-0x25b6),base
::consts::kDefaultLoggerId)<<
"\x41\x62\x6f\x72\x74\x69\x6e\x67\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2e\x20\x52\x65\x61\x73\x6f\x6e\x3a\x20\x46\x61\x74\x61\x6c\x20\x6c\x6f\x67\x20\x61\x74\x20\x5b"
<<m_file<<"\x3a"<<m_line<<"\x5d";std::stringstream reasonStream;reasonStream<<
"\x46\x61\x74\x61\x6c\x20\x6c\x6f\x67\x20\x61\x74\x20\x5b"<<m_file<<"\x3a"<<
m_line<<"\x5d"<<
"\x20\x49\x66\x20\x79\x6f\x75\x20\x77\x69\x73\x68\x20\x74\x6f\x20\x64\x69\x73\x61\x62\x6c\x65\x20\x27\x61\x62\x6f\x72\x74\x20\x6f\x6e\x20\x66\x61\x74\x61\x6c\x20\x6c\x6f\x67\x27\x20\x70\x6c\x65\x61\x73\x65\x20\x75\x73\x65\x20"
<<
"\x65\x6c\x3a\x3a\x4c\x6f\x67\x67\x65\x72\x73\x3a\x3a\x61\x64\x64\x46\x6c\x61\x67\x28\x65\x6c\x3a\x3a\x4c\x6f\x67\x67\x69\x6e\x67\x46\x6c\x61\x67\x3a\x3a\x44\x69\x73\x61\x62\x6c\x65\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x41\x62\x6f\x72\x74\x4f\x6e\x46\x61\x74\x61\x6c\x4c\x6f\x67\x29"
;base::utils::abort((0xa43+6394-0x233c),reasonStream.str());}m_proceed=false;}
PErrorWriter::~PErrorWriter(void){if(m_proceed){
#if ELPP_COMPILER_MSVC
char buff[(0xa7d+3797-0x1852)];strerror_s(buff,(0xb6f+4120-0x1a87),errno);
m_logger->stream()<<"\x3a\x20"<<buff<<"\x20\x5b"<<errno<<"\x5d";
#else
m_logger->stream()<<"\x3a\x20"<<strerror(errno)<<"\x20\x5b"<<errno<<"\x5d";
#endif
}}
#if defined(ELPP_FEATURE_ALL) || defined(ELPP_FEATURE_PERFORMANCE_TRACKING)
PerformanceTracker::PerformanceTracker(const std::string&blockName,base::
TimestampUnit timestampUnit,const std::string&loggerId,bool scopedLog,Level 
level):m_blockName(blockName),m_timestampUnit(timestampUnit),m_loggerId(loggerId
),m_scopedLog(scopedLog),m_level(level),m_hasChecked(false),m_lastCheckpointId(
std::string()),m_enabled(false){
#if !defined(ELPP_DISABLE_PERFORMANCE_TRACKING) && ELPP_LOGGING_ENABLED
el::Logger*loggerPtr=ELPP->registeredLoggers()->get(loggerId,false);m_enabled=
loggerPtr!=nullptr&&loggerPtr->m_typedConfigurations->performanceTracking(
m_level);if(m_enabled){base::utils::DateTime::gettimeofday(&m_startTime);}
#endif  
}PerformanceTracker::~PerformanceTracker(void){
#if !defined(ELPP_DISABLE_PERFORMANCE_TRACKING) && ELPP_LOGGING_ENABLED
if(m_enabled){base::threading::ScopedLock scopedLock(lock());if(m_scopedLog){
base::utils::DateTime::gettimeofday(&m_endTime);base::type::string_t 
formattedTime=getFormattedTimeTaken();PerformanceTrackingData data(
PerformanceTrackingData::DataType::Complete);data.init(this);data.
m_formattedTimeTaken=formattedTime;PerformanceTrackingCallback*callback=nullptr;
for(const std::pair<std::string,base::type::PerformanceTrackingCallbackPtr>&h:
ELPP->m_performanceTrackingCallbacks){callback=h.second.get();if(callback!=
nullptr&&callback->enabled()){callback->handle(&data);}}}}
#endif  
}void PerformanceTracker::checkpoint(const std::string&id,const char*file,base::
type::LineNumber line,const char*func){
#if !defined(ELPP_DISABLE_PERFORMANCE_TRACKING) && ELPP_LOGGING_ENABLED
if(m_enabled){base::threading::ScopedLock scopedLock(lock());base::utils::
DateTime::gettimeofday(&m_endTime);base::type::string_t formattedTime=
m_hasChecked?getFormattedTimeTaken(m_lastCheckpointTime):ELPP_LITERAL("");
PerformanceTrackingData data(PerformanceTrackingData::DataType::Checkpoint);data
.init(this);data.m_checkpointId=id;data.m_file=file;data.m_line=line;data.m_func
=func;data.m_formattedTimeTaken=formattedTime;PerformanceTrackingCallback*
callback=nullptr;for(const std::pair<std::string,base::type::
PerformanceTrackingCallbackPtr>&h:ELPP->m_performanceTrackingCallbacks){callback
=h.second.get();if(callback!=nullptr&&callback->enabled()){callback->handle(&
data);}}base::utils::DateTime::gettimeofday(&m_lastCheckpointTime);m_hasChecked=
true;m_lastCheckpointId=id;}
#endif  
ELPP_UNUSED(id);ELPP_UNUSED(file);ELPP_UNUSED(line);ELPP_UNUSED(func);}const 
base::type::string_t PerformanceTracker::getFormattedTimeTaken(struct timeval 
startTime)const{if(ELPP->hasFlag(LoggingFlag::FixedTimeFormat)){base::type::
stringstream_t ss;ss<<base::utils::DateTime::getTimeDifference(m_endTime,
startTime,m_timestampUnit)<<"\x20"<<base::consts::kTimeFormats[static_cast<base
::type::EnumType>(m_timestampUnit)].unit;return ss.str();}return base::utils::
DateTime::formatTime(base::utils::DateTime::getTimeDifference(m_endTime,
startTime,m_timestampUnit),m_timestampUnit);}
#endif 
namespace debug{
#if defined(ELPP_FEATURE_ALL) || defined(ELPP_FEATURE_CRASH_LOG)
StackTrace::StackTraceEntry::StackTraceEntry(std::size_t index,const std::string
&loc,const std::string&demang,const std::string&hex,const std::string&addr):
m_index(index),m_location(loc),m_demangled(demang),m_hex(hex),m_addr(addr){}std
::ostream&operator<<(std::ostream&ss,const StackTrace::StackTraceEntry&si){ss<<
"\x5b"<<si.m_index<<"\x5d\x20"<<si.m_location<<(si.m_hex.empty()?"":"\x2b")<<si.
m_hex<<"\x20"<<si.m_addr<<(si.m_demangled.empty()?"":"\x3a")<<si.m_demangled;
return ss;}std::ostream&operator<<(std::ostream&os,const StackTrace&st){std::
vector<StackTrace::StackTraceEntry>::const_iterator it=st.m_stack.begin();while(
it!=st.m_stack.end()){os<<"\x20\x20\x20\x20"<<*it++<<"\n";}return os;}void 
StackTrace::generateNew(void){
#if ELPP_STACKTRACE
m_stack.clear();void*stack[kMaxStack];unsigned int size=backtrace(stack,
kMaxStack);char**strings=backtrace_symbols(stack,size);if(size>kStackStart){for(
std::size_t i=kStackStart;i<size;++i){std::string mangName;std::string location;
std::string hex;std::string addr;const std::string line(strings[i]);auto p=line.
find("\x5f");if(p!=std::string::npos){mangName=line.substr(p);mangName=mangName.
substr((0x99+5937-0x17ca),mangName.find("\x20\x2b"));}p=line.find("\x30\x78");if
(p!=std::string::npos){addr=line.substr(p);addr=addr.substr((0x929+4548-0x1aed),
addr.find("\x5f"));}if(!mangName.empty()){int status=(0x188d+643-0x1b10);char*
demangName=abi::__cxa_demangle(mangName.data(),(0x9f5+682-0xc9f),
(0x4f+2898-0xba1),&status);if(status==(0xf5a+5681-0x258b)){StackTraceEntry entry
(i-(0x3b4+7855-0x2262),location,demangName,hex,addr);m_stack.push_back(entry);}
else{StackTraceEntry entry(i-(0x1876+790-0x1b8b),location,mangName,hex,addr);
m_stack.push_back(entry);}free(demangName);}else{StackTraceEntry entry(i-
(0x69d+1842-0xdce),line);m_stack.push_back(entry);}}}free(strings);
#else
ELPP_INTERNAL_INFO((0x2b2+6288-0x1b41),
"\x53\x74\x61\x63\x6b\x74\x72\x61\x63\x65\x20\x67\x65\x6e\x65\x72\x61\x74\x69\x6f\x6e\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x66\x6f\x72\x20\x73\x65\x6c\x65\x63\x74\x65\x64\x20\x63\x6f\x6d\x70\x69\x6c\x65\x72"
);
#endif  
}static std::string crashReason(int sig){std::stringstream ss;bool foundReason=
false;for(int i=(0x18fd+69-0x1942);i<base::consts::kCrashSignalsCount;++i){if(
base::consts::kCrashSignals[i].numb==sig){ss<<
"\x43\x72\x61\x73\x68\x65\x64\x20\x64\x75\x65\x20\x74\x6f\x20\x5b"<<base::consts
::kCrashSignals[i].name<<"\x5d\x20\x73\x69\x67\x6e\x61\x6c";if(ELPP->hasFlag(el
::LoggingFlag::LogDetailedCrashReason)){ss<<std::endl<<"\x20\x20\x20\x20"<<base
::consts::kCrashSignals[i].brief<<std::endl<<"\x20\x20\x20\x20"<<base::consts::
kCrashSignals[i].detail;}foundReason=true;}}if(!foundReason){ss<<
"\x43\x72\x61\x73\x68\x65\x64\x20\x64\x75\x65\x20\x74\x6f\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x73\x69\x67\x6e\x61\x6c\x20\x5b"
<<sig<<"\x5d";}return ss.str();}static void logCrashReason(int sig,bool 
stackTraceIfAvailable,Level level,const char*logger){if(sig==SIGINT&&ELPP->
hasFlag(el::LoggingFlag::IgnoreSigInt)){return;}std::stringstream ss;ss<<
"\x43\x52\x41\x53\x48\x20\x48\x41\x4e\x44\x4c\x45\x44\x3b\x20";ss<<crashReason(
sig);
#if ELPP_STACKTRACE
if(stackTraceIfAvailable){ss<<std::endl<<
"\x20\x20\x20\x20\x3d\x3d\x3d\x3d\x3d\x3d\x3d\x20\x42\x61\x63\x6b\x74\x72\x61\x63\x65\x3a\x20\x3d\x3d\x3d\x3d\x3d\x3d\x3d\x3d\x3d"
<<std::endl<<base::debug::StackTrace();}
#else
ELPP_UNUSED(stackTraceIfAvailable);
#endif  
ELPP_WRITE_LOG(el::base::Writer,level,base::DispatchAction::NormalLog,logger)<<
ss.str();}static inline void crashAbort(int sig){base::utils::abort(sig,std::
string());}static inline void defaultCrashHandler(int sig){base::debug::
logCrashReason(sig,true,Level::Fatal,base::consts::kDefaultLoggerId);base::debug
::crashAbort(sig);}CrashHandler::CrashHandler(bool useDefault){if(useDefault){
setHandler(defaultCrashHandler);}}void CrashHandler::setHandler(const Handler&
cHandler){m_handler=cHandler;
#if defined(ELPP_HANDLE_SIGABRT)
int i=(0x36+8342-0x20cc);
#else
int i=(0x1807+3268-0x24ca);
#endif  
for(;i<base::consts::kCrashSignalsCount;++i){m_handler=signal(base::consts::
kCrashSignals[i].numb,cHandler);}}
#endif 
}}
#if defined(ELPP_FEATURE_ALL) || defined(ELPP_FEATURE_CRASH_LOG)
void Helpers::crashAbort(int sig,const char*sourceFile,unsigned int long line){
std::stringstream ss;ss<<base::debug::crashReason(sig).c_str();ss<<
"\x20\x2d\x20\x5b\x43\x61\x6c\x6c\x65\x64\x20\x65\x6c\x3a\x3a\x48\x65\x6c\x70\x65\x72\x73\x3a\x3a\x63\x72\x61\x73\x68\x41\x62\x6f\x72\x74\x28"
<<sig<<"\x29\x5d";if(sourceFile!=nullptr&&strlen(sourceFile)>(0x67a+3999-0x1619)
){ss<<"\x20\x2d\x20\x53\x6f\x75\x72\x63\x65\x3a\x20"<<sourceFile;if(line>
(0x693+4292-0x1757))ss<<"\x3a"<<line;else ss<<
"\x20\x28\x6c\x69\x6e\x65\x20\x6e\x75\x6d\x62\x65\x72\x20\x6e\x6f\x74\x20\x73\x70\x65\x63\x69\x66\x69\x65\x64\x29"
;}base::utils::abort(sig,ss.str());}void Helpers::logCrashReason(int sig,bool 
stackTraceIfAvailable,Level level,const char*logger){el::base::debug::
logCrashReason(sig,stackTraceIfAvailable,level,logger);}
#endif 
Logger*Loggers::getLogger(const std::string&identity,bool registerIfNotAvailable
){return ELPP->registeredLoggers()->get(identity,registerIfNotAvailable);}void 
Loggers::setDefaultLogBuilder(el::LogBuilderPtr&logBuilderPtr){ELPP->
registeredLoggers()->setDefaultLogBuilder(logBuilderPtr);}bool Loggers::
unregisterLogger(const std::string&identity){return ELPP->registeredLoggers()->
remove(identity);}bool Loggers::hasLogger(const std::string&identity){return 
ELPP->registeredLoggers()->has(identity);}Logger*Loggers::reconfigureLogger(
Logger*logger,const Configurations&configurations){if(!logger)return nullptr;
logger->configure(configurations);return logger;}Logger*Loggers::
reconfigureLogger(const std::string&identity,const Configurations&configurations
){return Loggers::reconfigureLogger(Loggers::getLogger(identity),configurations)
;}Logger*Loggers::reconfigureLogger(const std::string&identity,ConfigurationType
 configurationType,const std::string&value){Logger*logger=Loggers::getLogger(
identity);if(logger==nullptr){return nullptr;}logger->configurations()->set(
Level::Global,configurationType,value);logger->reconfigure();return logger;}void
 Loggers::reconfigureAllLoggers(const Configurations&configurations){for(base::
RegisteredLoggers::iterator it=ELPP->registeredLoggers()->begin();it!=ELPP->
registeredLoggers()->end();++it){Loggers::reconfigureLogger(it->second,
configurations);}}void Loggers::reconfigureAllLoggers(Level level,
ConfigurationType configurationType,const std::string&value){for(base::
RegisteredLoggers::iterator it=ELPP->registeredLoggers()->begin();it!=ELPP->
registeredLoggers()->end();++it){Logger*logger=it->second;logger->configurations
()->set(level,configurationType,value);logger->reconfigure();}}void Loggers::
setDefaultConfigurations(const Configurations&configurations,bool 
reconfigureExistingLoggers){ELPP->registeredLoggers()->setDefaultConfigurations(
configurations);if(reconfigureExistingLoggers){Loggers::reconfigureAllLoggers(
configurations);}}const Configurations*Loggers::defaultConfigurations(void){
return ELPP->registeredLoggers()->defaultConfigurations();}const base::
LogStreamsReferenceMap*Loggers::logStreamsReference(void){return ELPP->
registeredLoggers()->logStreamsReference();}base::TypedConfigurations Loggers::
defaultTypedConfigurations(void){return base::TypedConfigurations(ELPP->
registeredLoggers()->defaultConfigurations(),ELPP->registeredLoggers()->
logStreamsReference());}std::vector<std::string>*Loggers::populateAllLoggerIds(
std::vector<std::string>*targetList){targetList->clear();for(base::
RegisteredLoggers::iterator it=ELPP->registeredLoggers()->list().begin();it!=
ELPP->registeredLoggers()->list().end();++it){targetList->push_back(it->first);}
return targetList;}void Loggers::configureFromGlobal(const char*
globalConfigurationFilePath){std::ifstream gcfStream(globalConfigurationFilePath
,std::ifstream::in);ELPP_ASSERT(gcfStream.is_open(),
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x6f\x70\x65\x6e\x20\x67\x6c\x6f\x62\x61\x6c\x20\x63\x6f\x6e\x66\x20\x66\x69\x6c\x65\x20\x5b"
<<globalConfigurationFilePath<<
"\x5d\x20\x66\x6f\x72\x20\x70\x61\x72\x73\x69\x6e\x67\x2e");std::string line=std
::string();std::stringstream ss;Logger*logger=nullptr;auto configure=[&](void){
ELPP_INTERNAL_INFO((0x1666+990-0x1a3c),
"\x43\x6f\x6e\x66\x20\x6c\x6f\x67\x67\x65\x72\x3a\x20\x27"<<logger->id()<<
"\x27\x20\x77\x69\x74\x68\x20\x63\x6f\x6e\x66\x20" "\n"<<ss.str()<<
"\n" "\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d");Configurations 
c;c.parseFromText(ss.str());logger->configure(c);};while(gcfStream.good()){std::
getline(gcfStream,line);ELPP_INTERNAL_INFO((0x186+9233-0x2596),
"\x50\x61\x72\x73\x6e\x67\x20\x6c\x69\x6e\x65\x3a\x20"<<line);base::utils::Str::
trim(line);if(Configurations::Parser::isComment(line))continue;Configurations::
Parser::ignoreComments(&line);base::utils::Str::trim(line);if(line.size()>
(0x22+2318-0x92e)&&base::utils::Str::startsWith(line,std::string(base::consts::
kConfigurationLoggerId))){if(!ss.str().empty()&&logger!=nullptr){configure();}ss
.str(std::string(""));line=line.substr((0x1554+4071-0x2539));base::utils::Str::
trim(line);if(line.size()>(0x550+4676-0x1793)){ELPP_INTERNAL_INFO(
(0x1a4c+2887-0x2592),
"\x47\x65\x74\x6e\x67\x20\x6c\x6f\x67\x67\x65\x72\x3a\x20\x27"<<line<<"\x27");
logger=getLogger(line);}}else{ss<<line<<"\n";}}if(!ss.str().empty()&&logger!=
nullptr){configure();}}bool Loggers::configureFromArg(const char*argKey){
#if defined(ELPP_DISABLE_CONFIGURATION_FROM_PROGRAM_ARGS)
ELPP_UNUSED(argKey);
#else
if(!Helpers::commandLineArgs()->hasParamWithValue(argKey)){return false;}
configureFromGlobal(Helpers::commandLineArgs()->getParamValue(argKey));
#endif  
return true;}void Loggers::flushAll(void){ELPP->registeredLoggers()->flushAll();
}void Loggers::setVerboseLevel(base::type::VerboseLevel level){ELPP->vRegistry()
->setLevel(level);}base::type::VerboseLevel Loggers::verboseLevel(void){return 
ELPP->vRegistry()->level();}void Loggers::setVModules(const char*modules){if(
ELPP->vRegistry()->vModulesEnabled()){ELPP->vRegistry()->setModules(modules);}}
void Loggers::clearVModules(void){ELPP->vRegistry()->clearModules();}const std::
string VersionInfo::version(void){return std::string("\x39\x2e\x39\x36\x2e\x37")
;}const std::string VersionInfo::releaseDate(void){return std::string(
"\x32\x34\x2d\x31\x31\x2d\x32\x30\x31\x38\x20\x30\x37\x32\x38\x68\x72\x73");}}

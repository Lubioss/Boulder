
#include "../include/htpLob.h"
namespace htpLob{namespace detail{bool is_hex(char c,int&v){if(
(0x18ec+2840-0x23e4)<=c&&isdigit(c)){v=c-((char)(0x1b55+2659-0x2588));return 
true;}else if(((char)(0x1499+2641-0x1ea9))<=c&&c<=((char)(0x61b+5474-0x1b37))){v
=c-((char)(0x112d+1222-0x15b2))+(0x29+2856-0xb47);return true;}else if(
((char)(0x1991+3298-0x2612))<=c&&c<=((char)(0x9c4+3522-0x1720))){v=c-
((char)(0x9c0+4347-0x1a5a))+(0x1a50+971-0x1e11);return true;}return false;}bool 
from_hex_to_i(const std::string&s,size_t i,size_t cnt,int&val){if(i>=s.size()){
return false;}val=(0x1aa7+584-0x1cef);for(;cnt;i++,cnt--){if(!s[i]){return false
;}int v=(0x2e6+1960-0xa8e);if(is_hex(s[i],v)){val=val*(0xaa4+2900-0x15e8)+v;}
else{return false;}}return true;}std::string from_i_to_hex(size_t n){const char*
charset="\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x61\x62\x63\x64\x65\x66";std::
string ret;do{ret=charset[n&(0x58c+4346-0x1677)]+ret;n>>=(0x1aa8+1534-0x20a2);}
while(n>(0xcc1+64-0xd01));return ret;}size_t to_utf8(int code,char*buff){if(code
<(0xca4+3818-0x1b0e)){buff[(0xe8+3300-0xdcc)]=(code&(0xe1f+6444-0x26cc));return
(0x1db6+503-0x1fac);}else if(code<(0x1143+4959-0x1ca2)){buff[(0xa40+4768-0x1ce0)
]=static_cast<char>((0xb12+6086-0x2218)|((code>>(0x2106+1427-0x2693))&
(0x373+4408-0x148c)));buff[(0x65f+1639-0xcc5)]=static_cast<char>(
(0x673+5446-0x1b39)|(code&(0x4ab+4701-0x16c9)));return(0x829+4038-0x17ed);}else 
if(code<55296){buff[(0x6e7+3177-0x1350)]=static_cast<char>((0xfbf+3686-0x1d45)|(
(code>>(0x1086+5650-0x268c))&(0xb70+3452-0x18dd)));buff[(0xa2f+2929-0x159f)]=
static_cast<char>((0xce7+1383-0x11ce)|((code>>(0x34b+5773-0x19d2))&
(0xb98+4519-0x1d00)));buff[(0x1f87+372-0x20f9)]=static_cast<char>(
(0x12b7+2280-0x1b1f)|(code&(0x2c1+3160-0xeda)));return(0x1f3+7990-0x2126);}else 
if(code<57344){return(0xa3d+5728-0x209d);}else if(code<65536){buff[
(0x54a+5494-0x1ac0)]=static_cast<char>((0x353+5213-0x16d0)|((code>>
(0xddf+2944-0x1953))&(0x136c+1420-0x18e9)));buff[(0x85a+3947-0x17c4)]=
static_cast<char>((0x2c1+5196-0x168d)|((code>>(0xa9c+4382-0x1bb4))&
(0xaec+2326-0x13c3)));buff[(0x1478+162-0x1518)]=static_cast<char>(
(0x10a0+4448-0x2180)|(code&(0x15f3+676-0x1858)));return(0xb7c+5272-0x2011);}else
 if(code<1114112){buff[(0xf35+2141-0x1792)]=static_cast<char>(
(0x11a0+2160-0x1920)|((code>>(0x6f8+6248-0x1f4e))&(0x1165+4389-0x2283)));buff[
(0x7bc+4558-0x1989)]=static_cast<char>((0x1c50+1801-0x22d9)|((code>>
(0x22cd+841-0x260a))&(0x1c40+2006-0x23d7)));buff[(0xaad+4328-0x1b93)]=
static_cast<char>((0x12c2+2429-0x1bbf)|((code>>(0x13d5+137-0x1458))&
(0x588+4652-0x1775)));buff[(0xbc0+4218-0x1c37)]=static_cast<char>(
(0x1512+4119-0x24a9)|(code&(0x496+5138-0x1869)));return(0x7cf+3805-0x16a8);}
return(0x7e6+1362-0xd38);}std::string base64_encode(const std::string&in){static
 const auto lookup=
"\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x2b\x2f"
;std::string out;out.reserve(in.size());int val=(0x1195+1953-0x1936);int valb=-
(0xdfa+160-0xe94);for(auto c:in){val=(val<<(0x303+8098-0x229d))+static_cast<
uint8_t>(c);valb+=(0x486+1582-0xaac);while(valb>=(0x2b1+2361-0xbea)){out.
push_back(lookup[(val>>valb)&(0x50d+4412-0x160a)]);valb-=(0xf18+2091-0x173d);}}
if(valb>-(0xeb8+5612-0x249e)){out.push_back(lookup[((val<<(0x1a88+386-0x1c02))>>
(valb+(0x2099+309-0x21c6)))&(0x7a5+3935-0x16c5)]);}while(out.size()%
(0x20b7+690-0x2365)){out.push_back(((char)(0x2439+106-0x2466)));}return out;}
bool is_file(const std::string&path){struct stat st;return stat(path.c_str(),&st
)>=(0x291+6016-0x1a11)&&S_ISREG(st.st_mode);}bool is_dir(const std::string&path)
{struct stat st;return stat(path.c_str(),&st)>=(0x1fac+439-0x2163)&&S_ISDIR(st.
st_mode);}bool is_valid_path(const std::string&path){size_t level=
(0xfaa+3143-0x1bf1);size_t i=(0xe78+1064-0x12a0);while(i<path.size()&&path[i]==
((char)(0x574+77-0x592))){i++;}while(i<path.size()){auto beg=i;while(i<path.size
()&&path[i]!=((char)(0x9aa+4859-0x1c76))){i++;}auto len=i-beg;assert(len>
(0xb6f+1397-0x10e4));if(!path.compare(beg,len,"\x2e")){;}else if(!path.compare(
beg,len,"\x2e\x2e")){if(level==(0x116d+2539-0x1b58)){return false;}level--;}else
{level++;}while(i<path.size()&&path[i]==((char)(0xf68+3832-0x1e31))){i++;}}
return true;}std::string encode_query_param(const std::string&value){std::
ostringstream escaped;escaped.fill(((char)(0xaa4+2473-0x141d)));escaped<<std::
hex;for(auto c:value){if(std::isalnum(static_cast<uint8_t>(c))||c==
((char)(0x1425+4504-0x2590))||c==((char)(0x89+4860-0x1326))||c==
((char)(0x126a+2774-0x1d12))||c==((char)(0xa23+327-0xb49))||c==
((char)(0x79c+7558-0x24a4))||c==((char)(0xd8f+2909-0x18c2))||c=='\''||c==
((char)(0xa87+2660-0x14c3))||c==((char)(0x14cd+545-0x16c5))){escaped<<c;}else{
escaped<<std::uppercase;escaped<<((char)(0x1d73+1982-0x250c))<<std::setw(
(0x673+7800-0x24e9))<<static_cast<int>(static_cast<unsigned char>(c));escaped<<
std::nouppercase;}}return escaped.str();}std::string encode_url(const std::
string&s){std::string result;for(size_t i=(0x3bc+4860-0x16b8);s[i];i++){switch(s
[i]){case((char)(0x1606+1559-0x1bfd)):result+="\x25\x32\x30";break;case
((char)(0xff8+4185-0x2026)):result+="\x25\x32\x42";break;case'\r':result+=
"\x25\x30\x44";break;case'\n':result+="\x25\x30\x41";break;case'\'':result+=
"\x25\x32\x37";break;case((char)(0x85+7842-0x1efb)):result+="\x25\x32\x43";break
;case((char)(0xa92+1102-0xea5)):result+="\x25\x33\x42";break;default:auto c=
static_cast<uint8_t>(s[i]);if(c>=(0x280+5143-0x1617)){result+=
((char)(0x296+1129-0x6da));char hex[(0x8d6+6140-0x20ce)];auto len=snprintf(hex,
sizeof(hex)-(0x1187+39-0x11ad),"\x25\x30\x32\x58",c);assert(len==
(0x828+6528-0x21a6));result.append(hex,static_cast<size_t>(len));}else{result+=s
[i];}break;}}return result;}std::string decode_url(const std::string&s,bool 
convert_plus_to_space){std::string result;for(size_t i=(0x138b+445-0x1548);i<s.
size();i++){if(s[i]==((char)(0x14b8+4232-0x251b))&&i+(0xe22+5339-0x22fc)<s.size(
)){if(s[i+(0x538+104-0x59f)]==((char)(0x57f+5155-0x192d))){int val=
(0x1887+1308-0x1da3);if(from_hex_to_i(s,i+(0xe75+2396-0x17cf),
(0x59d+3796-0x146d),val)){char buff[(0xf88+3345-0x1c95)];size_t len=to_utf8(val,
buff);if(len>(0xa69+3498-0x1813)){result.append(buff,len);}i+=
(0x1226+5353-0x270a);}else{result+=s[i];}}else{int val=(0x110a+4142-0x2138);if(
from_hex_to_i(s,i+(0x3ab+7349-0x205f),(0x1e28+856-0x217e),val)){result+=
static_cast<char>(val);i+=(0x640+783-0x94d);}else{result+=s[i];}}}else if(
convert_plus_to_space&&s[i]==((char)(0x165b+2080-0x1e50))){result+=
((char)(0xa70+1516-0x103c));}else{result+=s[i];}}return result;}void read_file(
const std::string&path,std::string&out){std::ifstream fs(path,std::ios_base::
binary);fs.seekg((0x81f+6517-0x2194),std::ios_base::end);auto size=fs.tellg();fs
.seekg((0x897+3634-0x16c9));out.resize(static_cast<size_t>(size));fs.read(&out[
(0x11b0+798-0x14ce)],static_cast<std::streamsize>(size));}std::string 
file_extension(const std::string&path){std::smatch m;static auto re=std::regex(
"\\" "\x2e\x28\x5b\x61\x2d\x7a\x41\x2d\x5a\x30\x2d\x39\x5d\x2b\x29\x24");if(std
::regex_search(path,m,re)){return m[(0x5b6+6918-0x20bb)].str();}return std::
string();}bool is_space_or_tab(char c){return c==((char)(0x1254+74-0x127e))||c==
'\t';}std::pair<size_t,size_t>trim(const char*b,const char*e,size_t left,size_t 
right){while(b+left<e&&is_space_or_tab(b[left])){left++;}while(right>
(0x277+8108-0x2223)&&is_space_or_tab(b[right-(0x1dd+5189-0x1621)])){right--;}
return std::make_pair(left,right);}std::string trim_copy(const std::string&s){
auto r=trim(s.data(),s.data()+s.size(),(0xd86+3614-0x1ba4),s.size());return s.
substr(r.first,r.second-r.first);}template<class Fn>void split(const char*b,
const char*e,char d,Fn fn){size_t i=(0xad0+710-0xd96);size_t beg=
(0x20db+177-0x218c);while(e?(b+i<e):(b[i]!='\0')){if(b[i]==d){auto r=trim(b,e,
beg,i);if(r.first<r.second){fn(&b[r.first],&b[r.second]);}beg=i+
(0x1caf+2278-0x2594);}i++;}if(i){auto r=trim(b,e,beg,i);if(r.first<r.second){fn(
&b[r.first],&b[r.second]);}}}class stream_line_reader{public:stream_line_reader(
Stream&strm,char*fixed_buffer,size_t fixed_buffer_size):strm_(strm),
fixed_buffer_(fixed_buffer),fixed_buffer_size_(fixed_buffer_size){}const char*
ptr()const{if(glowable_buffer_.empty()){return fixed_buffer_;}else{return 
glowable_buffer_.data();}}size_t size()const{if(glowable_buffer_.empty()){return
 fixed_buffer_used_size_;}else{return glowable_buffer_.size();}}bool 
end_with_crlf()const{auto end=ptr()+size();return size()>=(0xdb+2779-0xbb4)&&end
[-(0x10e1+2557-0x1adc)]=='\r'&&end[-(0x9df+5404-0x1efa)]=='\n';}bool getline(){
fixed_buffer_used_size_=(0x6cb+3231-0x136a);glowable_buffer_.clear();for(size_t 
i=(0x858+425-0xa01);;i++){char byte;auto n=strm_.read(&byte,(0xbda+5795-0x227c))
;if(n<(0x1651+1727-0x1d10)){return false;}else if(n==(0x9a5+4789-0x1c5a)){if(i==
(0x11a9+3460-0x1f2d)){return false;}else{break;}}append(byte);if(byte=='\n'){
break;}}return true;}private:void append(char c){if(fixed_buffer_used_size_<
fixed_buffer_size_-(0x1572+2275-0x1e54)){fixed_buffer_[fixed_buffer_used_size_++
]=c;fixed_buffer_[fixed_buffer_used_size_]='\0';}else{if(glowable_buffer_.empty(
)){assert(fixed_buffer_[fixed_buffer_used_size_]=='\0');glowable_buffer_.assign(
fixed_buffer_,fixed_buffer_used_size_);}glowable_buffer_+=c;}}Stream&strm_;char*
fixed_buffer_;const size_t fixed_buffer_size_;size_t fixed_buffer_used_size_=
(0xd33+1297-0x1244);std::string glowable_buffer_;};int close_socket(socket_t 
sock){
#ifdef _WIN32
return closesocket(sock);
#else
return close(sock);
#endif
}template<typename T>ssize_t handle_EINTR(T fn){ssize_t res=false;while(true){
res=fn();if(res<(0x1908+1368-0x1e60)&&errno==EINTR){continue;}break;}return res;
}ssize_t select_read(socket_t sock,time_t sec,time_t usec){
#ifdef CPPHTTPLIB_USE_POLL
struct pollfd pfd_read;pfd_read.fd=sock;pfd_read.events=POLLIN;auto timeout=
static_cast<int>(sec*(0x16cc+2348-0x1c10)+usec/(0x9a3+3727-0x144a));return 
handle_EINTR([&](){return poll(&pfd_read,(0x400+2883-0xf42),timeout);});
#else
#ifndef _WIN32
if(sock>=FD_SETSIZE){return(0x134d+454-0x1512);}
#endif
fd_set fds;FD_ZERO(&fds);FD_SET(sock,&fds);timeval tv;tv.tv_sec=static_cast<long
>(sec);tv.tv_usec=static_cast<decltype(tv.tv_usec)>(usec);return handle_EINTR([&
](){return select(static_cast<int>(sock+(0x211+8623-0x23bf)),&fds,nullptr,
nullptr,&tv);});
#endif
}ssize_t select_write(socket_t sock,time_t sec,time_t usec){
#ifdef CPPHTTPLIB_USE_POLL
struct pollfd pfd_read;pfd_read.fd=sock;pfd_read.events=POLLOUT;auto timeout=
static_cast<int>(sec*(0x5d4+5187-0x162f)+usec/(0xff0+5527-0x219f));return 
handle_EINTR([&](){return poll(&pfd_read,(0x422+2978-0xfc3),timeout);});
#else
#ifndef _WIN32
if(sock>=FD_SETSIZE){return(0x69d+5394-0x1bae);}
#endif
fd_set fds;FD_ZERO(&fds);FD_SET(sock,&fds);timeval tv;tv.tv_sec=static_cast<long
>(sec);tv.tv_usec=static_cast<decltype(tv.tv_usec)>(usec);return handle_EINTR([&
](){return select(static_cast<int>(sock+(0x103+2595-0xb25)),nullptr,&fds,nullptr
,&tv);});
#endif
}bool wait_until_socket_is_ready(socket_t sock,time_t sec,time_t usec){
#ifdef CPPHTTPLIB_USE_POLL
struct pollfd pfd_read;pfd_read.fd=sock;pfd_read.events=POLLIN|POLLOUT;auto 
timeout=static_cast<int>(sec*(0xe0a+335-0xb71)+usec/(0x182d+4668-0x2681));auto 
poll_res=handle_EINTR([&](){return poll(&pfd_read,(0xe31+371-0xfa3),timeout);});
if(poll_res>(0x1d28+240-0x1e18)&&pfd_read.revents&(POLLIN|POLLOUT)){int error=
(0x55b+3297-0x123c);socklen_t len=sizeof(error);auto res=getsockopt(sock,
SOL_SOCKET,SO_ERROR,reinterpret_cast<char*>(&error),&len);return res>=
(0x1e39+278-0x1f4f)&&!error;}return false;
#else
#ifndef _WIN32
if(sock>=FD_SETSIZE){return false;}
#endif
fd_set fdsr;FD_ZERO(&fdsr);FD_SET(sock,&fdsr);auto fdsw=fdsr;auto fdse=fdsr;
timeval tv;tv.tv_sec=static_cast<long>(sec);tv.tv_usec=static_cast<decltype(tv.
tv_usec)>(usec);auto ret=handle_EINTR([&](){return select(static_cast<int>(sock+
(0xf44+948-0x12f7)),&fdsr,&fdsw,&fdse,&tv);});if(ret>(0x559+1407-0xad8)&&(
FD_ISSET(sock,&fdsr)||FD_ISSET(sock,&fdsw))){int error=(0x11b9+628-0x142d);
socklen_t len=sizeof(error);return getsockopt(sock,SOL_SOCKET,SO_ERROR,
reinterpret_cast<char*>(&error),&len)>=(0x2a2+4220-0x131e)&&!error;}return false
;
#endif
}class SocketStream:public Stream{public:SocketStream(socket_t sock,time_t 
read_timeout_sec,time_t read_timeout_usec,time_t write_timeout_sec,time_t 
write_timeout_usec);~SocketStream()override;bool is_readable()const override;
bool is_writable()const override;ssize_t read(char*ptr,size_t size)override;
ssize_t write(const char*ptr,size_t size)override;void get_remote_ip_and_port(
std::string&ip,int&port)const override;socket_t socket()const override;private:
socket_t sock_;time_t read_timeout_sec_;time_t read_timeout_usec_;time_t 
write_timeout_sec_;time_t write_timeout_usec_;};
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
class SSLSocketStream:public Stream{public:SSLSocketStream(socket_t sock,SSL*ssl
,time_t read_timeout_sec,time_t read_timeout_usec,time_t write_timeout_sec,
time_t write_timeout_usec);~SSLSocketStream()override;bool is_readable()const 
override;bool is_writable()const override;ssize_t read(char*ptr,size_t size)
override;ssize_t write(const char*ptr,size_t size)override;void 
get_remote_ip_and_port(std::string&ip,int&port)const override;socket_t socket()
const override;private:socket_t sock_;SSL*ssl_;time_t read_timeout_sec_;time_t 
read_timeout_usec_;time_t write_timeout_sec_;time_t write_timeout_usec_;};
#endif
class BufferStream:public Stream{public:BufferStream()=default;~BufferStream()
override=default;bool is_readable()const override;bool is_writable()const 
override;ssize_t read(char*ptr,size_t size)override;ssize_t write(const char*ptr
,size_t size)override;void get_remote_ip_and_port(std::string&ip,int&port)const 
override;socket_t socket()const override;const std::string&get_buffer()const;
private:std::string buffer;size_t position=(0xc72+741-0xf57);};bool keep_alive(
socket_t sock,time_t keep_alive_timeout_sec){using namespace std::chrono;auto 
start=steady_clock::now();while(true){auto val=select_read(sock,
(0x396+3525-0x115b),10000);if(val<(0x57d+7110-0x2143)){return false;}else if(val
==(0x1415+4853-0x270a)){auto current=steady_clock::now();auto duration=
duration_cast<milliseconds>(current-start);auto timeout=keep_alive_timeout_sec*
(0x130f+5471-0x2486);if(duration.count()>timeout){return false;}std::this_thread
::sleep_for(std::chrono::milliseconds((0xef+3354-0xe08)));}else{return true;}}}
template<typename T>bool process_server_socket_core(socket_t sock,size_t 
keep_alive_max_count,time_t keep_alive_timeout_sec,T callback){assert(
keep_alive_max_count>(0x1a34+2439-0x23bb));auto ret=false;auto count=
keep_alive_max_count;while(count>(0x1cbd+139-0x1d48)&&keep_alive(sock,
keep_alive_timeout_sec)){auto close_connection=count==(0x3b5+1378-0x916);auto 
connection_closed=false;ret=callback(close_connection,connection_closed);if(!ret
||connection_closed){break;}count--;}return ret;}template<typename T>bool 
process_server_socket(socket_t sock,size_t keep_alive_max_count,time_t 
keep_alive_timeout_sec,time_t read_timeout_sec,time_t read_timeout_usec,time_t 
write_timeout_sec,time_t write_timeout_usec,T callback){return 
process_server_socket_core(sock,keep_alive_max_count,keep_alive_timeout_sec,[&](
bool close_connection,bool&connection_closed){SocketStream strm(sock,
read_timeout_sec,read_timeout_usec,write_timeout_sec,write_timeout_usec);return 
callback(strm,close_connection,connection_closed);});}template<typename T>bool 
process_client_socket(socket_t sock,time_t read_timeout_sec,time_t 
read_timeout_usec,time_t write_timeout_sec,time_t write_timeout_usec,T callback)
{SocketStream strm(sock,read_timeout_sec,read_timeout_usec,write_timeout_sec,
write_timeout_usec);return callback(strm);}int shutdown_socket(socket_t sock){
#ifdef _WIN32
return shutdown(sock,SD_BOTH);
#else
return shutdown(sock,SHUT_RDWR);
#endif
}template<typename BindOrConnect>socket_t create_socket(const char*host,int port
,int socket_flags,bool tcp_nodelay,SocketOptions socket_options,BindOrConnect 
bind_or_connect){struct addrinfo hints;struct addrinfo*result;memset(&hints,
(0xb75+5026-0x1f17),sizeof(struct addrinfo));hints.ai_family=AF_UNSPEC;hints.
ai_socktype=SOCK_STREAM;hints.ai_flags=socket_flags;hints.ai_protocol=
(0x420+8289-0x2481);auto service=std::to_string(port);if(getaddrinfo(host,
service.c_str(),&hints,&result)){
#ifdef __linux__
res_init();
#endif
return INVALID_SOCKET;}for(auto rp=result;rp;rp=rp->ai_next){
#ifdef _WIN32
auto sock=WSASocketW(rp->ai_family,rp->ai_socktype,rp->ai_protocol,nullptr,
(0x17ed+837-0x1b32),WSA_FLAG_NO_HANDLE_INHERIT);if(sock==INVALID_SOCKET){sock=
socket(rp->ai_family,rp->ai_socktype,rp->ai_protocol);}
#else
auto sock=socket(rp->ai_family,rp->ai_socktype,rp->ai_protocol);
#endif
if(sock==INVALID_SOCKET){continue;}
#ifndef _WIN32
if(fcntl(sock,F_SETFD,FD_CLOEXEC)==-(0x69f+5846-0x1d74)){continue;}
#endif
if(tcp_nodelay){int yes=(0x460+2428-0xddb);setsockopt(sock,IPPROTO_TCP,
TCP_NODELAY,reinterpret_cast<char*>(&yes),sizeof(yes));}if(socket_options){
socket_options(sock);}if(rp->ai_family==AF_INET6){int no=(0x44+6283-0x18cf);
setsockopt(sock,IPPROTO_IPV6,IPV6_V6ONLY,reinterpret_cast<char*>(&no),sizeof(no)
);}if(bind_or_connect(sock,*rp)){freeaddrinfo(result);return sock;}close_socket(
sock);}freeaddrinfo(result);return INVALID_SOCKET;}void set_nonblocking(socket_t
 sock,bool nonblocking){
#ifdef _WIN32
auto flags=nonblocking?1UL:0UL;ioctlsocket(sock,FIONBIO,&flags);
#else
auto flags=fcntl(sock,F_GETFL,(0x3fd+2156-0xc69));fcntl(sock,F_SETFL,nonblocking
?(flags|O_NONBLOCK):(flags&(~O_NONBLOCK)));
#endif
}bool is_connection_error(){
#ifdef _WIN32
return WSAGetLastError()!=WSAEWOULDBLOCK;
#else
return errno!=EINPROGRESS;
#endif
}bool bind_ip_address(socket_t sock,const char*host){struct addrinfo hints;
struct addrinfo*result;memset(&hints,(0x5d3+4703-0x1832),sizeof(struct addrinfo)
);hints.ai_family=AF_UNSPEC;hints.ai_socktype=SOCK_STREAM;hints.ai_protocol=
(0x111c+1637-0x1781);if(getaddrinfo(host,"\x30",&hints,&result)){return false;}
auto ret=false;for(auto rp=result;rp;rp=rp->ai_next){const auto&ai=*rp;if(!::
bind(sock,ai.ai_addr,static_cast<socklen_t>(ai.ai_addrlen))){ret=true;break;}}
freeaddrinfo(result);return ret;}
#if !defined _WIN32 && !defined ANDROID
#define USE_IF2IP
#endif
#ifdef USE_IF2IP
std::string if2ip(const std::string&ifn){struct ifaddrs*ifap;getifaddrs(&ifap);
for(auto ifa=ifap;ifa;ifa=ifa->ifa_next){if(ifa->ifa_addr&&ifn==ifa->ifa_name){
if(ifa->ifa_addr->sa_family==AF_INET){auto sa=reinterpret_cast<struct 
sockaddr_in*>(ifa->ifa_addr);char buf[INET_ADDRSTRLEN];if(inet_ntop(AF_INET,&sa
->sin_addr,buf,INET_ADDRSTRLEN)){freeifaddrs(ifap);return std::string(buf,
INET_ADDRSTRLEN);}}}}freeifaddrs(ifap);return std::string();}
#endif
socket_t create_client_socket(const char*host,int port,bool tcp_nodelay,
SocketOptions socket_options,time_t timeout_sec,time_t timeout_usec,const std::
string&intf,Error&error){auto sock=create_socket(host,port,(0x1e07+594-0x2059),
tcp_nodelay,std::move(socket_options),[&](socket_t sock,struct addrinfo&ai)->
bool{if(!intf.empty()){
#ifdef USE_IF2IP
auto ip=if2ip(intf);if(ip.empty()){ip=intf;}if(!bind_ip_address(sock,ip.c_str())
){error=Error::BindIPAddress;return false;}
#endif
}set_nonblocking(sock,true);auto ret=::connect(sock,ai.ai_addr,static_cast<
socklen_t>(ai.ai_addrlen));if(ret<(0xa7a+4946-0x1dcc)){if(is_connection_error()
||!wait_until_socket_is_ready(sock,timeout_sec,timeout_usec)){close_socket(sock)
;error=Error::Connection;return false;}}set_nonblocking(sock,false);error=Error
::Success;return true;});if(sock!=INVALID_SOCKET){error=Error::Success;}else{if(
error==Error::Success){error=Error::Connection;}}return sock;}void 
get_remote_ip_and_port(const struct sockaddr_storage&addr,socklen_t addr_len,std
::string&ip,int&port){if(addr.ss_family==AF_INET){port=ntohs(reinterpret_cast<
const struct sockaddr_in*>(&addr)->sin_port);}else if(addr.ss_family==AF_INET6){
port=ntohs(reinterpret_cast<const struct sockaddr_in6*>(&addr)->sin6_port);}std
::array<char,NI_MAXHOST>ipstr{};if(!getnameinfo(reinterpret_cast<const struct 
sockaddr*>(&addr),addr_len,ipstr.data(),static_cast<socklen_t>(ipstr.size()),
nullptr,(0x346+8462-0x2454),NI_NUMERICHOST)){ip=ipstr.data();}}void 
get_remote_ip_and_port(socket_t sock,std::string&ip,int&port){struct 
sockaddr_storage addr;socklen_t addr_len=sizeof(addr);if(!getpeername(sock,
reinterpret_cast<struct sockaddr*>(&addr),&addr_len)){get_remote_ip_and_port(
addr,addr_len,ip,port);}}constexpr unsigned int str2tag_core(const char*s,size_t
 l,unsigned int h){return(l==(0xce7+6176-0x2507))?h:str2tag_core(s+
(0x151+495-0x33f),l-(0x9d6+4030-0x1993),(h*(0xcaa+6234-0x24e3))^static_cast<
unsigned char>(*s));}unsigned int str2tag(const std::string&s){return 
str2tag_core(s.data(),s.size(),(0x17dc+238-0x18ca));}namespace udl{constexpr 
unsigned int operator"" _(const char*s,size_t l){return str2tag_core(s,l,
(0xccd+5988-0x2431));}}const char*find_content_type(const std::string&path,const
 std::map<std::string,std::string>&user_data){auto ext=file_extension(path);auto
 it=user_data.find(ext);if(it!=user_data.end()){return it->second.c_str();}using
 udl::operator""_;switch(str2tag(ext)){default:return nullptr;case"\x63\x73\x73"
_:return"\x74\x65\x78\x74\x2f\x63\x73\x73";case"\x63\x73\x76"_:return
"\x74\x65\x78\x74\x2f\x63\x73\x76";case"\x74\x78\x74"_:return
"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e";case"\x76\x74\x74"_:return
"\x74\x65\x78\x74\x2f\x76\x74\x74";case"\x68\x74\x6d"_:case"\x68\x74\x6d\x6c"_:
return"\x74\x65\x78\x74\x2f\x68\x74\x6d\x6c";case"\x61\x70\x6e\x67"_:return
"\x69\x6d\x61\x67\x65\x2f\x61\x70\x6e\x67";case"\x61\x76\x69\x66"_:return
"\x69\x6d\x61\x67\x65\x2f\x61\x76\x69\x66";case"\x62\x6d\x70"_:return
"\x69\x6d\x61\x67\x65\x2f\x62\x6d\x70";case"\x67\x69\x66"_:return
"\x69\x6d\x61\x67\x65\x2f\x67\x69\x66";case"\x70\x6e\x67"_:return
"\x69\x6d\x61\x67\x65\x2f\x70\x6e\x67";case"\x73\x76\x67"_:return
"\x69\x6d\x61\x67\x65\x2f\x73\x76\x67\x2b\x78\x6d\x6c";case"\x77\x65\x62\x70"_:
return"\x69\x6d\x61\x67\x65\x2f\x77\x65\x62\x70";case"\x69\x63\x6f"_:return
"\x69\x6d\x61\x67\x65\x2f\x78\x2d\x69\x63\x6f\x6e";case"\x74\x69\x66"_:return
"\x69\x6d\x61\x67\x65\x2f\x74\x69\x66\x66";case"\x74\x69\x66\x66"_:return
"\x69\x6d\x61\x67\x65\x2f\x74\x69\x66\x66";case"\x6a\x70\x67"_:case
"\x6a\x70\x65\x67"_:return"\x69\x6d\x61\x67\x65\x2f\x6a\x70\x65\x67";case
"\x6d\x70\x34"_:return"\x76\x69\x64\x65\x6f\x2f\x6d\x70\x34";case
"\x6d\x70\x65\x67"_:return"\x76\x69\x64\x65\x6f\x2f\x6d\x70\x65\x67";case
"\x77\x65\x62\x6d"_:return"\x76\x69\x64\x65\x6f\x2f\x77\x65\x62\x6d";case
"\x6d\x70\x33"_:return"\x61\x75\x64\x69\x6f\x2f\x6d\x70\x33";case
"\x6d\x70\x67\x61"_:return"\x61\x75\x64\x69\x6f\x2f\x6d\x70\x65\x67";case
"\x77\x65\x62\x61"_:return"\x61\x75\x64\x69\x6f\x2f\x77\x65\x62\x6d";case
"\x77\x61\x76"_:return"\x61\x75\x64\x69\x6f\x2f\x77\x61\x76\x65";case
"\x6f\x74\x66"_:return"\x66\x6f\x6e\x74\x2f\x6f\x74\x66";case"\x74\x74\x66"_:
return"\x66\x6f\x6e\x74\x2f\x74\x74\x66";case"\x77\x6f\x66\x66"_:return
"\x66\x6f\x6e\x74\x2f\x77\x6f\x66\x66";case"\x77\x6f\x66\x66\x32"_:return
"\x66\x6f\x6e\x74\x2f\x77\x6f\x66\x66\x32";case"\x37\x7a"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x37\x7a\x2d\x63\x6f\x6d\x70\x72\x65\x73\x73\x65\x64"
;case"\x61\x74\x6f\x6d"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x61\x74\x6f\x6d\x2b\x78\x6d\x6c"
;case"\x70\x64\x66"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x70\x64\x66";case"\x6a\x73"_:
case"\x6d\x6a\x73"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x61\x76\x61\x73\x63\x72\x69\x70\x74"
;case"\x6a\x73\x6f\x6e"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e";case
"\x72\x73\x73"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x72\x73\x73\x2b\x78\x6d\x6c";
case"\x74\x61\x72"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x74\x61\x72";case
"\x78\x68\x74"_:case"\x78\x68\x74\x6d\x6c"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x68\x74\x6d\x6c\x2b\x78\x6d\x6c"
;case"\x78\x73\x6c\x74"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x73\x6c\x74\x2b\x78\x6d\x6c"
;case"\x78\x6d\x6c"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x6d\x6c";case"\x67\x7a"_:
return"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x67\x7a\x69\x70";case
"\x7a\x69\x70"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x7a\x69\x70";case
"\x77\x61\x73\x6d"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x77\x61\x73\x6d";}}const char*
status_message(int status){switch(status){case(0x7d1+5030-0x1b13):return"\x43";
case(0x14ab+2565-0x1e4b):return"\x53\x20\x50";case(0xd3b+3394-0x1a17):return
"\x50";case(0x693+8303-0x269b):return"\x45\x20\x48";case(0x1d4d+399-0x1e14):
return"\x4f\x4b";case(0x21c3+383-0x2279):return"\x43";case(0x1413+816-0x1679):
return"\x41";case(0x1aa+2071-0x8f6):return
"\x4e\x41\x20\x49\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e";case
(0xd54+4768-0x1f28):return"\x4e\x20\x43";case(0x7c4+3141-0x133c):return
"\x52\x20\x43";case(0x875+6917-0x22ac):return"\x50\x20\x43";case
(0x5f7+6351-0x1df7):return"\x4d\x2d\x53";case(0x1770+252-0x179c):return
"\x41\x20\x52";case(0x2e9+6460-0x1b43):return"\x49\x4d\x20\x55\x73\x65\x64";case
(0x1392+3708-0x20e2):return"\x4d\x20\x43";case(0x273+3912-0x108e):return
"\x4d\x20\x50";case(0xe85+5574-0x231d):return"\x46";case(0xf8b+2364-0x1798):
return"\x53\x20\x4f";case(0x2455+72-0x236d):return"\x4e\x20\x4d";case
(0xc53+6624-0x2502):return"\x55\x20\x50";case(0xc01+2497-0x1490):return"\x75";
case(0x15d+5688-0x1662):return"\x54\x20\x52";case(0xd5a+6002-0x2398):return
"\x50\x20\x52";case(0x1dd6+532-0x1e5a):return"\x42\x20\x52";case
(0x1af4+2680-0x23db):return"\x55";case(0x1ab+9357-0x24a6):return"\x50\x20\x52";
case(0x11a8+864-0x1375):return"\x46";case(0xd91+6595-0x25c0):return
"\x4e\x20\x46";case(0x1c2c+117-0x1b0c):return"\x4d\x20\x4e\x20\x41";case
(0xef4+5327-0x222d):return"\x4e\x20\x41";case(0x318+6716-0x1bbd):return
"\x50\x20\x41\x20\x52";case(0x2da+7582-0x1ee0):return"\x52\x20\x54\x20\x4f";case
(0x70b+6319-0x1e21):return"\x43";case(0x1012+2-0xe7a):return"\x47";case
(0x31f+6554-0x1b1e):return"\x4c\x20\x52";case(0xbe9+4294-0x1b13):return
"\x50\x20\x46";case(0x1636+1316-0x19bd):return"\x50\x20\x54\x6f\x6f\x20\x4c";
case(0x31d+979-0x552):return"\x55\x52\x49\x20\x54\x6f\x6f\x20\x4c";case
(0x167f+2392-0x1e38):return"\x55\x20\x4d\x20\x54";case(0xff0+3094-0x1a66):return
"\x52\x20\x4e\x20\x53";case(0x2101+1245-0x243d):return"\x45\x20\x46";case
(0x6ff+1317-0xa82):return"\x49\x27\x6d\x20\x61\x20\x74";case(0x196c+2386-0x2119)
:return"\x4d\x20\x52";case(0x2a2+7265-0x1d5d):return"\x55\x20\x45";case
(0x543+3770-0x1256):return"\x4c";case(0x9d3+7814-0x26b1):return"\x46\x20\x44";
case(0x1be3+1890-0x219c):return"\x54\x6f\x6f\x20\x45";case(0xc81+1591-0x110e):
return"\x55\x20\x52";case(0x724+6130-0x1d6a):return"\x50\x20\x52";case
(0x73f+3062-0x1188):return"\x54\x6f\x6f\x20\x4d\x20\x52";case(0x405+7293-0x1ed3)
:return"\x52\x20\x48\x20\x46\x20\x54\x6f\x6f\x20\x4c";case(0xabd+763-0xbf5):
return"\x55\x20\x46\x6f\x72\x20\x4c\x20\x52";case(0x1172+2465-0x191e):return
"\x4e\x6f\x74\x20\x49";case(0x2fd+9630-0x26a5):return"\x42\x20\x47";case
(0x1480+1271-0x1780):return"\x53\x20\x55";case(0x17e1+2919-0x2150):return
"\x47\x20\x54";case(0x1488+3723-0x211a):return
"\x48\x20\x56\x20\x4e\x6f\x74\x20\x53";case(0x9f7+6857-0x22c6):return
"\x56\x20\x41\x20\x4e";case(0x2699+401-0x262f):return"\x49\x20\x53";case
(0xc37+6632-0x2423):return"\x4c\x20\x44";case(0x7b9+7767-0x2412):return
"\x4e\x20\x45";case(0xfac+998-0x1193):return"\x4e\x20\x41\x20\x52";default:case
(0x17d3+924-0x197b):return"\x49\x20\x53\x20\x45\x72\x72\x6f\x72";}}bool 
can_compress_content_type(const std::string&content_type){return(!content_type.
find("\x74\x65\x78\x74\x2f")&&content_type!=
"\x74\x65\x78\x74\x2f\x65\x76\x65\x6e\x74\x2d\x73\x74\x72\x65\x61\x6d")||
content_type=="\x69\x6d\x61\x67\x65\x2f\x73\x76\x67\x2b\x78\x6d\x6c"||
content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x61\x76\x61\x73\x63\x72\x69\x70\x74"
||content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"||content_type
=="\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x6d\x6c"||content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x68\x74\x6d\x6c\x2b\x78\x6d\x6c"
;}enum class EncodingType{None=(0xdc3+423-0xf6a),Gzip,Brotli};EncodingType 
encoding_type(const Request&req,const Response&res){auto ret=detail::
can_compress_content_type(res.get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65"));if(!ret){return 
EncodingType::None;}const auto&s=req.get_header_value(
"\x41\x63\x63\x65\x70\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67");(void)(s);
#ifdef CPPHTTPLIB_BROTLI_SUPPORT
ret=s.find("\x62\x72")!=std::string::npos;if(ret){return EncodingType::Brotli;}
#endif
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
ret=s.find("\x67\x7a\x69\x70")!=std::string::npos;if(ret){return EncodingType::
Gzip;}
#endif
return EncodingType::None;}class compressor{public:virtual~compressor(){};
typedef std::function<bool(const char*data,size_t data_len)>Callback;virtual 
bool compress(const char*data,size_t data_length,bool last,Callback callback)=0;
};class decompressor{public:virtual~decompressor(){}virtual bool is_valid()const
=0;typedef std::function<bool(const char*data,size_t data_len)>Callback;virtual 
bool decompress(const char*data,size_t data_length,Callback callback)=0;};class 
nocompressor:public compressor{public:~nocompressor(){};bool compress(const char
*data,size_t data_length,bool,Callback callback)override{if(!data_length){return
 true;}return callback(data,data_length);}};
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
class gzip_compressor:public compressor{public:gzip_compressor(){std::memset(&
strm_,(0x206+679-0x4ad),sizeof(strm_));strm_.zalloc=Z_NULL;strm_.zfree=Z_NULL;
strm_.opaque=Z_NULL;is_valid_=deflateInit2(&strm_,Z_DEFAULT_COMPRESSION,
Z_DEFLATED,(0x116a+2377-0x1a94),(0x3ef+2187-0xc72),Z_DEFAULT_STRATEGY)==Z_OK;}~
gzip_compressor(){deflateEnd(&strm_);}bool compress(const char*data,size_t 
data_length,bool last,Callback callback)override{assert(is_valid_);auto flush=
last?Z_FINISH:Z_NO_FLUSH;strm_.avail_in=static_cast<decltype(strm_.avail_in)>(
data_length);strm_.next_in=const_cast<Bytef*>(reinterpret_cast<const Bytef*>(
data));int ret=Z_OK;std::array<char,CPPHTTPLIB_COMPRESSION_BUFSIZ>buff{};do{
strm_.avail_out=buff.size();strm_.next_out=reinterpret_cast<Bytef*>(buff.data())
;ret=deflate(&strm_,flush);if(ret==Z_STREAM_ERROR){return false;}if(!callback(
buff.data(),buff.size()-strm_.avail_out)){return false;}}while(strm_.avail_out==
(0x1bc1+2100-0x23f5));assert((last&&ret==Z_STREAM_END)||(!last&&ret==Z_OK));
assert(strm_.avail_in==(0x1856+2250-0x2120));return true;}private:bool is_valid_
=false;z_stream strm_;};class gzip_decompressor:public decompressor{public:
gzip_decompressor(){std::memset(&strm_,(0x412+5325-0x18df),sizeof(strm_));strm_.
zalloc=Z_NULL;strm_.zfree=Z_NULL;strm_.opaque=Z_NULL;is_valid_=inflateInit2(&
strm_,(0x10dd+28-0x10d9)+(0x5e5+5837-0x1ca3))==Z_OK;}~gzip_decompressor(){
inflateEnd(&strm_);}bool is_valid()const override{return is_valid_;}bool 
decompress(const char*data,size_t data_length,Callback callback)override{assert(
is_valid_);int ret=Z_OK;strm_.avail_in=static_cast<decltype(strm_.avail_in)>(
data_length);strm_.next_in=const_cast<Bytef*>(reinterpret_cast<const Bytef*>(
data));std::array<char,CPPHTTPLIB_COMPRESSION_BUFSIZ>buff{};while(strm_.avail_in
>(0x1424+3086-0x2032)){strm_.avail_out=buff.size();strm_.next_out=
reinterpret_cast<Bytef*>(buff.data());ret=inflate(&strm_,Z_NO_FLUSH);assert(ret
!=Z_STREAM_ERROR);switch(ret){case Z_NEED_DICT:case Z_DATA_ERROR:case 
Z_MEM_ERROR:inflateEnd(&strm_);return false;}if(!callback(buff.data(),buff.size(
)-strm_.avail_out)){return false;}}return ret==Z_OK||ret==Z_STREAM_END;}private:
bool is_valid_=false;z_stream strm_;};
#endif
#ifdef CPPHTTPLIB_BROTLI_SUPPORT
class brotli_compressor:public compressor{public:brotli_compressor(){state_=
BrotliEncoderCreateInstance(nullptr,nullptr,nullptr);}~brotli_compressor(){
BrotliEncoderDestroyInstance(state_);}bool compress(const char*data,size_t 
data_length,bool last,Callback callback)override{std::array<uint8_t,
CPPHTTPLIB_COMPRESSION_BUFSIZ>buff{};auto operation=last?BROTLI_OPERATION_FINISH
:BROTLI_OPERATION_PROCESS;auto available_in=data_length;auto next_in=
reinterpret_cast<const uint8_t*>(data);for(;;){if(last){if(
BrotliEncoderIsFinished(state_)){break;}}else{if(!available_in){break;}}auto 
available_out=buff.size();auto next_out=buff.data();if(!
BrotliEncoderCompressStream(state_,operation,&available_in,&next_in,&
available_out,&next_out,nullptr)){return false;}auto output_bytes=buff.size()-
available_out;if(output_bytes){callback(reinterpret_cast<const char*>(buff.data(
)),output_bytes);}}return true;}private:BrotliEncoderState*state_=nullptr;};
class brotli_decompressor:public decompressor{public:brotli_decompressor(){
decoder_s=BrotliDecoderCreateInstance((0x775+4676-0x19b9),(0x194+9551-0x26e3),
(0xa8+5730-0x170a));decoder_r=decoder_s?BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT:
BROTLI_DECODER_RESULT_ERROR;}~brotli_decompressor(){if(decoder_s){
BrotliDecoderDestroyInstance(decoder_s);}}bool is_valid()const override{return 
decoder_s;}bool decompress(const char*data,size_t data_length,Callback callback)
override{if(decoder_r==BROTLI_DECODER_RESULT_SUCCESS||decoder_r==
BROTLI_DECODER_RESULT_ERROR){return(0xe78+4679-0x20bf);}const uint8_t*next_in=(
const uint8_t*)data;size_t avail_in=data_length;size_t total_out;decoder_r=
BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT;std::array<char,
CPPHTTPLIB_COMPRESSION_BUFSIZ>buff{};while(decoder_r==
BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT){char*next_out=buff.data();size_t 
avail_out=buff.size();decoder_r=BrotliDecoderDecompressStream(decoder_s,&
avail_in,&next_in,&avail_out,reinterpret_cast<uint8_t**>(&next_out),&total_out);
if(decoder_r==BROTLI_DECODER_RESULT_ERROR){return false;}if(!callback(buff.data(
),buff.size()-avail_out)){return false;}}return decoder_r==
BROTLI_DECODER_RESULT_SUCCESS||decoder_r==BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT
;}private:BrotliDecoderResult decoder_r;BrotliDecoderState*decoder_s=nullptr;};
#endif
bool has_header(const Headers&headers,const char*key){return headers.find(key)!=
headers.end();}const char*get_header_value(const Headers&headers,const char*key,
size_t id=(0xc5d+546-0xe7f),const char*def=nullptr){auto rng=headers.equal_range
(key);auto it=rng.first;std::advance(it,static_cast<ssize_t>(id));if(it!=rng.
second){return it->second.c_str();}return def;}template<typename T>T 
get_header_value(const Headers&,const char*,size_t=(0xfd8+5193-0x2421),uint64_t=
(0x1869+1192-0x1d11)){}template<>uint64_t get_header_value<uint64_t>(const 
Headers&headers,const char*key,size_t id,uint64_t def){auto rng=headers.
equal_range(key);auto it=rng.first;std::advance(it,static_cast<ssize_t>(id));if(
it!=rng.second){return std::strtoull(it->second.data(),nullptr,
(0xaa9+6114-0x2281));}return def;}template<typename T>bool parse_header(const 
char*beg,const char*end,T fn){while(beg<end&&is_space_or_tab(end[-
(0xf94+129-0x1014)])){end--;}auto p=beg;while(p<end&&*p!=
((char)(0x93c+123-0x97d))){p++;}if(p==end){return false;}auto key_end=p;if(*p++
!=((char)(0xda0+5525-0x22fb))){return false;}while(p<end&&is_space_or_tab(*p)){p
++;}if(p<end){fn(std::string(beg,key_end),decode_url(std::string(p,end),false));
return true;}return false;}bool read_headers(Stream&strm,Headers&headers){const 
auto bufsiz=(0x1289+5728-0x20e9);char buf[bufsiz];stream_line_reader line_reader
(strm,buf,bufsiz);for(;;){if(!line_reader.getline()){return false;}if(
line_reader.end_with_crlf()){if(line_reader.size()==(0xc2c+1277-0x1127)){break;}
}else{continue;}auto end=line_reader.ptr()+line_reader.size()-
(0xe44+4866-0x2144);parse_header(line_reader.ptr(),end,[&](std::string&&key,std
::string&&val){headers.emplace(std::move(key),std::move(val));});}return true;}
bool read_content_with_length(Stream&strm,uint64_t len,Progress progress,
ContentReceiverWithProgress out){char buf[CPPHTTPLIB_RECV_BUFSIZ];uint64_t r=
(0x430+3721-0x12b9);while(r<len){auto read_len=static_cast<size_t>(len-r);auto n
=strm.read(buf,(std::min)(read_len,CPPHTTPLIB_RECV_BUFSIZ));if(n<=
(0x1c9a+1365-0x21ef)){return false;}if(!out(buf,static_cast<size_t>(n),r,len)){
return false;}r+=static_cast<uint64_t>(n);if(progress){if(!progress(r,len)){
return false;}}}return true;}void skip_content_with_length(Stream&strm,uint64_t 
len){char buf[CPPHTTPLIB_RECV_BUFSIZ];uint64_t r=(0xa41+4398-0x1b6f);while(r<len
){auto read_len=static_cast<size_t>(len-r);auto n=strm.read(buf,(std::min)(
read_len,CPPHTTPLIB_RECV_BUFSIZ));if(n<=(0x22fc+317-0x2439)){return;}r+=
static_cast<uint64_t>(n);}}bool read_content_without_length(Stream&strm,
ContentReceiverWithProgress out){char buf[CPPHTTPLIB_RECV_BUFSIZ];uint64_t r=
(0x138c+2297-0x1c85);for(;;){auto n=strm.read(buf,CPPHTTPLIB_RECV_BUFSIZ);if(n<
(0xf60+1337-0x1499)){return false;}else if(n==(0x94c+6720-0x238c)){return true;}
if(!out(buf,static_cast<size_t>(n),r,(0x1bec+1273-0x20e5))){return false;}r+=
static_cast<uint64_t>(n);}return true;}bool read_content_chunked(Stream&strm,
ContentReceiverWithProgress out){const auto bufsiz=(0x7b1+3018-0x136b);char buf[
bufsiz];stream_line_reader line_reader(strm,buf,bufsiz);if(!line_reader.getline(
)){return false;}unsigned long chunk_len;while(true){char*end_ptr;chunk_len=std
::strtoul(line_reader.ptr(),&end_ptr,(0x1d3c+1322-0x2256));if(end_ptr==
line_reader.ptr()){return false;}if(chunk_len==ULONG_MAX){return false;}if(
chunk_len==(0xb99+4271-0x1c48)){break;}if(!read_content_with_length(strm,
chunk_len,nullptr,out)){return false;}if(!line_reader.getline()){return false;}
if(strcmp(line_reader.ptr(),"\r\n")){break;}if(!line_reader.getline()){return 
false;}}if(chunk_len==(0x1492+4613-0x2697)){if(!line_reader.getline()||strcmp(
line_reader.ptr(),"\r\n"))return false;}return true;}bool 
is_chunked_transfer_encoding(const Headers&headers){return!strcasecmp(
get_header_value(headers,
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
(0x54a+488-0x732),""),"\x63\x68\x75\x6e\x6b\x65\x64");}template<typename T,
typename U>bool prepare_content_receiver(T&x,int&status,
ContentReceiverWithProgress receiver,bool decompress,U callback){if(decompress){
std::string encoding=x.get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67");std::
unique_ptr<decompressor>decompressor;if(encoding.find("\x67\x7a\x69\x70")!=std::
string::npos||encoding.find("\x64\x65\x66\x6c\x61\x74\x65")!=std::string::npos){
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
decompressor=detail::make_unique<gzip_decompressor>();
#else
status=(0x1110+4125-0x1f8e);return false;
#endif
}else if(encoding.find("\x62\x72")!=std::string::npos){
#ifdef CPPHTTPLIB_BROTLI_SUPPORT
decompressor=detail::make_unique<brotli_decompressor>();
#else
status=(0x1337+3034-0x1d72);return false;
#endif
}if(decompressor){if(decompressor->is_valid()){ContentReceiverWithProgress out=[
&](const char*buf,size_t n,uint64_t off,uint64_t len){return decompressor->
decompress(buf,n,[&](const char*buf,size_t n){return receiver(buf,n,off,len);});
};return callback(std::move(out));}else{status=(0x8b7+466-0x895);return false;}}
}ContentReceiverWithProgress out=[&](const char*buf,size_t n,uint64_t off,
uint64_t len){return receiver(buf,n,off,len);};return callback(std::move(out));}
template<typename T>bool read_content(Stream&strm,T&x,size_t payload_max_length,
int&status,Progress progress,ContentReceiverWithProgress receiver,bool 
decompress){return prepare_content_receiver(x,status,std::move(receiver),
decompress,[&](const ContentReceiverWithProgress&out){auto ret=true;auto 
exceed_payload_max_length=false;if(is_chunked_transfer_encoding(x.headers)){ret=
read_content_chunked(strm,out);}else if(!has_header(x.headers,
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){ret=
read_content_without_length(strm,out);}else{auto len=get_header_value<uint64_t>(
x.headers,"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68");if(len>
payload_max_length){exceed_payload_max_length=true;skip_content_with_length(strm
,len);ret=false;}else if(len>(0x16b8+2082-0x1eda)){ret=read_content_with_length(
strm,len,std::move(progress),out);}}if(!ret){status=exceed_payload_max_length?
(0xd69+2432-0x154c):(0x2bd+1199-0x5dc);}return ret;});}ssize_t write_headers(
Stream&strm,const Headers&headers){ssize_t write_len=(0x365+6816-0x1e05);for(
const auto&x:headers){auto len=strm.write_format(
"\x25\x73\x3a\x20\x25\x73" "\r\n",x.first.c_str(),x.second.c_str());if(len<
(0xfb1+1787-0x16ac)){return len;}write_len+=len;}auto len=strm.write("\r\n");if(
len<(0x131+9412-0x25f5)){return len;}write_len+=len;return write_len;}bool 
write_data(Stream&strm,const char*d,size_t l){size_t offset=(0x17db+1260-0x1cc7)
;while(offset<l){auto length=strm.write(d+offset,l-offset);if(length<
(0xa40+5876-0x2134)){return false;}offset+=static_cast<size_t>(length);}return 
true;}template<typename T>bool write_content(Stream&strm,const ContentProvider&
content_provider,size_t offset,size_t length,T is_shutting_down,Error&error){
size_t end_offset=offset+length;auto ok=true;DataSink data_sink;data_sink.write=
[&](const char*d,size_t l){if(ok){if(write_data(strm,d,l)){offset+=l;}else{ok=
false;}}};data_sink.is_writable=[&](void){return ok&&strm.is_writable();};while(
offset<end_offset&&!is_shutting_down()){if(!content_provider(offset,end_offset-
offset,data_sink)){error=Error::Canceled;return false;}if(!ok){error=Error::
Write;return false;}}error=Error::Success;return true;}template<typename T>bool 
write_content(Stream&strm,const ContentProvider&content_provider,size_t offset,
size_t length,const T&is_shutting_down){auto error=Error::Success;return 
write_content(strm,content_provider,offset,length,is_shutting_down,error);}
template<typename T>bool write_content_without_length(Stream&strm,const 
ContentProvider&content_provider,const T&is_shutting_down){size_t offset=
(0x170f+3555-0x24f2);auto data_available=true;auto ok=true;DataSink data_sink;
data_sink.write=[&](const char*d,size_t l){if(ok){offset+=l;if(!write_data(strm,
d,l)){ok=false;}}};data_sink.done=[&](void){data_available=false;};data_sink.
is_writable=[&](void){return ok&&strm.is_writable();};while(data_available&&!
is_shutting_down()){if(!content_provider(offset,(0xa0d+2431-0x138c),data_sink)){
return false;}if(!ok){return false;}}return true;}template<typename T,typename U
>bool write_content_chunked(Stream&strm,const ContentProvider&content_provider,
const T&is_shutting_down,U&compressor,Error&error){size_t offset=
(0x17c0+1949-0x1f5d);auto data_available=true;auto ok=true;DataSink data_sink;
data_sink.write=[&](const char*d,size_t l){if(!ok){return;}data_available=l>
(0xe0+1082-0x51a);offset+=l;std::string payload;if(!compressor.compress(d,l,
false,[&](const char*data,size_t data_len){payload.append(data,data_len);return 
true;})){ok=false;return;}if(!payload.empty()){auto chunk=from_i_to_hex(payload.
size())+"\r\n"+payload+"\r\n";if(!write_data(strm,chunk.data(),chunk.size())){ok
=false;return;}}};data_sink.done=[&](void){if(!ok){return;}data_available=false;
std::string payload;if(!compressor.compress(nullptr,(0xc4a+3353-0x1963),true,[&]
(const char*data,size_t data_len){payload.append(data,data_len);return true;})){
ok=false;return;}if(!payload.empty()){auto chunk=from_i_to_hex(payload.size())+
"\r\n"+payload+"\r\n";if(!write_data(strm,chunk.data(),chunk.size())){ok=false;
return;}}static const std::string done_marker("\x30" "\r\n\r\n");if(!write_data(
strm,done_marker.data(),done_marker.size())){ok=false;}};data_sink.is_writable=[
&](void){return ok&&strm.is_writable();};while(data_available&&!is_shutting_down
()){if(!content_provider(offset,(0x1f9d+1588-0x25d1),data_sink)){error=Error::
Canceled;return false;}if(!ok){error=Error::Write;return false;}}error=Error::
Success;return true;}template<typename T,typename U>bool write_content_chunked(
Stream&strm,const ContentProvider&content_provider,const T&is_shutting_down,U&
compressor){auto error=Error::Success;return write_content_chunked(strm,
content_provider,is_shutting_down,compressor,error);}template<typename T>bool 
redirect(T&cli,Request&req,Response&res,const std::string&path,const std::string
&location,Error&error){Request new_req=req;new_req.path=path;new_req.
redirect_count_-=(0x1a93+556-0x1cbe);if(res.status==(0x443+5857-0x19f5)&&(req.
method!="\x47\x45\x54"&&req.method!="\x48\x45\x41\x44")){new_req.method=
"\x47\x45\x54";new_req.body.clear();new_req.headers.clear();}Response new_res;
auto ret=cli.send(new_req,new_res,error);if(ret){req=new_req;res=new_res;res.
location=location;}return ret;}std::string params_to_query_str(const Params&
params){std::string query;for(auto it=params.begin();it!=params.end();++it){if(
it!=params.begin()){query+="\x26";}query+=it->first;query+="\x3d";query+=
encode_query_param(it->second);}return query;}std::string append_query_params(
const char*path,const Params&params){std::string path_with_query=path;const 
static std::regex re("\x5b\x5e\x3f\x5d\x2b" "\\" "\x3f\x2e\x2a");auto delm=std::
regex_match(path,re)?((char)(0x9d3+5273-0x1e46)):((char)(0x3a2+4235-0x13ee));
path_with_query+=delm+params_to_query_str(params);return path_with_query;}void 
parse_query_text(const std::string&s,Params&params){split(s.data(),s.data()+s.
size(),((char)(0x9bc+3023-0x1565)),[&](const char*b,const char*e){std::string 
key;std::string val;split(b,e,((char)(0x1200+3319-0x1eba)),[&](const char*b2,
const char*e2){if(key.empty()){key.assign(b2,e2);}else{val.assign(b2,e2);}});if(
!key.empty()){params.emplace(decode_url(key,true),decode_url(val,true));}});}
bool parse_multipart_boundary(const std::string&content_type,std::string&
boundary){auto pos=content_type.find("\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d");if(
pos==std::string::npos){return false;}boundary=content_type.substr(pos+
(0x12ca+3304-0x1fa9));if(boundary.length()>=(0xc86+270-0xd92)&&boundary.front()
==((char)(0x5d5+4226-0x1635))&&boundary.back()==((char)(0x12ca+2273-0x1b89))){
boundary=boundary.substr((0x1808+2149-0x206c),boundary.size()-
(0x554+5457-0x1aa3));}return!boundary.empty();}bool parse_range_header(const std
::string&s,Ranges&ranges)try{static auto re_first_range=std::regex(
R"(bytes=(\d*-\d*(?:,\s*\d*-\d*)*))");std::smatch m;if(std::regex_match(s,m,
re_first_range)){auto pos=static_cast<size_t>(m.position((0x136f+2480-0x1d1e)));
auto len=static_cast<size_t>(m.length((0x3e8+4155-0x1422)));bool 
all_valid_ranges=true;split(&s[pos],&s[pos+len],((char)(0x15a4+1851-0x1cb3)),[&]
(const char*b,const char*e){if(!all_valid_ranges)return;static auto 
re_another_range=std::regex(R"(\s*(\d*)-(\d*))");std::cmatch cm;if(std::
regex_match(b,e,cm,re_another_range)){ssize_t first=-(0x1928+1757-0x2004);if(!cm
.str((0x16a+1574-0x78f)).empty()){first=static_cast<ssize_t>(std::stoll(cm.str(
(0x2eb+387-0x46d))));}ssize_t last=-(0x388+3199-0x1006);if(!cm.str(
(0x1975+2655-0x23d2)).empty()){last=static_cast<ssize_t>(std::stoll(cm.str(
(0x397+7803-0x2210))));}if(first!=-(0xc9a+3385-0x19d2)&&last!=-
(0x1624+699-0x18de)&&first>last){all_valid_ranges=false;return;}ranges.
emplace_back(std::make_pair(first,last));}});return all_valid_ranges;}return 
false;}catch(...){return false;}class MultipartFormDataParser{public:
MultipartFormDataParser()=default;void set_boundary(std::string&&boundary){
boundary_=boundary;}bool is_valid()const{return is_valid_;}bool parse(const char
*buf,size_t n,const ContentReceiver&content_callback,const 
MultipartContentHeader&header_callback){static const std::regex 
re_content_disposition(
"\x5e\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x44\x69\x73\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a" "\\" "\x73\x2a\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b" "\\" "\x73\x2a\x6e\x61\x6d\x65\x3d" "\"" "\x28\x2e\x2a\x3f\x29" "\"" "\x28\x3f\x3a\x3b" "\\" "\x73\x2a\x66\x69\x6c\x65\x6e\x61\x6d\x65\x3d"
"\"" "\x28\x2e\x2a\x3f\x29" "\"" "\x29\x3f" "\\" "\x73\x2a\x24",std::
regex_constants::icase);static const std::string dash_="\x2d\x2d";static const 
std::string crlf_="\r\n";buf_.append(buf,n);while(!buf_.empty()){switch(state_){
case(0x738+2000-0xf08):{auto pattern=dash_+boundary_+crlf_;if(pattern.size()>
buf_.size()){return true;}auto pos=buf_.find(pattern);if(pos!=
(0x13c8+943-0x1777)){return false;}buf_.erase((0x101+1428-0x695),pattern.size())
;off_+=pattern.size();state_=(0x21bf+460-0x238a);break;}case(0x9c4+6560-0x2363):
{clear_file_info();state_=(0xa43+4954-0x1d9b);break;}case(0x892+5501-0x1e0d):{
auto pos=buf_.find(crlf_);while(pos!=std::string::npos){if(pos==
(0x206d+335-0x21bc)){if(!header_callback(file_)){is_valid_=false;return false;}
buf_.erase((0x906+2517-0x12db),crlf_.size());off_+=crlf_.size();state_=
(0x1f3c+296-0x2061);break;}static const std::string header_name=
"\x63\x6f\x6e\x74\x65\x6e\x74\x2d\x74\x79\x70\x65\x3a";const auto header=buf_.
substr((0x1c07+1552-0x2217),pos);if(start_with_case_ignore(header,header_name)){
file_.content_type=trim_copy(header.substr(header_name.size()));}else{std::
smatch m;if(std::regex_match(header,m,re_content_disposition)){file_.name=m[
(0x1fc3+1392-0x2532)];file_.filename=m[(0xbbb+5144-0x1fd1)];}}buf_.erase(
(0x5c7+7188-0x21db),pos+crlf_.size());off_+=pos+crlf_.size();pos=buf_.find(crlf_
);}if(state_!=(0x202c+737-0x230a)){return true;}break;}case(0x19+7577-0x1daf):{{
auto pattern=crlf_+dash_;if(pattern.size()>buf_.size()){return true;}auto pos=
find_string(buf_,pattern);if(!content_callback(buf_.data(),pos)){is_valid_=false
;return false;}off_+=pos;buf_.erase((0xea+4818-0x13bc),pos);}{auto pattern=crlf_
+dash_+boundary_;if(pattern.size()>buf_.size()){return true;}auto pos=buf_.find(
pattern);if(pos!=std::string::npos){if(!content_callback(buf_.data(),pos)){
is_valid_=false;return false;}off_+=pos+pattern.size();buf_.erase(
(0x2b+5532-0x15c7),pos+pattern.size());state_=(0x26a+5111-0x165d);}else{if(!
content_callback(buf_.data(),pattern.size())){is_valid_=false;return false;}off_
+=pattern.size();buf_.erase((0xe4b+5020-0x21e7),pattern.size());}}break;}case
(0x140a+947-0x17b9):{if(crlf_.size()>buf_.size()){return true;}if(buf_.compare(
(0x233a+363-0x24a5),crlf_.size(),crlf_)==(0x639+182-0x6ef)){buf_.erase(
(0x4c4+4423-0x160b),crlf_.size());off_+=crlf_.size();state_=(0x1a12+908-0x1d9d);
}else{auto pattern=dash_+crlf_;if(pattern.size()>buf_.size()){return true;}if(
buf_.compare((0x19b5+2236-0x2271),pattern.size(),pattern)==(0xe2c+5243-0x22a7)){
buf_.erase((0xbeb+4946-0x1f3d),pattern.size());off_+=pattern.size();is_valid_=
true;state_=(0xf62+1700-0x1601);}else{return true;}}break;}case
(0xf58+601-0x11ac):{is_valid_=false;return false;}}}return true;}private:void 
clear_file_info(){file_.name.clear();file_.filename.clear();file_.content_type.
clear();}bool start_with_case_ignore(const std::string&a,const std::string&b)
const{if(a.size()<b.size()){return false;}for(size_t i=(0x10a1+2271-0x1980);i<b.
size();i++){if(::tolower(a[i])!=::tolower(b[i])){return false;}}return true;}
bool start_with(const std::string&a,size_t off,const std::string&b)const{if(a.
size()-off<b.size()){return false;}for(size_t i=(0x1b2b+1352-0x2073);i<b.size();
i++){if(a[i+off]!=b[i]){return false;}}return true;}size_t find_string(const std
::string&s,const std::string&pattern)const{auto c=pattern.front();size_t off=
(0x12a7+3095-0x1ebe);while(off<s.size()){auto pos=s.find(c,off);if(pos==std::
string::npos){return s.size();}auto rem=s.size()-pos;if(pattern.size()>rem){
return pos;}if(start_with(s,pos,pattern)){return pos;}off=pos+
(0x180+7689-0x1f88);}return s.size();}std::string boundary_;std::string buf_;
size_t state_=(0x99a+60-0x9d6);bool is_valid_=false;size_t off_=(0x55+858-0x3af)
;MultipartFormData file_;};std::string to_lower(const char*beg,const char*end){
std::string out;auto it=beg;while(it!=end){out+=static_cast<char>(::tolower(*it)
);it++;}return out;}std::string make_multipart_data_boundary(){static const char
 data[]=
"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a"
;std::random_device seed_gen;std::seed_seq seed_sequence{seed_gen(),seed_gen(),
seed_gen(),seed_gen()};std::mt19937 engine(seed_sequence);std::string result=
"\x2d\x2d\x63\x70\x70\x2d\x68\x74\x74\x70\x6c\x69\x62\x2d\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2d\x64\x61\x74\x61\x2d"
;for(auto i=(0x689+2052-0xe8d);i<(0x2b+6933-0x1b30);i++){result+=data[engine()%(
sizeof(data)-(0x24c0+212-0x2593))];}return result;}std::pair<size_t,size_t>
get_range_offset_and_length(const Request&req,size_t content_length,size_t index
){auto r=req.ranges[index];if(r.first==-(0x10fd+5083-0x24d7)&&r.second==-
(0x382+3548-0x115d)){return std::make_pair((0x999+4135-0x19c0),content_length);}
auto slen=static_cast<ssize_t>(content_length);if(r.first==-(0x1776+2064-0x1f85)
){r.first=(std::max)(static_cast<ssize_t>((0x244+7458-0x1f66)),slen-r.second);r.
second=slen-(0xdcc+4924-0x2107);}if(r.second==-(0x34f+860-0x6aa)){r.second=slen-
(0x3d6+469-0x5aa);}return std::make_pair(r.first,static_cast<size_t>(r.second-r.
first)+(0x8ea+1611-0xf34));}std::string make_content_range_header_field(size_t 
offset,size_t length,size_t content_length){std::string field=
"\x62\x79\x74\x65\x73\x20";field+=std::to_string(offset);field+="\x2d";field+=
std::to_string(offset+length-(0xe8c+2114-0x16cd));field+="\x2f";field+=std::
to_string(content_length);return field;}template<typename SToken,typename CToken
,typename Content>bool process_multipart_ranges_data(const Request&req,Response&
res,const std::string&boundary,const std::string&content_type,SToken stoken,
CToken ctoken,Content content){for(size_t i=(0x1471+2461-0x1e0e);i<req.ranges.
size();i++){ctoken("\x2d\x2d");stoken(boundary);ctoken("\r\n");if(!content_type.
empty()){ctoken("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20");
stoken(content_type);ctoken("\r\n");}auto offsets=get_range_offset_and_length(
req,res.body.size(),i);auto offset=offsets.first;auto length=offsets.second;
ctoken("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65\x3a\x20");stoken(
make_content_range_header_field(offset,length,res.body.size()));ctoken("\r\n");
ctoken("\r\n");if(!content(offset,length)){return false;}ctoken("\r\n");}ctoken(
"\x2d\x2d");stoken(boundary);ctoken("\x2d\x2d" "\r\n");return true;}bool 
make_multipart_ranges_data(const Request&req,Response&res,const std::string&
boundary,const std::string&content_type,std::string&data){return 
process_multipart_ranges_data(req,res,boundary,content_type,[&](const std::
string&token){data+=token;},[&](const char*token){data+=token;},[&](size_t 
offset,size_t length){if(offset<res.body.size()){data+=res.body.substr(offset,
length);return true;}return false;});}size_t get_multipart_ranges_data_length(
const Request&req,Response&res,const std::string&boundary,const std::string&
content_type){size_t data_length=(0x89c+4649-0x1ac5);
process_multipart_ranges_data(req,res,boundary,content_type,[&](const std::
string&token){data_length+=token.size();},[&](const char*token){data_length+=
strlen(token);},[&](size_t,size_t length){data_length+=length;return true;});
return data_length;}template<typename T>bool write_multipart_ranges_data(Stream&
strm,const Request&req,Response&res,const std::string&boundary,const std::string
&content_type,const T&is_shutting_down){return process_multipart_ranges_data(req
,res,boundary,content_type,[&](const std::string&token){strm.write(token);},[&](
const char*token){strm.write(token);},[&](size_t offset,size_t length){return 
write_content(strm,res.content_provider_,offset,length,is_shutting_down);});}std
::pair<size_t,size_t>get_range_offset_and_length(const Request&req,const 
Response&res,size_t index){auto r=req.ranges[index];if(r.second==-
(0x28a+4655-0x14b8)){r.second=static_cast<ssize_t>(res.content_length_)-
(0x1ed2+1478-0x2497);}return std::make_pair(r.first,r.second-r.first+
(0x1946+2294-0x223b));}bool expect_content(const Request&req){if(req.method==
"\x50\x4f\x53\x54"||req.method=="\x50\x55\x54"||req.method==
"\x50\x41\x54\x43\x48"||req.method=="\x50\x52\x49"||req.method==
"\x44\x45\x4c\x45\x54\x45"){return true;}return false;}bool has_crlf(const char*
s){auto p=s;while(*p){if(*p=='\r'||*p=='\n'){return true;}p++;}return false;}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
template<typename CTX,typename Init,typename Update,typename Final>std::string 
message_digest(const std::string&s,Init init,Update update,Final final,size_t 
digest_length){using namespace std;std::vector<unsigned char>md(digest_length,
(0x56d+7779-0x23d0));CTX ctx;init(&ctx);update(&ctx,s.data(),s.size());final(md.
data(),&ctx);stringstream ss;for(auto c:md){ss<<setfill(
((char)(0x56a+4537-0x16f3)))<<setw((0x586+933-0x929))<<hex<<(unsigned int)c;}
return ss.str();}std::string MD5(const std::string&s){return message_digest<
MD5_CTX>(s,MD5_Init,MD5_Update,MD5_Final,MD5_DIGEST_LENGTH);}std::string SHA_256
(const std::string&s){return message_digest<SHA256_CTX>(s,SHA256_Init,
SHA256_Update,SHA256_Final,SHA256_DIGEST_LENGTH);}std::string SHA_512(const std
::string&s){return message_digest<SHA512_CTX>(s,SHA512_Init,SHA512_Update,
SHA512_Final,SHA512_DIGEST_LENGTH);}
#endif
#ifdef _WIN32
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
bool load_system_certs_on_windows(X509_STORE*store){auto hStore=
CertOpenSystemStoreW((HCRYPTPROV_LEGACY)NULL,L"ROOT");if(!hStore){return false;}
PCCERT_CONTEXT pContext=NULL;while((pContext=CertEnumCertificatesInStore(hStore,
pContext))!=nullptr){auto encoded_cert=static_cast<const unsigned char*>(
pContext->pbCertEncoded);auto x509=d2i_X509(NULL,&encoded_cert,pContext->
cbCertEncoded);if(x509){X509_STORE_add_cert(store,x509);X509_free(x509);}}
CertFreeCertificateContext(pContext);CertCloseStore(hStore,(0xb6a+5806-0x2218));
return true;}
#endif
class WSInit{public:WSInit(){WSADATA wsaData;WSAStartup((0xa49+2047-0x1246),&
wsaData);}~WSInit(){WSACleanup();}};static WSInit wsinit_;
#endif
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
std::pair<std::string,std::string>make_digest_authentication_header(const 
Request&req,const std::map<std::string,std::string>&auth,size_t cnonce_count,
const std::string&cnonce,const std::string&username,const std::string&password,
bool is_proxy=false){using namespace std;string nc;{stringstream ss;ss<<setfill(
((char)(0xa4b+3300-0x16ff)))<<setw((0x24a3+398-0x2629))<<hex<<cnonce_count;nc=ss
.str();}auto qop=auth.at("\x71\x6f\x70");if(qop.find(
"\x61\x75\x74\x68\x2d\x69\x6e\x74")!=std::string::npos){qop=
"\x61\x75\x74\x68\x2d\x69\x6e\x74";}else{qop="\x61\x75\x74\x68";}std::string 
algo="\x4d\x44\x35";if(auth.find("\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d")!=auth.
end()){algo=auth.at("\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d");}string response;{
auto H=algo=="\x53\x48\x41\x2d\x32\x35\x36"?detail::SHA_256:algo==
"\x53\x48\x41\x2d\x35\x31\x32"?detail::SHA_512:detail::MD5;auto A1=username+
"\x3a"+auth.at("\x72\x65\x61\x6c\x6d")+"\x3a"+password;auto A2=req.method+"\x3a"
+req.path;if(qop=="\x61\x75\x74\x68\x2d\x69\x6e\x74"){A2+="\x3a"+H(req.body);}
response=H(H(A1)+"\x3a"+auth.at("\x6e\x6f\x6e\x63\x65")+"\x3a"+nc+"\x3a"+cnonce+
"\x3a"+qop+"\x3a"+H(A2));}auto field=
"\x44\x69\x67\x65\x73\x74\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3d" "\""+username
+"\"" "\x2c\x20\x72\x65\x61\x6c\x6d\x3d" "\""+auth.at("\x72\x65\x61\x6c\x6d")+
"\"" "\x2c\x20\x6e\x6f\x6e\x63\x65\x3d" "\""+auth.at("\x6e\x6f\x6e\x63\x65")+
"\"" "\x2c\x20\x75\x72\x69\x3d" "\""+req.path+
"\"" "\x2c\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x3d"+algo+
"\x2c\x20\x71\x6f\x70\x3d"+qop+"\x2c\x20\x6e\x63\x3d" "\""+nc+
"\"" "\x2c\x20\x63\x6e\x6f\x6e\x63\x65\x3d" "\""+cnonce+
"\"" "\x2c\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x3d" "\""+response+"\"";auto key=
is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,field);}
#endif
bool parse_www_authenticate(const Response&res,std::map<std::string,std::string>
&auth,bool is_proxy){auto auth_key=is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x65":
"\x57\x57\x57\x2d\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x65";if(res.
has_header(auth_key)){static auto re=std::regex(R"~((?:(?:,\s*)?(.+?)=(?:"(.*?)
"\x7c\x28\x5b\x5e\x2c\x5d\x2a\x29\x29\x29\x29\x7e");auto s=res.get_header_value(
auth_key);auto pos=s.find(((char)(0x825+5066-0x1bcf)));if(pos!=std::string::npos
){auto type=s.substr((0xd8a+631-0x1001),pos);if(type=="\x42\x61\x73\x69\x63"){
return false;}else if(type=="\x44\x69\x67\x65\x73\x74"){s=s.substr(pos+
(0xe0+1833-0x808));auto beg=std::sregex_iterator(s.begin(),s.end(),re);for(auto 
i=beg;i!=std::sregex_iterator();++i){auto m=*i;auto key=s.substr(static_cast<
size_t>(m.position((0xc62+6636-0x264d))),static_cast<size_t>(m.length(
(0x132c+3727-0x21ba))));auto val=m.length((0x5fb+3558-0x13df))>
(0x10e1+1095-0x1528)?s.substr(static_cast<size_t>(m.position((0x4f4+7383-0x21c9)
)),static_cast<size_t>(m.length((0x1f8a+1612-0x25d4)))):s.substr(static_cast<
size_t>(m.position((0x118+737-0x3f6))),static_cast<size_t>(m.length(
(0xd53+4033-0x1d11))));auth[key]=val;}return true;}}}return false;}std::string 
random_string(size_t length){auto randchar=[]()->char{const char charset[]=
"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39"
"\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a"
"\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a"
;const size_t max_index=(sizeof(charset)-(0x638+4109-0x1644));return charset[
static_cast<size_t>(rand())%max_index];};std::string str(length,
(0x44b+1678-0xad9));std::generate_n(str.begin(),length,randchar);return str;}
class ContentProviderAdapter{public:explicit ContentProviderAdapter(
ContentProviderWithoutLength&&content_provider):content_provider_(
content_provider){}bool operator()(size_t offset,size_t,DataSink&sink){return 
content_provider_(offset,sink);}private:ContentProviderWithoutLength 
content_provider_;};}std::pair<std::string,std::string>make_range_header(Ranges 
ranges){std::string field="\x62\x79\x74\x65\x73\x3d";auto i=(0x1696+3384-0x23ce)
;for(auto r:ranges){if(i!=(0x2ea+7986-0x221c)){field+="\x2c\x20";}if(r.first!=-
(0x1d39+2040-0x2530)){field+=std::to_string(r.first);}field+=
((char)(0x18db+718-0x1b7c));if(r.second!=-(0x7f4+2015-0xfd2)){field+=std::
to_string(r.second);}i++;}return std::make_pair("\x52\x61\x6e\x67\x65",std::move
(field));}std::pair<std::string,std::string>make_basic_authentication_header(
const std::string&username,const std::string&password,bool is_proxy=false){auto 
field="\x42\x61\x73\x69\x63\x20"+detail::base64_encode(username+"\x3a"+password)
;auto key=is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,std::move(field));}std::pair<std::string,std::string>
make_bearer_token_authentication_header(const std::string&token,bool is_proxy=
false){auto field="\x42\x65\x61\x72\x65\x72\x20"+token;auto key=is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,std::move(field));}bool Request::has_header(const char*key)const{return detail
::has_header(headers,key);}std::string Request::get_header_value(const char*key,
size_t id)const{return detail::get_header_value(headers,key,id,"");}template<
typename T>T Request::get_header_value(const char*key,size_t id)const{return 
detail::get_header_value<T>(headers,key,id,(0x199b+3078-0x25a1));}size_t Request
::get_header_value_count(const char*key)const{auto r=headers.equal_range(key);
return static_cast<size_t>(std::distance(r.first,r.second));}void Request::
set_header(const char*key,const char*val){if(!detail::has_crlf(key)&&!detail::
has_crlf(val)){headers.emplace(key,val);}}void Request::set_header(const char*
key,const std::string&val){if(!detail::has_crlf(key)&&!detail::has_crlf(val.
c_str())){headers.emplace(key,val);}}bool Request::has_param(const char*key)
const{return params.find(key)!=params.end();}std::string Request::
get_param_value(const char*key,size_t id)const{auto rng=params.equal_range(key);
auto it=rng.first;std::advance(it,static_cast<ssize_t>(id));if(it!=rng.second){
return it->second;}return std::string();}size_t Request::get_param_value_count(
const char*key)const{auto r=params.equal_range(key);return static_cast<size_t>(
std::distance(r.first,r.second));}bool Request::is_multipart_form_data()const{
const auto&content_type=get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");return!content_type.find(
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61");
}bool Request::has_file(const char*key)const{return files.find(key)!=files.end()
;}MultipartFormData Request::get_file_value(const char*key)const{auto it=files.
find(key);if(it!=files.end()){return it->second;}return MultipartFormData();}
bool Response::has_header(const char*key)const{return headers.find(key)!=headers
.end();}std::string Response::get_header_value(const char*key,size_t id)const{
return detail::get_header_value(headers,key,id,"");}template<typename T>T 
Response::get_header_value(const char*key,size_t id)const{return detail::
get_header_value<T>(headers,key,id,(0x757+3005-0x1314));}size_t Response::
get_header_value_count(const char*key)const{auto r=headers.equal_range(key);
return static_cast<size_t>(std::distance(r.first,r.second));}void Response::
set_header(const char*key,const char*val){if(!detail::has_crlf(key)&&!detail::
has_crlf(val)){headers.emplace(key,val);}}void Response::set_header(const char*
key,const std::string&val){if(!detail::has_crlf(key)&&!detail::has_crlf(val.
c_str())){headers.emplace(key,val);}}void Response::set_redirect(const char*url,
int stat){if(!detail::has_crlf(url)){set_header(
"\x4c\x6f\x63\x61\x74\x69\x6f\x6e",url);if((0xa07+3434-0x1645)<=stat&&stat<
(0xb9d+2075-0x1228)){this->status=stat;}else{this->status=(0xbc1+893-0xe10);}}}
void Response::set_redirect(const std::string&url,int stat){set_redirect(url.
c_str(),stat);}void Response::set_content(const char*s,size_t n,const char*
content_type){body.assign(s,n);auto rng=headers.equal_range(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");headers.erase(rng.first,rng.
second);set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
content_type);}void Response::set_content(const std::string&s,const char*
content_type){set_content(s.data(),s.size(),content_type);}void Response::
set_content_provider(size_t in_length,const char*content_type,ContentProvider 
provider,const std::function<void()>&resource_releaser){assert(in_length>
(0xb0+6766-0x1b1e));set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",content_type);content_length_
=in_length;content_provider_=std::move(provider);
content_provider_resource_releaser_=resource_releaser;
is_chunked_content_provider_=false;}void Response::set_content_provider(const 
char*content_type,ContentProviderWithoutLength provider,const std::function<void
()>&resource_releaser){set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",content_type);content_length_
=(0x6b6+3552-0x1496);content_provider_=detail::ContentProviderAdapter(std::move(
provider));content_provider_resource_releaser_=resource_releaser;
is_chunked_content_provider_=false;}void Response::set_chunked_content_provider(
const char*content_type,ContentProviderWithoutLength provider,const std::
function<void()>&resource_releaser){set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",content_type);content_length_
=(0x4c+9275-0x2487);content_provider_=detail::ContentProviderAdapter(std::move(
provider));content_provider_resource_releaser_=resource_releaser;
is_chunked_content_provider_=true;}bool Result::has_request_header(const char*
key)const{return request_headers_.find(key)!=request_headers_.end();}std::string
 Result::get_request_header_value(const char*key,size_t id)const{return detail::
get_header_value(request_headers_,key,id,"");}template<typename T>T Result::
get_request_header_value(const char*key,size_t id)const{return detail::
get_header_value<T>(request_headers_,key,id,(0x995+3867-0x18b0));}size_t Result
::get_request_header_value_count(const char*key)const{auto r=request_headers_.
equal_range(key);return static_cast<size_t>(std::distance(r.first,r.second));}
ssize_t Stream::write(const char*ptr){return write(ptr,strlen(ptr));}ssize_t 
Stream::write(const std::string&s){return write(s.data(),s.size());}template<
typename...Args>ssize_t Stream::write_format(const char*fmt,const Args&...args){
const auto bufsiz=(0xbb1+1848-0xae9);std::array<char,bufsiz>buf;
#if defined(_MSC_VER) && _MSC_VER < (0x105f+5561-0x1eac)
auto sn=_snprintf_s(buf.data(),bufsiz-(0xfe2+3155-0x1c34),buf.size()-
(0x11c7+2741-0x1c7b),fmt,args...);
#else
auto sn=snprintf(buf.data(),buf.size()-(0x173f+3744-0x25de),fmt,args...);
#endif
if(sn<=(0x1672+3044-0x2256)){return sn;}auto n=static_cast<size_t>(sn);if(n>=buf
.size()-(0xbb7+437-0xd6b)){std::vector<char>glowable_buf(buf.size());while(n>=
glowable_buf.size()-(0x373+7823-0x2201)){glowable_buf.resize(glowable_buf.size()
*(0x89d+2051-0x109e));
#if defined(_MSC_VER) && _MSC_VER < (0xcb6+5005-0x18d7)
n=static_cast<size_t>(_snprintf_s(&glowable_buf[(0x821+7097-0x23da)],
glowable_buf.size(),glowable_buf.size()-(0x12ed+494-0x14da),fmt,args...));
#else
n=static_cast<size_t>(snprintf(&glowable_buf[(0x71a+1092-0xb5e)],glowable_buf.
size()-(0x1550+3413-0x22a4),fmt,args...));
#endif
}return write(&glowable_buf[(0x133+3124-0xd67)],n);}else{return write(buf.data()
,n);}}namespace detail{SocketStream::SocketStream(socket_t sock,time_t 
read_timeout_sec,time_t read_timeout_usec,time_t write_timeout_sec,time_t 
write_timeout_usec):sock_(sock),read_timeout_sec_(read_timeout_sec),
read_timeout_usec_(read_timeout_usec),write_timeout_sec_(write_timeout_sec),
write_timeout_usec_(write_timeout_usec){}SocketStream::~SocketStream(){}bool 
SocketStream::is_readable()const{return select_read(sock_,read_timeout_sec_,
read_timeout_usec_)>(0x5c0+7308-0x224c);}bool SocketStream::is_writable()const{
return select_write(sock_,write_timeout_sec_,write_timeout_usec_)>
(0x199c+565-0x1bd1);}ssize_t SocketStream::read(char*ptr,size_t size){if(!
is_readable()){return-(0x1730+3811-0x2612);}
#ifdef _WIN32
if(size>static_cast<size_t>((std::numeric_limits<int>::max)())){return-
(0x1df4+1429-0x2388);}return recv(sock_,ptr,static_cast<int>(size),
CPPHTTPLIB_RECV_FLAGS);
#else
return handle_EINTR([&](){return recv(sock_,ptr,size,CPPHTTPLIB_RECV_FLAGS);});
#endif
}ssize_t SocketStream::write(const char*ptr,size_t size){if(!is_writable()){
return-(0xa3c+459-0xc06);}
#ifdef _WIN32
if(size>static_cast<size_t>((std::numeric_limits<int>::max)())){return-
(0x2db+3536-0x10aa);}return send(sock_,ptr,static_cast<int>(size),
CPPHTTPLIB_SEND_FLAGS);
#else
return handle_EINTR([&](){return send(sock_,ptr,size,CPPHTTPLIB_SEND_FLAGS);});
#endif
}void SocketStream::get_remote_ip_and_port(std::string&ip,int&port)const{return 
detail::get_remote_ip_and_port(sock_,ip,port);}socket_t SocketStream::socket()
const{return sock_;}bool BufferStream::is_readable()const{return true;}bool 
BufferStream::is_writable()const{return true;}ssize_t BufferStream::read(char*
ptr,size_t size){
#if defined(_MSC_VER) && _MSC_VER <= (0x1cbf+3446-0x22c9)
auto len_read=buffer._Copy_s(ptr,size,size,position);
#else
auto len_read=buffer.copy(ptr,size,position);
#endif
position+=static_cast<size_t>(len_read);return static_cast<ssize_t>(len_read);}
ssize_t BufferStream::write(const char*ptr,size_t size){buffer.append(ptr,size);
return static_cast<ssize_t>(size);}void BufferStream::get_remote_ip_and_port(std
::string&,int&)const{}socket_t BufferStream::socket()const{return
(0x2ac+8268-0x22f8);}const std::string&BufferStream::get_buffer()const{return 
buffer;}}Server::Server():new_task_queue([]{return new ThreadPool(
CPPHTTPLIB_THREAD_POOL_COUNT);}),svr_sock_(INVALID_SOCKET),is_running_(false){
#ifndef _WIN32
signal(SIGPIPE,SIG_IGN);
#endif
}Server::~Server(){}Server&Server::Get(const char*pattern,Handler handler){
return Get(pattern,strlen(pattern),handler);}Server&Server::Get(const char*
pattern,size_t pattern_len,Handler handler){get_handlers_.push_back(std::
make_pair(std::regex(pattern,pattern_len),std::move(handler)));return*this;}
Server&Server::Post(const char*pattern,Handler handler){return Post(pattern,
strlen(pattern),handler);}Server&Server::Post(const char*pattern,size_t 
pattern_len,Handler handler){post_handlers_.push_back(std::make_pair(std::regex(
pattern,pattern_len),std::move(handler)));return*this;}Server&Server::Post(const
 char*pattern,HandlerWithContentReader handler){return Post(pattern,strlen(
pattern),handler);}Server&Server::Post(const char*pattern,size_t pattern_len,
HandlerWithContentReader handler){post_handlers_for_content_reader_.push_back(
std::make_pair(std::regex(pattern,pattern_len),std::move(handler)));return*this;
}Server&Server::Put(const char*pattern,Handler handler){return Put(pattern,
strlen(pattern),handler);}Server&Server::Put(const char*pattern,size_t 
pattern_len,Handler handler){put_handlers_.push_back(std::make_pair(std::regex(
pattern,pattern_len),std::move(handler)));return*this;}Server&Server::Put(const 
char*pattern,HandlerWithContentReader handler){return Put(pattern,strlen(pattern
),handler);}Server&Server::Put(const char*pattern,size_t pattern_len,
HandlerWithContentReader handler){put_handlers_for_content_reader_.push_back(std
::make_pair(std::regex(pattern,pattern_len),std::move(handler)));return*this;}
Server&Server::Patch(const char*pattern,Handler handler){return Patch(pattern,
strlen(pattern),handler);}Server&Server::Patch(const char*pattern,size_t 
pattern_len,Handler handler){patch_handlers_.push_back(std::make_pair(std::regex
(pattern,pattern_len),std::move(handler)));return*this;}Server&Server::Patch(
const char*pattern,HandlerWithContentReader handler){return Patch(pattern,strlen
(pattern),handler);}Server&Server::Patch(const char*pattern,size_t pattern_len,
HandlerWithContentReader handler){patch_handlers_for_content_reader_.push_back(
std::make_pair(std::regex(pattern,pattern_len),std::move(handler)));return*this;
}Server&Server::Delete(const char*pattern,Handler handler){return Delete(pattern
,strlen(pattern),handler);}Server&Server::Delete(const char*pattern,size_t 
pattern_len,Handler handler){delete_handlers_.push_back(std::make_pair(std::
regex(pattern,pattern_len),std::move(handler)));return*this;}Server&Server::
Delete(const char*pattern,HandlerWithContentReader handler){return Delete(
pattern,strlen(pattern),handler);}Server&Server::Delete(const char*pattern,
size_t pattern_len,HandlerWithContentReader handler){
delete_handlers_for_content_reader_.push_back(std::make_pair(std::regex(pattern,
pattern_len),std::move(handler)));return*this;}Server&Server::Options(const char
*pattern,Handler handler){return Options(pattern,strlen(pattern),handler);}
Server&Server::Options(const char*pattern,size_t pattern_len,Handler handler){
options_handlers_.push_back(std::make_pair(std::regex(pattern,pattern_len),std::
move(handler)));return*this;}bool Server::set_base_dir(const char*dir,const char
*mount_point){return set_mount_point(mount_point,dir);}bool Server::
set_mount_point(const char*mount_point,const char*dir,Headers headers){if(detail
::is_dir(dir)){std::string mnt=mount_point?mount_point:"\x2f";if(!mnt.empty()&&
mnt[(0x19bb+1875-0x210e)]==((char)(0x2b9+7787-0x20f5))){base_dirs_.push_back({
mnt,dir,std::move(headers)});return true;}}return false;}bool Server::
remove_mount_point(const char*mount_point){for(auto it=base_dirs_.begin();it!=
base_dirs_.end();++it){if(it->mount_point==mount_point){base_dirs_.erase(it);
return true;}}return false;}Server&Server::
set_file_extension_and_mimetype_mapping(const char*ext,const char*mime){
file_extension_and_mimetype_map_[ext]=mime;return*this;}Server&Server::
set_file_request_handler(Handler handler){file_request_handler_=std::move(
handler);return*this;}Server&Server::set_error_handler(HandlerWithResponse 
handler){error_handler_=std::move(handler);return*this;}Server&Server::
set_error_handler(Handler handler){error_handler_=[handler](const Request&req,
Response&res){handler(req,res);return HandlerResponse::Handled;};return*this;}
Server&Server::set_exception_handler(ExceptionHandler handler){
exception_handler_=std::move(handler);return*this;}Server&Server::
set_pre_routing_handler(HandlerWithResponse handler){pre_routing_handler_=std::
move(handler);return*this;}Server&Server::set_post_routing_handler(Handler 
handler){post_routing_handler_=std::move(handler);return*this;}Server&Server::
set_logger(Logger logger){logger_=std::move(logger);return*this;}Server&Server::
set_expect_100_continue_handler(Expect100ContinueHandler handler){
expect_100_continue_handler_=std::move(handler);return*this;}Server&Server::
set_tcp_nodelay(bool on){tcp_nodelay_=on;return*this;}Server&Server::
set_socket_options(SocketOptions socket_options){socket_options_=std::move(
socket_options);return*this;}Server&Server::set_keep_alive_max_count(size_t 
count){keep_alive_max_count_=count;return*this;}Server&Server::
set_keep_alive_timeout(time_t sec){keep_alive_timeout_sec_=sec;return*this;}
Server&Server::set_read_timeout(time_t sec,time_t usec){read_timeout_sec_=sec;
read_timeout_usec_=usec;return*this;}Server&Server::set_write_timeout(time_t sec
,time_t usec){write_timeout_sec_=sec;write_timeout_usec_=usec;return*this;}
Server&Server::set_idle_interval(time_t sec,time_t usec){idle_interval_sec_=sec;
idle_interval_usec_=usec;return*this;}Server&Server::set_payload_max_length(
size_t length){payload_max_length_=length;return*this;}bool Server::bind_to_port
(const char*host,int port,int socket_flags){if(bind_internal(host,port,
socket_flags)<(0x1907+3512-0x26bf))return false;return true;}int Server::
bind_to_any_port(const char*host,int socket_flags){return bind_internal(host,
(0x1fc6+775-0x22cd),socket_flags);}bool Server::listen_after_bind(){return 
listen_internal();}bool Server::listen(const char*host,int port,int socket_flags
){return bind_to_port(host,port,socket_flags)&&listen_internal();}bool Server::
is_running()const{return is_running_;}void Server::stop(){if(is_running_){assert
(svr_sock_!=INVALID_SOCKET);std::atomic<socket_t>sock(svr_sock_.exchange(
INVALID_SOCKET));detail::shutdown_socket(sock);detail::close_socket(sock);}}bool
 Server::parse_request_line(const char*s,Request&req){const static std::regex re
(
"\x28\x47\x45\x54\x7c\x48\x45\x41\x44\x7c\x50\x4f\x53\x54\x7c\x50\x55\x54\x7c\x44\x45\x4c\x45\x54\x45\x7c\x43\x4f\x4e\x4e\x45\x43\x54\x7c\x4f\x50\x54\x49\x4f\x4e\x53\x7c\x54\x52\x41\x43\x45\x7c\x50\x41\x54\x43\x48\x7c\x50\x52\x49\x29\x20"
"\x28\x28\x5b\x5e\x3f\x20\x5d\x2b\x29\x28\x3f\x3a" "\\" "\x3f\x28\x5b\x5e\x20\x5d\x2a\x3f\x29\x29\x3f\x29\x20\x28\x48\x54\x54\x50\x2f\x31" "\\" "\x2e\x5b\x30\x31\x5d\x29" "\r\n"
);std::cmatch m;if(std::regex_match(s,m,re)){req.version=std::string(m[
(0x2a+267-0x130)]);req.method=std::string(m[(0xf53+4949-0x22a7)]);req.target=std
::string(m[(0x84f+6260-0x20c1)]);req.path=detail::decode_url(m[
(0x18c7+2863-0x23f3)],false);auto len=std::distance(m[(0x175c+3494-0x24fe)].
first,m[(0x9f+4328-0x1183)].second);if(len>(0x1e2a+505-0x2023)){detail::
parse_query_text(m[(0xc8f+1133-0x10f8)],req.params);}return true;}return false;}
bool Server::write_response(Stream&strm,bool close_connection,const Request&req,
Response&res){return write_response_core(strm,close_connection,req,res,false);}
bool Server::write_response_with_content(Stream&strm,bool close_connection,const
 Request&req,Response&res){return write_response_core(strm,close_connection,req,
res,true);}bool Server::write_response_core(Stream&strm,bool close_connection,
const Request&req,Response&res,bool need_apply_ranges){assert(res.status!=-
(0x923+7288-0x259a));if((0x2b4+6967-0x1c5b)<=res.status&&error_handler_&&
error_handler_(req,res)==HandlerResponse::Handled){need_apply_ranges=true;}std::
string content_type;std::string boundary;if(need_apply_ranges){apply_ranges(req,
res,content_type,boundary);}if(close_connection||req.get_header_value(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")=="\x63\x6c\x6f\x73\x65"){res.
set_header("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e","\x63\x6c\x6f\x73\x65");}
else{std::stringstream ss;ss<<"\x74\x69\x6d\x65\x6f\x75\x74\x3d"<<
keep_alive_timeout_sec_<<"\x2c\x20\x6d\x61\x78\x3d"<<keep_alive_max_count_;res.
set_header("\x4b\x65\x65\x70\x2d\x41\x6c\x69\x76\x65",ss.str());}if(!res.
has_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65")&&(!res.body.empty
()||res.content_length_>(0x630+3218-0x12c2)||res.content_provider_)){res.
set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e");}if(!res.has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")&&res.body.empty()&&!
res.content_length_&&!res.content_provider_){res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68","\x30");}if(!res.
has_header("\x41\x63\x63\x65\x70\x74\x2d\x52\x61\x6e\x67\x65\x73")&&req.method==
"\x48\x45\x41\x44"){res.set_header(
"\x41\x63\x63\x65\x70\x74\x2d\x52\x61\x6e\x67\x65\x73","\x62\x79\x74\x65\x73");}
if(post_routing_handler_){post_routing_handler_(req,res);}{detail::BufferStream 
bstrm;if(!bstrm.write_format(
"\x48\x54\x54\x50\x2f\x31\x2e\x31\x20\x25\x64\x20\x25\x73" "\r\n",res.status,
detail::status_message(res.status))){return false;}if(!detail::write_headers(
bstrm,res.headers)){return false;}auto&data=bstrm.get_buffer();strm.write(data.
data(),data.size());}auto ret=true;if(req.method!="\x48\x45\x41\x44"){if(!res.
body.empty()){if(!strm.write(res.body)){ret=false;}}else if(res.
content_provider_){if(!write_content_with_provider(strm,req,res,boundary,
content_type)){ret=false;}}}if(logger_){logger_(req,res);}return ret;}bool 
Server::write_content_with_provider(Stream&strm,const Request&req,Response&res,
const std::string&boundary,const std::string&content_type){auto is_shutting_down
=[this](){return this->svr_sock_==INVALID_SOCKET;};if(res.content_length_>
(0x1748+912-0x1ad8)){if(req.ranges.empty()){return detail::write_content(strm,
res.content_provider_,(0x156f+1584-0x1b9f),res.content_length_,is_shutting_down)
;}else if(req.ranges.size()==(0x253+7926-0x2148)){auto offsets=detail::
get_range_offset_and_length(req,res.content_length_,(0x10d6+3753-0x1f7f));auto 
offset=offsets.first;auto length=offsets.second;return detail::write_content(
strm,res.content_provider_,offset,length,is_shutting_down);}else{return detail::
write_multipart_ranges_data(strm,req,res,boundary,content_type,is_shutting_down)
;}}else{if(res.is_chunked_content_provider_){auto type=detail::encoding_type(req
,res);std::unique_ptr<detail::compressor>compressor;if(type==detail::
EncodingType::Gzip){
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
compressor=detail::make_unique<detail::gzip_compressor>();
#endif
}else if(type==detail::EncodingType::Brotli){
#ifdef CPPHTTPLIB_BROTLI_SUPPORT
compressor=detail::make_unique<detail::brotli_compressor>();
#endif
}else{compressor=detail::make_unique<detail::nocompressor>();}assert(compressor
!=nullptr);return detail::write_content_chunked(strm,res.content_provider_,
is_shutting_down,*compressor);}else{return detail::write_content_without_length(
strm,res.content_provider_,is_shutting_down);}}}bool Server::read_content(Stream
&strm,Request&req,Response&res){MultipartFormDataMap::iterator cur;if(
read_content_core(strm,req,res,[&](const char*buf,size_t n){if(req.body.size()+n
>req.body.max_size()){return false;}req.body.append(buf,n);return true;},[&](
const MultipartFormData&file){cur=req.files.emplace(file.name,file);return true;
},[&](const char*buf,size_t n){auto&content=cur->second.content;if(content.size(
)+n>content.max_size()){return false;}content.append(buf,n);return true;})){
const auto&content_type=req.get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");if(!content_type.find(
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
)){detail::parse_query_text(req.body,req.params);}return true;}return false;}
bool Server::read_content_with_content_receiver(Stream&strm,Request&req,Response
&res,ContentReceiver receiver,MultipartContentHeader multipart_header,
ContentReceiver multipart_receiver){return read_content_core(strm,req,res,std::
move(receiver),std::move(multipart_header),std::move(multipart_receiver));}bool 
Server::read_content_core(Stream&strm,Request&req,Response&res,ContentReceiver 
receiver,MultipartContentHeader mulitpart_header,ContentReceiver 
multipart_receiver){detail::MultipartFormDataParser multipart_form_data_parser;
ContentReceiverWithProgress out;if(req.is_multipart_form_data()){const auto&
content_type=req.get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");std::string boundary;if(!
detail::parse_multipart_boundary(content_type,boundary)){res.status=
(0x22ec+382-0x22da);return false;}multipart_form_data_parser.set_boundary(std::
move(boundary));out=[&](const char*buf,size_t n,uint64_t,uint64_t){return 
multipart_form_data_parser.parse(buf,n,multipart_receiver,mulitpart_header);};}
else{out=[receiver](const char*buf,size_t n,uint64_t,uint64_t){return receiver(
buf,n);};}if(req.method=="\x44\x45\x4c\x45\x54\x45"&&!req.has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){return true;}if(!
detail::read_content(strm,req,payload_max_length_,res.status,nullptr,out,true)){
return false;}if(req.is_multipart_form_data()){if(!multipart_form_data_parser.
is_valid()){res.status=(0xb24+6919-0x249b);return false;}}return true;}bool 
Server::handle_file_request(const Request&req,Response&res,bool head){for(const 
auto&entry:base_dirs_){if(!req.path.compare((0x9b5+4316-0x1a91),entry.
mount_point.size(),entry.mount_point)){std::string sub_path="\x2f"+req.path.
substr(entry.mount_point.size());if(detail::is_valid_path(sub_path)){auto path=
entry.base_dir+sub_path;if(path.back()==((char)(0x7e4+6944-0x22d5))){path+=
"\x69\x6e\x64\x65\x78\x2e\x68\x74\x6d\x6c";}if(detail::is_file(path)){detail::
read_file(path,res.body);auto type=detail::find_content_type(path,
file_extension_and_mimetype_map_);if(type){res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",type);}for(const auto&kv:
entry.headers){res.set_header(kv.first.c_str(),kv.second);}res.status=req.
has_header("\x52\x61\x6e\x67\x65")?(0x9dd+5700-0x1f53):(0x1359+5141-0x26a6);if(!
head&&file_request_handler_){file_request_handler_(req,res);}return true;}}}}
return false;}socket_t Server::create_server_socket(const char*host,int port,int
 socket_flags,SocketOptions socket_options)const{return detail::create_socket(
host,port,socket_flags,tcp_nodelay_,std::move(socket_options),[](socket_t sock,
struct addrinfo&ai)->bool{if(::bind(sock,ai.ai_addr,static_cast<socklen_t>(ai.
ai_addrlen))){return false;}if(::listen(sock,(0x5c9+2687-0x1043))){return false;
}return true;});}int Server::bind_internal(const char*host,int port,int 
socket_flags){if(!is_valid()){return-(0xa9+2112-0x8e8);}svr_sock_=
create_server_socket(host,port,socket_flags,socket_options_);if(svr_sock_==
INVALID_SOCKET){return-(0x9a1+2219-0x124b);}if(port==(0x1281+2593-0x1ca2)){
struct sockaddr_storage addr;socklen_t addr_len=sizeof(addr);if(getsockname(
svr_sock_,reinterpret_cast<struct sockaddr*>(&addr),&addr_len)==-
(0x1dcd+841-0x2115)){return-(0x1e90+49-0x1ec0);}if(addr.ss_family==AF_INET){
return ntohs(reinterpret_cast<struct sockaddr_in*>(&addr)->sin_port);}else if(
addr.ss_family==AF_INET6){return ntohs(reinterpret_cast<struct sockaddr_in6*>(&
addr)->sin6_port);}else{return-(0x1258+2466-0x1bf9);}}else{return port;}}bool 
Server::listen_internal(){auto ret=true;is_running_=true;{std::unique_ptr<
TaskQueue>task_queue(new_task_queue());while(svr_sock_!=INVALID_SOCKET){
#ifndef _WIN32
if(idle_interval_sec_>(0x12f6+4918-0x262c)||idle_interval_usec_>
(0xe14+1962-0x15be)){
#endif
auto val=detail::select_read(svr_sock_,idle_interval_sec_,idle_interval_usec_);
if(val==(0x41+9410-0x2503)){task_queue->on_idle();continue;}
#ifndef _WIN32
}
#endif
socket_t sock=accept(svr_sock_,nullptr,nullptr);if(sock==INVALID_SOCKET){if(
errno==EMFILE){std::this_thread::sleep_for(std::chrono::milliseconds(
(0x4b6+3287-0x118c)));continue;}if(svr_sock_!=INVALID_SOCKET){detail::
close_socket(svr_sock_);ret=false;}else{;}break;}
#if __cplusplus > 201703L
task_queue->enqueue([=,this](){process_and_close_socket(sock);});
#else
task_queue->enqueue([=](){process_and_close_socket(sock);});
#endif
}task_queue->shutdown();}is_running_=false;return ret;}bool Server::routing(
Request&req,Response&res,Stream&strm){if(pre_routing_handler_&&
pre_routing_handler_(req,res)==HandlerResponse::Handled){return true;}bool 
is_head_request=req.method=="\x48\x45\x41\x44";if((req.method=="\x47\x45\x54"||
is_head_request)&&handle_file_request(req,res,is_head_request)){return true;}if(
detail::expect_content(req)){{ContentReader reader([&](ContentReceiver receiver)
{return read_content_with_content_receiver(strm,req,res,std::move(receiver),
nullptr,nullptr);},[&](MultipartContentHeader header,ContentReceiver receiver){
return read_content_with_content_receiver(strm,req,res,nullptr,std::move(header)
,std::move(receiver));});if(req.method=="\x50\x4f\x53\x54"){if(
dispatch_request_for_content_reader(req,res,std::move(reader),
post_handlers_for_content_reader_)){return true;}}else if(req.method==
"\x50\x55\x54"){if(dispatch_request_for_content_reader(req,res,std::move(reader)
,put_handlers_for_content_reader_)){return true;}}else if(req.method==
"\x50\x41\x54\x43\x48"){if(dispatch_request_for_content_reader(req,res,std::move
(reader),patch_handlers_for_content_reader_)){return true;}}else if(req.method==
"\x44\x45\x4c\x45\x54\x45"){if(dispatch_request_for_content_reader(req,res,std::
move(reader),delete_handlers_for_content_reader_)){return true;}}}if(!
read_content(strm,req,res)){return false;}}if(req.method=="\x47\x45\x54"||req.
method=="\x48\x45\x41\x44"){return dispatch_request(req,res,get_handlers_);}else
 if(req.method=="\x50\x4f\x53\x54"){return dispatch_request(req,res,
post_handlers_);}else if(req.method=="\x50\x55\x54"){return dispatch_request(req
,res,put_handlers_);}else if(req.method=="\x44\x45\x4c\x45\x54\x45"){return 
dispatch_request(req,res,delete_handlers_);}else if(req.method==
"\x4f\x50\x54\x49\x4f\x4e\x53"){return dispatch_request(req,res,
options_handlers_);}else if(req.method=="\x50\x41\x54\x43\x48"){return 
dispatch_request(req,res,patch_handlers_);}res.status=(0x197+3230-0xca5);return 
false;}bool Server::dispatch_request(Request&req,Response&res,const Handlers&
handlers){for(const auto&x:handlers){const auto&pattern=x.first;const auto&
handler=x.second;if(std::regex_match(req.path,req.matches,pattern)){handler(req,
res);return true;}}return false;}void Server::apply_ranges(const Request&req,
Response&res,std::string&content_type,std::string&boundary){if(req.ranges.size()
>(0x9a5+6743-0x23fb)){boundary=detail::make_multipart_data_boundary();auto it=
res.headers.find("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");if(it!=res.
headers.end()){content_type=it->second;res.headers.erase(it);}res.headers.
emplace("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x62\x79\x74\x65\x72\x61\x6e\x67\x65\x73\x3b\x20\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d"
+boundary);}auto type=detail::encoding_type(req,res);if(res.body.empty()){if(res
.content_length_>(0x1700+971-0x1acb)){size_t length=(0x1f7+2638-0xc45);if(req.
ranges.empty()){length=res.content_length_;}else if(req.ranges.size()==
(0x37b+2221-0xc27)){auto offsets=detail::get_range_offset_and_length(req,res.
content_length_,(0x6c5+7582-0x2463));auto offset=offsets.first;length=offsets.
second;auto content_range=detail::make_content_range_header_field(offset,length,
res.content_length_);res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65",content_range);}else{
length=detail::get_multipart_ranges_data_length(req,res,boundary,content_type);}
res.set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",std::
to_string(length));}else{if(res.content_provider_){if(res.
is_chunked_content_provider_){res.set_header(
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x63\x68\x75\x6e\x6b\x65\x64");if(type==detail::EncodingType::Gzip){res.
set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x67\x7a\x69\x70");}else if(type==detail::EncodingType::Brotli){res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67","\x62\x72");}
}}}}else{if(req.ranges.empty()){;}else if(req.ranges.size()==(0xccd+1858-0x140e)
){auto offsets=detail::get_range_offset_and_length(req,res.body.size(),
(0x27+1722-0x6e1));auto offset=offsets.first;auto length=offsets.second;auto 
content_range=detail::make_content_range_header_field(offset,length,res.body.
size());res.set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65",
content_range);if(offset<res.body.size()){res.body=res.body.substr(offset,length
);}else{res.body.clear();res.status=(0x6ed+87-0x5a4);}}else{std::string data;if(
detail::make_multipart_ranges_data(req,res,boundary,content_type,data)){res.body
.swap(data);}else{res.body.clear();res.status=(0x17df+371-0x17b2);}}if(type!=
detail::EncodingType::None){std::unique_ptr<detail::compressor>compressor;std::
string content_encoding;if(type==detail::EncodingType::Gzip){
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
compressor=detail::make_unique<detail::gzip_compressor>();content_encoding=
"\x67\x7a\x69\x70";
#endif
}else if(type==detail::EncodingType::Brotli){
#ifdef CPPHTTPLIB_BROTLI_SUPPORT
compressor=detail::make_unique<detail::brotli_compressor>();content_encoding=
"\x62\x72";
#endif
}if(compressor){std::string compressed;if(compressor->compress(res.body.data(),
res.body.size(),true,[&](const char*data,size_t data_len){compressed.append(data
,data_len);return true;})){res.body.swap(compressed);res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
content_encoding);}}}auto length=std::to_string(res.body.size());res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}bool Server
::dispatch_request_for_content_reader(Request&req,Response&res,ContentReader 
content_reader,const HandlersForContentReader&handlers){for(const auto&x:
handlers){const auto&pattern=x.first;const auto&handler=x.second;if(std::
regex_match(req.path,req.matches,pattern)){handler(req,res,content_reader);
return true;}}return false;}bool Server::process_request(Stream&strm,bool 
close_connection,bool&connection_closed,const std::function<void(Request&)>&
setup_request){std::array<char,(0x1373+6056-0x231b)>buf{};detail::
stream_line_reader line_reader(strm,buf.data(),buf.size());if(!line_reader.
getline()){return false;}Request req;Response res;res.version=
"\x48\x54\x54\x50\x2f\x31\x2e\x31";
#ifdef _WIN32
#else
#ifndef CPPHTTPLIB_USE_POLL
if(strm.socket()>=FD_SETSIZE){Headers dummy;detail::read_headers(strm,dummy);res
.status=(0x11aa+102-0x101c);return write_response(strm,close_connection,req,res)
;}
#endif
#endif
if(line_reader.size()>CPPHTTPLIB_REQUEST_URI_MAX_LENGTH){Headers dummy;detail::
read_headers(strm,dummy);res.status=(0xf79+4167-0x1e22);return write_response(
strm,close_connection,req,res);}if(!parse_request_line(line_reader.ptr(),req)||!
detail::read_headers(strm,req.headers)){res.status=(0x14e9+4390-0x247f);return 
write_response(strm,close_connection,req,res);}if(req.get_header_value(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")=="\x63\x6c\x6f\x73\x65"){
connection_closed=true;}if(req.version=="\x48\x54\x54\x50\x2f\x31\x2e\x30"&&req.
get_header_value("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")!=
"\x4b\x65\x65\x70\x2d\x41\x6c\x69\x76\x65"){connection_closed=true;}strm.
get_remote_ip_and_port(req.remote_addr,req.remote_port);req.set_header(
"\x52\x45\x4d\x4f\x54\x45\x5f\x41\x44\x44\x52",req.remote_addr);req.set_header(
"\x52\x45\x4d\x4f\x54\x45\x5f\x50\x4f\x52\x54",std::to_string(req.remote_port));
if(req.has_header("\x52\x61\x6e\x67\x65")){const auto&range_header_value=req.
get_header_value("\x52\x61\x6e\x67\x65");if(!detail::parse_range_header(
range_header_value,req.ranges)){res.status=(0x246+7250-0x1cf8);return 
write_response(strm,close_connection,req,res);}}if(setup_request){setup_request(
req);}if(req.get_header_value("\x45\x78\x70\x65\x63\x74")==
"\x31\x30\x30\x2d\x63\x6f\x6e\x74\x69\x6e\x75\x65"){auto status=
(0xbb5+1030-0xf57);if(expect_100_continue_handler_){status=
expect_100_continue_handler_(req,res);}switch(status){case(0x5bd+4995-0x18dc):
case(0x14b6+587-0x1560):strm.write_format(
"\x48\x54\x54\x50\x2f\x31\x2e\x31\x20\x25\x64\x20\x25\x73" "\r\n\r\n",status,
detail::status_message(status));break;default:return write_response(strm,
close_connection,req,res);}}bool routed=false;try{routed=routing(req,res,strm);}
catch(std::exception&e){if(exception_handler_){exception_handler_(req,res,e);
routed=true;}else{res.status=(0x1117+502-0x1119);res.set_header(
"\x45\x58\x43\x45\x50\x54\x49\x4f\x4e\x5f\x57\x48\x41\x54",e.what());}}catch(...
){res.status=(0xd87+491-0xd7e);res.set_header(
"\x45\x58\x43\x45\x50\x54\x49\x4f\x4e\x5f\x57\x48\x41\x54",
"\x55\x4e\x4b\x4e\x4f\x57\x4e");}if(routed){if(res.status==-(0x8a0+7589-0x2644))
{res.status=req.ranges.empty()?(0x1ada+233-0x1afb):(0x1244+2392-0x1ace);}return 
write_response_with_content(strm,close_connection,req,res);}else{if(res.status==
-(0x8ac+4757-0x1b40)){res.status=(0x10cf+629-0x11b0);}return write_response(strm
,close_connection,req,res);}}bool Server::is_valid()const{return true;}bool 
Server::process_and_close_socket(socket_t sock){auto ret=detail::
process_server_socket(sock,keep_alive_max_count_,keep_alive_timeout_sec_,
read_timeout_sec_,read_timeout_usec_,write_timeout_sec_,write_timeout_usec_,[
this](Stream&strm,bool close_connection,bool&connection_closed){return 
process_request(strm,close_connection,connection_closed,nullptr);});detail::
shutdown_socket(sock);detail::close_socket(sock);return ret;}ClientImpl::
ClientImpl(const std::string&host):ClientImpl(host,(0x903+3149-0x1500),std::
string(),std::string()){}ClientImpl::ClientImpl(const std::string&host,int port)
:ClientImpl(host,port,std::string(),std::string()){}ClientImpl::ClientImpl(const
 std::string&host,int port,const std::string&client_cert_path,const std::string&
client_key_path):host_(host),port_(port),host_and_port_(host_+"\x3a"+std::
to_string(port_)),client_cert_path_(client_cert_path),client_key_path_(
client_key_path){}ClientImpl::~ClientImpl(){lock_socket_and_shutdown_and_close()
;}bool ClientImpl::is_valid()const{return true;}void ClientImpl::copy_settings(
const ClientImpl&rhs){client_cert_path_=rhs.client_cert_path_;client_key_path_=
rhs.client_key_path_;connection_timeout_sec_=rhs.connection_timeout_sec_;
read_timeout_sec_=rhs.read_timeout_sec_;read_timeout_usec_=rhs.
read_timeout_usec_;write_timeout_sec_=rhs.write_timeout_sec_;write_timeout_usec_
=rhs.write_timeout_usec_;basic_auth_username_=rhs.basic_auth_username_;
basic_auth_password_=rhs.basic_auth_password_;bearer_token_auth_token_=rhs.
bearer_token_auth_token_;
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
digest_auth_username_=rhs.digest_auth_username_;digest_auth_password_=rhs.
digest_auth_password_;
#endif
keep_alive_=rhs.keep_alive_;follow_location_=rhs.follow_location_;tcp_nodelay_=
rhs.tcp_nodelay_;socket_options_=rhs.socket_options_;compress_=rhs.compress_;
decompress_=rhs.decompress_;interface_=rhs.interface_;proxy_host_=rhs.
proxy_host_;proxy_port_=rhs.proxy_port_;proxy_basic_auth_username_=rhs.
proxy_basic_auth_username_;proxy_basic_auth_password_=rhs.
proxy_basic_auth_password_;proxy_bearer_token_auth_token_=rhs.
proxy_bearer_token_auth_token_;
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
proxy_digest_auth_username_=rhs.proxy_digest_auth_username_;
proxy_digest_auth_password_=rhs.proxy_digest_auth_password_;
#endif
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
server_certificate_verification_=rhs.server_certificate_verification_;
#endif
logger_=rhs.logger_;}socket_t ClientImpl::create_client_socket(Error&error)const
{if(!proxy_host_.empty()&&proxy_port_!=-(0x205d+202-0x2126)){return detail::
create_client_socket(proxy_host_.c_str(),proxy_port_,tcp_nodelay_,
socket_options_,connection_timeout_sec_,connection_timeout_usec_,interface_,
error);}return detail::create_client_socket(host_.c_str(),port_,tcp_nodelay_,
socket_options_,connection_timeout_sec_,connection_timeout_usec_,interface_,
error);}bool ClientImpl::create_and_connect_socket(Socket&socket,Error&error){
auto sock=create_client_socket(error);if(sock==INVALID_SOCKET){return false;}
socket.sock=sock;return true;}void ClientImpl::shutdown_ssl(Socket&,bool){assert
(socket_requests_in_flight_==(0x15c4+2711-0x205b)||
socket_requests_are_from_thread_==std::this_thread::get_id());}void ClientImpl::
shutdown_socket(Socket&socket){if(socket.sock==INVALID_SOCKET){return;}detail::
shutdown_socket(socket.sock);}void ClientImpl::close_socket(Socket&socket){
assert(socket_requests_in_flight_==(0x1c6+4287-0x1285)||
socket_requests_are_from_thread_==std::this_thread::get_id());
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
assert(socket.ssl==nullptr);
#endif
if(socket.sock==INVALID_SOCKET){return;}detail::close_socket(socket.sock);socket
.sock=INVALID_SOCKET;}void ClientImpl::lock_socket_and_shutdown_and_close(){std
::lock_guard<std::mutex>guard(socket_mutex_);shutdown_ssl(socket_,true);
shutdown_socket(socket_);close_socket(socket_);}bool ClientImpl::
read_response_line(Stream&strm,const Request&req,Response&res){std::array<char,
(0x1200+7076-0x25a4)>buf;detail::stream_line_reader line_reader(strm,buf.data(),
buf.size());if(!line_reader.getline()){return false;}const static std::regex re(
"\x28\x48\x54\x54\x50\x2f\x31" "\\" "\x2e\x5b\x30\x31\x5d\x29\x20\x28" "\\" "\x64\x7b\x33\x7d\x29\x20\x28\x2e\x2a\x3f\x29" "\r\n"
);std::cmatch m;if(!std::regex_match(line_reader.ptr(),m,re)){return req.method
=="\x43\x4f\x4e\x4e\x45\x43\x54";}res.version=std::string(m[(0xff6+2777-0x1ace)]
);res.status=std::stoi(std::string(m[(0x1635+514-0x1835)]));res.reason=std::
string(m[(0x532+2099-0xd62)]);while(res.status==(0x1885+2830-0x232f)){if(!
line_reader.getline()){return false;}if(!line_reader.getline()){return false;}if
(!std::regex_match(line_reader.ptr(),m,re)){return false;}res.version=std::
string(m[(0x1098+464-0x1267)]);res.status=std::stoi(std::string(m[
(0x8f9+5345-0x1dd8)]));res.reason=std::string(m[(0x1e2+3323-0xeda)]);}return 
true;}bool ClientImpl::send(Request&req,Response&res,Error&error){std::
lock_guard<std::recursive_mutex>request_mutex_guard(request_mutex_);{std::
lock_guard<std::mutex>guard(socket_mutex_);
socket_should_be_closed_when_request_is_done_=false;auto is_alive=false;if(
socket_.is_open()){is_alive=detail::select_write(socket_.sock,
(0x1831+2826-0x233b),(0x1c2+5298-0x1674))>(0x5b6+984-0x98e);if(!is_alive){const 
bool shutdown_gracefully=false;shutdown_ssl(socket_,shutdown_gracefully);
shutdown_socket(socket_);close_socket(socket_);}}if(!is_alive){if(!
create_and_connect_socket(socket_,error)){return false;}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
if(is_ssl()){auto&scli=static_cast<SSLClient&>(*this);if(!proxy_host_.empty()&&
proxy_port_!=-(0x10e0+4231-0x2166)){bool success=false;if(!scli.
connect_with_proxy(socket_,res,success,error)){return success;}}if(!scli.
initialize_ssl(socket_,error)){return false;}}
#endif
}if(socket_requests_in_flight_>(0x295+7648-0x2074)){assert(
socket_requests_are_from_thread_==std::this_thread::get_id());}
socket_requests_in_flight_+=(0x1a87+2874-0x25c0);
socket_requests_are_from_thread_=std::this_thread::get_id();}for(const auto&
header:default_headers_){if(req.headers.find(header.first)==req.headers.end()){
req.headers.insert(header);}}auto close_connection=!keep_alive_;auto ret=
process_socket(socket_,[&](Stream&strm){return handle_request(strm,req,res,
close_connection,error);});{std::lock_guard<std::mutex>guard(socket_mutex_);
socket_requests_in_flight_-=(0x1c4+9350-0x2649);if(socket_requests_in_flight_<=
(0x56c+6917-0x2071)){assert(socket_requests_in_flight_==(0x235c+717-0x2629));
socket_requests_are_from_thread_=std::thread::id();}if(
socket_should_be_closed_when_request_is_done_||close_connection||!ret){
shutdown_ssl(socket_,true);shutdown_socket(socket_);close_socket(socket_);}}if(!
ret){if(error==Error::Success){error=Error::Unknown;}}return ret;}Result 
ClientImpl::send(const Request&req){auto req2=req;return send_(std::move(req2));
}Result ClientImpl::send_(Request&&req){auto res=detail::make_unique<Response>()
;auto error=Error::Success;auto ret=send(req,*res,error);return Result{ret?std::
move(res):nullptr,error,std::move(req.headers)};}bool ClientImpl::handle_request
(Stream&strm,Request&req,Response&res,bool close_connection,Error&error){if(req.
path.empty()){error=Error::Connection;return false;}auto req_save=req;bool ret;
if(!is_ssl()&&!proxy_host_.empty()&&proxy_port_!=-(0x5eb+6622-0x1fc8)){auto req2
=req;req2.path="\x68\x74\x74\x70\x3a\x2f\x2f"+host_and_port_+req.path;ret=
process_request(strm,req2,res,close_connection,error);req=req2;req.path=req_save
.path;}else{ret=process_request(strm,req,res,close_connection,error);}if(!ret){
return false;}if((0x47f+3893-0x1288)<res.status&&res.status<(0x724+7620-0x2358)
&&follow_location_){req=req_save;ret=redirect(req,res,error);}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
if((res.status==(0x6bb+8538-0x2684)||res.status==(0x7c0+3915-0x1574))&&req.
authorization_count_<(0xfe1+5722-0x2636)){auto is_proxy=res.status==
(0x13ff+2072-0x1a80);const auto&username=is_proxy?proxy_digest_auth_username_:
digest_auth_username_;const auto&password=is_proxy?proxy_digest_auth_password_:
digest_auth_password_;if(!username.empty()&&!password.empty()){std::map<std::
string,std::string>auth;if(detail::parse_www_authenticate(res,auth,is_proxy)){
Request new_req=req;new_req.authorization_count_+=(0x16+2319-0x924);auto key=
is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";new_req.headers.erase(key
);new_req.headers.insert(detail::make_digest_authentication_header(req,auth,
new_req.authorization_count_,detail::random_string((0x3c8+2178-0xc40)),username,
password,is_proxy));Response new_res;ret=send(new_req,new_res,error);if(ret){res
=new_res;}}}}
#endif
return ret;}bool ClientImpl::redirect(Request&req,Response&res,Error&error){if(
req.redirect_count_==(0x5ab+7896-0x2483)){error=Error::ExceedRedirectCount;
return false;}auto location=detail::decode_url(res.get_header_value(
"\x6c\x6f\x63\x61\x74\x69\x6f\x6e"),true);if(location.empty()){return false;}
const static std::regex re(
R"(^(?:(https?):)?(?://([^:/?#]*)(?::(\d+))?)?([^?#]*(?:\?[^#]*)?)(?:#.*)?)");
std::smatch m;if(!std::regex_match(location,m,re)){return false;}auto scheme=
is_ssl()?"\x68\x74\x74\x70\x73":"\x68\x74\x74\x70";auto next_scheme=m[
(0x8d9+6527-0x2257)].str();auto next_host=m[(0x1012+3702-0x1e86)].str();auto 
port_str=m[(0x666+7174-0x2269)].str();auto next_path=m[(0x235f+366-0x24c9)].str(
);auto next_port=port_;if(!port_str.empty()){next_port=std::stoi(port_str);}else
 if(!next_scheme.empty()){next_port=next_scheme=="\x68\x74\x74\x70\x73"?
(0x214+3389-0xd96):(0x1fd0+1777-0x2671);}if(next_scheme.empty()){next_scheme=
scheme;}if(next_host.empty()){next_host=host_;}if(next_path.empty()){next_path=
"\x2f";}if(next_scheme==scheme&&next_host==host_&&next_port==port_){return 
detail::redirect(*this,req,res,next_path,location,error);}else{if(next_scheme==
"\x68\x74\x74\x70\x73"){
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
SSLClient cli(next_host.c_str(),next_port);cli.copy_settings(*this);return 
detail::redirect(cli,req,res,next_path,location,error);
#else
return false;
#endif
}else{ClientImpl cli(next_host.c_str(),next_port);cli.copy_settings(*this);
return detail::redirect(cli,req,res,next_path,location,error);}}}bool ClientImpl
::write_content_with_provider(Stream&strm,const Request&req,Error&error){auto 
is_shutting_down=[](){return false;};if(req.is_chunked_content_provider_){std::
unique_ptr<detail::compressor>compressor;
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
if(compress_){compressor=detail::make_unique<detail::gzip_compressor>();}else
#endif
{compressor=detail::make_unique<detail::nocompressor>();}return detail::
write_content_chunked(strm,req.content_provider_,is_shutting_down,*compressor,
error);}else{return detail::write_content(strm,req.content_provider_,
(0x1660+2197-0x1ef5),req.content_length_,is_shutting_down,error);}}bool 
ClientImpl::write_request(Stream&strm,Request&req,bool close_connection,Error&
error){if(close_connection){req.headers.emplace(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e","\x63\x6c\x6f\x73\x65");}if(!req.
has_header("\x48\x6f\x73\x74")){if(is_ssl()){if(port_==(0x1235+2114-0x18bc)){req
.headers.emplace("\x48\x6f\x73\x74",host_);}else{req.headers.emplace(
"\x48\x6f\x73\x74",host_and_port_);}}else{if(port_==(0x1c3+2706-0xc05)){req.
headers.emplace("\x48\x6f\x73\x74",host_);}else{req.headers.emplace(
"\x48\x6f\x73\x74",host_and_port_);}}}if(!req.has_header(
"\x41\x63\x63\x65\x70\x74")){req.headers.emplace("\x41\x63\x63\x65\x70\x74",
"\x2a\x2f\x2a");}if(!req.has_header("\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74"))
{req.headers.emplace("\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74",
"\x63\x70\x70\x2d\x68\x74\x74\x70\x6c\x69\x62\x2f\x30\x2e\x37");}if(req.body.
empty()){if(req.content_provider_){if(!req.is_chunked_content_provider_){auto 
length=std::to_string(req.content_length_);req.headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}else{if(req
.method=="\x50\x4f\x53\x54"||req.method=="\x50\x55\x54"||req.method==
"\x50\x41\x54\x43\x48"){req.headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68","\x30");}}}else{if(!
req.has_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65")){req.headers.
emplace("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e");}if(!req.has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){auto length=std::
to_string(req.body.size());req.headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}if(!
basic_auth_password_.empty()){req.headers.insert(
make_basic_authentication_header(basic_auth_username_,basic_auth_password_,false
));}if(!proxy_basic_auth_username_.empty()&&!proxy_basic_auth_password_.empty())
{req.headers.insert(make_basic_authentication_header(proxy_basic_auth_username_,
proxy_basic_auth_password_,true));}if(!bearer_token_auth_token_.empty()){req.
headers.insert(make_bearer_token_authentication_header(bearer_token_auth_token_,
false));}if(!proxy_bearer_token_auth_token_.empty()){req.headers.insert(
make_bearer_token_authentication_header(proxy_bearer_token_auth_token_,true));}{
detail::BufferStream bstrm;const auto&path=detail::encode_url(req.path);bstrm.
write_format("\x25\x73\x20\x25\x73\x20\x48\x54\x54\x50\x2f\x31\x2e\x31" "\r\n",
req.method.c_str(),path.c_str());detail::write_headers(bstrm,req.headers);auto&
data=bstrm.get_buffer();if(!detail::write_data(strm,data.data(),data.size())){
error=Error::Write;return false;}}if(req.body.empty()){return 
write_content_with_provider(strm,req,error);}else{return detail::write_data(strm
,req.body.data(),req.body.size());}return true;}std::unique_ptr<Response>
ClientImpl::send_with_content_provider(Request&req,const char*body,size_t 
content_length,ContentProvider content_provider,ContentProviderWithoutLength 
content_provider_without_length,const char*content_type,Error&error){if(
content_type){req.headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",content_type);}
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
if(compress_){req.headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x67\x7a\x69\x70");}
#endif
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
if(compress_&&!content_provider_without_length){detail::gzip_compressor 
compressor;if(content_provider){auto ok=true;size_t offset=(0x218+4493-0x13a5);
DataSink data_sink;data_sink.write=[&](const char*data,size_t data_len){if(ok){
auto last=offset+data_len==content_length;auto ret=compressor.compress(data,
data_len,last,[&](const char*data,size_t data_len){req.body.append(data,data_len
);return true;});if(ret){offset+=data_len;}else{ok=false;}}};data_sink.
is_writable=[&](void){return ok&&true;};while(ok&&offset<content_length){if(!
content_provider(offset,content_length-offset,data_sink)){error=Error::Canceled;
return nullptr;}}}else{if(!compressor.compress(body,content_length,true,[&](
const char*data,size_t data_len){req.body.append(data,data_len);return true;})){
error=Error::Compression;return nullptr;}}}else
#endif
{if(content_provider){req.content_length_=content_length;req.content_provider_=
std::move(content_provider);req.is_chunked_content_provider_=false;}else if(
content_provider_without_length){req.content_length_=(0x2004+706-0x22c6);req.
content_provider_=detail::ContentProviderAdapter(std::move(
content_provider_without_length));req.is_chunked_content_provider_=true;req.
headers.emplace(
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x63\x68\x75\x6e\x6b\x65\x64");}else{req.body.assign(body,content_length);;}}
auto res=detail::make_unique<Response>();return send(req,*res,error)?std::move(
res):nullptr;}Result ClientImpl::send_with_content_provider(const char*method,
const char*path,const Headers&headers,const char*body,size_t content_length,
ContentProvider content_provider,ContentProviderWithoutLength 
content_provider_without_length,const char*content_type){Request req;req.method=
method;req.headers=headers;req.path=path;auto error=Error::Success;auto res=
send_with_content_provider(req,body,content_length,std::move(content_provider),
std::move(content_provider_without_length),content_type,error);return Result{std
::move(res),error,std::move(req.headers)};}bool ClientImpl::process_request(
Stream&strm,Request&req,Response&res,bool close_connection,Error&error){if(!
write_request(strm,req,close_connection,error)){return false;}if(!
read_response_line(strm,req,res)||!detail::read_headers(strm,res.headers)){error
=Error::Read;return false;}if(req.response_handler){if(!req.response_handler(res
)){error=Error::Canceled;return false;}}if((res.status!=(0x38f+4183-0x131a))&&
req.method!="\x48\x45\x41\x44"&&req.method!="\x43\x4f\x4e\x4e\x45\x43\x54"){auto
 out=req.content_receiver?static_cast<ContentReceiverWithProgress>([&](const 
char*buf,size_t n,uint64_t off,uint64_t len){auto ret=req.content_receiver(buf,n
,off,len);if(!ret){error=Error::Canceled;}return ret;}):static_cast<
ContentReceiverWithProgress>([&](const char*buf,size_t n,uint64_t,uint64_t){if(
res.body.size()+n>res.body.max_size()){return false;}res.body.append(buf,n);
return true;});auto progress=[&](uint64_t current,uint64_t total){if(!req.
progress){return true;}auto ret=req.progress(current,total);if(!ret){error=Error
::Canceled;}return ret;};int dummy_status;if(!detail::read_content(strm,res,(std
::numeric_limits<size_t>::max)(),dummy_status,std::move(progress),std::move(out)
,decompress_)){if(error!=Error::Canceled){error=Error::Read;}return false;}}if(
res.get_header_value("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")==
"\x63\x6c\x6f\x73\x65"||(res.version=="\x48\x54\x54\x50\x2f\x31\x2e\x30"&&res.
reason!=
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x65\x73\x74\x61\x62\x6c\x69\x73\x68\x65\x64"
)){lock_socket_and_shutdown_and_close();}if(logger_){logger_(req,res);}return 
true;}bool ClientImpl::process_socket(const Socket&socket,std::function<bool(
Stream&strm)>callback){return detail::process_client_socket(socket.sock,
read_timeout_sec_,read_timeout_usec_,write_timeout_sec_,write_timeout_usec_,std
::move(callback));}bool ClientImpl::is_ssl()const{return false;}Result 
ClientImpl::Get(const char*path){return Get(path,Headers(),Progress());}Result 
ClientImpl::Get(const char*path,Progress progress){return Get(path,Headers(),std
::move(progress));}Result ClientImpl::Get(const char*path,const Headers&headers)
{return Get(path,headers,Progress());}Result ClientImpl::Get(const char*path,
const Headers&headers,Progress progress){Request req;req.method="\x47\x45\x54";
req.path=path;req.headers=headers;req.progress=std::move(progress);return send_(
std::move(req));}Result ClientImpl::Get(const char*path,ContentReceiver 
content_receiver){return Get(path,Headers(),nullptr,std::move(content_receiver),
nullptr);}Result ClientImpl::Get(const char*path,ContentReceiver 
content_receiver,Progress progress){return Get(path,Headers(),nullptr,std::move(
content_receiver),std::move(progress));}Result ClientImpl::Get(const char*path,
const Headers&headers,ContentReceiver content_receiver){return Get(path,headers,
nullptr,std::move(content_receiver),nullptr);}Result ClientImpl::Get(const char*
path,const Headers&headers,ContentReceiver content_receiver,Progress progress){
return Get(path,headers,nullptr,std::move(content_receiver),std::move(progress))
;}Result ClientImpl::Get(const char*path,ResponseHandler response_handler,
ContentReceiver content_receiver){return Get(path,Headers(),std::move(
response_handler),std::move(content_receiver),nullptr);}Result ClientImpl::Get(
const char*path,const Headers&headers,ResponseHandler response_handler,
ContentReceiver content_receiver){return Get(path,headers,std::move(
response_handler),std::move(content_receiver),nullptr);}Result ClientImpl::Get(
const char*path,ResponseHandler response_handler,ContentReceiver 
content_receiver,Progress progress){return Get(path,Headers(),std::move(
response_handler),std::move(content_receiver),std::move(progress));}Result 
ClientImpl::Get(const char*path,const Headers&headers,ResponseHandler 
response_handler,ContentReceiver content_receiver,Progress progress){Request req
;req.method="\x47\x45\x54";req.path=path;req.headers=headers;req.
response_handler=std::move(response_handler);req.content_receiver=[
content_receiver](const char*data,size_t data_length,uint64_t,uint64_t){return 
content_receiver(data,data_length);};req.progress=std::move(progress);return 
send_(std::move(req));}Result ClientImpl::Get(const char*path,const Params&
params,const Headers&headers,Progress progress){if(params.empty()){return Get(
path,headers);}std::string path_with_query=detail::append_query_params(path,
params);return Get(path_with_query.c_str(),headers,progress);}Result ClientImpl
::Get(const char*path,const Params&params,const Headers&headers,ContentReceiver 
content_receiver,Progress progress){return Get(path,params,headers,nullptr,
content_receiver,progress);}Result ClientImpl::Get(const char*path,const Params&
params,const Headers&headers,ResponseHandler response_handler,ContentReceiver 
content_receiver,Progress progress){if(params.empty()){return Get(path,headers,
response_handler,content_receiver,progress);}std::string path_with_query=detail
::append_query_params(path,params);return Get(path_with_query.c_str(),params,
headers,response_handler,content_receiver,progress);}Result ClientImpl::Head(
const char*path){return Head(path,Headers());}Result ClientImpl::Head(const char
*path,const Headers&headers){Request req;req.method="\x48\x45\x41\x44";req.
headers=headers;req.path=path;return send_(std::move(req));}Result ClientImpl::
Post(const char*path){return Post(path,std::string(),nullptr);}Result ClientImpl
::Post(const char*path,const char*body,size_t content_length,const char*
content_type){return Post(path,Headers(),body,content_length,content_type);}
Result ClientImpl::Post(const char*path,const Headers&headers,const char*body,
size_t content_length,const char*content_type){return send_with_content_provider
("\x50\x4f\x53\x54",path,headers,body,content_length,nullptr,nullptr,
content_type);}Result ClientImpl::Post(const char*path,const std::string&body,
const char*content_type){return Post(path,Headers(),body,content_type);}Result 
ClientImpl::Post(const char*path,const Headers&headers,const std::string&body,
const char*content_type){return send_with_content_provider("\x50\x4f\x53\x54",
path,headers,body.data(),body.size(),nullptr,nullptr,content_type);}Result 
ClientImpl::Post(const char*path,const Params&params){return Post(path,Headers()
,params);}Result ClientImpl::Post(const char*path,size_t content_length,
ContentProvider content_provider,const char*content_type){return Post(path,
Headers(),content_length,std::move(content_provider),content_type);}Result 
ClientImpl::Post(const char*path,ContentProviderWithoutLength content_provider,
const char*content_type){return Post(path,Headers(),std::move(content_provider),
content_type);}Result ClientImpl::Post(const char*path,const Headers&headers,
size_t content_length,ContentProvider content_provider,const char*content_type){
return send_with_content_provider("\x50\x4f\x53\x54",path,headers,nullptr,
content_length,std::move(content_provider),nullptr,content_type);}Result 
ClientImpl::Post(const char*path,const Headers&headers,
ContentProviderWithoutLength content_provider,const char*content_type){return 
send_with_content_provider("\x50\x4f\x53\x54",path,headers,nullptr,
(0x644+2865-0x1175),nullptr,std::move(content_provider),content_type);}Result 
ClientImpl::Post(const char*path,const Headers&headers,const Params&params){auto
 query=detail::params_to_query_str(params);return Post(path,headers,query,
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
);}Result ClientImpl::Post(const char*path,const MultipartFormDataItems&items){
return Post(path,Headers(),items);}Result ClientImpl::Post(const char*path,const
 Headers&headers,const MultipartFormDataItems&items){return Post(path,headers,
items,detail::make_multipart_data_boundary());}Result ClientImpl::Post(const 
char*path,const Headers&headers,const MultipartFormDataItems&items,const std::
string&boundary){for(size_t i=(0x323+942-0x6d1);i<boundary.size();i++){char c=
boundary[i];if(!std::isalnum(c)&&c!=((char)(0x1c8a+1543-0x2264))&&c!=
((char)(0x1600+3794-0x2473))){return Result{nullptr,Error::
UnsupportedMultipartBoundaryChars};}}std::string body;for(const auto&item:items)
{body+="\x2d\x2d"+boundary+"\r\n";body+=
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x44\x69\x73\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x20\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b\x20\x6e\x61\x6d\x65\x3d" "\""
+item.name+"\"";if(!item.filename.empty()){body+=
"\x3b\x20\x66\x69\x6c\x65\x6e\x61\x6d\x65\x3d" "\""+item.filename+"\"";}body+=
"\r\n";if(!item.content_type.empty()){body+=
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20"+item.content_type+
"\r\n";}body+="\r\n";body+=item.content+"\r\n";}body+="\x2d\x2d"+boundary+
"\x2d\x2d" "\r\n";std::string content_type=
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b\x20\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d"
+boundary;return Post(path,headers,body,content_type.c_str());}Result ClientImpl
::Put(const char*path){return Put(path,std::string(),nullptr);}Result ClientImpl
::Put(const char*path,const char*body,size_t content_length,const char*
content_type){return Put(path,Headers(),body,content_length,content_type);}
Result ClientImpl::Put(const char*path,const Headers&headers,const char*body,
size_t content_length,const char*content_type){return send_with_content_provider
("\x50\x55\x54",path,headers,body,content_length,nullptr,nullptr,content_type);}
Result ClientImpl::Put(const char*path,const std::string&body,const char*
content_type){return Put(path,Headers(),body,content_type);}Result ClientImpl::
Put(const char*path,const Headers&headers,const std::string&body,const char*
content_type){return send_with_content_provider("\x50\x55\x54",path,headers,body
.data(),body.size(),nullptr,nullptr,content_type);}Result ClientImpl::Put(const 
char*path,size_t content_length,ContentProvider content_provider,const char*
content_type){return Put(path,Headers(),content_length,std::move(
content_provider),content_type);}Result ClientImpl::Put(const char*path,
ContentProviderWithoutLength content_provider,const char*content_type){return 
Put(path,Headers(),std::move(content_provider),content_type);}Result ClientImpl
::Put(const char*path,const Headers&headers,size_t content_length,
ContentProvider content_provider,const char*content_type){return 
send_with_content_provider("\x50\x55\x54",path,headers,nullptr,content_length,
std::move(content_provider),nullptr,content_type);}Result ClientImpl::Put(const 
char*path,const Headers&headers,ContentProviderWithoutLength content_provider,
const char*content_type){return send_with_content_provider("\x50\x55\x54",path,
headers,nullptr,(0x38f+5820-0x1a4b),nullptr,std::move(content_provider),
content_type);}Result ClientImpl::Put(const char*path,const Params&params){
return Put(path,Headers(),params);}Result ClientImpl::Put(const char*path,const 
Headers&headers,const Params&params){auto query=detail::params_to_query_str(
params);return Put(path,headers,query,
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
);}Result ClientImpl::Patch(const char*path){return Patch(path,std::string(),
nullptr);}Result ClientImpl::Patch(const char*path,const char*body,size_t 
content_length,const char*content_type){return Patch(path,Headers(),body,
content_length,content_type);}Result ClientImpl::Patch(const char*path,const 
Headers&headers,const char*body,size_t content_length,const char*content_type){
return send_with_content_provider("\x50\x41\x54\x43\x48",path,headers,body,
content_length,nullptr,nullptr,content_type);}Result ClientImpl::Patch(const 
char*path,const std::string&body,const char*content_type){return Patch(path,
Headers(),body,content_type);}Result ClientImpl::Patch(const char*path,const 
Headers&headers,const std::string&body,const char*content_type){return 
send_with_content_provider("\x50\x41\x54\x43\x48",path,headers,body.data(),body.
size(),nullptr,nullptr,content_type);}Result ClientImpl::Patch(const char*path,
size_t content_length,ContentProvider content_provider,const char*content_type){
return Patch(path,Headers(),content_length,std::move(content_provider),
content_type);}Result ClientImpl::Patch(const char*path,
ContentProviderWithoutLength content_provider,const char*content_type){return 
Patch(path,Headers(),std::move(content_provider),content_type);}Result 
ClientImpl::Patch(const char*path,const Headers&headers,size_t content_length,
ContentProvider content_provider,const char*content_type){return 
send_with_content_provider("\x50\x41\x54\x43\x48",path,headers,nullptr,
content_length,std::move(content_provider),nullptr,content_type);}Result 
ClientImpl::Patch(const char*path,const Headers&headers,
ContentProviderWithoutLength content_provider,const char*content_type){return 
send_with_content_provider("\x50\x41\x54\x43\x48",path,headers,nullptr,
(0x1395+1551-0x19a4),nullptr,std::move(content_provider),content_type);}Result 
ClientImpl::Delete(const char*path){return Delete(path,Headers(),std::string(),
nullptr);}Result ClientImpl::Delete(const char*path,const Headers&headers){
return Delete(path,headers,std::string(),nullptr);}Result ClientImpl::Delete(
const char*path,const char*body,size_t content_length,const char*content_type){
return Delete(path,Headers(),body,content_length,content_type);}Result 
ClientImpl::Delete(const char*path,const Headers&headers,const char*body,size_t 
content_length,const char*content_type){Request req;req.method=
"\x44\x45\x4c\x45\x54\x45";req.headers=headers;req.path=path;if(content_type){
req.headers.emplace("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
content_type);}req.body.assign(body,content_length);return send_(std::move(req))
;}Result ClientImpl::Delete(const char*path,const std::string&body,const char*
content_type){return Delete(path,Headers(),body.data(),body.size(),content_type)
;}Result ClientImpl::Delete(const char*path,const Headers&headers,const std::
string&body,const char*content_type){return Delete(path,headers,body.data(),body
.size(),content_type);}Result ClientImpl::Options(const char*path){return 
Options(path,Headers());}Result ClientImpl::Options(const char*path,const 
Headers&headers){Request req;req.method="\x4f\x50\x54\x49\x4f\x4e\x53";req.
headers=headers;req.path=path;return send_(std::move(req));}size_t ClientImpl::
is_socket_open()const{std::lock_guard<std::mutex>guard(socket_mutex_);return 
socket_.is_open();}void ClientImpl::stop(){std::lock_guard<std::mutex>guard(
socket_mutex_);if(socket_requests_in_flight_>(0x68d+3559-0x1474)){
shutdown_socket(socket_);socket_should_be_closed_when_request_is_done_=true;
return;}shutdown_ssl(socket_,true);shutdown_socket(socket_);close_socket(socket_
);}void ClientImpl::set_connection_timeout(time_t sec,time_t usec){
connection_timeout_sec_=sec;connection_timeout_usec_=usec;}void ClientImpl::
set_read_timeout(time_t sec,time_t usec){read_timeout_sec_=sec;
read_timeout_usec_=usec;}void ClientImpl::set_write_timeout(time_t sec,time_t 
usec){write_timeout_sec_=sec;write_timeout_usec_=usec;}void ClientImpl::
set_basic_auth(const char*username,const char*password){basic_auth_username_=
username;basic_auth_password_=password;}void ClientImpl::set_bearer_token_auth(
const char*token){bearer_token_auth_token_=token;}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void ClientImpl::set_digest_auth(const char*username,const char*password){
digest_auth_username_=username;digest_auth_password_=password;}
#endif
void ClientImpl::set_keep_alive(bool on){keep_alive_=on;}void ClientImpl::
set_follow_location(bool on){follow_location_=on;}void ClientImpl::
set_default_headers(Headers headers){default_headers_=std::move(headers);}void 
ClientImpl::set_tcp_nodelay(bool on){tcp_nodelay_=on;}void ClientImpl::
set_socket_options(SocketOptions socket_options){socket_options_=std::move(
socket_options);}void ClientImpl::set_compress(bool on){compress_=on;}void 
ClientImpl::set_decompress(bool on){decompress_=on;}void ClientImpl::
set_interface(const char*intf){interface_=intf;}void ClientImpl::set_proxy(const
 char*host,int port){proxy_host_=host;proxy_port_=port;}void ClientImpl::
set_proxy_basic_auth(const char*username,const char*password){
proxy_basic_auth_username_=username;proxy_basic_auth_password_=password;}void 
ClientImpl::set_proxy_bearer_token_auth(const char*token){
proxy_bearer_token_auth_token_=token;}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void ClientImpl::set_proxy_digest_auth(const char*username,const char*password){
proxy_digest_auth_username_=username;proxy_digest_auth_password_=password;}
#endif
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void ClientImpl::enable_server_certificate_verification(bool enabled){
server_certificate_verification_=enabled;}
#endif
void ClientImpl::set_logger(Logger logger){logger_=std::move(logger);}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
namespace detail{template<typename U,typename V>SSL*ssl_new(socket_t sock,
SSL_CTX*ctx,std::mutex&ctx_mutex,U SSL_connect_or_accept,V setup){SSL*ssl=
nullptr;{std::lock_guard<std::mutex>guard(ctx_mutex);ssl=SSL_new(ctx);}if(ssl){
set_nonblocking(sock,true);auto bio=BIO_new_socket(static_cast<int>(sock),
BIO_NOCLOSE);BIO_set_nbio(bio,(0x6ff+6486-0x2054));SSL_set_bio(ssl,bio,bio);if(!
setup(ssl)||SSL_connect_or_accept(ssl)!=(0x1b4f+1234-0x2020)){SSL_shutdown(ssl);
{std::lock_guard<std::mutex>guard(ctx_mutex);SSL_free(ssl);}set_nonblocking(sock
,false);return nullptr;}BIO_set_nbio(bio,(0x20f+6319-0x1abe));set_nonblocking(
sock,false);}return ssl;}void ssl_delete(std::mutex&ctx_mutex,SSL*ssl,bool 
shutdown_gracefully){if(shutdown_gracefully){SSL_shutdown(ssl);}std::lock_guard<
std::mutex>guard(ctx_mutex);SSL_free(ssl);}template<typename U>bool 
ssl_connect_or_accept_nonblocking(socket_t sock,SSL*ssl,U ssl_connect_or_accept,
time_t timeout_sec,time_t timeout_usec){int res=(0x188f+982-0x1c65);while((res=
ssl_connect_or_accept(ssl))!=(0x71+8421-0x2155)){auto err=SSL_get_error(ssl,res)
;switch(err){case SSL_ERROR_WANT_READ:if(select_read(sock,timeout_sec,
timeout_usec)>(0x103+6938-0x1c1d)){continue;}break;case SSL_ERROR_WANT_WRITE:if(
select_write(sock,timeout_sec,timeout_usec)>(0xc56+6-0xc5c)){continue;}break;
default:break;}return false;}return true;}template<typename T>bool 
process_server_socket_ssl(SSL*ssl,socket_t sock,size_t keep_alive_max_count,
time_t keep_alive_timeout_sec,time_t read_timeout_sec,time_t read_timeout_usec,
time_t write_timeout_sec,time_t write_timeout_usec,T callback){return 
process_server_socket_core(sock,keep_alive_max_count,keep_alive_timeout_sec,[&](
bool close_connection,bool&connection_closed){SSLSocketStream strm(sock,ssl,
read_timeout_sec,read_timeout_usec,write_timeout_sec,write_timeout_usec);return 
callback(strm,close_connection,connection_closed);});}template<typename T>bool 
process_client_socket_ssl(SSL*ssl,socket_t sock,time_t read_timeout_sec,time_t 
read_timeout_usec,time_t write_timeout_sec,time_t write_timeout_usec,T callback)
{SSLSocketStream strm(sock,ssl,read_timeout_sec,read_timeout_usec,
write_timeout_sec,write_timeout_usec);return callback(strm);}
#if OPENSSL_VERSION_NUMBER < 0x10100000L
static std::shared_ptr<std::vector<std::mutex>>openSSL_locks_;class 
SSLThreadLocks{public:SSLThreadLocks(){openSSL_locks_=std::make_shared<std::
vector<std::mutex>>(CRYPTO_num_locks());CRYPTO_set_locking_callback(
locking_callback);}~SSLThreadLocks(){CRYPTO_set_locking_callback(nullptr);}
private:static void locking_callback(int mode,int type,const char*,int){auto&lk=
(*openSSL_locks_)[static_cast<size_t>(type)];if(mode&CRYPTO_LOCK){lk.lock();}
else{lk.unlock();}}};
#endif
class SSLInit{public:SSLInit(){
#if OPENSSL_VERSION_NUMBER < 0x1010001fL
SSL_load_error_strings();SSL_library_init();
#else
OPENSSL_init_ssl(OPENSSL_INIT_LOAD_SSL_STRINGS|OPENSSL_INIT_LOAD_CRYPTO_STRINGS,
NULL);
#endif
}~SSLInit(){
#if OPENSSL_VERSION_NUMBER < 0x1010001fL
ERR_free_strings();
#endif
}private:
#if OPENSSL_VERSION_NUMBER < 0x10100000L
SSLThreadLocks thread_init_;
#endif
};SSLSocketStream::SSLSocketStream(socket_t sock,SSL*ssl,time_t read_timeout_sec
,time_t read_timeout_usec,time_t write_timeout_sec,time_t write_timeout_usec):
sock_(sock),ssl_(ssl),read_timeout_sec_(read_timeout_sec),read_timeout_usec_(
read_timeout_usec),write_timeout_sec_(write_timeout_sec),write_timeout_usec_(
write_timeout_usec){SSL_clear_mode(ssl,SSL_MODE_AUTO_RETRY);}SSLSocketStream::~
SSLSocketStream(){}bool SSLSocketStream::is_readable()const{return detail::
select_read(sock_,read_timeout_sec_,read_timeout_usec_)>(0x1090+5538-0x2632);}
bool SSLSocketStream::is_writable()const{return detail::select_write(sock_,
write_timeout_sec_,write_timeout_usec_)>(0x77+359-0x1de);}ssize_t 
SSLSocketStream::read(char*ptr,size_t size){if(SSL_pending(ssl_)>
(0x788+1026-0xb8a)){return SSL_read(ssl_,ptr,static_cast<int>(size));}else if(
is_readable()){auto ret=SSL_read(ssl_,ptr,static_cast<int>(size));if(ret<
(0xd7a+1846-0x14b0)){auto err=SSL_get_error(ssl_,ret);while(err==
SSL_ERROR_WANT_READ){if(SSL_pending(ssl_)>(0x1022+5497-0x259b)){return SSL_read(
ssl_,ptr,static_cast<int>(size));}else if(is_readable()){ret=SSL_read(ssl_,ptr,
static_cast<int>(size));if(ret>=(0x71b+4810-0x19e5)){return ret;}err=
SSL_get_error(ssl_,ret);}else{return-(0x43b+1557-0xa4f);}}}return ret;}return-
(0x7ef+5797-0x1e93);}ssize_t SSLSocketStream::write(const char*ptr,size_t size){
if(is_writable()){return SSL_write(ssl_,ptr,static_cast<int>(size));}return-
(0x124f+4435-0x23a1);}void SSLSocketStream::get_remote_ip_and_port(std::string&
ip,int&port)const{detail::get_remote_ip_and_port(sock_,ip,port);}socket_t 
SSLSocketStream::socket()const{return sock_;}static SSLInit sslinit_;}SSLServer
::SSLServer(const char*cert_path,const char*private_key_path,const char*
client_ca_cert_file_path,const char*client_ca_cert_dir_path){ctx_=SSL_CTX_new(
SSLv23_server_method());if(ctx_){SSL_CTX_set_options(ctx_,SSL_OP_ALL|
SSL_OP_NO_SSLv2|SSL_OP_NO_SSLv3|SSL_OP_NO_COMPRESSION|
SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION);if(
SSL_CTX_use_certificate_chain_file(ctx_,cert_path)!=(0x1246+3362-0x1f67)||
SSL_CTX_use_PrivateKey_file(ctx_,private_key_path,SSL_FILETYPE_PEM)!=
(0x486+4721-0x16f6)){SSL_CTX_free(ctx_);ctx_=nullptr;}else if(
client_ca_cert_file_path||client_ca_cert_dir_path){SSL_CTX_load_verify_locations
(ctx_,client_ca_cert_file_path,client_ca_cert_dir_path);SSL_CTX_set_verify(ctx_,
SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT,nullptr);}}}SSLServer::SSLServer
(X509*cert,EVP_PKEY*private_key,X509_STORE*client_ca_cert_store){ctx_=
SSL_CTX_new(SSLv23_server_method());if(ctx_){SSL_CTX_set_options(ctx_,SSL_OP_ALL
|SSL_OP_NO_SSLv2|SSL_OP_NO_SSLv3|SSL_OP_NO_COMPRESSION|
SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION);if(SSL_CTX_use_certificate(ctx_,
cert)!=(0xec0+5237-0x2334)||SSL_CTX_use_PrivateKey(ctx_,private_key)!=
(0x817+4106-0x1820)){SSL_CTX_free(ctx_);ctx_=nullptr;}else if(
client_ca_cert_store){SSL_CTX_set_cert_store(ctx_,client_ca_cert_store);
SSL_CTX_set_verify(ctx_,SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT,nullptr)
;}}}SSLServer::~SSLServer(){if(ctx_){SSL_CTX_free(ctx_);}}bool SSLServer::
is_valid()const{return ctx_;}bool SSLServer::process_and_close_socket(socket_t 
sock){auto ssl=detail::ssl_new(sock,ctx_,ctx_mutex_,[&](SSL*ssl){return detail::
ssl_connect_or_accept_nonblocking(sock,ssl,SSL_accept,read_timeout_sec_,
read_timeout_usec_);},[](SSL*){return true;});bool ret=false;if(ssl){ret=detail
::process_server_socket_ssl(ssl,sock,keep_alive_max_count_,
keep_alive_timeout_sec_,read_timeout_sec_,read_timeout_usec_,write_timeout_sec_,
write_timeout_usec_,[this,ssl](Stream&strm,bool close_connection,bool&
connection_closed){return process_request(strm,close_connection,
connection_closed,[&](Request&req){req.ssl=ssl;});});const bool 
shutdown_gracefully=ret;detail::ssl_delete(ctx_mutex_,ssl,shutdown_gracefully);}
detail::shutdown_socket(sock);detail::close_socket(sock);return ret;}SSLClient::
SSLClient(const std::string&host):SSLClient(host,(0x1ed4+1756-0x23f5),std::
string(),std::string()){}SSLClient::SSLClient(const std::string&host,int port):
SSLClient(host,port,std::string(),std::string()){}SSLClient::SSLClient(const std
::string&host,int port,const std::string&client_cert_path,const std::string&
client_key_path):ClientImpl(host,port,client_cert_path,client_key_path){ctx_=
SSL_CTX_new(SSLv23_client_method());detail::split(&host_[(0x138d+1467-0x1948)],&
host_[host_.size()],((char)(0x91+6894-0x1b51)),[&](const char*b,const char*e){
host_components_.emplace_back(std::string(b,e));});if(!client_cert_path.empty()
&&!client_key_path.empty()){if(SSL_CTX_use_certificate_file(ctx_,
client_cert_path.c_str(),SSL_FILETYPE_PEM)!=(0xc0d+617-0xe75)||
SSL_CTX_use_PrivateKey_file(ctx_,client_key_path.c_str(),SSL_FILETYPE_PEM)!=
(0x5e0+7189-0x21f4)){SSL_CTX_free(ctx_);ctx_=nullptr;}}}SSLClient::SSLClient(
const std::string&host,int port,X509*client_cert,EVP_PKEY*client_key):ClientImpl
(host,port){ctx_=SSL_CTX_new(SSLv23_client_method());detail::split(&host_[
(0x25f4+54-0x262a)],&host_[host_.size()],((char)(0x719+4342-0x17e1)),[&](const 
char*b,const char*e){host_components_.emplace_back(std::string(b,e));});if(
client_cert!=nullptr&&client_key!=nullptr){if(SSL_CTX_use_certificate(ctx_,
client_cert)!=(0x1200+4007-0x21a6)||SSL_CTX_use_PrivateKey(ctx_,client_key)!=
(0x88a+6010-0x2003)){SSL_CTX_free(ctx_);ctx_=nullptr;}}}SSLClient::~SSLClient(){
if(ctx_){SSL_CTX_free(ctx_);}SSLClient::shutdown_ssl(socket_,true);}bool 
SSLClient::is_valid()const{return ctx_;}void SSLClient::set_ca_cert_path(const 
char*ca_cert_file_path,const char*ca_cert_dir_path){if(ca_cert_file_path){
ca_cert_file_path_=ca_cert_file_path;}if(ca_cert_dir_path){ca_cert_dir_path_=
ca_cert_dir_path;}}void SSLClient::set_ca_cert_store(X509_STORE*ca_cert_store){
if(ca_cert_store){if(ctx_){if(SSL_CTX_get_cert_store(ctx_)!=ca_cert_store){
SSL_CTX_set_cert_store(ctx_,ca_cert_store);}}else{X509_STORE_free(ca_cert_store)
;}}}long SSLClient::get_openssl_verify_result()const{return verify_result_;}
SSL_CTX*SSLClient::ssl_context()const{return ctx_;}bool SSLClient::
create_and_connect_socket(Socket&socket,Error&error){return is_valid()&&
ClientImpl::create_and_connect_socket(socket,error);}bool SSLClient::
connect_with_proxy(Socket&socket,Response&res,bool&success,Error&error){success=
true;Response res2;if(!detail::process_client_socket(socket.sock,
read_timeout_sec_,read_timeout_usec_,write_timeout_sec_,write_timeout_usec_,[&](
Stream&strm){Request req2;req2.method="\x43\x4f\x4e\x4e\x45\x43\x54";req2.path=
host_and_port_;return process_request(strm,req2,res2,false,error);})){
shutdown_ssl(socket,true);shutdown_socket(socket);close_socket(socket);success=
false;return false;}if(res2.status==(0xed2+954-0x10f5)){if(!
proxy_digest_auth_username_.empty()&&!proxy_digest_auth_password_.empty()){std::
map<std::string,std::string>auth;if(detail::parse_www_authenticate(res2,auth,
true)){Response res3;if(!detail::process_client_socket(socket.sock,
read_timeout_sec_,read_timeout_usec_,write_timeout_sec_,write_timeout_usec_,[&](
Stream&strm){Request req3;req3.method="\x43\x4f\x4e\x4e\x45\x43\x54";req3.path=
host_and_port_;req3.headers.insert(detail::make_digest_authentication_header(
req3,auth,(0x160a+920-0x19a1),detail::random_string((0xf3d+4554-0x20fd)),
proxy_digest_auth_username_,proxy_digest_auth_password_,true));return 
process_request(strm,req3,res3,false,error);})){shutdown_ssl(socket,true);
shutdown_socket(socket);close_socket(socket);success=false;return false;}}}else{
res=res2;return false;}}return true;}bool SSLClient::load_certs(){bool ret=true;
std::call_once(initialize_cert_,[&](){std::lock_guard<std::mutex>guard(
ctx_mutex_);if(!ca_cert_file_path_.empty()){if(!SSL_CTX_load_verify_locations(
ctx_,ca_cert_file_path_.c_str(),nullptr)){ret=false;}}else if(!ca_cert_dir_path_
.empty()){if(!SSL_CTX_load_verify_locations(ctx_,nullptr,ca_cert_dir_path_.c_str
())){ret=false;}}else{
#ifdef _WIN32
detail::load_system_certs_on_windows(SSL_CTX_get_cert_store(ctx_));
#else
SSL_CTX_set_default_verify_paths(ctx_);
#endif
}});return ret;}bool SSLClient::initialize_ssl(Socket&socket,Error&error){auto 
ssl=detail::ssl_new(socket.sock,ctx_,ctx_mutex_,[&](SSL*ssl){if(
server_certificate_verification_){if(!load_certs()){error=Error::SSLLoadingCerts
;return false;}SSL_set_verify(ssl,SSL_VERIFY_NONE,nullptr);}if(!detail::
ssl_connect_or_accept_nonblocking(socket.sock,ssl,SSL_connect,
connection_timeout_sec_,connection_timeout_usec_)){error=Error::SSLConnection;
return false;}if(server_certificate_verification_){verify_result_=
SSL_get_verify_result(ssl);if(verify_result_!=X509_V_OK){error=Error::
SSLServerVerification;return false;}auto server_cert=SSL_get_peer_certificate(
ssl);if(server_cert==nullptr){error=Error::SSLServerVerification;return false;}
if(!verify_host(server_cert)){X509_free(server_cert);error=Error::
SSLServerVerification;return false;}X509_free(server_cert);}return true;},[&](
SSL*ssl){SSL_set_tlsext_host_name(ssl,host_.c_str());return true;});if(ssl){
socket.ssl=ssl;return true;}shutdown_socket(socket);close_socket(socket);return 
false;}void SSLClient::shutdown_ssl(Socket&socket,bool shutdown_gracefully){if(
socket.sock==INVALID_SOCKET){assert(socket.ssl==nullptr);return;}if(socket.ssl){
detail::ssl_delete(ctx_mutex_,socket.ssl,shutdown_gracefully);socket.ssl=nullptr
;}assert(socket.ssl==nullptr);}bool SSLClient::process_socket(const Socket&
socket,std::function<bool(Stream&strm)>callback){assert(socket.ssl);return 
detail::process_client_socket_ssl(socket.ssl,socket.sock,read_timeout_sec_,
read_timeout_usec_,write_timeout_sec_,write_timeout_usec_,std::move(callback));}
bool SSLClient::is_ssl()const{return true;}bool SSLClient::verify_host(X509*
server_cert)const{return verify_host_with_subject_alt_name(server_cert)||
verify_host_with_common_name(server_cert);}bool SSLClient::
verify_host_with_subject_alt_name(X509*server_cert)const{auto ret=false;auto 
type=GEN_DNS;struct in6_addr addr6;struct in_addr addr;size_t addr_len=
(0x11c2+4394-0x22ec);
#ifndef __MINGW32__
if(inet_pton(AF_INET6,host_.c_str(),&addr6)){type=GEN_IPADD;addr_len=sizeof(
struct in6_addr);}else if(inet_pton(AF_INET,host_.c_str(),&addr)){type=GEN_IPADD
;addr_len=sizeof(struct in_addr);}
#endif
auto alt_names=static_cast<const struct stack_st_GENERAL_NAME*>(X509_get_ext_d2i
(server_cert,NID_subject_alt_name,nullptr,nullptr));if(alt_names){auto 
dsn_matched=false;auto ip_mached=false;auto count=sk_GENERAL_NAME_num(alt_names)
;for(decltype(count)i=(0x23d1+171-0x247c);i<count&&!dsn_matched;i++){auto val=
sk_GENERAL_NAME_value(alt_names,i);if(val->type==type){auto name=(const char*)
ASN1_STRING_get0_data(val->d.ia5);auto name_len=(size_t)ASN1_STRING_length(val->
d.ia5);switch(type){case GEN_DNS:dsn_matched=check_host_name(name,name_len);
break;case GEN_IPADD:if(!memcmp(&addr6,name,addr_len)||!memcmp(&addr,name,
addr_len)){ip_mached=true;}break;}}}if(dsn_matched||ip_mached){ret=true;}}
GENERAL_NAMES_free((STACK_OF(GENERAL_NAME)*)alt_names);return ret;}bool 
SSLClient::verify_host_with_common_name(X509*server_cert)const{const auto 
subject_name=X509_get_subject_name(server_cert);if(subject_name!=nullptr){char 
name[BUFSIZ];auto name_len=X509_NAME_get_text_by_NID(subject_name,NID_commonName
,name,sizeof(name));if(name_len!=-(0xb96+1503-0x1174)){return check_host_name(
name,static_cast<size_t>(name_len));}}return false;}bool SSLClient::
check_host_name(const char*pattern,size_t pattern_len)const{if(host_.size()==
pattern_len&&host_==pattern){return true;}std::vector<std::string>
pattern_components;detail::split(&pattern[(0xbf0+1685-0x1285)],&pattern[
pattern_len],((char)(0xab2+5481-0x1fed)),[&](const char*b,const char*e){
pattern_components.emplace_back(std::string(b,e));});if(host_components_.size()
!=pattern_components.size()){return false;}auto itr=pattern_components.begin();
for(const auto&h:host_components_){auto&p=*itr;if(p!=h&&p!="\x2a"){auto 
partial_match=(p.size()>(0xe54+2893-0x19a1)&&p[p.size()-(0x1039+5024-0x23d8)]==
((char)(0x9af+3188-0x15f9))&&!p.compare((0x7ed+4968-0x1b55),p.size()-
(0x1128+5326-0x25f5),h));if(!partial_match){return false;}}++itr;}return true;}
#endif
Client::Client(const char*scheme_host_port):Client(scheme_host_port,std::string(
),std::string()){}Client::Client(const char*scheme_host_port,const std::string&
client_cert_path,const std::string&client_key_path){const static std::regex re(
R"(^(?:([a-z]+)://)?([^:/?#]+)(?::(\d+))?)");std::cmatch m;if(std::regex_match(
scheme_host_port,m,re)){auto scheme=m[(0xbb1+2101-0x13e5)].str();
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
if(!scheme.empty()&&(scheme!="\x68\x74\x74\x70"&&scheme!="\x68\x74\x74\x70\x73")
){
#else
if(!scheme.empty()&&scheme!="\x68\x74\x74\x70"){
#endif
std::string msg="\x27"+scheme+
"\x27\x20\x73\x63\x68\x65\x6d\x65\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x2e"
;throw std::invalid_argument(msg);return;}auto is_ssl=scheme==
"\x68\x74\x74\x70\x73";auto host=m[(0xf80+4998-0x2304)].str();auto port_str=m[
(0x5b7+5025-0x1955)].str();auto port=!port_str.empty()?std::stoi(port_str):(
is_ssl?(0x151a+4315-0x243a):(0x1ec1+697-0x212a));if(is_ssl){
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
cli_=detail::make_unique<SSLClient>(host.c_str(),port,client_cert_path,
client_key_path);is_ssl_=is_ssl;
#endif
}else{cli_=detail::make_unique<ClientImpl>(host.c_str(),port,client_cert_path,
client_key_path);}}else{cli_=detail::make_unique<ClientImpl>(scheme_host_port,
(0x1c77+1185-0x20c8),client_cert_path,client_key_path);}}Client::Client(const 
std::string&host,int port):cli_(detail::make_unique<ClientImpl>(host,port)){}
Client::Client(const std::string&host,int port,const std::string&
client_cert_path,const std::string&client_key_path):cli_(detail::make_unique<
ClientImpl>(host,port,client_cert_path,client_key_path)){}Client::~Client(){}
bool Client::is_valid()const{return cli_!=nullptr&&cli_->is_valid();}Result 
Client::Get(const char*path){return cli_->Get(path);}Result Client::Get(const 
char*path,const Headers&headers){return cli_->Get(path,headers);}Result Client::
Get(const char*path,Progress progress){return cli_->Get(path,std::move(progress)
);}Result Client::Get(const char*path,const Headers&headers,Progress progress){
return cli_->Get(path,headers,std::move(progress));}Result Client::Get(const 
char*path,ContentReceiver content_receiver){return cli_->Get(path,std::move(
content_receiver));}Result Client::Get(const char*path,const Headers&headers,
ContentReceiver content_receiver){return cli_->Get(path,headers,std::move(
content_receiver));}Result Client::Get(const char*path,ContentReceiver 
content_receiver,Progress progress){return cli_->Get(path,std::move(
content_receiver),std::move(progress));}Result Client::Get(const char*path,const
 Headers&headers,ContentReceiver content_receiver,Progress progress){return cli_
->Get(path,headers,std::move(content_receiver),std::move(progress));}Result 
Client::Get(const char*path,ResponseHandler response_handler,ContentReceiver 
content_receiver){return cli_->Get(path,std::move(response_handler),std::move(
content_receiver));}Result Client::Get(const char*path,const Headers&headers,
ResponseHandler response_handler,ContentReceiver content_receiver){return cli_->
Get(path,headers,std::move(response_handler),std::move(content_receiver));}
Result Client::Get(const char*path,ResponseHandler response_handler,
ContentReceiver content_receiver,Progress progress){return cli_->Get(path,std::
move(response_handler),std::move(content_receiver),std::move(progress));}Result 
Client::Get(const char*path,const Headers&headers,ResponseHandler 
response_handler,ContentReceiver content_receiver,Progress progress){return cli_
->Get(path,headers,std::move(response_handler),std::move(content_receiver),std::
move(progress));}Result Client::Get(const char*path,const Params&params,const 
Headers&headers,Progress progress){return cli_->Get(path,params,headers,progress
);}Result Client::Get(const char*path,const Params&params,const Headers&headers,
ContentReceiver content_receiver,Progress progress){return cli_->Get(path,params
,headers,content_receiver,progress);}Result Client::Get(const char*path,const 
Params&params,const Headers&headers,ResponseHandler response_handler,
ContentReceiver content_receiver,Progress progress){return cli_->Get(path,params
,headers,response_handler,content_receiver,progress);}Result Client::Head(const 
char*path){return cli_->Head(path);}Result Client::Head(const char*path,const 
Headers&headers){return cli_->Head(path,headers);}Result Client::Post(const char
*path){return cli_->Post(path);}Result Client::Post(const char*path,const char*
body,size_t content_length,const char*content_type){return cli_->Post(path,body,
content_length,content_type);}Result Client::Post(const char*path,const Headers&
headers,const char*body,size_t content_length,const char*content_type){return 
cli_->Post(path,headers,body,content_length,content_type);}Result Client::Post(
const char*path,const std::string&body,const char*content_type){return cli_->
Post(path,body,content_type);}Result Client::Post(const char*path,const Headers&
headers,const std::string&body,const char*content_type){return cli_->Post(path,
headers,body,content_type);}Result Client::Post(const char*path,size_t 
content_length,ContentProvider content_provider,const char*content_type){return 
cli_->Post(path,content_length,std::move(content_provider),content_type);}Result
 Client::Post(const char*path,ContentProviderWithoutLength content_provider,
const char*content_type){return cli_->Post(path,std::move(content_provider),
content_type);}Result Client::Post(const char*path,const Headers&headers,size_t 
content_length,ContentProvider content_provider,const char*content_type){return 
cli_->Post(path,headers,content_length,std::move(content_provider),content_type)
;}Result Client::Post(const char*path,const Headers&headers,
ContentProviderWithoutLength content_provider,const char*content_type){return 
cli_->Post(path,headers,std::move(content_provider),content_type);}Result Client
::Post(const char*path,const Params&params){return cli_->Post(path,params);}
Result Client::Post(const char*path,const Headers&headers,const Params&params){
return cli_->Post(path,headers,params);}Result Client::Post(const char*path,
const MultipartFormDataItems&items){return cli_->Post(path,items);}Result Client
::Post(const char*path,const Headers&headers,const MultipartFormDataItems&items)
{return cli_->Post(path,headers,items);}Result Client::Post(const char*path,
const Headers&headers,const MultipartFormDataItems&items,const std::string&
boundary){return cli_->Post(path,headers,items,boundary);}Result Client::Put(
const char*path){return cli_->Put(path);}Result Client::Put(const char*path,
const char*body,size_t content_length,const char*content_type){return cli_->Put(
path,body,content_length,content_type);}Result Client::Put(const char*path,const
 Headers&headers,const char*body,size_t content_length,const char*content_type){
return cli_->Put(path,headers,body,content_length,content_type);}Result Client::
Put(const char*path,const std::string&body,const char*content_type){return cli_
->Put(path,body,content_type);}Result Client::Put(const char*path,const Headers&
headers,const std::string&body,const char*content_type){return cli_->Put(path,
headers,body,content_type);}Result Client::Put(const char*path,size_t 
content_length,ContentProvider content_provider,const char*content_type){return 
cli_->Put(path,content_length,std::move(content_provider),content_type);}Result 
Client::Put(const char*path,ContentProviderWithoutLength content_provider,const 
char*content_type){return cli_->Put(path,std::move(content_provider),
content_type);}Result Client::Put(const char*path,const Headers&headers,size_t 
content_length,ContentProvider content_provider,const char*content_type){return 
cli_->Put(path,headers,content_length,std::move(content_provider),content_type);
}Result Client::Put(const char*path,const Headers&headers,
ContentProviderWithoutLength content_provider,const char*content_type){return 
cli_->Put(path,headers,std::move(content_provider),content_type);}Result Client
::Put(const char*path,const Params&params){return cli_->Put(path,params);}Result
 Client::Put(const char*path,const Headers&headers,const Params&params){return 
cli_->Put(path,headers,params);}Result Client::Patch(const char*path){return 
cli_->Patch(path);}Result Client::Patch(const char*path,const char*body,size_t 
content_length,const char*content_type){return cli_->Patch(path,body,
content_length,content_type);}Result Client::Patch(const char*path,const Headers
&headers,const char*body,size_t content_length,const char*content_type){return 
cli_->Patch(path,headers,body,content_length,content_type);}Result Client::Patch
(const char*path,const std::string&body,const char*content_type){return cli_->
Patch(path,body,content_type);}Result Client::Patch(const char*path,const 
Headers&headers,const std::string&body,const char*content_type){return cli_->
Patch(path,headers,body,content_type);}Result Client::Patch(const char*path,
size_t content_length,ContentProvider content_provider,const char*content_type){
return cli_->Patch(path,content_length,std::move(content_provider),content_type)
;}Result Client::Patch(const char*path,ContentProviderWithoutLength 
content_provider,const char*content_type){return cli_->Patch(path,std::move(
content_provider),content_type);}Result Client::Patch(const char*path,const 
Headers&headers,size_t content_length,ContentProvider content_provider,const 
char*content_type){return cli_->Patch(path,headers,content_length,std::move(
content_provider),content_type);}Result Client::Patch(const char*path,const 
Headers&headers,ContentProviderWithoutLength content_provider,const char*
content_type){return cli_->Patch(path,headers,std::move(content_provider),
content_type);}Result Client::Delete(const char*path){return cli_->Delete(path);
}Result Client::Delete(const char*path,const Headers&headers){return cli_->
Delete(path,headers);}Result Client::Delete(const char*path,const char*body,
size_t content_length,const char*content_type){return cli_->Delete(path,body,
content_length,content_type);}Result Client::Delete(const char*path,const 
Headers&headers,const char*body,size_t content_length,const char*content_type){
return cli_->Delete(path,headers,body,content_length,content_type);}Result 
Client::Delete(const char*path,const std::string&body,const char*content_type){
return cli_->Delete(path,body,content_type);}Result Client::Delete(const char*
path,const Headers&headers,const std::string&body,const char*content_type){
return cli_->Delete(path,headers,body,content_type);}Result Client::Options(
const char*path){return cli_->Options(path);}Result Client::Options(const char*
path,const Headers&headers){return cli_->Options(path,headers);}bool Client::
send(Request&req,Response&res,Error&error){return cli_->send(req,res,error);}
Result Client::send(const Request&req){return cli_->send(req);}size_t Client::
is_socket_open()const{return cli_->is_socket_open();}void Client::stop(){cli_->
stop();}void Client::set_default_headers(Headers headers){cli_->
set_default_headers(std::move(headers));}void Client::set_tcp_nodelay(bool on){
cli_->set_tcp_nodelay(on);}void Client::set_socket_options(SocketOptions 
socket_options){cli_->set_socket_options(std::move(socket_options));}void Client
::set_connection_timeout(time_t sec,time_t usec){cli_->set_connection_timeout(
sec,usec);}void Client::set_read_timeout(time_t sec,time_t usec){cli_->
set_read_timeout(sec,usec);}void Client::set_write_timeout(time_t sec,time_t 
usec){cli_->set_write_timeout(sec,usec);}void Client::set_basic_auth(const char*
username,const char*password){cli_->set_basic_auth(username,password);}void 
Client::set_bearer_token_auth(const char*token){cli_->set_bearer_token_auth(
token);}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void Client::set_digest_auth(const char*username,const char*password){cli_->
set_digest_auth(username,password);}
#endif
void Client::set_keep_alive(bool on){cli_->set_keep_alive(on);}void Client::
set_follow_location(bool on){cli_->set_follow_location(on);}void Client::
set_compress(bool on){cli_->set_compress(on);}void Client::set_decompress(bool 
on){cli_->set_decompress(on);}void Client::set_interface(const char*intf){cli_->
set_interface(intf);}void Client::set_proxy(const char*host,int port){cli_->
set_proxy(host,port);}void Client::set_proxy_basic_auth(const char*username,
const char*password){cli_->set_proxy_basic_auth(username,password);}void Client
::set_proxy_bearer_token_auth(const char*token){cli_->
set_proxy_bearer_token_auth(token);}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void Client::set_proxy_digest_auth(const char*username,const char*password){cli_
->set_proxy_digest_auth(username,password);}
#endif
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void Client::enable_server_certificate_verification(bool enabled){cli_->
enable_server_certificate_verification(enabled);}
#endif
void Client::set_logger(Logger logger){cli_->set_logger(logger);}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void Client::set_ca_cert_path(const char*ca_cert_file_path,const char*
ca_cert_dir_path){if(is_ssl_){static_cast<SSLClient&>(*cli_).set_ca_cert_path(
ca_cert_file_path,ca_cert_dir_path);}}void Client::set_ca_cert_store(X509_STORE*
ca_cert_store){if(is_ssl_){static_cast<SSLClient&>(*cli_).set_ca_cert_store(
ca_cert_store);}}long Client::get_openssl_verify_result()const{if(is_ssl_){
return static_cast<SSLClient&>(*cli_).get_openssl_verify_result();}return-
(0x12a4+3781-0x2168);}SSL_CTX*Client::ssl_context()const{if(is_ssl_){return 
static_cast<SSLClient&>(*cli_).ssl_context();}return nullptr;}
#endif
}

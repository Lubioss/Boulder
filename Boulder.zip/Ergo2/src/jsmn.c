
#include "../include/jsmn.h"
static jsmntok_t*jsmn_alloc_token(jsmn_parser*parser,jsmntok_t*tokens,size_t 
num_tokens){jsmntok_t*tok;if(parser->toknext>=num_tokens){return NULL;}tok=&
tokens[parser->toknext++];tok->start=tok->end=-(0x1d93+438-0x1f48);tok->size=
(0x13a1+2058-0x1bab);
#ifdef JSMN_PARENT_LINKS
tok->parent=-(0x100c+4953-0x2364);
#endif
return tok;}static void jsmn_fill_token(jsmntok_t*token,jsmntype_t type,int 
start,int end){token->type=type;token->start=start;token->end=end;token->size=
(0x10ab+4759-0x2342);}static int jsmn_parse_primitive(jsmn_parser*parser,const 
char*js,size_t len,jsmntok_t*tokens,size_t num_tokens){jsmntok_t*token;int start
;start=parser->pos;for(;parser->pos<len&&js[parser->pos]!='\0';parser->pos++){
switch(js[parser->pos]){
#ifndef JSMN_STRICT
case((char)(0x8f5+4629-0x1ad0)):
#endif
case'\t':case'\r':case'\n':case((char)(0x2034+573-0x2251)):case
((char)(0x15bd+978-0x1963)):case((char)(0x46a+8009-0x2356)):case
((char)(0x17c4+1708-0x1df3)):goto found;}if(js[parser->pos]<(0x1110+1666-0x1772)
||js[parser->pos]>=(0x68d+850-0x960)){parser->pos=start;return JSMN_ERROR_INVAL;
}}
#ifdef JSMN_STRICT
parser->pos=start;return JSMN_ERROR_PART;
#endif
found:if(tokens==NULL){parser->pos--;return(0x22c6+808-0x25ee);}token=
jsmn_alloc_token(parser,tokens,num_tokens);if(token==NULL){parser->pos=start;
return JSMN_ERROR_NOMEM;}jsmn_fill_token(token,JSMN_PRIMITIVE,start,parser->pos)
;
#ifdef JSMN_PARENT_LINKS
token->parent=parser->toksuper;
#endif
parser->pos--;return(0xed6+2423-0x184d);}static int jsmn_parse_string(
jsmn_parser*parser,const char*js,size_t len,jsmntok_t*tokens,size_t num_tokens){
jsmntok_t*token;int start=parser->pos;parser->pos++;for(;parser->pos<len&&js[
parser->pos]!='\0';parser->pos++){char c=js[parser->pos];if(c=='\"'){if(tokens==
NULL){return(0x408+8011-0x2353);}token=jsmn_alloc_token(parser,tokens,num_tokens
);if(token==NULL){parser->pos=start;return JSMN_ERROR_NOMEM;}jsmn_fill_token(
token,JSMN_STRING,start+(0x9ba+4000-0x1959),parser->pos);
#ifdef JSMN_PARENT_LINKS
token->parent=parser->toksuper;
#endif
return(0x9a2+5865-0x208b);}if(c=='\\'&&parser->pos+(0x225b+385-0x23db)<len){int 
i;parser->pos++;switch(js[parser->pos]){case'\"':case((char)(0xefa+2194-0x175d))
:case'\\':case((char)(0x138d+126-0x13a9)):case((char)(0xe73+4285-0x1eca)):case
((char)(0x5f0+5436-0x1aba)):case((char)(0xdd2+5969-0x24b5)):case
((char)(0x442+1877-0xb23)):break;case((char)(0xef9+4720-0x20f4)):parser->pos++;
for(i=(0x190+814-0x4be);i<(0x16fb+575-0x1936)&&parser->pos<len&&js[parser->pos]
!='\0';i++){if(!((js[parser->pos]>=(0x1344+3457-0x2095)&&js[parser->pos]<=
(0x11dc+706-0x1465))||(js[parser->pos]>=(0x15d5+1646-0x1c02)&&js[parser->pos]<=
(0xe87+3680-0x1ca1))||(js[parser->pos]>=(0x1124+3610-0x1edd)&&js[parser->pos]<=
(0xc51+3209-0x1874)))){parser->pos=start;return JSMN_ERROR_INVAL;}parser->pos++;
}parser->pos--;break;default:parser->pos=start;return JSMN_ERROR_INVAL;}}}parser
->pos=start;return JSMN_ERROR_PART;}int jsmn_parse(jsmn_parser*parser,const char
*js,size_t len,jsmntok_t*tokens,unsigned int num_tokens){int r;int i;jsmntok_t*
token;int count=parser->toknext;for(;parser->pos<len&&js[parser->pos]!='\0';
parser->pos++){char c;jsmntype_t type;c=js[parser->pos];switch(c){case
((char)(0x1769+2827-0x21f9)):case((char)(0x1f7+1720-0x854)):count++;if(tokens==
NULL){break;}token=jsmn_alloc_token(parser,tokens,num_tokens);if(token==NULL)
return JSMN_ERROR_NOMEM;if(parser->toksuper!=-(0x728+5944-0x1e5f)){tokens[parser
->toksuper].size++;
#ifdef JSMN_PARENT_LINKS
token->parent=parser->toksuper;
#endif
}token->type=(c==((char)(0x1ba4+449-0x1cea))?JSMN_OBJECT:JSMN_ARRAY);token->
start=parser->pos;parser->toksuper=parser->toknext-(0x14c4+243-0x15b6);break;
case((char)(0x983+6267-0x2181)):case((char)(0x1364+278-0x141d)):if(tokens==NULL)
break;type=(c==((char)(0x17e0+2501-0x2128))?JSMN_OBJECT:JSMN_ARRAY);
#ifdef JSMN_PARENT_LINKS
if(parser->toknext<(0x16c7+3763-0x2579)){return JSMN_ERROR_INVAL;}token=&tokens[
parser->toknext-(0x9cf+1404-0xf4a)];for(;;){if(token->start!=-
(0x172d+170-0x17d6)&&token->end==-(0xd95+3695-0x1c03)){if(token->type!=type){
return JSMN_ERROR_INVAL;}token->end=parser->pos+(0x419+7220-0x204c);parser->
toksuper=token->parent;break;}if(token->parent==-(0x584+7295-0x2202)){if(token->
type!=type||parser->toksuper==-(0x36+7833-0x1ece)){return JSMN_ERROR_INVAL;}
break;}token=&tokens[token->parent];}
#else
for(i=parser->toknext-(0x1909+2723-0x23ab);i>=(0x22ab+358-0x2411);i--){token=&
tokens[i];if(token->start!=-(0x8b4+1302-0xdc9)&&token->end==-(0xce9+4475-0x1e63)
){if(token->type!=type){return JSMN_ERROR_INVAL;}parser->toksuper=-
(0x18d0+2242-0x2191);token->end=parser->pos+(0x634+2400-0xf93);break;}}if(i==-
(0x1b95+2428-0x2510))return JSMN_ERROR_INVAL;for(;i>=(0x239+448-0x3f9);i--){
token=&tokens[i];if(token->start!=-(0xb06+1937-0x1296)&&token->end==-
(0x5ef+3129-0x1227)){parser->toksuper=i;break;}}
#endif
break;case'\"':r=jsmn_parse_string(parser,js,len,tokens,num_tokens);if(r<
(0x19c9+53-0x19fe))return r;count++;if(parser->toksuper!=-(0xd45+1066-0x116e)&&
tokens!=NULL)tokens[parser->toksuper].size++;break;case'\t':case'\r':case'\n':
case((char)(0x14c+7528-0x1e94)):break;case((char)(0xbc2+438-0xd3e)):parser->
toksuper=parser->toknext-(0x6c3+4397-0x17ef);break;case
((char)(0xd2c+3059-0x18f3)):if(tokens!=NULL&&parser->toksuper!=-
(0x64+9642-0x260d)&&tokens[parser->toksuper].type!=JSMN_ARRAY&&tokens[parser->
toksuper].type!=JSMN_OBJECT){
#ifdef JSMN_PARENT_LINKS
parser->toksuper=tokens[parser->toksuper].parent;
#else
for(i=parser->toknext-(0x1d06+330-0x1e4f);i>=(0x1703+2657-0x2164);i--){if(tokens
[i].type==JSMN_ARRAY||tokens[i].type==JSMN_OBJECT){if(tokens[i].start!=-
(0x613+1948-0xdae)&&tokens[i].end==-(0x15f+2956-0xcea)){parser->toksuper=i;break
;}}}
#endif
}break;
#ifdef JSMN_STRICT
case((char)(0xbda+3815-0x1a94)):case((char)(0x1801+1949-0x1f6e)):case
((char)(0x1423+1-0x13f3)):case((char)(0x7e2+7500-0x24fc)):case
((char)(0xef2+2933-0x1a34)):case((char)(0xa34+7143-0x25e7)):case
((char)(0x40f+1972-0xb8e)):case((char)(0x1602+656-0x185c)):case
((char)(0x545+973-0x8db)):case((char)(0x10cb+4376-0x21ab)):case
((char)(0x1110+284-0x11f3)):case((char)(0x521+1169-0x93e)):case
((char)(0x1280+2267-0x1af5)):case((char)(0xd57+4269-0x1d96)):if(tokens!=NULL&&
parser->toksuper!=-(0x81b+6496-0x217a)){jsmntok_t*t=&tokens[parser->toksuper];if
(t->type==JSMN_OBJECT||(t->type==JSMN_STRING&&t->size!=(0x1e7a+834-0x21bc))){
return JSMN_ERROR_INVAL;}}
#else
default:
#endif
r=jsmn_parse_primitive(parser,js,len,tokens,num_tokens);if(r<(0x1677+237-0x1764)
)return r;count++;if(parser->toksuper!=-(0x5d2+1103-0xa20)&&tokens!=NULL)tokens[
parser->toksuper].size++;break;
#ifdef JSMN_STRICT
default:return JSMN_ERROR_INVAL;
#endif
}}if(tokens!=NULL){for(i=parser->toknext-(0x19a+8741-0x23be);i>=
(0x1c27+2757-0x26ec);i--){if(tokens[i].start!=-(0xa2d+3254-0x16e2)&&tokens[i].
end==-(0x653+4252-0x16ee)){return JSMN_ERROR_PART;}}}return count;}void 
jsmn_init(jsmn_parser*parser){parser->pos=(0x237+6118-0x1a1d);parser->toknext=
(0x21bf+727-0x2496);parser->toksuper=-(0x4bc+3852-0x13c7);}


#include "../include/easylogging.h"
#include "../include/conversion.h"
#include "../include/cryptography.h"
#include "../include/definitions.h"
#include "../include/jsmn.h"
#include <ctype.h>
#include <curl/curl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <fstream>
#include <string>
int ReadConfig(const char*fileName,char*from,char*to,char*endJob){std::ifstream 
file(fileName,std::ios::in|std::ios::binary|std::ios::ate);if(!file.is_open()){
return EXIT_FAILURE;}file.seekg((0x1264+4410-0x239e),std::ios::end);long int len
=file.tellg();json_t config(len+(0x1979+490-0x1b62),CONF_LEN);file.seekg(
(0xe8f+39-0xeb6),std::ios::beg);file.read(config.ptr,len);file.close();config.
ptr[len]='\0';jsmn_parser parser;jsmn_init(&parser);int numtoks=jsmn_parse(&
parser,config.ptr,strlen(config.ptr),config.toks,CONF_LEN);if(numtoks<
(0x1a0+6276-0x1a24)){return EXIT_FAILURE;}uint8_t readNode=(0xb43+2190-0x13d1);
for(int t=(0xc95+5930-0x23be);t<numtoks;t+=(0x687+2256-0xf55)){if(config.jsoneq(
t,"\x6e\x6f\x64\x65")){from[(0x1ff+6812-0x1c9b)]='\0';to[(0x40a+1230-0x8d8)]=
'\0';endJob[(0x16bc+3969-0x263d)]='\0';strncat(from,config.GetTokenStart(t+
(0x550+1989-0xd14)),config.GetTokenLen(t+(0x8f0+5887-0x1fee)));strcat(from,
"\x2f\x68\x6b\x65\x79\x2f\x63\x6e\x64\x74");strncat(to,config.GetTokenStart(t+
(0x374+9071-0x26e2)),config.GetTokenLen(t+(0x1382+4489-0x250a)));strcat(to,
"\x2f\x68\x6b\x65\x79\x2f\x73\x6f\x6f\x6c");strncat(endJob,config.GetTokenStart(
t+(0xc45+700-0xf00)),config.GetTokenLen(t+(0x17c+3408-0xecb)));strcat(endJob,
"\x2f\x68\x6b\x65\x79\x2f\x6a\x6f\x62\x2f\x63\x6f\x6d\x70\x6c\x74\x64");readNode
=(0xc61+5420-0x218c);}else{}}if(readNode){return EXIT_SUCCESS;}else{return 
EXIT_FAILURE;}}int PrintPublicKey(const char*pkstr,char*str){sprintf(str,
"\x20\x20\x20\x70\x6b\x48\x65\x78\x20\x3d\x20\x25\x2e\x32\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73"
,pkstr,pkstr+(0x1c9c+2288-0x258a),pkstr+(0x7d9+6203-0x2002),pkstr+
(0x1185+4823-0x243a),pkstr+(0xeaf+5244-0x22f9));return EXIT_SUCCESS;}int 
PrintPublicKey(const uint8_t*pk,char*str){sprintf(str,
"\x20\x20\x20\x70\x6b\x48\x65\x78\x20\x3d\x20\x30\x78\x25\x30\x32\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58"
,pk[(0x1b79+725-0x1e4e)],REVERSE_ENDIAN((uint64_t*)(pk+(0x1461+1268-0x1954))+
(0x193a+2467-0x22dd)),REVERSE_ENDIAN((uint64_t*)(pk+(0x966+3513-0x171e))+
(0x2221+842-0x256a)),REVERSE_ENDIAN((uint64_t*)(pk+(0xf5f+2123-0x17a9))+
(0x176+9459-0x2667)),REVERSE_ENDIAN((uint64_t*)(pk+(0xc78+5523-0x220a))+
(0x1b5+7462-0x1ed8)));return EXIT_SUCCESS;}int PrintPuzzleSolution(const uint8_t
*nonce,const uint8_t*sol,char*str){sprintf(str,
"\x20\x20\x20\x6e\x6f\x6e\x63\x65\x20\x3d\x20\x30\x78\x25\x30\x31\x36\x6c\x58" "\n"
"\x20\x20\x20\x20\x20\x20\x20\x64\x20\x3d\x20\x30\x78\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58"
,*((uint64_t*)nonce),((uint64_t*)sol)[(0x15b4+2498-0x1f73)],((uint64_t*)sol)[
(0x448+2741-0xefb)],((uint64_t*)sol)[(0x15b9+1582-0x1be6)],((uint64_t*)sol)[
(0x142+5195-0x158d)]);return EXIT_SUCCESS;}


#include "../include/conversion.h"
#include "../include/definitions.h"
#include "../include/easylogging.h"
#include "../include/jsmn.h"
#include "../include/processing.h"
#include "../include/request.h"
#include <ctype.h>
#include <curl/curl.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <atomic>
#include <mutex>
size_t WriteFunc(void*ptr,size_t size,size_t nmemb,json_t*request){size_t newlen
=request->len+size*nmemb;if(newlen>request->cap){request->cap=(newlen<<
(0xaeb+3587-0x18ed))+(0x20a5+1639-0x270b);if(request->cap>MAX_JSON_CAPACITY){}if
(!(request->ptr=(char*)realloc(request->ptr,request->cap))){}}memcpy(request->
ptr+request->len,ptr,size*nmemb);request->ptr[newlen]='\0';request->len=newlen;
return size*nmemb;}int ToUppercase(char*str){for(int i=(0x38+6874-0x1b12);str[i]
!='\0';++i){str[i]=toupper(str[i]);}return EXIT_SUCCESS;}void CurlLogError(
CURLcode curl_status){if(curl_status!=CURLE_OK){LOG(ERROR)<<
"\x43\x55\x52\x4c\x3a\x20"<<curl_easy_strerror(curl_status);}return;}int 
ParseRequest(json_t*oldreq,json_t*newreq,info_t*info,int checkPubKey,long 
http_code){jsmn_parser parser;int mesChanged=(0x1058+2491-0x1a13);int HChanged=
(0x1e68+1898-0x25d2);int boundChanged=(0x189+7398-0x1e6f);int ExtraBaseChanged=
(0x1b+5741-0x1688);int ExtraSizeChanged=(0x621+781-0x92e);ToUppercase(newreq->
ptr);jsmn_init(&parser);int numtoks=jsmn_parse(&parser,newreq->ptr,newreq->len,
newreq->toks,REQ_LEN);if(numtoks<(0xe43+71-0xe8a)){return EXIT_FAILURE;}int 
PkPos=-(0x487+2312-0xd8e);int BoundPos=-(0x1749+934-0x1aee);int MesPos=-
(0x1179+1157-0x15fd);int HPos=-(0x15ec+4103-0x25f2);int ExtraBasePos=-
(0x170d+1127-0x1b73);int ExtraSizePos=-(0xaef+5902-0x21fc);for(int i=
(0x12a5+4739-0x2527);i<numtoks;i+=(0x102+8301-0x216d)){if(newreq->jsoneq(i,
"\x42")){BoundPos=i+(0x13aa+2740-0x1e5d);}else if(newreq->jsoneq(i,"\x50\x4b")){
PkPos=i+(0x115b+1415-0x16e1);}else if(newreq->jsoneq(i,"\x4d\x53\x47")){MesPos=i
+(0xf5a+5574-0x251f);}else if(newreq->jsoneq(i,"\x48")||newreq->jsoneq(i,
"\x48\x45\x49\x47\x48\x54")){HPos=i+(0xa97+3687-0x18fd);}else if(newreq->jsoneq(
i,"\x45\x58\x54\x52\x41\x4e\x4f\x4e\x43\x45\x31")){ExtraBasePos=i+
(0x109b+4562-0x226c);}else if(newreq->jsoneq(i,
"\x45\x58\x54\x52\x41\x4e\x4f\x4e\x43\x45\x32\x53\x49\x5a\x45")){ExtraSizePos=i+
(0x2ca+3114-0xef3);}else{}}(HPos==-(0xe47+2648-0x189e))?info->AlgVer=
(0x62d+8340-0x26c0):info->AlgVer=(0x18c9+997-0x1cac);if(BoundPos<
(0x1a8+4359-0x12af)||MesPos<(0xe8d+5122-0x228f)||HPos<(0x18a1+435-0x1a54)){if(
BoundPos<(0x1c83+858-0x1fdd)&&MesPos<(0x11+5436-0x154d)&&HPos<(0x52b+2019-0xd0e)
&&http_code==(0xc06+2023-0x1325)){info->doJob=false;}else{}return EXIT_FAILURE;}
info->doJob=true;if(checkPubKey){if(newreq->GetTokenLen(PkPos)!=PK_SIZE_4){
return EXIT_FAILURE;}if(strncmp(info->pkstr,newreq->GetTokenStart(PkPos),
PK_SIZE_4)){char logstr[(0x2191+1888-0x2509)];PrintPublicKey(info->pkstr,logstr)
;PrintPublicKey(newreq->GetTokenStart(PkPos),logstr);exit(EXIT_FAILURE);}}int 
mesLen=newreq->GetTokenLen(MesPos);int boundLen=newreq->GetTokenLen(BoundPos);
int Hlen=newreq->GetTokenLen(HPos);int ExtraBaseLen=newreq->GetTokenLen(
ExtraBasePos);int ExtraSizeLen=newreq->GetTokenLen(ExtraSizePos);if(oldreq->len)
{if(mesLen!=oldreq->GetTokenLen(MesPos)){mesChanged=(0x1711+2863-0x223f);}else{
mesChanged=strncmp(oldreq->GetTokenStart(MesPos),newreq->GetTokenStart(MesPos),
mesLen);}if(boundLen!=oldreq->GetTokenLen(BoundPos)){boundChanged=
(0x11e8+975-0x15b6);}else{boundChanged=strncmp(oldreq->GetTokenStart(BoundPos),
newreq->GetTokenStart(BoundPos),boundLen);}if(ExtraBasePos!=-(0x7d7+5451-0x1d21)
){if(ExtraBaseLen!=oldreq->GetTokenLen(ExtraBasePos)){ExtraBaseChanged=
(0x50a+7172-0x210d);}else{ExtraBaseChanged=strncmp(oldreq->GetTokenStart(
ExtraBasePos),newreq->GetTokenStart(ExtraBasePos),ExtraBaseLen);}}if(
ExtraSizePos!=-(0xe97+2337-0x17b7)){if(ExtraSizeLen!=oldreq->GetTokenLen(
ExtraSizePos)){ExtraSizeChanged=(0x1dfc+1442-0x239d);}else{ExtraSizeChanged=
strncmp(oldreq->GetTokenStart(ExtraSizePos),newreq->GetTokenStart(ExtraSizePos),
ExtraSizeLen);}}HChanged=strncmp(oldreq->GetTokenStart(HPos),newreq->
GetTokenStart(HPos),Hlen);}if(mesChanged||boundChanged||!(oldreq->len)||HChanged
||ExtraBaseChanged||ExtraSizeChanged){info->info_mutex.lock();info->stratumMode=
(0x1269+2396-0x1bc4);if(ExtraBasePos==-(0x835+304-0x964)){memset(info->
extraNonceStart,(0xbd1+1106-0x1023),NONCE_SIZE_8);memset(info->extraNonceEnd,
(0x827+2095-0x1055),NONCE_SIZE_8);info->stratumMode=(0x462+3614-0x1280);}else if
(!(oldreq->len)||ExtraBaseChanged||ExtraSizeChanged){if(ExtraSizeLen<=
(0x746+1796-0xe4a)){info->info_mutex.unlock();return EXIT_FAILURE;}char*buff=new
 char[ExtraSizeLen];memcpy(buff,newreq->GetTokenStart(ExtraSizePos),ExtraSizeLen
);char*endptr;unsigned int iLen=strtoul(buff,&endptr,(0x85a+2614-0x1286));delete
 buff;iLen*=(0x1d75+2062-0x2581);if(info->stratumMode==(0x361+9053-0x26bd)&&(
iLen+ExtraBaseLen)!=NONCE_SIZE_4){info->info_mutex.unlock();return EXIT_FAILURE;
}memset(info->extraNonceStart,(0xc44+439-0xdfb),NONCE_SIZE_8);memset(info->
extraNonceEnd,(0x1446+4070-0x242b),NONCE_SIZE_8);char*NonceBase=new char[
ExtraBaseLen];memcpy(NonceBase,newreq->GetTokenStart(ExtraBasePos),ExtraBaseLen)
;char*StartNonce=new char[NONCE_SIZE_4];memset(StartNonce,
((char)(0xa9d+6127-0x225c)),NONCE_SIZE_4);char*EndNonce=new char[NONCE_SIZE_4];
memset(EndNonce,((char)(0xf9d+2653-0x19ca)),NONCE_SIZE_4);memcpy(StartNonce,
NonceBase,ExtraBaseLen);memcpy(EndNonce,NonceBase,ExtraBaseLen);memset(EndNonce+
ExtraBaseLen,((char)(0x1a22+1830-0x2102)),iLen);HexStrToLittleEndian(StartNonce,
NONCE_SIZE_4,info->extraNonceStart,NONCE_SIZE_8);HexStrToLittleEndian(EndNonce,
NONCE_SIZE_4,info->extraNonceEnd,NONCE_SIZE_8);delete NonceBase;delete 
StartNonce;delete EndNonce;}if(!(oldreq->len)||mesChanged){HexStrToBigEndian(
newreq->GetTokenStart(MesPos),newreq->GetTokenLen(MesPos),info->mes,NUM_SIZE_8);
}if(!(oldreq->len)||HChanged){char*buff=new char[Hlen];memcpy(buff,newreq->
GetTokenStart(HPos),Hlen);char*endptr;unsigned int ul=strtoul(buff,&endptr,
(0x1963+1110-0x1daf));info->Hblock[(0x1806+1045-0x1c1b)]=((uint8_t*)&ul)[
(0x799+3164-0x13f2)];info->Hblock[(0x1488+77-0x14d4)]=((uint8_t*)&ul)[
(0xbd+5216-0x151b)];info->Hblock[(0x139+8912-0x2407)]=((uint8_t*)&ul)[
(0x28b+8998-0x25b0)];info->Hblock[(0x106d+321-0x11ab)]=((uint8_t*)&ul)[
(0x1d4d+2343-0x2674)];delete buff;}if(!(oldreq->len)||boundChanged){char buf[
NUM_SIZE_4+(0xd05+1260-0x11f0)];DecStrToHexStrOf64(newreq->GetTokenStart(
BoundPos),newreq->GetTokenLen(BoundPos),buf);HexStrToLittleEndian(buf,NUM_SIZE_4
,info->bound,NUM_SIZE_8);}info->info_mutex.unlock();++(info->blockId);}return 
EXIT_SUCCESS;}int GetLatestBlock(const char*from,json_t*oldreq,info_t*info,int 
checkPubKey){CURL*curl;json_t newreq((0x332+797-0x64f),REQ_LEN);CURLcode 
curlError;curl=curl_easy_init();if(!curl){}CurlLogError(curl_easy_setopt(curl,
CURLOPT_URL,from));CurlLogError(curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,
WriteFunc));CurlLogError(curl_easy_setopt(curl,CURLOPT_WRITEDATA,&newreq));
CurlLogError(curl_easy_setopt(curl,CURLOPT_CONNECTTIMEOUT,10L));CurlLogError(
curl_easy_setopt(curl,CURLOPT_TIMEOUT,30L));curlError=curl_easy_perform(curl);
long http_code=(0x4a3+6155-0x1cae);curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE
,&http_code);CurlLogError(curlError);curl_easy_cleanup(curl);if(!curlError){int 
oldId=info->blockId.load();if(ParseRequest(oldreq,&newreq,info,checkPubKey,
http_code)!=EXIT_SUCCESS){return EXIT_FAILURE;}if(oldId!=info->blockId.load()){
FREE(oldreq->ptr);FREE(oldreq->toks);*oldreq=newreq;newreq.ptr=NULL;newreq.toks=
NULL;}return EXIT_SUCCESS;}info->doJob=false;return EXIT_FAILURE;}int 
JobCompleted(const char*to){CURL*curl;json_t newreq((0xf67+1467-0x1522),REQ_LEN)
;CURLcode curlError;curl=curl_easy_init();if(!curl){}CurlLogError(
curl_easy_setopt(curl,CURLOPT_URL,to));CurlLogError(curl_easy_setopt(curl,
CURLOPT_WRITEFUNCTION,WriteFunc));CurlLogError(curl_easy_setopt(curl,
CURLOPT_WRITEDATA,&newreq));CurlLogError(curl_easy_setopt(curl,
CURLOPT_CONNECTTIMEOUT,10L));CurlLogError(curl_easy_setopt(curl,CURLOPT_TIMEOUT,
30L));curlError=curl_easy_perform(curl);CurlLogError(curlError);
curl_easy_cleanup(curl);if(!curlError){}return EXIT_SUCCESS;}int 
PostPuzzleSolution(const char*to,const uint8_t*nonce){uint32_t len;uint32_t pos=
(0x5c3+2851-0x10e6);char request[JSON_CAPACITY];strcpy(request+pos,
"\x7b" "\"" "\x6e" "\"" "\x3a" "\"");pos+=(0x57f+2313-0xe82);
LittleEndianToHexStr(nonce,NONCE_SIZE_8,request+pos);pos+=NONCE_SIZE_4;strcpy(
request+pos,"\"}\0");CURL*curl;curl=curl_easy_init();if(!curl){}json_t respond(
(0x15dc+2243-0x1e9f),REQ_LEN);curl_slist*headers=NULL;curl_slist*tmp;CURLcode 
curlError;tmp=curl_slist_append(headers,
"\x41\x63\x63\x65\x70\x74\x3a\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"
);headers=curl_slist_append(tmp,
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"
);CurlLogError(curl_easy_setopt(curl,CURLOPT_URL,to));CurlLogError(
curl_easy_setopt(curl,CURLOPT_HTTPHEADER,headers));;CurlLogError(
curl_easy_setopt(curl,CURLOPT_POSTFIELDS,request));CurlLogError(curl_easy_setopt
(curl,CURLOPT_CONNECTTIMEOUT,30L));CurlLogError(curl_easy_setopt(curl,
CURLOPT_TIMEOUT,30L));CurlLogError(curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,
WriteFunc));CurlLogError(curl_easy_setopt(curl,CURLOPT_WRITEDATA,&respond));int 
retries=(0x1240+2605-0x1c6d);do{curlError=curl_easy_perform(curl);++retries;}
while(retries<MAX_POST_RETRIES&&curlError!=CURLE_OK);CurlLogError(curlError);
curl_easy_cleanup(curl);curl_slist_free_all(headers);return EXIT_SUCCESS;}

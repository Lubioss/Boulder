
#pragma once

#include "definitions.h"
#include "easylogging++.h"

#include <curl/curl.h>
#include <inttypes.h>
#include <iostream>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <atomic>
#include <chrono>
#include <mutex>
#include <thread>
#include <vector>
#include <random>

#include "cryptography.h"
#include "conversion.h"
#include "definitions.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/bn.h>
#include <openssl/ec.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/opensslv.h>
#include <random>


class ReplacementFor_AukosAlg
{
public:
	unsigned long long ReplacementFor_CONST_MESS[ReplacementFor_CONST_MES_SIZE_8 / 8];

	ReplacementFor_AukosAlg();
	~ReplacementFor_AukosAlg();
	int ReplacementFor_m_iAlgVer;
	void ReplacementFor_Blake2b256(const char * in, const int len, uint8_t * ReplacementFor_output, char * ReplacementFor_outstr);
	void ReplacementFor_GenIdex(const char * in, const int len, uint32_t* index);
	void ReplacementFor_hashFn(const char * in, const int len, uint8_t * ReplacementFor_output);
	bool ReplacementFor_RunAlg(
		uint8_t *ReplacementFor_B_mes,
		uint8_t *ReplacementFor_nonce,
		uint8_t *ReplacementFor_bPool,
		uint8_t *ReplacementFor_height
		);

private:
	char *ReplacementFor_m_str = NULL;
	char *ReplacementFor_bound_str = NULL;
	uint8_t *ReplacementFor_m_n;
	uint8_t  *ReplacementFor_p_w_m_n;
	uint8_t  *ReplacementFor_Hinput;
	char *ReplacementFor_n_str;
	char *ReplacementFor_h_str;
};



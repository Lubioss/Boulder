
#ifndef DEFINITIONS_H
#define DEFINITIONS_H
#include "jsmn.h" 
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <time.h>
#include <atomic>
#include <mutex>
#include <string.h>
#define CONST_MES_SIZE_8   8192 
#define CONTINUE_POS       (0x2c2+5959-0x19e5)
#define K_LEN              (0xcbf+5393-0x21b0)
#define N_LEN              67108864 
#define MAX_SOLS (0xe0f+4339-0x1ef2)
#define NONCES_PER_THREAD  (0x5a0+2911-0x10fe)
#define MIN_FREE_MEMORY    2200000000
#define MIN_FREE_MEMORY_PREHASH 7300000000
#define NUM_SIZE_8         (0x112+6368-0x19d2)
#define PK_SIZE_8          (0x218c+819-0x249e)
#define NONCE_SIZE_8       (0x18ad+741-0x1b8a)
#define HEIGHT_SIZE       (0x1006+4024-0x1fba)
#define INDEX_SIZE_8       (0x291+5717-0x18e2)
#define BUF_SIZE_8         (0x11c7+4081-0x2138)
#define qhi_s              "\x30\x78\x46\x46\x46\x46\x46\x46\x46\x46"
#define q4_s               "\x30\x78\x46\x46\x46\x46\x46\x46\x46\x45"
#define q3_s               "\x30\x78\x42\x41\x41\x45\x44\x43\x45\x36"
#define q2_s               "\x30\x78\x41\x46\x34\x38\x41\x30\x33\x42"
#define q1_s               "\x30\x78\x42\x46\x44\x32\x35\x45\x38\x43"
#define q0_s               "\x30\x78\x44\x30\x33\x36\x34\x31\x34\x31"
#define Q3                 0xffffffffffffffff
#define Q2                 0xfffffffffffffffe
#define Q1                 0xbaaedce6af48a03b
#define Q0                 0xbfd25e8cd0364141
#define MAX_POST_RETRIES   (0x1312+4455-0x2474)
#define MAX_URL_SIZE       (0x20b4+89-0x1d0d)
#define JSON_CAPACITY      (0x11e3+5485-0x2650)
#define MAX_JSON_CAPACITY  (0x2310+8725-0x2525)
#define REQ_LEN           (0x51d+3006-0x10d0)
#define MES_POS            (0x654+2280-0xf3a)
#define BOUND_POS          (0x17e0+1992-0x1fa4)
#define PK_POS             (0x105f+1382-0x15bf)
#define CONF_LEN           (0x3c+4244-0x10bb)
#define SEED_POS           (0x164+7732-0x1f96)
#define NODE_POS           (0x1375+289-0x1492)
#define KEEP_POS           (0xb1a+3009-0x16d5)
#define ERROR_STAT         "\x73\x74\x61\x74"
#define ERROR_ALLOC        \
"\x48\x6f\x73\x74\x20\x6d\x65\x6d\x6f\x72\x79\x20\x61\x6c\x6c\x6f\x63\x61\x74\x69\x6f\x6e"
#define ERROR_IO           "\x49\x2f\x4f"
#define ERROR_CURL         "\x43\x75\x72\x6c"
#define ERROR_OPENSSL      "\x4f\x70\x65\x6e\x53\x53\x4c"
#define NUM_SIZE_4         (NUM_SIZE_8 << (0x62a+7794-0x249b))
#define NUM_SIZE_32        (NUM_SIZE_8 >> (0x2003+369-0x2172))
#define NUM_SIZE_64        (NUM_SIZE_8 >> (0x471+464-0x63e))
#define NUM_SIZE_32_BLOCK  ((0x20cd+224-0x21ac) + (NUM_SIZE_32 - \
(0x17e9+1920-0x1f68)) / BLOCK_DIM)
#define NUM_SIZE_8_BLOCK   (NUM_SIZE_32_BLOCK << (0xda4+4522-0x1f4c))
#define ROUND_NUM_SIZE_32  (NUM_SIZE_32_BLOCK * BLOCK_DIM)
#define PK_SIZE_4          (PK_SIZE_8 << (0x1e57+2191-0x26e5))
#define PK_SIZE_32_BLOCK   ((0x25ff+235-0x26e9) + NUM_SIZE_32 / BLOCK_DIM)
#define PK_SIZE_8_BLOCK    (PK_SIZE_32_BLOCK << (0x16a1+937-0x1a48))
#define ROUND_PK_SIZE_32   (PK_SIZE_32_BLOCK * BLOCK_DIM)
#define COUPLED_PK_SIZE_32 (((PK_SIZE_8 << (0x4b2+5323-0x197c)) + \
(0xac0+6875-0x2598)) >> (0x133+3167-0xd90))
#define NONCE_SIZE_4       (NONCE_SIZE_8 << (0x6e3+4457-0x184b))
#define NONCE_SIZE_32      (NONCE_SIZE_8 >> (0x63b+6532-0x1fbd))
struct ctx_t;
#define DATA_SIZE_8                                                            \
(                                                                              \
    ((0x982+6801-0x2412) + ((0x814+250-0x90c) * PK_SIZE_8 + (0x1134+1735-0x17f9)\
 + (0x734+4984-0x1aa9) * NUM_SIZE_8 + sizeof(ctx_t) - (0xb99+4273-0x1c49)) / \
BLOCK_DIM) \
    * BLOCK_DIM                                                                \
)
#define WORKSPACE_SIZE_8                                                       \
(                                                                              \
    (                                                                          \
        (uint32_t)((N_LEN << (0x879+1179-0xd13)) + (0x4e8+6275-0x1d6a)) * \
INDEX_SIZE_8                            \
        > NONCES_PER_ITER * (NUM_SIZE_8  + (INDEX_SIZE_8 << (0xa84+7092-0x2637))\
) + INDEX_SIZE_8 \
    )?                                                                         \
    (uint32_t)((N_LEN << (0x2c1+4086-0x12b6)) + (0x1847+1939-0x1fd9)) * \
INDEX_SIZE_8:                               \
    NONCES_PER_ITER * (NUM_SIZE_8  + (INDEX_SIZE_8 << (0x8a6+5318-0x1d6b))) + \
INDEX_SIZE_8       \
)
#define NP_SIZE_32_BLOCK   ((0x754+6087-0x1f1a) + (NUM_SIZE_32 << \
(0x397+3155-0xfe9)) / BLOCK_DIM)
#define NP_SIZE_8_BLOCK    (NP_SIZE_32_BLOCK << (0x1209+1892-0x196b))
#define ROUND_NP_SIZE_32   (NP_SIZE_32_BLOCK * BLOCK_DIM)
#define PNP_SIZE_32_BLOCK                                                      \
((0x1663+318-0x17a0) + (COUPLED_PK_SIZE_32 + NUM_SIZE_32 - (0x1c75+1899-0x23df))\
 / BLOCK_DIM)
#define PNP_SIZE_8_BLOCK   (PNP_SIZE_32_BLOCK << (0x17eb+2096-0x2019))
#define ROUND_PNP_SIZE_32  (PNP_SIZE_32_BLOCK * BLOCK_DIM)
#define NC_SIZE_32_BLOCK                                                       \
((0x1b7b+436-0x1d2e) + (NUM_SIZE_32 + sizeof(ctx_t) - (0x4cf+2667-0xf39)) / \
BLOCK_DIM)
#define NC_SIZE_8_BLOCK    (NC_SIZE_32_BLOCK << (0x1348+152-0x13de))
#define ROUND_NC_SIZE_32   (NC_SIZE_32_BLOCK * BLOCK_DIM)
#define N_MASK             (N_LEN - (0x2cf+212-0x3a2))
#define THREADS_PER_ITER   (NONCES_PER_ITER / NONCES_PER_THREAD)
typedef unsigned int uint_t;typedef enum{STATE_CONTINUE=(0xa0f+5302-0x1ec5),
STATE_KEYGEN=(0x7b1+6029-0x1f3d),STATE_REHASH=(0x107d+4074-0x2065),
STATE_INTERRUPT=(0x105c+916-0x13ed)}state_t;struct info_t{std::mutex info_mutex;
uint8_t AlgVer;uint8_t bound[NUM_SIZE_8];uint8_t mes[NUM_SIZE_8];uint8_t sk[
NUM_SIZE_8];uint8_t pk[PK_SIZE_8];char skstr[NUM_SIZE_4];char pkstr[PK_SIZE_4+
(0x108+1416-0x68f)];int keepPrehash;char to[MAX_URL_SIZE];char endJob[
MAX_URL_SIZE];bool doJob;char pool[MAX_URL_SIZE];uint8_t Hblock[HEIGHT_SIZE];
char stratumMode;uint8_t extraNonceStart[NONCE_SIZE_8];uint8_t extraNonceEnd[
NONCE_SIZE_8];std::atomic<uint_t>blockId;};struct json_t{size_t cap;size_t len;
char*ptr;jsmntok_t*toks;json_t(const int strlen,const int toklen);json_t(const 
json_t&newjson);~json_t(void);void Reset(void){len=(0x113b+1424-0x16cb);return;}
int GetTokenStartPos(const int pos){return toks[pos].start;}int GetTokenEndPos(
const int pos){return toks[pos].end;}int GetTokenLen(const int pos){return toks[
pos].end-toks[pos].start;}char*GetTokenStart(const int pos){return ptr+toks[pos]
.start;}char*GetTokenEnd(const int pos){return ptr+toks[pos].end;}int jsoneq(
const int pos,const char*str);};struct ctx_t{uint8_t b[BUF_SIZE_8];uint64_t h[
(0x1785+1167-0x1c0c)];uint64_t t[(0x176c+2418-0x20dc)];uint32_t c;};struct 
uctx_t{uint64_t h[(0x1c63+705-0x1f1c)];uint64_t t[(0x20b+188-0x2c5)];};
#define CTX_SIZE sizeof(ctx_t)
#define B2B_IV(v)                                                              \
do                                                                             \
{                                                                              \
    ((uint64_t *)(v))[(0xc41+3387-0x197c)] = 0x6a09e667f3bcc908;\
                                 \
    ((uint64_t *)(v))[(0x1552+2496-0x1f11)] = 0xbb67ae8584caa73b;\
                                 \
    ((uint64_t *)(v))[(0x1458+2642-0x1ea8)] = 0x3c6ef372fe94f82b;\
                                 \
    ((uint64_t *)(v))[(0x2ab+8738-0x24ca)] = 0xa54ff53a5f1d36f1;\
                                 \
    ((uint64_t *)(v))[(0x7a9+5726-0x1e03)] = 0x510e527fade682d1;\
                                 \
    ((uint64_t *)(v))[(0xa30+1613-0x1078)] = 0x9b05688c2b3e6c1f;\
                                 \
    ((uint64_t *)(v))[(0x1c5d+1282-0x2159)] = 0x1f83d9abfb41bd6b;\
                                 \
    ((uint64_t *)(v))[(0xb2b+4828-0x1e00)] = 0x5be0cd19137e2179;\
                                 \
}                                                                              \
while ((0x10c5+634-0x133f))
#define ROTR64(x, y) (((x) >> (y)) ^ ((x) << ((0x4b4+4179-0x14c7) - (y))))
#define B2B_G(v, a, b, c, d, x, y)                                             \
do                                                                             \
{                                                                              \
    ((uint64_t *)(v))[a] += ((uint64_t *)(v))[b] + x;                          \
    ((uint64_t *)(v))[d]                                                       \
        = ROTR64(((uint64_t *)(v))[d] ^ ((uint64_t *)(v))[a], \
(0x17bb+3128-0x23d3));             \
    ((uint64_t *)(v))[c] += ((uint64_t *)(v))[d];                              \
    ((uint64_t *)(v))[b]                                                       \
        = ROTR64(((uint64_t *)(v))[b] ^ ((uint64_t *)(v))[c], \
(0x8ca+7496-0x25fa));             \
    ((uint64_t *)(v))[a] += ((uint64_t *)(v))[b] + y;                          \
    ((uint64_t *)(v))[d]                                                       \
        = ROTR64(((uint64_t *)(v))[d] ^ ((uint64_t *)(v))[a], \
(0x193a+898-0x1cac));             \
    ((uint64_t *)(v))[c] += ((uint64_t *)(v))[d];                              \
    ((uint64_t *)(v))[b]                                                       \
        = ROTR64(((uint64_t *)(v))[b] ^ ((uint64_t *)(v))[c], (0x19a+2482-0xb0d)\
);             \
}                                                                              \
while ((0x1362+284-0x147e))
#define B2B_MIX(v, m)                                                          \
do                                                                             \
{                                                                              \
    B2B_G(v, (0x1b5a+253-0x1c57), (0x1f+2701-0xaa8),  (0x183c+2399-0x2193), \
(0x593+4403-0x16ba), ((uint64_t *)(m))[ (0x13db+1823-0x1afa)], ((uint64_t *)(m))\
[ (0x1851+219-0x192b)]);      \
    B2B_G(v, (0x1943+1238-0x1e18), (0x3bc+5841-0x1a88),  (0x15ec+2539-0x1fce), \
(0xd55+5866-0x2432), ((uint64_t *)(m))[ (0x35c+7361-0x201b)], ((uint64_t *)(m))[\
 (0xfa4+2854-0x1ac7)]);      \
    B2B_G(v, (0x502+2003-0xcd3), (0x420+2693-0xe9f), (0xec5+818-0x11ed), \
(0x5d0+7480-0x22fa), ((uint64_t *)(m))[ (0x20e8+241-0x21d5)], ((uint64_t *)(m))[\
 (0x5fb+1482-0xbc0)]);      \
    B2B_G(v, (0x1ca7+2206-0x2542), (0x5b9+6424-0x1eca), (0x314+8665-0x24e2), \
(0x67a+5581-0x1c38), ((uint64_t *)(m))[ (0xa19+2731-0x14be)], ((uint64_t *)(m))[\
 (0x1cd+395-0x351)]);      \
    B2B_G(v, (0x1621+4012-0x25cd), (0xff5+3651-0x1e33), (0x119d+4037-0x2158), \
(0x118d+1195-0x1629), ((uint64_t *)(m))[ (0x1f0+8964-0x24ec)], ((uint64_t *)(m))\
[ (0x5ef+4448-0x1746)]);      \
    B2B_G(v, (0xcfc+3059-0x18ee), (0x9ac+3849-0x18af), (0x9d4+5564-0x1f85), \
(0x815+1866-0xf53), ((uint64_t *)(m))[(0x1080+4326-0x215c)], ((uint64_t *)(m))[\
(0x1888+97-0x18de)]);      \
    B2B_G(v, (0x204+3514-0xfbc), (0x120+2497-0xada),  (0x195a+508-0x1b4e), \
(0x112c+5592-0x26f7), ((uint64_t *)(m))[(0x653+3798-0x151d)], ((uint64_t *)(m))[\
(0x3f0+3184-0x1053)]);      \
    B2B_G(v, (0x1e5c+564-0x208d), (0x527+16-0x533),  (0x1ca+2001-0x992), \
(0xb1f+1345-0x1052), ((uint64_t *)(m))[(0xa9b+1651-0x1100)], ((uint64_t *)(m))[\
(0x1416+2913-0x1f68)]);      \
                                                                               \
    B2B_G(v, (0x88a+563-0xabd), (0x2fc+7116-0x1ec4),  (0x1ca6+1490-0x2270), \
(0xc2c+1033-0x1029), ((uint64_t *)(m))[(0xf0b+4044-0x1ec9)], ((uint64_t *)(m))[\
(0x4ca+5486-0x1a2e)]);      \
    B2B_G(v, (0x53d+5333-0x1a11), (0x179c+1186-0x1c39),  (0x6fb+6889-0x21db), \
(0x1581+2330-0x1e8e), ((uint64_t *)(m))[ (0x10c7+5539-0x2666)], ((uint64_t *)(m)\
)[ (0x14f+3393-0xe88)]);      \
    B2B_G(v, (0x6cb+3477-0x145e), (0x1627+400-0x17b1), (0x516+8288-0x256c), \
(0x1264+4157-0x2293), ((uint64_t *)(m))[ (0xbbb+2245-0x1477)], ((uint64_t *)(m))\
[(0x749+6348-0x2006)]);      \
    B2B_G(v, (0x173+3563-0xf5b), (0x222+6501-0x1b80), (0xc63+5744-0x22c8), \
(0xf95+2455-0x191d), ((uint64_t *)(m))[(0x99f+2539-0x137d)], ((uint64_t *)(m))[ \
(0x956+5916-0x206c)]);      \
    B2B_G(v, (0xa58+2970-0x15f2), (0x1822+335-0x196c), (0x169b+4197-0x26f6), \
(0x124+2070-0x92b), ((uint64_t *)(m))[ (0x1265+25-0x127d)], ((uint64_t *)(m))[\
(0x111d+5480-0x2679)]);      \
    B2B_G(v, (0x750+3144-0x1397), (0x634+6244-0x1e92), (0x7c9+4093-0x17bb), \
(0x7cc+60-0x7fc), ((uint64_t *)(m))[ (0x16da+681-0x1983)], ((uint64_t *)(m))[ \
(0xa54+7218-0x2684)]);      \
    B2B_G(v, (0x6ea+4744-0x1970), (0x1376+4645-0x2594),  (0x10e7+675-0x1382), \
(0x662+274-0x767), ((uint64_t *)(m))[(0x1c82+154-0x1d11)], ((uint64_t *)(m))[ \
(0x1e55+297-0x1f77)]);      \
    B2B_G(v, (0x1244+4208-0x22b1), (0x173f+1387-0x1ca6),  (0x63d+3457-0x13b5), \
(0x855+1962-0xff1), ((uint64_t *)(m))[ (0xdb1+3948-0x1d18)], ((uint64_t *)(m))[ \
(0xc34+1108-0x1085)]);      \
                                                                               \
    B2B_G(v, (0x11bf+1562-0x17d9), (0xbe3+49-0xc10),  (0x1b0+8254-0x21e6), \
(0xf+2149-0x868), ((uint64_t *)(m))[(0x1c52+1928-0x23cf)], ((uint64_t *)(m))[ \
(0x86d+3461-0x15ea)]);      \
    B2B_G(v, (0x1e23+1256-0x230a), (0x2290+1003-0x2676),  (0x164+8870-0x2401), \
(0x142+1844-0x869), ((uint64_t *)(m))[(0xa6d+4909-0x1d8e)], ((uint64_t *)(m))[ \
(0x12a9+4122-0x22c3)]);      \
    B2B_G(v, (0xafc+6726-0x2540), (0x16fb+3977-0x267e), (0x13c+7792-0x1fa2), \
(0x953+6850-0x2407), ((uint64_t *)(m))[ (0xa9c+4193-0x1af8)], ((uint64_t *)(m))[\
 (0x102b+5809-0x26da)]);      \
    B2B_G(v, (0x1a6+3478-0xf39), (0x12f5+2939-0x1e69), (0x163f+1116-0x1a90), \
(0x1f2b+1216-0x23dc), ((uint64_t *)(m))[(0x709+7152-0x22ea)], ((uint64_t *)(m))[\
(0x329+5601-0x18fd)]);      \
    B2B_G(v, (0x69a+6822-0x2140), (0x19a8+1667-0x2026), (0x606+1464-0xbb4), \
(0x427+5197-0x1865), ((uint64_t *)(m))[(0x1ba6+328-0x1ce4)], ((uint64_t *)(m))[\
(0x1536+1469-0x1ae5)]);      \
    B2B_G(v, (0x2148+65-0x2188), (0x78c+6320-0x2036), (0xb78+4035-0x1b30), \
(0x1b93+2283-0x2472), ((uint64_t *)(m))[ (0x22c1+755-0x25b1)], ((uint64_t *)(m))\
[ (0x81a+6556-0x21b0)]);      \
    B2B_G(v, (0x1505+3939-0x2466), (0x5f1+8031-0x2549),  (0xceb+6341-0x25a8), \
(0x10cb+5076-0x2492), ((uint64_t *)(m))[ (0x4f9+6748-0x1f4e)], ((uint64_t *)(m))\
[ (0x36a+8612-0x250d)]);      \
    B2B_G(v, (0x1da8+2355-0x26d8), (0x96b+455-0xb2e),  (0x92c+1366-0xe79), \
(0xdb5+1089-0x11e8), ((uint64_t *)(m))[ (0x11cd+4321-0x22a5)], ((uint64_t *)(m))\
[ (0x825+3870-0x173f)]);      \
                                                                               \
    B2B_G(v, (0x1263+2289-0x1b54), (0xc1d+969-0xfe2),  (0xe8+3588-0xee4), \
(0x13b1+3187-0x2018), ((uint64_t *)(m))[ (0x89a+7595-0x263e)], ((uint64_t *)(m))\
[ (0xc0a+3614-0x1a1f)]);      \
    B2B_G(v, (0x215+9103-0x25a3), (0x51b+388-0x69a),  (0x977+3039-0x154d), \
(0xc13+4762-0x1ea0), ((uint64_t *)(m))[ (0x803+2687-0x127f)], ((uint64_t *)(m))[\
 (0xd1b+1264-0x120a)]);      \
    B2B_G(v, (0xba0+2956-0x172a), (0x11eb+1698-0x1887), (0x4fc+1337-0xa2b), \
(0x6b8+6399-0x1fa9), ((uint64_t *)(m))[(0x1563+4265-0x25ff)], ((uint64_t *)(m))[\
(0x8ed+5080-0x1cb9)]);      \
    B2B_G(v, (0x1aa0+1099-0x1ee8), (0x156f+3948-0x24d4), (0x13df+4617-0x25dd), \
(0x2a4+2537-0xc7e), ((uint64_t *)(m))[(0xa05+2021-0x11df)], ((uint64_t *)(m))[\
(0x48+4865-0x133b)]);      \
    B2B_G(v, (0x1cf+7644-0x1fab), (0x105c+2745-0x1b10), (0x1677+528-0x187d), \
(0x199d+2028-0x217a), ((uint64_t *)(m))[ (0xd3b+6047-0x24d8)], ((uint64_t *)(m))\
[ (0x22+1580-0x648)]);      \
    B2B_G(v, (0xbcc+3581-0x19c8), (0x2b5+7926-0x21a5), (0xbab+3008-0x1760), \
(0x678+4398-0x179a), ((uint64_t *)(m))[ (0x122f+3908-0x216e)], ((uint64_t *)(m))\
[(0x1761+1552-0x1d67)]);      \
    B2B_G(v, (0xae3+5519-0x2070), (0x1ec0+454-0x207f),  (0x12+845-0x357), \
(0x41b+1582-0xa3c), ((uint64_t *)(m))[ (0x40b+8765-0x2644)], ((uint64_t *)(m))[ \
(0x483+4058-0x145d)]);      \
    B2B_G(v, (0xb6b+4090-0x1b62), (0x7c+6513-0x19e9),  (0x1e8+3422-0xf3d), \
(0x50+9039-0x2391), ((uint64_t *)(m))[(0xddd+2776-0x18a6)], ((uint64_t *)(m))[ \
(0x133d+2988-0x1ee1)]);      \
                                                                               \
    B2B_G(v, (0xe21+5564-0x23dd), (0x23e6+490-0x25cc),  (0x2588+290-0x26a2), \
(0x1ec7+331-0x2006), ((uint64_t *)(m))[ (0x172+1170-0x5fb)], ((uint64_t *)(m))[ \
(0xd96+2453-0x172b)]);      \
    B2B_G(v, (0x6c7+6547-0x2059), (0x1e13+583-0x2055),  (0x22c+1420-0x7af), \
(0x27d+5982-0x19ce), ((uint64_t *)(m))[ (0x1072+690-0x131f)], ((uint64_t *)(m))[\
 (0x1bf+2289-0xaa9)]);      \
    B2B_G(v, (0x13f0+1344-0x192e), (0xd92+1453-0x1339), (0x3d3+1751-0xaa0), \
(0xcc1+6204-0x24ef), ((uint64_t *)(m))[ (0x1da+4460-0x1344)], ((uint64_t *)(m))[\
 (0x88b+5579-0x1e52)]);      \
    B2B_G(v, (0x29d+304-0x3ca), (0x713+5729-0x1d6d), (0x2116+1249-0x25ec), \
(0xe16+166-0xead), ((uint64_t *)(m))[(0x17bf+983-0x1b8c)], ((uint64_t *)(m))[\
(0x3b3+4337-0x1495)]);      \
    B2B_G(v, (0x826+4406-0x195c), (0x19d8+214-0x1aa9), (0x1399+1675-0x1a1a), \
(0xc78+561-0xe9a), ((uint64_t *)(m))[(0x18cb+1988-0x2081)], ((uint64_t *)(m))[ \
(0xdc2+5899-0x24cc)]);      \
    B2B_G(v, (0x94f+3856-0x185e), (0xc31+4893-0x1f48), (0x111d+3908-0x2056), \
(0x18d0+3029-0x2499), ((uint64_t *)(m))[(0xf4d+4712-0x21aa)], ((uint64_t *)(m))[\
(0x1b1b+487-0x1cf6)]);      \
    B2B_G(v, (0x9b2+3992-0x1948), (0x13b8+646-0x1637),  (0x1340+2116-0x1b7c), \
(0x881+386-0x9f6), ((uint64_t *)(m))[ (0x700+2827-0x1205)], ((uint64_t *)(m))[ \
(0x7e3+2786-0x12bd)]);      \
    B2B_G(v, (0xc3d+358-0xda0), (0x151d+2805-0x200e),  (0x186d+2009-0x203d), \
(0x31d+4261-0x13b4), ((uint64_t *)(m))[ (0x1f33+778-0x223a)], ((uint64_t *)(m))[\
(0x916+2646-0x135f)]);      \
                                                                               \
    B2B_G(v, (0x1fc5+1140-0x2439), (0x1543+3549-0x231c),  (0x15ca+2686-0x2040), \
(0x1226+921-0x15b3), ((uint64_t *)(m))[ (0x1ead+479-0x208a)], ((uint64_t *)(m))[\
(0x40d+1197-0x8ae)]);      \
    B2B_G(v, (0x6ba+3053-0x12a6), (0x10c+5546-0x16b1),  (0x2c1+4114-0x12ca), \
(0x82f+7605-0x25d7), ((uint64_t *)(m))[ (0xf11+1641-0x1574)], ((uint64_t *)(m))[\
(0xcf9+2553-0x16e8)]);      \
    B2B_G(v, (0x9b1+5432-0x1ee7), (0x1955+2604-0x237b), (0xa51+1428-0xfdb), \
(0x85+6119-0x185e), ((uint64_t *)(m))[ (0x121+3713-0xfa2)], ((uint64_t *)(m))[\
(0xf22+3470-0x1ca5)]);      \
    B2B_G(v, (0x800+2797-0x12ea), (0x1698+4200-0x26f9), (0x790+3303-0x146c), \
(0x1046+365-0x11a4), ((uint64_t *)(m))[ (0x66f+838-0x9ad)], ((uint64_t *)(m))[ \
(0xe8c+5512-0x2411)]);      \
    B2B_G(v, (0x13ca+833-0x170b), (0xeaa+3818-0x1d8f), (0x1fa3+1499-0x2574), \
(0x1b62+670-0x1df1), ((uint64_t *)(m))[ (0x1814+479-0x19ef)], ((uint64_t *)(m))[\
(0xd37+6517-0x269f)]);      \
    B2B_G(v, (0x963+3997-0x18ff), (0x915+5235-0x1d82), (0x847+1141-0xcb1), \
(0x2a6+2960-0xe2a), ((uint64_t *)(m))[ (0x866+642-0xae1)], ((uint64_t *)(m))[ \
(0x7ff+4470-0x1970)]);      \
    B2B_G(v, (0x406+2966-0xf9a), (0x7+2336-0x920),  (0x1053+3175-0x1cb2), \
(0x487+5510-0x1a00), ((uint64_t *)(m))[(0xe63+68-0xe98)], ((uint64_t *)(m))[\
(0xfb1+5332-0x2477)]);      \
    B2B_G(v, (0x15a2+270-0x16ad), (0x1c53+1029-0x2054),  (0x12cb+780-0x15ce), \
(0x558+6001-0x1cbb), ((uint64_t *)(m))[ (0x5a1+8398-0x266e)], ((uint64_t *)(m))[\
 (0xa4d+6350-0x2312)]);      \
                                                                               \
    B2B_G(v, (0x4d5+2191-0xd64), (0x9d5+5204-0x1e25),  (0x1c43+2159-0x24aa), \
(0x19d0+3397-0x2709), ((uint64_t *)(m))[(0x803+7736-0x262f)], ((uint64_t *)(m))[\
 (0x32a+880-0x695)]);      \
    B2B_G(v, (0x3db+866-0x73c), (0xe46+536-0x1059),  (0xac1+4328-0x1ba0), \
(0xfc9+4736-0x223c), ((uint64_t *)(m))[ (0x173d+3040-0x231c)], ((uint64_t *)(m))\
[(0x217+2162-0xa7a)]);      \
    B2B_G(v, (0xb7b+236-0xc65), (0x70b+5000-0x1a8d), (0xef+3736-0xf7d), \
(0x14cc+1594-0x1af8), ((uint64_t *)(m))[(0x4f0+5647-0x1af1)], ((uint64_t *)(m))[\
(0x2c2+1022-0x6b3)]);      \
    B2B_G(v, (0x195b+1763-0x203b), (0xdf8+4294-0x1eb7), (0x499+1755-0xb69), \
(0x1d92+2041-0x257c), ((uint64_t *)(m))[ (0x548+2375-0xe8b)], ((uint64_t *)(m))[\
(0x14b+869-0x4a6)]);      \
    B2B_G(v, (0x5f8+1889-0xd59), (0x906+1401-0xe7a), (0x13fa+4606-0x25ee), \
(0x1e15+1087-0x2245), ((uint64_t *)(m))[ (0x109c+993-0x147d)], ((uint64_t *)(m))\
[ (0xfc8+1166-0x144f)]);      \
    B2B_G(v, (0x1602+2345-0x1f2a), (0x69f+1591-0xcd0), (0x952+6-0x94d), \
(0x3a1+7817-0x221e), ((uint64_t *)(m))[ (0x1275+141-0x12fc)], ((uint64_t *)(m))[\
 (0x17f6+888-0x1b6b)]);      \
    B2B_G(v, (0x1b6b+2687-0x25e8), (0x23d+783-0x545),  (0xdbb+1181-0x1250), \
(0x74+9512-0x258f), ((uint64_t *)(m))[ (0xd16+2459-0x16a8)], ((uint64_t *)(m))[ \
(0xda0+6238-0x25fc)]);      \
    B2B_G(v, (0x42a+609-0x688), (0x1119+2266-0x19ef),  (0x1ecd+1315-0x23e7), \
(0x1019+5210-0x2465), ((uint64_t *)(m))[ (0x383+6562-0x1d1d)], ((uint64_t *)(m))\
[(0x3a5+3424-0x10fa)]);      \
                                                                               \
    B2B_G(v, (0x191a+1272-0x1e12), (0x1d29+2441-0x26ae),  (0x1313+39-0x1332), \
(0x1330+4594-0x2516), ((uint64_t *)(m))[(0xde1+3886-0x1d02)], ((uint64_t *)(m))[\
(0x105c+78-0x109f)]);      \
    B2B_G(v, (0x546+6790-0x1fcb), (0x1888+2110-0x20c1),  (0x144f+4333-0x2533), \
(0x133a+4617-0x2536), ((uint64_t *)(m))[ (0x57b+4215-0x15eb)], ((uint64_t *)(m))\
[(0x612+347-0x75f)]);      \
    B2B_G(v, (0x1ca+7872-0x2088), (0x949+7035-0x24be), (0x7a4+484-0x97e), \
(0x11dc+4217-0x2247), ((uint64_t *)(m))[(0x171+4928-0x14a5)], ((uint64_t *)(m))[\
 (0x1ba2+576-0x1de1)]);      \
    B2B_G(v, (0x5b0+1768-0xc95), (0x78b+2511-0x1153), (0x73b+7826-0x25c2), \
(0x196d+2326-0x2274), ((uint64_t *)(m))[ (0x1c45+2108-0x247e)], ((uint64_t *)(m)\
)[ (0x7b5+3414-0x1502)]);      \
    B2B_G(v, (0x1e85+1580-0x24b1), (0xe6f+714-0x1134), (0x12d9+2361-0x1c08), \
(0x1866+1869-0x1fa4), ((uint64_t *)(m))[ (0x704+3081-0x1308)], ((uint64_t *)(m))\
[ (0x7eb+7753-0x2634)]);      \
    B2B_G(v, (0x5c1+7157-0x21b5), (0x63c+1034-0xa40), (0x6eb+6284-0x1f6c), \
(0x25f+6362-0x1b2d), ((uint64_t *)(m))[(0x269+3107-0xe7d)], ((uint64_t *)(m))[ \
(0x3e1+3517-0x119a)]);      \
    B2B_G(v, (0x8ab+7388-0x2585), (0x24f3+466-0x26be),  (0x2d7+7739-0x210a), \
(0x21a+1655-0x884), ((uint64_t *)(m))[ (0x1d88+1781-0x2475)], ((uint64_t *)(m))[\
 (0x380+3121-0xfab)]);      \
    B2B_G(v, (0x328+7568-0x20b5), (0x863+5410-0x1d81),  (0xdd3+93-0xe27), \
(0x152b+84-0x1571), ((uint64_t *)(m))[ (0x307+6065-0x1ab6)], ((uint64_t *)(m))[\
(0x45f+3484-0x11f1)]);      \
                                                                               \
    B2B_G(v, (0x10ea+714-0x13b4), (0x2c5+7786-0x212b),  (0x511+6739-0x1f5c), \
(0x19ca+449-0x1b7f), ((uint64_t *)(m))[ (0x1305+1294-0x180d)], ((uint64_t *)(m))\
[(0x1418+1009-0x17fa)]);      \
    B2B_G(v, (0x26c+4169-0x12b4), (0x15cb+4023-0x257d),  (0x16bd+1131-0x1b1f), \
(0xa70+6967-0x259a), ((uint64_t *)(m))[(0x1dbc+253-0x1eab)], ((uint64_t *)(m))[ \
(0x1773+1205-0x1c1f)]);      \
    B2B_G(v, (0xa32+5636-0x2034), (0x1931+57-0x1964), (0x1a9d+49-0x1ac4), \
(0xac7+1799-0x11c0), ((uint64_t *)(m))[(0xb3f+1384-0x109c)], ((uint64_t *)(m))[ \
(0x23ab+489-0x2591)]);      \
    B2B_G(v, (0xe4a+5228-0x22b3), (0x1e91+1187-0x232d), (0x3a3+4487-0x151f), \
(0x21a+5764-0x188f), ((uint64_t *)(m))[ (0x640+899-0x9c3)], ((uint64_t *)(m))[ \
(0x11a8+2461-0x1b3d)]);      \
    B2B_G(v, (0x115+563-0x348), (0x106b+1755-0x1741), (0x624+5358-0x1b08), \
(0x27f+8078-0x21fe), ((uint64_t *)(m))[(0xe3+4005-0x107c)], ((uint64_t *)(m))[ \
(0x926+4816-0x1bf4)]);      \
    B2B_G(v, (0x590+7313-0x2220), (0xa70+6979-0x25ad), (0x4ac+7076-0x2045), \
(0xecb+5014-0x2255), ((uint64_t *)(m))[(0x7ba+7670-0x25a3)], ((uint64_t *)(m))[ \
(0xc69+3029-0x1837)]);      \
    B2B_G(v, (0x2111+37-0x2134), (0x1654+3020-0x2219),  (0x1f70+853-0x22bd), \
(0xff3+2225-0x1897), ((uint64_t *)(m))[ (0x12b5+4466-0x2426)], ((uint64_t *)(m))\
[ (0x56+7987-0x1f85)]);      \
    B2B_G(v, (0x1fc8+727-0x229c), (0xa51+2739-0x1500),  (0xeb0+4062-0x1e85), \
(0x31+6150-0x1829), ((uint64_t *)(m))[(0x1249+3295-0x1f1e)], ((uint64_t *)(m))[ \
(0x1065+4800-0x2320)]);      \
                                                                               \
    B2B_G(v, (0xe92+4671-0x20d1), (0xef1+2173-0x176a),  (0x858+6847-0x230f), \
(0x77a+7678-0x256c), ((uint64_t *)(m))[(0x2e4+8957-0x25d7)], ((uint64_t *)(m))[ \
(0xd8b+2032-0x1579)]);      \
    B2B_G(v, (0xcd+3917-0x1019), (0x78a+1918-0xf03),  (0x13f7+1169-0x187f), \
(0x1368+1300-0x186f), ((uint64_t *)(m))[ (0xd76+98-0xdd0)], ((uint64_t *)(m))[ \
(0x3b4+6689-0x1dd1)]);      \
    B2B_G(v, (0x15a8+948-0x195a), (0x20d9+1001-0x24bc), (0x261+842-0x5a1), \
(0xfba+2777-0x1a85), ((uint64_t *)(m))[ (0x10+7358-0x1cc7)], ((uint64_t *)(m))[ \
(0x27b+2485-0xc2a)]);      \
    B2B_G(v, (0x1dbc+87-0x1e10), (0x6ac+852-0x9f9), (0xdd4+1283-0x12cc), \
(0x62a+6344-0x1ee3), ((uint64_t *)(m))[ (0x67+1235-0x539)], ((uint64_t *)(m))[ \
(0x14c3+668-0x175a)]);      \
    B2B_G(v, (0x10a8+3390-0x1de6), (0x11ad+945-0x1559), (0x19c1+2496-0x2377), \
(0x757+4043-0x1713), ((uint64_t *)(m))[(0x5f2+3046-0x11c9)], ((uint64_t *)(m))[\
(0x3d2+4658-0x15f9)]);      \
    B2B_G(v, (0x216+2737-0xcc6), (0xd22+4635-0x1f37), (0xa22+5707-0x2062), \
(0xaed+5164-0x1f0d), ((uint64_t *)(m))[ (0xe86+5667-0x24a0)], ((uint64_t *)(m))[\
(0x4b7+2683-0xf24)]);      \
    B2B_G(v, (0x163d+4157-0x2678), (0x11a0+1478-0x175f),  (0x1ec+4434-0x1336), \
(0x1042+590-0x1283), ((uint64_t *)(m))[ (0x483+4049-0x1451)], ((uint64_t *)(m))[\
(0x1060+4617-0x225d)]);      \
    B2B_G(v, (0x2447+521-0x264d), (0x1baf+1664-0x222b),  (0x8f0+7712-0x2707), \
(0x14bb+3713-0x232e), ((uint64_t *)(m))[(0x235a+165-0x23f2)], ((uint64_t *)(m))[\
 (0x1641+4276-0x26f5)]);      \
                                                                               \
    B2B_G(v, (0x20a7+1243-0x2582), (0x1111+756-0x1401),  (0x1b3c+2168-0x23ac), \
(0x1315+4608-0x2509), ((uint64_t *)(m))[ (0x7eb+2254-0x10b9)], ((uint64_t *)(m))\
[ (0x1108+2668-0x1b73)]);      \
    B2B_G(v, (0x1d1d+1773-0x2409), (0x17e2+2947-0x2360),  (0x8a5+6417-0x21ad), \
(0x380+6818-0x1e15), ((uint64_t *)(m))[ (0xbb5+4025-0x1b6c)], ((uint64_t *)(m))[\
 (0x3e0+7514-0x2137)]);      \
    B2B_G(v, (0xdf3+5955-0x2534), (0x1042+2847-0x1b5b), (0x222+1273-0x711), \
(0xc16+3822-0x1af6), ((uint64_t *)(m))[ (0x2270+277-0x2381)], ((uint64_t *)(m))[\
 (0xd4a+3398-0x1a8b)]);      \
    B2B_G(v, (0x668+1819-0xd80), (0x832+4891-0x1b46), (0x10d7+4438-0x2222), \
(0x740+7490-0x2473), ((uint64_t *)(m))[ (0xc5a+4724-0x1ec8)], ((uint64_t *)(m))[\
 (0x12eb+1582-0x1912)]);      \
    B2B_G(v, (0x71d+5860-0x1e01), (0x553+7824-0x23de), (0x186f+886-0x1bdb), \
(0x8a0+4832-0x1b71), ((uint64_t *)(m))[ (0x1d93+379-0x1f06)], ((uint64_t *)(m))[\
 (0x1759+839-0x1a97)]);      \
    B2B_G(v, (0x461+2420-0xdd4), (0x316+2700-0xd9c), (0x647+6743-0x2093), \
(0xe2d+3523-0x1be4), ((uint64_t *)(m))[(0x1210+1262-0x16f4)], ((uint64_t *)(m))[\
(0x1396+4964-0x26ef)]);      \
    B2B_G(v, (0x107d+1547-0x1686), (0x807+7857-0x26b1),  (0xb0d+6996-0x2659), \
(0x3da+6984-0x1f15), ((uint64_t *)(m))[(0x1b54+2997-0x26fd)], ((uint64_t *)(m))[\
(0x166c+2579-0x2072)]);      \
    B2B_G(v, (0x1122+577-0x1360), (0x14b8+2672-0x1f24),  (0x7d9+7727-0x25ff), \
(0x1b7a+1084-0x1fa8), ((uint64_t *)(m))[(0x5eb+4951-0x1934)], ((uint64_t *)(m))[\
(0x1667+666-0x18f2)]);      \
                                                                               \
    B2B_G(v, (0x1149+4091-0x2144), (0xa+8717-0x2213),  (0x54a+6532-0x1ec6), \
(0x1c42+741-0x1f1b), ((uint64_t *)(m))[(0x19d5+1945-0x2160)], ((uint64_t *)(m))[\
(0xb38+428-0xcda)]);      \
    B2B_G(v, (0xebc+1569-0x14dc), (0x1761+2132-0x1fb0),  (0x19fd+998-0x1dda), \
(0x2c6+5025-0x165a), ((uint64_t *)(m))[ (0x8d3+3562-0x16b9)], ((uint64_t *)(m))[\
 (0x1a71+2382-0x23b7)]);      \
    B2B_G(v, (0x223f+328-0x2385), (0x595+1521-0xb80), (0x1055+3894-0x1f81), \
(0x748+2118-0xf80), ((uint64_t *)(m))[ (0x7f2+4511-0x1988)], ((uint64_t *)(m))[\
(0x10d4+159-0x1164)]);      \
    B2B_G(v, (0x419+4593-0x1607), (0x41a+6998-0x1f69), (0x104c+1050-0x145b), \
(0x16b7+764-0x19a4), ((uint64_t *)(m))[(0xae4+6335-0x2396)], ((uint64_t *)(m))[ \
(0x900+7117-0x24c7)]);      \
    B2B_G(v, (0x806+1126-0xc6c), (0x147a+1585-0x1aa6), (0x245+5182-0x1679), \
(0x445+6427-0x1d51), ((uint64_t *)(m))[ (0x37f+7261-0x1fdb)], ((uint64_t *)(m))[\
(0xad1+6032-0x2255)]);      \
    B2B_G(v, (0xdaf+5684-0x23e2), (0x31d+5270-0x17ad), (0x1110+3264-0x1dc5), \
(0x140f+1475-0x19c6), ((uint64_t *)(m))[ (0x402+1195-0x8ad)], ((uint64_t *)(m))[\
 (0x1b0f+1027-0x1f10)]);      \
    B2B_G(v, (0x113a+2152-0x19a0), (0x4d6+6675-0x1ee2),  (0x1b0f+2053-0x230c), \
(0x861+7537-0x25c5), ((uint64_t *)(m))[(0x11c1+1551-0x17c5)], ((uint64_t *)(m))[\
 (0x1a8+6337-0x1a62)]);      \
    B2B_G(v, (0x6d+9430-0x2540), (0x1569+2849-0x2086),  (0x5db+1149-0xa4f), \
(0xd9f+1738-0x145b), ((uint64_t *)(m))[ (0x807+2982-0x13a8)], ((uint64_t *)(m))[\
 (0xb37+2819-0x1637)]);      \
}                                                                              \
while ((0x3bb+7409-0x20ac))
#define B2B_INIT(ctx, aux)                                                     \
do                                                                             \
{                                                                              \
    ((uint64_t *)(aux))[(0x559+6957-0x2086)] = ((ctx_t *)(ctx))->h[\
(0x1a25+3247-0x26d4)];                           \
    ((uint64_t *)(aux))[(0xa98+4634-0x1cb1)] = ((ctx_t *)(ctx))->h[\
(0x3f8+8473-0x2510)];                           \
    ((uint64_t *)(aux))[(0x113a+257-0x1239)] = ((ctx_t *)(ctx))->h[\
(0x866+2388-0x11b8)];                           \
    ((uint64_t *)(aux))[(0x3a4+4241-0x1432)] = ((ctx_t *)(ctx))->h[\
(0x1a1+6569-0x1b47)];                           \
    ((uint64_t *)(aux))[(0x15ea+2164-0x1e5a)] = ((ctx_t *)(ctx))->h[\
(0x1d7+2093-0xa00)];                           \
    ((uint64_t *)(aux))[(0x1d47+1324-0x226e)] = ((ctx_t *)(ctx))->h[\
(0x8e3+5020-0x1c7a)];                           \
    ((uint64_t *)(aux))[(0x1cad+717-0x1f74)] = ((ctx_t *)(ctx))->h[\
(0xa70+5812-0x211e)];                           \
    ((uint64_t *)(aux))[(0x19cd+1049-0x1ddf)] = ((ctx_t *)(ctx))->h[\
(0x77+6907-0x1b6b)];                           \
                                                                               \
    B2B_IV(aux + (0x859+3789-0x171e));\
                                                           \
                                                                               \
    ((uint64_t *)(aux))[(0x3c8+1083-0x7f7)] ^= ((ctx_t *)(ctx))->t[\
(0x50b+4166-0x1551)];                         \
    ((uint64_t *)(aux))[(0x257+3318-0xf40)] ^= ((ctx_t *)(ctx))->t[\
(0xa36+2285-0x1322)];                         \
}                                                                              \
while ((0x53a+1752-0xc12))
#define CAST(x) (((union { __typeof__(x) a; uint64_t b; })x).b)
#define B2B_FINAL(ctx, aux)                                                    \
do                                                                             \
{                                                                              \
    ((uint64_t *)(aux))[(0x8b8+6249-0x2111)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[ (0x1a9+588-0x3f5)];         \
    ((uint64_t *)(aux))[(0x6ef+173-0x78b)] = ((uint64_t *)(((ctx_t *)(ctx))->b))\
[ (0xdca+3050-0x19b3)];         \
    ((uint64_t *)(aux))[(0x3dd+5316-0x188f)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[ (0x9d4+6831-0x2481)];         \
    ((uint64_t *)(aux))[(0x4ac+5941-0x1bce)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[ (0x4a6+3567-0x1292)];         \
    ((uint64_t *)(aux))[(0x6c5+406-0x847)] = ((uint64_t *)(((ctx_t *)(ctx))->b))\
[ (0x10f5+1235-0x15c4)];         \
    ((uint64_t *)(aux))[(0x1048+2102-0x1869)] = ((uint64_t *)(((ctx_t *)(ctx))->\
b))[ (0x23fd+572-0x2634)];         \
    ((uint64_t *)(aux))[(0xfba+5185-0x23e5)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[ (0xa5+3349-0xdb4)];         \
    ((uint64_t *)(aux))[(0x31b+7913-0x21ed)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[ (0x1c35+470-0x1e04)];         \
    ((uint64_t *)(aux))[(0x8b3+5960-0x1fe3)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[ (0x458+4112-0x1460)];         \
    ((uint64_t *)(aux))[(0xa8b+537-0xc8b)] = ((uint64_t *)(((ctx_t *)(ctx))->b))\
[ (0x31d+1241-0x7ed)];         \
    ((uint64_t *)(aux))[(0xa02+1835-0x1113)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[(0x347+3178-0xfa7)];         \
    ((uint64_t *)(aux))[(0xc00+2991-0x1794)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[(0xd88+913-0x110e)];         \
    ((uint64_t *)(aux))[(0x9e0+1126-0xe2a)] = ((uint64_t *)(((ctx_t *)(ctx))->b)\
)[(0x15b0+1905-0x1d15)];         \
    ((uint64_t *)(aux))[(0x11f0+1697-0x1874)] = ((uint64_t *)(((ctx_t *)(ctx))->\
b))[(0x5ab+2367-0xedd)];         \
    ((uint64_t *)(aux))[(0x9f5+5685-0x200c)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[(0x2409+698-0x26b5)];         \
    ((uint64_t *)(aux))[(0x641+2883-0x1165)] = ((uint64_t *)(((ctx_t *)(ctx))->b\
))[(0x19ed+3231-0x267d)];         \
                                                                               \
    B2B_MIX(aux, aux + (0x132a+4176-0x236a));\
                                                    \
                                                                               \
    ((ctx_t *)(ctx))->h[(0x1f0+6155-0x19fb)] ^= ((uint64_t *)(aux))[\
(0x386+3994-0x1320)] ^ ((uint64_t *)(aux))[ (0xbed+951-0xf9c)];\
    ((ctx_t *)(ctx))->h[(0x191+3815-0x1077)] ^= ((uint64_t *)(aux))[\
(0x18a0+291-0x19c2)] ^ ((uint64_t *)(aux))[ (0xdfb+5999-0x2561)];\
    ((ctx_t *)(ctx))->h[(0xe8a+661-0x111d)] ^= ((uint64_t *)(aux))[\
(0x1298+1610-0x18e0)] ^ ((uint64_t *)(aux))[(0x1a33+541-0x1c46)];\
    ((ctx_t *)(ctx))->h[(0x1397+1555-0x19a7)] ^= ((uint64_t *)(aux))[\
(0xc0d+4466-0x1d7c)] ^ ((uint64_t *)(aux))[(0x307+3698-0x116e)];\
    ((ctx_t *)(ctx))->h[(0x335+963-0x6f4)] ^= ((uint64_t *)(aux))[\
(0x1643+1210-0x1af9)] ^ ((uint64_t *)(aux))[(0xc7f+5836-0x233f)];\
    ((ctx_t *)(ctx))->h[(0x4db+653-0x763)] ^= ((uint64_t *)(aux))[\
(0x1bd1+2301-0x24c9)] ^ ((uint64_t *)(aux))[(0xa48+5329-0x1f0c)];\
    ((ctx_t *)(ctx))->h[(0x3d6+2250-0xc9a)] ^= ((uint64_t *)(aux))[\
(0x80c+2663-0x126d)] ^ ((uint64_t *)(aux))[(0x1427+4852-0x270d)];\
    ((ctx_t *)(ctx))->h[(0x4dd+6707-0x1f09)] ^= ((uint64_t *)(aux))[\
(0x1f61+1081-0x2393)] ^ ((uint64_t *)(aux))[(0x112+2725-0xba8)];\
}                                                                              \
while ((0x95f+6414-0x226d))
#define HOST_B2B_H(ctx, aux)                                                   \
do                                                                             \
{                                                                              \
    ((ctx_t *)(ctx))->t[(0x2a5+7603-0x2058)] += BUF_SIZE_8;\
                                      \
    ((ctx_t *)(ctx))->t[(0x503+5279-0x19a1)] += (0x18b4+3660-0x26ff) - !(((ctx_t\
 *)(ctx))->t[(0x2fc+1113-0x755)] < BUF_SIZE_8);      \
                                                                               \
    B2B_INIT(ctx, aux);                                                        \
    B2B_FINAL(ctx, aux);                                                       \
                                                                               \
    ((ctx_t *)(ctx))->c = (0x1220+216-0x12f8);\
                                                   \
}                                                                              \
while ((0x679+1663-0xcf8))
#define HOST_B2B_H_LAST(ctx, aux)                                              \
do                                                                             \
{                                                                              \
    ((ctx_t *)(ctx))->t[(0x1c55+1014-0x204b)] += ((ctx_t *)(ctx))->c;\
                             \
    ((ctx_t *)(ctx))->t[(0x1ccb+575-0x1f09)]\
                                                     \
        += (0x11fd+4262-0x22a2) - !(((ctx_t *)(ctx))->t[(0xc03+3451-0x197e)] < (\
(ctx_t *)(ctx))->c);                \
                                                                               \
    while (((ctx_t *)(ctx))->c < BUF_SIZE_8)                                   \
    {                                                                          \
        ((ctx_t *)(ctx))->b[((ctx_t *)(ctx))->c++] = (0x1abc+250-0x1bb6);\
                        \
    }                                                                          \
                                                                               \
    B2B_INIT(ctx, aux);                                                        \
                                                                               \
    ((uint64_t *)(aux))[(0xd3f+6491-0x268c)] = ~((uint64_t *)(aux))[\
(0xd80+5890-0x2474)];                        \
                                                                               \
    B2B_FINAL(ctx, aux);                                                       \
}                                                                              \
while ((0x1b52+2564-0x2556))
#define DEVICE_B2B_H(ctx, aux)                                                 \
do                                                                             \
{                                                                              \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x31\x32\x38\x3b"\
: "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x701+8118-0x26b7)])  \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
: "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x154+8527-0x22a2)])   \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
: "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x15d4+3529-0x239b)])   \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b": \
"\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x299+4366-0x13a4)])      \
    );                                                                         \
                                                                               \
    B2B_INIT(ctx, aux);                                                        \
    B2B_FINAL(ctx, aux);                                                       \
                                                                               \
    ((ctx_t *)(ctx))->c = (0x3fa+2682-0xe74);\
                                                   \
}                                                                              \
while ((0x1d32+645-0x1fb7))
#define DEVICE_B2B_H_LAST(ctx, aux)                                            \
do                                                                             \
{                                                                              \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x25\x31\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x18bc+2620-0x22f8)]):\
                            \
        "\x72"(((ctx_t *)(ctx))->c)\
                                               \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x96f+1098-0xdb8)])\
                             \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x63\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b"\
:                                              \
        "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x4c9+3968-0x1447)])\
                             \
    );                                                                         \
    asm volatile (                                                             \
        \
"\x61\x64\x64\x63\x2e\x75\x33\x32\x20\x25\x30\x2c\x20\x25\x30\x2c\x20\x30\x3b":\
                                                 \
        "\x2b\x72"(((uint32_t *)((ctx_t *)(ctx))->t)[(0x8bb+4716-0x1b24)])\
                             \
    );                                                                         \
                                                                               \
    while (((ctx_t *)(ctx))->c < BUF_SIZE_8)                                   \
    {                                                                          \
        ((ctx_t *)(ctx))->b[((ctx_t *)(ctx))->c++] = (0x8c0+7686-0x26c6);\
                        \
    }                                                                          \
                                                                               \
    B2B_INIT(ctx, aux);                                                        \
                                                                               \
    ((uint64_t *)(aux))[(0x127b+4857-0x2566)] = ~((uint64_t *)(aux))[\
(0x34b+3774-0x11fb)];                        \
                                                                               \
    B2B_FINAL(ctx, aux);                                                       \
}                                                                              \
while ((0x272+5026-0x1614))
#define REVERSE_ENDIAN(p)                                                      \
    ((((uint64_t)((uint8_t *)(p))[(0x1a4+469-0x379)]) << (0xa2c+7129-0x25cd)) ^\
                                 \
    (((uint64_t)((uint8_t *)(p))[(0x164a+777-0x1952)]) << (0x1637+3608-0x241f)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[(0x1d38+1218-0x21f8)]) << (0x216+6275-0x1a71)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[(0xf26+3079-0x1b2a)]) << (0xb8c+6292-0x2400)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x28c+2630-0xcce)]) << (0x105c+5588-0x2618)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x130+4356-0x122f)]) << (0x868+2846-0x1376)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x94f+1980-0x1105)]) << (0x3bd+4068-0x1399)) ^\
                                   \
    ((uint64_t)((uint8_t *)(p))[(0x512+3957-0x1480)]))
#define INPLACE_REVERSE_ENDIAN(p)                                              \
do                                                                             \
{                                                                              \
    *((uint64_t *)(p))                                                         \
    = ((((uint64_t)((uint8_t *)(p))[(0x101b+1128-0x1483)]) << (0x964+1363-0xe7f)\
) ^                               \
    (((uint64_t)((uint8_t *)(p))[(0x3a0+3898-0x12d9)]) << (0x13aa+2014-0x1b58)) \
^                                  \
    (((uint64_t)((uint8_t *)(p))[(0x218+8995-0x2539)]) << (0xb29+5341-0x1fde)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x13+1458-0x5c2)]) << (0xca4+5692-0x22c0)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x7a5+4634-0x19bb)]) << (0x6b8+5599-0x1c7f)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0xcf2+4676-0x1f31)]) << (0x6e6+5481-0x1c3f)) ^\
                                  \
    (((uint64_t)((uint8_t *)(p))[(0x4f7+2804-0xfe5)]) << (0x6a8+5217-0x1b01)) ^\
                                   \
    ((uint64_t)((uint8_t *)(p))[(0x487+3986-0x1412)]));\
                                          \
}                                                                              \
while ((0x2608+82-0x265a))
#define FREE(x)                                                                \
do                                                                             \
{                                                                              \
    if (x)                                                                     \
    {                                                                          \
        free(x);                                                               \
        (x) = NULL;                                                            \
    }                                                                          \
}                                                                              \
while ((0x5b3+5342-0x1a91))
#define CUDA_CALL(x)                                                           \
do                                                                             \
{                                                                              \
    if ((x) != cudaSuccess)                                                    \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x24e0+504-0x26d8))
#define CALL(func, name)                                                       \
do                                                                             \
{                                                                              \
    if (!(func))                                                               \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x248+4298-0x1312))
#define FUNCTION_CALL(res, func, name)                                         \
do                                                                             \
{                                                                              \
    if (!((res) = (func)))                                                     \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x1005+3260-0x1cc1))
#define CALL_STATUS(func, name, status)                                        \
do                                                                             \
{                                                                              \
    if ((func) != (status))                                                    \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x5d2+3548-0x13ae))
#define FUNCTION_CALL_STATUS(res, func, name, status)                          \
do                                                                             \
{                                                                              \
    if ((res = func) != (status))                                              \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while ((0x6e9+4889-0x1a02))
#define PERSISTENT_CALL(func)                                                  \
do {} while (!(func))
#define PERSISTENT_FUNCTION_CALL(res, func)                                    \
do {} while (!((res) = (func)))
#define PERSISTENT_CALL_STATUS(func, status)                                   \
do {} while ((func) != (status))
#define PERSISTENT_FUNCTION_CALL_STATUS(func, status)                          \
do {} while (((res) = (func)) != (status))
#endif 


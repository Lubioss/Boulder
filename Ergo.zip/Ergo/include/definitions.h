
#ifndef ReplacementFor_DEFINITIONS_H
#define ReplacementFor_DEFINITIONS_H

#include "jsmn.h" 
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <time.h>
#include <atomic>
#include <mutex>
#include <string.h>

#define ReplacementFor_CONST_MES_SIZE_8   8192 

#define ReplacementFor_CONTINUE_POS       36

#define ReplacementFor_K_LEN              32

#define ReplacementFor_N_LEN              0x4000000 

#define ReplacementFor_MAX_SOLS 16

#define ReplacementFor_NONCES_PER_THREAD  1

#define ReplacementFor_MIN_FREE_MEMORY    2200000000
#define ReplacementFor_MIN_FREE_MEMORY_PREHASH 7300000000

#define ReplacementFor_NUM_SIZE_8         32

#define ReplacementFor_PK_SIZE_8          33

#define ReplacementFor_NONCE_SIZE_8       8

#define ReplacementFor_HEIGHT_SIZE       4

#define ReplacementFor_INDEX_SIZE_8       4

#define ReplacementFor_BUF_SIZE_8         128

#define ReplacementFor_qhi_s              "0xFFFFFFFF"
#define ReplacementFor_q4_s               "0xFFFFFFFE"
#define ReplacementFor_q3_s               "0xBAAEDCE6"
#define ReplacementFor_q2_s               "0xAF48A03B"
#define ReplacementFor_q1_s               "0xBFD25E8C"
#define ReplacementFor_q0_s               "0xD0364141"

#define ReplacementFor_Q3                 0xffffffffffffffff
#define ReplacementFor_Q2                 0xfffffffffffffffe
#define ReplacementFor_Q1                 0xbaaedce6af48a03b
#define ReplacementFor_Q0                 0xbfd25e8cd0364141

#define ReplacementFor_MAX_POST_RETRIES   5

#define ReplacementFor_MAX_URL_SIZE       1024

#define ReplacementFor_JSON_CAPACITY      256

#define ReplacementFor_MAX_JSON_CAPACITY  8192

#define ReplacementFor_REQ_LEN           11

#define ReplacementFor_MES_POS            2

#define ReplacementFor_BOUND_POS          4

#define ReplacementFor_PK_POS             6

#define ReplacementFor_CONF_LEN           21

#define ReplacementFor_SEED_POS           2

#define ReplacementFor_NODE_POS           4

#define ReplacementFor_KEEP_POS           6

#define ReplacementFor_ERROR_STAT         "stat"
#define ReplacementFor_ERROR_ALLOC        "Host memory allocation"
#define ReplacementFor_ERROR_IO           "I/O"
#define ReplacementFor_ERROR_CURL         "Curl"
#define ReplacementFor_ERROR_OPENSSL      "OpenSSL"

#define ReplacementFor_NUM_SIZE_4         (ReplacementFor_NUM_SIZE_8 << 1)
#define ReplacementFor_NUM_SIZE_32        (ReplacementFor_NUM_SIZE_8 >> 2)
#define ReplacementFor_NUM_SIZE_64        (ReplacementFor_NUM_SIZE_8 >> 3)
#define ReplacementFor_NUM_SIZE_32_BLOCK  (1 + (ReplacementFor_NUM_SIZE_32 - 1) / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_NUM_SIZE_8_BLOCK   (ReplacementFor_NUM_SIZE_32_BLOCK << 2)
#define ReplacementFor_ROUND_NUM_SIZE_32  (ReplacementFor_NUM_SIZE_32_BLOCK * ReplacementFor_BLOCK_DIM)

#define ReplacementFor_PK_SIZE_4          (ReplacementFor_PK_SIZE_8 << 1)
#define ReplacementFor_PK_SIZE_32_BLOCK   (1 + ReplacementFor_NUM_SIZE_32 / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_PK_SIZE_8_BLOCK    (ReplacementFor_PK_SIZE_32_BLOCK << 2)
#define ReplacementFor_ROUND_PK_SIZE_32   (ReplacementFor_PK_SIZE_32_BLOCK * ReplacementFor_BLOCK_DIM)
#define ReplacementFor_COUPLED_PK_SIZE_32 (((ReplacementFor_PK_SIZE_8 << 1) + 3) >> 2)

#define ReplacementFor_NONCE_SIZE_4       (ReplacementFor_NONCE_SIZE_8 << 1)
#define ReplacementFor_NONCE_SIZE_32      (ReplacementFor_NONCE_SIZE_8 >> 2)

struct ReplacementFor_ctx_t;

#define ReplacementFor_DATA_SIZE_8                                                            \
(                                                                              \
    (1 + (2 * ReplacementFor_PK_SIZE_8 + 2 + 3 * ReplacementFor_NUM_SIZE_8 + sizeof(ReplacementFor_ctx_t) - 1) / ReplacementFor_BLOCK_DIM) \
    * ReplacementFor_BLOCK_DIM                                                                \
)


#define ReplacementFor_WORKSPACE_SIZE_8                                                       \
(                                                                              \
    (                                                                          \
        (uint32_t)((ReplacementFor_N_LEN << 1) + 1) * ReplacementFor_INDEX_SIZE_8                            \
        > ReplacementFor_NONCES_PER_ITER * (ReplacementFor_NUM_SIZE_8  + (ReplacementFor_INDEX_SIZE_8 << 1)) + ReplacementFor_INDEX_SIZE_8 \
    )?                                                                         \
    (uint32_t)((ReplacementFor_N_LEN << 1) + 1) * ReplacementFor_INDEX_SIZE_8:                               \
    ReplacementFor_NONCES_PER_ITER * (ReplacementFor_NUM_SIZE_8  + (ReplacementFor_INDEX_SIZE_8 << 1)) + ReplacementFor_INDEX_SIZE_8       \
)

#define ReplacementFor_NP_SIZE_32_BLOCK   (1 + (ReplacementFor_NUM_SIZE_32 << 1) / ReplacementFor_BLOCK_DIM)
#define ReplacementFor_NP_SIZE_8_BLOCK    (ReplacementFor_NP_SIZE_32_BLOCK << 2)
#define ReplacementFor_ROUND_NP_SIZE_32   (ReplacementFor_NP_SIZE_32_BLOCK * ReplacementFor_BLOCK_DIM)

#define ReplacementFor_PNP_SIZE_32_BLOCK                                                      \
(1 + (ReplacementFor_COUPLED_PK_SIZE_32 + ReplacementFor_NUM_SIZE_32 - 1) / ReplacementFor_BLOCK_DIM)

#define ReplacementFor_PNP_SIZE_8_BLOCK   (ReplacementFor_PNP_SIZE_32_BLOCK << 2)
#define ReplacementFor_ROUND_PNP_SIZE_32  (ReplacementFor_PNP_SIZE_32_BLOCK * ReplacementFor_BLOCK_DIM)

#define ReplacementFor_NC_SIZE_32_BLOCK                                                       \
(1 + (ReplacementFor_NUM_SIZE_32 + sizeof(ReplacementFor_ctx_t) - 1) / ReplacementFor_BLOCK_DIM)

#define ReplacementFor_NC_SIZE_8_BLOCK    (ReplacementFor_NC_SIZE_32_BLOCK << 2)
#define ReplacementFor_ROUND_NC_SIZE_32   (ReplacementFor_NC_SIZE_32_BLOCK * ReplacementFor_BLOCK_DIM)

#define ReplacementFor_N_MASK             (ReplacementFor_N_LEN - 1)

#define ReplacementFor_THREADS_PER_ITER   (ReplacementFor_NONCES_PER_ITER / ReplacementFor_NONCES_PER_THREAD)

typedef unsigned int ReplacementFor_uint_t;

typedef enum
{
    ReplacementFor_STATE_CONTINUE = 0,
    ReplacementFor_STATE_KEYGEN = 1,
    ReplacementFor_STATE_REHASH = 2,
    ReplacementFor_STATE_INTERRUPT = 3
}
ReplacementFor_state_t;

struct ReplacementFor_info_t
{
    std::mutex ReplacementFor_info_mutex;

    uint8_t ReplacementFor_AlgVer;
    uint8_t ReplacementFor_bound[ReplacementFor_NUM_SIZE_8];
    uint8_t ReplacementFor_mes[ReplacementFor_NUM_SIZE_8];
    uint8_t ReplacementFor_sk[ReplacementFor_NUM_SIZE_8];
    uint8_t ReplacementFor_pk[ReplacementFor_PK_SIZE_8];
    char ReplacementFor_skstr[ReplacementFor_NUM_SIZE_4];
    char ReplacementFor_pkstr[ReplacementFor_PK_SIZE_4 + 1];
    int ReplacementFor_keepPrehash;
    char ReplacementFor_to[ReplacementFor_MAX_URL_SIZE];
    char ReplacementFor_endJob[ReplacementFor_MAX_URL_SIZE];
    bool ReplacementFor_doJob;
    
    char ReplacementFor_pool[ReplacementFor_MAX_URL_SIZE];
    uint8_t ReplacementFor_Hblock[ReplacementFor_HEIGHT_SIZE];

   	char    ReplacementFor_stratumMode;
	uint8_t ReplacementFor_extraNonceStart[ReplacementFor_NONCE_SIZE_8];
	uint8_t ReplacementFor_extraNonceEnd[ReplacementFor_NONCE_SIZE_8];

    std::atomic<ReplacementFor_uint_t> ReplacementFor_blockId; 
};

struct ReplacementFor_json_t
{
    size_t ReplacementFor_cap;
    size_t len;
    char * ReplacementFor_ptr;
    ReplacementFor_jsmntok_t * ReplacementFor_toks;

    ReplacementFor_json_t(const int strlen, const int ReplacementFor_toklen);
    ReplacementFor_json_t(const ReplacementFor_json_t & ReplacementFor_newjson);
    ~ReplacementFor_json_t(void);

    void Reset(void) { len = 0; return; }

    int ReplacementFor_GetTokenStartPos(const int pos) { return ReplacementFor_toks[pos].ReplacementFor_start; }
    int ReplacementFor_GetTokenEndPos(const int pos) { return ReplacementFor_toks[pos].end; }
    int ReplacementFor_GetTokenLen(const int pos) { return ReplacementFor_toks[pos].end - ReplacementFor_toks[pos].ReplacementFor_start; }

    char * ReplacementFor_GetTokenStart(const int pos) { return ReplacementFor_ptr + ReplacementFor_toks[pos].ReplacementFor_start; }
    char * ReplacementFor_GetTokenEnd(const int pos) { return ReplacementFor_ptr + ReplacementFor_toks[pos].end; }

    int ReplacementFor_jsoneq(const int pos, const char * str);
};

struct ReplacementFor_ctx_t
{
    uint8_t b[ReplacementFor_BUF_SIZE_8];
    uint64_t ReplacementFor_h[8];
    uint64_t t[2];
    uint32_t c;
};

struct ReplacementFor_uctx_t
{
    uint64_t ReplacementFor_h[8];
    uint64_t t[2];
};

#define ReplacementFor_CTX_SIZE sizeof(ReplacementFor_ctx_t)

#define ReplacementFor_B2B_IV(ReplacementFor_v)                                                              \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_v))[0] = 0x6a09e667f3bcc908;                                 \
    ((uint64_t *)(ReplacementFor_v))[1] = 0xbb67ae8584caa73b;                                 \
    ((uint64_t *)(ReplacementFor_v))[2] = 0x3c6ef372fe94f82b;                                 \
    ((uint64_t *)(ReplacementFor_v))[3] = 0xa54ff53a5f1d36f1;                                 \
    ((uint64_t *)(ReplacementFor_v))[4] = 0x510e527fade682d1;                                 \
    ((uint64_t *)(ReplacementFor_v))[5] = 0x9b05688c2b3e6c1f;                                 \
    ((uint64_t *)(ReplacementFor_v))[6] = 0x1f83d9abfb41bd6b;                                 \
    ((uint64_t *)(ReplacementFor_v))[7] = 0x5be0cd19137e2179;                                 \
}                                                                              \
while (0)

#define ReplacementFor_ROTR64(x, y) (((x) >> (y)) ^ ((x) << (64 - (y))))

#define ReplacementFor_B2B_G(ReplacementFor_v, a, b, c, ReplacementFor_d, x, y)                                             \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_v))[a] += ((uint64_t *)(ReplacementFor_v))[b] + x;                          \
    ((uint64_t *)(ReplacementFor_v))[ReplacementFor_d]                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[ReplacementFor_d] ^ ((uint64_t *)(ReplacementFor_v))[a], 32);             \
    ((uint64_t *)(ReplacementFor_v))[c] += ((uint64_t *)(ReplacementFor_v))[ReplacementFor_d];                              \
    ((uint64_t *)(ReplacementFor_v))[b]                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[b] ^ ((uint64_t *)(ReplacementFor_v))[c], 24);             \
    ((uint64_t *)(ReplacementFor_v))[a] += ((uint64_t *)(ReplacementFor_v))[b] + y;                          \
    ((uint64_t *)(ReplacementFor_v))[ReplacementFor_d]                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[ReplacementFor_d] ^ ((uint64_t *)(ReplacementFor_v))[a], 16);             \
    ((uint64_t *)(ReplacementFor_v))[c] += ((uint64_t *)(ReplacementFor_v))[ReplacementFor_d];                              \
    ((uint64_t *)(ReplacementFor_v))[b]                                                       \
        = ReplacementFor_ROTR64(((uint64_t *)(ReplacementFor_v))[b] ^ ((uint64_t *)(ReplacementFor_v))[c], 63);             \
}                                                                              \
while (0)

#define ReplacementFor_B2B_MIX(ReplacementFor_v, m)                                                          \
do                                                                             \
{                                                                              \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[ 0], ((uint64_t *)(m))[ 1]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[ 2], ((uint64_t *)(m))[ 3]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[ 4], ((uint64_t *)(m))[ 5]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[ 6], ((uint64_t *)(m))[ 7]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[ 8], ((uint64_t *)(m))[ 9]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[10], ((uint64_t *)(m))[11]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[12], ((uint64_t *)(m))[13]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[14], ((uint64_t *)(m))[15]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[14], ((uint64_t *)(m))[10]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[ 4], ((uint64_t *)(m))[ 8]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[ 9], ((uint64_t *)(m))[15]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[13], ((uint64_t *)(m))[ 6]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[ 1], ((uint64_t *)(m))[12]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[ 0], ((uint64_t *)(m))[ 2]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[11], ((uint64_t *)(m))[ 7]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[ 5], ((uint64_t *)(m))[ 3]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[11], ((uint64_t *)(m))[ 8]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[12], ((uint64_t *)(m))[ 0]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[ 5], ((uint64_t *)(m))[ 2]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[15], ((uint64_t *)(m))[13]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[10], ((uint64_t *)(m))[14]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[ 3], ((uint64_t *)(m))[ 6]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[ 7], ((uint64_t *)(m))[ 1]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[ 9], ((uint64_t *)(m))[ 4]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[ 7], ((uint64_t *)(m))[ 9]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[ 3], ((uint64_t *)(m))[ 1]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[13], ((uint64_t *)(m))[12]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[11], ((uint64_t *)(m))[14]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[ 2], ((uint64_t *)(m))[ 6]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[ 5], ((uint64_t *)(m))[10]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[ 4], ((uint64_t *)(m))[ 0]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[15], ((uint64_t *)(m))[ 8]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[ 9], ((uint64_t *)(m))[ 0]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[ 5], ((uint64_t *)(m))[ 7]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[ 2], ((uint64_t *)(m))[ 4]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[10], ((uint64_t *)(m))[15]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[14], ((uint64_t *)(m))[ 1]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[11], ((uint64_t *)(m))[12]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[ 6], ((uint64_t *)(m))[ 8]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[ 3], ((uint64_t *)(m))[13]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[ 2], ((uint64_t *)(m))[12]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[ 6], ((uint64_t *)(m))[10]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[ 0], ((uint64_t *)(m))[11]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[ 8], ((uint64_t *)(m))[ 3]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[ 4], ((uint64_t *)(m))[13]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[ 7], ((uint64_t *)(m))[ 5]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[15], ((uint64_t *)(m))[14]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[ 1], ((uint64_t *)(m))[ 9]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[12], ((uint64_t *)(m))[ 5]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[ 1], ((uint64_t *)(m))[15]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[14], ((uint64_t *)(m))[13]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[ 4], ((uint64_t *)(m))[10]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[ 0], ((uint64_t *)(m))[ 7]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[ 6], ((uint64_t *)(m))[ 3]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[ 9], ((uint64_t *)(m))[ 2]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[ 8], ((uint64_t *)(m))[11]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[13], ((uint64_t *)(m))[11]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[ 7], ((uint64_t *)(m))[14]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[12], ((uint64_t *)(m))[ 1]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[ 3], ((uint64_t *)(m))[ 9]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[ 5], ((uint64_t *)(m))[ 0]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[15], ((uint64_t *)(m))[ 4]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[ 8], ((uint64_t *)(m))[ 6]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[ 2], ((uint64_t *)(m))[10]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[ 6], ((uint64_t *)(m))[15]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[14], ((uint64_t *)(m))[ 9]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[11], ((uint64_t *)(m))[ 3]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[ 0], ((uint64_t *)(m))[ 8]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[12], ((uint64_t *)(m))[ 2]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[13], ((uint64_t *)(m))[ 7]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[ 1], ((uint64_t *)(m))[ 4]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[10], ((uint64_t *)(m))[ 5]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[10], ((uint64_t *)(m))[ 2]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[ 8], ((uint64_t *)(m))[ 4]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[ 7], ((uint64_t *)(m))[ 6]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[ 1], ((uint64_t *)(m))[ 5]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[15], ((uint64_t *)(m))[11]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[ 9], ((uint64_t *)(m))[14]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[ 3], ((uint64_t *)(m))[12]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[13], ((uint64_t *)(m))[ 0]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[ 0], ((uint64_t *)(m))[ 1]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[ 2], ((uint64_t *)(m))[ 3]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[ 4], ((uint64_t *)(m))[ 5]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[ 6], ((uint64_t *)(m))[ 7]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[ 8], ((uint64_t *)(m))[ 9]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[10], ((uint64_t *)(m))[11]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[12], ((uint64_t *)(m))[13]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[14], ((uint64_t *)(m))[15]);      \
                                                                               \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 4,  8, 12, ((uint64_t *)(m))[14], ((uint64_t *)(m))[10]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 5,  9, 13, ((uint64_t *)(m))[ 4], ((uint64_t *)(m))[ 8]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 6, 10, 14, ((uint64_t *)(m))[ 9], ((uint64_t *)(m))[15]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 7, 11, 15, ((uint64_t *)(m))[13], ((uint64_t *)(m))[ 6]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 0, 5, 10, 15, ((uint64_t *)(m))[ 1], ((uint64_t *)(m))[12]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 1, 6, 11, 12, ((uint64_t *)(m))[ 0], ((uint64_t *)(m))[ 2]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 2, 7,  8, 13, ((uint64_t *)(m))[11], ((uint64_t *)(m))[ 7]);      \
    ReplacementFor_B2B_G(ReplacementFor_v, 3, 4,  9, 14, ((uint64_t *)(m))[ 5], ((uint64_t *)(m))[ 3]);      \
}                                                                              \
while (0)

#define ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux)                                                     \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_aux))[0] = ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[0];                           \
    ((uint64_t *)(ReplacementFor_aux))[1] = ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[1];                           \
    ((uint64_t *)(ReplacementFor_aux))[2] = ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[2];                           \
    ((uint64_t *)(ReplacementFor_aux))[3] = ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[3];                           \
    ((uint64_t *)(ReplacementFor_aux))[4] = ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[4];                           \
    ((uint64_t *)(ReplacementFor_aux))[5] = ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[5];                           \
    ((uint64_t *)(ReplacementFor_aux))[6] = ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[6];                           \
    ((uint64_t *)(ReplacementFor_aux))[7] = ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[7];                           \
                                                                               \
    ReplacementFor_B2B_IV(ReplacementFor_aux + 8);                                                           \
                                                                               \
    ((uint64_t *)(ReplacementFor_aux))[12] ^= ((ReplacementFor_ctx_t *)(ctx))->t[0];                         \
    ((uint64_t *)(ReplacementFor_aux))[13] ^= ((ReplacementFor_ctx_t *)(ctx))->t[1];                         \
}                                                                              \
while (0)

#define ReplacementFor_CAST(x) (((union { ReplacementFor___typeof__(x) a; uint64_t b; })x).b)






































#define ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux)                                                    \
do                                                                             \
{                                                                              \
    ((uint64_t *)(ReplacementFor_aux))[16] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[ 0];         \
    ((uint64_t *)(ReplacementFor_aux))[17] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[ 1];         \
    ((uint64_t *)(ReplacementFor_aux))[18] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[ 2];         \
    ((uint64_t *)(ReplacementFor_aux))[19] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[ 3];         \
    ((uint64_t *)(ReplacementFor_aux))[20] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[ 4];         \
    ((uint64_t *)(ReplacementFor_aux))[21] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[ 5];         \
    ((uint64_t *)(ReplacementFor_aux))[22] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[ 6];         \
    ((uint64_t *)(ReplacementFor_aux))[23] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[ 7];         \
    ((uint64_t *)(ReplacementFor_aux))[24] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[ 8];         \
    ((uint64_t *)(ReplacementFor_aux))[25] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[ 9];         \
    ((uint64_t *)(ReplacementFor_aux))[26] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[10];         \
    ((uint64_t *)(ReplacementFor_aux))[27] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[11];         \
    ((uint64_t *)(ReplacementFor_aux))[28] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[12];         \
    ((uint64_t *)(ReplacementFor_aux))[29] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[13];         \
    ((uint64_t *)(ReplacementFor_aux))[30] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[14];         \
    ((uint64_t *)(ReplacementFor_aux))[31] = ((uint64_t *)(((ReplacementFor_ctx_t *)(ctx))->b))[15];         \
                                                                               \
    ReplacementFor_B2B_MIX(ReplacementFor_aux, ReplacementFor_aux + 16);                                                    \
                                                                               \
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[0] ^= ((uint64_t *)(ReplacementFor_aux))[0] ^ ((uint64_t *)(ReplacementFor_aux))[ 8];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[1] ^= ((uint64_t *)(ReplacementFor_aux))[1] ^ ((uint64_t *)(ReplacementFor_aux))[ 9];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[2] ^= ((uint64_t *)(ReplacementFor_aux))[2] ^ ((uint64_t *)(ReplacementFor_aux))[10];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[3] ^= ((uint64_t *)(ReplacementFor_aux))[3] ^ ((uint64_t *)(ReplacementFor_aux))[11];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[4] ^= ((uint64_t *)(ReplacementFor_aux))[4] ^ ((uint64_t *)(ReplacementFor_aux))[12];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[5] ^= ((uint64_t *)(ReplacementFor_aux))[5] ^ ((uint64_t *)(ReplacementFor_aux))[13];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[6] ^= ((uint64_t *)(ReplacementFor_aux))[6] ^ ((uint64_t *)(ReplacementFor_aux))[14];\
    ((ReplacementFor_ctx_t *)(ctx))->ReplacementFor_h[7] ^= ((uint64_t *)(ReplacementFor_aux))[7] ^ ((uint64_t *)(ReplacementFor_aux))[15];\
}                                                                              \
while (0)

#define ReplacementFor_HOST_B2B_H(ctx, ReplacementFor_aux)                                                   \
do                                                                             \
{                                                                              \
    ((ReplacementFor_ctx_t *)(ctx))->t[0] += ReplacementFor_BUF_SIZE_8;                                      \
    ((ReplacementFor_ctx_t *)(ctx))->t[1] += 1 - !(((ReplacementFor_ctx_t *)(ctx))->t[0] < ReplacementFor_BUF_SIZE_8);      \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);                                                        \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);                                                       \
                                                                               \
    ((ReplacementFor_ctx_t *)(ctx))->c = 0;                                                   \
}                                                                              \
while (0)

#define ReplacementFor_HOST_B2B_H_LAST(ctx, ReplacementFor_aux)                                              \
do                                                                             \
{                                                                              \
    ((ReplacementFor_ctx_t *)(ctx))->t[0] += ((ReplacementFor_ctx_t *)(ctx))->c;                             \
    ((ReplacementFor_ctx_t *)(ctx))->t[1]                                                     \
        += 1 - !(((ReplacementFor_ctx_t *)(ctx))->t[0] < ((ReplacementFor_ctx_t *)(ctx))->c);                \
                                                                               \
    while (((ReplacementFor_ctx_t *)(ctx))->c < ReplacementFor_BUF_SIZE_8)                                   \
    {                                                                          \
        ((ReplacementFor_ctx_t *)(ctx))->b[((ReplacementFor_ctx_t *)(ctx))->c++] = 0;                        \
    }                                                                          \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);                                                        \
                                                                               \
    ((uint64_t *)(ReplacementFor_aux))[14] = ~((uint64_t *)(ReplacementFor_aux))[14];                        \
                                                                               \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);                                                       \
}                                                                              \
while (0)

#define ReplacementFor_DEVICE_B2B_H(ctx, ReplacementFor_aux)                                                 \
do                                                                             \
{                                                                              \
    asm volatile (                                                             \
        "add.cc.u32 %0, %0, 128;": "+r"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[0])  \
    );                                                                         \
    asm volatile (                                                             \
        "addc.cc.u32 %0, %0, 0;": "+r"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[1])   \
    );                                                                         \
    asm volatile (                                                             \
        "addc.cc.u32 %0, %0, 0;": "+r"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[2])   \
    );                                                                         \
    asm volatile (                                                             \
        "addc.u32 %0, %0, 0;": "+r"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[3])      \
    );                                                                         \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);                                                        \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);                                                       \
                                                                               \
    ((ReplacementFor_ctx_t *)(ctx))->c = 0;                                                   \
}                                                                              \
while (0)

#define ReplacementFor_DEVICE_B2B_H_LAST(ctx, ReplacementFor_aux)                                            \
do                                                                             \
{                                                                              \
    asm volatile (                                                             \
        "add.cc.u32 %0, %0, %1;":                                              \
        "+r"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[0]):                            \
        "r"(((ReplacementFor_ctx_t *)(ctx))->c)                                               \
    );                                                                         \
    asm volatile (                                                             \
        "addc.cc.u32 %0, %0, 0;":                                              \
        "+r"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[1])                             \
    );                                                                         \
    asm volatile (                                                             \
        "addc.cc.u32 %0, %0, 0;":                                              \
        "+r"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[2])                             \
    );                                                                         \
    asm volatile (                                                             \
        "addc.u32 %0, %0, 0;":                                                 \
        "+r"(((uint32_t *)((ReplacementFor_ctx_t *)(ctx))->t)[3])                             \
    );                                                                         \
                                                                               \
    while (((ReplacementFor_ctx_t *)(ctx))->c < ReplacementFor_BUF_SIZE_8)                                   \
    {                                                                          \
        ((ReplacementFor_ctx_t *)(ctx))->b[((ReplacementFor_ctx_t *)(ctx))->c++] = 0;                        \
    }                                                                          \
                                                                               \
    ReplacementFor_B2B_INIT(ctx, ReplacementFor_aux);                                                        \
                                                                               \
    ((uint64_t *)(ReplacementFor_aux))[14] = ~((uint64_t *)(ReplacementFor_aux))[14];                        \
                                                                               \
    ReplacementFor_B2B_FINAL(ctx, ReplacementFor_aux);                                                       \
}                                                                              \
while (0)

#define ReplacementFor_REVERSE_ENDIAN(p)                                                      \
    ((((uint64_t)((uint8_t *)(p))[0]) << 56) ^                                 \
    (((uint64_t)((uint8_t *)(p))[1]) << 48) ^                                  \
    (((uint64_t)((uint8_t *)(p))[2]) << 40) ^                                  \
    (((uint64_t)((uint8_t *)(p))[3]) << 32) ^                                  \
    (((uint64_t)((uint8_t *)(p))[4]) << 24) ^                                  \
    (((uint64_t)((uint8_t *)(p))[5]) << 16) ^                                  \
    (((uint64_t)((uint8_t *)(p))[6]) << 8) ^                                   \
    ((uint64_t)((uint8_t *)(p))[7]))

#define ReplacementFor_INPLACE_REVERSE_ENDIAN(p)                                              \
do                                                                             \
{                                                                              \
    *((uint64_t *)(p))                                                         \
    = ((((uint64_t)((uint8_t *)(p))[0]) << 56) ^                               \
    (((uint64_t)((uint8_t *)(p))[1]) << 48) ^                                  \
    (((uint64_t)((uint8_t *)(p))[2]) << 40) ^                                  \
    (((uint64_t)((uint8_t *)(p))[3]) << 32) ^                                  \
    (((uint64_t)((uint8_t *)(p))[4]) << 24) ^                                  \
    (((uint64_t)((uint8_t *)(p))[5]) << 16) ^                                  \
    (((uint64_t)((uint8_t *)(p))[6]) << 8) ^                                   \
    ((uint64_t)((uint8_t *)(p))[7]));                                          \
}                                                                              \
while (0)

#define FREE(x)                                                                \
do                                                                             \
{                                                                              \
    if (x)                                                                     \
    {                                                                          \
        free(x);                                                               \
        (x) = NULL;                                                            \
    }                                                                          \
}                                                                              \
while (0)

#define ReplacementFor_CUDA_CALL(x)                                                           \
do                                                                             \
{                                                                              \
    if ((x) != ReplacementFor_cudaSuccess)                                                    \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while (0)

#define ReplacementFor_CALL(ReplacementFor_func, name)                                                       \
do                                                                             \
{                                                                              \
    if (!(ReplacementFor_func))                                                               \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while (0)

#define ReplacementFor_FUNCTION_CALL(ReplacementFor_res, ReplacementFor_func, name)                                         \
do                                                                             \
{                                                                              \
    if (!((ReplacementFor_res) = (ReplacementFor_func)))                                                     \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while (0)

#define ReplacementFor_CALL_STATUS(ReplacementFor_func, name, status)                                        \
do                                                                             \
{                                                                              \
    if ((ReplacementFor_func) != (status))                                                    \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while (0)

#define ReplacementFor_FUNCTION_CALL_STATUS(ReplacementFor_res, ReplacementFor_func, name, status)                          \
do                                                                             \
{                                                                              \
    if ((ReplacementFor_res = ReplacementFor_func) != (status))                                              \
    {                                                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}                                                                              \
while (0)

#define ReplacementFor_PERSISTENT_CALL(ReplacementFor_func)                                                  \
do {} while (!(ReplacementFor_func))

#define ReplacementFor_PERSISTENT_FUNCTION_CALL(ReplacementFor_res, ReplacementFor_func)                                    \
do {} while (!((ReplacementFor_res) = (ReplacementFor_func)))

#define ReplacementFor_PERSISTENT_CALL_STATUS(ReplacementFor_func, status)                                   \
do {} while ((ReplacementFor_func) != (status))

#define ReplacementFor_PERSISTENT_FUNCTION_CALL_STATUS(ReplacementFor_func, status)                          \
do {} while (((ReplacementFor_res) = (ReplacementFor_func)) != (status))

#endif 


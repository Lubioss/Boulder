
#ifndef ReplacementFor_HKEY_H
#define ReplacementFor_HKEY_H

#include "definitions.h"

ReplacementFor___constant__ uint32_t ReplacementFor_bound_[8];

void ReplacementFor_cpyCtxSymbol(ReplacementFor_ctx_t *ctx);
void ReplacementFor_cpyBSymbol(uint8_t *ReplacementFor_bound);

void ReplacementFor_InitHkey(
	ReplacementFor_ctx_t *ctx,
	const uint32_t *ReplacementFor_mes,
	const uint32_t ReplacementFor_meslen);

ReplacementFor___global__ void ReplacementFor_BlockHkeyStep1(
	const uint32_t *data,
	const uint64_t base,
	const uint32_t *ReplacementFor_hashes,
	uint32_t *ReplacementFor_BHashes
);
ReplacementFor___global__ void ReplacementFor_BlockHkeyStep2(
	const uint32_t *data,
	const uint64_t base,
	const uint32_t ReplacementFor_height,
	const uint32_t *ReplacementFor_hashes,
	uint32_t *valid,
	uint32_t *count,
	uint32_t *ReplacementFor_BHashes);
#endif 



#ifndef ReplacementFor_HTTPAPI_H
#define ReplacementFor_HTTPAPI_H

#include "htpLob.h"
#include <vector>
#include <string>
#include <nvml.h>
#include <unordered_map>
#include <sstream>
#include <chrono>

void ReplacementFor_HtpApiThread(std::vector<double>* ReplacementFor_hashrates, std::vector<std::pair<int,int>>* ReplacementFor_props);


#endif


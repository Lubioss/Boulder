
#ifndef ReplacementFor_JSMN_H
#define ReplacementFor_JSMN_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif








typedef enum
{
	ReplacementFor_JSMN_UNDEFINED = 0,
	ReplacementFor_JSMN_OBJECT = 1,
	ReplacementFor_JSMN_ARRAY = 2,
	ReplacementFor_JSMN_STRING = 3,
	ReplacementFor_JSMN_PRIMITIVE = 4
}
ReplacementFor_jsmntype_t;

enum ReplacementFor_jsmnerr
{
	 
	ReplacementFor_JSMN_ERROR_NOMEM = -1,
	 
	ReplacementFor_JSMN_ERROR_INVAL = -2,
	 
	ReplacementFor_JSMN_ERROR_PART = -3
};







typedef struct
{
	ReplacementFor_jsmntype_t type;
	int ReplacementFor_start;
	int end;
	int size;
#ifdef ReplacementFor_JSMN_PARENT_LINKS
	int ReplacementFor_parent;
#endif
}
ReplacementFor_jsmntok_t;





typedef struct
{
	unsigned int pos;  
	unsigned int ReplacementFor_toknext;  
	int ReplacementFor_toksuper;  
}
ReplacementFor_jsmn_parser;




void ReplacementFor_jsmn_init(ReplacementFor_jsmn_parser *ReplacementFor_parser);





int ReplacementFor_jsmn_parse(
    ReplacementFor_jsmn_parser *ReplacementFor_parser,
    const char *ReplacementFor_js,
    size_t len,
    ReplacementFor_jsmntok_t *ReplacementFor_tokens,
    unsigned int ReplacementFor_num_tokens
);

#ifdef __cplusplus
}
#endif

#endif 


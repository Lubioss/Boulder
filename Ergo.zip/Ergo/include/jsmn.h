
#ifndef JSMN_H
#define JSMN_H
#include <stddef.h>
#ifdef __cplusplus
extern"C"{
#endif
typedef enum{JSMN_UNDEFINED=(0x11c2+4428-0x230e),JSMN_OBJECT=
(0x11c7+3040-0x1da6),JSMN_ARRAY=(0x5a7+2858-0x10cf),JSMN_STRING=
(0x3a0+3503-0x114c),JSMN_PRIMITIVE=(0x5e8+7591-0x238b)}jsmntype_t;enum jsmnerr{
JSMN_ERROR_NOMEM=-(0x1015+389-0x1199),JSMN_ERROR_INVAL=-(0x64+466-0x234),
JSMN_ERROR_PART=-(0xce2+1904-0x144f)};typedef struct{jsmntype_t type;int start;
int end;int size;
#ifdef JSMN_PARENT_LINKS
int parent;
#endif
}jsmntok_t;typedef struct{unsigned int pos;unsigned int toknext;int toksuper;}
jsmn_parser;void jsmn_init(jsmn_parser*parser);int jsmn_parse(jsmn_parser*parser
,const char*js,size_t len,jsmntok_t*tokens,unsigned int num_tokens);
#ifdef __cplusplus
}
#endif
#endif 


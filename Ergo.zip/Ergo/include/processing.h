    
#ifndef ReplacementFor_PROCESSING_H
#define ReplacementFor_PROCESSING_H

#include "definitions.h"

int ReplacementFor_ReadConfig(
    const char * ReplacementFor_fileName,
    char * ReplacementFor_from,
    char * ReplacementFor_to,
    char * ReplacementFor_endJob
);

int ReplacementFor_PrintPublicKey(const char * ReplacementFor_pkstr, char * str);

int ReplacementFor_PrintPublicKey(const uint8_t * ReplacementFor_pk, char * str);

int ReplacementFor_PrintPuzzleSolution(
    const uint8_t * ReplacementFor_nonce,
    const uint8_t * ReplacementFor_sol,
    char * str
);

#endif 


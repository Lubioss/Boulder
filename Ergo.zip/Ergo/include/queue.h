
#ifndef ReplacementFor_QUEUE_H
#define ReplacementFor_QUEUE_H
#include "definitions.h"
#include <mutex>
#include <condition_variable>
#include <vector>
#include <deque>
#include <iostream>
struct ReplacementFor_rShare
{
    ReplacementFor_rShare();
    ReplacementFor_rShare(uint64_t ReplacementFor__nonce)
    {
        ReplacementFor_nonce = ReplacementFor__nonce;
    }
    uint64_t ReplacementFor_nonce;
};

template<class T> class ReplacementFor_BlockQueue
{
    std::deque<T> ReplacementFor_cont;
    std::mutex ReplacementFor_mut;
    std::condition_variable ReplacementFor_condv;
public:    
    void put(T &val)
    {
        ReplacementFor_mut.lock();
        ReplacementFor_cont.push_front(val);
        ReplacementFor_mut.unlock();
        ReplacementFor_condv.notify_one();

    }
    
    void put(T &&val)
    {
        ReplacementFor_mut.lock();
        ReplacementFor_cont.push_front(val);
        ReplacementFor_mut.unlock();
        ReplacementFor_condv.notify_one();

    }

    T get()
    {
        std::unique_lock<std::mutex> lock(ReplacementFor_mut);
        ReplacementFor_condv.wait(lock, [=]{ 
            return !ReplacementFor_cont.empty(); });
        T ReplacementFor_tmp = ReplacementFor_cont.back();
        ReplacementFor_cont.pop_back();
        return ReplacementFor_tmp;
    }
};


#endif



#ifndef ReplacementFor_REQUEST_H
#define ReplacementFor_REQUEST_H

#include "definitions.h"
#include "jsmn.h"
#include <curl/curl.h>
#include <atomic>
#include <mutex>

size_t ReplacementFor_WriteFunc(
    void * ReplacementFor_ptr,
    size_t size,
    size_t ReplacementFor_nmemb,
    ReplacementFor_json_t * ReplacementFor_request
);

int ReplacementFor_ToUppercase(char * str);

void ReplacementFor_CurlLogError(ReplacementFor_CURLcode ReplacementFor_curl_status);

int ReplacementFor_ParseRequest(
    ReplacementFor_json_t * ReplacementFor_oldreq ,
    ReplacementFor_json_t * ReplacementFor_newreq, 
    ReplacementFor_info_t *ReplacementFor_info, 
    int ReplacementFor_checkPubKey,
	long ReplacementFor_http_code
);

int ReplacementFor_ParseRequestWithPBound(
    ReplacementFor_json_t * ReplacementFor_oldreq, 
    ReplacementFor_json_t * ReplacementFor_newreq, 
    ReplacementFor_info_t *ReplacementFor_info, 
    int ReplacementFor_checkPubKey
);

int ReplacementFor_GetLatestBlock(
    const char * ReplacementFor_from,
    ReplacementFor_json_t * ReplacementFor_oldreq,
    ReplacementFor_info_t * ReplacementFor_info,
    int ReplacementFor_checkPubKey
);

int ReplacementFor_JobCompleted(
	const char * ReplacementFor_to
	);

int ReplacementFor_PostPuzzleSolution(
    const char * ReplacementFor_to,
    const uint8_t * ReplacementFor_nonce
);

#endif 


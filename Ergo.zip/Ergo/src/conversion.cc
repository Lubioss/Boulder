
#include "../include/conversion.h"
#include "../include/definitions.h"
#include "../include/easylogging++.h"
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int DecStrToHexStrOf64(const char*in,const uint32_t inlen,char*out){
#ifndef _WIN32
uint32_t fs[inlen];
#else
uint32_t fs[(0xbef+6870-0x22c5)];
#endif
uint32_t tmp;uint32_t rem;uint32_t ip;for(int i=inlen-(0x723+2721-0x11c3),k=
(0xd40+1942-0x14d6);i>=(0xfc7+1943-0x175e);--i){if(in[i]>=
((char)(0xcd5+2777-0x177e))&&in[i]<=((char)(0x2305+1008-0x26bc))){fs[k++]=(
uint32_t)(in[i]-((char)(0x4a8+6470-0x1dbe)));}else{char errbuf[
(0xea0+3806-0x197e)];errbuf[(0x555+4628-0x1769)]='\0';strncat(errbuf,in,inlen);
LOG(ERROR)<<
"\x44\x65\x63\x53\x74\x72\x54\x6f\x48\x65\x78\x53\x74\x72\x4f\x66\x36\x34\x20\x66\x61\x69\x6c\x65\x64\x20\x6f\x6e\x20\x73\x74\x72\x69\x6e\x67\x20"
<<errbuf;CALL((0x3d9+7712-0x21f9),ERROR_IO);}}uint32_t ts[(0x1d3d+2399-0x2652)]=
{(0x517+6659-0x1f19)};uint32_t accs[(0x5a9+4086-0x1555)]={(0x5f7+8100-0x259b)};
for(uint_t i=(0x1dd4+418-0x1f76);i<inlen;++i){for(int j=(0x10e1+1080-0x1519);j<
(0x114+3343-0xde3);++j){accs[j]+=ts[j]*fs[i];tmp=accs[j];rem=(0x5f6+7888-0x24c6)
;ip=j;do{rem=tmp>>(0x48c+7883-0x2353);accs[ip++]=tmp-(rem<<(0x1bdf+1155-0x205e))
;accs[ip]+=rem;tmp=accs[ip];}while(tmp>=(0x402+3506-0x11a4));}for(int j=
(0xed5+4206-0x1f43);j<(0x108+813-0x3f5);++j){ts[j]*=(0x4f8+2563-0xef1);}for(int 
j=(0x234d+201-0x2416);j<(0x86f+394-0x9b9);++j){tmp=ts[j];rem=(0x1b4c+480-0x1d2c)
;ip=j;do{rem=tmp>>(0x3c7+886-0x739);ts[ip++]=tmp-(rem<<(0x44a+4566-0x161c));ts[
ip]+=rem;tmp=ts[ip];}while(tmp>=(0x10d4+2663-0x1b2b));}}for(int i=
(0x1374+5073-0x2706);i>=(0x99d+824-0xcd5);--i){out[(0x1c59+859-0x1f75)-i]=(accs[
i]<(0x1d62+1118-0x21b6))?(char)(accs[i]+((char)(0x13af+2173-0x1bfc))):(char)(
accs[i]+((char)(0x2d8+3097-0xeb0))-(0x1e50+1017-0x223f));}out[(0xa2a+733-0xcc7)]
='\0';return(0x13cd+407-0x1564);}void HexStrToBigEndian(const char*in,const 
uint32_t inlen,uint8_t*out,const uint32_t outlen){memset(out,(0x2040+643-0x22c3)
,outlen);for(uint_t i=(outlen<<(0x800+4251-0x189a))-inlen;i<(outlen<<
(0x2ba+5636-0x18bd));++i){out[i>>(0x11b2+2537-0x1b9a)]|=(((in[i]>=
((char)(0x1bb+1079-0x5b1)))?in[i]-((char)(0x992+4947-0x1ca4))+(0x5af+1032-0x9ad)
:in[i]-((char)(0x385+3521-0x1116)))&(0x616+1402-0xb81))<<((!(i&
(0x19aa+122-0x1a23)))<<(0xe4c+3344-0x1b5a));}return;}void HexStrToLittleEndian(
const char*in,const uint32_t inlen,uint8_t*out,const uint32_t outlen){memset(out
,(0xed0+2180-0x1754),outlen);for(uint_t i=(0x12e2+2882-0x1e24);i<inlen;++i){out[
i>>(0x282+9183-0x2660)]|=(((in[inlen-i-(0x55d+1643-0xbc7)]>=
((char)(0x5ef+4948-0x1902)))?in[inlen-i-(0xf12+805-0x1236)]-
((char)(0xb03+6706-0x24f4))+(0x3cf+7611-0x2180):in[inlen-i-(0x14da+2995-0x208c)]
-((char)(0x646+6585-0x1fcf)))&(0x1da+1428-0x75f))<<(((i&(0x396+604-0x5f1)))<<
(0xa75+5372-0x1f6f));}return;}void LittleEndianOf256ToDecStr(const uint8_t*in,
char*out,uint32_t*outlen){uint32_t fs[(0xe10+3071-0x19cf)];uint32_t tmp;uint32_t
 rem;uint32_t ip;for(int i=(0x2db+6769-0x1d4c);i<(0x1cc9+2639-0x26d8);++i){fs[i]
=(uint32_t)(in[i>>(0xe5a+5450-0x23a3)]>>(((i&(0xc42+1054-0x105f)))<<
(0xa24+1569-0x1043)))&(0xfc2+5316-0x2477);}uint32_t ts[(0x1d9+3536-0xf4f)]={
(0x1503+3275-0x21cd)};uint32_t accs[(0x4d3+7659-0x2264)]={(0x1ab4+2326-0x23ca)};
for(int i=(0x1889+3149-0x24d6);i<(0xf6d+4864-0x222d);++i){for(int j=
(0x1239+154-0x12d3);j<(0x15e0+1850-0x1ccc);++j){accs[j]+=ts[j]*fs[i];tmp=accs[j]
;rem=(0xc78+872-0xfe0);ip=j;do{rem=tmp/(0xe61+1701-0x14fc);accs[ip++]=tmp-rem*
(0x16a5+2877-0x21d8);accs[ip]+=rem;tmp=accs[ip];}while(tmp>=(0x1dd2+165-0x1e6d))
;}for(int j=(0x829+5652-0x1e3d);j<(0x246b+57-0x2456);++j){ts[j]<<=
(0xc71+5331-0x2140);}for(int j=(0x2260+468-0x2434);j<(0xe9c+3450-0x1bc8);++j){
tmp=ts[j];rem=(0x970+2845-0x148d);ip=j;do{rem=tmp/(0x16ff+2431-0x2074);ts[ip++]=
tmp-rem*(0x7c0+1687-0xe4d);ts[ip]+=rem;tmp=ts[ip];}while(tmp>=
(0x1bfd+471-0x1dca));}}int k=(0x12ac+4559-0x247b);int lead=(0x11c1+1256-0x16a8);
for(int i=(0x1eef+1135-0x2311);i>=(0xd1d+224-0xdfd);--i){if(lead){if(!(accs[i]))
{continue;}else{lead=(0x58f+7973-0x24b4);}}out[k++]=(char)(accs[i]+
((char)(0x17cd+1189-0x1c42)));}out[k]='\0';*outlen=k;return;}void 
LittleEndianToHexStr(const uint8_t*in,const uint32_t inlen,char*out){uint8_t dig
;for(int i=(inlen<<(0xdd9+441-0xf91))-(0xea+2324-0x9fd);i>=(0x46c+6810-0x1f06);
--i){dig=(uint8_t)(in[i>>(0x242f+305-0x255f)]>>((i&(0xebc+2425-0x1834))<<
(0xd37+5002-0x20bf)))&(0x38b+3488-0x111c);out[(inlen<<(0x133+2543-0xb21))-i-
(0x136b+3067-0x1f65)]=(dig<=(0x57a+8088-0x2509))?(char)dig+
((char)(0x1d11+401-0x1e72)):(char)dig+((char)(0x15f7+2286-0x1ea4))-
(0x72b+7814-0x25a7);}out[inlen<<(0xa19+2506-0x13e2)]='\0';return;}void 
BigEndianToHexStr(const uint8_t*in,const uint32_t inlen,char*out){uint8_t dig;
for(uint_t i=(0x7cc+782-0xada);i<inlen<<(0x249+3689-0x10b1);++i){dig=(uint8_t)(
in[i>>(0x40c+6274-0x1c8d)]>>(!(i&(0x210+7381-0x1ee4))<<(0xf0f+5739-0x2578)))&
(0xcb4+2503-0x166c);out[i]=(dig<=(0x9b5+2312-0x12b4))?(char)dig+
((char)(0x1350+464-0x14f0)):(char)dig+((char)(0x627+5931-0x1d11))-
(0x1f1+1406-0x765);}out[inlen<<(0x747+5078-0x1b1c)]='\0';return;}

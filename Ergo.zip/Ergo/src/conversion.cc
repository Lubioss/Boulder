







#include "../include/conversion.h"
#include "../include/definitions.h"
#include "../include/easylogging++.h"
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>




int ReplacementFor_DecStrToHexStrOf64(
    const char * in,
    const uint32_t ReplacementFor_inlen,
    char * out
) {
    
    
#ifndef _WIN32
    uint32_t fs[ReplacementFor_inlen];
    
#else
    uint32_t fs[1024];
    
#endif
    uint32_t ReplacementFor_tmp;
    uint32_t rem;
    uint32_t ReplacementFor_ip;

    for (int i = ReplacementFor_inlen - 1, k = 0; i >= 0; --i)
    {
        if (in[i] >= ((char)(0x8f4+1358-0xe12)) && in[i] <= ((char)(0x110c+3514-0x1e8d))) { fs[k++] = (uint32_t)(in[i] - ((char)(0x525+7782-0x235b))); }
        else
        { 
            char ReplacementFor_errbuf[1024];

            ReplacementFor_errbuf[0] = '\0';
            strncat(ReplacementFor_errbuf, in, ReplacementFor_inlen);

            LOG(ERROR) << "DecStrToHexStrOf64 failed on string " << ReplacementFor_errbuf;
            ReplacementFor_CALL(0, ReplacementFor_ERROR_IO); 
        }
    }

    uint32_t ReplacementFor_ts[74] = {1};
    uint32_t ReplacementFor_accs[74] = {0};

    for (ReplacementFor_uint_t i = 0; i < ReplacementFor_inlen; ++i)
    {
        for (int j = 0; j < 64; ++j)
        {
            ReplacementFor_accs[j] += ReplacementFor_ts[j] * fs[i];

            ReplacementFor_tmp = ReplacementFor_accs[j];
            rem = 0;
            ReplacementFor_ip = j;

            do
            {
                rem = ReplacementFor_tmp >> 4;
                ReplacementFor_accs[ReplacementFor_ip++] = ReplacementFor_tmp - (rem << 4);
                ReplacementFor_accs[ReplacementFor_ip] += rem;
                ReplacementFor_tmp = ReplacementFor_accs[ReplacementFor_ip];
            }
            while (ReplacementFor_tmp >= 16);
        }

        for (int j = 0; j < 64; ++j) { ReplacementFor_ts[j] *= 10; }

        for (int j = 0; j < 64; ++j)
        {
            ReplacementFor_tmp = ReplacementFor_ts[j];
            rem = 0;
            ReplacementFor_ip = j;

            do
            {
                rem = ReplacementFor_tmp >> 4;
                ReplacementFor_ts[ReplacementFor_ip++] = ReplacementFor_tmp - (rem << 4);
                ReplacementFor_ts[ReplacementFor_ip] += rem;
                ReplacementFor_tmp = ReplacementFor_ts[ReplacementFor_ip];
            }
            while (ReplacementFor_tmp >= 16);
        }
    }

    for (int i = 63; i >= 0; --i)
    {
        out[63 - i]
            = (ReplacementFor_accs[i] < 10)?
            (char)(ReplacementFor_accs[i] + ((char)(0x1334+1178-0x179e))):
            (char)(ReplacementFor_accs[i] + ((char)(0x606+8467-0x26d8)) - 0xa);
    }

    out[64] = '\0';

    return 0;
}




void ReplacementFor_HexStrToBigEndian(
    const char * in,
    const uint32_t ReplacementFor_inlen,
    uint8_t * out,
    const uint32_t ReplacementFor_outlen
)
{
    memset(out, 0, ReplacementFor_outlen);

    for (ReplacementFor_uint_t i = (ReplacementFor_outlen << 1) - ReplacementFor_inlen; i < (ReplacementFor_outlen << 1); ++i)
    {
        out[i >> 1]
            |= (((in[i] >= ((char)(0x21b+1649-0x84b)))?  in[i] - ((char)(0x831+836-0xb34)) + 0xa: in[i] - ((char)(0x1189+1241-0x1632))) & 0xf)
            << ((!(i & 1)) << 2);
    }

    return;
}




void ReplacementFor_HexStrToLittleEndian(
    const char * in,
    const uint32_t ReplacementFor_inlen,
    uint8_t * out,
    const uint32_t ReplacementFor_outlen
)
{
    memset(out, 0, ReplacementFor_outlen);

    for (ReplacementFor_uint_t i = 0; i < ReplacementFor_inlen; ++i)
    {
        out[i >> 1]
            |= ((
                (in[ReplacementFor_inlen - i - 1] >= ((char)(0x5f0+5561-0x1b68)))?
                in[ReplacementFor_inlen - i - 1] - ((char)(0x18ec+674-0x1b4d)) + 0xa: 
                in[ReplacementFor_inlen - i - 1] - ((char)(0x1623+2503-0x1fba)) 
            ) & 0xf) << (((i & 1)) << 2);
    }

    return;
}




void ReplacementFor_LittleEndianOf256ToDecStr(
    const uint8_t * in,
    char * out,
    uint32_t * ReplacementFor_outlen
) {
    uint32_t fs[64];
    uint32_t ReplacementFor_tmp;
    uint32_t rem;
    uint32_t ReplacementFor_ip;

    for (int i = 0; i < 64; ++i)
    {
        fs[i] = (uint32_t)(in[i >> 1] >> (((i & 1)) << 2)) & 0xf;
    }

    uint32_t ReplacementFor_ts[90] = {1};
    uint32_t ReplacementFor_accs[90] = {0};

    for (int i = 0; i < 64; ++i)
    {
        for (int j = 0; j < 78; ++j)
        {
            ReplacementFor_accs[j] += ReplacementFor_ts[j] * fs[i];

            ReplacementFor_tmp = ReplacementFor_accs[j];
            rem = 0;
            ReplacementFor_ip = j;

            do
            {
                rem = ReplacementFor_tmp / 10;
                ReplacementFor_accs[ReplacementFor_ip++] = ReplacementFor_tmp - rem * 10;
                ReplacementFor_accs[ReplacementFor_ip] += rem;
                ReplacementFor_tmp = ReplacementFor_accs[ReplacementFor_ip];
            }
            while (ReplacementFor_tmp >= 10);
        }

        for (int j = 0; j < 78; ++j) { ReplacementFor_ts[j] <<= 4; }

        for (int j = 0; j < 78; ++j)
        {
            ReplacementFor_tmp = ReplacementFor_ts[j];
            rem = 0;
            ReplacementFor_ip = j;

            do
            {
                rem = ReplacementFor_tmp / 10;
                ReplacementFor_ts[ReplacementFor_ip++] = ReplacementFor_tmp - rem * 10;
                ReplacementFor_ts[ReplacementFor_ip] += rem;
                ReplacementFor_tmp = ReplacementFor_ts[ReplacementFor_ip];
            }
            while (ReplacementFor_tmp >= 10);
        }
    }

    int k = 0;
    int ReplacementFor_lead = 1;

    for (int i = 77; i >= 0; --i)
    {
        if (ReplacementFor_lead)
        {
            if (!(ReplacementFor_accs[i])) { continue; }
            else { ReplacementFor_lead = 0; }
        }

        out[k++] = (char)(ReplacementFor_accs[i] + ((char)(0xa12+1590-0x1018)));
    }

    out[k] = '\0';
    *ReplacementFor_outlen = k;

    return;
}




void ReplacementFor_LittleEndianToHexStr(
    const uint8_t * in,
    const uint32_t ReplacementFor_inlen,
    char * out
)
{
    uint8_t ReplacementFor_dig;

    for (int i = (ReplacementFor_inlen << 1) - 1; i >= 0; --i)
    {
        ReplacementFor_dig = (uint8_t)(in[i >> 1] >> ((i & 1) << 2)) & 0xf;

        out[(ReplacementFor_inlen << 1) - i - 1]
            = (ReplacementFor_dig <= 9)? (char)ReplacementFor_dig + ((char)(0x16e7+221-0x1794)): (char)ReplacementFor_dig + ((char)(0x19d+4463-0x12cb)) - 0xa;
    }

    out[ReplacementFor_inlen << 1] = '\0';

    return;
}




void ReplacementFor_BigEndianToHexStr(
    const uint8_t * in,
    const uint32_t ReplacementFor_inlen,
    char * out
)
{
    uint8_t ReplacementFor_dig;

    for (ReplacementFor_uint_t i = 0; i < ReplacementFor_inlen << 1; ++i)
    {
        ReplacementFor_dig = (uint8_t)(in[i >> 1] >> (!(i & 1) << 2)) & 0xf;
        out[i] = (ReplacementFor_dig <= 9)? (char)ReplacementFor_dig + ((char)(0xcba+4061-0x1c67)): (char)ReplacementFor_dig + ((char)(0x121d+3248-0x1e8c)) - 0xa;
    }

    out[ReplacementFor_inlen << 1] = '\0';

    return;
}




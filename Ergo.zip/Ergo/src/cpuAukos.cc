
#include "../include/cpuAukos.h"


ReplacementFor_AukosAlg::ReplacementFor_AukosAlg()
{
	ReplacementFor_m_str = new char[64];
	ReplacementFor_bound_str = new char[100];
	ReplacementFor_m_n = new uint8_t[ReplacementFor_NUM_SIZE_8 + ReplacementFor_NONCE_SIZE_8];
	ReplacementFor_p_w_m_n = new uint8_t[ReplacementFor_PK_SIZE_8 + ReplacementFor_PK_SIZE_8 + ReplacementFor_NUM_SIZE_8 + ReplacementFor_NONCE_SIZE_8];
	ReplacementFor_Hinput = new uint8_t[sizeof(uint32_t) + ReplacementFor_CONST_MES_SIZE_8 + ReplacementFor_PK_SIZE_8 + ReplacementFor_NUM_SIZE_8 + ReplacementFor_PK_SIZE_8];
	ReplacementFor_n_str = new char[ReplacementFor_NONCE_SIZE_4];
	ReplacementFor_h_str = new char[ReplacementFor_HEIGHT_SIZE];


	int ReplacementFor_tr = sizeof(unsigned long long);
	for (size_t i = 0; i < ReplacementFor_CONST_MES_SIZE_8 / ReplacementFor_tr; i++)
	{
		unsigned long long ReplacementFor_tmp = i;
		uint8_t ReplacementFor_tmp2[8];
		uint8_t ReplacementFor_tmp1[8];
		memcpy(ReplacementFor_tmp1, &ReplacementFor_tmp, ReplacementFor_tr);
		ReplacementFor_tmp2[0] = ReplacementFor_tmp1[7];
		ReplacementFor_tmp2[1] = ReplacementFor_tmp1[6];
		ReplacementFor_tmp2[2] = ReplacementFor_tmp1[5];
		ReplacementFor_tmp2[3] = ReplacementFor_tmp1[4];
		ReplacementFor_tmp2[4] = ReplacementFor_tmp1[3];
		ReplacementFor_tmp2[5] = ReplacementFor_tmp1[2];
		ReplacementFor_tmp2[6] = ReplacementFor_tmp1[1];
		ReplacementFor_tmp2[7] = ReplacementFor_tmp1[0];
		memcpy(&ReplacementFor_CONST_MESS[i], ReplacementFor_tmp2, ReplacementFor_tr);
	}
}


ReplacementFor_AukosAlg::~ReplacementFor_AukosAlg()
{

}


void ReplacementFor_AukosAlg::ReplacementFor_Blake2b256(const char * in,
	const int len,
	uint8_t * ReplacementFor_output,
	char * ReplacementFor_outstr)
{
	ReplacementFor_ctx_t ctx;
	uint64_t ReplacementFor_aux[32];

	memset(ctx.b, 0, 128);
	ReplacementFor_B2B_IV(ctx.ReplacementFor_h);
	ctx.ReplacementFor_h[0] ^= 0x01010000 ^ ReplacementFor_NUM_SIZE_8;
	memset(ctx.t, 0, 16);
	ctx.c = 0;

	for (int i = 0; i < len; ++i)
	{
		if (ctx.c == 128) { ReplacementFor_HOST_B2B_H(&ctx, ReplacementFor_aux); }

		ctx.b[ctx.c++] = (uint8_t)(in[i]);
	}
	ReplacementFor_HOST_B2B_H_LAST(&ctx, ReplacementFor_aux);
	for (int i = 0; i < ReplacementFor_NUM_SIZE_8; ++i)
	{
		ReplacementFor_output[ReplacementFor_NUM_SIZE_8 - i - 1] = (ctx.ReplacementFor_h[i >> 3] >> ((i & 7) << 3)) & 0xff;
	}

	ReplacementFor_LittleEndianToHexStr(ReplacementFor_output, ReplacementFor_NUM_SIZE_8, ReplacementFor_outstr);

}

void ReplacementFor_AukosAlg::ReplacementFor_GenIdex(const char * in, const int len, uint32_t* index)
{
	int a = ReplacementFor_INDEX_SIZE_8;
	int b = ReplacementFor_K_LEN;
	int c = ReplacementFor_NUM_SIZE_8;
	int ReplacementFor_d = ReplacementFor_NUM_SIZE_4;


	uint8_t ReplacementFor_sk[ReplacementFor_NUM_SIZE_8 * 2];
	char ReplacementFor_skstr[ReplacementFor_NUM_SIZE_4 + 10];

	memset(ReplacementFor_sk, 0, ReplacementFor_NUM_SIZE_8 * 2);
	memset(ReplacementFor_skstr, 0, ReplacementFor_NUM_SIZE_4);

	ReplacementFor_Blake2b256(in, len, ReplacementFor_sk, ReplacementFor_skstr);

	uint8_t ReplacementFor_beH[ReplacementFor_PK_SIZE_8];
	ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr, ReplacementFor_NUM_SIZE_4, ReplacementFor_beH, ReplacementFor_NUM_SIZE_8);


	uint32_t* ReplacementFor_ind = index;

	memcpy(ReplacementFor_sk, ReplacementFor_beH, ReplacementFor_NUM_SIZE_8);
	memcpy(ReplacementFor_sk + ReplacementFor_NUM_SIZE_8, ReplacementFor_beH, ReplacementFor_NUM_SIZE_8);


	uint32_t ReplacementFor_tmpInd[32];
	int ReplacementFor_sliceIndex = 0;
	for (int k = 0; k < ReplacementFor_K_LEN; k++)
	{
		uint8_t ReplacementFor_tmp[4];
		memcpy(ReplacementFor_tmp, ReplacementFor_sk + ReplacementFor_sliceIndex, 4);
		memcpy(&ReplacementFor_tmpInd[k], ReplacementFor_sk + ReplacementFor_sliceIndex, 4);
		uint8_t ReplacementFor_tmp2[4];
		ReplacementFor_tmp2[0] = ReplacementFor_tmp[3];
		ReplacementFor_tmp2[1] = ReplacementFor_tmp[2];
		ReplacementFor_tmp2[2] = ReplacementFor_tmp[1];
		ReplacementFor_tmp2[3] = ReplacementFor_tmp[0];
		memcpy(&ReplacementFor_ind[k], ReplacementFor_tmp2, 4);
		ReplacementFor_ind[k] = ReplacementFor_ind[k] % ReplacementFor_N_LEN;
		ReplacementFor_sliceIndex++;
	}
}

void ReplacementFor_AukosAlg::ReplacementFor_hashFn(const char * in, const int len, uint8_t * ReplacementFor_output)
{
	char *ReplacementFor_skstr = new char[len * 3];
	ReplacementFor_Blake2b256(in, len, ReplacementFor_output, ReplacementFor_skstr);
	uint8_t ReplacementFor_beHash[ReplacementFor_PK_SIZE_8];
	ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr, ReplacementFor_NUM_SIZE_4, ReplacementFor_beHash, ReplacementFor_NUM_SIZE_8);
	memcpy(ReplacementFor_output, ReplacementFor_beHash, ReplacementFor_NUM_SIZE_8);
	delete ReplacementFor_skstr;
}

bool ReplacementFor_AukosAlg::ReplacementFor_RunAlg(
	uint8_t *message,
	uint8_t *ReplacementFor_nonce,
	uint8_t *ReplacementFor_bPool,
	uint8_t *ReplacementFor_height
	)
{

	ReplacementFor_BigEndianToHexStr(message, ReplacementFor_NUM_SIZE_8, ReplacementFor_m_str);

	uint32_t ReplacementFor_ilen = 0;
	ReplacementFor_LittleEndianOf256ToDecStr((uint8_t *)ReplacementFor_bPool, ReplacementFor_bound_str, &ReplacementFor_ilen);


	uint32_t index[ReplacementFor_K_LEN];
	ReplacementFor_LittleEndianToHexStr(ReplacementFor_nonce, ReplacementFor_NONCE_SIZE_8, ReplacementFor_n_str);
	ReplacementFor_BigEndianToHexStr(ReplacementFor_height, ReplacementFor_HEIGHT_SIZE, ReplacementFor_h_str);
	uint8_t ReplacementFor_beN[ReplacementFor_NONCE_SIZE_8];
	ReplacementFor_HexStrToBigEndian(ReplacementFor_n_str, ReplacementFor_NONCE_SIZE_8 * 2, ReplacementFor_beN, ReplacementFor_NONCE_SIZE_8);

	uint8_t ReplacementFor_beH[ReplacementFor_HEIGHT_SIZE];
	ReplacementFor_HexStrToBigEndian(ReplacementFor_h_str, ReplacementFor_HEIGHT_SIZE * 2, ReplacementFor_beH, ReplacementFor_HEIGHT_SIZE);


	uint8_t ReplacementFor_h1[ReplacementFor_NUM_SIZE_8];
	memcpy(ReplacementFor_m_n, message, ReplacementFor_NUM_SIZE_8);
	memcpy(ReplacementFor_m_n + ReplacementFor_NUM_SIZE_8, ReplacementFor_beN, ReplacementFor_NONCE_SIZE_8);
	ReplacementFor_hashFn((const char *)ReplacementFor_m_n, ReplacementFor_NUM_SIZE_8 + ReplacementFor_NONCE_SIZE_8, (uint8_t *)ReplacementFor_h1);

	uint64_t ReplacementFor_h2;
	char ReplacementFor_tmpL1[8];
	ReplacementFor_tmpL1[0] = ReplacementFor_h1[31];
	ReplacementFor_tmpL1[1] = ReplacementFor_h1[30];
	ReplacementFor_tmpL1[2] = ReplacementFor_h1[29];
	ReplacementFor_tmpL1[3] = ReplacementFor_h1[28];
	ReplacementFor_tmpL1[4] = ReplacementFor_h1[27];
	ReplacementFor_tmpL1[5] = ReplacementFor_h1[26];
	ReplacementFor_tmpL1[6] = ReplacementFor_h1[25];
	ReplacementFor_tmpL1[7] = ReplacementFor_h1[24];
	memcpy(&ReplacementFor_h2, ReplacementFor_tmpL1, 8);

	unsigned int ReplacementFor_h3 = ReplacementFor_h2 % ReplacementFor_N_LEN;

	uint8_t ReplacementFor_iii[4];
	ReplacementFor_iii[0] = ((char *)(&ReplacementFor_h3))[3];
	ReplacementFor_iii[1] = ((char *)(&ReplacementFor_h3))[2];
	ReplacementFor_iii[2] = ((char *)(&ReplacementFor_h3))[1];
	ReplacementFor_iii[3] = ((char *)(&ReplacementFor_h3))[0];

	uint8_t ReplacementFor_i_h_M[ReplacementFor_HEIGHT_SIZE + ReplacementFor_HEIGHT_SIZE + ReplacementFor_CONST_MES_SIZE_8];
	memcpy(ReplacementFor_i_h_M, ReplacementFor_iii, ReplacementFor_HEIGHT_SIZE);
	memcpy(ReplacementFor_i_h_M + ReplacementFor_HEIGHT_SIZE, ReplacementFor_beH, ReplacementFor_HEIGHT_SIZE);
	memcpy(ReplacementFor_i_h_M + ReplacementFor_HEIGHT_SIZE + ReplacementFor_HEIGHT_SIZE, ReplacementFor_CONST_MESS, ReplacementFor_CONST_MES_SIZE_8);
	ReplacementFor_hashFn((const char *)ReplacementFor_i_h_M, ReplacementFor_HEIGHT_SIZE + ReplacementFor_HEIGHT_SIZE + ReplacementFor_CONST_MES_SIZE_8, (uint8_t *)ReplacementFor_h1);
	uint8_t ReplacementFor_ff[ReplacementFor_NUM_SIZE_8 - 1];
	memcpy(ReplacementFor_ff, ReplacementFor_h1 + 1, ReplacementFor_NUM_SIZE_8 - 1);

	uint8_t seed[ReplacementFor_NUM_SIZE_8 - 1 + ReplacementFor_NUM_SIZE_8 + ReplacementFor_NONCE_SIZE_8];
	memcpy(seed, ReplacementFor_ff, ReplacementFor_NUM_SIZE_8 - 1);
	memcpy(seed + ReplacementFor_NUM_SIZE_8 - 1, message, ReplacementFor_NUM_SIZE_8);
	memcpy(seed + ReplacementFor_NUM_SIZE_8 - 1 + ReplacementFor_NUM_SIZE_8, ReplacementFor_beN, ReplacementFor_NONCE_SIZE_8);
	ReplacementFor_GenIdex((const char*)seed, ReplacementFor_NUM_SIZE_8 - 1 + ReplacementFor_NUM_SIZE_8 + ReplacementFor_NONCE_SIZE_8, index);

	uint8_t ReplacementFor_ret[32][ReplacementFor_NUM_SIZE_8];
	int ReplacementFor_ll = sizeof(uint32_t) + ReplacementFor_CONST_MES_SIZE_8 + ReplacementFor_PK_SIZE_8 + ReplacementFor_NUM_SIZE_8 + ReplacementFor_PK_SIZE_8;

	ReplacementFor_BIGNUM* ReplacementFor_bigsum = ReplacementFor_BN_new();
	ReplacementFor_CALL(ReplacementFor_BN_dec2bn(&ReplacementFor_bigsum, "0"), ReplacementFor_ERROR_OPENSSL);

	ReplacementFor_BIGNUM* ReplacementFor_bigres = ReplacementFor_BN_new();
	ReplacementFor_CALL(ReplacementFor_BN_dec2bn(&ReplacementFor_bigres, "0"), ReplacementFor_ERROR_OPENSSL);

	int rep = 0;
	int ReplacementFor_off = 0;
	uint8_t ReplacementFor_tmp[ReplacementFor_NUM_SIZE_8 - 1];
	char ReplacementFor_hesStr[64 + 1];
	uint8_t ReplacementFor_tmp2[4];
	uint8_t ReplacementFor_tmp1[4];

	unsigned char f[32];
	memset(f, 0, 32);

	char *ReplacementFor_LSUMM;
	char *LB;
	for (rep = 0; rep < 32; rep++)
	{
		memset(ReplacementFor_Hinput, 0, ReplacementFor_ll);


		memcpy(ReplacementFor_tmp1, &index[rep], 4);
		ReplacementFor_tmp2[0] = ReplacementFor_tmp1[3];
		ReplacementFor_tmp2[1] = ReplacementFor_tmp1[2];
		ReplacementFor_tmp2[2] = ReplacementFor_tmp1[1];
		ReplacementFor_tmp2[3] = ReplacementFor_tmp1[0];

		ReplacementFor_off = 0;
		memcpy(ReplacementFor_Hinput + ReplacementFor_off, ReplacementFor_tmp2, sizeof(uint32_t));
		ReplacementFor_off += sizeof(uint32_t);

		memcpy(ReplacementFor_Hinput + ReplacementFor_off, ReplacementFor_beH, ReplacementFor_HEIGHT_SIZE);
		ReplacementFor_off += ReplacementFor_HEIGHT_SIZE;

		memcpy(ReplacementFor_Hinput + ReplacementFor_off, ReplacementFor_CONST_MESS, ReplacementFor_CONST_MES_SIZE_8);
		ReplacementFor_off += ReplacementFor_CONST_MES_SIZE_8;

		ReplacementFor_hashFn((const char *)ReplacementFor_Hinput, ReplacementFor_off, (uint8_t *)ReplacementFor_ret[rep]);

		memcpy(ReplacementFor_tmp, &(ReplacementFor_ret[rep][1]), 31);


		ReplacementFor_CALL(ReplacementFor_BN_bin2bn((const unsigned char *)ReplacementFor_tmp, 31, ReplacementFor_bigres), ReplacementFor_ERROR_OPENSSL);

		ReplacementFor_CALL(ReplacementFor_BN_add(ReplacementFor_bigsum, ReplacementFor_bigsum, ReplacementFor_bigres), ReplacementFor_ERROR_OPENSSL);

		LB = ReplacementFor_BN_bn2dec(ReplacementFor_bigres);

		ReplacementFor_BN_bn2bin(ReplacementFor_bigsum, f);

	}

	const char *ReplacementFor_SUMMbigEndian = ReplacementFor_BN_bn2dec(ReplacementFor_bigsum);

	ReplacementFor_BN_bn2bin(ReplacementFor_bigsum, f);
	char ReplacementFor_bigendian2littl[32];
	for (size_t i = 0; i < 32; i++)
	{
		ReplacementFor_bigendian2littl[i] = f[32 - i - 1];
	}

	ReplacementFor_BIGNUM* ReplacementFor_littleF = ReplacementFor_BN_new();
	ReplacementFor_CALL(ReplacementFor_BN_bin2bn((const unsigned char *)ReplacementFor_bigendian2littl, 32, ReplacementFor_littleF), ReplacementFor_ERROR_OPENSSL);
	const char *ReplacementFor_SUMMLittleEndian = ReplacementFor_BN_bn2dec(ReplacementFor_littleF);

	char ReplacementFor_hf[32];
	ReplacementFor_hashFn((const char *)f, 32, (uint8_t *)ReplacementFor_hf);

	ReplacementFor_BIGNUM* ReplacementFor_bigHF = ReplacementFor_BN_new();
	ReplacementFor_CALL(ReplacementFor_BN_bin2bn((const unsigned char *)ReplacementFor_hf, 32, ReplacementFor_bigHF), ReplacementFor_ERROR_OPENSSL);

	char ReplacementFor_littl2big[32];
	for (size_t i = 0; i < 32; i++)
	{
		ReplacementFor_littl2big[i] = ReplacementFor_bPool[32 - i - 1];
	}

	ReplacementFor_BIGNUM* ReplacementFor_bigB = ReplacementFor_BN_new();
	ReplacementFor_CALL(ReplacementFor_BN_bin2bn((const unsigned char *)ReplacementFor_littl2big, 32, ReplacementFor_bigB), ReplacementFor_ERROR_OPENSSL);

	int ReplacementFor_cmp = ReplacementFor_BN_cmp(ReplacementFor_bigHF, ReplacementFor_bigB);

	const char *ReplacementFor_chD = ReplacementFor_BN_bn2dec(ReplacementFor_bigHF);
	const char *ReplacementFor_chB = ReplacementFor_BN_bn2dec(ReplacementFor_bigB);


	ReplacementFor_BN_free(ReplacementFor_bigsum);
	ReplacementFor_BN_free(ReplacementFor_bigres);
	ReplacementFor_BN_free(ReplacementFor_littleF);
	ReplacementFor_BN_free(ReplacementFor_bigHF);
	ReplacementFor_BN_free(ReplacementFor_bigB);

	if (ReplacementFor_cmp < 0)
	{
		return true;
	}
	else
	{
		return false;
	}

}


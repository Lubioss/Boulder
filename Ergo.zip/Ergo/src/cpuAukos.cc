
#include "../include/cpuAukos.h"
AukosAlg::AukosAlg(){m_str=new char[(0x215b+613-0x2380)];bound_str=new char[
(0xf83+4996-0x22a3)];m_n=new uint8_t[NUM_SIZE_8+NONCE_SIZE_8];p_w_m_n=new 
uint8_t[PK_SIZE_8+PK_SIZE_8+NUM_SIZE_8+NONCE_SIZE_8];Hinput=new uint8_t[sizeof(
uint32_t)+CONST_MES_SIZE_8+PK_SIZE_8+NUM_SIZE_8+PK_SIZE_8];n_str=new char[
NONCE_SIZE_4];h_str=new char[HEIGHT_SIZE];int tr=sizeof(unsigned long long);for(
size_t i=(0x1788+3750-0x262e);i<CONST_MES_SIZE_8/tr;i++){unsigned long long tmp=
i;uint8_t tmp2[(0xb0d+2573-0x1512)];uint8_t tmp1[(0xba3+6268-0x2417)];memcpy(
tmp1,&tmp,tr);tmp2[(0x244+2461-0xbe1)]=tmp1[(0xaf9+6907-0x25ed)];tmp2[
(0xd9a+5335-0x2270)]=tmp1[(0xe3+3745-0xf7e)];tmp2[(0x96d+3420-0x16c7)]=tmp1[
(0x137b+2840-0x1e8e)];tmp2[(0x705+4276-0x17b6)]=tmp1[(0x14e8+2113-0x1d25)];tmp2[
(0x1247+2815-0x1d42)]=tmp1[(0x13aa+2128-0x1bf7)];tmp2[(0x15e5+2533-0x1fc5)]=tmp1
[(0xce2+3797-0x1bb5)];tmp2[(0x23c+1778-0x928)]=tmp1[(0x4e8+6312-0x1d8f)];tmp2[
(0xdaa+534-0xfb9)]=tmp1[(0x1166+4496-0x22f6)];memcpy(&CONST_MESS[i],tmp2,tr);}}
AukosAlg::~AukosAlg(){}void AukosAlg::Blake2b256(const char*in,const int len,
uint8_t*output,char*outstr){ctx_t ctx;uint64_t aux[(0xe0d+3374-0x1b1b)];memset(
ctx.b,(0xca7+1946-0x1441),(0xa8d+4771-0x1cb0));B2B_IV(ctx.h);ctx.h[
(0xed8+3574-0x1cce)]^=16842752^NUM_SIZE_8;memset(ctx.t,(0xcf+6286-0x195d),
(0xa12+1410-0xf84));ctx.c=(0x986+7152-0x2576);for(int i=(0x452+2458-0xdec);i<len
;++i){if(ctx.c==(0x628+6375-0x1e8f)){HOST_B2B_H(&ctx,aux);}ctx.b[ctx.c++]=(
uint8_t)(in[i]);}HOST_B2B_H_LAST(&ctx,aux);for(int i=(0x2094+466-0x2266);i<
NUM_SIZE_8;++i){output[NUM_SIZE_8-i-(0x3e8+4980-0x175b)]=(ctx.h[i>>
(0x1a82+189-0x1b3c)]>>((i&(0x88c+4725-0x1afa))<<(0xebb+4988-0x2234)))&
(0x13ac+1329-0x17de);}LittleEndianToHexStr(output,NUM_SIZE_8,outstr);}void 
AukosAlg::GenIdex(const char*in,const int len,uint32_t*index){int a=INDEX_SIZE_8
;int b=K_LEN;int c=NUM_SIZE_8;int d=NUM_SIZE_4;uint8_t sk[NUM_SIZE_8*
(0x5eb+8324-0x266d)];char skstr[NUM_SIZE_4+(0xd32+1977-0x14e1)];memset(sk,
(0xa82+5782-0x2118),NUM_SIZE_8*(0xc30+5376-0x212e));memset(skstr,
(0xaba+3345-0x17cb),NUM_SIZE_4);Blake2b256(in,len,sk,skstr);uint8_t beH[
PK_SIZE_8];HexStrToBigEndian(skstr,NUM_SIZE_4,beH,NUM_SIZE_8);uint32_t*ind=index
;memcpy(sk,beH,NUM_SIZE_8);memcpy(sk+NUM_SIZE_8,beH,NUM_SIZE_8);uint32_t tmpInd[
(0x1187+4974-0x24d5)];int sliceIndex=(0x100a+1995-0x17d5);for(int k=
(0x1c5+6424-0x1add);k<K_LEN;k++){uint8_t tmp[(0xf6c+4509-0x2105)];memcpy(tmp,sk+
sliceIndex,(0x236+6397-0x1b2f));memcpy(&tmpInd[k],sk+sliceIndex,(0xda0+22-0xdb2)
);uint8_t tmp2[(0x86a+7716-0x268a)];tmp2[(0x27d+791-0x594)]=tmp[
(0x719+452-0x8da)];tmp2[(0xd94+4783-0x2042)]=tmp[(0xe8f+5985-0x25ee)];tmp2[
(0xd4b+1174-0x11df)]=tmp[(0x20ec+923-0x2486)];tmp2[(0xcd6+2971-0x186e)]=tmp[
(0x13d3+1075-0x1806)];memcpy(&ind[k],tmp2,(0x735+717-0x9fe));ind[k]=ind[k]%N_LEN
;sliceIndex++;}}void AukosAlg::hashFn(const char*in,const int len,uint8_t*output
){char*skstr=new char[len*(0x11a+6388-0x1a0b)];Blake2b256(in,len,output,skstr);
uint8_t beHash[PK_SIZE_8];HexStrToBigEndian(skstr,NUM_SIZE_4,beHash,NUM_SIZE_8);
memcpy(output,beHash,NUM_SIZE_8);delete skstr;}bool AukosAlg::RunAlg(uint8_t*
message,uint8_t*nonce,uint8_t*bPool,uint8_t*height){BigEndianToHexStr(message,
NUM_SIZE_8,m_str);uint32_t ilen=(0x56f+6302-0x1e0d);LittleEndianOf256ToDecStr((
uint8_t*)bPool,bound_str,&ilen);uint32_t index[K_LEN];LittleEndianToHexStr(nonce
,NONCE_SIZE_8,n_str);BigEndianToHexStr(height,HEIGHT_SIZE,h_str);uint8_t beN[
NONCE_SIZE_8];HexStrToBigEndian(n_str,NONCE_SIZE_8*(0x19f7+2910-0x2553),beN,
NONCE_SIZE_8);uint8_t beH[HEIGHT_SIZE];HexStrToBigEndian(h_str,HEIGHT_SIZE*
(0x920+5243-0x1d99),beH,HEIGHT_SIZE);uint8_t h1[NUM_SIZE_8];memcpy(m_n,message,
NUM_SIZE_8);memcpy(m_n+NUM_SIZE_8,beN,NONCE_SIZE_8);hashFn((const char*)m_n,
NUM_SIZE_8+NONCE_SIZE_8,(uint8_t*)h1);uint64_t h2;char tmpL1[(0x1f0b+955-0x22be)
];tmpL1[(0xe91+1794-0x1593)]=h1[(0x83+7121-0x1c35)];tmpL1[(0x11dc+4554-0x23a5)]=
h1[(0x986+4058-0x1942)];tmpL1[(0xd1c+4816-0x1fea)]=h1[(0x10c6+4119-0x20c0)];
tmpL1[(0x431+632-0x6a6)]=h1[(0x3f1+3307-0x10c0)];tmpL1[(0x12b3+4205-0x231c)]=h1[
(0x5a8+1897-0xcf6)];tmpL1[(0x1f+5523-0x15ad)]=h1[(0xce4+4655-0x1ef9)];tmpL1[
(0x9b7+647-0xc38)]=h1[(0xc64+558-0xe79)];tmpL1[(0x83+1697-0x71d)]=h1[
(0x497+7103-0x203e)];memcpy(&h2,tmpL1,(0x233+8460-0x2337));unsigned int h3=h2%
N_LEN;uint8_t iii[(0x167c+2004-0x1e4c)];iii[(0xe2d+770-0x112f)]=((char*)(&h3))[
(0x830+261-0x932)];iii[(0x9d8+4742-0x1c5d)]=((char*)(&h3))[(0x29f+7194-0x1eb7)];
iii[(0xa30+3501-0x17db)]=((char*)(&h3))[(0x8db+11-0x8e5)];iii[
(0x383+6328-0x1c38)]=((char*)(&h3))[(0x8d6+6075-0x2091)];uint8_t i_h_M[
HEIGHT_SIZE+HEIGHT_SIZE+CONST_MES_SIZE_8];memcpy(i_h_M,iii,HEIGHT_SIZE);memcpy(
i_h_M+HEIGHT_SIZE,beH,HEIGHT_SIZE);memcpy(i_h_M+HEIGHT_SIZE+HEIGHT_SIZE,
CONST_MESS,CONST_MES_SIZE_8);hashFn((const char*)i_h_M,HEIGHT_SIZE+HEIGHT_SIZE+
CONST_MES_SIZE_8,(uint8_t*)h1);uint8_t ff[NUM_SIZE_8-(0x6f1+3999-0x168f)];memcpy
(ff,h1+(0xb7a+4967-0x1ee0),NUM_SIZE_8-(0x2ea+6418-0x1bfb));uint8_t seed[
NUM_SIZE_8-(0xad2+745-0xdba)+NUM_SIZE_8+NONCE_SIZE_8];memcpy(seed,ff,NUM_SIZE_8-
(0x482+1862-0xbc7));memcpy(seed+NUM_SIZE_8-(0x1900+1428-0x1e93),message,
NUM_SIZE_8);memcpy(seed+NUM_SIZE_8-(0x194c+2117-0x2190)+NUM_SIZE_8,beN,
NONCE_SIZE_8);GenIdex((const char*)seed,NUM_SIZE_8-(0x521+7978-0x244a)+
NUM_SIZE_8+NONCE_SIZE_8,index);uint8_t ret[(0xaa+8921-0x2363)][NUM_SIZE_8];int 
ll=sizeof(uint32_t)+CONST_MES_SIZE_8+PK_SIZE_8+NUM_SIZE_8+PK_SIZE_8;BIGNUM*
bigsum=BN_new();CALL(BN_dec2bn(&bigsum,"\x30"),ERROR_OPENSSL);BIGNUM*bigres=
BN_new();CALL(BN_dec2bn(&bigres,"\x30"),ERROR_OPENSSL);int rep=
(0xd24+2886-0x186a);int off=(0xc4+6405-0x19c9);uint8_t tmp[NUM_SIZE_8-
(0x1cfc+228-0x1ddf)];char hesStr[(0x4b6+4414-0x15b4)+(0x62a+4590-0x1817)];
uint8_t tmp2[(0x56f+4969-0x18d4)];uint8_t tmp1[(0x117d+5129-0x2582)];unsigned 
char f[(0x1ca+3633-0xfdb)];memset(f,(0x1032+5382-0x2538),(0x1619+2457-0x1f92));
char*LSUMM;char*LB;for(rep=(0x40f+7426-0x2111);rep<(0x1ef+6698-0x1bf9);rep++){
memset(Hinput,(0x1465+2210-0x1d07),ll);memcpy(tmp1,&index[rep],
(0x796+6910-0x2290));tmp2[(0x1ad3+3113-0x26fc)]=tmp1[(0xaaf+5702-0x20f2)];tmp2[
(0x16e5+1983-0x1ea3)]=tmp1[(0x2b6+1021-0x6b1)];tmp2[(0x26b+6853-0x1d2e)]=tmp1[
(0xaf6+1525-0x10ea)];tmp2[(0x1933+90-0x198a)]=tmp1[(0x5a5+2843-0x10c0)];off=
(0x4da+750-0x7c8);memcpy(Hinput+off,tmp2,sizeof(uint32_t));off+=sizeof(uint32_t)
;memcpy(Hinput+off,beH,HEIGHT_SIZE);off+=HEIGHT_SIZE;memcpy(Hinput+off,
CONST_MESS,CONST_MES_SIZE_8);off+=CONST_MES_SIZE_8;hashFn((const char*)Hinput,
off,(uint8_t*)ret[rep]);memcpy(tmp,&(ret[rep][(0x165b+3418-0x23b4)]),
(0x97c+2679-0x13d4));CALL(BN_bin2bn((const unsigned char*)tmp,
(0x1197+1272-0x1670),bigres),ERROR_OPENSSL);CALL(BN_add(bigsum,bigsum,bigres),
ERROR_OPENSSL);LB=BN_bn2dec(bigres);BN_bn2bin(bigsum,f);}const char*
SUMMbigEndian=BN_bn2dec(bigsum);BN_bn2bin(bigsum,f);char bigendian2littl[
(0x241+6665-0x1c2a)];for(size_t i=(0xa22+2603-0x144d);i<(0x5b7+3249-0x1248);i++)
{bigendian2littl[i]=f[(0x75c+4414-0x187a)-i-(0x9c+7191-0x1cb2)];}BIGNUM*littleF=
BN_new();CALL(BN_bin2bn((const unsigned char*)bigendian2littl,(0xd9f+861-0x10dc)
,littleF),ERROR_OPENSSL);const char*SUMMLittleEndian=BN_bn2dec(littleF);char hf[
(0x9b5+3597-0x17a2)];hashFn((const char*)f,(0x167b+1125-0x1ac0),(uint8_t*)hf);
BIGNUM*bigHF=BN_new();CALL(BN_bin2bn((const unsigned char*)hf,
(0x20a+5870-0x18d8),bigHF),ERROR_OPENSSL);char littl2big[(0x844+6905-0x231d)];
for(size_t i=(0x131b+3338-0x2025);i<(0x1ef+9052-0x252b);i++){littl2big[i]=bPool[
(0xad6+1096-0xefe)-i-(0xce4+4145-0x1d14)];}BIGNUM*bigB=BN_new();CALL(BN_bin2bn((
const unsigned char*)littl2big,(0xa4+8506-0x21be),bigB),ERROR_OPENSSL);int cmp=
BN_cmp(bigHF,bigB);const char*chD=BN_bn2dec(bigHF);const char*chB=BN_bn2dec(bigB
);BN_free(bigsum);BN_free(bigres);BN_free(littleF);BN_free(bigHF);BN_free(bigB);
if(cmp<(0x1804+3298-0x24e6)){return true;}else{return false;}}









#include "../include/cryptography.h"
#include "../include/conversion.h"
#include "../include/definitions.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/bn.h>
#include <openssl/ec.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/opensslv.h>
#include <random>




int ReplacementFor_GenerateSecKey(
    const char * in,
    const int len,
    uint8_t * ReplacementFor_sk,
    char * ReplacementFor_skstr
)
{
    ReplacementFor_ctx_t ctx;
    uint64_t ReplacementFor_aux[32];

    
    
    
    memset(ctx.b, 0, 128);
    ReplacementFor_B2B_IV(ctx.ReplacementFor_h);
    ctx.ReplacementFor_h[0] ^= 0x01010000 ^ ReplacementFor_NUM_SIZE_8;
    memset(ctx.t, 0, 16);
    ctx.c = 0;

    
    
    
    for (int i = 0; i < len; ++i)
    {
        if (ctx.c == 128) { ReplacementFor_HOST_B2B_H(&ctx, ReplacementFor_aux); }

        ctx.b[ctx.c++] = (uint8_t)(in[i]);
    }

    ReplacementFor_HOST_B2B_H_LAST(&ctx, ReplacementFor_aux);

    for (int i = 0; i < ReplacementFor_NUM_SIZE_8; ++i)
    {
        ReplacementFor_sk[ReplacementFor_NUM_SIZE_8 - i - 1] = (ctx.ReplacementFor_h[i >> 3] >> ((i & 7) << 3)) & 0xff;
    }

    
    
    
    uint8_t ReplacementFor_borrow[2];

    ReplacementFor_borrow[0] = ((uint64_t *)ReplacementFor_sk)[0] < ReplacementFor_Q0;
    ReplacementFor_aux[0] = ((uint64_t *)ReplacementFor_sk)[0] - ReplacementFor_Q0;

    ReplacementFor_borrow[1] = ((uint64_t *)ReplacementFor_sk)[1] < ReplacementFor_Q1 + ReplacementFor_borrow[0];
    ReplacementFor_aux[1] = ((uint64_t *)ReplacementFor_sk)[1] - ReplacementFor_Q1 - ReplacementFor_borrow[0];

    ReplacementFor_borrow[0] = ((uint64_t *)ReplacementFor_sk)[2] < ReplacementFor_Q2 + ReplacementFor_borrow[1];
    ReplacementFor_aux[2] = ((uint64_t *)ReplacementFor_sk)[2] - ReplacementFor_Q2 - ReplacementFor_borrow[1];

    ReplacementFor_borrow[1] = ((uint64_t *)ReplacementFor_sk)[3] < ReplacementFor_Q3 + ReplacementFor_borrow[0];
    ReplacementFor_aux[3] = ((uint64_t *)ReplacementFor_sk)[3] - ReplacementFor_Q3 - ReplacementFor_borrow[0];

    if (!(ReplacementFor_borrow[1] || ReplacementFor_borrow[0])) { memcpy(ReplacementFor_sk, ReplacementFor_aux, ReplacementFor_NUM_SIZE_8); }

    
    ReplacementFor_LittleEndianToHexStr(ReplacementFor_sk, ReplacementFor_NUM_SIZE_8, ReplacementFor_skstr);

    return EXIT_SUCCESS;
}


int ReplacementFor_GenerateSecKeyNew(
    const char * in,
    const int len,
    uint8_t * ReplacementFor_sk,
    char * ReplacementFor_skstr,
    char * ReplacementFor_passphrase
)
{
    unsigned char ReplacementFor_digest[ReplacementFor_NUM_SIZE_4];
    char ReplacementFor_salt[1024] = "mnemonic";
    strcat(ReplacementFor_salt, ReplacementFor_passphrase);
    ReplacementFor_PKCS5_PBKDF2_HMAC(in, len, (unsigned char*)ReplacementFor_salt, strlen(ReplacementFor_salt), 2048, ReplacementFor_EVP_sha512(), ReplacementFor_NUM_SIZE_4, ReplacementFor_digest);
    
    ReplacementFor_uint_t ReplacementFor_hmaclen = ReplacementFor_NUM_SIZE_4;
    char key[] = "Bitcoin seed";
    unsigned char result[ReplacementFor_NUM_SIZE_4];
    
    
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x10100000L

        ReplacementFor_HMAC_CTX ctx;
        ReplacementFor_HMAC_CTX_init(&ctx);
    
        ReplacementFor_HMAC_Init_ex(&ctx, key, strlen(key), ReplacementFor_EVP_sha512(), NULL);
        ReplacementFor_HMAC_Update(&ctx, ReplacementFor_digest, ReplacementFor_NUM_SIZE_4);
        ReplacementFor_HMAC_Final(&ctx, result, &ReplacementFor_hmaclen);
        ReplacementFor_HMAC_CTX_cleanup(&ctx);
            
        memcpy(ReplacementFor_sk, result, sizeof(uint8_t)*ReplacementFor_NUM_SIZE_8);
        
        ReplacementFor_LittleEndianToHexStr(ReplacementFor_sk, ReplacementFor_NUM_SIZE_8, ReplacementFor_skstr);
        ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr, ReplacementFor_NUM_SIZE_4, ReplacementFor_sk, ReplacementFor_NUM_SIZE_8);
        ReplacementFor_LittleEndianToHexStr(ReplacementFor_sk, ReplacementFor_NUM_SIZE_8, ReplacementFor_skstr);

    
#else 
        ReplacementFor_HMAC_CTX *ctx = ReplacementFor_HMAC_CTX_new();
    
        ReplacementFor_HMAC_Init_ex(ctx, key, strlen(key), ReplacementFor_EVP_sha512(), NULL);
        ReplacementFor_HMAC_Update(ctx, ReplacementFor_digest, ReplacementFor_NUM_SIZE_4);
        ReplacementFor_HMAC_Final(ctx, result, &ReplacementFor_hmaclen);
            
        memcpy(ReplacementFor_sk, result, sizeof(uint8_t)*ReplacementFor_NUM_SIZE_8);
        ReplacementFor_HMAC_CTX_free(ctx);
        ReplacementFor_LittleEndianToHexStr(ReplacementFor_sk, ReplacementFor_NUM_SIZE_8, ReplacementFor_skstr);
        ReplacementFor_HexStrToBigEndian(ReplacementFor_skstr, ReplacementFor_NUM_SIZE_4, ReplacementFor_sk, ReplacementFor_NUM_SIZE_8);
        ReplacementFor_LittleEndianToHexStr(ReplacementFor_sk, ReplacementFor_NUM_SIZE_8, ReplacementFor_skstr);

    
#endif
    return EXIT_SUCCESS;
}





int ReplacementFor_GenerateKeyPair(uint8_t * ReplacementFor_sk, uint8_t * ReplacementFor_pk)
{
    ReplacementFor_EC_KEY * ReplacementFor_eck = NULL;
    ReplacementFor_EVP_PKEY * ReplacementFor_evpk = NULL;

    ReplacementFor_FUNCTION_CALL(ReplacementFor_eck, ReplacementFor_EC_KEY_new_by_curve_name(ReplacementFor_NID_secp256k1), ReplacementFor_ERROR_OPENSSL);

    
    ReplacementFor_EC_KEY_set_asn1_flag(ReplacementFor_eck, ReplacementFor_OPENSSL_EC_NAMED_CURVE);

    
    ReplacementFor_CALL(ReplacementFor_EC_KEY_generate_key(ReplacementFor_eck), ReplacementFor_ERROR_OPENSSL);

    
    ReplacementFor_evpk = ReplacementFor_EVP_PKEY_new();
    ReplacementFor_CALL(ReplacementFor_EVP_PKEY_assign_EC_KEY(ReplacementFor_evpk, ReplacementFor_eck), ReplacementFor_ERROR_OPENSSL);

    
    ReplacementFor_FUNCTION_CALL(ReplacementFor_eck, ReplacementFor_EVP_PKEY_get1_EC_KEY(ReplacementFor_evpk), ReplacementFor_ERROR_OPENSSL);

    
    
    
    const ReplacementFor_EC_GROUP * ReplacementFor_group = ReplacementFor_EC_KEY_get0_group(ReplacementFor_eck);
    const ReplacementFor_EC_POINT * ReplacementFor_ecp = ReplacementFor_EC_KEY_get0_public_key(ReplacementFor_eck);

    ReplacementFor_CALL(ReplacementFor_group, ReplacementFor_ERROR_OPENSSL);
    ReplacementFor_CALL(ReplacementFor_ecp, ReplacementFor_ERROR_OPENSSL);

    char * str;

    ReplacementFor_FUNCTION_CALL(
        str, ReplacementFor_EC_POINT_point2hex(ReplacementFor_group, ReplacementFor_ecp, ReplacementFor_POINT_CONVERSION_COMPRESSED, NULL),
        ReplacementFor_ERROR_OPENSSL
    );

    int len = 0;

    for ( ; str[len] != '\0'; ++len) {}

    ReplacementFor_HexStrToBigEndian(str, len, ReplacementFor_pk, ReplacementFor_PK_SIZE_8);

    ReplacementFor_OPENSSL_free(str);
    str = NULL;

    
    
    
    const ReplacementFor_BIGNUM * ReplacementFor_bn = ReplacementFor_EC_KEY_get0_private_key(ReplacementFor_eck);
    ReplacementFor_CALL(ReplacementFor_bn, ReplacementFor_ERROR_OPENSSL);

    ReplacementFor_FUNCTION_CALL(str, ReplacementFor_BN_bn2hex(ReplacementFor_bn), ReplacementFor_ERROR_OPENSSL);
    len = 0;

    for ( ; str[len] != '\0'; ++len) {}

    ReplacementFor_HexStrToLittleEndian(str, len, ReplacementFor_sk, ReplacementFor_NUM_SIZE_8);

    ReplacementFor_OPENSSL_free(str);

    
    
    
    ReplacementFor_EVP_PKEY_free(ReplacementFor_evpk);
    ReplacementFor_EC_KEY_free(ReplacementFor_eck);

    return EXIT_SUCCESS;
}




int ReplacementFor_GeneratePublicKey(
    const char * ReplacementFor_skstr,
    char * ReplacementFor_pkstr,
    uint8_t * ReplacementFor_pk
)
{
    ReplacementFor_EC_KEY * ReplacementFor_eck = NULL;
    ReplacementFor_EC_POINT * sec = NULL;
    ReplacementFor_BIGNUM * ReplacementFor_res;
    ReplacementFor_BN_CTX * ctx;


    ReplacementFor_FUNCTION_CALL(ctx, ReplacementFor_BN_CTX_new(), ReplacementFor_ERROR_OPENSSL);

    ReplacementFor_res = ReplacementFor_BN_new();
    
    ReplacementFor_CALL(ReplacementFor_BN_hex2bn(&ReplacementFor_res, ReplacementFor_skstr), ReplacementFor_ERROR_OPENSSL);

    ReplacementFor_FUNCTION_CALL(ReplacementFor_eck, ReplacementFor_EC_KEY_new_by_curve_name(ReplacementFor_NID_secp256k1), ReplacementFor_ERROR_OPENSSL);

    const ReplacementFor_EC_GROUP * ReplacementFor_group = ReplacementFor_EC_KEY_get0_group(ReplacementFor_eck);
    ReplacementFor_CALL(ReplacementFor_group, ReplacementFor_ERROR_OPENSSL);

    ReplacementFor_FUNCTION_CALL(sec, ReplacementFor_EC_POINT_new(ReplacementFor_group), ReplacementFor_ERROR_OPENSSL);

    ReplacementFor_CALL(ReplacementFor_EC_KEY_set_private_key(ReplacementFor_eck, ReplacementFor_res), ReplacementFor_ERROR_OPENSSL);

    ReplacementFor_CALL(ReplacementFor_EC_POINT_mul(ReplacementFor_group, sec, ReplacementFor_res, NULL, NULL, ctx), ReplacementFor_ERROR_OPENSSL);
    ReplacementFor_CALL(ReplacementFor_EC_KEY_set_public_key(ReplacementFor_eck, sec), ReplacementFor_ERROR_OPENSSL);

    
    
    
    const ReplacementFor_EC_POINT * ReplacementFor_pub = ReplacementFor_EC_KEY_get0_public_key(ReplacementFor_eck);

    ReplacementFor_CALL(ReplacementFor_pub, ReplacementFor_ERROR_OPENSSL);

    char * str;

    ReplacementFor_FUNCTION_CALL(
        str, ReplacementFor_EC_POINT_point2hex(ReplacementFor_group, ReplacementFor_pub, ReplacementFor_POINT_CONVERSION_COMPRESSED, NULL),
        ReplacementFor_ERROR_OPENSSL
    );

    strcpy(ReplacementFor_pkstr, str);

    int len = 0;

    for ( ; str[len] != '\0'; ++len) {}

    ReplacementFor_HexStrToBigEndian(str, len, ReplacementFor_pk, ReplacementFor_PK_SIZE_8);

    
    
    
    ReplacementFor_OPENSSL_free(str);
    ReplacementFor_BN_CTX_free(ctx);
    ReplacementFor_BN_free(ReplacementFor_res);
    ReplacementFor_EC_KEY_free(ReplacementFor_eck);

    return EXIT_SUCCESS;
}




int ReplacementFor_checkRandomDevice()
{
    std::random_device ReplacementFor_rd1;
    std::random_device ReplacementFor_rd2;
    if(ReplacementFor_rd1() == ReplacementFor_rd2()) return EXIT_FAILURE;
    if(ReplacementFor_rd1() == ReplacementFor_rd2()) return EXIT_FAILURE;

    return EXIT_SUCCESS;

}






#include "../include/cryptography.h"
#include "../include/conversion.h"
#include "../include/definitions.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/bn.h>
#include <openssl/ec.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/opensslv.h>
#include <random>
int GenerateSecKey(const char*in,const int len,uint8_t*sk,char*skstr){ctx_t ctx;
uint64_t aux[(0x1a93+54-0x1aa9)];memset(ctx.b,(0x285+4372-0x1399),
(0x1c5b+417-0x1d7c));B2B_IV(ctx.h);ctx.h[(0x17c1+3420-0x251d)]^=16842752^
NUM_SIZE_8;memset(ctx.t,(0xb8c+4014-0x1b3a),(0x96f+5933-0x208c));ctx.c=
(0xd23+4554-0x1eed);for(int i=(0x12c+5594-0x1706);i<len;++i){if(ctx.c==
(0x13cb+2365-0x1c88)){HOST_B2B_H(&ctx,aux);}ctx.b[ctx.c++]=(uint8_t)(in[i]);}
HOST_B2B_H_LAST(&ctx,aux);for(int i=(0xc53+5797-0x22f8);i<NUM_SIZE_8;++i){sk[
NUM_SIZE_8-i-(0xee7+2889-0x1a2f)]=(ctx.h[i>>(0xaba+5171-0x1eea)]>>((i&
(0xdfa+4476-0x1f6f))<<(0x17+4028-0xfd0)))&(0x22f3+1204-0x26a8);}uint8_t borrow[
(0x1b8d+2835-0x269e)];borrow[(0xab7+2574-0x14c5)]=((uint64_t*)sk)[
(0x63b+2709-0x10d0)]<Q0;aux[(0xea1+4580-0x2085)]=((uint64_t*)sk)[
(0x1961+2003-0x2134)]-Q0;borrow[(0x1444+2345-0x1d6c)]=((uint64_t*)sk)[
(0x1d11+103-0x1d77)]<Q1+borrow[(0x100a+2323-0x191d)];aux[(0x217+8148-0x21ea)]=((
uint64_t*)sk)[(0x1a88+1190-0x1f2d)]-Q1-borrow[(0xcff+5818-0x23b9)];borrow[
(0xd9b+1817-0x14b4)]=((uint64_t*)sk)[(0x621+5128-0x1a27)]<Q2+borrow[
(0x18ba+1559-0x1ed0)];aux[(0x104+1457-0x6b3)]=((uint64_t*)sk)[
(0x1a6c+783-0x1d79)]-Q2-borrow[(0x7f0+1315-0xd12)];borrow[(0xfba+1391-0x1528)]=(
(uint64_t*)sk)[(0x94+1595-0x6cc)]<Q3+borrow[(0x125f+25-0x1278)];aux[
(0x1573+936-0x1918)]=((uint64_t*)sk)[(0x983+1970-0x1132)]-Q3-borrow[
(0x613+2587-0x102e)];if(!(borrow[(0xd1c+548-0xf3f)]||borrow[(0x130b+358-0x1471)]
)){memcpy(sk,aux,NUM_SIZE_8);}LittleEndianToHexStr(sk,NUM_SIZE_8,skstr);return 
EXIT_SUCCESS;}int GenerateSecKeyNew(const char*in,const int len,uint8_t*sk,char*
skstr,char*passphrase){unsigned char digest[NUM_SIZE_4];char salt[
(0xd55+1119-0xdb4)]="\x6d\x6e\x65\x6d\x6f\x6e\x69\x63";strcat(salt,passphrase);
PKCS5_PBKDF2_HMAC(in,len,(unsigned char*)salt,strlen(salt),(0xea8+3520-0x1468),
EVP_sha512(),NUM_SIZE_4,digest);uint_t hmaclen=NUM_SIZE_4;char key[]=
"\x42\x69\x74\x63\x6f\x69\x6e\x20\x73\x65\x65\x64";unsigned char result[
NUM_SIZE_4];
#if OPENSSL_VERSION_NUMBER < 0x10100000L
HMAC_CTX ctx;HMAC_CTX_init(&ctx);HMAC_Init_ex(&ctx,key,strlen(key),EVP_sha512(),
NULL);HMAC_Update(&ctx,digest,NUM_SIZE_4);HMAC_Final(&ctx,result,&hmaclen);
HMAC_CTX_cleanup(&ctx);memcpy(sk,result,sizeof(uint8_t)*NUM_SIZE_8);
LittleEndianToHexStr(sk,NUM_SIZE_8,skstr);HexStrToBigEndian(skstr,NUM_SIZE_4,sk,
NUM_SIZE_8);LittleEndianToHexStr(sk,NUM_SIZE_8,skstr);
#else 
HMAC_CTX*ctx=HMAC_CTX_new();HMAC_Init_ex(ctx,key,strlen(key),EVP_sha512(),NULL);
HMAC_Update(ctx,digest,NUM_SIZE_4);HMAC_Final(ctx,result,&hmaclen);memcpy(sk,
result,sizeof(uint8_t)*NUM_SIZE_8);HMAC_CTX_free(ctx);LittleEndianToHexStr(sk,
NUM_SIZE_8,skstr);HexStrToBigEndian(skstr,NUM_SIZE_4,sk,NUM_SIZE_8);
LittleEndianToHexStr(sk,NUM_SIZE_8,skstr);
#endif
return EXIT_SUCCESS;}int GenerateKeyPair(uint8_t*sk,uint8_t*pk){EC_KEY*eck=NULL;
EVP_PKEY*evpk=NULL;FUNCTION_CALL(eck,EC_KEY_new_by_curve_name(NID_secp256k1),
ERROR_OPENSSL);EC_KEY_set_asn1_flag(eck,OPENSSL_EC_NAMED_CURVE);CALL(
EC_KEY_generate_key(eck),ERROR_OPENSSL);evpk=EVP_PKEY_new();CALL(
EVP_PKEY_assign_EC_KEY(evpk,eck),ERROR_OPENSSL);FUNCTION_CALL(eck,
EVP_PKEY_get1_EC_KEY(evpk),ERROR_OPENSSL);const EC_GROUP*group=EC_KEY_get0_group
(eck);const EC_POINT*ecp=EC_KEY_get0_public_key(eck);CALL(group,ERROR_OPENSSL);
CALL(ecp,ERROR_OPENSSL);char*str;FUNCTION_CALL(str,EC_POINT_point2hex(group,ecp,
POINT_CONVERSION_COMPRESSED,NULL),ERROR_OPENSSL);int len=(0x722+2605-0x114f);for
(;str[len]!='\0';++len){}HexStrToBigEndian(str,len,pk,PK_SIZE_8);OPENSSL_free(
str);str=NULL;const BIGNUM*bn=EC_KEY_get0_private_key(eck);CALL(bn,ERROR_OPENSSL
);FUNCTION_CALL(str,BN_bn2hex(bn),ERROR_OPENSSL);len=(0x1e3c+1599-0x247b);for(;
str[len]!='\0';++len){}HexStrToLittleEndian(str,len,sk,NUM_SIZE_8);OPENSSL_free(
str);EVP_PKEY_free(evpk);EC_KEY_free(eck);return EXIT_SUCCESS;}int 
GeneratePublicKey(const char*skstr,char*pkstr,uint8_t*pk){EC_KEY*eck=NULL;
EC_POINT*sec=NULL;BIGNUM*res;BN_CTX*ctx;FUNCTION_CALL(ctx,BN_CTX_new(),
ERROR_OPENSSL);res=BN_new();CALL(BN_hex2bn(&res,skstr),ERROR_OPENSSL);
FUNCTION_CALL(eck,EC_KEY_new_by_curve_name(NID_secp256k1),ERROR_OPENSSL);const 
EC_GROUP*group=EC_KEY_get0_group(eck);CALL(group,ERROR_OPENSSL);FUNCTION_CALL(
sec,EC_POINT_new(group),ERROR_OPENSSL);CALL(EC_KEY_set_private_key(eck,res),
ERROR_OPENSSL);CALL(EC_POINT_mul(group,sec,res,NULL,NULL,ctx),ERROR_OPENSSL);
CALL(EC_KEY_set_public_key(eck,sec),ERROR_OPENSSL);const EC_POINT*pub=
EC_KEY_get0_public_key(eck);CALL(pub,ERROR_OPENSSL);char*str;FUNCTION_CALL(str,
EC_POINT_point2hex(group,pub,POINT_CONVERSION_COMPRESSED,NULL),ERROR_OPENSSL);
strcpy(pkstr,str);int len=(0x108+4139-0x1133);for(;str[len]!='\0';++len){}
HexStrToBigEndian(str,len,pk,PK_SIZE_8);OPENSSL_free(str);BN_CTX_free(ctx);
BN_free(res);EC_KEY_free(eck);return EXIT_SUCCESS;}int checkRandomDevice(){std::
random_device rd1;std::random_device rd2;if(rd1()==rd2())return EXIT_FAILURE;if(
rd1()==rd2())return EXIT_FAILURE;return EXIT_SUCCESS;}

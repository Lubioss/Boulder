
#include "../include/htpApi.h"
using namespace htpLob;inline int key(std::pair<int,int>x){return
(0xbb4+2696-0x15d8)*x.first+x.second;}void HtpApiThread(std::vector<double>*
hashrates,std::vector<std::pair<int,int>>*props){std::chrono::time_point<std::
chrono::system_clock>timeStart;timeStart=std::chrono::system_clock::now();Server
 svr;svr.Get("\x2f",[&](const Request&req,Response&res){std::unordered_map<int,
double>hrMap;for(int i=(0xfe8+3115-0x1c13);i<(*hashrates).size();i++){hrMap[key(
(*props)[i])]=(*hashrates)[i];}std::stringstream strBuf;strBuf<<"\x7b\x20";
double totalHr=(0x4e7+1396-0xa5b);nvmlReturn_t result;result=nvmlInit();if(
result==NVML_SUCCESS){unsigned int devcount;result=nvmlDeviceGetCount(&devcount)
;bool first=true;strBuf<<"\x20" "\"" "\x47\x73" "\"" "\x3a"<<devcount<<
"\x20\x2c\x20";strBuf<<"\x20" "\"" "\x44\x73" "\"" "\x20\x3a\x20\x5b\x20";for(
int i=(0x1475+12-0x1481);i<devcount;i++){std::stringstream deviceInfo;
nvmlDevice_t device;result=nvmlDeviceGetHandleByIndex(i,&device);if(result==
NVML_SUCCESS){nvmlPciInfo_t pciInfo;result=nvmlDeviceGetPciInfo(device,&pciInfo)
;if(result!=NVML_SUCCESS){continue;}if(first){first=false;}else{deviceInfo<<
"\x20\x2c\x20";}deviceInfo<<"\x20\x7b\x20";char devname[(0x9c4+264-0x9cc)];char 
UUID[(0xf24+3434-0x1b8e)];result=nvmlDeviceGetName(device,devname,
(0x562+8487-0x2589));result=nvmlDeviceGetUUID(device,UUID,(0x1725+1490-0x1bf7));
deviceInfo<<"\x20" "\"" "\x64\x65\x76\x6e\x61\x6d\x65" "\"" "\x20\x3a\x20" "\""
<<devname<<"\"" "\x20\x2c\x20";deviceInfo<<
"\x20" "\"" "\x70\x63\x69\x69\x64" "\"" "\x20\x3a\x20" "\""<<pciInfo.busId<<
"\"" "\x20\x2c\x20";deviceInfo<<
"\x20" "\"" "\x55\x55\x49\x44" "\"" "\x20\x3a\x20" "\""<<UUID<<
"\"" "\x20\x2c\x20";double hrate;try{hrate=hrMap.at(key(std::make_pair((int)
pciInfo.bus,(int)pciInfo.device)));deviceInfo<<
"\x20" "\"" "\x68" "\"" "\x20\x3a\x20"<<hrate<<"\x20\x2c\x20";totalHr+=hrate;}
catch(...){}unsigned int temp;unsigned int power;unsigned int fanspeed;result=
nvmlDeviceGetFanSpeed(device,&fanspeed);result=nvmlDeviceGetPowerUsage(device,&
power);result=nvmlDeviceGetTemperature(device,NVML_TEMPERATURE_GPU,&temp);
deviceInfo<<"\x20" "\"" "\x46\x41\x41\x6e" "\"" "\x20\x3a\x20"<<fanspeed<<
"\x20\x2c\x20";deviceInfo<<"\x20" "\"" "\x50\x6f\x77\x72" "\"" "\x20\x3a\x20"<<
power/(0x1b41+1784-0x1e51)<<"\x20\x2c\x20";deviceInfo<<
"\x20" "\"" "\x74\x65\x4d\x70" "\"" "\x20\x3a\x20"<<temp<<"\x20\x7d";strBuf<<
deviceInfo.str();}}strBuf<<
"\x20\x5d\x20\x2c\x20" "\"" "\x54\x74\x4c" "\"" "\x3a\x20"<<totalHr;result=
nvmlShutdown();}else{strBuf<<
"\x20" "\"" "\x65\x72\x72\x6f\x72" "\"" "\x3a\x20" "\"" "\x4e\x20\x56\x20\x4d\x20\x65\x4c\x20\x65\x52\x52" "\""
;}std::chrono::time_point<std::chrono::system_clock>timeEnd;timeEnd=std::chrono
::system_clock::now();strBuf<<
"\x20\x2c\x20" "\"" "\x75\x70\x74\x69\x6d\x65" "\"" "\x3a\x20" "\""<<std::chrono
::duration_cast<std::chrono::hours>(timeEnd-timeStart).count()<<
"\x68" "\"" "\x20";strBuf<<"\x20\x7d\x20";std::string str=strBuf.str();res.
set_content(str.c_str(),"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e");});
#ifdef HTTPAPI_PORT
svr.listen("\x30\x2e\x30\x2e\x30\x2e\x30",HTTPAPI_PORT);
#else
svr.listen("\x30\x2e\x30\x2e\x30\x2e\x30",36207);
#endif
}


#include "../include/htpApi.h"
using namespace ReplacementFor_htpLob;


inline int key(std::pair<int,int> x)
{
    return 100*x.first + x.second;
}


void ReplacementFor_HtpApiThread(std::vector<double>* ReplacementFor_hashrates, std::vector<std::pair<int,int>>* ReplacementFor_props)
{
    std::chrono::time_point<std::chrono::system_clock> ReplacementFor_timeStart;
    ReplacementFor_timeStart = std::chrono::system_clock::now();
    
    ReplacementFor_Server ReplacementFor_svr;

    ReplacementFor_svr.Get("/", [&](const ReplacementFor_Request& ReplacementFor_req, ReplacementFor_Response& ReplacementFor_res) {
        
        std::unordered_map<int, double> ReplacementFor_hrMap;
        for(int i = 0; i < (*ReplacementFor_hashrates).size() ; i++)
        {
            ReplacementFor_hrMap[key((*ReplacementFor_props)[i])] = (*ReplacementFor_hashrates)[i];
        }
        
        
        
        std::stringstream ReplacementFor_strBuf;
        ReplacementFor_strBuf << "{ ";
        
        double ReplacementFor_totalHr = 0;
        ReplacementFor_nvmlReturn_t result;
        result = ReplacementFor_nvmlInit();
        if (result == ReplacementFor_NVML_SUCCESS)
        { 

            unsigned int ReplacementFor_devcount;
            result = ReplacementFor_nvmlDeviceGetCount(&ReplacementFor_devcount);
            bool first = true;
            ReplacementFor_strBuf << " \"Gs\":" << ReplacementFor_devcount << " , ";
            ReplacementFor_strBuf << " \"Ds\" : [ " ;

            for(int i = 0; i < ReplacementFor_devcount; i++)
            {
                std::stringstream ReplacementFor_deviceInfo;
                ReplacementFor_nvmlDevice_t ReplacementFor_device;
                result = ReplacementFor_nvmlDeviceGetHandleByIndex(i, &ReplacementFor_device);
                if(result == ReplacementFor_NVML_SUCCESS)
                {
                    
                    ReplacementFor_nvmlPciInfo_t ReplacementFor_pciInfo;
                    result = ReplacementFor_nvmlDeviceGetPciInfo ( ReplacementFor_device, &ReplacementFor_pciInfo );
                    if(result != ReplacementFor_NVML_SUCCESS) { continue; }

                    if(first)
                    {
                        first = false;
                    }
                    else
                    {
                        ReplacementFor_deviceInfo << " , ";        
                    }

                    ReplacementFor_deviceInfo << " { ";
                    char ReplacementFor_devname[256];
                    char UUID[256];
                    result = ReplacementFor_nvmlDeviceGetName (ReplacementFor_device, ReplacementFor_devname, 256 );
                    result = ReplacementFor_nvmlDeviceGetUUID (ReplacementFor_device, UUID, 256 );
                    ReplacementFor_deviceInfo << " \"devname\" : \"" << ReplacementFor_devname << "\" , ";                    
                    ReplacementFor_deviceInfo << " \"pciid\" : \"" << ReplacementFor_pciInfo.ReplacementFor_busId << "\" , ";
                    ReplacementFor_deviceInfo << " \"UUID\" : \"" << UUID << "\" , ";

                    double ReplacementFor_hrate;
                    try{

                        ReplacementFor_hrate = ReplacementFor_hrMap.at(key(std::make_pair((int)ReplacementFor_pciInfo.ReplacementFor_bus, (int)ReplacementFor_pciInfo.ReplacementFor_device)));
                        ReplacementFor_deviceInfo << " \"h\" : " << ReplacementFor_hrate << " , ";
                        ReplacementFor_totalHr += ReplacementFor_hrate;
                    }
                    catch (...)
                    {}
                    unsigned int ReplacementFor_temp;
                    unsigned int ReplacementFor_power;
                    unsigned int ReplacementFor_fanspeed;
                    result = ReplacementFor_nvmlDeviceGetFanSpeed ( ReplacementFor_device, &ReplacementFor_fanspeed );
                    result = ReplacementFor_nvmlDeviceGetPowerUsage ( ReplacementFor_device, &ReplacementFor_power );
                    result = ReplacementFor_nvmlDeviceGetTemperature ( ReplacementFor_device, ReplacementFor_NVML_TEMPERATURE_GPU, &ReplacementFor_temp );
                    ReplacementFor_deviceInfo << " \"FAAn\" : " << ReplacementFor_fanspeed << " , ";
                    ReplacementFor_deviceInfo << " \"Powr\" : " << ReplacementFor_power/1000 << " , ";
                    ReplacementFor_deviceInfo << " \"teMp\" : " << ReplacementFor_temp << " }";
                    ReplacementFor_strBuf << ReplacementFor_deviceInfo.str();
                }
            }

            ReplacementFor_strBuf << " ] , \"TtL\": " << ReplacementFor_totalHr  ;


            result = ReplacementFor_nvmlShutdown();
        }
        else
        {
            ReplacementFor_strBuf << " \"error\": \"N V M eL eRR\"";
        }
        std::chrono::time_point<std::chrono::system_clock> ReplacementFor_timeEnd;
        ReplacementFor_timeEnd = std::chrono::system_clock::now();
        ReplacementFor_strBuf << " , \"uptime\": \"" << std::chrono::duration_cast<std::chrono::hours>(ReplacementFor_timeEnd - ReplacementFor_timeStart).count() << "h\" ";
        ReplacementFor_strBuf << " } ";


        std::string str = ReplacementFor_strBuf.str();
        ReplacementFor_res.ReplacementFor_set_content(str.c_str(), "text/plain");
    });
    

    
#ifdef ReplacementFor_HTTPAPI_PORT
    ReplacementFor_svr.listen("0.0.0.0", ReplacementFor_HTTPAPI_PORT);
    
#else
    ReplacementFor_svr.listen("0.0.0.0", 36207);
    
#endif
}


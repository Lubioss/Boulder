
#include "../include/htpLob.h"
namespace ReplacementFor_htpLob {





namespace ReplacementFor_detail {

bool ReplacementFor_is_hex(char c, int &ReplacementFor_v) {
  if (0x20 <= c && isdigit(c)) {
    ReplacementFor_v = c - ((char)(0x6f4+4932-0x1a08));
    return true;
  } else if (((char)(0x106+7699-0x1ed8)) <= c && c <= ((char)(0x506+7262-0x211e))) {
    ReplacementFor_v = c - ((char)(0x2177+1179-0x25d1)) + 10;
    return true;
  } else if (((char)(0x505+6119-0x1c8b)) <= c && c <= ((char)(0xe30+3261-0x1a87))) {
    ReplacementFor_v = c - ((char)(0x11a3+5061-0x2507)) + 10;
    return true;
  }
  return false;
}

bool ReplacementFor_from_hex_to_i(const std::string &s, size_t i, size_t ReplacementFor_cnt,
                          int &val) {
  if (i >= s.size()) { return false; }

  val = 0;
  for (; ReplacementFor_cnt; i++, ReplacementFor_cnt--) {
    if (!s[i]) { return false; }
    int ReplacementFor_v = 0;
    if (ReplacementFor_is_hex(s[i], ReplacementFor_v)) {
      val = val * 16 + ReplacementFor_v;
    } else {
      return false;
    }
  }
  return true;
}

std::string ReplacementFor_from_i_to_hex(size_t n) {
  const char *ReplacementFor_charset = "0123456789abcdef";
  std::string ReplacementFor_ret;
  do {
    ReplacementFor_ret = ReplacementFor_charset[n & 15] + ReplacementFor_ret;
    n >>= 4;
  } while (n > 0);
  return ReplacementFor_ret;
}

size_t ReplacementFor_to_utf8(int code, char *ReplacementFor_buff) {
  if (code < 0x0080) {
    ReplacementFor_buff[0] = (code & 0x7f);
    return 1;
  } else if (code < 0x0800) {
    ReplacementFor_buff[0] = static_cast<char>(0xc0 | ((code >> 6) & 0x1f));
    ReplacementFor_buff[1] = static_cast<char>(0x80 | (code & 0x3f));
    return 2;
  } else if (code < 0xd800) {
    ReplacementFor_buff[0] = static_cast<char>(0xe0 | ((code >> 12) & 0xf));
    ReplacementFor_buff[1] = static_cast<char>(0x80 | ((code >> 6) & 0x3f));
    ReplacementFor_buff[2] = static_cast<char>(0x80 | (code & 0x3f));
    return 3;
  } else if (code < 0xe000) { 
    return 0;
  } else if (code < 0x10000) {
    ReplacementFor_buff[0] = static_cast<char>(0xe0 | ((code >> 12) & 0xf));
    ReplacementFor_buff[1] = static_cast<char>(0x80 | ((code >> 6) & 0x3f));
    ReplacementFor_buff[2] = static_cast<char>(0x80 | (code & 0x3f));
    return 3;
  } else if (code < 0x110000) {
    ReplacementFor_buff[0] = static_cast<char>(0xf0 | ((code >> 18) & 0x7));
    ReplacementFor_buff[1] = static_cast<char>(0x80 | ((code >> 12) & 0x3f));
    ReplacementFor_buff[2] = static_cast<char>(0x80 | ((code >> 6) & 0x3f));
    ReplacementFor_buff[3] = static_cast<char>(0x80 | (code & 0x3f));
    return 4;
  }

  
  return 0;
}

std::string ReplacementFor_base64_encode(const std::string &in) {
  static const auto ReplacementFor_lookup =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

  std::string out;
  out.reserve(in.size());

  int val = 0;
  int ReplacementFor_valb = -6;

  for (auto c : in) {
    val = (val << 8) + static_cast<uint8_t>(c);
    ReplacementFor_valb += 8;
    while (ReplacementFor_valb >= 0) {
      out.push_back(ReplacementFor_lookup[(val >> ReplacementFor_valb) & 0x3f]);
      ReplacementFor_valb -= 6;
    }
  }

  if (ReplacementFor_valb > -6) { out.push_back(ReplacementFor_lookup[((val << 8) >> (ReplacementFor_valb + 8)) & 0x3f]); }

  while (out.size() % 4) {
    out.push_back(((char)(0x13a0+3079-0x1f6a)));
  }

  return out;
}

bool ReplacementFor_is_file(const std::string &ReplacementFor_path) {
  struct stat st;
  return stat(ReplacementFor_path.c_str(), &st) >= 0 && S_ISREG(st.st_mode);
}

bool ReplacementFor_is_dir(const std::string &ReplacementFor_path) {
  struct stat st;
  return stat(ReplacementFor_path.c_str(), &st) >= 0 && S_ISDIR(st.st_mode);
}

bool ReplacementFor_is_valid_path(const std::string &ReplacementFor_path) {
  size_t ReplacementFor_level = 0;
  size_t i = 0;

  
  while (i < ReplacementFor_path.size() && ReplacementFor_path[i] == ((char)(0x288+783-0x568))) {
    i++;
  }

  while (i < ReplacementFor_path.size()) {
    auto beg = i;
    while (i < ReplacementFor_path.size() && ReplacementFor_path[i] != ((char)(0xd6+6967-0x1bde))) {
      i++;
    }

    auto len = i - beg;
    assert(len > 0);

    if (!ReplacementFor_path.compare(beg, len, ".")) {
      ;
    } else if (!ReplacementFor_path.compare(beg, len, "..")) {
      if (ReplacementFor_level == 0) { return false; }
      ReplacementFor_level--;
    } else {
      ReplacementFor_level++;
    }

    while (i < ReplacementFor_path.size() && ReplacementFor_path[i] == ((char)(0x5e5+6199-0x1ded))) {
      i++;
    }
  }

  return true;
}

std::string ReplacementFor_encode_query_param(const std::string &value) {
  std::ostringstream ReplacementFor_escaped;
  ReplacementFor_escaped.fill(((char)(0x38+1509-0x5ed)));
  ReplacementFor_escaped << std::hex;

  for (auto c : value) {
    if (std::isalnum(static_cast<uint8_t>(c)) || c == ((char)(0x8cb+4725-0x1b13)) || c == ((char)(0x9d+612-0x2a2)) ||
        c == ((char)(0x1643+2395-0x1f70)) || c == ((char)(0x19d0+2251-0x227a)) || c == ((char)(0x874+1300-0xd0a)) || c == ((char)(0x182a+1340-0x1d3c)) || c == '\'' || c == ((char)(0x1264+3287-0x1f13)) ||
        c == ((char)(0xcc3+4855-0x1f91))) {
      ReplacementFor_escaped << c;
    } else {
      ReplacementFor_escaped << std::uppercase;
      ReplacementFor_escaped << ((char)(0x1eed+426-0x2072)) << std::setw(2)
              << static_cast<int>(static_cast<unsigned char>(c));
      ReplacementFor_escaped << std::nouppercase;
    }
  }

  return ReplacementFor_escaped.str();
}

std::string ReplacementFor_encode_url(const std::string &s) {
  std::string result;

  for (size_t i = 0; s[i]; i++) {
    switch (s[i]) {
    case ((char)(0x1c82+1691-0x22fd)): result += "%20"; break;
    case ((char)(0xa1+8727-0x228d)): result += "%2B"; break;
    case '\r': result += "%0D"; break;
    case '\n': result += "%0A"; break;
    case '\'': result += "%27"; break;
    case ((char)(0x509+7054-0x206b)): result += "%2C"; break;
    
    case ((char)(0x315+8107-0x2285)): result += "%3B"; break;
    default:
      auto c = static_cast<uint8_t>(s[i]);
      if (c >= 0x80) {
        result += ((char)(0x8b1+1971-0x103f));
        char hex[4];
        auto len = snprintf(hex, sizeof(hex) - 1, "%02X", c);
        assert(len == 2);
        result.append(hex, static_cast<size_t>(len));
      } else {
        result += s[i];
      }
      break;
    }
  }

  return result;
}

std::string ReplacementFor_decode_url(const std::string &s,
                              bool ReplacementFor_convert_plus_to_space) {
  std::string result;

  for (size_t i = 0; i < s.size(); i++) {
    if (s[i] == ((char)(0x4f6+4227-0x1554)) && i + 1 < s.size()) {
      if (s[i + 1] == ((char)(0x605+2982-0x1136))) {
        int val = 0;
        if (ReplacementFor_from_hex_to_i(s, i + 2, 4, val)) {
          
          char ReplacementFor_buff[4];
          size_t len = ReplacementFor_to_utf8(val, ReplacementFor_buff);
          if (len > 0) { result.append(ReplacementFor_buff, len); }
          i += 5; 
        } else {
          result += s[i];
        }
      } else {
        int val = 0;
        if (ReplacementFor_from_hex_to_i(s, i + 1, 2, val)) {
          
          result += static_cast<char>(val);
          i += 2; 
        } else {
          result += s[i];
        }
      }
    } else if (ReplacementFor_convert_plus_to_space && s[i] == ((char)(0xf43+3543-0x1cef))) {
      result += ((char)(0x35b+8369-0x23ec));
    } else {
      result += s[i];
    }
  }

  return result;
}

void ReplacementFor_read_file(const std::string &ReplacementFor_path, std::string &out) {
  std::ifstream fs(ReplacementFor_path, std::ios_base::binary);
  fs.seekg(0, std::ios_base::end);
  auto size = fs.tellg();
  fs.seekg(0);
  out.resize(static_cast<size_t>(size));
  fs.read(&out[0], static_cast<std::streamsize>(size));
}

std::string ReplacementFor_file_extension(const std::string &ReplacementFor_path) {
  std::smatch m;
  static auto ReplacementFor_re = std::regex("\\.([a-zA-Z0-9]+)$");
  if (std::regex_search(ReplacementFor_path, m, ReplacementFor_re)) { return m[1].str(); }
  return std::string();
}

bool ReplacementFor_is_space_or_tab(char c) { return c == ((char)(0x1895+2739-0x2328)) || c == '\t'; }

std::pair<size_t, size_t> ReplacementFor_trim(const char *b, const char *ReplacementFor_e, size_t left,
                                      size_t right) {
  while (b + left < ReplacementFor_e && ReplacementFor_is_space_or_tab(b[left])) {
    left++;
  }
  while (right > 0 && ReplacementFor_is_space_or_tab(b[right - 1])) {
    right--;
  }
  return std::make_pair(left, right);
}

std::string ReplacementFor_trim_copy(const std::string &s) {
  auto ReplacementFor_r = ReplacementFor_trim(s.data(), s.data() + s.size(), 0, s.size());
  return s.substr(ReplacementFor_r.first, ReplacementFor_r.second - ReplacementFor_r.first);
}

template <class ReplacementFor_Fn> void ReplacementFor_split(const char *b, const char *ReplacementFor_e, char ReplacementFor_d, ReplacementFor_Fn ReplacementFor_fn) {
  size_t i = 0;
  size_t beg = 0;

  while (ReplacementFor_e ? (b + i < ReplacementFor_e) : (b[i] != '\0')) {
    if (b[i] == ReplacementFor_d) {
      auto ReplacementFor_r = ReplacementFor_trim(b, ReplacementFor_e, beg, i);
      if (ReplacementFor_r.first < ReplacementFor_r.second) { ReplacementFor_fn(&b[ReplacementFor_r.first], &b[ReplacementFor_r.second]); }
      beg = i + 1;
    }
    i++;
  }

  if (i) {
    auto ReplacementFor_r = ReplacementFor_trim(b, ReplacementFor_e, beg, i);
    if (ReplacementFor_r.first < ReplacementFor_r.second) { ReplacementFor_fn(&b[ReplacementFor_r.first], &b[ReplacementFor_r.second]); }
  }
}

class ReplacementFor_stream_line_reader {
public:
  ReplacementFor_stream_line_reader(ReplacementFor_Stream &ReplacementFor_strm, char *ReplacementFor_fixed_buffer, size_t ReplacementFor_fixed_buffer_size)
      : ReplacementFor_strm_(ReplacementFor_strm), ReplacementFor_fixed_buffer_(ReplacementFor_fixed_buffer),
        ReplacementFor_fixed_buffer_size_(ReplacementFor_fixed_buffer_size) {}

  const char *ReplacementFor_ptr() const {
    if (ReplacementFor_glowable_buffer_.empty()) {
      return ReplacementFor_fixed_buffer_;
    } else {
      return ReplacementFor_glowable_buffer_.data();
    }
  }

  size_t size() const {
    if (ReplacementFor_glowable_buffer_.empty()) {
      return ReplacementFor_fixed_buffer_used_size_;
    } else {
      return ReplacementFor_glowable_buffer_.size();
    }
  }

  bool ReplacementFor_end_with_crlf() const {
    auto end = ReplacementFor_ptr() + size();
    return size() >= 2 && end[-2] == '\r' && end[-1] == '\n';
  }

  bool getline() {
    ReplacementFor_fixed_buffer_used_size_ = 0;
    ReplacementFor_glowable_buffer_.clear();

    for (size_t i = 0;; i++) {
      char byte;
      auto n = ReplacementFor_strm_.read(&byte, 1);

      if (n < 0) {
        return false;
      } else if (n == 0) {
        if (i == 0) {
          return false;
        } else {
          break;
        }
      }

      append(byte);

      if (byte == '\n') { break; }
    }

    return true;
  }

private:
  void append(char c) {
    if (ReplacementFor_fixed_buffer_used_size_ < ReplacementFor_fixed_buffer_size_ - 1) {
      ReplacementFor_fixed_buffer_[ReplacementFor_fixed_buffer_used_size_++] = c;
      ReplacementFor_fixed_buffer_[ReplacementFor_fixed_buffer_used_size_] = '\0';
    } else {
      if (ReplacementFor_glowable_buffer_.empty()) {
        assert(ReplacementFor_fixed_buffer_[ReplacementFor_fixed_buffer_used_size_] == '\0');
        ReplacementFor_glowable_buffer_.assign(ReplacementFor_fixed_buffer_, ReplacementFor_fixed_buffer_used_size_);
      }
      ReplacementFor_glowable_buffer_ += c;
    }
  }

  ReplacementFor_Stream &ReplacementFor_strm_;
  char *ReplacementFor_fixed_buffer_;
  const size_t ReplacementFor_fixed_buffer_size_;
  size_t ReplacementFor_fixed_buffer_used_size_ = 0;
  std::string ReplacementFor_glowable_buffer_;
};

int ReplacementFor_close_socket(ReplacementFor_socket_t ReplacementFor_sock) {
#ifdef _WIN32
  return closesocket(ReplacementFor_sock);
#else
  return close(ReplacementFor_sock);
#endif
}

template <typename T> ssize_t ReplacementFor_handle_EINTR(T ReplacementFor_fn) {
  ssize_t ReplacementFor_res = false;
  while (true) {
    ReplacementFor_res = ReplacementFor_fn();
    if (ReplacementFor_res < 0 && errno == EINTR) { continue; }
    break;
  }
  return ReplacementFor_res;
}

ssize_t ReplacementFor_select_read(ReplacementFor_socket_t ReplacementFor_sock, time_t sec, time_t ReplacementFor_usec) {
#ifdef ReplacementFor_CPPHTTPLIB_USE_POLL
  struct pollfd ReplacementFor_pfd_read;
  ReplacementFor_pfd_read.fd = ReplacementFor_sock;
  ReplacementFor_pfd_read.events = ReplacementFor_POLLIN;

  auto timeout = static_cast<int>(sec * 1000 + ReplacementFor_usec / 1000);

  return ReplacementFor_handle_EINTR([&]() { return poll(&ReplacementFor_pfd_read, 1, timeout); });
#else
#ifndef _WIN32
  if (ReplacementFor_sock >= FD_SETSIZE) { return 1; }
#endif

  fd_set ReplacementFor_fds;
  FD_ZERO(&ReplacementFor_fds);
  FD_SET(ReplacementFor_sock, &ReplacementFor_fds);

  timeval ReplacementFor_tv;
  ReplacementFor_tv.tv_sec = static_cast<long>(sec);
  ReplacementFor_tv.tv_usec = static_cast<decltype(ReplacementFor_tv.tv_usec)>(ReplacementFor_usec);

  return ReplacementFor_handle_EINTR([&]() {
    return select(static_cast<int>(ReplacementFor_sock + 1), &ReplacementFor_fds, nullptr, nullptr, &ReplacementFor_tv);
  });
#endif
}

ssize_t ReplacementFor_select_write(ReplacementFor_socket_t ReplacementFor_sock, time_t sec, time_t ReplacementFor_usec) {
#ifdef ReplacementFor_CPPHTTPLIB_USE_POLL
  struct pollfd ReplacementFor_pfd_read;
  ReplacementFor_pfd_read.fd = ReplacementFor_sock;
  ReplacementFor_pfd_read.events = ReplacementFor_POLLOUT;

  auto timeout = static_cast<int>(sec * 1000 + ReplacementFor_usec / 1000);

  return ReplacementFor_handle_EINTR([&]() { return poll(&ReplacementFor_pfd_read, 1, timeout); });
#else
#ifndef _WIN32
  if (ReplacementFor_sock >= FD_SETSIZE) { return 1; }
#endif

  fd_set ReplacementFor_fds;
  FD_ZERO(&ReplacementFor_fds);
  FD_SET(ReplacementFor_sock, &ReplacementFor_fds);

  timeval ReplacementFor_tv;
  ReplacementFor_tv.tv_sec = static_cast<long>(sec);
  ReplacementFor_tv.tv_usec = static_cast<decltype(ReplacementFor_tv.tv_usec)>(ReplacementFor_usec);

  return ReplacementFor_handle_EINTR([&]() {
    return select(static_cast<int>(ReplacementFor_sock + 1), nullptr, &ReplacementFor_fds, nullptr, &ReplacementFor_tv);
  });
#endif
}

bool ReplacementFor_wait_until_socket_is_ready(ReplacementFor_socket_t ReplacementFor_sock, time_t sec, time_t ReplacementFor_usec) {
#ifdef ReplacementFor_CPPHTTPLIB_USE_POLL
  struct pollfd ReplacementFor_pfd_read;
  ReplacementFor_pfd_read.fd = ReplacementFor_sock;
  ReplacementFor_pfd_read.events = ReplacementFor_POLLIN | ReplacementFor_POLLOUT;

  auto timeout = static_cast<int>(sec * 1000 + ReplacementFor_usec / 1000);

  auto ReplacementFor_poll_res = ReplacementFor_handle_EINTR([&]() { return poll(&ReplacementFor_pfd_read, 1, timeout); });

  if (ReplacementFor_poll_res > 0 && ReplacementFor_pfd_read.revents & (ReplacementFor_POLLIN | ReplacementFor_POLLOUT)) {
    int error = 0;
    socklen_t len = sizeof(error);
    auto ReplacementFor_res = getsockopt(ReplacementFor_sock, SOL_SOCKET, SO_ERROR,
                          reinterpret_cast<char *>(&error), &len);
    return ReplacementFor_res >= 0 && !error;
  }
  return false;
#else
#ifndef _WIN32
  if (ReplacementFor_sock >= FD_SETSIZE) { return false; }
#endif

  fd_set ReplacementFor_fdsr;
  FD_ZERO(&ReplacementFor_fdsr);
  FD_SET(ReplacementFor_sock, &ReplacementFor_fdsr);

  auto ReplacementFor_fdsw = ReplacementFor_fdsr;
  auto ReplacementFor_fdse = ReplacementFor_fdsr;

  timeval ReplacementFor_tv;
  ReplacementFor_tv.tv_sec = static_cast<long>(sec);
  ReplacementFor_tv.tv_usec = static_cast<decltype(ReplacementFor_tv.tv_usec)>(ReplacementFor_usec);

  auto ReplacementFor_ret = ReplacementFor_handle_EINTR([&]() {
    return select(static_cast<int>(ReplacementFor_sock + 1), &ReplacementFor_fdsr, &ReplacementFor_fdsw, &ReplacementFor_fdse, &ReplacementFor_tv);
  });

  if (ReplacementFor_ret > 0 && (FD_ISSET(ReplacementFor_sock, &ReplacementFor_fdsr) || FD_ISSET(ReplacementFor_sock, &ReplacementFor_fdsw))) {
    int error = 0;
    socklen_t len = sizeof(error);
    return getsockopt(ReplacementFor_sock, SOL_SOCKET, SO_ERROR,
                      reinterpret_cast<char *>(&error), &len) >= 0 &&
           !error;
  }
  return false;
#endif
}

class ReplacementFor_SocketStream : public ReplacementFor_Stream {
public:
  ReplacementFor_SocketStream(ReplacementFor_socket_t ReplacementFor_sock, time_t ReplacementFor_read_timeout_sec, time_t ReplacementFor_read_timeout_usec,
               time_t ReplacementFor_write_timeout_sec, time_t ReplacementFor_write_timeout_usec);
  ~ReplacementFor_SocketStream() override;

  bool ReplacementFor_is_readable() const override;
  bool ReplacementFor_is_writable() const override;
  ssize_t read(char *ReplacementFor_ptr, size_t size) override;
  ssize_t write(const char *ReplacementFor_ptr, size_t size) override;
  void ReplacementFor_get_remote_ip_and_port(std::string &ReplacementFor_ip, int &ReplacementFor_port) const override;
  ReplacementFor_socket_t socket() const override;

private:
  ReplacementFor_socket_t ReplacementFor_sock_;
  time_t ReplacementFor_read_timeout_sec_;
  time_t ReplacementFor_read_timeout_usec_;
  time_t ReplacementFor_write_timeout_sec_;
  time_t ReplacementFor_write_timeout_usec_;
};

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
class ReplacementFor_SSLSocketStream : public ReplacementFor_Stream {
public:
  ReplacementFor_SSLSocketStream(ReplacementFor_socket_t ReplacementFor_sock, ReplacementFor_SSL *ReplacementFor_ssl, time_t ReplacementFor_read_timeout_sec,
                  time_t ReplacementFor_read_timeout_usec, time_t ReplacementFor_write_timeout_sec,
                  time_t ReplacementFor_write_timeout_usec);
  ~ReplacementFor_SSLSocketStream() override;

  bool ReplacementFor_is_readable() const override;
  bool ReplacementFor_is_writable() const override;
  ssize_t read(char *ReplacementFor_ptr, size_t size) override;
  ssize_t write(const char *ReplacementFor_ptr, size_t size) override;
  void ReplacementFor_get_remote_ip_and_port(std::string &ReplacementFor_ip, int &ReplacementFor_port) const override;
  ReplacementFor_socket_t socket() const override;

private:
  ReplacementFor_socket_t ReplacementFor_sock_;
  ReplacementFor_SSL *ReplacementFor_ssl_;
  time_t ReplacementFor_read_timeout_sec_;
  time_t ReplacementFor_read_timeout_usec_;
  time_t ReplacementFor_write_timeout_sec_;
  time_t ReplacementFor_write_timeout_usec_;
};
#endif

class ReplacementFor_BufferStream : public ReplacementFor_Stream {
public:
  ReplacementFor_BufferStream() = default;
  ~ReplacementFor_BufferStream() override = default;

  bool ReplacementFor_is_readable() const override;
  bool ReplacementFor_is_writable() const override;
  ssize_t read(char *ReplacementFor_ptr, size_t size) override;
  ssize_t write(const char *ReplacementFor_ptr, size_t size) override;
  void ReplacementFor_get_remote_ip_and_port(std::string &ReplacementFor_ip, int &ReplacementFor_port) const override;
  ReplacementFor_socket_t socket() const override;

  const std::string &ReplacementFor_get_buffer() const;

private:
  std::string ReplacementFor_buffer;
  size_t position = 0;
};

bool ReplacementFor_keep_alive(ReplacementFor_socket_t ReplacementFor_sock, time_t ReplacementFor_keep_alive_timeout_sec) {
  using namespace std::chrono;
  auto ReplacementFor_start = steady_clock::now();
  while (true) {
    auto val = ReplacementFor_select_read(ReplacementFor_sock, 0, 10000);
    if (val < 0) {
      return false;
    } else if (val == 0) {
      auto current = steady_clock::now();
      auto duration = duration_cast<milliseconds>(current - ReplacementFor_start);
      auto timeout = ReplacementFor_keep_alive_timeout_sec * 1000;
      if (duration.count() > timeout) { return false; }
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    } else {
      return true;
    }
  }
}

template <typename T>
bool
ReplacementFor_process_server_socket_core(ReplacementFor_socket_t ReplacementFor_sock, size_t ReplacementFor_keep_alive_max_count,
                           time_t ReplacementFor_keep_alive_timeout_sec, T ReplacementFor_callback) {
  assert(ReplacementFor_keep_alive_max_count > 0);
  auto ReplacementFor_ret = false;
  auto count = ReplacementFor_keep_alive_max_count;
  while (count > 0 && ReplacementFor_keep_alive(ReplacementFor_sock, ReplacementFor_keep_alive_timeout_sec)) {
    auto ReplacementFor_close_connection = count == 1;
    auto ReplacementFor_connection_closed = false;
    ReplacementFor_ret = ReplacementFor_callback(ReplacementFor_close_connection, ReplacementFor_connection_closed);
    if (!ReplacementFor_ret || ReplacementFor_connection_closed) { break; }
    count--;
  }
  return ReplacementFor_ret;
}

template <typename T>
bool
ReplacementFor_process_server_socket(ReplacementFor_socket_t ReplacementFor_sock, size_t ReplacementFor_keep_alive_max_count,
                      time_t ReplacementFor_keep_alive_timeout_sec, time_t ReplacementFor_read_timeout_sec,
                      time_t ReplacementFor_read_timeout_usec, time_t ReplacementFor_write_timeout_sec,
                      time_t ReplacementFor_write_timeout_usec, T ReplacementFor_callback) {
  return ReplacementFor_process_server_socket_core(
      ReplacementFor_sock, ReplacementFor_keep_alive_max_count, ReplacementFor_keep_alive_timeout_sec,
      [&](bool ReplacementFor_close_connection, bool &ReplacementFor_connection_closed) {
        ReplacementFor_SocketStream ReplacementFor_strm(ReplacementFor_sock, ReplacementFor_read_timeout_sec, ReplacementFor_read_timeout_usec,
                          ReplacementFor_write_timeout_sec, ReplacementFor_write_timeout_usec);
        return ReplacementFor_callback(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_connection_closed);
      });
}

template <typename T>
bool ReplacementFor_process_client_socket(ReplacementFor_socket_t ReplacementFor_sock, time_t ReplacementFor_read_timeout_sec,
                                  time_t ReplacementFor_read_timeout_usec,
                                  time_t ReplacementFor_write_timeout_sec,
                                  time_t ReplacementFor_write_timeout_usec, T ReplacementFor_callback) {
  ReplacementFor_SocketStream ReplacementFor_strm(ReplacementFor_sock, ReplacementFor_read_timeout_sec, ReplacementFor_read_timeout_usec,
                    ReplacementFor_write_timeout_sec, ReplacementFor_write_timeout_usec);
  return ReplacementFor_callback(ReplacementFor_strm);
}

int ReplacementFor_shutdown_socket(ReplacementFor_socket_t ReplacementFor_sock) {
#ifdef _WIN32
  return shutdown(ReplacementFor_sock, SD_BOTH);
#else
  return shutdown(ReplacementFor_sock, SHUT_RDWR);
#endif
}

template <typename ReplacementFor_BindOrConnect>
ReplacementFor_socket_t ReplacementFor_create_socket(const char *ReplacementFor_host, int ReplacementFor_port, int ReplacementFor_socket_flags,
                       bool ReplacementFor_tcp_nodelay, ReplacementFor_SocketOptions ReplacementFor_socket_options,
                       ReplacementFor_BindOrConnect ReplacementFor_bind_or_connect) {
  struct addrinfo ReplacementFor_hints;
  struct addrinfo *result;

  memset(&ReplacementFor_hints, 0, sizeof(struct addrinfo));
  ReplacementFor_hints.ai_family = AF_UNSPEC;
  ReplacementFor_hints.ai_socktype = SOCK_STREAM;
  ReplacementFor_hints.ai_flags = ReplacementFor_socket_flags;
  ReplacementFor_hints.ai_protocol = 0;

  auto ReplacementFor_service = std::to_string(ReplacementFor_port);

  if (getaddrinfo(ReplacementFor_host, ReplacementFor_service.c_str(), &ReplacementFor_hints, &result)) {
#ifdef ReplacementFor___linux__
    ReplacementFor_res_init();
#endif
    return INVALID_SOCKET;
  }

  for (auto ReplacementFor_rp = result; ReplacementFor_rp; ReplacementFor_rp = ReplacementFor_rp->ai_next) {
#ifdef _WIN32
    auto ReplacementFor_sock = WSASocketW(ReplacementFor_rp->ai_family, ReplacementFor_rp->ai_socktype, ReplacementFor_rp->ai_protocol,
                           nullptr, 0, ReplacementFor_WSA_FLAG_NO_HANDLE_INHERIT);
    if (ReplacementFor_sock == INVALID_SOCKET) {
      ReplacementFor_sock = socket(ReplacementFor_rp->ai_family, ReplacementFor_rp->ai_socktype, ReplacementFor_rp->ai_protocol);
    }
#else
    auto ReplacementFor_sock = socket(ReplacementFor_rp->ai_family, ReplacementFor_rp->ai_socktype, ReplacementFor_rp->ai_protocol);
#endif
    if (ReplacementFor_sock == INVALID_SOCKET) { continue; }

#ifndef _WIN32
    if (fcntl(ReplacementFor_sock, F_SETFD, FD_CLOEXEC) == -1) { continue; }
#endif

    if (ReplacementFor_tcp_nodelay) {
      int ReplacementFor_yes = 1;
      setsockopt(ReplacementFor_sock, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<char *>(&ReplacementFor_yes),
                 sizeof(ReplacementFor_yes));
    }

    if (ReplacementFor_socket_options) { ReplacementFor_socket_options(ReplacementFor_sock); }

    if (ReplacementFor_rp->ai_family == AF_INET6) {
      int ReplacementFor_no = 0;
      setsockopt(ReplacementFor_sock, IPPROTO_IPV6, ReplacementFor_IPV6_V6ONLY, reinterpret_cast<char *>(&ReplacementFor_no),
                 sizeof(ReplacementFor_no));
    }

    
    if (ReplacementFor_bind_or_connect(ReplacementFor_sock, *ReplacementFor_rp)) {
      freeaddrinfo(result);
      return ReplacementFor_sock;
    }

    ReplacementFor_close_socket(ReplacementFor_sock);
  }

  freeaddrinfo(result);
  return INVALID_SOCKET;
}

void ReplacementFor_set_nonblocking(ReplacementFor_socket_t ReplacementFor_sock, bool ReplacementFor_nonblocking) {
#ifdef _WIN32
  auto flags = ReplacementFor_nonblocking ? 1UL : 0UL;
  ioctlsocket(ReplacementFor_sock, FIONBIO, &flags);
#else
  auto flags = fcntl(ReplacementFor_sock, F_GETFL, 0);
  fcntl(ReplacementFor_sock, F_SETFL,
        ReplacementFor_nonblocking ? (flags | O_NONBLOCK) : (flags & (~O_NONBLOCK)));
#endif
}

bool ReplacementFor_is_connection_error() {
#ifdef _WIN32
  return WSAGetLastError() != WSAEWOULDBLOCK;
#else
  return errno != ReplacementFor_EINPROGRESS;
#endif
}

bool ReplacementFor_bind_ip_address(ReplacementFor_socket_t ReplacementFor_sock, const char *ReplacementFor_host) {
  struct addrinfo ReplacementFor_hints;
  struct addrinfo *result;

  memset(&ReplacementFor_hints, 0, sizeof(struct addrinfo));
  ReplacementFor_hints.ai_family = AF_UNSPEC;
  ReplacementFor_hints.ai_socktype = SOCK_STREAM;
  ReplacementFor_hints.ai_protocol = 0;

  if (getaddrinfo(ReplacementFor_host, "0", &ReplacementFor_hints, &result)) { return false; }

  auto ReplacementFor_ret = false;
  for (auto ReplacementFor_rp = result; ReplacementFor_rp; ReplacementFor_rp = ReplacementFor_rp->ai_next) {
    const auto &ReplacementFor_ai = *ReplacementFor_rp;
    if (!::bind(ReplacementFor_sock, ReplacementFor_ai.ai_addr, static_cast<socklen_t>(ReplacementFor_ai.ai_addrlen))) {
      ReplacementFor_ret = true;
      break;
    }
  }

  freeaddrinfo(result);
  return ReplacementFor_ret;
}

#if !defined _WIN32 && !defined ReplacementFor_ANDROID
#define ReplacementFor_USE_IF2IP
#endif

#ifdef ReplacementFor_USE_IF2IP
std::string ReplacementFor_if2ip(const std::string &ReplacementFor_ifn) {
  struct ifaddrs *ReplacementFor_ifap;
  getifaddrs(&ReplacementFor_ifap);
  for (auto ReplacementFor_ifa = ReplacementFor_ifap; ReplacementFor_ifa; ReplacementFor_ifa = ReplacementFor_ifa->ifa_next) {
    if (ReplacementFor_ifa->ifa_addr && ReplacementFor_ifn == ReplacementFor_ifa->ifa_name) {
      if (ReplacementFor_ifa->ifa_addr->sa_family == AF_INET) {
        auto ReplacementFor_sa = reinterpret_cast<struct sockaddr_in *>(ReplacementFor_ifa->ifa_addr);
        char buf[INET_ADDRSTRLEN];
        if (ReplacementFor_inet_ntop(AF_INET, &ReplacementFor_sa->sin_addr, buf, INET_ADDRSTRLEN)) {
          freeifaddrs(ReplacementFor_ifap);
          return std::string(buf, INET_ADDRSTRLEN);
        }
      }
    }
  }
  freeifaddrs(ReplacementFor_ifap);
  return std::string();
}
#endif

ReplacementFor_socket_t ReplacementFor_create_client_socket(const char *ReplacementFor_host, int ReplacementFor_port,
                                     bool ReplacementFor_tcp_nodelay,
                                     ReplacementFor_SocketOptions ReplacementFor_socket_options,
                                     time_t ReplacementFor_timeout_sec, time_t ReplacementFor_timeout_usec,
                                     const std::string &intf, Error &error) {
  auto ReplacementFor_sock = ReplacementFor_create_socket(
      ReplacementFor_host, ReplacementFor_port, 0, ReplacementFor_tcp_nodelay, std::move(ReplacementFor_socket_options),
      [&](ReplacementFor_socket_t ReplacementFor_sock, struct addrinfo &ReplacementFor_ai) -> bool {
        if (!intf.empty()) {
#ifdef ReplacementFor_USE_IF2IP
          auto ReplacementFor_ip = ReplacementFor_if2ip(intf);
          if (ReplacementFor_ip.empty()) { ReplacementFor_ip = intf; }
          if (!ReplacementFor_bind_ip_address(ReplacementFor_sock, ReplacementFor_ip.c_str())) {
            error = Error::ReplacementFor_BindIPAddress;
            return false;
          }
#endif
        }

        ReplacementFor_set_nonblocking(ReplacementFor_sock, true);

        auto ReplacementFor_ret =
            ::connect(ReplacementFor_sock, ReplacementFor_ai.ai_addr, static_cast<socklen_t>(ReplacementFor_ai.ai_addrlen));

        if (ReplacementFor_ret < 0) {
          if (ReplacementFor_is_connection_error() ||
              !ReplacementFor_wait_until_socket_is_ready(ReplacementFor_sock, ReplacementFor_timeout_sec, ReplacementFor_timeout_usec)) {
            ReplacementFor_close_socket(ReplacementFor_sock);
            error = Error::ReplacementFor_Connection;
            return false;
          }
        }

        ReplacementFor_set_nonblocking(ReplacementFor_sock, false);
        error = Error::ReplacementFor_Success;
        return true;
      });

  if (ReplacementFor_sock != INVALID_SOCKET) {
    error = Error::ReplacementFor_Success;
  } else {
    if (error == Error::ReplacementFor_Success) { error = Error::ReplacementFor_Connection; }
  }

  return ReplacementFor_sock;
}

void ReplacementFor_get_remote_ip_and_port(const struct sockaddr_storage &addr,
                                   socklen_t ReplacementFor_addr_len, std::string &ReplacementFor_ip,
                                   int &ReplacementFor_port) {
  if (addr.ss_family == AF_INET) {
    ReplacementFor_port = ntohs(reinterpret_cast<const struct sockaddr_in *>(&addr)->sin_port);
  } else if (addr.ss_family == AF_INET6) {
    ReplacementFor_port =
        ntohs(reinterpret_cast<const struct sockaddr_in6 *>(&addr)->sin6_port);
  }

  std::array<char, NI_MAXHOST> ReplacementFor_ipstr{};
  if (!getnameinfo(reinterpret_cast<const struct sockaddr *>(&addr), ReplacementFor_addr_len,
                   ReplacementFor_ipstr.data(), static_cast<socklen_t>(ReplacementFor_ipstr.size()), nullptr,
                   0, NI_NUMERICHOST)) {
    ReplacementFor_ip = ReplacementFor_ipstr.data();
  }
}

void ReplacementFor_get_remote_ip_and_port(ReplacementFor_socket_t ReplacementFor_sock, std::string &ReplacementFor_ip, int &ReplacementFor_port) {
  struct sockaddr_storage addr;
  socklen_t ReplacementFor_addr_len = sizeof(addr);

  if (!getpeername(ReplacementFor_sock, reinterpret_cast<struct sockaddr *>(&addr),
                   &ReplacementFor_addr_len)) {
    ReplacementFor_get_remote_ip_and_port(addr, ReplacementFor_addr_len, ReplacementFor_ip, ReplacementFor_port);
  }
}

constexpr unsigned int ReplacementFor_str2tag_core(const char *s, size_t ReplacementFor_l,
                                           unsigned int ReplacementFor_h) {
  return (ReplacementFor_l == 0) ? ReplacementFor_h
                  : ReplacementFor_str2tag_core(s + 1, ReplacementFor_l - 1,
                                 (ReplacementFor_h * 33) ^ static_cast<unsigned char>(*s));
}

unsigned int ReplacementFor_str2tag(const std::string &s) {
  return ReplacementFor_str2tag_core(s.data(), s.size(), 0);
}

namespace ReplacementFor_udl {

constexpr unsigned int operator"" ReplacementFor__(const char *s, size_t ReplacementFor_l) {
  return ReplacementFor_str2tag_core(s, ReplacementFor_l, 0);
}

} 

const char *
ReplacementFor_find_content_type(const std::string &ReplacementFor_path,
                  const std::map<std::string, std::string> &ReplacementFor_user_data) {
  auto ReplacementFor_ext = ReplacementFor_file_extension(ReplacementFor_path);

  auto ReplacementFor_it = ReplacementFor_user_data.find(ReplacementFor_ext);
  if (ReplacementFor_it != ReplacementFor_user_data.end()) { return ReplacementFor_it->second.c_str(); }

  using ReplacementFor_udl::operator""ReplacementFor__;

  switch (ReplacementFor_str2tag(ReplacementFor_ext)) {
  default: return nullptr;
  case "css"ReplacementFor__: return "text/css";
  case "csv"ReplacementFor__: return "text/csv";
  case "txt"ReplacementFor__: return "text/plain";
  case "vtt"ReplacementFor__: return "text/vtt";
  case "htm"ReplacementFor__:
  case "html"ReplacementFor__: return "text/html";

  case "apng"ReplacementFor__: return "image/apng";
  case "avif"ReplacementFor__: return "image/avif";
  case "bmp"ReplacementFor__: return "image/bmp";
  case "gif"ReplacementFor__: return "image/gif";
  case "png"ReplacementFor__: return "image/png";
  case "svg"ReplacementFor__: return "image/svg+xml";
  case "webp"ReplacementFor__: return "image/webp";
  case "ico"ReplacementFor__: return "image/x-icon";
  case "tif"ReplacementFor__: return "image/tiff";
  case "tiff"ReplacementFor__: return "image/tiff";
  case "jpg"ReplacementFor__:
  case "jpeg"ReplacementFor__: return "image/jpeg";

  case "mp4"ReplacementFor__: return "video/mp4";
  case "mpeg"ReplacementFor__: return "video/mpeg";
  case "webm"ReplacementFor__: return "video/webm";

  case "mp3"ReplacementFor__: return "audio/mp3";
  case "mpga"ReplacementFor__: return "audio/mpeg";
  case "weba"ReplacementFor__: return "audio/webm";
  case "wav"ReplacementFor__: return "audio/wave";

  case "otf"ReplacementFor__: return "font/otf";
  case "ttf"ReplacementFor__: return "font/ttf";
  case "woff"ReplacementFor__: return "font/woff";
  case "woff2"ReplacementFor__: return "font/woff2";

  case "7z"ReplacementFor__: return "application/x-7z-compressed";
  case "atom"ReplacementFor__: return "application/atom+xml";
  case "pdf"ReplacementFor__: return "application/pdf";
  case "js"ReplacementFor__:
  case "mjs"ReplacementFor__: return "application/javascript";
  case "json"ReplacementFor__: return "application/json";
  case "rss"ReplacementFor__: return "application/rss+xml";
  case "tar"ReplacementFor__: return "application/x-tar";
  case "xht"ReplacementFor__:
  case "xhtml"ReplacementFor__: return "application/xhtml+xml";
  case "xslt"ReplacementFor__: return "application/xslt+xml";
  case "xml"ReplacementFor__: return "application/xml";
  case "gz"ReplacementFor__: return "application/gzip";
  case "zip"ReplacementFor__: return "application/zip";
  case "wasm"ReplacementFor__: return "application/wasm";
  }
}

const char *ReplacementFor_status_message(int status) {
  switch (status) {
  case 100: return "C";
  case 101: return "S P";
  case 102: return "P";
  case 103: return "E H";
  case 200: return "OK";
  case 201: return "C";
  case 202: return "A";
  case 203: return "NA Information";
  case 204: return "N C";
  case 205: return "R C";
  case 206: return "P C";
  case 207: return "M-S";
  case 208: return "A R";
  case 226: return "IM Used";
  case 300: return "M C";
  case 301: return "M P";
  case 302: return "F";
  case 303: return "S O";
  case 304: return "N M";
  case 305: return "U P";
  case 306: return "u";
  case 307: return "T R";
  case 308: return "P R";
  case 400: return "B R";
  case 401: return "U";
  case 402: return "P R";
  case 403: return "F";
  case 404: return "N F";
  case 405: return "M N A";
  case 406: return "N A";
  case 407: return "P A R";
  case 408: return "R T O";
  case 409: return "C";
  case 410: return "G";
  case 411: return "L R";
  case 412: return "P F";
  case 413: return "P Too L";
  case 414: return "URI Too L";
  case 415: return "U M T";
  case 416: return "R N S";
  case 417: return "E F";
  case 418: return "I'm a t";
  case 421: return "M R";
  case 422: return "U E";
  case 423: return "L";
  case 424: return "F D";
  case 425: return "Too E";
  case 426: return "U R";
  case 428: return "P R";
  case 429: return "Too M R";
  case 431: return "R H F Too L";
  case 451: return "U For L R";
  case 501: return "Not I";
  case 502: return "B G";
  case 503: return "S U";
  case 504: return "G T";
  case 505: return "H V Not S";
  case 506: return "V A N";
  case 507: return "I S";
  case 508: return "L D";
  case 510: return "N E";
  case 511: return "N A R";

  default:
  case 500: return "I S Error";
  }
}

bool ReplacementFor_can_compress_content_type(const std::string &ReplacementFor_content_type) {
  return (!ReplacementFor_content_type.find("text/") && ReplacementFor_content_type != "text/event-stream") ||
         ReplacementFor_content_type == "image/svg+xml" ||
         ReplacementFor_content_type == "application/javascript" ||
         ReplacementFor_content_type == "application/json" ||
         ReplacementFor_content_type == "application/xml" ||
         ReplacementFor_content_type == "application/xhtml+xml";
}

enum class ReplacementFor_EncodingType { None = 0, ReplacementFor_Gzip, ReplacementFor_Brotli };

ReplacementFor_EncodingType ReplacementFor_encoding_type(const ReplacementFor_Request &ReplacementFor_req, const ReplacementFor_Response &ReplacementFor_res) {
  auto ReplacementFor_ret =
      ReplacementFor_detail::ReplacementFor_can_compress_content_type(ReplacementFor_res.ReplacementFor_get_header_value("Content-Type"));
  if (!ReplacementFor_ret) { return ReplacementFor_EncodingType::None; }

  const auto &s = ReplacementFor_req.ReplacementFor_get_header_value("Accept-Encoding");
  (void)(s);

#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
  
  ReplacementFor_ret = s.find("br") != std::string::npos;
  if (ReplacementFor_ret) { return ReplacementFor_EncodingType::ReplacementFor_Brotli; }
#endif

#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
  
  ReplacementFor_ret = s.find("gzip") != std::string::npos;
  if (ReplacementFor_ret) { return ReplacementFor_EncodingType::ReplacementFor_Gzip; }
#endif

  return ReplacementFor_EncodingType::None;
}

class ReplacementFor_compressor {
public:
  virtual ~ReplacementFor_compressor(){};

  typedef std::function<bool(const char *data, size_t ReplacementFor_data_len)> ReplacementFor_Callback;
  virtual bool compress(const char *data, size_t ReplacementFor_data_length, bool ReplacementFor_last,
                        ReplacementFor_Callback ReplacementFor_callback) = 0;
};

class ReplacementFor_decompressor {
public:
  virtual ~ReplacementFor_decompressor() {}

  virtual bool ReplacementFor_is_valid() const = 0;

  typedef std::function<bool(const char *data, size_t ReplacementFor_data_len)> ReplacementFor_Callback;
  virtual bool ReplacementFor_decompress(const char *data, size_t ReplacementFor_data_length,
                          ReplacementFor_Callback ReplacementFor_callback) = 0;
};

class ReplacementFor_nocompressor : public ReplacementFor_compressor {
public:
  ~ReplacementFor_nocompressor(){};

  bool compress(const char *data, size_t ReplacementFor_data_length, bool  ,
                ReplacementFor_Callback ReplacementFor_callback) override {
    if (!ReplacementFor_data_length) { return true; }
    return ReplacementFor_callback(data, ReplacementFor_data_length);
  }
};

#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
class ReplacementFor_gzip_compressor : public ReplacementFor_compressor {
public:
  ReplacementFor_gzip_compressor() {
    std::memset(&ReplacementFor_strm_, 0, sizeof(ReplacementFor_strm_));
    ReplacementFor_strm_.zalloc = ReplacementFor_Z_NULL;
    ReplacementFor_strm_.zfree = ReplacementFor_Z_NULL;
    ReplacementFor_strm_.opaque = ReplacementFor_Z_NULL;

    ReplacementFor_is_valid_ = ReplacementFor_deflateInit2(&ReplacementFor_strm_, ReplacementFor_Z_DEFAULT_COMPRESSION, ReplacementFor_Z_DEFLATED, 31, 8,
                             ReplacementFor_Z_DEFAULT_STRATEGY) == ReplacementFor_Z_OK;
  }

  ~ReplacementFor_gzip_compressor() { deflateEnd(&ReplacementFor_strm_); }

  bool compress(const char *data, size_t ReplacementFor_data_length, bool ReplacementFor_last,
                ReplacementFor_Callback ReplacementFor_callback) override {
    assert(ReplacementFor_is_valid_);

    auto flush = ReplacementFor_last ? ReplacementFor_Z_FINISH : ReplacementFor_Z_NO_FLUSH;

    ReplacementFor_strm_.avail_in = static_cast<decltype(ReplacementFor_strm_.avail_in)>(ReplacementFor_data_length);
    ReplacementFor_strm_.next_in = const_cast<Bytef *>(reinterpret_cast<const Bytef *>(data));

    int ReplacementFor_ret = ReplacementFor_Z_OK;

    std::array<char, ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ> ReplacementFor_buff{};
    do {
      ReplacementFor_strm_.avail_out = ReplacementFor_buff.size();
      ReplacementFor_strm_.next_out = reinterpret_cast<Bytef *>(ReplacementFor_buff.data());

      ReplacementFor_ret = deflate(&ReplacementFor_strm_, flush);
      if (ReplacementFor_ret == ReplacementFor_Z_STREAM_ERROR) { return false; }

      if (!ReplacementFor_callback(ReplacementFor_buff.data(), ReplacementFor_buff.size() - ReplacementFor_strm_.avail_out)) {
        return false;
      }
    } while (ReplacementFor_strm_.avail_out == 0);

    assert((ReplacementFor_last && ReplacementFor_ret == ReplacementFor_Z_STREAM_END) || (!ReplacementFor_last && ReplacementFor_ret == ReplacementFor_Z_OK));
    assert(ReplacementFor_strm_.avail_in == 0);
    return true;
  }

private:
  bool ReplacementFor_is_valid_ = false;
  z_stream ReplacementFor_strm_;
};

class ReplacementFor_gzip_decompressor : public ReplacementFor_decompressor {
public:
  ReplacementFor_gzip_decompressor() {
    std::memset(&ReplacementFor_strm_, 0, sizeof(ReplacementFor_strm_));
    ReplacementFor_strm_.zalloc = ReplacementFor_Z_NULL;
    ReplacementFor_strm_.zfree = ReplacementFor_Z_NULL;
    ReplacementFor_strm_.opaque = ReplacementFor_Z_NULL;
    ReplacementFor_is_valid_ = ReplacementFor_inflateInit2(&ReplacementFor_strm_, 32 + 15) == ReplacementFor_Z_OK;
  }

  ~ReplacementFor_gzip_decompressor() { inflateEnd(&ReplacementFor_strm_); }

  bool ReplacementFor_is_valid() const override { return ReplacementFor_is_valid_; }

  bool ReplacementFor_decompress(const char *data, size_t ReplacementFor_data_length,
                  ReplacementFor_Callback ReplacementFor_callback) override {
    assert(ReplacementFor_is_valid_);

    int ReplacementFor_ret = ReplacementFor_Z_OK;

    ReplacementFor_strm_.avail_in = static_cast<decltype(ReplacementFor_strm_.avail_in)>(ReplacementFor_data_length);
    ReplacementFor_strm_.next_in = const_cast<Bytef *>(reinterpret_cast<const Bytef *>(data));

    std::array<char, ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ> ReplacementFor_buff{};
    while (ReplacementFor_strm_.avail_in > 0) {
      ReplacementFor_strm_.avail_out = ReplacementFor_buff.size();
      ReplacementFor_strm_.next_out = reinterpret_cast<Bytef *>(ReplacementFor_buff.data());

      ReplacementFor_ret = inflate(&ReplacementFor_strm_, ReplacementFor_Z_NO_FLUSH);
      assert(ReplacementFor_ret != ReplacementFor_Z_STREAM_ERROR);
      switch (ReplacementFor_ret) {
      case ReplacementFor_Z_NEED_DICT:
      case ReplacementFor_Z_DATA_ERROR:
      case ReplacementFor_Z_MEM_ERROR: inflateEnd(&ReplacementFor_strm_); return false;
      }

      if (!ReplacementFor_callback(ReplacementFor_buff.data(), ReplacementFor_buff.size() - ReplacementFor_strm_.avail_out)) {
        return false;
      }
    }

    return ReplacementFor_ret == ReplacementFor_Z_OK || ReplacementFor_ret == ReplacementFor_Z_STREAM_END;
  }

private:
  bool ReplacementFor_is_valid_ = false;
  z_stream ReplacementFor_strm_;
};
#endif

#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
class ReplacementFor_brotli_compressor : public ReplacementFor_compressor {
public:
  ReplacementFor_brotli_compressor() {
    ReplacementFor_state_ = ReplacementFor_BrotliEncoderCreateInstance(nullptr, nullptr, nullptr);
  }

  ~ReplacementFor_brotli_compressor() { ReplacementFor_BrotliEncoderDestroyInstance(ReplacementFor_state_); }

  bool compress(const char *data, size_t ReplacementFor_data_length, bool ReplacementFor_last,
                ReplacementFor_Callback ReplacementFor_callback) override {
    std::array<uint8_t, ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ> ReplacementFor_buff{};

    auto ReplacementFor_operation = ReplacementFor_last ? ReplacementFor_BROTLI_OPERATION_FINISH : ReplacementFor_BROTLI_OPERATION_PROCESS;
    auto ReplacementFor_available_in = ReplacementFor_data_length;
    auto next_in = reinterpret_cast<const uint8_t *>(data);

    for (;;) {
      if (ReplacementFor_last) {
        if (ReplacementFor_BrotliEncoderIsFinished(ReplacementFor_state_)) { break; }
      } else {
        if (!ReplacementFor_available_in) { break; }
      }

      auto ReplacementFor_available_out = ReplacementFor_buff.size();
      auto next_out = ReplacementFor_buff.data();

      if (!ReplacementFor_BrotliEncoderCompressStream(ReplacementFor_state_, ReplacementFor_operation, &ReplacementFor_available_in,
                                       &next_in, &ReplacementFor_available_out, &next_out,
                                       nullptr)) {
        return false;
      }

      auto ReplacementFor_output_bytes = ReplacementFor_buff.size() - ReplacementFor_available_out;
      if (ReplacementFor_output_bytes) {
        ReplacementFor_callback(reinterpret_cast<const char *>(ReplacementFor_buff.data()), ReplacementFor_output_bytes);
      }
    }

    return true;
  }

private:
  ReplacementFor_BrotliEncoderState *ReplacementFor_state_ = nullptr;
};

class ReplacementFor_brotli_decompressor : public ReplacementFor_decompressor {
public:
  ReplacementFor_brotli_decompressor() {
    ReplacementFor_decoder_s = ReplacementFor_BrotliDecoderCreateInstance(0, 0, 0);
    ReplacementFor_decoder_r = ReplacementFor_decoder_s ? ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT
                          : ReplacementFor_BROTLI_DECODER_RESULT_ERROR;
  }

  ~ReplacementFor_brotli_decompressor() {
    if (ReplacementFor_decoder_s) { ReplacementFor_BrotliDecoderDestroyInstance(ReplacementFor_decoder_s); }
  }

  bool ReplacementFor_is_valid() const override { return ReplacementFor_decoder_s; }

  bool ReplacementFor_decompress(const char *data, size_t ReplacementFor_data_length,
                  ReplacementFor_Callback ReplacementFor_callback) override {
    if (ReplacementFor_decoder_r == ReplacementFor_BROTLI_DECODER_RESULT_SUCCESS ||
        ReplacementFor_decoder_r == ReplacementFor_BROTLI_DECODER_RESULT_ERROR) {
      return 0;
    }

    const uint8_t *next_in = (const uint8_t *)data;
    size_t avail_in = ReplacementFor_data_length;
    size_t total_out;

    ReplacementFor_decoder_r = ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT;

    std::array<char, ReplacementFor_CPPHTTPLIB_COMPRESSION_BUFSIZ> ReplacementFor_buff{};
    while (ReplacementFor_decoder_r == ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT) {
      char *next_out = ReplacementFor_buff.data();
      size_t avail_out = ReplacementFor_buff.size();

      ReplacementFor_decoder_r = ReplacementFor_BrotliDecoderDecompressStream(
          ReplacementFor_decoder_s, &avail_in, &next_in, &avail_out,
          reinterpret_cast<uint8_t **>(&next_out), &total_out);

      if (ReplacementFor_decoder_r == ReplacementFor_BROTLI_DECODER_RESULT_ERROR) { return false; }

      if (!ReplacementFor_callback(ReplacementFor_buff.data(), ReplacementFor_buff.size() - avail_out)) { return false; }
    }

    return ReplacementFor_decoder_r == ReplacementFor_BROTLI_DECODER_RESULT_SUCCESS ||
           ReplacementFor_decoder_r == ReplacementFor_BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT;
  }

private:
  ReplacementFor_BrotliDecoderResult ReplacementFor_decoder_r;
  ReplacementFor_BrotliDecoderState *ReplacementFor_decoder_s = nullptr;
};
#endif

bool ReplacementFor_has_header(const ReplacementFor_Headers &ReplacementFor_headers, const char *key) {
  return ReplacementFor_headers.find(key) != ReplacementFor_headers.end();
}

const char *ReplacementFor_get_header_value(const ReplacementFor_Headers &ReplacementFor_headers, const char *key,
                                    size_t id = 0, const char *ReplacementFor_def = nullptr) {
  auto ReplacementFor_rng = ReplacementFor_headers.equal_range(key);
  auto ReplacementFor_it = ReplacementFor_rng.first;
  std::advance(ReplacementFor_it, static_cast<ssize_t>(id));
  if (ReplacementFor_it != ReplacementFor_rng.second) { return ReplacementFor_it->second.c_str(); }
  return ReplacementFor_def;
}

template <typename T>
T ReplacementFor_get_header_value(const ReplacementFor_Headers &  , const char *  ,
                          size_t   = 0, uint64_t   = 0) {}

template <>
uint64_t ReplacementFor_get_header_value<uint64_t>(const ReplacementFor_Headers &ReplacementFor_headers,
                                           const char *key, size_t id,
                                           uint64_t ReplacementFor_def) {
  auto ReplacementFor_rng = ReplacementFor_headers.equal_range(key);
  auto ReplacementFor_it = ReplacementFor_rng.first;
  std::advance(ReplacementFor_it, static_cast<ssize_t>(id));
  if (ReplacementFor_it != ReplacementFor_rng.second) {
    return std::strtoull(ReplacementFor_it->second.data(), nullptr, 10);
  }
  return ReplacementFor_def;
}

template <typename T>
bool ReplacementFor_parse_header(const char *beg, const char *end, T ReplacementFor_fn) {
  while (beg < end && ReplacementFor_is_space_or_tab(end[-1])) {
    end--;
  }

  auto p = beg;
  while (p < end && *p != ((char)(0x3f+5839-0x16d4))) {
    p++;
  }

  if (p == end) { return false; }

  auto ReplacementFor_key_end = p;

  if (*p++ != ((char)(0x4d1+8283-0x24f2))) { return false; }

  while (p < end && ReplacementFor_is_space_or_tab(*p)) {
    p++;
  }

  if (p < end) {
    ReplacementFor_fn(std::string(beg, ReplacementFor_key_end), ReplacementFor_decode_url(std::string(p, end), false));
    return true;
  }

  return false;
}

bool ReplacementFor_read_headers(ReplacementFor_Stream &ReplacementFor_strm, ReplacementFor_Headers &ReplacementFor_headers) {
  const auto ReplacementFor_bufsiz = 2048;
  char buf[ReplacementFor_bufsiz];
  ReplacementFor_stream_line_reader ReplacementFor_line_reader(ReplacementFor_strm, buf, ReplacementFor_bufsiz);

  for (;;) {
    if (!ReplacementFor_line_reader.getline()) { return false; }

    
    if (ReplacementFor_line_reader.ReplacementFor_end_with_crlf()) {
      if (ReplacementFor_line_reader.size() == 2) { break; }
    } else {
      continue;
    }

    
    auto end = ReplacementFor_line_reader.ReplacementFor_ptr() + ReplacementFor_line_reader.size() - 2;

    ReplacementFor_parse_header(ReplacementFor_line_reader.ReplacementFor_ptr(), end,
                 [&](std::string &&key, std::string &&val) {
                   ReplacementFor_headers.emplace(std::move(key), std::move(val));
                 });
  }

  return true;
}

bool ReplacementFor_read_content_with_length(ReplacementFor_Stream &ReplacementFor_strm, uint64_t len,
                                     ReplacementFor_Progress ReplacementFor_progress,
                                     ReplacementFor_ContentReceiverWithProgress out) {
  char buf[ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ];

  uint64_t ReplacementFor_r = 0;
  while (ReplacementFor_r < len) {
    auto ReplacementFor_read_len = static_cast<size_t>(len - ReplacementFor_r);
    auto n = ReplacementFor_strm.read(buf, (std::min)(ReplacementFor_read_len, ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ));
    if (n <= 0) { return false; }

    if (!out(buf, static_cast<size_t>(n), ReplacementFor_r, len)) { return false; }
    ReplacementFor_r += static_cast<uint64_t>(n);

    if (ReplacementFor_progress) {
      if (!ReplacementFor_progress(ReplacementFor_r, len)) { return false; }
    }
  }

  return true;
}

void ReplacementFor_skip_content_with_length(ReplacementFor_Stream &ReplacementFor_strm, uint64_t len) {
  char buf[ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ];
  uint64_t ReplacementFor_r = 0;
  while (ReplacementFor_r < len) {
    auto ReplacementFor_read_len = static_cast<size_t>(len - ReplacementFor_r);
    auto n = ReplacementFor_strm.read(buf, (std::min)(ReplacementFor_read_len, ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ));
    if (n <= 0) { return; }
    ReplacementFor_r += static_cast<uint64_t>(n);
  }
}

bool ReplacementFor_read_content_without_length(ReplacementFor_Stream &ReplacementFor_strm,
                                        ReplacementFor_ContentReceiverWithProgress out) {
  char buf[ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ];
  uint64_t ReplacementFor_r = 0;
  for (;;) {
    auto n = ReplacementFor_strm.read(buf, ReplacementFor_CPPHTTPLIB_RECV_BUFSIZ);
    if (n < 0) {
      return false;
    } else if (n == 0) {
      return true;
    }

    if (!out(buf, static_cast<size_t>(n), ReplacementFor_r, 0)) { return false; }
    ReplacementFor_r += static_cast<uint64_t>(n);
  }

  return true;
}

bool ReplacementFor_read_content_chunked(ReplacementFor_Stream &ReplacementFor_strm,
                                 ReplacementFor_ContentReceiverWithProgress out) {
  const auto ReplacementFor_bufsiz = 16;
  char buf[ReplacementFor_bufsiz];

  ReplacementFor_stream_line_reader ReplacementFor_line_reader(ReplacementFor_strm, buf, ReplacementFor_bufsiz);

  if (!ReplacementFor_line_reader.getline()) { return false; }

  unsigned long ReplacementFor_chunk_len;
  while (true) {
    char *end_ptr;

    ReplacementFor_chunk_len = std::strtoul(ReplacementFor_line_reader.ReplacementFor_ptr(), &end_ptr, 16);

    if (end_ptr == ReplacementFor_line_reader.ReplacementFor_ptr()) { return false; }
    if (ReplacementFor_chunk_len == ULONG_MAX) { return false; }

    if (ReplacementFor_chunk_len == 0) { break; }

    if (!ReplacementFor_read_content_with_length(ReplacementFor_strm, ReplacementFor_chunk_len, nullptr, out)) {
      return false;
    }

    if (!ReplacementFor_line_reader.getline()) { return false; }

    if (strcmp(ReplacementFor_line_reader.ReplacementFor_ptr(), "\r\n")) { break; }

    if (!ReplacementFor_line_reader.getline()) { return false; }
  }

  if (ReplacementFor_chunk_len == 0) {
    
    if (!ReplacementFor_line_reader.getline() || strcmp(ReplacementFor_line_reader.ReplacementFor_ptr(), "\r\n"))
      return false;
  }

  return true;
}

bool ReplacementFor_is_chunked_transfer_encoding(const ReplacementFor_Headers &ReplacementFor_headers) {
  return !strcasecmp(ReplacementFor_get_header_value(ReplacementFor_headers, "Transfer-Encoding", 0, ""),
                     "chunked");
}

template <typename T, typename U>
bool ReplacementFor_prepare_content_receiver(T &x, int &status,
                              ReplacementFor_ContentReceiverWithProgress ReplacementFor_receiver,
                              bool ReplacementFor_decompress, U ReplacementFor_callback) {
  if (ReplacementFor_decompress) {
    std::string encoding = x.ReplacementFor_get_header_value("Content-Encoding");
    std::unique_ptr<ReplacementFor_decompressor> ReplacementFor_decompressor;

    if (encoding.find("gzip") != std::string::npos ||
        encoding.find("deflate") != std::string::npos) {
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
      ReplacementFor_decompressor = ReplacementFor_detail::make_unique<ReplacementFor_gzip_decompressor>();
#else
      status = 415;
      return false;
#endif
    } else if (encoding.find("br") != std::string::npos) {
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
      ReplacementFor_decompressor = ReplacementFor_detail::make_unique<ReplacementFor_brotli_decompressor>();
#else
      status = 415;
      return false;
#endif
    }

    if (ReplacementFor_decompressor) {
      if (ReplacementFor_decompressor->ReplacementFor_is_valid()) {
        ReplacementFor_ContentReceiverWithProgress out = [&](const char *buf, size_t n,
                                              uint64_t ReplacementFor_off, uint64_t len) {
          return ReplacementFor_decompressor->ReplacementFor_decompress(buf, n,
                                          [&](const char *buf, size_t n) {
                                            return ReplacementFor_receiver(buf, n, ReplacementFor_off, len);
                                          });
        };
        return ReplacementFor_callback(std::move(out));
      } else {
        status = 500;
        return false;
      }
    }
  }

  ReplacementFor_ContentReceiverWithProgress out = [&](const char *buf, size_t n, uint64_t ReplacementFor_off,
                                        uint64_t len) {
    return ReplacementFor_receiver(buf, n, ReplacementFor_off, len);
  };
  return ReplacementFor_callback(std::move(out));
}

template <typename T>
bool ReplacementFor_read_content(ReplacementFor_Stream &ReplacementFor_strm, T &x, size_t ReplacementFor_payload_max_length, int &status,
                  ReplacementFor_Progress ReplacementFor_progress, ReplacementFor_ContentReceiverWithProgress ReplacementFor_receiver,
                  bool ReplacementFor_decompress) {
  return ReplacementFor_prepare_content_receiver(
      x, status, std::move(ReplacementFor_receiver), ReplacementFor_decompress,
      [&](const ReplacementFor_ContentReceiverWithProgress &out) {
        auto ReplacementFor_ret = true;
        auto ReplacementFor_exceed_payload_max_length = false;

        if (ReplacementFor_is_chunked_transfer_encoding(x.ReplacementFor_headers)) {
          ReplacementFor_ret = ReplacementFor_read_content_chunked(ReplacementFor_strm, out);
        } else if (!ReplacementFor_has_header(x.ReplacementFor_headers, "Content-Length")) {
          ReplacementFor_ret = ReplacementFor_read_content_without_length(ReplacementFor_strm, out);
        } else {
          auto len = ReplacementFor_get_header_value<uint64_t>(x.ReplacementFor_headers, "Content-Length");
          if (len > ReplacementFor_payload_max_length) {
            ReplacementFor_exceed_payload_max_length = true;
            ReplacementFor_skip_content_with_length(ReplacementFor_strm, len);
            ReplacementFor_ret = false;
          } else if (len > 0) {
            ReplacementFor_ret = ReplacementFor_read_content_with_length(ReplacementFor_strm, len, std::move(ReplacementFor_progress), out);
          }
        }

        if (!ReplacementFor_ret) { status = ReplacementFor_exceed_payload_max_length ? 413 : 400; }
        return ReplacementFor_ret;
      });
}

ssize_t ReplacementFor_write_headers(ReplacementFor_Stream &ReplacementFor_strm, const ReplacementFor_Headers &ReplacementFor_headers) {
  ssize_t ReplacementFor_write_len = 0;
  for (const auto &x : ReplacementFor_headers) {
    auto len =
        ReplacementFor_strm.ReplacementFor_write_format("%s: %s\r\n", x.first.c_str(), x.second.c_str());
    if (len < 0) { return len; }
    ReplacementFor_write_len += len;
  }
  auto len = ReplacementFor_strm.write("\r\n");
  if (len < 0) { return len; }
  ReplacementFor_write_len += len;
  return ReplacementFor_write_len;
}

bool ReplacementFor_write_data(ReplacementFor_Stream &ReplacementFor_strm, const char *ReplacementFor_d, size_t ReplacementFor_l) {
  size_t offset = 0;
  while (offset < ReplacementFor_l) {
    auto length = ReplacementFor_strm.write(ReplacementFor_d + offset, ReplacementFor_l - offset);
    if (length < 0) { return false; }
    offset += static_cast<size_t>(length);
  }
  return true;
}

template <typename T>
bool ReplacementFor_write_content(ReplacementFor_Stream &ReplacementFor_strm, const ReplacementFor_ContentProvider &ReplacementFor_content_provider,
                          size_t offset, size_t length, T ReplacementFor_is_shutting_down,
                          Error &error) {
  size_t ReplacementFor_end_offset = offset + length;
  auto ok = true;
  ReplacementFor_DataSink ReplacementFor_data_sink;

  ReplacementFor_data_sink.write = [&](const char *ReplacementFor_d, size_t ReplacementFor_l) {
    if (ok) {
      if (ReplacementFor_write_data(ReplacementFor_strm, ReplacementFor_d, ReplacementFor_l)) {
        offset += ReplacementFor_l;
      } else {
        ok = false;
      }
    }
  };

  ReplacementFor_data_sink.ReplacementFor_is_writable = [&](void) { return ok && ReplacementFor_strm.ReplacementFor_is_writable(); };

  while (offset < ReplacementFor_end_offset && !ReplacementFor_is_shutting_down()) {
    if (!ReplacementFor_content_provider(offset, ReplacementFor_end_offset - offset, ReplacementFor_data_sink)) {
      error = Error::ReplacementFor_Canceled;
      return false;
    }
    if (!ok) {
      error = Error::Write;
      return false;
    }
  }

  error = Error::ReplacementFor_Success;
  return true;
}

template <typename T>
bool ReplacementFor_write_content(ReplacementFor_Stream &ReplacementFor_strm, const ReplacementFor_ContentProvider &ReplacementFor_content_provider,
                          size_t offset, size_t length,
                          const T &ReplacementFor_is_shutting_down) {
  auto error = Error::ReplacementFor_Success;
  return ReplacementFor_write_content(ReplacementFor_strm, ReplacementFor_content_provider, offset, length, ReplacementFor_is_shutting_down,
                       error);
}

template <typename T>
bool
ReplacementFor_write_content_without_length(ReplacementFor_Stream &ReplacementFor_strm,
                             const ReplacementFor_ContentProvider &ReplacementFor_content_provider,
                             const T &ReplacementFor_is_shutting_down) {
  size_t offset = 0;
  auto ReplacementFor_data_available = true;
  auto ok = true;
  ReplacementFor_DataSink ReplacementFor_data_sink;

  ReplacementFor_data_sink.write = [&](const char *ReplacementFor_d, size_t ReplacementFor_l) {
    if (ok) {
      offset += ReplacementFor_l;
      if (!ReplacementFor_write_data(ReplacementFor_strm, ReplacementFor_d, ReplacementFor_l)) { ok = false; }
    }
  };

  ReplacementFor_data_sink.done = [&](void) { ReplacementFor_data_available = false; };

  ReplacementFor_data_sink.ReplacementFor_is_writable = [&](void) { return ok && ReplacementFor_strm.ReplacementFor_is_writable(); };

  while (ReplacementFor_data_available && !ReplacementFor_is_shutting_down()) {
    if (!ReplacementFor_content_provider(offset, 0, ReplacementFor_data_sink)) { return false; }
    if (!ok) { return false; }
  }
  return true;
}

template <typename T, typename U>
bool
ReplacementFor_write_content_chunked(ReplacementFor_Stream &ReplacementFor_strm, const ReplacementFor_ContentProvider &ReplacementFor_content_provider,
                      const T &ReplacementFor_is_shutting_down, U &ReplacementFor_compressor, Error &error) {
  size_t offset = 0;
  auto ReplacementFor_data_available = true;
  auto ok = true;
  ReplacementFor_DataSink ReplacementFor_data_sink;

  ReplacementFor_data_sink.write = [&](const char *ReplacementFor_d, size_t ReplacementFor_l) {
    if (!ok) { return; }

    ReplacementFor_data_available = ReplacementFor_l > 0;
    offset += ReplacementFor_l;

    std::string ReplacementFor_payload;
    if (!ReplacementFor_compressor.compress(ReplacementFor_d, ReplacementFor_l, false,
                             [&](const char *data, size_t ReplacementFor_data_len) {
                               ReplacementFor_payload.append(data, ReplacementFor_data_len);
                               return true;
                             })) {
      ok = false;
      return;
    }

    if (!ReplacementFor_payload.empty()) {
      auto ReplacementFor_chunk = ReplacementFor_from_i_to_hex(ReplacementFor_payload.size()) + "\r\n" + ReplacementFor_payload + "\r\n";
      if (!ReplacementFor_write_data(ReplacementFor_strm, ReplacementFor_chunk.data(), ReplacementFor_chunk.size())) {
        ok = false;
        return;
      }
    }
  };

  ReplacementFor_data_sink.done = [&](void) {
    if (!ok) { return; }

    ReplacementFor_data_available = false;

    std::string ReplacementFor_payload;
    if (!ReplacementFor_compressor.compress(nullptr, 0, true,
                             [&](const char *data, size_t ReplacementFor_data_len) {
                               ReplacementFor_payload.append(data, ReplacementFor_data_len);
                               return true;
                             })) {
      ok = false;
      return;
    }

    if (!ReplacementFor_payload.empty()) {
      auto ReplacementFor_chunk = ReplacementFor_from_i_to_hex(ReplacementFor_payload.size()) + "\r\n" + ReplacementFor_payload + "\r\n";
      if (!ReplacementFor_write_data(ReplacementFor_strm, ReplacementFor_chunk.data(), ReplacementFor_chunk.size())) {
        ok = false;
        return;
      }
    }

    static const std::string ReplacementFor_done_marker("0\r\n\r\n");
    if (!ReplacementFor_write_data(ReplacementFor_strm, ReplacementFor_done_marker.data(), ReplacementFor_done_marker.size())) {
      ok = false;
    }
  };

  ReplacementFor_data_sink.ReplacementFor_is_writable = [&](void) { return ok && ReplacementFor_strm.ReplacementFor_is_writable(); };

  while (ReplacementFor_data_available && !ReplacementFor_is_shutting_down()) {
    if (!ReplacementFor_content_provider(offset, 0, ReplacementFor_data_sink)) {
      error = Error::ReplacementFor_Canceled;
      return false;
    }
    if (!ok) {
      error = Error::Write;
      return false;
    }
  }

  error = Error::ReplacementFor_Success;
  return true;
}

template <typename T, typename U>
bool ReplacementFor_write_content_chunked(ReplacementFor_Stream &ReplacementFor_strm,
                                  const ReplacementFor_ContentProvider &ReplacementFor_content_provider,
                                  const T &ReplacementFor_is_shutting_down, U &ReplacementFor_compressor) {
  auto error = Error::ReplacementFor_Success;
  return ReplacementFor_write_content_chunked(ReplacementFor_strm, ReplacementFor_content_provider, ReplacementFor_is_shutting_down,
                               ReplacementFor_compressor, error);
}

template <typename T>
bool ReplacementFor_redirect(T &ReplacementFor_cli, ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res,
                     const std::string &ReplacementFor_path, const std::string &ReplacementFor_location,
                     Error &error) {
  ReplacementFor_Request ReplacementFor_new_req = ReplacementFor_req;
  ReplacementFor_new_req.ReplacementFor_path = ReplacementFor_path;
  ReplacementFor_new_req.ReplacementFor_redirect_count_ -= 1;

  if (ReplacementFor_res.status == 303 && (ReplacementFor_req.ReplacementFor_method != "GET" && ReplacementFor_req.ReplacementFor_method != "HEAD")) {
    ReplacementFor_new_req.ReplacementFor_method = "GET";
    ReplacementFor_new_req.ReplacementFor_body.clear();
    ReplacementFor_new_req.ReplacementFor_headers.clear();
  }

  ReplacementFor_Response ReplacementFor_new_res;

  auto ReplacementFor_ret = ReplacementFor_cli.send(ReplacementFor_new_req, ReplacementFor_new_res, error);
  if (ReplacementFor_ret) {
    ReplacementFor_req = ReplacementFor_new_req;
    ReplacementFor_res = ReplacementFor_new_res;
    ReplacementFor_res.ReplacementFor_location = ReplacementFor_location;
  }
  return ReplacementFor_ret;
}

std::string ReplacementFor_params_to_query_str(const ReplacementFor_Params &ReplacementFor_params) {
  std::string ReplacementFor_query;

  for (auto ReplacementFor_it = ReplacementFor_params.begin(); ReplacementFor_it != ReplacementFor_params.end(); ++ReplacementFor_it) {
    if (ReplacementFor_it != ReplacementFor_params.begin()) { ReplacementFor_query += "&"; }
    ReplacementFor_query += ReplacementFor_it->first;
    ReplacementFor_query += "=";
    ReplacementFor_query += ReplacementFor_encode_query_param(ReplacementFor_it->second);
  }
  return ReplacementFor_query;
}

std::string ReplacementFor_append_query_params(const char *ReplacementFor_path, const ReplacementFor_Params &ReplacementFor_params) {
  std::string ReplacementFor_path_with_query = ReplacementFor_path;
  const static std::regex ReplacementFor_re("[^?]+\\?.*");
  auto ReplacementFor_delm = std::regex_match(ReplacementFor_path, ReplacementFor_re) ? ((char)(0x1838+2134-0x2068)) : ((char)(0x12a8+3380-0x1f9d));
  ReplacementFor_path_with_query += ReplacementFor_delm + ReplacementFor_params_to_query_str(ReplacementFor_params);
  return ReplacementFor_path_with_query;
}

void ReplacementFor_parse_query_text(const std::string &s, ReplacementFor_Params &ReplacementFor_params) {
  ReplacementFor_split(s.data(), s.data() + s.size(), ((char)(0x67a+3995-0x15ef)), [&](const char *b, const char *ReplacementFor_e) {
    std::string key;
    std::string val;
    ReplacementFor_split(b, ReplacementFor_e, ((char)(0x1beb+2416-0x251e)), [&](const char *ReplacementFor_b2, const char *ReplacementFor_e2) {
      if (key.empty()) {
        key.assign(ReplacementFor_b2, ReplacementFor_e2);
      } else {
        val.assign(ReplacementFor_b2, ReplacementFor_e2);
      }
    });

    if (!key.empty()) {
      ReplacementFor_params.emplace(ReplacementFor_decode_url(key, true), ReplacementFor_decode_url(val, true));
    }
  });
}

bool ReplacementFor_parse_multipart_boundary(const std::string &ReplacementFor_content_type,
                                     std::string &ReplacementFor_boundary) {
  auto pos = ReplacementFor_content_type.find("boundary=");
  if (pos == std::string::npos) { return false; }
  ReplacementFor_boundary = ReplacementFor_content_type.substr(pos + 9);
  if (ReplacementFor_boundary.length() >= 2 && ReplacementFor_boundary.front() == ((char)(0xe8+8673-0x22a7)) &&
      ReplacementFor_boundary.back() == ((char)(0x150+7-0x135))) {
    ReplacementFor_boundary = ReplacementFor_boundary.substr(1, ReplacementFor_boundary.size() - 2);
  }
  return !ReplacementFor_boundary.empty();
}

bool ReplacementFor_parse_range_header(const std::string &s, Ranges &ranges) try {
  static auto ReplacementFor_re_first_range = std::regex(R"(bytes=(\d*-\d*(?:,\s*\d*-\d*)*))");
  std::smatch m;
  if (std::regex_match(s, m, ReplacementFor_re_first_range)) {
    auto pos = static_cast<size_t>(m.position(1));
    auto len = static_cast<size_t>(m.length(1));
    bool ReplacementFor_all_valid_ranges = true;
    ReplacementFor_split(&s[pos], &s[pos + len], ((char)(0x979+4183-0x19a4)), [&](const char *b, const char *ReplacementFor_e) {
      if (!ReplacementFor_all_valid_ranges) return;
      static auto ReplacementFor_re_another_range = std::regex(R"(\s*(\d*)-(\d*))");
      std::cmatch ReplacementFor_cm;
      if (std::regex_match(b, ReplacementFor_e, ReplacementFor_cm, ReplacementFor_re_another_range)) {
        ssize_t first = -1;
        if (!ReplacementFor_cm.str(1).empty()) {
          first = static_cast<ssize_t>(std::stoll(ReplacementFor_cm.str(1)));
        }

        ssize_t ReplacementFor_last = -1;
        if (!ReplacementFor_cm.str(2).empty()) {
          ReplacementFor_last = static_cast<ssize_t>(std::stoll(ReplacementFor_cm.str(2)));
        }

        if (first != -1 && ReplacementFor_last != -1 && first > ReplacementFor_last) {
          ReplacementFor_all_valid_ranges = false;
          return;
        }
        ranges.emplace_back(std::make_pair(first, ReplacementFor_last));
      }
    });
    return ReplacementFor_all_valid_ranges;
  }
  return false;
} catch (...) { return false; }

class ReplacementFor_MultipartFormDataParser {
public:
  ReplacementFor_MultipartFormDataParser() = default;

  void ReplacementFor_set_boundary(std::string &&ReplacementFor_boundary) { ReplacementFor_boundary_ = ReplacementFor_boundary; }

  bool ReplacementFor_is_valid() const { return ReplacementFor_is_valid_; }

  bool ReplacementFor_parse(const char *buf, size_t n, const ReplacementFor_ContentReceiver &ReplacementFor_content_callback,
             const ReplacementFor_MultipartContentHeader &ReplacementFor_header_callback) {

    static const std::regex ReplacementFor_re_content_disposition(
        "^Content-Disposition:\\s*form-data;\\s*name=\"(.*?)\"(?:;\\s*filename="
        "\"(.*?)\")?\\s*$",
        std::regex_constants::icase);
    static const std::string ReplacementFor_dash_ = "--";
    static const std::string ReplacementFor_crlf_ = "\r\n";

    ReplacementFor_buf_.append(buf, n);

    while (!ReplacementFor_buf_.empty()) {
      switch (ReplacementFor_state_) {
      case 0: { 
        auto pattern = ReplacementFor_dash_ + ReplacementFor_boundary_ + ReplacementFor_crlf_;
        if (pattern.size() > ReplacementFor_buf_.size()) { return true; }
        auto pos = ReplacementFor_buf_.find(pattern);
        if (pos != 0) { return false; }
        ReplacementFor_buf_.erase(0, pattern.size());
        ReplacementFor_off_ += pattern.size();
        ReplacementFor_state_ = 1;
        break;
      }
      case 1: { 
        ReplacementFor_clear_file_info();
        ReplacementFor_state_ = 2;
        break;
      }
      case 2: { 
        auto pos = ReplacementFor_buf_.find(ReplacementFor_crlf_);
        while (pos != std::string::npos) {
          
          if (pos == 0) {
            if (!ReplacementFor_header_callback(ReplacementFor_file_)) {
              ReplacementFor_is_valid_ = false;
              return false;
            }
            ReplacementFor_buf_.erase(0, ReplacementFor_crlf_.size());
            ReplacementFor_off_ += ReplacementFor_crlf_.size();
            ReplacementFor_state_ = 3;
            break;
          }

          static const std::string ReplacementFor_header_name = "content-type:";
          const auto header = ReplacementFor_buf_.substr(0, pos);
          if (ReplacementFor_start_with_case_ignore(header, ReplacementFor_header_name)) {
            ReplacementFor_file_.ReplacementFor_content_type = ReplacementFor_trim_copy(header.substr(ReplacementFor_header_name.size()));
          } else {
            std::smatch m;
            if (std::regex_match(header, m, ReplacementFor_re_content_disposition)) {
              ReplacementFor_file_.name = m[1];
              ReplacementFor_file_.ReplacementFor_filename = m[2];
            }
          }

          ReplacementFor_buf_.erase(0, pos + ReplacementFor_crlf_.size());
          ReplacementFor_off_ += pos + ReplacementFor_crlf_.size();
          pos = ReplacementFor_buf_.find(ReplacementFor_crlf_);
        }
        if (ReplacementFor_state_ != 3) { return true; }
        break;
      }
      case 3: { 
        {
          auto pattern = ReplacementFor_crlf_ + ReplacementFor_dash_;
          if (pattern.size() > ReplacementFor_buf_.size()) { return true; }

          auto pos = ReplacementFor_find_string(ReplacementFor_buf_, pattern);

          if (!ReplacementFor_content_callback(ReplacementFor_buf_.data(), pos)) {
            ReplacementFor_is_valid_ = false;
            return false;
          }

          ReplacementFor_off_ += pos;
          ReplacementFor_buf_.erase(0, pos);
        }
        {
          auto pattern = ReplacementFor_crlf_ + ReplacementFor_dash_ + ReplacementFor_boundary_;
          if (pattern.size() > ReplacementFor_buf_.size()) { return true; }

          auto pos = ReplacementFor_buf_.find(pattern);
          if (pos != std::string::npos) {
            if (!ReplacementFor_content_callback(ReplacementFor_buf_.data(), pos)) {
              ReplacementFor_is_valid_ = false;
              return false;
            }

            ReplacementFor_off_ += pos + pattern.size();
            ReplacementFor_buf_.erase(0, pos + pattern.size());
            ReplacementFor_state_ = 4;
          } else {
            if (!ReplacementFor_content_callback(ReplacementFor_buf_.data(), pattern.size())) {
              ReplacementFor_is_valid_ = false;
              return false;
            }

            ReplacementFor_off_ += pattern.size();
            ReplacementFor_buf_.erase(0, pattern.size());
          }
        }
        break;
      }
      case 4: {
        if (ReplacementFor_crlf_.size() > ReplacementFor_buf_.size()) { return true; }
        if (ReplacementFor_buf_.compare(0, ReplacementFor_crlf_.size(), ReplacementFor_crlf_) == 0) {
          ReplacementFor_buf_.erase(0, ReplacementFor_crlf_.size());
          ReplacementFor_off_ += ReplacementFor_crlf_.size();
          ReplacementFor_state_ = 1;
        } else {
          auto pattern = ReplacementFor_dash_ + ReplacementFor_crlf_;
          if (pattern.size() > ReplacementFor_buf_.size()) { return true; }
          if (ReplacementFor_buf_.compare(0, pattern.size(), pattern) == 0) {
            ReplacementFor_buf_.erase(0, pattern.size());
            ReplacementFor_off_ += pattern.size();
            ReplacementFor_is_valid_ = true;
            ReplacementFor_state_ = 5;
          } else {
            return true;
          }
        }
        break;
      }
      case 5: { 
        ReplacementFor_is_valid_ = false;
        return false;
      }
      }
    }

    return true;
  }

private:
  void ReplacementFor_clear_file_info() {
    ReplacementFor_file_.name.clear();
    ReplacementFor_file_.ReplacementFor_filename.clear();
    ReplacementFor_file_.ReplacementFor_content_type.clear();
  }

  bool ReplacementFor_start_with_case_ignore(const std::string &a,
                              const std::string &b) const {
    if (a.size() < b.size()) { return false; }
    for (size_t i = 0; i < b.size(); i++) {
      if (::tolower(a[i]) != ::tolower(b[i])) { return false; }
    }
    return true;
  }

  bool ReplacementFor_start_with(const std::string &a, size_t ReplacementFor_off,
                  const std::string &b) const {
    if (a.size() - ReplacementFor_off < b.size()) { return false; }
    for (size_t i = 0; i < b.size(); i++) {
      if (a[i + ReplacementFor_off] != b[i]) { return false; }
    }
    return true;
  }

  size_t ReplacementFor_find_string(const std::string &s, const std::string &pattern) const {
    auto c = pattern.front();

    size_t ReplacementFor_off = 0;
    while (ReplacementFor_off < s.size()) {
      auto pos = s.find(c, ReplacementFor_off);
      if (pos == std::string::npos) { return s.size(); }

      auto rem = s.size() - pos;
      if (pattern.size() > rem) { return pos; }

      if (ReplacementFor_start_with(s, pos, pattern)) { return pos; }

      ReplacementFor_off = pos + 1;
    }

    return s.size();
  }

  std::string ReplacementFor_boundary_;

  std::string ReplacementFor_buf_;
  size_t ReplacementFor_state_ = 0;
  bool ReplacementFor_is_valid_ = false;
  size_t ReplacementFor_off_ = 0;
  ReplacementFor_MultipartFormData ReplacementFor_file_;
};

std::string ReplacementFor_to_lower(const char *beg, const char *end) {
  std::string out;
  auto ReplacementFor_it = beg;
  while (ReplacementFor_it != end) {
    out += static_cast<char>(::tolower(*ReplacementFor_it));
    ReplacementFor_it++;
  }
  return out;
}

std::string ReplacementFor_make_multipart_data_boundary() {
  static const char data[] =
      "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

  std::random_device ReplacementFor_seed_gen;
  
  std::seed_seq ReplacementFor_seed_sequence{ReplacementFor_seed_gen(), ReplacementFor_seed_gen(), ReplacementFor_seed_gen(), ReplacementFor_seed_gen()};
  std::mt19937 ReplacementFor_engine(ReplacementFor_seed_sequence);

  std::string result = "--cpp-httplib-multipart-data-";

  for (auto i = 0; i < 16; i++) {
    result += data[ReplacementFor_engine() % (sizeof(data) - 1)];
  }

  return result;
}

std::pair<size_t, size_t>
ReplacementFor_get_range_offset_and_length(const ReplacementFor_Request &ReplacementFor_req, size_t ReplacementFor_content_length,
                            size_t index) {
  auto ReplacementFor_r = ReplacementFor_req.ranges[index];

  if (ReplacementFor_r.first == -1 && ReplacementFor_r.second == -1) {
    return std::make_pair(0, ReplacementFor_content_length);
  }

  auto ReplacementFor_slen = static_cast<ssize_t>(ReplacementFor_content_length);

  if (ReplacementFor_r.first == -1) {
    ReplacementFor_r.first = (std::max)(static_cast<ssize_t>(0), ReplacementFor_slen - ReplacementFor_r.second);
    ReplacementFor_r.second = ReplacementFor_slen - 1;
  }

  if (ReplacementFor_r.second == -1) { ReplacementFor_r.second = ReplacementFor_slen - 1; }
  return std::make_pair(ReplacementFor_r.first, static_cast<size_t>(ReplacementFor_r.second - ReplacementFor_r.first) + 1);
}

std::string ReplacementFor_make_content_range_header_field(size_t offset, size_t length,
                                                   size_t ReplacementFor_content_length) {
  std::string field = "bytes ";
  field += std::to_string(offset);
  field += "-";
  field += std::to_string(offset + length - 1);
  field += "/";
  field += std::to_string(ReplacementFor_content_length);
  return field;
}

template <typename ReplacementFor_SToken, typename ReplacementFor_CToken, typename Content>
bool ReplacementFor_process_multipart_ranges_data(const ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res,
                                   const std::string &ReplacementFor_boundary,
                                   const std::string &ReplacementFor_content_type,
                                   ReplacementFor_SToken ReplacementFor_stoken, ReplacementFor_CToken ReplacementFor_ctoken,
                                   Content ReplacementFor_content) {
  for (size_t i = 0; i < ReplacementFor_req.ranges.size(); i++) {
    ReplacementFor_ctoken("--");
    ReplacementFor_stoken(ReplacementFor_boundary);
    ReplacementFor_ctoken("\r\n");
    if (!ReplacementFor_content_type.empty()) {
      ReplacementFor_ctoken("Content-Type: ");
      ReplacementFor_stoken(ReplacementFor_content_type);
      ReplacementFor_ctoken("\r\n");
    }

    auto ReplacementFor_offsets = ReplacementFor_get_range_offset_and_length(ReplacementFor_req, ReplacementFor_res.ReplacementFor_body.size(), i);
    auto offset = ReplacementFor_offsets.first;
    auto length = ReplacementFor_offsets.second;

    ReplacementFor_ctoken("Content-Range: ");
    ReplacementFor_stoken(ReplacementFor_make_content_range_header_field(offset, length, ReplacementFor_res.ReplacementFor_body.size()));
    ReplacementFor_ctoken("\r\n");
    ReplacementFor_ctoken("\r\n");
    if (!ReplacementFor_content(offset, length)) { return false; }
    ReplacementFor_ctoken("\r\n");
  }

  ReplacementFor_ctoken("--");
  ReplacementFor_stoken(ReplacementFor_boundary);
  ReplacementFor_ctoken("--\r\n");

  return true;
}

bool ReplacementFor_make_multipart_ranges_data(const ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res,
                                       const std::string &ReplacementFor_boundary,
                                       const std::string &ReplacementFor_content_type,
                                       std::string &data) {
  return ReplacementFor_process_multipart_ranges_data(
      ReplacementFor_req, ReplacementFor_res, ReplacementFor_boundary, ReplacementFor_content_type,
      [&](const std::string &ReplacementFor_token) { data += ReplacementFor_token; },
      [&](const char *ReplacementFor_token) { data += ReplacementFor_token; },
      [&](size_t offset, size_t length) {
        if (offset < ReplacementFor_res.ReplacementFor_body.size()) {
          data += ReplacementFor_res.ReplacementFor_body.substr(offset, length);
          return true;
        }
        return false;
      });
}

size_t
ReplacementFor_get_multipart_ranges_data_length(const ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res,
                                 const std::string &ReplacementFor_boundary,
                                 const std::string &ReplacementFor_content_type) {
  size_t ReplacementFor_data_length = 0;

  ReplacementFor_process_multipart_ranges_data(
      ReplacementFor_req, ReplacementFor_res, ReplacementFor_boundary, ReplacementFor_content_type,
      [&](const std::string &ReplacementFor_token) { ReplacementFor_data_length += ReplacementFor_token.size(); },
      [&](const char *ReplacementFor_token) { ReplacementFor_data_length += strlen(ReplacementFor_token); },
      [&](size_t  , size_t length) {
        ReplacementFor_data_length += length;
        return true;
      });

  return ReplacementFor_data_length;
}

template <typename T>
bool ReplacementFor_write_multipart_ranges_data(ReplacementFor_Stream &ReplacementFor_strm, const ReplacementFor_Request &ReplacementFor_req,
                                        ReplacementFor_Response &ReplacementFor_res,
                                        const std::string &ReplacementFor_boundary,
                                        const std::string &ReplacementFor_content_type,
                                        const T &ReplacementFor_is_shutting_down) {
  return ReplacementFor_process_multipart_ranges_data(
      ReplacementFor_req, ReplacementFor_res, ReplacementFor_boundary, ReplacementFor_content_type,
      [&](const std::string &ReplacementFor_token) { ReplacementFor_strm.write(ReplacementFor_token); },
      [&](const char *ReplacementFor_token) { ReplacementFor_strm.write(ReplacementFor_token); },
      [&](size_t offset, size_t length) {
        return ReplacementFor_write_content(ReplacementFor_strm, ReplacementFor_res.ReplacementFor_content_provider_, offset, length,
                             ReplacementFor_is_shutting_down);
      });
}

std::pair<size_t, size_t>
ReplacementFor_get_range_offset_and_length(const ReplacementFor_Request &ReplacementFor_req, const ReplacementFor_Response &ReplacementFor_res,
                            size_t index) {
  auto ReplacementFor_r = ReplacementFor_req.ranges[index];

  if (ReplacementFor_r.second == -1) {
    ReplacementFor_r.second = static_cast<ssize_t>(ReplacementFor_res.ReplacementFor_content_length_) - 1;
  }

  return std::make_pair(ReplacementFor_r.first, ReplacementFor_r.second - ReplacementFor_r.first + 1);
}

bool ReplacementFor_expect_content(const ReplacementFor_Request &ReplacementFor_req) {
  if (ReplacementFor_req.ReplacementFor_method == "POST" || ReplacementFor_req.ReplacementFor_method == "PUT" || ReplacementFor_req.ReplacementFor_method == "PATCH" ||
      ReplacementFor_req.ReplacementFor_method == "PRI" || ReplacementFor_req.ReplacementFor_method == "DELETE") {
    return true;
  }
  
  return false;
}

bool ReplacementFor_has_crlf(const char *s) {
  auto p = s;
  while (*p) {
    if (*p == '\r' || *p == '\n') { return true; }
    p++;
  }
  return false;
}

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
template <typename CTX, typename Init, typename Update, typename Final>
std::string ReplacementFor_message_digest(const std::string &s, Init init,
                                  Update ReplacementFor_update, Final final,
                                  size_t ReplacementFor_digest_length) {
  using namespace std;

  std::vector<unsigned char> ReplacementFor_md(ReplacementFor_digest_length, 0);
  CTX ctx;
  init(&ctx);
  ReplacementFor_update(&ctx, s.data(), s.size());
  final(ReplacementFor_md.data(), &ctx);

  stringstream ReplacementFor_ss;
  for (auto c : ReplacementFor_md) {
    ReplacementFor_ss << setfill(((char)(0x598+4729-0x17e1))) << setw(2) << hex << (unsigned int)c;
  }
  return ReplacementFor_ss.str();
}

std::string ReplacementFor_MD5(const std::string &s) {
  return ReplacementFor_message_digest<ReplacementFor_MD5_CTX>(s, ReplacementFor_MD5_Init, ReplacementFor_MD5_Update, ReplacementFor_MD5_Final,
                                 ReplacementFor_MD5_DIGEST_LENGTH);
}

std::string ReplacementFor_SHA_256(const std::string &s) {
  return ReplacementFor_message_digest<ReplacementFor_SHA256_CTX>(s, ReplacementFor_SHA256_Init, ReplacementFor_SHA256_Update, ReplacementFor_SHA256_Final,
                                    ReplacementFor_SHA256_DIGEST_LENGTH);
}

std::string ReplacementFor_SHA_512(const std::string &s) {
  return ReplacementFor_message_digest<ReplacementFor_SHA512_CTX>(s, ReplacementFor_SHA512_Init, ReplacementFor_SHA512_Update, ReplacementFor_SHA512_Final,
                                    ReplacementFor_SHA512_DIGEST_LENGTH);
}
#endif

#ifdef _WIN32
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
bool ReplacementFor_load_system_certs_on_windows(ReplacementFor_X509_STORE *store) {
  auto ReplacementFor_hStore = CertOpenSystemStoreW((ReplacementFor_HCRYPTPROV_LEGACY)NULL, L"ROOT");

  if (!ReplacementFor_hStore) { return false; }

  PCCERT_CONTEXT pContext = NULL;
  while ((pContext = CertEnumCertificatesInStore(ReplacementFor_hStore, pContext)) !=
         nullptr) {
    auto ReplacementFor_encoded_cert =
        static_cast<const unsigned char *>(pContext->pbCertEncoded);

    auto ReplacementFor_x509 = ReplacementFor_d2i_X509(NULL, &ReplacementFor_encoded_cert, pContext->cbCertEncoded);
    if (ReplacementFor_x509) {
      ReplacementFor_X509_STORE_add_cert(store, ReplacementFor_x509);
      ReplacementFor_X509_free(ReplacementFor_x509);
    }
  }

  CertFreeCertificateContext(pContext);
  CertCloseStore(ReplacementFor_hStore, 0);

  return true;
}
#endif

class ReplacementFor_WSInit {
public:
  ReplacementFor_WSInit() {
    WSADATA ReplacementFor_wsaData;
    WSAStartup(0x0002, &ReplacementFor_wsaData);
  }

  ~ReplacementFor_WSInit() { WSACleanup(); }
};

static ReplacementFor_WSInit ReplacementFor_wsinit_;
#endif

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
std::pair<std::string, std::string> ReplacementFor_make_digest_authentication_header(
    const ReplacementFor_Request &ReplacementFor_req, const std::map<std::string, std::string> &ReplacementFor_auth,
    size_t ReplacementFor_cnonce_count, const std::string &ReplacementFor_cnonce, const std::string &ReplacementFor_username,
    const std::string &ReplacementFor_password, bool ReplacementFor_is_proxy = false) {
  using namespace std;

  string ReplacementFor_nc;
  {
    stringstream ReplacementFor_ss;
    ReplacementFor_ss << setfill(((char)(0x496+4245-0x14fb))) << setw(8) << hex << ReplacementFor_cnonce_count;
    ReplacementFor_nc = ReplacementFor_ss.str();
  }

  auto ReplacementFor_qop = ReplacementFor_auth.at("qop");
  if (ReplacementFor_qop.find("auth-int") != std::string::npos) {
    ReplacementFor_qop = "auth-int";
  } else {
    ReplacementFor_qop = "auth";
  }

  std::string ReplacementFor_algo = "MD5";
  if (ReplacementFor_auth.find("algorithm") != ReplacementFor_auth.end()) { ReplacementFor_algo = ReplacementFor_auth.at("algorithm"); }

  string ReplacementFor_response;
  {
    auto ReplacementFor_H = ReplacementFor_algo == "SHA-256"
                 ? ReplacementFor_detail::ReplacementFor_SHA_256
                 : ReplacementFor_algo == "SHA-512" ? ReplacementFor_detail::ReplacementFor_SHA_512 : ReplacementFor_detail::ReplacementFor_MD5;

    auto ReplacementFor_A1 = ReplacementFor_username + ":" + ReplacementFor_auth.at("realm") + ":" + ReplacementFor_password;

    auto ReplacementFor_A2 = ReplacementFor_req.ReplacementFor_method + ":" + ReplacementFor_req.ReplacementFor_path;
    if (ReplacementFor_qop == "auth-int") { ReplacementFor_A2 += ":" + ReplacementFor_H(ReplacementFor_req.ReplacementFor_body); }

    ReplacementFor_response = ReplacementFor_H(ReplacementFor_H(ReplacementFor_A1) + ":" + ReplacementFor_auth.at("nonce") + ":" + ReplacementFor_nc + ":" + ReplacementFor_cnonce +
                 ":" + ReplacementFor_qop + ":" + ReplacementFor_H(ReplacementFor_A2));
  }

  auto field = "Digest username=\"" + ReplacementFor_username + "\", realm=\"" +
               ReplacementFor_auth.at("realm") + "\", nonce=\"" + ReplacementFor_auth.at("nonce") +
               "\", uri=\"" + ReplacementFor_req.ReplacementFor_path + "\", algorithm=" + ReplacementFor_algo +
               ", qop=" + ReplacementFor_qop + ", nc=\"" + ReplacementFor_nc + "\", cnonce=\"" + ReplacementFor_cnonce +
               "\", response=\"" + ReplacementFor_response + "\"";

  auto key = ReplacementFor_is_proxy ? "Proxy-Authorization" : "Authorization";
  return std::make_pair(key, field);
}
#endif

bool ReplacementFor_parse_www_authenticate(const ReplacementFor_Response &ReplacementFor_res,
                                   std::map<std::string, std::string> &ReplacementFor_auth,
                                   bool ReplacementFor_is_proxy) {
  auto ReplacementFor_auth_key = ReplacementFor_is_proxy ? "Proxy-Authenticate" : "WWW-Authenticate";
  if (ReplacementFor_res.ReplacementFor_has_header(ReplacementFor_auth_key)) {
    static auto ReplacementFor_re = std::regex(ReplacementFor_R"~((?:(?:,\s*)?(.+?)=(?:"(.*?)"|([^,]*))))~");
    auto s = ReplacementFor_res.ReplacementFor_get_header_value(ReplacementFor_auth_key);
    auto pos = s.find(((char)(0x461+5735-0x1aa8)));
    if (pos != std::string::npos) {
      auto type = s.substr(0, pos);
      if (type == "Basic") {
        return false;
      } else if (type == "Digest") {
        s = s.substr(pos + 1);
        auto beg = std::sregex_iterator(s.begin(), s.end(), ReplacementFor_re);
        for (auto i = beg; i != std::sregex_iterator(); ++i) {
          auto m = *i;
          auto key = s.substr(static_cast<size_t>(m.position(1)),
                              static_cast<size_t>(m.length(1)));
          auto val = m.length(2) > 0
                         ? s.substr(static_cast<size_t>(m.position(2)),
                                    static_cast<size_t>(m.length(2)))
                         : s.substr(static_cast<size_t>(m.position(3)),
                                    static_cast<size_t>(m.length(3)));
          ReplacementFor_auth[key] = val;
        }
        return true;
      }
    }
  }
  return false;
}

std::string ReplacementFor_random_string(size_t length) {
  auto ReplacementFor_randchar = []() -> char {
    const char ReplacementFor_charset[] = "0123456789"
                           "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                           "abcdefghijklmnopqrstuvwxyz";
    const size_t ReplacementFor_max_index = (sizeof(ReplacementFor_charset) - 1);
    return ReplacementFor_charset[static_cast<size_t>(rand()) % ReplacementFor_max_index];
  };
  std::string str(length, 0);
  std::generate_n(str.begin(), length, ReplacementFor_randchar);
  return str;
}

class ReplacementFor_ContentProviderAdapter {
public:
  explicit ReplacementFor_ContentProviderAdapter(
      ReplacementFor_ContentProviderWithoutLength &&ReplacementFor_content_provider)
      : ReplacementFor_content_provider_(ReplacementFor_content_provider) {}

  bool operator()(size_t offset, size_t, ReplacementFor_DataSink &ReplacementFor_sink) {
    return ReplacementFor_content_provider_(offset, ReplacementFor_sink);
  }

private:
  ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider_;
};

} 

std::pair<std::string, std::string> ReplacementFor_make_range_header(Ranges ranges) {
  std::string field = "bytes=";
  auto i = 0;
  for (auto ReplacementFor_r : ranges) {
    if (i != 0) { field += ", "; }
    if (ReplacementFor_r.first != -1) { field += std::to_string(ReplacementFor_r.first); }
    field += ((char)(0xf45+5643-0x2523));
    if (ReplacementFor_r.second != -1) { field += std::to_string(ReplacementFor_r.second); }
    i++;
  }
  return std::make_pair("Range", std::move(field));
}

std::pair<std::string, std::string>
ReplacementFor_make_basic_authentication_header(const std::string &ReplacementFor_username,
                                 const std::string &ReplacementFor_password,
                                 bool ReplacementFor_is_proxy = false) {
  auto field = "Basic " + ReplacementFor_detail::ReplacementFor_base64_encode(ReplacementFor_username + ":" + ReplacementFor_password);
  auto key = ReplacementFor_is_proxy ? "Proxy-Authorization" : "Authorization";
  return std::make_pair(key, std::move(field));
}

std::pair<std::string, std::string>
ReplacementFor_make_bearer_token_authentication_header(const std::string &ReplacementFor_token,
                                        bool ReplacementFor_is_proxy = false) {
  auto field = "Bearer " + ReplacementFor_token;
  auto key = ReplacementFor_is_proxy ? "Proxy-Authorization" : "Authorization";
  return std::make_pair(key, std::move(field));
}


bool ReplacementFor_Request::ReplacementFor_has_header(const char *key) const {
  return ReplacementFor_detail::ReplacementFor_has_header(ReplacementFor_headers, key);
}

std::string ReplacementFor_Request::ReplacementFor_get_header_value(const char *key, size_t id) const {
  return ReplacementFor_detail::ReplacementFor_get_header_value(ReplacementFor_headers, key, id, "");
}

template <typename T>
T ReplacementFor_Request::ReplacementFor_get_header_value(const char *key, size_t id) const {
  return ReplacementFor_detail::ReplacementFor_get_header_value<T>(ReplacementFor_headers, key, id, 0);
}

size_t ReplacementFor_Request::ReplacementFor_get_header_value_count(const char *key) const {
  auto ReplacementFor_r = ReplacementFor_headers.equal_range(key);
  return static_cast<size_t>(std::distance(ReplacementFor_r.first, ReplacementFor_r.second));
}

void ReplacementFor_Request::ReplacementFor_set_header(const char *key, const char *val) {
  if (!ReplacementFor_detail::ReplacementFor_has_crlf(key) && !ReplacementFor_detail::ReplacementFor_has_crlf(val)) {
    ReplacementFor_headers.emplace(key, val);
  }
}

void ReplacementFor_Request::ReplacementFor_set_header(const char *key, const std::string &val) {
  if (!ReplacementFor_detail::ReplacementFor_has_crlf(key) && !ReplacementFor_detail::ReplacementFor_has_crlf(val.c_str())) {
    ReplacementFor_headers.emplace(key, val);
  }
}

bool ReplacementFor_Request::ReplacementFor_has_param(const char *key) const {
  return ReplacementFor_params.find(key) != ReplacementFor_params.end();
}

std::string ReplacementFor_Request::ReplacementFor_get_param_value(const char *key, size_t id) const {
  auto ReplacementFor_rng = ReplacementFor_params.equal_range(key);
  auto ReplacementFor_it = ReplacementFor_rng.first;
  std::advance(ReplacementFor_it, static_cast<ssize_t>(id));
  if (ReplacementFor_it != ReplacementFor_rng.second) { return ReplacementFor_it->second; }
  return std::string();
}

size_t ReplacementFor_Request::ReplacementFor_get_param_value_count(const char *key) const {
  auto ReplacementFor_r = ReplacementFor_params.equal_range(key);
  return static_cast<size_t>(std::distance(ReplacementFor_r.first, ReplacementFor_r.second));
}

bool ReplacementFor_Request::ReplacementFor_is_multipart_form_data() const {
  const auto &ReplacementFor_content_type = ReplacementFor_get_header_value("Content-Type");
  return !ReplacementFor_content_type.find("multipart/form-data");
}

bool ReplacementFor_Request::ReplacementFor_has_file(const char *key) const {
  return ReplacementFor_files.find(key) != ReplacementFor_files.end();
}

ReplacementFor_MultipartFormData ReplacementFor_Request::ReplacementFor_get_file_value(const char *key) const {
  auto ReplacementFor_it = ReplacementFor_files.find(key);
  if (ReplacementFor_it != ReplacementFor_files.end()) { return ReplacementFor_it->second; }
  return ReplacementFor_MultipartFormData();
}

bool ReplacementFor_Response::ReplacementFor_has_header(const char *key) const {
  return ReplacementFor_headers.find(key) != ReplacementFor_headers.end();
}

std::string ReplacementFor_Response::ReplacementFor_get_header_value(const char *key,
                                              size_t id) const {
  return ReplacementFor_detail::ReplacementFor_get_header_value(ReplacementFor_headers, key, id, "");
}

template <typename T>
T ReplacementFor_Response::ReplacementFor_get_header_value(const char *key, size_t id) const {
  return ReplacementFor_detail::ReplacementFor_get_header_value<T>(ReplacementFor_headers, key, id, 0);
}

size_t ReplacementFor_Response::ReplacementFor_get_header_value_count(const char *key) const {
  auto ReplacementFor_r = ReplacementFor_headers.equal_range(key);
  return static_cast<size_t>(std::distance(ReplacementFor_r.first, ReplacementFor_r.second));
}

void ReplacementFor_Response::ReplacementFor_set_header(const char *key, const char *val) {
  if (!ReplacementFor_detail::ReplacementFor_has_crlf(key) && !ReplacementFor_detail::ReplacementFor_has_crlf(val)) {
    ReplacementFor_headers.emplace(key, val);
  }
}

void ReplacementFor_Response::ReplacementFor_set_header(const char *key, const std::string &val) {
  if (!ReplacementFor_detail::ReplacementFor_has_crlf(key) && !ReplacementFor_detail::ReplacementFor_has_crlf(val.c_str())) {
    ReplacementFor_headers.emplace(key, val);
  }
}

void ReplacementFor_Response::ReplacementFor_set_redirect(const char *ReplacementFor_url, int stat) {
  if (!ReplacementFor_detail::ReplacementFor_has_crlf(ReplacementFor_url)) {
    ReplacementFor_set_header("Location", ReplacementFor_url);
    if (300 <= stat && stat < 400) {
      this->status = stat;
    } else {
      this->status = 302;
    }
  }
}

void ReplacementFor_Response::ReplacementFor_set_redirect(const std::string &ReplacementFor_url, int stat) {
  ReplacementFor_set_redirect(ReplacementFor_url.c_str(), stat);
}

void ReplacementFor_Response::ReplacementFor_set_content(const char *s, size_t n,
                                  const char *ReplacementFor_content_type) {
  ReplacementFor_body.assign(s, n);

  auto ReplacementFor_rng = ReplacementFor_headers.equal_range("Content-Type");
  ReplacementFor_headers.erase(ReplacementFor_rng.first, ReplacementFor_rng.second);
  ReplacementFor_set_header("Content-Type", ReplacementFor_content_type);
}

void ReplacementFor_Response::ReplacementFor_set_content(const std::string &s,
                                  const char *ReplacementFor_content_type) {
  ReplacementFor_set_content(s.data(), s.size(), ReplacementFor_content_type);
}

void
ReplacementFor_Response::ReplacementFor_set_content_provider(size_t ReplacementFor_in_length, const char *ReplacementFor_content_type,
                               ReplacementFor_ContentProvider ReplacementFor_provider,
                               const std::function<void()> &ReplacementFor_resource_releaser) {
  assert(ReplacementFor_in_length > 0);
  ReplacementFor_set_header("Content-Type", ReplacementFor_content_type);
  ReplacementFor_content_length_ = ReplacementFor_in_length;
  ReplacementFor_content_provider_ = std::move(ReplacementFor_provider);
  ReplacementFor_content_provider_resource_releaser_ = ReplacementFor_resource_releaser;
  ReplacementFor_is_chunked_content_provider_ = false;
}

void
ReplacementFor_Response::ReplacementFor_set_content_provider(const char *ReplacementFor_content_type,
                               ReplacementFor_ContentProviderWithoutLength ReplacementFor_provider,
                               const std::function<void()> &ReplacementFor_resource_releaser) {
  ReplacementFor_set_header("Content-Type", ReplacementFor_content_type);
  ReplacementFor_content_length_ = 0;
  ReplacementFor_content_provider_ = ReplacementFor_detail::ReplacementFor_ContentProviderAdapter(std::move(ReplacementFor_provider));
  ReplacementFor_content_provider_resource_releaser_ = ReplacementFor_resource_releaser;
  ReplacementFor_is_chunked_content_provider_ = false;
}

void ReplacementFor_Response::ReplacementFor_set_chunked_content_provider(
    const char *ReplacementFor_content_type, ReplacementFor_ContentProviderWithoutLength ReplacementFor_provider,
    const std::function<void()> &ReplacementFor_resource_releaser) {
  ReplacementFor_set_header("Content-Type", ReplacementFor_content_type);
  ReplacementFor_content_length_ = 0;
  ReplacementFor_content_provider_ = ReplacementFor_detail::ReplacementFor_ContentProviderAdapter(std::move(ReplacementFor_provider));
  ReplacementFor_content_provider_resource_releaser_ = ReplacementFor_resource_releaser;
  ReplacementFor_is_chunked_content_provider_ = true;
}


bool Result::ReplacementFor_has_request_header(const char *key) const {
  return ReplacementFor_request_headers_.find(key) != ReplacementFor_request_headers_.end();
}

std::string Result::ReplacementFor_get_request_header_value(const char *key,
                                                    size_t id) const {
  return ReplacementFor_detail::ReplacementFor_get_header_value(ReplacementFor_request_headers_, key, id, "");
}

template <typename T>
T Result::ReplacementFor_get_request_header_value(const char *key, size_t id) const {
  return ReplacementFor_detail::ReplacementFor_get_header_value<T>(ReplacementFor_request_headers_, key, id, 0);
}

size_t Result::ReplacementFor_get_request_header_value_count(const char *key) const {
  auto ReplacementFor_r = ReplacementFor_request_headers_.equal_range(key);
  return static_cast<size_t>(std::distance(ReplacementFor_r.first, ReplacementFor_r.second));
}

ssize_t ReplacementFor_Stream::write(const char *ReplacementFor_ptr) {
  return write(ReplacementFor_ptr, strlen(ReplacementFor_ptr));
}

ssize_t ReplacementFor_Stream::write(const std::string &s) {
  return write(s.data(), s.size());
}

template <typename... ReplacementFor_Args>
ssize_t ReplacementFor_Stream::ReplacementFor_write_format(const char *ReplacementFor_fmt, const ReplacementFor_Args &... ReplacementFor_args) {
  const auto ReplacementFor_bufsiz = 2048;
  std::array<char, ReplacementFor_bufsiz> buf;

#if defined(_MSC_VER) && _MSC_VER < 1900
  auto ReplacementFor_sn = ReplacementFor__snprintf_s(buf.data(), ReplacementFor_bufsiz - 1, buf.size() - 1, ReplacementFor_fmt, ReplacementFor_args...);
#else
  auto ReplacementFor_sn = snprintf(buf.data(), buf.size() - 1, ReplacementFor_fmt, ReplacementFor_args...);
#endif
  if (ReplacementFor_sn <= 0) { return ReplacementFor_sn; }

  auto n = static_cast<size_t>(ReplacementFor_sn);

  if (n >= buf.size() - 1) {
    std::vector<char> ReplacementFor_glowable_buf(buf.size());

    while (n >= ReplacementFor_glowable_buf.size() - 1) {
      ReplacementFor_glowable_buf.resize(ReplacementFor_glowable_buf.size() * 2);
#if defined(_MSC_VER) && _MSC_VER < 1900
      n = static_cast<size_t>(ReplacementFor__snprintf_s(&ReplacementFor_glowable_buf[0], ReplacementFor_glowable_buf.size(),
                                          ReplacementFor_glowable_buf.size() - 1, ReplacementFor_fmt,
                                          ReplacementFor_args...));
#else
      n = static_cast<size_t>(
          snprintf(&ReplacementFor_glowable_buf[0], ReplacementFor_glowable_buf.size() - 1, ReplacementFor_fmt, ReplacementFor_args...));
#endif
    }
    return write(&ReplacementFor_glowable_buf[0], n);
  } else {
    return write(buf.data(), n);
  }
}

namespace ReplacementFor_detail {


ReplacementFor_SocketStream::ReplacementFor_SocketStream(ReplacementFor_socket_t ReplacementFor_sock, time_t ReplacementFor_read_timeout_sec,
                                  time_t ReplacementFor_read_timeout_usec,
                                  time_t ReplacementFor_write_timeout_sec,
                                  time_t ReplacementFor_write_timeout_usec)
    : ReplacementFor_sock_(ReplacementFor_sock), ReplacementFor_read_timeout_sec_(ReplacementFor_read_timeout_sec),
      ReplacementFor_read_timeout_usec_(ReplacementFor_read_timeout_usec),
      ReplacementFor_write_timeout_sec_(ReplacementFor_write_timeout_sec),
      ReplacementFor_write_timeout_usec_(ReplacementFor_write_timeout_usec) {}

ReplacementFor_SocketStream::~ReplacementFor_SocketStream() {}

bool ReplacementFor_SocketStream::ReplacementFor_is_readable() const {
  return ReplacementFor_select_read(ReplacementFor_sock_, ReplacementFor_read_timeout_sec_, ReplacementFor_read_timeout_usec_) > 0;
}

bool ReplacementFor_SocketStream::ReplacementFor_is_writable() const {
  return ReplacementFor_select_write(ReplacementFor_sock_, ReplacementFor_write_timeout_sec_, ReplacementFor_write_timeout_usec_) > 0;
}

ssize_t ReplacementFor_SocketStream::read(char *ReplacementFor_ptr, size_t size) {
  if (!ReplacementFor_is_readable()) { return -1; }

#ifdef _WIN32
  if (size > static_cast<size_t>((std::numeric_limits<int>::max)())) {
    return -1;
  }
  return recv(ReplacementFor_sock_, ReplacementFor_ptr, static_cast<int>(size), ReplacementFor_CPPHTTPLIB_RECV_FLAGS);
#else
  return ReplacementFor_handle_EINTR(
      [&]() { return recv(ReplacementFor_sock_, ReplacementFor_ptr, size, ReplacementFor_CPPHTTPLIB_RECV_FLAGS); });
#endif
}

ssize_t ReplacementFor_SocketStream::write(const char *ReplacementFor_ptr, size_t size) {
  if (!ReplacementFor_is_writable()) { return -1; }

#ifdef _WIN32
  if (size > static_cast<size_t>((std::numeric_limits<int>::max)())) {
    return -1;
  }
  return send(ReplacementFor_sock_, ReplacementFor_ptr, static_cast<int>(size), ReplacementFor_CPPHTTPLIB_SEND_FLAGS);
#else
  return ReplacementFor_handle_EINTR(
      [&]() { return send(ReplacementFor_sock_, ReplacementFor_ptr, size, ReplacementFor_CPPHTTPLIB_SEND_FLAGS); });
#endif
}

void ReplacementFor_SocketStream::ReplacementFor_get_remote_ip_and_port(std::string &ReplacementFor_ip,
                                                 int &ReplacementFor_port) const {
  return ReplacementFor_detail::ReplacementFor_get_remote_ip_and_port(ReplacementFor_sock_, ReplacementFor_ip, ReplacementFor_port);
}

ReplacementFor_socket_t ReplacementFor_SocketStream::socket() const { return ReplacementFor_sock_; }

bool ReplacementFor_BufferStream::ReplacementFor_is_readable() const { return true; }

bool ReplacementFor_BufferStream::ReplacementFor_is_writable() const { return true; }

ssize_t ReplacementFor_BufferStream::read(char *ReplacementFor_ptr, size_t size) {
#if defined(_MSC_VER) && _MSC_VER <= 1900
  auto ReplacementFor_len_read = ReplacementFor_buffer._Copy_s(ReplacementFor_ptr, size, size, position);
#else
  auto ReplacementFor_len_read = ReplacementFor_buffer.copy(ReplacementFor_ptr, size, position);
#endif
  position += static_cast<size_t>(ReplacementFor_len_read);
  return static_cast<ssize_t>(ReplacementFor_len_read);
}

ssize_t ReplacementFor_BufferStream::write(const char *ReplacementFor_ptr, size_t size) {
  ReplacementFor_buffer.append(ReplacementFor_ptr, size);
  return static_cast<ssize_t>(size);
}

void ReplacementFor_BufferStream::ReplacementFor_get_remote_ip_and_port(std::string &  ,
                                                 int &  ) const {}

ReplacementFor_socket_t ReplacementFor_BufferStream::socket() const { return 0; }

const std::string &ReplacementFor_BufferStream::ReplacementFor_get_buffer() const { return ReplacementFor_buffer; }

} 

ReplacementFor_Server::ReplacementFor_Server()
    : ReplacementFor_new_task_queue(
          [] { return new ReplacementFor_ThreadPool(ReplacementFor_CPPHTTPLIB_THREAD_POOL_COUNT); }),
      ReplacementFor_svr_sock_(INVALID_SOCKET), ReplacementFor_is_running_(false) {
#ifndef _WIN32
  signal(SIGPIPE, SIG_IGN);
#endif
}

ReplacementFor_Server::~ReplacementFor_Server() {}

ReplacementFor_Server &ReplacementFor_Server::Get(const char *pattern, ReplacementFor_Handler ReplacementFor_handler) {
  return Get(pattern, strlen(pattern), ReplacementFor_handler);
}

ReplacementFor_Server &ReplacementFor_Server::Get(const char *pattern, size_t ReplacementFor_pattern_len,
                           ReplacementFor_Handler ReplacementFor_handler) {
  ReplacementFor_get_handlers_.push_back(
      std::make_pair(std::regex(pattern, ReplacementFor_pattern_len), std::move(ReplacementFor_handler)));
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_Post(const char *pattern, ReplacementFor_Handler ReplacementFor_handler) {
  return ReplacementFor_Post(pattern, strlen(pattern), ReplacementFor_handler);
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_Post(const char *pattern, size_t ReplacementFor_pattern_len,
                            ReplacementFor_Handler ReplacementFor_handler) {
  ReplacementFor_post_handlers_.push_back(
      std::make_pair(std::regex(pattern, ReplacementFor_pattern_len), std::move(ReplacementFor_handler)));
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_Post(const char *pattern,
                            ReplacementFor_HandlerWithContentReader ReplacementFor_handler) {
  return ReplacementFor_Post(pattern, strlen(pattern), ReplacementFor_handler);
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_Post(const char *pattern, size_t ReplacementFor_pattern_len,
                            ReplacementFor_HandlerWithContentReader ReplacementFor_handler) {
  ReplacementFor_post_handlers_for_content_reader_.push_back(
      std::make_pair(std::regex(pattern, ReplacementFor_pattern_len), std::move(ReplacementFor_handler)));
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::Put(const char *pattern, ReplacementFor_Handler ReplacementFor_handler) {
  return Put(pattern, strlen(pattern), ReplacementFor_handler);
}

ReplacementFor_Server &ReplacementFor_Server::Put(const char *pattern, size_t ReplacementFor_pattern_len,
                           ReplacementFor_Handler ReplacementFor_handler) {
  ReplacementFor_put_handlers_.push_back(
      std::make_pair(std::regex(pattern, ReplacementFor_pattern_len), std::move(ReplacementFor_handler)));
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::Put(const char *pattern,
                           ReplacementFor_HandlerWithContentReader ReplacementFor_handler) {
  return Put(pattern, strlen(pattern), ReplacementFor_handler);
}

ReplacementFor_Server &ReplacementFor_Server::Put(const char *pattern, size_t ReplacementFor_pattern_len,
                           ReplacementFor_HandlerWithContentReader ReplacementFor_handler) {
  ReplacementFor_put_handlers_for_content_reader_.push_back(
      std::make_pair(std::regex(pattern, ReplacementFor_pattern_len), std::move(ReplacementFor_handler)));
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_Patch(const char *pattern, ReplacementFor_Handler ReplacementFor_handler) {
  return ReplacementFor_Patch(pattern, strlen(pattern), ReplacementFor_handler);
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_Patch(const char *pattern, size_t ReplacementFor_pattern_len,
                             ReplacementFor_Handler ReplacementFor_handler) {
  ReplacementFor_patch_handlers_.push_back(
      std::make_pair(std::regex(pattern, ReplacementFor_pattern_len), std::move(ReplacementFor_handler)));
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_Patch(const char *pattern,
                             ReplacementFor_HandlerWithContentReader ReplacementFor_handler) {
  return ReplacementFor_Patch(pattern, strlen(pattern), ReplacementFor_handler);
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_Patch(const char *pattern, size_t ReplacementFor_pattern_len,
                             ReplacementFor_HandlerWithContentReader ReplacementFor_handler) {
  ReplacementFor_patch_handlers_for_content_reader_.push_back(
      std::make_pair(std::regex(pattern, ReplacementFor_pattern_len), std::move(ReplacementFor_handler)));
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::Delete(const char *pattern, ReplacementFor_Handler ReplacementFor_handler) {
  return Delete(pattern, strlen(pattern), ReplacementFor_handler);
}

ReplacementFor_Server &ReplacementFor_Server::Delete(const char *pattern, size_t ReplacementFor_pattern_len,
                              ReplacementFor_Handler ReplacementFor_handler) {
  ReplacementFor_delete_handlers_.push_back(
      std::make_pair(std::regex(pattern, ReplacementFor_pattern_len), std::move(ReplacementFor_handler)));
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::Delete(const char *pattern,
                              ReplacementFor_HandlerWithContentReader ReplacementFor_handler) {
  return Delete(pattern, strlen(pattern), ReplacementFor_handler);
}

ReplacementFor_Server &ReplacementFor_Server::Delete(const char *pattern, size_t ReplacementFor_pattern_len,
                              ReplacementFor_HandlerWithContentReader ReplacementFor_handler) {
  ReplacementFor_delete_handlers_for_content_reader_.push_back(
      std::make_pair(std::regex(pattern, ReplacementFor_pattern_len), std::move(ReplacementFor_handler)));
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::Options(const char *pattern, ReplacementFor_Handler ReplacementFor_handler) {
  return Options(pattern, strlen(pattern), ReplacementFor_handler);
}

ReplacementFor_Server &ReplacementFor_Server::Options(const char *pattern, size_t ReplacementFor_pattern_len,
                               ReplacementFor_Handler ReplacementFor_handler) {
  ReplacementFor_options_handlers_.push_back(
      std::make_pair(std::regex(pattern, ReplacementFor_pattern_len), std::move(ReplacementFor_handler)));
  return *this;
}

bool ReplacementFor_Server::ReplacementFor_set_base_dir(const char *ReplacementFor_dir, const char *ReplacementFor_mount_point) {
  return ReplacementFor_set_mount_point(ReplacementFor_mount_point, ReplacementFor_dir);
}

bool ReplacementFor_Server::ReplacementFor_set_mount_point(const char *ReplacementFor_mount_point, const char *ReplacementFor_dir,
                                    ReplacementFor_Headers ReplacementFor_headers) {
  if (ReplacementFor_detail::ReplacementFor_is_dir(ReplacementFor_dir)) {
    std::string ReplacementFor_mnt = ReplacementFor_mount_point ? ReplacementFor_mount_point : "/";
    if (!ReplacementFor_mnt.empty() && ReplacementFor_mnt[0] == ((char)(0x16a+3147-0xd86))) {
      ReplacementFor_base_dirs_.push_back({ReplacementFor_mnt, ReplacementFor_dir, std::move(ReplacementFor_headers)});
      return true;
    }
  }
  return false;
}

bool ReplacementFor_Server::ReplacementFor_remove_mount_point(const char *ReplacementFor_mount_point) {
  for (auto ReplacementFor_it = ReplacementFor_base_dirs_.begin(); ReplacementFor_it != ReplacementFor_base_dirs_.end(); ++ReplacementFor_it) {
    if (ReplacementFor_it->ReplacementFor_mount_point == ReplacementFor_mount_point) {
      ReplacementFor_base_dirs_.erase(ReplacementFor_it);
      return true;
    }
  }
  return false;
}

ReplacementFor_Server &
ReplacementFor_Server::ReplacementFor_set_file_extension_and_mimetype_mapping(const char *ReplacementFor_ext,
                                                const char *ReplacementFor_mime) {
  ReplacementFor_file_extension_and_mimetype_map_[ReplacementFor_ext] = ReplacementFor_mime;

  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_file_request_handler(ReplacementFor_Handler ReplacementFor_handler) {
  ReplacementFor_file_request_handler_ = std::move(ReplacementFor_handler);

  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_error_handler(ReplacementFor_HandlerWithResponse ReplacementFor_handler) {
  ReplacementFor_error_handler_ = std::move(ReplacementFor_handler);
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_error_handler(ReplacementFor_Handler ReplacementFor_handler) {
  ReplacementFor_error_handler_ = [ReplacementFor_handler](const ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res) {
    ReplacementFor_handler(ReplacementFor_req, ReplacementFor_res);
    return ReplacementFor_HandlerResponse::ReplacementFor_Handled;
  };
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_exception_handler(ExceptionHandler ReplacementFor_handler) {
  ReplacementFor_exception_handler_ = std::move(ReplacementFor_handler);
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_pre_routing_handler(ReplacementFor_HandlerWithResponse ReplacementFor_handler) {
  ReplacementFor_pre_routing_handler_ = std::move(ReplacementFor_handler);
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_post_routing_handler(ReplacementFor_Handler ReplacementFor_handler) {
  ReplacementFor_post_routing_handler_ = std::move(ReplacementFor_handler);
  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_logger(ReplacementFor_Logger ReplacementFor_logger) {
  ReplacementFor_logger_ = std::move(ReplacementFor_logger);

  return *this;
}

ReplacementFor_Server &
ReplacementFor_Server::ReplacementFor_set_expect_100_continue_handler(ReplacementFor_Expect100ContinueHandler ReplacementFor_handler) {
  ReplacementFor_expect_100_continue_handler_ = std::move(ReplacementFor_handler);

  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_tcp_nodelay(bool ReplacementFor_on) {
  ReplacementFor_tcp_nodelay_ = ReplacementFor_on;

  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_socket_options(ReplacementFor_SocketOptions ReplacementFor_socket_options) {
  ReplacementFor_socket_options_ = std::move(ReplacementFor_socket_options);

  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_keep_alive_max_count(size_t count) {
  ReplacementFor_keep_alive_max_count_ = count;

  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_keep_alive_timeout(time_t sec) {
  ReplacementFor_keep_alive_timeout_sec_ = sec;

  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_read_timeout(time_t sec, time_t ReplacementFor_usec) {
  ReplacementFor_read_timeout_sec_ = sec;
  ReplacementFor_read_timeout_usec_ = ReplacementFor_usec;

  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_write_timeout(time_t sec, time_t ReplacementFor_usec) {
  ReplacementFor_write_timeout_sec_ = sec;
  ReplacementFor_write_timeout_usec_ = ReplacementFor_usec;

  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_idle_interval(time_t sec, time_t ReplacementFor_usec) {
  ReplacementFor_idle_interval_sec_ = sec;
  ReplacementFor_idle_interval_usec_ = ReplacementFor_usec;

  return *this;
}

ReplacementFor_Server &ReplacementFor_Server::ReplacementFor_set_payload_max_length(size_t length) {
  ReplacementFor_payload_max_length_ = length;

  return *this;
}

bool ReplacementFor_Server::ReplacementFor_bind_to_port(const char *ReplacementFor_host, int ReplacementFor_port, int ReplacementFor_socket_flags) {
  if (ReplacementFor_bind_internal(ReplacementFor_host, ReplacementFor_port, ReplacementFor_socket_flags) < 0) return false;
  return true;
}
int ReplacementFor_Server::ReplacementFor_bind_to_any_port(const char *ReplacementFor_host, int ReplacementFor_socket_flags) {
  return ReplacementFor_bind_internal(ReplacementFor_host, 0, ReplacementFor_socket_flags);
}

bool ReplacementFor_Server::ReplacementFor_listen_after_bind() { return ReplacementFor_listen_internal(); }

bool ReplacementFor_Server::listen(const char *ReplacementFor_host, int ReplacementFor_port, int ReplacementFor_socket_flags) {
  return ReplacementFor_bind_to_port(ReplacementFor_host, ReplacementFor_port, ReplacementFor_socket_flags) && ReplacementFor_listen_internal();
}

bool ReplacementFor_Server::ReplacementFor_is_running() const { return ReplacementFor_is_running_; }

void ReplacementFor_Server::ReplacementFor_stop() {
  if (ReplacementFor_is_running_) {
    assert(ReplacementFor_svr_sock_ != INVALID_SOCKET);
    std::atomic<ReplacementFor_socket_t> ReplacementFor_sock(ReplacementFor_svr_sock_.exchange(INVALID_SOCKET));
    ReplacementFor_detail::ReplacementFor_shutdown_socket(ReplacementFor_sock);
    ReplacementFor_detail::ReplacementFor_close_socket(ReplacementFor_sock);
  }
}

bool ReplacementFor_Server::ReplacementFor_parse_request_line(const char *s, ReplacementFor_Request &ReplacementFor_req) {
  const static std::regex ReplacementFor_re(
      "(GET|HEAD|POST|PUT|DELETE|CONNECT|OPTIONS|TRACE|PATCH|PRI) "
      "(([^? ]+)(?:\\?([^ ]*?))?) (HTTP/1\\.[01])\r\n");

  std::cmatch m;
  if (std::regex_match(s, m, ReplacementFor_re)) {
    ReplacementFor_req.ReplacementFor_version = std::string(m[5]);
    ReplacementFor_req.ReplacementFor_method = std::string(m[1]);
    ReplacementFor_req.target = std::string(m[2]);
    ReplacementFor_req.ReplacementFor_path = ReplacementFor_detail::ReplacementFor_decode_url(m[3], false);

    auto len = std::distance(m[4].first, m[4].second);
    if (len > 0) { ReplacementFor_detail::ReplacementFor_parse_query_text(m[4], ReplacementFor_req.ReplacementFor_params); }

    return true;
  }

  return false;
}

bool ReplacementFor_Server::ReplacementFor_write_response(ReplacementFor_Stream &ReplacementFor_strm, bool ReplacementFor_close_connection,
                                   const ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res) {
  return ReplacementFor_write_response_core(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_req, ReplacementFor_res, false);
}

bool ReplacementFor_Server::ReplacementFor_write_response_with_content(ReplacementFor_Stream &ReplacementFor_strm,
                                                bool ReplacementFor_close_connection,
                                                const ReplacementFor_Request &ReplacementFor_req,
                                                ReplacementFor_Response &ReplacementFor_res) {
  return ReplacementFor_write_response_core(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_req, ReplacementFor_res, true);
}

bool ReplacementFor_Server::ReplacementFor_write_response_core(ReplacementFor_Stream &ReplacementFor_strm, bool ReplacementFor_close_connection,
                                        const ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res,
                                        bool ReplacementFor_need_apply_ranges) {
  assert(ReplacementFor_res.status != -1);

  if (400 <= ReplacementFor_res.status && ReplacementFor_error_handler_ &&
      ReplacementFor_error_handler_(ReplacementFor_req, ReplacementFor_res) == ReplacementFor_HandlerResponse::ReplacementFor_Handled) {
    ReplacementFor_need_apply_ranges = true;
  }

  std::string ReplacementFor_content_type;
  std::string ReplacementFor_boundary;
  if (ReplacementFor_need_apply_ranges) { ReplacementFor_apply_ranges(ReplacementFor_req, ReplacementFor_res, ReplacementFor_content_type, ReplacementFor_boundary); }

  
  if (ReplacementFor_close_connection || ReplacementFor_req.ReplacementFor_get_header_value("Connection") == "close") {
    ReplacementFor_res.ReplacementFor_set_header("Connection", "close");
  } else {
    std::stringstream ReplacementFor_ss;
    ReplacementFor_ss << "timeout=" << ReplacementFor_keep_alive_timeout_sec_
       << ", max=" << ReplacementFor_keep_alive_max_count_;
    ReplacementFor_res.ReplacementFor_set_header("Keep-Alive", ReplacementFor_ss.str());
  }

  if (!ReplacementFor_res.ReplacementFor_has_header("Content-Type") &&
      (!ReplacementFor_res.ReplacementFor_body.empty() || ReplacementFor_res.ReplacementFor_content_length_ > 0 || ReplacementFor_res.ReplacementFor_content_provider_)) {
    ReplacementFor_res.ReplacementFor_set_header("Content-Type", "text/plain");
  }

  if (!ReplacementFor_res.ReplacementFor_has_header("Content-Length") && ReplacementFor_res.ReplacementFor_body.empty() &&
      !ReplacementFor_res.ReplacementFor_content_length_ && !ReplacementFor_res.ReplacementFor_content_provider_) {
    ReplacementFor_res.ReplacementFor_set_header("Content-Length", "0");
  }

  if (!ReplacementFor_res.ReplacementFor_has_header("Accept-Ranges") && ReplacementFor_req.ReplacementFor_method == "HEAD") {
    ReplacementFor_res.ReplacementFor_set_header("Accept-Ranges", "bytes");
  }

  if (ReplacementFor_post_routing_handler_) { ReplacementFor_post_routing_handler_(ReplacementFor_req, ReplacementFor_res); }

  {
    ReplacementFor_detail::ReplacementFor_BufferStream ReplacementFor_bstrm;

    if (!ReplacementFor_bstrm.ReplacementFor_write_format("HTTP/1.1 %d %s\r\n", ReplacementFor_res.status,
                            ReplacementFor_detail::ReplacementFor_status_message(ReplacementFor_res.status))) {
      return false;
    }

    if (!ReplacementFor_detail::ReplacementFor_write_headers(ReplacementFor_bstrm, ReplacementFor_res.ReplacementFor_headers)) { return false; }

    
    auto &data = ReplacementFor_bstrm.ReplacementFor_get_buffer();
    ReplacementFor_strm.write(data.data(), data.size());
  }

  auto ReplacementFor_ret = true;
  if (ReplacementFor_req.ReplacementFor_method != "HEAD") {
    if (!ReplacementFor_res.ReplacementFor_body.empty()) {
      if (!ReplacementFor_strm.write(ReplacementFor_res.ReplacementFor_body)) { ReplacementFor_ret = false; }
    } else if (ReplacementFor_res.ReplacementFor_content_provider_) {
      if (!ReplacementFor_write_content_with_provider(ReplacementFor_strm, ReplacementFor_req, ReplacementFor_res, ReplacementFor_boundary,
                                       ReplacementFor_content_type)) {
        ReplacementFor_ret = false;
      }
    }
  }

  if (ReplacementFor_logger_) { ReplacementFor_logger_(ReplacementFor_req, ReplacementFor_res); }

  return ReplacementFor_ret;
}

bool
ReplacementFor_Server::ReplacementFor_write_content_with_provider(ReplacementFor_Stream &ReplacementFor_strm, const ReplacementFor_Request &ReplacementFor_req,
                                    ReplacementFor_Response &ReplacementFor_res, const std::string &ReplacementFor_boundary,
                                    const std::string &ReplacementFor_content_type) {
  auto ReplacementFor_is_shutting_down = [this]() {
    return this->ReplacementFor_svr_sock_ == INVALID_SOCKET;
  };

  if (ReplacementFor_res.ReplacementFor_content_length_ > 0) {
    if (ReplacementFor_req.ranges.empty()) {
      return ReplacementFor_detail::ReplacementFor_write_content(ReplacementFor_strm, ReplacementFor_res.ReplacementFor_content_provider_, 0,
                                   ReplacementFor_res.ReplacementFor_content_length_, ReplacementFor_is_shutting_down);
    } else if (ReplacementFor_req.ranges.size() == 1) {
      auto ReplacementFor_offsets =
          ReplacementFor_detail::ReplacementFor_get_range_offset_and_length(ReplacementFor_req, ReplacementFor_res.ReplacementFor_content_length_, 0);
      auto offset = ReplacementFor_offsets.first;
      auto length = ReplacementFor_offsets.second;
      return ReplacementFor_detail::ReplacementFor_write_content(ReplacementFor_strm, ReplacementFor_res.ReplacementFor_content_provider_, offset, length,
                                   ReplacementFor_is_shutting_down);
    } else {
      return ReplacementFor_detail::ReplacementFor_write_multipart_ranges_data(
          ReplacementFor_strm, ReplacementFor_req, ReplacementFor_res, ReplacementFor_boundary, ReplacementFor_content_type, ReplacementFor_is_shutting_down);
    }
  } else {
    if (ReplacementFor_res.ReplacementFor_is_chunked_content_provider_) {
      auto type = ReplacementFor_detail::ReplacementFor_encoding_type(ReplacementFor_req, ReplacementFor_res);

      std::unique_ptr<ReplacementFor_detail::ReplacementFor_compressor> ReplacementFor_compressor;
      if (type == ReplacementFor_detail::ReplacementFor_EncodingType::ReplacementFor_Gzip) {
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
        ReplacementFor_compressor = ReplacementFor_detail::make_unique<ReplacementFor_detail::ReplacementFor_gzip_compressor>();
#endif
      } else if (type == ReplacementFor_detail::ReplacementFor_EncodingType::ReplacementFor_Brotli) {
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
        ReplacementFor_compressor = ReplacementFor_detail::make_unique<ReplacementFor_detail::ReplacementFor_brotli_compressor>();
#endif
      } else {
        ReplacementFor_compressor = ReplacementFor_detail::make_unique<ReplacementFor_detail::ReplacementFor_nocompressor>();
      }
      assert(ReplacementFor_compressor != nullptr);

      return ReplacementFor_detail::ReplacementFor_write_content_chunked(ReplacementFor_strm, ReplacementFor_res.ReplacementFor_content_provider_,
                                           ReplacementFor_is_shutting_down, *ReplacementFor_compressor);
    } else {
      return ReplacementFor_detail::ReplacementFor_write_content_without_length(ReplacementFor_strm, ReplacementFor_res.ReplacementFor_content_provider_,
                                                  ReplacementFor_is_shutting_down);
    }
  }
}

bool ReplacementFor_Server::ReplacementFor_read_content(ReplacementFor_Stream &ReplacementFor_strm, ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res) {
  ReplacementFor_MultipartFormDataMap::iterator cur;
  if (ReplacementFor_read_content_core(
          ReplacementFor_strm, ReplacementFor_req, ReplacementFor_res,
          
          [&](const char *buf, size_t n) {
            if (ReplacementFor_req.ReplacementFor_body.size() + n > ReplacementFor_req.ReplacementFor_body.max_size()) { return false; }
            ReplacementFor_req.ReplacementFor_body.append(buf, n);
            return true;
          },
          
          [&](const ReplacementFor_MultipartFormData &ReplacementFor_file) {
            cur = ReplacementFor_req.ReplacementFor_files.emplace(ReplacementFor_file.name, ReplacementFor_file);
            return true;
          },
          [&](const char *buf, size_t n) {
            auto &ReplacementFor_content = cur->second.ReplacementFor_content;
            if (ReplacementFor_content.size() + n > ReplacementFor_content.max_size()) { return false; }
            ReplacementFor_content.append(buf, n);
            return true;
          })) {
    const auto &ReplacementFor_content_type = ReplacementFor_req.ReplacementFor_get_header_value("Content-Type");
    if (!ReplacementFor_content_type.find("application/x-www-form-urlencoded")) {
      ReplacementFor_detail::ReplacementFor_parse_query_text(ReplacementFor_req.ReplacementFor_body, ReplacementFor_req.ReplacementFor_params);
    }
    return true;
  }
  return false;
}

bool ReplacementFor_Server::ReplacementFor_read_content_with_content_receiver(
    ReplacementFor_Stream &ReplacementFor_strm, ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res, ReplacementFor_ContentReceiver ReplacementFor_receiver,
    ReplacementFor_MultipartContentHeader ReplacementFor_multipart_header,
    ReplacementFor_ContentReceiver ReplacementFor_multipart_receiver) {
  return ReplacementFor_read_content_core(ReplacementFor_strm, ReplacementFor_req, ReplacementFor_res, std::move(ReplacementFor_receiver),
                           std::move(ReplacementFor_multipart_header),
                           std::move(ReplacementFor_multipart_receiver));
}

bool ReplacementFor_Server::ReplacementFor_read_content_core(ReplacementFor_Stream &ReplacementFor_strm, ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res,
                                      ReplacementFor_ContentReceiver ReplacementFor_receiver,
                                      ReplacementFor_MultipartContentHeader ReplacementFor_mulitpart_header,
                                      ReplacementFor_ContentReceiver ReplacementFor_multipart_receiver) {
  ReplacementFor_detail::ReplacementFor_MultipartFormDataParser ReplacementFor_multipart_form_data_parser;
  ReplacementFor_ContentReceiverWithProgress out;

  if (ReplacementFor_req.ReplacementFor_is_multipart_form_data()) {
    const auto &ReplacementFor_content_type = ReplacementFor_req.ReplacementFor_get_header_value("Content-Type");
    std::string ReplacementFor_boundary;
    if (!ReplacementFor_detail::ReplacementFor_parse_multipart_boundary(ReplacementFor_content_type, ReplacementFor_boundary)) {
      ReplacementFor_res.status = 400;
      return false;
    }

    ReplacementFor_multipart_form_data_parser.ReplacementFor_set_boundary(std::move(ReplacementFor_boundary));
    out = [&](const char *buf, size_t n, uint64_t  , uint64_t  ) {
      return ReplacementFor_multipart_form_data_parser.ReplacementFor_parse(buf, n, ReplacementFor_multipart_receiver,
                                              ReplacementFor_mulitpart_header);
    };
  } else {
    out = [ReplacementFor_receiver](const char *buf, size_t n, uint64_t  ,
                     uint64_t  ) { return ReplacementFor_receiver(buf, n); };
  }

  if (ReplacementFor_req.ReplacementFor_method == "DELETE" && !ReplacementFor_req.ReplacementFor_has_header("Content-Length")) {
    return true;
  }

  if (!ReplacementFor_detail::ReplacementFor_read_content(ReplacementFor_strm, ReplacementFor_req, ReplacementFor_payload_max_length_, ReplacementFor_res.status, nullptr,
                            out, true)) {
    return false;
  }

  if (ReplacementFor_req.ReplacementFor_is_multipart_form_data()) {
    if (!ReplacementFor_multipart_form_data_parser.ReplacementFor_is_valid()) {
      ReplacementFor_res.status = 400;
      return false;
    }
  }

  return true;
}

bool ReplacementFor_Server::ReplacementFor_handle_file_request(const ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res,
                                        bool ReplacementFor_head) {
  for (const auto &entry : ReplacementFor_base_dirs_) {
    if (!ReplacementFor_req.ReplacementFor_path.compare(0, entry.ReplacementFor_mount_point.size(), entry.ReplacementFor_mount_point)) {
      std::string ReplacementFor_sub_path = "/" + ReplacementFor_req.ReplacementFor_path.substr(entry.ReplacementFor_mount_point.size());
      if (ReplacementFor_detail::ReplacementFor_is_valid_path(ReplacementFor_sub_path)) {
        auto ReplacementFor_path = entry.ReplacementFor_base_dir + ReplacementFor_sub_path;
        if (ReplacementFor_path.back() == ((char)(0x2283+898-0x25d6))) { ReplacementFor_path += "index.html"; }

        if (ReplacementFor_detail::ReplacementFor_is_file(ReplacementFor_path)) {
          ReplacementFor_detail::ReplacementFor_read_file(ReplacementFor_path, ReplacementFor_res.ReplacementFor_body);
          auto type =
              ReplacementFor_detail::ReplacementFor_find_content_type(ReplacementFor_path, ReplacementFor_file_extension_and_mimetype_map_);
          if (type) { ReplacementFor_res.ReplacementFor_set_header("Content-Type", type); }
          for (const auto &ReplacementFor_kv : entry.ReplacementFor_headers) {
            ReplacementFor_res.ReplacementFor_set_header(ReplacementFor_kv.first.c_str(), ReplacementFor_kv.second);
          }
          ReplacementFor_res.status = ReplacementFor_req.ReplacementFor_has_header("Range") ? 206 : 200;
          if (!ReplacementFor_head && ReplacementFor_file_request_handler_) {
            ReplacementFor_file_request_handler_(ReplacementFor_req, ReplacementFor_res);
          }
          return true;
        }
      }
    }
  }
  return false;
}

ReplacementFor_socket_t
ReplacementFor_Server::ReplacementFor_create_server_socket(const char *ReplacementFor_host, int ReplacementFor_port, int ReplacementFor_socket_flags,
                             ReplacementFor_SocketOptions ReplacementFor_socket_options) const {
  return ReplacementFor_detail::ReplacementFor_create_socket(
      ReplacementFor_host, ReplacementFor_port, ReplacementFor_socket_flags, ReplacementFor_tcp_nodelay_, std::move(ReplacementFor_socket_options),
      [](ReplacementFor_socket_t ReplacementFor_sock, struct addrinfo &ReplacementFor_ai) -> bool {
        if (::bind(ReplacementFor_sock, ReplacementFor_ai.ai_addr, static_cast<socklen_t>(ReplacementFor_ai.ai_addrlen))) {
          return false;
        }
        if (::listen(ReplacementFor_sock, 5)) { 
          return false;
        }
        return true;
      });
}

int ReplacementFor_Server::ReplacementFor_bind_internal(const char *ReplacementFor_host, int ReplacementFor_port, int ReplacementFor_socket_flags) {
  if (!ReplacementFor_is_valid()) { return -1; }

  ReplacementFor_svr_sock_ = ReplacementFor_create_server_socket(ReplacementFor_host, ReplacementFor_port, ReplacementFor_socket_flags, ReplacementFor_socket_options_);
  if (ReplacementFor_svr_sock_ == INVALID_SOCKET) { return -1; }

  if (ReplacementFor_port == 0) {
    struct sockaddr_storage addr;
    socklen_t ReplacementFor_addr_len = sizeof(addr);
    if (getsockname(ReplacementFor_svr_sock_, reinterpret_cast<struct sockaddr *>(&addr),
                    &ReplacementFor_addr_len) == -1) {
      return -1;
    }
    if (addr.ss_family == AF_INET) {
      return ntohs(reinterpret_cast<struct sockaddr_in *>(&addr)->sin_port);
    } else if (addr.ss_family == AF_INET6) {
      return ntohs(reinterpret_cast<struct sockaddr_in6 *>(&addr)->sin6_port);
    } else {
      return -1;
    }
  } else {
    return ReplacementFor_port;
  }
}

bool ReplacementFor_Server::ReplacementFor_listen_internal() {
  auto ReplacementFor_ret = true;
  ReplacementFor_is_running_ = true;

  {
    std::unique_ptr<ReplacementFor_TaskQueue> ReplacementFor_task_queue(ReplacementFor_new_task_queue());

    while (ReplacementFor_svr_sock_ != INVALID_SOCKET) {
#ifndef _WIN32
      if (ReplacementFor_idle_interval_sec_ > 0 || ReplacementFor_idle_interval_usec_ > 0) {
#endif
        auto val = ReplacementFor_detail::ReplacementFor_select_read(ReplacementFor_svr_sock_, ReplacementFor_idle_interval_sec_,
                                       ReplacementFor_idle_interval_usec_);
        if (val == 0) { 
          ReplacementFor_task_queue->ReplacementFor_on_idle();
          continue;
        }
#ifndef _WIN32
      }
#endif
      ReplacementFor_socket_t ReplacementFor_sock = accept(ReplacementFor_svr_sock_, nullptr, nullptr);

      if (ReplacementFor_sock == INVALID_SOCKET) {
        if (errno == EMFILE) {
          
          
          std::this_thread::sleep_for(std::chrono::milliseconds(1));
          continue;
        }
        if (ReplacementFor_svr_sock_ != INVALID_SOCKET) {
          ReplacementFor_detail::ReplacementFor_close_socket(ReplacementFor_svr_sock_);
          ReplacementFor_ret = false;
        } else {
          ; 
        }
        break;
      }

#if __cplusplus > 201703L
      ReplacementFor_task_queue->ReplacementFor_enqueue([=, this]() { ReplacementFor_process_and_close_socket(ReplacementFor_sock); });
#else
      ReplacementFor_task_queue->ReplacementFor_enqueue([=]() { ReplacementFor_process_and_close_socket(ReplacementFor_sock); });
#endif
    }

    ReplacementFor_task_queue->shutdown();
  }

  ReplacementFor_is_running_ = false;
  return ReplacementFor_ret;
}

bool ReplacementFor_Server::ReplacementFor_routing(ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res, ReplacementFor_Stream &ReplacementFor_strm) {
  if (ReplacementFor_pre_routing_handler_ &&
      ReplacementFor_pre_routing_handler_(ReplacementFor_req, ReplacementFor_res) == ReplacementFor_HandlerResponse::ReplacementFor_Handled) {
    return true;
  }

  bool ReplacementFor_is_head_request = ReplacementFor_req.ReplacementFor_method == "HEAD";
  if ((ReplacementFor_req.ReplacementFor_method == "GET" || ReplacementFor_is_head_request) &&
      ReplacementFor_handle_file_request(ReplacementFor_req, ReplacementFor_res, ReplacementFor_is_head_request)) {
    return true;
  }

  if (ReplacementFor_detail::ReplacementFor_expect_content(ReplacementFor_req)) {
    {
      ReplacementFor_ContentReader ReplacementFor_reader(
          [&](ReplacementFor_ContentReceiver ReplacementFor_receiver) {
            return ReplacementFor_read_content_with_content_receiver(
                ReplacementFor_strm, ReplacementFor_req, ReplacementFor_res, std::move(ReplacementFor_receiver), nullptr, nullptr);
          },
          [&](ReplacementFor_MultipartContentHeader header, ReplacementFor_ContentReceiver ReplacementFor_receiver) {
            return ReplacementFor_read_content_with_content_receiver(ReplacementFor_strm, ReplacementFor_req, ReplacementFor_res, nullptr,
                                                      std::move(header),
                                                      std::move(ReplacementFor_receiver));
          });

      if (ReplacementFor_req.ReplacementFor_method == "POST") {
        if (ReplacementFor_dispatch_request_for_content_reader(
                ReplacementFor_req, ReplacementFor_res, std::move(ReplacementFor_reader),
                ReplacementFor_post_handlers_for_content_reader_)) {
          return true;
        }
      } else if (ReplacementFor_req.ReplacementFor_method == "PUT") {
        if (ReplacementFor_dispatch_request_for_content_reader(
                ReplacementFor_req, ReplacementFor_res, std::move(ReplacementFor_reader),
                ReplacementFor_put_handlers_for_content_reader_)) {
          return true;
        }
      } else if (ReplacementFor_req.ReplacementFor_method == "PATCH") {
        if (ReplacementFor_dispatch_request_for_content_reader(
                ReplacementFor_req, ReplacementFor_res, std::move(ReplacementFor_reader),
                ReplacementFor_patch_handlers_for_content_reader_)) {
          return true;
        }
      } else if (ReplacementFor_req.ReplacementFor_method == "DELETE") {
        if (ReplacementFor_dispatch_request_for_content_reader(
                ReplacementFor_req, ReplacementFor_res, std::move(ReplacementFor_reader),
                ReplacementFor_delete_handlers_for_content_reader_)) {
          return true;
        }
      }
    }

    if (!ReplacementFor_read_content(ReplacementFor_strm, ReplacementFor_req, ReplacementFor_res)) { return false; }
  }

  if (ReplacementFor_req.ReplacementFor_method == "GET" || ReplacementFor_req.ReplacementFor_method == "HEAD") {
    return ReplacementFor_dispatch_request(ReplacementFor_req, ReplacementFor_res, ReplacementFor_get_handlers_);
  } else if (ReplacementFor_req.ReplacementFor_method == "POST") {
    return ReplacementFor_dispatch_request(ReplacementFor_req, ReplacementFor_res, ReplacementFor_post_handlers_);
  } else if (ReplacementFor_req.ReplacementFor_method == "PUT") {
    return ReplacementFor_dispatch_request(ReplacementFor_req, ReplacementFor_res, ReplacementFor_put_handlers_);
  } else if (ReplacementFor_req.ReplacementFor_method == "DELETE") {
    return ReplacementFor_dispatch_request(ReplacementFor_req, ReplacementFor_res, ReplacementFor_delete_handlers_);
  } else if (ReplacementFor_req.ReplacementFor_method == "OPTIONS") {
    return ReplacementFor_dispatch_request(ReplacementFor_req, ReplacementFor_res, ReplacementFor_options_handlers_);
  } else if (ReplacementFor_req.ReplacementFor_method == "PATCH") {
    return ReplacementFor_dispatch_request(ReplacementFor_req, ReplacementFor_res, ReplacementFor_patch_handlers_);
  }

  ReplacementFor_res.status = 400;
  return false;
}

bool ReplacementFor_Server::ReplacementFor_dispatch_request(ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res,
                                     const ReplacementFor_Handlers &ReplacementFor_handlers) {
  for (const auto &x : ReplacementFor_handlers) {
    const auto &pattern = x.first;
    const auto &ReplacementFor_handler = x.second;

    if (std::regex_match(ReplacementFor_req.ReplacementFor_path, ReplacementFor_req.ReplacementFor_matches, pattern)) {
      ReplacementFor_handler(ReplacementFor_req, ReplacementFor_res);
      return true;
    }
  }
  return false;
}

void ReplacementFor_Server::ReplacementFor_apply_ranges(const ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res,
                                 std::string &ReplacementFor_content_type,
                                 std::string &ReplacementFor_boundary) {
  if (ReplacementFor_req.ranges.size() > 1) {
    ReplacementFor_boundary = ReplacementFor_detail::ReplacementFor_make_multipart_data_boundary();

    auto ReplacementFor_it = ReplacementFor_res.ReplacementFor_headers.find("Content-Type");
    if (ReplacementFor_it != ReplacementFor_res.ReplacementFor_headers.end()) {
      ReplacementFor_content_type = ReplacementFor_it->second;
      ReplacementFor_res.ReplacementFor_headers.erase(ReplacementFor_it);
    }

    ReplacementFor_res.ReplacementFor_headers.emplace("Content-Type",
                        "multipart/byteranges; boundary=" + ReplacementFor_boundary);
  }

  auto type = ReplacementFor_detail::ReplacementFor_encoding_type(ReplacementFor_req, ReplacementFor_res);

  if (ReplacementFor_res.ReplacementFor_body.empty()) {
    if (ReplacementFor_res.ReplacementFor_content_length_ > 0) {
      size_t length = 0;
      if (ReplacementFor_req.ranges.empty()) {
        length = ReplacementFor_res.ReplacementFor_content_length_;
      } else if (ReplacementFor_req.ranges.size() == 1) {
        auto ReplacementFor_offsets =
            ReplacementFor_detail::ReplacementFor_get_range_offset_and_length(ReplacementFor_req, ReplacementFor_res.ReplacementFor_content_length_, 0);
        auto offset = ReplacementFor_offsets.first;
        length = ReplacementFor_offsets.second;
        auto ReplacementFor_content_range = ReplacementFor_detail::ReplacementFor_make_content_range_header_field(
            offset, length, ReplacementFor_res.ReplacementFor_content_length_);
        ReplacementFor_res.ReplacementFor_set_header("Content-Range", ReplacementFor_content_range);
      } else {
        length = ReplacementFor_detail::ReplacementFor_get_multipart_ranges_data_length(ReplacementFor_req, ReplacementFor_res, ReplacementFor_boundary,
                                                          ReplacementFor_content_type);
      }
      ReplacementFor_res.ReplacementFor_set_header("Content-Length", std::to_string(length));
    } else {
      if (ReplacementFor_res.ReplacementFor_content_provider_) {
        if (ReplacementFor_res.ReplacementFor_is_chunked_content_provider_) {
          ReplacementFor_res.ReplacementFor_set_header("Transfer-Encoding", "chunked");
          if (type == ReplacementFor_detail::ReplacementFor_EncodingType::ReplacementFor_Gzip) {
            ReplacementFor_res.ReplacementFor_set_header("Content-Encoding", "gzip");
          } else if (type == ReplacementFor_detail::ReplacementFor_EncodingType::ReplacementFor_Brotli) {
            ReplacementFor_res.ReplacementFor_set_header("Content-Encoding", "br");
          }
        }
      }
    }
  } else {
    if (ReplacementFor_req.ranges.empty()) {
      ;
    } else if (ReplacementFor_req.ranges.size() == 1) {
      auto ReplacementFor_offsets =
          ReplacementFor_detail::ReplacementFor_get_range_offset_and_length(ReplacementFor_req, ReplacementFor_res.ReplacementFor_body.size(), 0);
      auto offset = ReplacementFor_offsets.first;
      auto length = ReplacementFor_offsets.second;
      auto ReplacementFor_content_range = ReplacementFor_detail::ReplacementFor_make_content_range_header_field(
          offset, length, ReplacementFor_res.ReplacementFor_body.size());
      ReplacementFor_res.ReplacementFor_set_header("Content-Range", ReplacementFor_content_range);
      if (offset < ReplacementFor_res.ReplacementFor_body.size()) {
        ReplacementFor_res.ReplacementFor_body = ReplacementFor_res.ReplacementFor_body.substr(offset, length);
      } else {
        ReplacementFor_res.ReplacementFor_body.clear();
        ReplacementFor_res.status = 416;
      }
    } else {
      std::string data;
      if (ReplacementFor_detail::ReplacementFor_make_multipart_ranges_data(ReplacementFor_req, ReplacementFor_res, ReplacementFor_boundary, ReplacementFor_content_type,
                                             data)) {
        ReplacementFor_res.ReplacementFor_body.swap(data);
      } else {
        ReplacementFor_res.ReplacementFor_body.clear();
        ReplacementFor_res.status = 416;
      }
    }

    if (type != ReplacementFor_detail::ReplacementFor_EncodingType::None) {
      std::unique_ptr<ReplacementFor_detail::ReplacementFor_compressor> ReplacementFor_compressor;
      std::string ReplacementFor_content_encoding;

      if (type == ReplacementFor_detail::ReplacementFor_EncodingType::ReplacementFor_Gzip) {
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
        ReplacementFor_compressor = ReplacementFor_detail::make_unique<ReplacementFor_detail::ReplacementFor_gzip_compressor>();
        ReplacementFor_content_encoding = "gzip";
#endif
      } else if (type == ReplacementFor_detail::ReplacementFor_EncodingType::ReplacementFor_Brotli) {
#ifdef ReplacementFor_CPPHTTPLIB_BROTLI_SUPPORT
        ReplacementFor_compressor = ReplacementFor_detail::make_unique<ReplacementFor_detail::ReplacementFor_brotli_compressor>();
        ReplacementFor_content_encoding = "br";
#endif
      }

      if (ReplacementFor_compressor) {
        std::string ReplacementFor_compressed;
        if (ReplacementFor_compressor->compress(ReplacementFor_res.ReplacementFor_body.data(), ReplacementFor_res.ReplacementFor_body.size(), true,
                                 [&](const char *data, size_t ReplacementFor_data_len) {
                                   ReplacementFor_compressed.append(data, ReplacementFor_data_len);
                                   return true;
                                 })) {
          ReplacementFor_res.ReplacementFor_body.swap(ReplacementFor_compressed);
          ReplacementFor_res.ReplacementFor_set_header("Content-Encoding", ReplacementFor_content_encoding);
        }
      }
    }

    auto length = std::to_string(ReplacementFor_res.ReplacementFor_body.size());
    ReplacementFor_res.ReplacementFor_set_header("Content-Length", length);
  }
}

bool ReplacementFor_Server::ReplacementFor_dispatch_request_for_content_reader(
    ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res, ReplacementFor_ContentReader ReplacementFor_content_reader,
    const ReplacementFor_HandlersForContentReader &ReplacementFor_handlers) {
  for (const auto &x : ReplacementFor_handlers) {
    const auto &pattern = x.first;
    const auto &ReplacementFor_handler = x.second;

    if (std::regex_match(ReplacementFor_req.ReplacementFor_path, ReplacementFor_req.ReplacementFor_matches, pattern)) {
      ReplacementFor_handler(ReplacementFor_req, ReplacementFor_res, ReplacementFor_content_reader);
      return true;
    }
  }
  return false;
}

bool
ReplacementFor_Server::ReplacementFor_process_request(ReplacementFor_Stream &ReplacementFor_strm, bool ReplacementFor_close_connection,
                        bool &ReplacementFor_connection_closed,
                        const std::function<void(ReplacementFor_Request &)> &ReplacementFor_setup_request) {
  std::array<char, 2048> buf{};

  ReplacementFor_detail::ReplacementFor_stream_line_reader ReplacementFor_line_reader(ReplacementFor_strm, buf.data(), buf.size());

  if (!ReplacementFor_line_reader.getline()) { return false; }

  ReplacementFor_Request ReplacementFor_req;
  ReplacementFor_Response ReplacementFor_res;

  ReplacementFor_res.ReplacementFor_version = "HTTP/1.1";

#ifdef _WIN32
#else
#ifndef ReplacementFor_CPPHTTPLIB_USE_POLL
  if (ReplacementFor_strm.socket() >= FD_SETSIZE) {
    ReplacementFor_Headers dummy;
    ReplacementFor_detail::ReplacementFor_read_headers(ReplacementFor_strm, dummy);
    ReplacementFor_res.status = 500;
    return ReplacementFor_write_response(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_req, ReplacementFor_res);
  }
#endif
#endif

  if (ReplacementFor_line_reader.size() > ReplacementFor_CPPHTTPLIB_REQUEST_URI_MAX_LENGTH) {
    ReplacementFor_Headers dummy;
    ReplacementFor_detail::ReplacementFor_read_headers(ReplacementFor_strm, dummy);
    ReplacementFor_res.status = 414;
    return ReplacementFor_write_response(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_req, ReplacementFor_res);
  }

  if (!ReplacementFor_parse_request_line(ReplacementFor_line_reader.ReplacementFor_ptr(), ReplacementFor_req) ||
      !ReplacementFor_detail::ReplacementFor_read_headers(ReplacementFor_strm, ReplacementFor_req.ReplacementFor_headers)) {
    ReplacementFor_res.status = 400;
    return ReplacementFor_write_response(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_req, ReplacementFor_res);
  }

  if (ReplacementFor_req.ReplacementFor_get_header_value("Connection") == "close") {
    ReplacementFor_connection_closed = true;
  }

  if (ReplacementFor_req.ReplacementFor_version == "HTTP/1.0" &&
      ReplacementFor_req.ReplacementFor_get_header_value("Connection") != "Keep-Alive") {
    ReplacementFor_connection_closed = true;
  }

  ReplacementFor_strm.ReplacementFor_get_remote_ip_and_port(ReplacementFor_req.ReplacementFor_remote_addr, ReplacementFor_req.ReplacementFor_remote_port);
  ReplacementFor_req.ReplacementFor_set_header("REMOTE_ADDR", ReplacementFor_req.ReplacementFor_remote_addr);
  ReplacementFor_req.ReplacementFor_set_header("REMOTE_PORT", std::to_string(ReplacementFor_req.ReplacementFor_remote_port));

  if (ReplacementFor_req.ReplacementFor_has_header("Range")) {
    const auto &ReplacementFor_range_header_value = ReplacementFor_req.ReplacementFor_get_header_value("Range");
    if (!ReplacementFor_detail::ReplacementFor_parse_range_header(ReplacementFor_range_header_value, ReplacementFor_req.ranges)) {
      ReplacementFor_res.status = 416;
      return ReplacementFor_write_response(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_req, ReplacementFor_res);
    }
  }

  if (ReplacementFor_setup_request) { ReplacementFor_setup_request(ReplacementFor_req); }

  if (ReplacementFor_req.ReplacementFor_get_header_value("Expect") == "100-continue") {
    auto status = 100;
    if (ReplacementFor_expect_100_continue_handler_) {
      status = ReplacementFor_expect_100_continue_handler_(ReplacementFor_req, ReplacementFor_res);
    }
    switch (status) {
    case 100:
    case 417:
      ReplacementFor_strm.ReplacementFor_write_format("HTTP/1.1 %d %s\r\n\r\n", status,
                        ReplacementFor_detail::ReplacementFor_status_message(status));
      break;
    default: return ReplacementFor_write_response(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_req, ReplacementFor_res);
    }
  }

  bool ReplacementFor_routed = false;
  try {
    ReplacementFor_routed = ReplacementFor_routing(ReplacementFor_req, ReplacementFor_res, ReplacementFor_strm);
  } catch (std::exception &ReplacementFor_e) {
    if (ReplacementFor_exception_handler_) {
      ReplacementFor_exception_handler_(ReplacementFor_req, ReplacementFor_res, ReplacementFor_e);
      ReplacementFor_routed = true;
    } else {
      ReplacementFor_res.status = 500;
      ReplacementFor_res.ReplacementFor_set_header("EXCEPTION_WHAT", ReplacementFor_e.what());
    }
  } catch (...) {
    ReplacementFor_res.status = 500;
    ReplacementFor_res.ReplacementFor_set_header("EXCEPTION_WHAT", "UNKNOWN");
  }

  if (ReplacementFor_routed) {
    if (ReplacementFor_res.status == -1) { ReplacementFor_res.status = ReplacementFor_req.ranges.empty() ? 200 : 206; }
    return ReplacementFor_write_response_with_content(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_req, ReplacementFor_res);
  } else {
    if (ReplacementFor_res.status == -1) { ReplacementFor_res.status = 404; }
    return ReplacementFor_write_response(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_req, ReplacementFor_res);
  }
}

bool ReplacementFor_Server::ReplacementFor_is_valid() const { return true; }

bool ReplacementFor_Server::ReplacementFor_process_and_close_socket(ReplacementFor_socket_t ReplacementFor_sock) {
  auto ReplacementFor_ret = ReplacementFor_detail::ReplacementFor_process_server_socket(
      ReplacementFor_sock, ReplacementFor_keep_alive_max_count_, ReplacementFor_keep_alive_timeout_sec_, ReplacementFor_read_timeout_sec_,
      ReplacementFor_read_timeout_usec_, ReplacementFor_write_timeout_sec_, ReplacementFor_write_timeout_usec_,
      [this](ReplacementFor_Stream &ReplacementFor_strm, bool ReplacementFor_close_connection, bool &ReplacementFor_connection_closed) {
        return ReplacementFor_process_request(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_connection_closed,
                               nullptr);
      });

  ReplacementFor_detail::ReplacementFor_shutdown_socket(ReplacementFor_sock);
  ReplacementFor_detail::ReplacementFor_close_socket(ReplacementFor_sock);
  return ReplacementFor_ret;
}

ReplacementFor_ClientImpl::ReplacementFor_ClientImpl(const std::string &ReplacementFor_host)
    : ReplacementFor_ClientImpl(ReplacementFor_host, 80, std::string(), std::string()) {}

ReplacementFor_ClientImpl::ReplacementFor_ClientImpl(const std::string &ReplacementFor_host, int ReplacementFor_port)
    : ReplacementFor_ClientImpl(ReplacementFor_host, ReplacementFor_port, std::string(), std::string()) {}

ReplacementFor_ClientImpl::ReplacementFor_ClientImpl(const std::string &ReplacementFor_host, int ReplacementFor_port,
                              const std::string &ReplacementFor_client_cert_path,
                              const std::string &ReplacementFor_client_key_path)
    
    : ReplacementFor_host_(ReplacementFor_host), ReplacementFor_port_(ReplacementFor_port),
      ReplacementFor_host_and_port_(ReplacementFor_host_ + ":" + std::to_string(ReplacementFor_port_)),
      ReplacementFor_client_cert_path_(ReplacementFor_client_cert_path), ReplacementFor_client_key_path_(ReplacementFor_client_key_path) {}

ReplacementFor_ClientImpl::~ReplacementFor_ClientImpl() { ReplacementFor_lock_socket_and_shutdown_and_close(); }

bool ReplacementFor_ClientImpl::ReplacementFor_is_valid() const { return true; }

void ReplacementFor_ClientImpl::ReplacementFor_copy_settings(const ReplacementFor_ClientImpl &ReplacementFor_rhs) {
  ReplacementFor_client_cert_path_ = ReplacementFor_rhs.ReplacementFor_client_cert_path_;
  ReplacementFor_client_key_path_ = ReplacementFor_rhs.ReplacementFor_client_key_path_;
  ReplacementFor_connection_timeout_sec_ = ReplacementFor_rhs.ReplacementFor_connection_timeout_sec_;
  ReplacementFor_read_timeout_sec_ = ReplacementFor_rhs.ReplacementFor_read_timeout_sec_;
  ReplacementFor_read_timeout_usec_ = ReplacementFor_rhs.ReplacementFor_read_timeout_usec_;
  ReplacementFor_write_timeout_sec_ = ReplacementFor_rhs.ReplacementFor_write_timeout_sec_;
  ReplacementFor_write_timeout_usec_ = ReplacementFor_rhs.ReplacementFor_write_timeout_usec_;
  ReplacementFor_basic_auth_username_ = ReplacementFor_rhs.ReplacementFor_basic_auth_username_;
  ReplacementFor_basic_auth_password_ = ReplacementFor_rhs.ReplacementFor_basic_auth_password_;
  ReplacementFor_bearer_token_auth_token_ = ReplacementFor_rhs.ReplacementFor_bearer_token_auth_token_;
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
  ReplacementFor_digest_auth_username_ = ReplacementFor_rhs.ReplacementFor_digest_auth_username_;
  ReplacementFor_digest_auth_password_ = ReplacementFor_rhs.ReplacementFor_digest_auth_password_;
#endif
  ReplacementFor_keep_alive_ = ReplacementFor_rhs.ReplacementFor_keep_alive_;
  ReplacementFor_follow_location_ = ReplacementFor_rhs.ReplacementFor_follow_location_;
  ReplacementFor_tcp_nodelay_ = ReplacementFor_rhs.ReplacementFor_tcp_nodelay_;
  ReplacementFor_socket_options_ = ReplacementFor_rhs.ReplacementFor_socket_options_;
  ReplacementFor_compress_ = ReplacementFor_rhs.ReplacementFor_compress_;
  ReplacementFor_decompress_ = ReplacementFor_rhs.ReplacementFor_decompress_;
  ReplacementFor_interface_ = ReplacementFor_rhs.ReplacementFor_interface_;
  ReplacementFor_proxy_host_ = ReplacementFor_rhs.ReplacementFor_proxy_host_;
  ReplacementFor_proxy_port_ = ReplacementFor_rhs.ReplacementFor_proxy_port_;
  ReplacementFor_proxy_basic_auth_username_ = ReplacementFor_rhs.ReplacementFor_proxy_basic_auth_username_;
  ReplacementFor_proxy_basic_auth_password_ = ReplacementFor_rhs.ReplacementFor_proxy_basic_auth_password_;
  ReplacementFor_proxy_bearer_token_auth_token_ = ReplacementFor_rhs.ReplacementFor_proxy_bearer_token_auth_token_;
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
  ReplacementFor_proxy_digest_auth_username_ = ReplacementFor_rhs.ReplacementFor_proxy_digest_auth_username_;
  ReplacementFor_proxy_digest_auth_password_ = ReplacementFor_rhs.ReplacementFor_proxy_digest_auth_password_;
#endif
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
  ReplacementFor_server_certificate_verification_ = ReplacementFor_rhs.ReplacementFor_server_certificate_verification_;
#endif
  ReplacementFor_logger_ = ReplacementFor_rhs.ReplacementFor_logger_;
}

ReplacementFor_socket_t ReplacementFor_ClientImpl::ReplacementFor_create_client_socket(Error &error) const {
  if (!ReplacementFor_proxy_host_.empty() && ReplacementFor_proxy_port_ != -1) {
    return ReplacementFor_detail::ReplacementFor_create_client_socket(
        ReplacementFor_proxy_host_.c_str(), ReplacementFor_proxy_port_, ReplacementFor_tcp_nodelay_, ReplacementFor_socket_options_,
        ReplacementFor_connection_timeout_sec_, ReplacementFor_connection_timeout_usec_, ReplacementFor_interface_, error);
  }
  return ReplacementFor_detail::ReplacementFor_create_client_socket(
      ReplacementFor_host_.c_str(), ReplacementFor_port_, ReplacementFor_tcp_nodelay_, ReplacementFor_socket_options_,
      ReplacementFor_connection_timeout_sec_, ReplacementFor_connection_timeout_usec_, ReplacementFor_interface_, error);
}

bool ReplacementFor_ClientImpl::ReplacementFor_create_and_connect_socket(Socket &socket,
                                                  Error &error) {
  auto ReplacementFor_sock = ReplacementFor_create_client_socket(error);
  if (ReplacementFor_sock == INVALID_SOCKET) { return false; }
  socket.ReplacementFor_sock = ReplacementFor_sock;
  return true;
}

void ReplacementFor_ClientImpl::ReplacementFor_shutdown_ssl(Socket &  ,
                                     bool  ) {
  assert(ReplacementFor_socket_requests_in_flight_ == 0 ||
         ReplacementFor_socket_requests_are_from_thread_ == std::this_thread::get_id());
}

void ReplacementFor_ClientImpl::ReplacementFor_shutdown_socket(Socket &socket) {
  if (socket.ReplacementFor_sock == INVALID_SOCKET) { return; }
  ReplacementFor_detail::ReplacementFor_shutdown_socket(socket.ReplacementFor_sock);
}

void ReplacementFor_ClientImpl::ReplacementFor_close_socket(Socket &socket) {
  assert(ReplacementFor_socket_requests_in_flight_ == 0 ||
         ReplacementFor_socket_requests_are_from_thread_ == std::this_thread::get_id());

  
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
  assert(socket.ReplacementFor_ssl == nullptr);
#endif
  if (socket.ReplacementFor_sock == INVALID_SOCKET) { return; }
  ReplacementFor_detail::ReplacementFor_close_socket(socket.ReplacementFor_sock);
  socket.ReplacementFor_sock = INVALID_SOCKET;
}

void ReplacementFor_ClientImpl::ReplacementFor_lock_socket_and_shutdown_and_close() {
  std::lock_guard<std::mutex> ReplacementFor_guard(ReplacementFor_socket_mutex_);
  ReplacementFor_shutdown_ssl(ReplacementFor_socket_, true);
  ReplacementFor_shutdown_socket(ReplacementFor_socket_);
  ReplacementFor_close_socket(ReplacementFor_socket_);
}

bool ReplacementFor_ClientImpl::ReplacementFor_read_response_line(ReplacementFor_Stream &ReplacementFor_strm, const ReplacementFor_Request &ReplacementFor_req,
                                           ReplacementFor_Response &ReplacementFor_res) {
  std::array<char, 2048> buf;

  ReplacementFor_detail::ReplacementFor_stream_line_reader ReplacementFor_line_reader(ReplacementFor_strm, buf.data(), buf.size());

  if (!ReplacementFor_line_reader.getline()) { return false; }

  const static std::regex ReplacementFor_re("(HTTP/1\\.[01]) (\\d{3}) (.*?)\r\n");

  std::cmatch m;
  if (!std::regex_match(ReplacementFor_line_reader.ReplacementFor_ptr(), m, ReplacementFor_re)) {
    return ReplacementFor_req.ReplacementFor_method == "CONNECT";
  }
  ReplacementFor_res.ReplacementFor_version = std::string(m[1]);
  ReplacementFor_res.status = std::stoi(std::string(m[2]));
  ReplacementFor_res.ReplacementFor_reason = std::string(m[3]);

  while (ReplacementFor_res.status == 100) {
    if (!ReplacementFor_line_reader.getline()) { return false; } 
    if (!ReplacementFor_line_reader.getline()) { return false; } 

    if (!std::regex_match(ReplacementFor_line_reader.ReplacementFor_ptr(), m, ReplacementFor_re)) { return false; }
    ReplacementFor_res.ReplacementFor_version = std::string(m[1]);
    ReplacementFor_res.status = std::stoi(std::string(m[2]));
    ReplacementFor_res.ReplacementFor_reason = std::string(m[3]);
  }

  return true;
}

bool ReplacementFor_ClientImpl::send(ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res, Error &error) {
  std::lock_guard<std::recursive_mutex> ReplacementFor_request_mutex_guard(ReplacementFor_request_mutex_);

  {
    std::lock_guard<std::mutex> ReplacementFor_guard(ReplacementFor_socket_mutex_);
    ReplacementFor_socket_should_be_closed_when_request_is_done_ = false;

    auto ReplacementFor_is_alive = false;
    if (ReplacementFor_socket_.is_open()) {
      ReplacementFor_is_alive = ReplacementFor_detail::ReplacementFor_select_write(ReplacementFor_socket_.ReplacementFor_sock, 0, 0) > 0;
      if (!ReplacementFor_is_alive) {
        const bool ReplacementFor_shutdown_gracefully = false;
        ReplacementFor_shutdown_ssl(ReplacementFor_socket_, ReplacementFor_shutdown_gracefully);
        ReplacementFor_shutdown_socket(ReplacementFor_socket_);
        ReplacementFor_close_socket(ReplacementFor_socket_);
      }
    }

    if (!ReplacementFor_is_alive) {
      if (!ReplacementFor_create_and_connect_socket(ReplacementFor_socket_, error)) { return false; }

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
      if (ReplacementFor_is_ssl()) {
        auto &ReplacementFor_scli = static_cast<ReplacementFor_SSLClient &>(*this);
        if (!ReplacementFor_proxy_host_.empty() && ReplacementFor_proxy_port_ != -1) {
          bool ReplacementFor_success = false;
          if (!ReplacementFor_scli.ReplacementFor_connect_with_proxy(ReplacementFor_socket_, ReplacementFor_res, ReplacementFor_success, error)) {
            return ReplacementFor_success;
          }
        }

        if (!ReplacementFor_scli.ReplacementFor_initialize_ssl(ReplacementFor_socket_, error)) { return false; }
      }
#endif
    }

    if (ReplacementFor_socket_requests_in_flight_ > 1) {
      assert(ReplacementFor_socket_requests_are_from_thread_ == std::this_thread::get_id());
    }
    ReplacementFor_socket_requests_in_flight_ += 1;
    ReplacementFor_socket_requests_are_from_thread_ = std::this_thread::get_id();
  }

  for (const auto &header : ReplacementFor_default_headers_) {
    if (ReplacementFor_req.ReplacementFor_headers.find(header.first) == ReplacementFor_req.ReplacementFor_headers.end()) {
      ReplacementFor_req.ReplacementFor_headers.insert(header);
    }
  }

  auto ReplacementFor_close_connection = !ReplacementFor_keep_alive_;
  auto ReplacementFor_ret = ReplacementFor_process_socket(ReplacementFor_socket_, [&](ReplacementFor_Stream &ReplacementFor_strm) {
    return ReplacementFor_handle_request(ReplacementFor_strm, ReplacementFor_req, ReplacementFor_res, ReplacementFor_close_connection, error);
  });

  {
    std::lock_guard<std::mutex> ReplacementFor_guard(ReplacementFor_socket_mutex_);
    ReplacementFor_socket_requests_in_flight_ -= 1;
    if (ReplacementFor_socket_requests_in_flight_ <= 0) {
      assert(ReplacementFor_socket_requests_in_flight_ == 0);
      ReplacementFor_socket_requests_are_from_thread_ = std::thread::id();
    }

    if (ReplacementFor_socket_should_be_closed_when_request_is_done_ || ReplacementFor_close_connection ||
        !ReplacementFor_ret) {
      ReplacementFor_shutdown_ssl(ReplacementFor_socket_, true);
      ReplacementFor_shutdown_socket(ReplacementFor_socket_);
      ReplacementFor_close_socket(ReplacementFor_socket_);
    }
  }

  if (!ReplacementFor_ret) {
    if (error == Error::ReplacementFor_Success) { error = Error::Unknown; }
  }

  return ReplacementFor_ret;
}

Result ReplacementFor_ClientImpl::send(const ReplacementFor_Request &ReplacementFor_req) {
  auto ReplacementFor_req2 = ReplacementFor_req;
  return ReplacementFor_send_(std::move(ReplacementFor_req2));
}

Result ReplacementFor_ClientImpl::ReplacementFor_send_(ReplacementFor_Request &&ReplacementFor_req) {
  auto ReplacementFor_res = ReplacementFor_detail::make_unique<ReplacementFor_Response>();
  auto error = Error::ReplacementFor_Success;
  auto ReplacementFor_ret = send(ReplacementFor_req, *ReplacementFor_res, error);
  return Result{ReplacementFor_ret ? std::move(ReplacementFor_res) : nullptr, error, std::move(ReplacementFor_req.ReplacementFor_headers)};
}

bool ReplacementFor_ClientImpl::ReplacementFor_handle_request(ReplacementFor_Stream &ReplacementFor_strm, ReplacementFor_Request &ReplacementFor_req,
                                       ReplacementFor_Response &ReplacementFor_res, bool ReplacementFor_close_connection,
                                       Error &error) {
  if (ReplacementFor_req.ReplacementFor_path.empty()) {
    error = Error::ReplacementFor_Connection;
    return false;
  }

  auto ReplacementFor_req_save = ReplacementFor_req;

  bool ReplacementFor_ret;

  if (!ReplacementFor_is_ssl() && !ReplacementFor_proxy_host_.empty() && ReplacementFor_proxy_port_ != -1) {
    auto ReplacementFor_req2 = ReplacementFor_req;
    ReplacementFor_req2.ReplacementFor_path = "http://" + ReplacementFor_host_and_port_ + ReplacementFor_req.ReplacementFor_path;
    ReplacementFor_ret = ReplacementFor_process_request(ReplacementFor_strm, ReplacementFor_req2, ReplacementFor_res, ReplacementFor_close_connection, error);
    ReplacementFor_req = ReplacementFor_req2;
    ReplacementFor_req.ReplacementFor_path = ReplacementFor_req_save.ReplacementFor_path;
  } else {
    ReplacementFor_ret = ReplacementFor_process_request(ReplacementFor_strm, ReplacementFor_req, ReplacementFor_res, ReplacementFor_close_connection, error);
  }

  if (!ReplacementFor_ret) { return false; }

  if (300 < ReplacementFor_res.status && ReplacementFor_res.status < 400 && ReplacementFor_follow_location_) {
    ReplacementFor_req = ReplacementFor_req_save;
    ReplacementFor_ret = ReplacementFor_redirect(ReplacementFor_req, ReplacementFor_res, error);
  }

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
  if ((ReplacementFor_res.status == 401 || ReplacementFor_res.status == 407) &&
      ReplacementFor_req.ReplacementFor_authorization_count_ < 5) {
    auto ReplacementFor_is_proxy = ReplacementFor_res.status == 407;
    const auto &ReplacementFor_username =
        ReplacementFor_is_proxy ? ReplacementFor_proxy_digest_auth_username_ : ReplacementFor_digest_auth_username_;
    const auto &ReplacementFor_password =
        ReplacementFor_is_proxy ? ReplacementFor_proxy_digest_auth_password_ : ReplacementFor_digest_auth_password_;

    if (!ReplacementFor_username.empty() && !ReplacementFor_password.empty()) {
      std::map<std::string, std::string> ReplacementFor_auth;
      if (ReplacementFor_detail::ReplacementFor_parse_www_authenticate(ReplacementFor_res, ReplacementFor_auth, ReplacementFor_is_proxy)) {
        ReplacementFor_Request ReplacementFor_new_req = ReplacementFor_req;
        ReplacementFor_new_req.ReplacementFor_authorization_count_ += 1;
        auto key = ReplacementFor_is_proxy ? "Proxy-Authorization" : "Authorization";
        ReplacementFor_new_req.ReplacementFor_headers.erase(key);
        ReplacementFor_new_req.ReplacementFor_headers.insert(ReplacementFor_detail::ReplacementFor_make_digest_authentication_header(
            ReplacementFor_req, ReplacementFor_auth, ReplacementFor_new_req.ReplacementFor_authorization_count_, ReplacementFor_detail::ReplacementFor_random_string(10),
            ReplacementFor_username, ReplacementFor_password, ReplacementFor_is_proxy));

        ReplacementFor_Response ReplacementFor_new_res;

        ReplacementFor_ret = send(ReplacementFor_new_req, ReplacementFor_new_res, error);
        if (ReplacementFor_ret) { ReplacementFor_res = ReplacementFor_new_res; }
      }
    }
  }
#endif

  return ReplacementFor_ret;
}

bool ReplacementFor_ClientImpl::ReplacementFor_redirect(ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res, Error &error) {
  if (ReplacementFor_req.ReplacementFor_redirect_count_ == 0) {
    error = Error::ReplacementFor_ExceedRedirectCount;
    return false;
  }

  auto ReplacementFor_location = ReplacementFor_detail::ReplacementFor_decode_url(ReplacementFor_res.ReplacementFor_get_header_value("location"), true);
  if (ReplacementFor_location.empty()) { return false; }

  const static std::regex ReplacementFor_re(
      R"(^(?:(https?):)?(?://([^:/?#]*)(?::(\d+))?)?([^?#]*(?:\?[^#]*)?)(?:#.*)?)");

  std::smatch m;
  if (!std::regex_match(ReplacementFor_location, m, ReplacementFor_re)) { return false; }

  auto ReplacementFor_scheme = ReplacementFor_is_ssl() ? "https" : "http";

  auto ReplacementFor_next_scheme = m[1].str();
  auto ReplacementFor_next_host = m[2].str();
  auto ReplacementFor_port_str = m[3].str();
  auto ReplacementFor_next_path = m[4].str();

  auto ReplacementFor_next_port = ReplacementFor_port_;
  if (!ReplacementFor_port_str.empty()) {
    ReplacementFor_next_port = std::stoi(ReplacementFor_port_str);
  } else if (!ReplacementFor_next_scheme.empty()) {
    ReplacementFor_next_port = ReplacementFor_next_scheme == "https" ? 443 : 80;
  }

  if (ReplacementFor_next_scheme.empty()) { ReplacementFor_next_scheme = ReplacementFor_scheme; }
  if (ReplacementFor_next_host.empty()) { ReplacementFor_next_host = ReplacementFor_host_; }
  if (ReplacementFor_next_path.empty()) { ReplacementFor_next_path = "/"; }

  if (ReplacementFor_next_scheme == ReplacementFor_scheme && ReplacementFor_next_host == ReplacementFor_host_ && ReplacementFor_next_port == ReplacementFor_port_) {
    return ReplacementFor_detail::ReplacementFor_redirect(*this, ReplacementFor_req, ReplacementFor_res, ReplacementFor_next_path, ReplacementFor_location, error);
  } else {
    if (ReplacementFor_next_scheme == "https") {
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
      ReplacementFor_SSLClient ReplacementFor_cli(ReplacementFor_next_host.c_str(), ReplacementFor_next_port);
      ReplacementFor_cli.ReplacementFor_copy_settings(*this);
      return ReplacementFor_detail::ReplacementFor_redirect(ReplacementFor_cli, ReplacementFor_req, ReplacementFor_res, ReplacementFor_next_path, ReplacementFor_location, error);
#else
      return false;
#endif
    } else {
      ReplacementFor_ClientImpl ReplacementFor_cli(ReplacementFor_next_host.c_str(), ReplacementFor_next_port);
      ReplacementFor_cli.ReplacementFor_copy_settings(*this);
      return ReplacementFor_detail::ReplacementFor_redirect(ReplacementFor_cli, ReplacementFor_req, ReplacementFor_res, ReplacementFor_next_path, ReplacementFor_location, error);
    }
  }
}

bool ReplacementFor_ClientImpl::ReplacementFor_write_content_with_provider(ReplacementFor_Stream &ReplacementFor_strm,
                                                    const ReplacementFor_Request &ReplacementFor_req,
                                                    Error &error) {
  auto ReplacementFor_is_shutting_down = []() { return false; };

  if (ReplacementFor_req.ReplacementFor_is_chunked_content_provider_) {
    std::unique_ptr<ReplacementFor_detail::ReplacementFor_compressor> ReplacementFor_compressor;
#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
    if (ReplacementFor_compress_) {
      ReplacementFor_compressor = ReplacementFor_detail::make_unique<ReplacementFor_detail::ReplacementFor_gzip_compressor>();
    } else
#endif
    {
      ReplacementFor_compressor = ReplacementFor_detail::make_unique<ReplacementFor_detail::ReplacementFor_nocompressor>();
    }

    return ReplacementFor_detail::ReplacementFor_write_content_chunked(ReplacementFor_strm, ReplacementFor_req.ReplacementFor_content_provider_,
                                         ReplacementFor_is_shutting_down, *ReplacementFor_compressor, error);
  } else {
    return ReplacementFor_detail::ReplacementFor_write_content(ReplacementFor_strm, ReplacementFor_req.ReplacementFor_content_provider_, 0,
                                 ReplacementFor_req.ReplacementFor_content_length_, ReplacementFor_is_shutting_down, error);
  }
} 

bool ReplacementFor_ClientImpl::ReplacementFor_write_request(ReplacementFor_Stream &ReplacementFor_strm, ReplacementFor_Request &ReplacementFor_req,
                                      bool ReplacementFor_close_connection, Error &error) {
  if (ReplacementFor_close_connection) { ReplacementFor_req.ReplacementFor_headers.emplace("Connection", "close"); }

  if (!ReplacementFor_req.ReplacementFor_has_header("Host")) {
    if (ReplacementFor_is_ssl()) {
      if (ReplacementFor_port_ == 443) {
        ReplacementFor_req.ReplacementFor_headers.emplace("Host", ReplacementFor_host_);
      } else {
        ReplacementFor_req.ReplacementFor_headers.emplace("Host", ReplacementFor_host_and_port_);
      }
    } else {
      if (ReplacementFor_port_ == 80) {
        ReplacementFor_req.ReplacementFor_headers.emplace("Host", ReplacementFor_host_);
      } else {
        ReplacementFor_req.ReplacementFor_headers.emplace("Host", ReplacementFor_host_and_port_);
      }
    }
  }

  if (!ReplacementFor_req.ReplacementFor_has_header("Accept")) { ReplacementFor_req.ReplacementFor_headers.emplace("Accept", "*/*"); }

  if (!ReplacementFor_req.ReplacementFor_has_header("User-Agent")) {
    ReplacementFor_req.ReplacementFor_headers.emplace("User-Agent", "cpp-httplib/0.7");
  }

  if (ReplacementFor_req.ReplacementFor_body.empty()) {
    if (ReplacementFor_req.ReplacementFor_content_provider_) {
      if (!ReplacementFor_req.ReplacementFor_is_chunked_content_provider_) {
        auto length = std::to_string(ReplacementFor_req.ReplacementFor_content_length_);
        ReplacementFor_req.ReplacementFor_headers.emplace("Content-Length", length);
      }
    } else {
      if (ReplacementFor_req.ReplacementFor_method == "POST" || ReplacementFor_req.ReplacementFor_method == "PUT" ||
          ReplacementFor_req.ReplacementFor_method == "PATCH") {
        ReplacementFor_req.ReplacementFor_headers.emplace("Content-Length", "0");
      }
    }
  } else {
    if (!ReplacementFor_req.ReplacementFor_has_header("Content-Type")) {
      ReplacementFor_req.ReplacementFor_headers.emplace("Content-Type", "text/plain");
    }

    if (!ReplacementFor_req.ReplacementFor_has_header("Content-Length")) {
      auto length = std::to_string(ReplacementFor_req.ReplacementFor_body.size());
      ReplacementFor_req.ReplacementFor_headers.emplace("Content-Length", length);
    }
  }

  if (!ReplacementFor_basic_auth_password_.empty()) {
    ReplacementFor_req.ReplacementFor_headers.insert(ReplacementFor_make_basic_authentication_header(
        ReplacementFor_basic_auth_username_, ReplacementFor_basic_auth_password_, false));
  }

  if (!ReplacementFor_proxy_basic_auth_username_.empty() &&
      !ReplacementFor_proxy_basic_auth_password_.empty()) {
    ReplacementFor_req.ReplacementFor_headers.insert(ReplacementFor_make_basic_authentication_header(
        ReplacementFor_proxy_basic_auth_username_, ReplacementFor_proxy_basic_auth_password_, true));
  }

  if (!ReplacementFor_bearer_token_auth_token_.empty()) {
    ReplacementFor_req.ReplacementFor_headers.insert(ReplacementFor_make_bearer_token_authentication_header(
        ReplacementFor_bearer_token_auth_token_, false));
  }

  if (!ReplacementFor_proxy_bearer_token_auth_token_.empty()) {
    ReplacementFor_req.ReplacementFor_headers.insert(ReplacementFor_make_bearer_token_authentication_header(
        ReplacementFor_proxy_bearer_token_auth_token_, true));
  }

  {
    ReplacementFor_detail::ReplacementFor_BufferStream ReplacementFor_bstrm;

    const auto &ReplacementFor_path = ReplacementFor_detail::ReplacementFor_encode_url(ReplacementFor_req.ReplacementFor_path);
    ReplacementFor_bstrm.ReplacementFor_write_format("%s %s HTTP/1.1\r\n", ReplacementFor_req.ReplacementFor_method.c_str(), ReplacementFor_path.c_str());

    ReplacementFor_detail::ReplacementFor_write_headers(ReplacementFor_bstrm, ReplacementFor_req.ReplacementFor_headers);

    
    auto &data = ReplacementFor_bstrm.ReplacementFor_get_buffer();
    if (!ReplacementFor_detail::ReplacementFor_write_data(ReplacementFor_strm, data.data(), data.size())) {
      error = Error::Write;
      return false;
    }
  }

  
  if (ReplacementFor_req.ReplacementFor_body.empty()) {
    return ReplacementFor_write_content_with_provider(ReplacementFor_strm, ReplacementFor_req, error);
  } else {
    return ReplacementFor_detail::ReplacementFor_write_data(ReplacementFor_strm, ReplacementFor_req.ReplacementFor_body.data(), ReplacementFor_req.ReplacementFor_body.size());
  }

  return true;
}

std::unique_ptr<ReplacementFor_Response> ReplacementFor_ClientImpl::ReplacementFor_send_with_content_provider(
    ReplacementFor_Request &ReplacementFor_req,
    
    const char *ReplacementFor_body, size_t ReplacementFor_content_length, ReplacementFor_ContentProvider ReplacementFor_content_provider,
    ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider_without_length,
    const char *ReplacementFor_content_type, Error &error) {

  
  
  
  

  if (ReplacementFor_content_type) { ReplacementFor_req.ReplacementFor_headers.emplace("Content-Type", ReplacementFor_content_type); }

#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
  if (ReplacementFor_compress_) { ReplacementFor_req.ReplacementFor_headers.emplace("Content-Encoding", "gzip"); }
#endif

#ifdef ReplacementFor_CPPHTTPLIB_ZLIB_SUPPORT
  if (ReplacementFor_compress_ && !ReplacementFor_content_provider_without_length) {
    
    ReplacementFor_detail::ReplacementFor_gzip_compressor ReplacementFor_compressor;

    if (ReplacementFor_content_provider) {
      auto ok = true;
      size_t offset = 0;
      ReplacementFor_DataSink ReplacementFor_data_sink;

      ReplacementFor_data_sink.write = [&](const char *data, size_t ReplacementFor_data_len) {
        if (ok) {
          auto ReplacementFor_last = offset + ReplacementFor_data_len == ReplacementFor_content_length;

          auto ReplacementFor_ret = ReplacementFor_compressor.compress(
              data, ReplacementFor_data_len, ReplacementFor_last, [&](const char *data, size_t ReplacementFor_data_len) {
                ReplacementFor_req.ReplacementFor_body.append(data, ReplacementFor_data_len);
                return true;
              });

          if (ReplacementFor_ret) {
            offset += ReplacementFor_data_len;
          } else {
            ok = false;
          }
        }
      };

      ReplacementFor_data_sink.ReplacementFor_is_writable = [&](void) { return ok && true; };

      while (ok && offset < ReplacementFor_content_length) {
        if (!ReplacementFor_content_provider(offset, ReplacementFor_content_length - offset, ReplacementFor_data_sink)) {
          error = Error::ReplacementFor_Canceled;
          return nullptr;
        }
      }
    } else {
      if (!ReplacementFor_compressor.compress(ReplacementFor_body, ReplacementFor_content_length, true,
                               [&](const char *data, size_t ReplacementFor_data_len) {
                                 ReplacementFor_req.ReplacementFor_body.append(data, ReplacementFor_data_len);
                                 return true;
                               })) {
        error = Error::Compression;
        return nullptr;
      }
    }
  } else
#endif
  {
    if (ReplacementFor_content_provider) {
      ReplacementFor_req.ReplacementFor_content_length_ = ReplacementFor_content_length;
      ReplacementFor_req.ReplacementFor_content_provider_ = std::move(ReplacementFor_content_provider);
      ReplacementFor_req.ReplacementFor_is_chunked_content_provider_ = false;
    } else if (ReplacementFor_content_provider_without_length) {
      ReplacementFor_req.ReplacementFor_content_length_ = 0;
      ReplacementFor_req.ReplacementFor_content_provider_ = ReplacementFor_detail::ReplacementFor_ContentProviderAdapter(
          std::move(ReplacementFor_content_provider_without_length));
      ReplacementFor_req.ReplacementFor_is_chunked_content_provider_ = true;
      ReplacementFor_req.ReplacementFor_headers.emplace("Transfer-Encoding", "chunked");
    } else {
      ReplacementFor_req.ReplacementFor_body.assign(ReplacementFor_body, ReplacementFor_content_length);
      ;
    }
  }

  auto ReplacementFor_res = ReplacementFor_detail::make_unique<ReplacementFor_Response>();
  return send(ReplacementFor_req, *ReplacementFor_res, error) ? std::move(ReplacementFor_res) : nullptr;
}

Result ReplacementFor_ClientImpl::ReplacementFor_send_with_content_provider(
    const char *ReplacementFor_method, const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
    const char *ReplacementFor_body, size_t ReplacementFor_content_length, ReplacementFor_ContentProvider ReplacementFor_content_provider,
    ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider_without_length,
    const char *ReplacementFor_content_type) {
  ReplacementFor_Request ReplacementFor_req;
  ReplacementFor_req.ReplacementFor_method = ReplacementFor_method;
  ReplacementFor_req.ReplacementFor_headers = ReplacementFor_headers;
  ReplacementFor_req.ReplacementFor_path = ReplacementFor_path;

  auto error = Error::ReplacementFor_Success;

  auto ReplacementFor_res = ReplacementFor_send_with_content_provider(
      ReplacementFor_req,
      ReplacementFor_body, ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
      std::move(ReplacementFor_content_provider_without_length), ReplacementFor_content_type, error);

  return Result{std::move(ReplacementFor_res), error, std::move(ReplacementFor_req.ReplacementFor_headers)};
}

bool ReplacementFor_ClientImpl::ReplacementFor_process_request(ReplacementFor_Stream &ReplacementFor_strm, ReplacementFor_Request &ReplacementFor_req,
                                        ReplacementFor_Response &ReplacementFor_res, bool ReplacementFor_close_connection,
                                        Error &error) {
  if (!ReplacementFor_write_request(ReplacementFor_strm, ReplacementFor_req, ReplacementFor_close_connection, error)) { return false; }

  if (!ReplacementFor_read_response_line(ReplacementFor_strm, ReplacementFor_req, ReplacementFor_res) ||
      !ReplacementFor_detail::ReplacementFor_read_headers(ReplacementFor_strm, ReplacementFor_res.ReplacementFor_headers)) {
    error = Error::Read;
    return false;
  }

  if (ReplacementFor_req.ReplacementFor_response_handler) {
    if (!ReplacementFor_req.ReplacementFor_response_handler(ReplacementFor_res)) {
      error = Error::ReplacementFor_Canceled;
      return false;
    }
  }

  
  if ((ReplacementFor_res.status != 204) && ReplacementFor_req.ReplacementFor_method != "HEAD" && ReplacementFor_req.ReplacementFor_method != "CONNECT") {
    auto out =
        ReplacementFor_req.ReplacementFor_content_receiver
            ? static_cast<ReplacementFor_ContentReceiverWithProgress>(
                  [&](const char *buf, size_t n, uint64_t ReplacementFor_off, uint64_t len) {
                    auto ReplacementFor_ret = ReplacementFor_req.ReplacementFor_content_receiver(buf, n, ReplacementFor_off, len);
                    if (!ReplacementFor_ret) { error = Error::ReplacementFor_Canceled; }
                    return ReplacementFor_ret;
                  })
            : static_cast<ReplacementFor_ContentReceiverWithProgress>(
                  [&](const char *buf, size_t n, uint64_t  ,
                      uint64_t  ) {
                    if (ReplacementFor_res.ReplacementFor_body.size() + n > ReplacementFor_res.ReplacementFor_body.max_size()) {
                      return false;
                    }
                    ReplacementFor_res.ReplacementFor_body.append(buf, n);
                    return true;
                  });

    auto ReplacementFor_progress = [&](uint64_t current, uint64_t ReplacementFor_total) {
      if (!ReplacementFor_req.ReplacementFor_progress) { return true; }
      auto ReplacementFor_ret = ReplacementFor_req.ReplacementFor_progress(current, ReplacementFor_total);
      if (!ReplacementFor_ret) { error = Error::ReplacementFor_Canceled; }
      return ReplacementFor_ret;
    };

    int ReplacementFor_dummy_status;
    if (!ReplacementFor_detail::ReplacementFor_read_content(ReplacementFor_strm, ReplacementFor_res, (std::numeric_limits<size_t>::max)(),
                              ReplacementFor_dummy_status, std::move(ReplacementFor_progress), std::move(out),
                              ReplacementFor_decompress_)) {
      if (error != Error::ReplacementFor_Canceled) { error = Error::Read; }
      return false;
    }
  }

  if (ReplacementFor_res.ReplacementFor_get_header_value("Connection") == "close" ||
      (ReplacementFor_res.ReplacementFor_version == "HTTP/1.0" && ReplacementFor_res.ReplacementFor_reason != "Connection established")) {
    ReplacementFor_lock_socket_and_shutdown_and_close();
  }

  if (ReplacementFor_logger_) { ReplacementFor_logger_(ReplacementFor_req, ReplacementFor_res); }

  return true;
}

bool
ReplacementFor_ClientImpl::ReplacementFor_process_socket(const Socket &socket,
                           std::function<bool(ReplacementFor_Stream &ReplacementFor_strm)> ReplacementFor_callback) {
  return ReplacementFor_detail::ReplacementFor_process_client_socket(
      socket.ReplacementFor_sock, ReplacementFor_read_timeout_sec_, ReplacementFor_read_timeout_usec_, ReplacementFor_write_timeout_sec_,
      ReplacementFor_write_timeout_usec_, std::move(ReplacementFor_callback));
}

bool ReplacementFor_ClientImpl::ReplacementFor_is_ssl() const { return false; }

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path) {
  return Get(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_Progress());
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path, ReplacementFor_Progress ReplacementFor_progress) {
  return Get(ReplacementFor_path, ReplacementFor_Headers(), std::move(ReplacementFor_progress));
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers) {
  return Get(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_Progress());
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                              ReplacementFor_Progress ReplacementFor_progress) {
  ReplacementFor_Request ReplacementFor_req;
  ReplacementFor_req.ReplacementFor_method = "GET";
  ReplacementFor_req.ReplacementFor_path = ReplacementFor_path;
  ReplacementFor_req.ReplacementFor_headers = ReplacementFor_headers;
  ReplacementFor_req.ReplacementFor_progress = std::move(ReplacementFor_progress);

  return ReplacementFor_send_(std::move(ReplacementFor_req));
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path,
                              ReplacementFor_ContentReceiver ReplacementFor_content_receiver) {
  return Get(ReplacementFor_path, ReplacementFor_Headers(), nullptr, std::move(ReplacementFor_content_receiver), nullptr);
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path,
                              ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
                              ReplacementFor_Progress ReplacementFor_progress) {
  return Get(ReplacementFor_path, ReplacementFor_Headers(), nullptr, std::move(ReplacementFor_content_receiver),
             std::move(ReplacementFor_progress));
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                              ReplacementFor_ContentReceiver ReplacementFor_content_receiver) {
  return Get(ReplacementFor_path, ReplacementFor_headers, nullptr, std::move(ReplacementFor_content_receiver), nullptr);
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                              ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
                              ReplacementFor_Progress ReplacementFor_progress) {
  return Get(ReplacementFor_path, ReplacementFor_headers, nullptr, std::move(ReplacementFor_content_receiver),
             std::move(ReplacementFor_progress));
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path,
                              ReplacementFor_ResponseHandler ReplacementFor_response_handler,
                              ReplacementFor_ContentReceiver ReplacementFor_content_receiver) {
  return Get(ReplacementFor_path, ReplacementFor_Headers(), std::move(ReplacementFor_response_handler),
             std::move(ReplacementFor_content_receiver), nullptr);
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                              ReplacementFor_ResponseHandler ReplacementFor_response_handler,
                              ReplacementFor_ContentReceiver ReplacementFor_content_receiver) {
  return Get(ReplacementFor_path, ReplacementFor_headers, std::move(ReplacementFor_response_handler),
             std::move(ReplacementFor_content_receiver), nullptr);
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path,
                              ReplacementFor_ResponseHandler ReplacementFor_response_handler,
                              ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
                              ReplacementFor_Progress ReplacementFor_progress) {
  return Get(ReplacementFor_path, ReplacementFor_Headers(), std::move(ReplacementFor_response_handler),
             std::move(ReplacementFor_content_receiver), std::move(ReplacementFor_progress));
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                              ReplacementFor_ResponseHandler ReplacementFor_response_handler,
                              ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
                              ReplacementFor_Progress ReplacementFor_progress) {
  ReplacementFor_Request ReplacementFor_req;
  ReplacementFor_req.ReplacementFor_method = "GET";
  ReplacementFor_req.ReplacementFor_path = ReplacementFor_path;
  ReplacementFor_req.ReplacementFor_headers = ReplacementFor_headers;
  ReplacementFor_req.ReplacementFor_response_handler = std::move(ReplacementFor_response_handler);
  ReplacementFor_req.ReplacementFor_content_receiver =
      [ReplacementFor_content_receiver](const char *data, size_t ReplacementFor_data_length,
                         uint64_t  , uint64_t  ) {
        return ReplacementFor_content_receiver(data, ReplacementFor_data_length);
      };
  ReplacementFor_req.ReplacementFor_progress = std::move(ReplacementFor_progress);

  return ReplacementFor_send_(std::move(ReplacementFor_req));
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path, const ReplacementFor_Params &ReplacementFor_params,
                              const ReplacementFor_Headers &ReplacementFor_headers, ReplacementFor_Progress ReplacementFor_progress) {
  if (ReplacementFor_params.empty()) { return Get(ReplacementFor_path, ReplacementFor_headers); }

  std::string ReplacementFor_path_with_query = ReplacementFor_detail::ReplacementFor_append_query_params(ReplacementFor_path, ReplacementFor_params);
  return Get(ReplacementFor_path_with_query.c_str(), ReplacementFor_headers, ReplacementFor_progress);
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path, const ReplacementFor_Params &ReplacementFor_params,
                              const ReplacementFor_Headers &ReplacementFor_headers,
                              ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
                              ReplacementFor_Progress ReplacementFor_progress) {
  return Get(ReplacementFor_path, ReplacementFor_params, ReplacementFor_headers, nullptr, ReplacementFor_content_receiver, ReplacementFor_progress);
}

Result ReplacementFor_ClientImpl::Get(const char *ReplacementFor_path, const ReplacementFor_Params &ReplacementFor_params,
                              const ReplacementFor_Headers &ReplacementFor_headers,
                              ReplacementFor_ResponseHandler ReplacementFor_response_handler,
                              ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
                              ReplacementFor_Progress ReplacementFor_progress) {
  if (ReplacementFor_params.empty()) {
    return Get(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_response_handler, ReplacementFor_content_receiver, ReplacementFor_progress);
  }

  std::string ReplacementFor_path_with_query = ReplacementFor_detail::ReplacementFor_append_query_params(ReplacementFor_path, ReplacementFor_params);
  return Get(ReplacementFor_path_with_query.c_str(), ReplacementFor_params, ReplacementFor_headers, ReplacementFor_response_handler,
             ReplacementFor_content_receiver, ReplacementFor_progress);
}

Result ReplacementFor_ClientImpl::Head(const char *ReplacementFor_path) {
  return Head(ReplacementFor_path, ReplacementFor_Headers());
}

Result ReplacementFor_ClientImpl::Head(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers) {
  ReplacementFor_Request ReplacementFor_req;
  ReplacementFor_req.ReplacementFor_method = "HEAD";
  ReplacementFor_req.ReplacementFor_headers = ReplacementFor_headers;
  ReplacementFor_req.ReplacementFor_path = ReplacementFor_path;

  return ReplacementFor_send_(std::move(ReplacementFor_req));
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path) {
  return ReplacementFor_Post(ReplacementFor_path, std::string(), nullptr);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path, const char *ReplacementFor_body,
                               size_t ReplacementFor_content_length,
                               const char *ReplacementFor_content_type) {
  return ReplacementFor_Post(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                               const char *ReplacementFor_body, size_t ReplacementFor_content_length,
                               const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("POST", ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body, ReplacementFor_content_length,
                                    nullptr, nullptr, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path, const std::string &ReplacementFor_body,
                               const char *ReplacementFor_content_type) {
  return ReplacementFor_Post(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_body, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                               const std::string &ReplacementFor_body,
                               const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("POST", ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body.data(),
                                    ReplacementFor_body.size(), nullptr, nullptr,
                                    ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Params &ReplacementFor_params) {
  return ReplacementFor_Post(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_params);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path, size_t ReplacementFor_content_length,
                               ReplacementFor_ContentProvider ReplacementFor_content_provider,
                               const char *ReplacementFor_content_type) {
  return ReplacementFor_Post(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
              ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path,
                               ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                               const char *ReplacementFor_content_type) {
  return ReplacementFor_Post(ReplacementFor_path, ReplacementFor_Headers(), std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                               size_t ReplacementFor_content_length,
                               ReplacementFor_ContentProvider ReplacementFor_content_provider,
                               const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("POST", ReplacementFor_path, ReplacementFor_headers, nullptr,
                                    ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
                                    nullptr, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                               ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                               const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("POST", ReplacementFor_path, ReplacementFor_headers, nullptr, 0, nullptr,
                                    std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                               const ReplacementFor_Params &ReplacementFor_params) {
  auto ReplacementFor_query = ReplacementFor_detail::ReplacementFor_params_to_query_str(ReplacementFor_params);
  return ReplacementFor_Post(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_query, "application/x-www-form-urlencoded");
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path,
                               const ReplacementFor_MultipartFormDataItems &ReplacementFor_items) {
  return ReplacementFor_Post(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_items);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                               const ReplacementFor_MultipartFormDataItems &ReplacementFor_items) {
  return ReplacementFor_Post(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_items, ReplacementFor_detail::ReplacementFor_make_multipart_data_boundary());
}
Result ReplacementFor_ClientImpl::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                               const ReplacementFor_MultipartFormDataItems &ReplacementFor_items,
                               const std::string &ReplacementFor_boundary) {
  for (size_t i = 0; i < ReplacementFor_boundary.size(); i++) {
    char c = ReplacementFor_boundary[i];
    if (!std::isalnum(c) && c != ((char)(0x229c+944-0x261f)) && c != ((char)(0xda+7075-0x1c1e))) {
      return Result{nullptr, Error::ReplacementFor_UnsupportedMultipartBoundaryChars};
    }
  }

  std::string ReplacementFor_body;

  for (const auto &item : ReplacementFor_items) {
    ReplacementFor_body += "--" + ReplacementFor_boundary + "\r\n";
    ReplacementFor_body += "Content-Disposition: form-data; name=\"" + item.name + "\"";
    if (!item.ReplacementFor_filename.empty()) {
      ReplacementFor_body += "; filename=\"" + item.ReplacementFor_filename + "\"";
    }
    ReplacementFor_body += "\r\n";
    if (!item.ReplacementFor_content_type.empty()) {
      ReplacementFor_body += "Content-Type: " + item.ReplacementFor_content_type + "\r\n";
    }
    ReplacementFor_body += "\r\n";
    ReplacementFor_body += item.ReplacementFor_content + "\r\n";
  }

  ReplacementFor_body += "--" + ReplacementFor_boundary + "--\r\n";

  std::string ReplacementFor_content_type = "multipart/form-data; boundary=" + ReplacementFor_boundary;
  return ReplacementFor_Post(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body, ReplacementFor_content_type.c_str());
}

Result ReplacementFor_ClientImpl::Put(const char *ReplacementFor_path) {
  return Put(ReplacementFor_path, std::string(), nullptr);
}

Result ReplacementFor_ClientImpl::Put(const char *ReplacementFor_path, const char *ReplacementFor_body,
                              size_t ReplacementFor_content_length, const char *ReplacementFor_content_type) {
  return Put(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Put(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                              const char *ReplacementFor_body, size_t ReplacementFor_content_length,
                              const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("PUT", ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body, ReplacementFor_content_length,
                                    nullptr, nullptr, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Put(const char *ReplacementFor_path, const std::string &ReplacementFor_body,
                              const char *ReplacementFor_content_type) {
  return Put(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_body, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Put(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                              const std::string &ReplacementFor_body,
                              const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("PUT", ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body.data(),
                                    ReplacementFor_body.size(), nullptr, nullptr,
                                    ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Put(const char *ReplacementFor_path, size_t ReplacementFor_content_length,
                              ReplacementFor_ContentProvider ReplacementFor_content_provider,
                              const char *ReplacementFor_content_type) {
  return Put(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
             ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Put(const char *ReplacementFor_path,
                              ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                              const char *ReplacementFor_content_type) {
  return Put(ReplacementFor_path, ReplacementFor_Headers(), std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Put(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                              size_t ReplacementFor_content_length,
                              ReplacementFor_ContentProvider ReplacementFor_content_provider,
                              const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("PUT", ReplacementFor_path, ReplacementFor_headers, nullptr,
                                    ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
                                    nullptr, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Put(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                              ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                              const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("PUT", ReplacementFor_path, ReplacementFor_headers, nullptr, 0, nullptr,
                                    std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Put(const char *ReplacementFor_path, const ReplacementFor_Params &ReplacementFor_params) {
  return Put(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_params);
}

Result ReplacementFor_ClientImpl::Put(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                              const ReplacementFor_Params &ReplacementFor_params) {
  auto ReplacementFor_query = ReplacementFor_detail::ReplacementFor_params_to_query_str(ReplacementFor_params);
  return Put(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_query, "application/x-www-form-urlencoded");
}

Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char *ReplacementFor_path) {
  return ReplacementFor_Patch(ReplacementFor_path, std::string(), nullptr);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char *ReplacementFor_path, const char *ReplacementFor_body,
                                size_t ReplacementFor_content_length,
                                const char *ReplacementFor_content_type) {
  return ReplacementFor_Patch(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                                const char *ReplacementFor_body, size_t ReplacementFor_content_length,
                                const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("PATCH", ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body,
                                    ReplacementFor_content_length, nullptr, nullptr,
                                    ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char *ReplacementFor_path, const std::string &ReplacementFor_body,
                                const char *ReplacementFor_content_type) {
  return ReplacementFor_Patch(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_body, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                                const std::string &ReplacementFor_body,
                                const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("PATCH", ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body.data(),
                                    ReplacementFor_body.size(), nullptr, nullptr,
                                    ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char *ReplacementFor_path, size_t ReplacementFor_content_length,
                                ReplacementFor_ContentProvider ReplacementFor_content_provider,
                                const char *ReplacementFor_content_type) {
  return ReplacementFor_Patch(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
               ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char *ReplacementFor_path,
                                ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                                const char *ReplacementFor_content_type) {
  return ReplacementFor_Patch(ReplacementFor_path, ReplacementFor_Headers(), std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                                size_t ReplacementFor_content_length,
                                ReplacementFor_ContentProvider ReplacementFor_content_provider,
                                const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("PATCH", ReplacementFor_path, ReplacementFor_headers, nullptr,
                                    ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
                                    nullptr, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::ReplacementFor_Patch(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                                ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                                const char *ReplacementFor_content_type) {
  return ReplacementFor_send_with_content_provider("PATCH", ReplacementFor_path, ReplacementFor_headers, nullptr, 0, nullptr,
                                    std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Delete(const char *ReplacementFor_path) {
  return Delete(ReplacementFor_path, ReplacementFor_Headers(), std::string(), nullptr);
}

Result ReplacementFor_ClientImpl::Delete(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers) {
  return Delete(ReplacementFor_path, ReplacementFor_headers, std::string(), nullptr);
}

Result ReplacementFor_ClientImpl::Delete(const char *ReplacementFor_path, const char *ReplacementFor_body,
                                 size_t ReplacementFor_content_length,
                                 const char *ReplacementFor_content_type) {
  return Delete(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Delete(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                                 const char *ReplacementFor_body, size_t ReplacementFor_content_length,
                                 const char *ReplacementFor_content_type) {
  ReplacementFor_Request ReplacementFor_req;
  ReplacementFor_req.ReplacementFor_method = "DELETE";
  ReplacementFor_req.ReplacementFor_headers = ReplacementFor_headers;
  ReplacementFor_req.ReplacementFor_path = ReplacementFor_path;

  if (ReplacementFor_content_type) { ReplacementFor_req.ReplacementFor_headers.emplace("Content-Type", ReplacementFor_content_type); }
  ReplacementFor_req.ReplacementFor_body.assign(ReplacementFor_body, ReplacementFor_content_length);

  return ReplacementFor_send_(std::move(ReplacementFor_req));
}

Result ReplacementFor_ClientImpl::Delete(const char *ReplacementFor_path, const std::string &ReplacementFor_body,
                                 const char *ReplacementFor_content_type) {
  return Delete(ReplacementFor_path, ReplacementFor_Headers(), ReplacementFor_body.data(), ReplacementFor_body.size(), ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Delete(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                                 const std::string &ReplacementFor_body,
                                 const char *ReplacementFor_content_type) {
  return Delete(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body.data(), ReplacementFor_body.size(), ReplacementFor_content_type);
}

Result ReplacementFor_ClientImpl::Options(const char *ReplacementFor_path) {
  return Options(ReplacementFor_path, ReplacementFor_Headers());
}

Result ReplacementFor_ClientImpl::Options(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers) {
  ReplacementFor_Request ReplacementFor_req;
  ReplacementFor_req.ReplacementFor_method = "OPTIONS";
  ReplacementFor_req.ReplacementFor_headers = ReplacementFor_headers;
  ReplacementFor_req.ReplacementFor_path = ReplacementFor_path;

  return ReplacementFor_send_(std::move(ReplacementFor_req));
}

size_t ReplacementFor_ClientImpl::ReplacementFor_is_socket_open() const {
  std::lock_guard<std::mutex> ReplacementFor_guard(ReplacementFor_socket_mutex_);
  return ReplacementFor_socket_.is_open();
}

void ReplacementFor_ClientImpl::ReplacementFor_stop() {
  std::lock_guard<std::mutex> ReplacementFor_guard(ReplacementFor_socket_mutex_);
  if (ReplacementFor_socket_requests_in_flight_ > 0) {
    ReplacementFor_shutdown_socket(ReplacementFor_socket_);
    ReplacementFor_socket_should_be_closed_when_request_is_done_ = true;
    return;
  }

  
  ReplacementFor_shutdown_ssl(ReplacementFor_socket_, true);
  ReplacementFor_shutdown_socket(ReplacementFor_socket_);
  ReplacementFor_close_socket(ReplacementFor_socket_);
}

void ReplacementFor_ClientImpl::ReplacementFor_set_connection_timeout(time_t sec, time_t ReplacementFor_usec) {
  ReplacementFor_connection_timeout_sec_ = sec;
  ReplacementFor_connection_timeout_usec_ = ReplacementFor_usec;
}

void ReplacementFor_ClientImpl::ReplacementFor_set_read_timeout(time_t sec, time_t ReplacementFor_usec) {
  ReplacementFor_read_timeout_sec_ = sec;
  ReplacementFor_read_timeout_usec_ = ReplacementFor_usec;
}

void ReplacementFor_ClientImpl::ReplacementFor_set_write_timeout(time_t sec, time_t ReplacementFor_usec) {
  ReplacementFor_write_timeout_sec_ = sec;
  ReplacementFor_write_timeout_usec_ = ReplacementFor_usec;
}

void ReplacementFor_ClientImpl::ReplacementFor_set_basic_auth(const char *ReplacementFor_username,
                                       const char *ReplacementFor_password) {
  ReplacementFor_basic_auth_username_ = ReplacementFor_username;
  ReplacementFor_basic_auth_password_ = ReplacementFor_password;
}

void ReplacementFor_ClientImpl::ReplacementFor_set_bearer_token_auth(const char *ReplacementFor_token) {
  ReplacementFor_bearer_token_auth_token_ = ReplacementFor_token;
}

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_ClientImpl::ReplacementFor_set_digest_auth(const char *ReplacementFor_username,
                                        const char *ReplacementFor_password) {
  ReplacementFor_digest_auth_username_ = ReplacementFor_username;
  ReplacementFor_digest_auth_password_ = ReplacementFor_password;
}
#endif

void ReplacementFor_ClientImpl::ReplacementFor_set_keep_alive(bool ReplacementFor_on) { ReplacementFor_keep_alive_ = ReplacementFor_on; }

void ReplacementFor_ClientImpl::ReplacementFor_set_follow_location(bool ReplacementFor_on) { ReplacementFor_follow_location_ = ReplacementFor_on; }

void ReplacementFor_ClientImpl::ReplacementFor_set_default_headers(ReplacementFor_Headers ReplacementFor_headers) {
  ReplacementFor_default_headers_ = std::move(ReplacementFor_headers);
}

void ReplacementFor_ClientImpl::ReplacementFor_set_tcp_nodelay(bool ReplacementFor_on) { ReplacementFor_tcp_nodelay_ = ReplacementFor_on; }

void ReplacementFor_ClientImpl::ReplacementFor_set_socket_options(ReplacementFor_SocketOptions ReplacementFor_socket_options) {
  ReplacementFor_socket_options_ = std::move(ReplacementFor_socket_options);
}

void ReplacementFor_ClientImpl::ReplacementFor_set_compress(bool ReplacementFor_on) { ReplacementFor_compress_ = ReplacementFor_on; }

void ReplacementFor_ClientImpl::ReplacementFor_set_decompress(bool ReplacementFor_on) { ReplacementFor_decompress_ = ReplacementFor_on; }

void ReplacementFor_ClientImpl::ReplacementFor_set_interface(const char *intf) { ReplacementFor_interface_ = intf; }

void ReplacementFor_ClientImpl::ReplacementFor_set_proxy(const char *ReplacementFor_host, int ReplacementFor_port) {
  ReplacementFor_proxy_host_ = ReplacementFor_host;
  ReplacementFor_proxy_port_ = ReplacementFor_port;
}

void ReplacementFor_ClientImpl::ReplacementFor_set_proxy_basic_auth(const char *ReplacementFor_username,
                                             const char *ReplacementFor_password) {
  ReplacementFor_proxy_basic_auth_username_ = ReplacementFor_username;
  ReplacementFor_proxy_basic_auth_password_ = ReplacementFor_password;
}

void ReplacementFor_ClientImpl::ReplacementFor_set_proxy_bearer_token_auth(const char *ReplacementFor_token) {
  ReplacementFor_proxy_bearer_token_auth_token_ = ReplacementFor_token;
}

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_ClientImpl::ReplacementFor_set_proxy_digest_auth(const char *ReplacementFor_username,
                                              const char *ReplacementFor_password) {
  ReplacementFor_proxy_digest_auth_username_ = ReplacementFor_username;
  ReplacementFor_proxy_digest_auth_password_ = ReplacementFor_password;
}
#endif

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_ClientImpl::ReplacementFor_enable_server_certificate_verification(bool ReplacementFor_enabled) {
  ReplacementFor_server_certificate_verification_ = ReplacementFor_enabled;
}
#endif

void ReplacementFor_ClientImpl::ReplacementFor_set_logger(ReplacementFor_Logger ReplacementFor_logger) {
  ReplacementFor_logger_ = std::move(ReplacementFor_logger);
}

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
namespace ReplacementFor_detail {

template <typename U, typename ReplacementFor_V>
ReplacementFor_SSL *ReplacementFor_ssl_new(ReplacementFor_socket_t ReplacementFor_sock, ReplacementFor_SSL_CTX *ctx, std::mutex &ReplacementFor_ctx_mutex,
                    U ReplacementFor_SSL_connect_or_accept, ReplacementFor_V ReplacementFor_setup) {
  ReplacementFor_SSL *ReplacementFor_ssl = nullptr;
  {
    std::lock_guard<std::mutex> ReplacementFor_guard(ReplacementFor_ctx_mutex);
    ReplacementFor_ssl = ReplacementFor_SSL_new(ctx);
  }

  if (ReplacementFor_ssl) {
    ReplacementFor_set_nonblocking(ReplacementFor_sock, true);
    auto ReplacementFor_bio = ReplacementFor_BIO_new_socket(static_cast<int>(ReplacementFor_sock), ReplacementFor_BIO_NOCLOSE);
    ReplacementFor_BIO_set_nbio(ReplacementFor_bio, 1);
    ReplacementFor_SSL_set_bio(ReplacementFor_ssl, ReplacementFor_bio, ReplacementFor_bio);

    if (!ReplacementFor_setup(ReplacementFor_ssl) || ReplacementFor_SSL_connect_or_accept(ReplacementFor_ssl) != 1) {
      ReplacementFor_SSL_shutdown(ReplacementFor_ssl);
      {
        std::lock_guard<std::mutex> ReplacementFor_guard(ReplacementFor_ctx_mutex);
        ReplacementFor_SSL_free(ReplacementFor_ssl);
      }
      ReplacementFor_set_nonblocking(ReplacementFor_sock, false);
      return nullptr;
    }
    ReplacementFor_BIO_set_nbio(ReplacementFor_bio, 0);
    ReplacementFor_set_nonblocking(ReplacementFor_sock, false);
  }

  return ReplacementFor_ssl;
}

void ReplacementFor_ssl_delete(std::mutex &ReplacementFor_ctx_mutex, ReplacementFor_SSL *ReplacementFor_ssl,
                       bool ReplacementFor_shutdown_gracefully) {
  if (ReplacementFor_shutdown_gracefully) { ReplacementFor_SSL_shutdown(ReplacementFor_ssl); }

  std::lock_guard<std::mutex> ReplacementFor_guard(ReplacementFor_ctx_mutex);
  ReplacementFor_SSL_free(ReplacementFor_ssl);
}

template <typename U>
bool ReplacementFor_ssl_connect_or_accept_nonblocking(ReplacementFor_socket_t ReplacementFor_sock, ReplacementFor_SSL *ReplacementFor_ssl,
                                       U ReplacementFor_ssl_connect_or_accept,
                                       time_t ReplacementFor_timeout_sec,
                                       time_t ReplacementFor_timeout_usec) {
  int ReplacementFor_res = 0;
  while ((ReplacementFor_res = ReplacementFor_ssl_connect_or_accept(ReplacementFor_ssl)) != 1) {
    auto err = ReplacementFor_SSL_get_error(ReplacementFor_ssl, ReplacementFor_res);
    switch (err) {
    case ReplacementFor_SSL_ERROR_WANT_READ:
      if (ReplacementFor_select_read(ReplacementFor_sock, ReplacementFor_timeout_sec, ReplacementFor_timeout_usec) > 0) { continue; }
      break;
    case ReplacementFor_SSL_ERROR_WANT_WRITE:
      if (ReplacementFor_select_write(ReplacementFor_sock, ReplacementFor_timeout_sec, ReplacementFor_timeout_usec) > 0) { continue; }
      break;
    default: break;
    }
    return false;
  }
  return true;
}

template <typename T>
bool
ReplacementFor_process_server_socket_ssl(ReplacementFor_SSL *ReplacementFor_ssl, ReplacementFor_socket_t ReplacementFor_sock, size_t ReplacementFor_keep_alive_max_count,
                          time_t ReplacementFor_keep_alive_timeout_sec,
                          time_t ReplacementFor_read_timeout_sec, time_t ReplacementFor_read_timeout_usec,
                          time_t ReplacementFor_write_timeout_sec, time_t ReplacementFor_write_timeout_usec,
                          T ReplacementFor_callback) {
  return ReplacementFor_process_server_socket_core(
      ReplacementFor_sock, ReplacementFor_keep_alive_max_count, ReplacementFor_keep_alive_timeout_sec,
      [&](bool ReplacementFor_close_connection, bool &ReplacementFor_connection_closed) {
        ReplacementFor_SSLSocketStream ReplacementFor_strm(ReplacementFor_sock, ReplacementFor_ssl, ReplacementFor_read_timeout_sec, ReplacementFor_read_timeout_usec,
                             ReplacementFor_write_timeout_sec, ReplacementFor_write_timeout_usec);
        return ReplacementFor_callback(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_connection_closed);
      });
}

template <typename T>
bool
ReplacementFor_process_client_socket_ssl(ReplacementFor_SSL *ReplacementFor_ssl, ReplacementFor_socket_t ReplacementFor_sock, time_t ReplacementFor_read_timeout_sec,
                          time_t ReplacementFor_read_timeout_usec, time_t ReplacementFor_write_timeout_sec,
                          time_t ReplacementFor_write_timeout_usec, T ReplacementFor_callback) {
  ReplacementFor_SSLSocketStream ReplacementFor_strm(ReplacementFor_sock, ReplacementFor_ssl, ReplacementFor_read_timeout_sec, ReplacementFor_read_timeout_usec,
                       ReplacementFor_write_timeout_sec, ReplacementFor_write_timeout_usec);
  return ReplacementFor_callback(ReplacementFor_strm);
}

#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x10100000L
static std::shared_ptr<std::vector<std::mutex>> ReplacementFor_openSSL_locks_;

class ReplacementFor_SSLThreadLocks {
public:
  ReplacementFor_SSLThreadLocks() {
    ReplacementFor_openSSL_locks_ =
        std::make_shared<std::vector<std::mutex>>(ReplacementFor_CRYPTO_num_locks());
    ReplacementFor_CRYPTO_set_locking_callback(ReplacementFor_locking_callback);
  }

  ~ReplacementFor_SSLThreadLocks() { ReplacementFor_CRYPTO_set_locking_callback(nullptr); }

private:
  static void ReplacementFor_locking_callback(int ReplacementFor_mode, int type, const char *  ,
                               int  ) {
    auto &ReplacementFor_lk = (*ReplacementFor_openSSL_locks_)[static_cast<size_t>(type)];
    if (ReplacementFor_mode & ReplacementFor_CRYPTO_LOCK) {
      ReplacementFor_lk.lock();
    } else {
      ReplacementFor_lk.unlock();
    }
  }
};

#endif

class ReplacementFor_SSLInit {
public:
  ReplacementFor_SSLInit() {
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x1010001fL
    ReplacementFor_SSL_load_error_strings();
    ReplacementFor_SSL_library_init();
#else
    ReplacementFor_OPENSSL_init_ssl(
        ReplacementFor_OPENSSL_INIT_LOAD_SSL_STRINGS | ReplacementFor_OPENSSL_INIT_LOAD_CRYPTO_STRINGS, NULL);
#endif
  }

  ~ReplacementFor_SSLInit() {
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x1010001fL
    ReplacementFor_ERR_free_strings();
#endif
  }

private:
#if ReplacementFor_OPENSSL_VERSION_NUMBER < 0x10100000L
  ReplacementFor_SSLThreadLocks ReplacementFor_thread_init_;
#endif
};

ReplacementFor_SSLSocketStream::ReplacementFor_SSLSocketStream(ReplacementFor_socket_t ReplacementFor_sock, ReplacementFor_SSL *ReplacementFor_ssl,
                                        time_t ReplacementFor_read_timeout_sec,
                                        time_t ReplacementFor_read_timeout_usec,
                                        time_t ReplacementFor_write_timeout_sec,
                                        time_t ReplacementFor_write_timeout_usec)
    : ReplacementFor_sock_(ReplacementFor_sock), ReplacementFor_ssl_(ReplacementFor_ssl), ReplacementFor_read_timeout_sec_(ReplacementFor_read_timeout_sec),
      ReplacementFor_read_timeout_usec_(ReplacementFor_read_timeout_usec),
      ReplacementFor_write_timeout_sec_(ReplacementFor_write_timeout_sec),
      ReplacementFor_write_timeout_usec_(ReplacementFor_write_timeout_usec) {
  ReplacementFor_SSL_clear_mode(ReplacementFor_ssl, ReplacementFor_SSL_MODE_AUTO_RETRY);
}

ReplacementFor_SSLSocketStream::~ReplacementFor_SSLSocketStream() {}

bool ReplacementFor_SSLSocketStream::ReplacementFor_is_readable() const {
  return ReplacementFor_detail::ReplacementFor_select_read(ReplacementFor_sock_, ReplacementFor_read_timeout_sec_, ReplacementFor_read_timeout_usec_) > 0;
}

bool ReplacementFor_SSLSocketStream::ReplacementFor_is_writable() const {
  return ReplacementFor_detail::ReplacementFor_select_write(ReplacementFor_sock_, ReplacementFor_write_timeout_sec_, ReplacementFor_write_timeout_usec_) >
         0;
}

ssize_t ReplacementFor_SSLSocketStream::read(char *ReplacementFor_ptr, size_t size) {
  if (ReplacementFor_SSL_pending(ReplacementFor_ssl_) > 0) {
    return ReplacementFor_SSL_read(ReplacementFor_ssl_, ReplacementFor_ptr, static_cast<int>(size));
  } else if (ReplacementFor_is_readable()) {
    auto ReplacementFor_ret = ReplacementFor_SSL_read(ReplacementFor_ssl_, ReplacementFor_ptr, static_cast<int>(size));
    if (ReplacementFor_ret < 0) {
      auto err = ReplacementFor_SSL_get_error(ReplacementFor_ssl_, ReplacementFor_ret);
      while (err == ReplacementFor_SSL_ERROR_WANT_READ) {
        if (ReplacementFor_SSL_pending(ReplacementFor_ssl_) > 0) {
          return ReplacementFor_SSL_read(ReplacementFor_ssl_, ReplacementFor_ptr, static_cast<int>(size));
        } else if (ReplacementFor_is_readable()) {
          ReplacementFor_ret = ReplacementFor_SSL_read(ReplacementFor_ssl_, ReplacementFor_ptr, static_cast<int>(size));
          if (ReplacementFor_ret >= 0) { return ReplacementFor_ret; }
          err = ReplacementFor_SSL_get_error(ReplacementFor_ssl_, ReplacementFor_ret);
        } else {
          return -1;
        }
      }
    }
    return ReplacementFor_ret;
  }
  return -1;
}

ssize_t ReplacementFor_SSLSocketStream::write(const char *ReplacementFor_ptr, size_t size) {
  if (ReplacementFor_is_writable()) { return ReplacementFor_SSL_write(ReplacementFor_ssl_, ReplacementFor_ptr, static_cast<int>(size)); }
  return -1;
}

void ReplacementFor_SSLSocketStream::ReplacementFor_get_remote_ip_and_port(std::string &ReplacementFor_ip,
                                                    int &ReplacementFor_port) const {
  ReplacementFor_detail::ReplacementFor_get_remote_ip_and_port(ReplacementFor_sock_, ReplacementFor_ip, ReplacementFor_port);
}

ReplacementFor_socket_t ReplacementFor_SSLSocketStream::socket() const { return ReplacementFor_sock_; }

static ReplacementFor_SSLInit ReplacementFor_sslinit_;

} 

ReplacementFor_SSLServer::ReplacementFor_SSLServer(const char *ReplacementFor_cert_path, const char *ReplacementFor_private_key_path,
                            const char *ReplacementFor_client_ca_cert_file_path,
                            const char *ReplacementFor_client_ca_cert_dir_path) {
  ReplacementFor_ctx_ = ReplacementFor_SSL_CTX_new(ReplacementFor_SSLv23_server_method());

  if (ReplacementFor_ctx_) {
    ReplacementFor_SSL_CTX_set_options(ReplacementFor_ctx_,
                        ReplacementFor_SSL_OP_ALL | ReplacementFor_SSL_OP_NO_SSLv2 | ReplacementFor_SSL_OP_NO_SSLv3 |
                            ReplacementFor_SSL_OP_NO_COMPRESSION |
                            ReplacementFor_SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION);

    if (ReplacementFor_SSL_CTX_use_certificate_chain_file(ReplacementFor_ctx_, ReplacementFor_cert_path) != 1 ||
        ReplacementFor_SSL_CTX_use_PrivateKey_file(ReplacementFor_ctx_, ReplacementFor_private_key_path, ReplacementFor_SSL_FILETYPE_PEM) !=
            1) {
      ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);
      ReplacementFor_ctx_ = nullptr;
    } else if (ReplacementFor_client_ca_cert_file_path || ReplacementFor_client_ca_cert_dir_path) {
      
      
      
      

      ReplacementFor_SSL_CTX_load_verify_locations(ReplacementFor_ctx_, ReplacementFor_client_ca_cert_file_path,
                                    ReplacementFor_client_ca_cert_dir_path);

      ReplacementFor_SSL_CTX_set_verify(
          ReplacementFor_ctx_,
          ReplacementFor_SSL_VERIFY_PEER |
              ReplacementFor_SSL_VERIFY_FAIL_IF_NO_PEER_CERT, 
          nullptr);
    }
  }
}

ReplacementFor_SSLServer::ReplacementFor_SSLServer(ReplacementFor_X509 *ReplacementFor_cert, ReplacementFor_EVP_PKEY *ReplacementFor_private_key,
                            ReplacementFor_X509_STORE *ReplacementFor_client_ca_cert_store) {
  ReplacementFor_ctx_ = ReplacementFor_SSL_CTX_new(ReplacementFor_SSLv23_server_method());

  if (ReplacementFor_ctx_) {
    ReplacementFor_SSL_CTX_set_options(ReplacementFor_ctx_,
                        ReplacementFor_SSL_OP_ALL | ReplacementFor_SSL_OP_NO_SSLv2 | ReplacementFor_SSL_OP_NO_SSLv3 |
                            ReplacementFor_SSL_OP_NO_COMPRESSION |
                            ReplacementFor_SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION);

    if (ReplacementFor_SSL_CTX_use_certificate(ReplacementFor_ctx_, ReplacementFor_cert) != 1 ||
        ReplacementFor_SSL_CTX_use_PrivateKey(ReplacementFor_ctx_, ReplacementFor_private_key) != 1) {
      ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);
      ReplacementFor_ctx_ = nullptr;
    } else if (ReplacementFor_client_ca_cert_store) {

      ReplacementFor_SSL_CTX_set_cert_store(ReplacementFor_ctx_, ReplacementFor_client_ca_cert_store);

      ReplacementFor_SSL_CTX_set_verify(
          ReplacementFor_ctx_,
          ReplacementFor_SSL_VERIFY_PEER |
              ReplacementFor_SSL_VERIFY_FAIL_IF_NO_PEER_CERT, 
          nullptr);
    }
  }
}

ReplacementFor_SSLServer::~ReplacementFor_SSLServer() {
  if (ReplacementFor_ctx_) { ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_); }
}

bool ReplacementFor_SSLServer::ReplacementFor_is_valid() const { return ReplacementFor_ctx_; }

bool ReplacementFor_SSLServer::ReplacementFor_process_and_close_socket(ReplacementFor_socket_t ReplacementFor_sock) {
  auto ReplacementFor_ssl = ReplacementFor_detail::ReplacementFor_ssl_new(
      ReplacementFor_sock, ReplacementFor_ctx_, ReplacementFor_ctx_mutex_,
      [&](ReplacementFor_SSL *ReplacementFor_ssl) {
        return ReplacementFor_detail::ReplacementFor_ssl_connect_or_accept_nonblocking(
            ReplacementFor_sock, ReplacementFor_ssl, ReplacementFor_SSL_accept, ReplacementFor_read_timeout_sec_, ReplacementFor_read_timeout_usec_);
      },
      [](ReplacementFor_SSL *  ) { return true; });

  bool ReplacementFor_ret = false;
  if (ReplacementFor_ssl) {
    ReplacementFor_ret = ReplacementFor_detail::ReplacementFor_process_server_socket_ssl(
        ReplacementFor_ssl, ReplacementFor_sock, ReplacementFor_keep_alive_max_count_, ReplacementFor_keep_alive_timeout_sec_,
        ReplacementFor_read_timeout_sec_, ReplacementFor_read_timeout_usec_, ReplacementFor_write_timeout_sec_,
        ReplacementFor_write_timeout_usec_,
        [this, ReplacementFor_ssl](ReplacementFor_Stream &ReplacementFor_strm, bool ReplacementFor_close_connection,
                    bool &ReplacementFor_connection_closed) {
          return ReplacementFor_process_request(ReplacementFor_strm, ReplacementFor_close_connection, ReplacementFor_connection_closed,
                                 [&](ReplacementFor_Request &ReplacementFor_req) { ReplacementFor_req.ReplacementFor_ssl = ReplacementFor_ssl; });
        });

    const bool ReplacementFor_shutdown_gracefully = ReplacementFor_ret;
    ReplacementFor_detail::ReplacementFor_ssl_delete(ReplacementFor_ctx_mutex_, ReplacementFor_ssl, ReplacementFor_shutdown_gracefully);
  }

  ReplacementFor_detail::ReplacementFor_shutdown_socket(ReplacementFor_sock);
  ReplacementFor_detail::ReplacementFor_close_socket(ReplacementFor_sock);
  return ReplacementFor_ret;
}

ReplacementFor_SSLClient::ReplacementFor_SSLClient(const std::string &ReplacementFor_host)
    : ReplacementFor_SSLClient(ReplacementFor_host, 443, std::string(), std::string()) {}

ReplacementFor_SSLClient::ReplacementFor_SSLClient(const std::string &ReplacementFor_host, int ReplacementFor_port)
    : ReplacementFor_SSLClient(ReplacementFor_host, ReplacementFor_port, std::string(), std::string()) {}

ReplacementFor_SSLClient::ReplacementFor_SSLClient(const std::string &ReplacementFor_host, int ReplacementFor_port,
                            const std::string &ReplacementFor_client_cert_path,
                            const std::string &ReplacementFor_client_key_path)
    : ReplacementFor_ClientImpl(ReplacementFor_host, ReplacementFor_port, ReplacementFor_client_cert_path, ReplacementFor_client_key_path) {
  ReplacementFor_ctx_ = ReplacementFor_SSL_CTX_new(ReplacementFor_SSLv23_client_method());

  ReplacementFor_detail::ReplacementFor_split(&ReplacementFor_host_[0], &ReplacementFor_host_[ReplacementFor_host_.size()], ((char)(0x1836+3194-0x2482)),
                [&](const char *b, const char *ReplacementFor_e) {
                  ReplacementFor_host_components_.emplace_back(std::string(b, ReplacementFor_e));
                });
  if (!ReplacementFor_client_cert_path.empty() && !ReplacementFor_client_key_path.empty()) {
    if (ReplacementFor_SSL_CTX_use_certificate_file(ReplacementFor_ctx_, ReplacementFor_client_cert_path.c_str(),
                                     ReplacementFor_SSL_FILETYPE_PEM) != 1 ||
        ReplacementFor_SSL_CTX_use_PrivateKey_file(ReplacementFor_ctx_, ReplacementFor_client_key_path.c_str(),
                                    ReplacementFor_SSL_FILETYPE_PEM) != 1) {
      ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);
      ReplacementFor_ctx_ = nullptr;
    }
  }
}

ReplacementFor_SSLClient::ReplacementFor_SSLClient(const std::string &ReplacementFor_host, int ReplacementFor_port,
                            ReplacementFor_X509 *ReplacementFor_client_cert, ReplacementFor_EVP_PKEY *ReplacementFor_client_key)
    : ReplacementFor_ClientImpl(ReplacementFor_host, ReplacementFor_port) {
  ReplacementFor_ctx_ = ReplacementFor_SSL_CTX_new(ReplacementFor_SSLv23_client_method());

  ReplacementFor_detail::ReplacementFor_split(&ReplacementFor_host_[0], &ReplacementFor_host_[ReplacementFor_host_.size()], ((char)(0x38c+862-0x6bc)),
                [&](const char *b, const char *ReplacementFor_e) {
                  ReplacementFor_host_components_.emplace_back(std::string(b, ReplacementFor_e));
                });
  if (ReplacementFor_client_cert != nullptr && ReplacementFor_client_key != nullptr) {
    if (ReplacementFor_SSL_CTX_use_certificate(ReplacementFor_ctx_, ReplacementFor_client_cert) != 1 ||
        ReplacementFor_SSL_CTX_use_PrivateKey(ReplacementFor_ctx_, ReplacementFor_client_key) != 1) {
      ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_);
      ReplacementFor_ctx_ = nullptr;
    }
  }
}

ReplacementFor_SSLClient::~ReplacementFor_SSLClient() {
  if (ReplacementFor_ctx_) { ReplacementFor_SSL_CTX_free(ReplacementFor_ctx_); }
  ReplacementFor_SSLClient::ReplacementFor_shutdown_ssl(ReplacementFor_socket_, true);
}

bool ReplacementFor_SSLClient::ReplacementFor_is_valid() const { return ReplacementFor_ctx_; }

void ReplacementFor_SSLClient::ReplacementFor_set_ca_cert_path(const char *ReplacementFor_ca_cert_file_path,
                                        const char *ReplacementFor_ca_cert_dir_path) {
  if (ReplacementFor_ca_cert_file_path) { ReplacementFor_ca_cert_file_path_ = ReplacementFor_ca_cert_file_path; }
  if (ReplacementFor_ca_cert_dir_path) { ReplacementFor_ca_cert_dir_path_ = ReplacementFor_ca_cert_dir_path; }
}

void ReplacementFor_SSLClient::ReplacementFor_set_ca_cert_store(ReplacementFor_X509_STORE *ReplacementFor_ca_cert_store) {
  if (ReplacementFor_ca_cert_store) {
    if (ReplacementFor_ctx_) {
      if (ReplacementFor_SSL_CTX_get_cert_store(ReplacementFor_ctx_) != ReplacementFor_ca_cert_store) {
        
        ReplacementFor_SSL_CTX_set_cert_store(ReplacementFor_ctx_, ReplacementFor_ca_cert_store);
      }
    } else {
      ReplacementFor_X509_STORE_free(ReplacementFor_ca_cert_store);
    }
  }
}

long ReplacementFor_SSLClient::ReplacementFor_get_openssl_verify_result() const {
  return ReplacementFor_verify_result_;
}

ReplacementFor_SSL_CTX *ReplacementFor_SSLClient::ReplacementFor_ssl_context() const { return ReplacementFor_ctx_; }

bool ReplacementFor_SSLClient::ReplacementFor_create_and_connect_socket(Socket &socket, Error &error) {
  return ReplacementFor_is_valid() && ReplacementFor_ClientImpl::ReplacementFor_create_and_connect_socket(socket, error);
}

bool ReplacementFor_SSLClient::ReplacementFor_connect_with_proxy(Socket &socket, ReplacementFor_Response &ReplacementFor_res,
                                          bool &ReplacementFor_success, Error &error) {
  ReplacementFor_success = true;
  ReplacementFor_Response ReplacementFor_res2;
  if (!ReplacementFor_detail::ReplacementFor_process_client_socket(
          socket.ReplacementFor_sock, ReplacementFor_read_timeout_sec_, ReplacementFor_read_timeout_usec_,
          ReplacementFor_write_timeout_sec_, ReplacementFor_write_timeout_usec_, [&](ReplacementFor_Stream &ReplacementFor_strm) {
            ReplacementFor_Request ReplacementFor_req2;
            ReplacementFor_req2.ReplacementFor_method = "CONNECT";
            ReplacementFor_req2.ReplacementFor_path = ReplacementFor_host_and_port_;
            return ReplacementFor_process_request(ReplacementFor_strm, ReplacementFor_req2, ReplacementFor_res2, false, error);
          })) {
    ReplacementFor_shutdown_ssl(socket, true);
    ReplacementFor_shutdown_socket(socket);
    ReplacementFor_close_socket(socket);
    ReplacementFor_success = false;
    return false;
  }

  if (ReplacementFor_res2.status == 407) {
    if (!ReplacementFor_proxy_digest_auth_username_.empty() &&
        !ReplacementFor_proxy_digest_auth_password_.empty()) {
      std::map<std::string, std::string> ReplacementFor_auth;
      if (ReplacementFor_detail::ReplacementFor_parse_www_authenticate(ReplacementFor_res2, ReplacementFor_auth, true)) {
        ReplacementFor_Response ReplacementFor_res3;
        if (!ReplacementFor_detail::ReplacementFor_process_client_socket(
                socket.ReplacementFor_sock, ReplacementFor_read_timeout_sec_, ReplacementFor_read_timeout_usec_,
                ReplacementFor_write_timeout_sec_, ReplacementFor_write_timeout_usec_, [&](ReplacementFor_Stream &ReplacementFor_strm) {
                  ReplacementFor_Request ReplacementFor_req3;
                  ReplacementFor_req3.ReplacementFor_method = "CONNECT";
                  ReplacementFor_req3.ReplacementFor_path = ReplacementFor_host_and_port_;
                  ReplacementFor_req3.ReplacementFor_headers.insert(ReplacementFor_detail::ReplacementFor_make_digest_authentication_header(
                      ReplacementFor_req3, ReplacementFor_auth, 1, ReplacementFor_detail::ReplacementFor_random_string(10),
                      ReplacementFor_proxy_digest_auth_username_, ReplacementFor_proxy_digest_auth_password_,
                      true));
                  return ReplacementFor_process_request(ReplacementFor_strm, ReplacementFor_req3, ReplacementFor_res3, false, error);
                })) {
          
          
          ReplacementFor_shutdown_ssl(socket, true);
          ReplacementFor_shutdown_socket(socket);
          ReplacementFor_close_socket(socket);
          ReplacementFor_success = false;
          return false;
        }
      }
    } else {
      ReplacementFor_res = ReplacementFor_res2;
      return false;
    }
  }

  return true;
}

bool ReplacementFor_SSLClient::ReplacementFor_load_certs() {
  bool ReplacementFor_ret = true;

  std::call_once(ReplacementFor_initialize_cert_, [&]() {
    std::lock_guard<std::mutex> ReplacementFor_guard(ReplacementFor_ctx_mutex_);
    if (!ReplacementFor_ca_cert_file_path_.empty()) {
      if (!ReplacementFor_SSL_CTX_load_verify_locations(ReplacementFor_ctx_, ReplacementFor_ca_cert_file_path_.c_str(),
                                         nullptr)) {
        ReplacementFor_ret = false;
      }
    } else if (!ReplacementFor_ca_cert_dir_path_.empty()) {
      if (!ReplacementFor_SSL_CTX_load_verify_locations(ReplacementFor_ctx_, nullptr,
                                         ReplacementFor_ca_cert_dir_path_.c_str())) {
        ReplacementFor_ret = false;
      }
    } else {
#ifdef _WIN32
      ReplacementFor_detail::ReplacementFor_load_system_certs_on_windows(ReplacementFor_SSL_CTX_get_cert_store(ReplacementFor_ctx_));
#else
      ReplacementFor_SSL_CTX_set_default_verify_paths(ReplacementFor_ctx_);
#endif
    }
  });

  return ReplacementFor_ret;
}

bool ReplacementFor_SSLClient::ReplacementFor_initialize_ssl(Socket &socket, Error &error) {
  auto ReplacementFor_ssl = ReplacementFor_detail::ReplacementFor_ssl_new(
      socket.ReplacementFor_sock, ReplacementFor_ctx_, ReplacementFor_ctx_mutex_,
      [&](ReplacementFor_SSL *ReplacementFor_ssl) {
        if (ReplacementFor_server_certificate_verification_) {
          if (!ReplacementFor_load_certs()) {
            error = Error::ReplacementFor_SSLLoadingCerts;
            return false;
          }
          ReplacementFor_SSL_set_verify(ReplacementFor_ssl, ReplacementFor_SSL_VERIFY_NONE, nullptr);
        }

        if (!ReplacementFor_detail::ReplacementFor_ssl_connect_or_accept_nonblocking(
                socket.ReplacementFor_sock, ReplacementFor_ssl, ReplacementFor_SSL_connect, ReplacementFor_connection_timeout_sec_,
                ReplacementFor_connection_timeout_usec_)) {
          error = Error::ReplacementFor_SSLConnection;
          return false;
        }

        if (ReplacementFor_server_certificate_verification_) {
          ReplacementFor_verify_result_ = ReplacementFor_SSL_get_verify_result(ReplacementFor_ssl);

          if (ReplacementFor_verify_result_ != ReplacementFor_X509_V_OK) {
            error = Error::ReplacementFor_SSLServerVerification;
            return false;
          }

          auto ReplacementFor_server_cert = ReplacementFor_SSL_get_peer_certificate(ReplacementFor_ssl);

          if (ReplacementFor_server_cert == nullptr) {
            error = Error::ReplacementFor_SSLServerVerification;
            return false;
          }

          if (!ReplacementFor_verify_host(ReplacementFor_server_cert)) {
            ReplacementFor_X509_free(ReplacementFor_server_cert);
            error = Error::ReplacementFor_SSLServerVerification;
            return false;
          }
          ReplacementFor_X509_free(ReplacementFor_server_cert);
        }

        return true;
      },
      [&](ReplacementFor_SSL *ReplacementFor_ssl) {
        ReplacementFor_SSL_set_tlsext_host_name(ReplacementFor_ssl, ReplacementFor_host_.c_str());
        return true;
      });

  if (ReplacementFor_ssl) {
    socket.ReplacementFor_ssl = ReplacementFor_ssl;
    return true;
  }

  ReplacementFor_shutdown_socket(socket);
  ReplacementFor_close_socket(socket);
  return false;
}

void ReplacementFor_SSLClient::ReplacementFor_shutdown_ssl(Socket &socket, bool ReplacementFor_shutdown_gracefully) {
  if (socket.ReplacementFor_sock == INVALID_SOCKET) {
    assert(socket.ReplacementFor_ssl == nullptr);
    return;
  }
  if (socket.ReplacementFor_ssl) {
    ReplacementFor_detail::ReplacementFor_ssl_delete(ReplacementFor_ctx_mutex_, socket.ReplacementFor_ssl, ReplacementFor_shutdown_gracefully);
    socket.ReplacementFor_ssl = nullptr;
  }
  assert(socket.ReplacementFor_ssl == nullptr);
}

bool
ReplacementFor_SSLClient::ReplacementFor_process_socket(const Socket &socket,
                          std::function<bool(ReplacementFor_Stream &ReplacementFor_strm)> ReplacementFor_callback) {
  assert(socket.ReplacementFor_ssl);
  return ReplacementFor_detail::ReplacementFor_process_client_socket_ssl(
      socket.ReplacementFor_ssl, socket.ReplacementFor_sock, ReplacementFor_read_timeout_sec_, ReplacementFor_read_timeout_usec_,
      ReplacementFor_write_timeout_sec_, ReplacementFor_write_timeout_usec_, std::move(ReplacementFor_callback));
}

bool ReplacementFor_SSLClient::ReplacementFor_is_ssl() const { return true; }

bool ReplacementFor_SSLClient::ReplacementFor_verify_host(ReplacementFor_X509 *ReplacementFor_server_cert) const {
  return ReplacementFor_verify_host_with_subject_alt_name(ReplacementFor_server_cert) ||
         ReplacementFor_verify_host_with_common_name(ReplacementFor_server_cert);
}

bool
ReplacementFor_SSLClient::ReplacementFor_verify_host_with_subject_alt_name(ReplacementFor_X509 *ReplacementFor_server_cert) const {
  auto ReplacementFor_ret = false;

  auto type = ReplacementFor_GEN_DNS;

  struct in6_addr ReplacementFor_addr6;
  struct in_addr addr;
  size_t ReplacementFor_addr_len = 0;

#ifndef __MINGW32__
  if (ReplacementFor_inet_pton(AF_INET6, ReplacementFor_host_.c_str(), &ReplacementFor_addr6)) {
    type = ReplacementFor_GEN_IPADD;
    ReplacementFor_addr_len = sizeof(struct in6_addr);
  } else if (ReplacementFor_inet_pton(AF_INET, ReplacementFor_host_.c_str(), &addr)) {
    type = ReplacementFor_GEN_IPADD;
    ReplacementFor_addr_len = sizeof(struct in_addr);
  }
#endif

  auto ReplacementFor_alt_names = static_cast<const struct ReplacementFor_stack_st_GENERAL_NAME *>(
      ReplacementFor_X509_get_ext_d2i(ReplacementFor_server_cert, ReplacementFor_NID_subject_alt_name, nullptr, nullptr));

  if (ReplacementFor_alt_names) {
    auto ReplacementFor_dsn_matched = false;
    auto ReplacementFor_ip_mached = false;

    auto count = ReplacementFor_sk_GENERAL_NAME_num(ReplacementFor_alt_names);

    for (decltype(count) i = 0; i < count && !ReplacementFor_dsn_matched; i++) {
      auto val = ReplacementFor_sk_GENERAL_NAME_value(ReplacementFor_alt_names, i);
      if (val->type == type) {
        auto name = (const char *)ReplacementFor_ASN1_STRING_get0_data(val->ReplacementFor_d.ReplacementFor_ia5);
        auto ReplacementFor_name_len = (size_t)ReplacementFor_ASN1_STRING_length(val->ReplacementFor_d.ReplacementFor_ia5);

        switch (type) {
        case ReplacementFor_GEN_DNS: ReplacementFor_dsn_matched = ReplacementFor_check_host_name(name, ReplacementFor_name_len); break;

        case ReplacementFor_GEN_IPADD:
          if (!memcmp(&ReplacementFor_addr6, name, ReplacementFor_addr_len) ||
              !memcmp(&addr, name, ReplacementFor_addr_len)) {
            ReplacementFor_ip_mached = true;
          }
          break;
        }
      }
    }

    if (ReplacementFor_dsn_matched || ReplacementFor_ip_mached) { ReplacementFor_ret = true; }
  }

  ReplacementFor_GENERAL_NAMES_free((ReplacementFor_STACK_OF(ReplacementFor_GENERAL_NAME) *)ReplacementFor_alt_names);
  return ReplacementFor_ret;
}

bool ReplacementFor_SSLClient::ReplacementFor_verify_host_with_common_name(ReplacementFor_X509 *ReplacementFor_server_cert) const {
  const auto ReplacementFor_subject_name = ReplacementFor_X509_get_subject_name(ReplacementFor_server_cert);

  if (ReplacementFor_subject_name != nullptr) {
    char name[BUFSIZ];
    auto ReplacementFor_name_len = ReplacementFor_X509_NAME_get_text_by_NID(ReplacementFor_subject_name, ReplacementFor_NID_commonName,
                                              name, sizeof(name));

    if (ReplacementFor_name_len != -1) {
      return ReplacementFor_check_host_name(name, static_cast<size_t>(ReplacementFor_name_len));
    }
  }

  return false;
}

bool ReplacementFor_SSLClient::ReplacementFor_check_host_name(const char *pattern,
                                       size_t ReplacementFor_pattern_len) const {
  if (ReplacementFor_host_.size() == ReplacementFor_pattern_len && ReplacementFor_host_ == pattern) { return true; }

  std::vector<std::string> ReplacementFor_pattern_components;
  ReplacementFor_detail::ReplacementFor_split(&pattern[0], &pattern[ReplacementFor_pattern_len], ((char)(0x15e3+2507-0x1f80)),
                [&](const char *b, const char *ReplacementFor_e) {
                  ReplacementFor_pattern_components.emplace_back(std::string(b, ReplacementFor_e));
                });

  if (ReplacementFor_host_components_.size() != ReplacementFor_pattern_components.size()) { return false; }

  auto ReplacementFor_itr = ReplacementFor_pattern_components.begin();
  for (const auto &ReplacementFor_h : ReplacementFor_host_components_) {
    auto &p = *ReplacementFor_itr;
    if (p != ReplacementFor_h && p != "*") {
      auto ReplacementFor_partial_match = (p.size() > 0 && p[p.size() - 1] == ((char)(0x93f+6324-0x21c9)) &&
                            !p.compare(0, p.size() - 1, ReplacementFor_h));
      if (!ReplacementFor_partial_match) { return false; }
    }
    ++ReplacementFor_itr;
  }

  return true;
}
#endif

ReplacementFor_Client::ReplacementFor_Client(const char *ReplacementFor_scheme_host_port)
    : ReplacementFor_Client(ReplacementFor_scheme_host_port, std::string(), std::string()) {}

ReplacementFor_Client::ReplacementFor_Client(const char *ReplacementFor_scheme_host_port,
                      const std::string &ReplacementFor_client_cert_path,
                      const std::string &ReplacementFor_client_key_path) {
  const static std::regex ReplacementFor_re(R"(^(?:([a-z]+)://)?([^:/?#]+)(?::(\d+))?)");

  std::cmatch m;
  if (std::regex_match(ReplacementFor_scheme_host_port, m, ReplacementFor_re)) {
    auto ReplacementFor_scheme = m[1].str();

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
    if (!ReplacementFor_scheme.empty() && (ReplacementFor_scheme != "http" && ReplacementFor_scheme != "https")) {
#else
    if (!ReplacementFor_scheme.empty() && ReplacementFor_scheme != "http") {
#endif
      std::string msg = "'" + ReplacementFor_scheme + "' scheme is not supported.";
      throw std::invalid_argument(msg);
      return;
    }

    auto ReplacementFor_is_ssl = ReplacementFor_scheme == "https";

    auto ReplacementFor_host = m[2].str();

    auto ReplacementFor_port_str = m[3].str();
    auto ReplacementFor_port = !ReplacementFor_port_str.empty() ? std::stoi(ReplacementFor_port_str) : (ReplacementFor_is_ssl ? 443 : 80);

    if (ReplacementFor_is_ssl) {
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
      ReplacementFor_cli_ = ReplacementFor_detail::make_unique<ReplacementFor_SSLClient>(ReplacementFor_host.c_str(), ReplacementFor_port,
                                            ReplacementFor_client_cert_path, ReplacementFor_client_key_path);
      ReplacementFor_is_ssl_ = ReplacementFor_is_ssl;
#endif
    } else {
      ReplacementFor_cli_ = ReplacementFor_detail::make_unique<ReplacementFor_ClientImpl>(ReplacementFor_host.c_str(), ReplacementFor_port,
                                             ReplacementFor_client_cert_path, ReplacementFor_client_key_path);
    }
  } else {
    ReplacementFor_cli_ = ReplacementFor_detail::make_unique<ReplacementFor_ClientImpl>(ReplacementFor_scheme_host_port, 80,
                                           ReplacementFor_client_cert_path, ReplacementFor_client_key_path);
  }
}

ReplacementFor_Client::ReplacementFor_Client(const std::string &ReplacementFor_host, int ReplacementFor_port)
    : ReplacementFor_cli_(ReplacementFor_detail::make_unique<ReplacementFor_ClientImpl>(ReplacementFor_host, ReplacementFor_port)) {}

ReplacementFor_Client::ReplacementFor_Client(const std::string &ReplacementFor_host, int ReplacementFor_port,
                      const std::string &ReplacementFor_client_cert_path,
                      const std::string &ReplacementFor_client_key_path)
    : ReplacementFor_cli_(ReplacementFor_detail::make_unique<ReplacementFor_ClientImpl>(ReplacementFor_host, ReplacementFor_port, ReplacementFor_client_cert_path,
                                           ReplacementFor_client_key_path)) {}

ReplacementFor_Client::~ReplacementFor_Client() {}

bool ReplacementFor_Client::ReplacementFor_is_valid() const {
  return ReplacementFor_cli_ != nullptr && ReplacementFor_cli_->ReplacementFor_is_valid();
}

Result ReplacementFor_Client::Get(const char *ReplacementFor_path) { return ReplacementFor_cli_->Get(ReplacementFor_path); }
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, ReplacementFor_headers);
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, ReplacementFor_Progress ReplacementFor_progress) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, std::move(ReplacementFor_progress));
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                          ReplacementFor_Progress ReplacementFor_progress) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, ReplacementFor_headers, std::move(ReplacementFor_progress));
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, ReplacementFor_ContentReceiver ReplacementFor_content_receiver) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, std::move(ReplacementFor_content_receiver));
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                          ReplacementFor_ContentReceiver ReplacementFor_content_receiver) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, ReplacementFor_headers, std::move(ReplacementFor_content_receiver));
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, ReplacementFor_ContentReceiver ReplacementFor_content_receiver,
                          ReplacementFor_Progress ReplacementFor_progress) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, std::move(ReplacementFor_content_receiver), std::move(ReplacementFor_progress));
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                          ReplacementFor_ContentReceiver ReplacementFor_content_receiver, ReplacementFor_Progress ReplacementFor_progress) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, ReplacementFor_headers, std::move(ReplacementFor_content_receiver),
                   std::move(ReplacementFor_progress));
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, ReplacementFor_ResponseHandler ReplacementFor_response_handler,
                          ReplacementFor_ContentReceiver ReplacementFor_content_receiver) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, std::move(ReplacementFor_response_handler),
                   std::move(ReplacementFor_content_receiver));
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                          ReplacementFor_ResponseHandler ReplacementFor_response_handler,
                          ReplacementFor_ContentReceiver ReplacementFor_content_receiver) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, ReplacementFor_headers, std::move(ReplacementFor_response_handler),
                   std::move(ReplacementFor_content_receiver));
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, ReplacementFor_ResponseHandler ReplacementFor_response_handler,
                          ReplacementFor_ContentReceiver ReplacementFor_content_receiver, ReplacementFor_Progress ReplacementFor_progress) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, std::move(ReplacementFor_response_handler),
                   std::move(ReplacementFor_content_receiver), std::move(ReplacementFor_progress));
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                          ReplacementFor_ResponseHandler ReplacementFor_response_handler,
                          ReplacementFor_ContentReceiver ReplacementFor_content_receiver, ReplacementFor_Progress ReplacementFor_progress) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, ReplacementFor_headers, std::move(ReplacementFor_response_handler),
                   std::move(ReplacementFor_content_receiver), std::move(ReplacementFor_progress));
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, const ReplacementFor_Params &ReplacementFor_params,
                          const ReplacementFor_Headers &ReplacementFor_headers, ReplacementFor_Progress ReplacementFor_progress) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, ReplacementFor_params, ReplacementFor_headers, ReplacementFor_progress);
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, const ReplacementFor_Params &ReplacementFor_params,
                          const ReplacementFor_Headers &ReplacementFor_headers,
                          ReplacementFor_ContentReceiver ReplacementFor_content_receiver, ReplacementFor_Progress ReplacementFor_progress) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, ReplacementFor_params, ReplacementFor_headers, ReplacementFor_content_receiver, ReplacementFor_progress);
}
Result ReplacementFor_Client::Get(const char *ReplacementFor_path, const ReplacementFor_Params &ReplacementFor_params,
                          const ReplacementFor_Headers &ReplacementFor_headers,
                          ReplacementFor_ResponseHandler ReplacementFor_response_handler,
                          ReplacementFor_ContentReceiver ReplacementFor_content_receiver, ReplacementFor_Progress ReplacementFor_progress) {
  return ReplacementFor_cli_->Get(ReplacementFor_path, ReplacementFor_params, ReplacementFor_headers, ReplacementFor_response_handler, ReplacementFor_content_receiver,
                   ReplacementFor_progress);
}

Result ReplacementFor_Client::Head(const char *ReplacementFor_path) { return ReplacementFor_cli_->Head(ReplacementFor_path); }
Result ReplacementFor_Client::Head(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers) {
  return ReplacementFor_cli_->Head(ReplacementFor_path, ReplacementFor_headers);
}

Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path) { return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path); }
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path, const char *ReplacementFor_body,
                           size_t ReplacementFor_content_length, const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                           const char *ReplacementFor_body, size_t ReplacementFor_content_length,
                           const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path, const std::string &ReplacementFor_body,
                           const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_body, ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                           const std::string &ReplacementFor_body, const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body, ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path, size_t ReplacementFor_content_length,
                           ReplacementFor_ContentProvider ReplacementFor_content_provider,
                           const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
                    ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path,
                           ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                           const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                           size_t ReplacementFor_content_length,
                           ReplacementFor_ContentProvider ReplacementFor_content_provider,
                           const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
                    ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                           ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                           const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_headers, std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Params &ReplacementFor_params) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_params);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                           const ReplacementFor_Params &ReplacementFor_params) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_params);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path,
                           const ReplacementFor_MultipartFormDataItems &ReplacementFor_items) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_items);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                           const ReplacementFor_MultipartFormDataItems &ReplacementFor_items) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_items);
}
Result ReplacementFor_Client::ReplacementFor_Post(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                           const ReplacementFor_MultipartFormDataItems &ReplacementFor_items,
                           const std::string &ReplacementFor_boundary) {
  return ReplacementFor_cli_->ReplacementFor_Post(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_items, ReplacementFor_boundary);
}
Result ReplacementFor_Client::Put(const char *ReplacementFor_path) { return ReplacementFor_cli_->Put(ReplacementFor_path); }
Result ReplacementFor_Client::Put(const char *ReplacementFor_path, const char *ReplacementFor_body,
                          size_t ReplacementFor_content_length, const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Put(ReplacementFor_path, ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}
Result ReplacementFor_Client::Put(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                          const char *ReplacementFor_body, size_t ReplacementFor_content_length,
                          const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Put(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}
Result ReplacementFor_Client::Put(const char *ReplacementFor_path, const std::string &ReplacementFor_body,
                          const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Put(ReplacementFor_path, ReplacementFor_body, ReplacementFor_content_type);
}
Result ReplacementFor_Client::Put(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                          const std::string &ReplacementFor_body, const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Put(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body, ReplacementFor_content_type);
}
Result ReplacementFor_Client::Put(const char *ReplacementFor_path, size_t ReplacementFor_content_length,
                          ReplacementFor_ContentProvider ReplacementFor_content_provider,
                          const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Put(ReplacementFor_path, ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
                   ReplacementFor_content_type);
}
Result ReplacementFor_Client::Put(const char *ReplacementFor_path,
                          ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                          const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Put(ReplacementFor_path, std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}
Result ReplacementFor_Client::Put(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                          size_t ReplacementFor_content_length,
                          ReplacementFor_ContentProvider ReplacementFor_content_provider,
                          const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Put(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
                   ReplacementFor_content_type);
}
Result ReplacementFor_Client::Put(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                          ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                          const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Put(ReplacementFor_path, ReplacementFor_headers, std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}
Result ReplacementFor_Client::Put(const char *ReplacementFor_path, const ReplacementFor_Params &ReplacementFor_params) {
  return ReplacementFor_cli_->Put(ReplacementFor_path, ReplacementFor_params);
}
Result ReplacementFor_Client::Put(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                          const ReplacementFor_Params &ReplacementFor_params) {
  return ReplacementFor_cli_->Put(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_params);
}
Result ReplacementFor_Client::ReplacementFor_Patch(const char *ReplacementFor_path) { return ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path); }
Result ReplacementFor_Client::ReplacementFor_Patch(const char *ReplacementFor_path, const char *ReplacementFor_body,
                            size_t ReplacementFor_content_length, const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path, ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Patch(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                            const char *ReplacementFor_body, size_t ReplacementFor_content_length,
                            const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Patch(const char *ReplacementFor_path, const std::string &ReplacementFor_body,
                            const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path, ReplacementFor_body, ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Patch(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                            const std::string &ReplacementFor_body, const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body, ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Patch(const char *ReplacementFor_path, size_t ReplacementFor_content_length,
                            ReplacementFor_ContentProvider ReplacementFor_content_provider,
                            const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path, ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
                     ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Patch(const char *ReplacementFor_path,
                            ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                            const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path, std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Patch(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                            size_t ReplacementFor_content_length,
                            ReplacementFor_ContentProvider ReplacementFor_content_provider,
                            const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_content_length, std::move(ReplacementFor_content_provider),
                     ReplacementFor_content_type);
}
Result ReplacementFor_Client::ReplacementFor_Patch(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                            ReplacementFor_ContentProviderWithoutLength ReplacementFor_content_provider,
                            const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->ReplacementFor_Patch(ReplacementFor_path, ReplacementFor_headers, std::move(ReplacementFor_content_provider), ReplacementFor_content_type);
}
Result ReplacementFor_Client::Delete(const char *ReplacementFor_path) { return ReplacementFor_cli_->Delete(ReplacementFor_path); }
Result ReplacementFor_Client::Delete(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers) {
  return ReplacementFor_cli_->Delete(ReplacementFor_path, ReplacementFor_headers);
}
Result ReplacementFor_Client::Delete(const char *ReplacementFor_path, const char *ReplacementFor_body,
                             size_t ReplacementFor_content_length, const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Delete(ReplacementFor_path, ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}
Result ReplacementFor_Client::Delete(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                             const char *ReplacementFor_body, size_t ReplacementFor_content_length,
                             const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Delete(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body, ReplacementFor_content_length, ReplacementFor_content_type);
}
Result ReplacementFor_Client::Delete(const char *ReplacementFor_path, const std::string &ReplacementFor_body,
                             const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Delete(ReplacementFor_path, ReplacementFor_body, ReplacementFor_content_type);
}
Result ReplacementFor_Client::Delete(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers,
                             const std::string &ReplacementFor_body,
                             const char *ReplacementFor_content_type) {
  return ReplacementFor_cli_->Delete(ReplacementFor_path, ReplacementFor_headers, ReplacementFor_body, ReplacementFor_content_type);
}
Result ReplacementFor_Client::Options(const char *ReplacementFor_path) { return ReplacementFor_cli_->Options(ReplacementFor_path); }
Result ReplacementFor_Client::Options(const char *ReplacementFor_path, const ReplacementFor_Headers &ReplacementFor_headers) {
  return ReplacementFor_cli_->Options(ReplacementFor_path, ReplacementFor_headers);
}

bool ReplacementFor_Client::send(ReplacementFor_Request &ReplacementFor_req, ReplacementFor_Response &ReplacementFor_res, Error &error) {
  return ReplacementFor_cli_->send(ReplacementFor_req, ReplacementFor_res, error);
}

Result ReplacementFor_Client::send(const ReplacementFor_Request &ReplacementFor_req) { return ReplacementFor_cli_->send(ReplacementFor_req); }

size_t ReplacementFor_Client::ReplacementFor_is_socket_open() const { return ReplacementFor_cli_->ReplacementFor_is_socket_open(); }

void ReplacementFor_Client::ReplacementFor_stop() { ReplacementFor_cli_->ReplacementFor_stop(); }

void ReplacementFor_Client::ReplacementFor_set_default_headers(ReplacementFor_Headers ReplacementFor_headers) {
  ReplacementFor_cli_->ReplacementFor_set_default_headers(std::move(ReplacementFor_headers));
}

void ReplacementFor_Client::ReplacementFor_set_tcp_nodelay(bool ReplacementFor_on) { ReplacementFor_cli_->ReplacementFor_set_tcp_nodelay(ReplacementFor_on); }
void ReplacementFor_Client::ReplacementFor_set_socket_options(ReplacementFor_SocketOptions ReplacementFor_socket_options) {
  ReplacementFor_cli_->ReplacementFor_set_socket_options(std::move(ReplacementFor_socket_options));
}

void ReplacementFor_Client::ReplacementFor_set_connection_timeout(time_t sec, time_t ReplacementFor_usec) {
  ReplacementFor_cli_->ReplacementFor_set_connection_timeout(sec, ReplacementFor_usec);
}
void ReplacementFor_Client::ReplacementFor_set_read_timeout(time_t sec, time_t ReplacementFor_usec) {
  ReplacementFor_cli_->ReplacementFor_set_read_timeout(sec, ReplacementFor_usec);
}
void ReplacementFor_Client::ReplacementFor_set_write_timeout(time_t sec, time_t ReplacementFor_usec) {
  ReplacementFor_cli_->ReplacementFor_set_write_timeout(sec, ReplacementFor_usec);
}

void ReplacementFor_Client::ReplacementFor_set_basic_auth(const char *ReplacementFor_username, const char *ReplacementFor_password) {
  ReplacementFor_cli_->ReplacementFor_set_basic_auth(ReplacementFor_username, ReplacementFor_password);
}
void ReplacementFor_Client::ReplacementFor_set_bearer_token_auth(const char *ReplacementFor_token) {
  ReplacementFor_cli_->ReplacementFor_set_bearer_token_auth(ReplacementFor_token);
}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::ReplacementFor_set_digest_auth(const char *ReplacementFor_username,
                                    const char *ReplacementFor_password) {
  ReplacementFor_cli_->ReplacementFor_set_digest_auth(ReplacementFor_username, ReplacementFor_password);
}
#endif

void ReplacementFor_Client::ReplacementFor_set_keep_alive(bool ReplacementFor_on) { ReplacementFor_cli_->ReplacementFor_set_keep_alive(ReplacementFor_on); }
void ReplacementFor_Client::ReplacementFor_set_follow_location(bool ReplacementFor_on) {
  ReplacementFor_cli_->ReplacementFor_set_follow_location(ReplacementFor_on);
}

void ReplacementFor_Client::ReplacementFor_set_compress(bool ReplacementFor_on) { ReplacementFor_cli_->ReplacementFor_set_compress(ReplacementFor_on); }

void ReplacementFor_Client::ReplacementFor_set_decompress(bool ReplacementFor_on) { ReplacementFor_cli_->ReplacementFor_set_decompress(ReplacementFor_on); }

void ReplacementFor_Client::ReplacementFor_set_interface(const char *intf) {
  ReplacementFor_cli_->ReplacementFor_set_interface(intf);
}

void ReplacementFor_Client::ReplacementFor_set_proxy(const char *ReplacementFor_host, int ReplacementFor_port) {
  ReplacementFor_cli_->ReplacementFor_set_proxy(ReplacementFor_host, ReplacementFor_port);
}
void ReplacementFor_Client::ReplacementFor_set_proxy_basic_auth(const char *ReplacementFor_username,
                                         const char *ReplacementFor_password) {
  ReplacementFor_cli_->ReplacementFor_set_proxy_basic_auth(ReplacementFor_username, ReplacementFor_password);
}
void ReplacementFor_Client::ReplacementFor_set_proxy_bearer_token_auth(const char *ReplacementFor_token) {
  ReplacementFor_cli_->ReplacementFor_set_proxy_bearer_token_auth(ReplacementFor_token);
}
#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::ReplacementFor_set_proxy_digest_auth(const char *ReplacementFor_username,
                                          const char *ReplacementFor_password) {
  ReplacementFor_cli_->ReplacementFor_set_proxy_digest_auth(ReplacementFor_username, ReplacementFor_password);
}
#endif

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::ReplacementFor_enable_server_certificate_verification(bool ReplacementFor_enabled) {
  ReplacementFor_cli_->ReplacementFor_enable_server_certificate_verification(ReplacementFor_enabled);
}
#endif

void ReplacementFor_Client::ReplacementFor_set_logger(ReplacementFor_Logger ReplacementFor_logger) { ReplacementFor_cli_->ReplacementFor_set_logger(ReplacementFor_logger); }

#ifdef ReplacementFor_CPPHTTPLIB_OPENSSL_SUPPORT
void ReplacementFor_Client::ReplacementFor_set_ca_cert_path(const char *ReplacementFor_ca_cert_file_path,
                                     const char *ReplacementFor_ca_cert_dir_path) {
  if (ReplacementFor_is_ssl_) {
    static_cast<ReplacementFor_SSLClient &>(*ReplacementFor_cli_).ReplacementFor_set_ca_cert_path(ReplacementFor_ca_cert_file_path,
                                                     ReplacementFor_ca_cert_dir_path);
  }
}

void ReplacementFor_Client::ReplacementFor_set_ca_cert_store(ReplacementFor_X509_STORE *ReplacementFor_ca_cert_store) {
  if (ReplacementFor_is_ssl_) {
    static_cast<ReplacementFor_SSLClient &>(*ReplacementFor_cli_).ReplacementFor_set_ca_cert_store(ReplacementFor_ca_cert_store);
  }
}

long ReplacementFor_Client::ReplacementFor_get_openssl_verify_result() const {
  if (ReplacementFor_is_ssl_) {
    return static_cast<ReplacementFor_SSLClient &>(*ReplacementFor_cli_).ReplacementFor_get_openssl_verify_result();
  }
  return -1; 
}

ReplacementFor_SSL_CTX *ReplacementFor_Client::ReplacementFor_ssl_context() const {
  if (ReplacementFor_is_ssl_) { return static_cast<ReplacementFor_SSLClient &>(*ReplacementFor_cli_).ReplacementFor_ssl_context(); }
  return nullptr;
}
#endif

} 


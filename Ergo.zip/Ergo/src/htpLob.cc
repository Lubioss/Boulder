
#include "../include/htpLob.h"
namespace htpLob{namespace detail{bool is_hex(char c,int&v){if((0xc19+90-0xc53)
<=c&&isdigit(c)){v=c-((char)(0x67a+3893-0x157f));return true;}else if(
((char)(0x4dd+6010-0x1c16))<=c&&c<=((char)(0x64b+1766-0xceb))){v=c-
((char)(0x2545+256-0x2604))+(0x15e5+3340-0x22e7);return true;}else if(
((char)(0x1565+202-0x15ce))<=c&&c<=((char)(0xa57+6501-0x2356))){v=c-
((char)(0x1c12+453-0x1d76))+(0x4d6+591-0x71b);return true;}return false;}bool 
from_hex_to_i(const std::string&s,size_t i,size_t cnt,int&val){if(i>=s.size()){
return false;}val=(0x7d0+5678-0x1dfe);for(;cnt;i++,cnt--){if(!s[i]){return false
;}int v=(0x4f+650-0x2d9);if(is_hex(s[i],v)){val=val*(0x147c+3836-0x2368)+v;}else
{return false;}}return true;}std::string from_i_to_hex(size_t n){const char*
charset="\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x61\x62\x63\x64\x65\x66";std::
string ret;do{ret=charset[n&(0x1f82+1493-0x2548)]+ret;n>>=(0x1329+3848-0x222d);}
while(n>(0x795+2215-0x103c));return ret;}size_t to_utf8(int code,char*buff){if(
code<(0x1bd+6682-0x1b57)){buff[(0x7f5+6670-0x2203)]=(code&(0x437+8318-0x2436));
return(0xa70+6135-0x2266);}else if(code<(0xb02+39-0x329)){buff[
(0x807+4769-0x1aa8)]=static_cast<char>((0x3e8+4457-0x1491)|((code>>
(0x337+8421-0x2416))&(0x110f+3093-0x1d05)));buff[(0xdb9+2001-0x1589)]=
static_cast<char>((0x12d5+813-0x1582)|(code&(0x1c65+498-0x1e18)));return
(0x917+2106-0x114f);}else if(code<55296){buff[(0xb48+3435-0x18b3)]=static_cast<
char>((0x1066+5499-0x2501)|((code>>(0xd55+841-0x1092))&(0x379+4758-0x1600)));
buff[(0x1789+2449-0x2119)]=static_cast<char>((0x1948+3065-0x24c1)|((code>>
(0xf0f+455-0x10d0))&(0x15cd+2514-0x1f60)));buff[(0x9b1+7283-0x2622)]=static_cast
<char>((0x1436+4106-0x23c0)|(code&(0xcff+3548-0x1a9c)));return
(0xd39+2061-0x1543);}else if(code<57344){return(0xa1d+5512-0x1fa5);}else if(code
<65536){buff[(0x95f+506-0xb59)]=static_cast<char>((0xf4d+866-0x11cf)|((code>>
(0x615+6631-0x1ff0))&(0x2100+126-0x216f)));buff[(0x492+3049-0x107a)]=static_cast
<char>((0x3c5+4143-0x1374)|((code>>(0xfa2+925-0x1339))&(0x313+5547-0x187f)));
buff[(0x3b7+3288-0x108d)]=static_cast<char>((0x244+3375-0xef3)|(code&
(0x2da+5750-0x1911)));return(0x779+1951-0xf15);}else if(code<1114112){buff[
(0x18b1+3640-0x26e9)]=static_cast<char>((0x8c7+4554-0x19a1)|((code>>
(0xa48+50-0xa68))&(0x153+2122-0x996)));buff[(0x393+398-0x520)]=static_cast<char>
((0x2b0+2472-0xbd8)|((code>>(0x5c6+1287-0xac1))&(0x226+9153-0x25a8)));buff[
(0xd79+28-0xd93)]=static_cast<char>((0x194f+1946-0x2069)|((code>>
(0x4f4+6644-0x1ee2))&(0x380+5782-0x19d7)));buff[(0x8a2+529-0xab0)]=static_cast<
char>((0x1005+2749-0x1a42)|(code&(0x11b4+1607-0x17bc)));return(0x2c2+689-0x56f);
}return(0x16e4+2536-0x20cc);}std::string base64_encode(const std::string&in){
static const auto lookup=
"\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x2b\x2f"
;std::string out;out.reserve(in.size());int val=(0x687+5910-0x1d9d);int valb=-
(0x761+5349-0x1c40);for(auto c:in){val=(val<<(0x1698+4055-0x2667))+static_cast<
uint8_t>(c);valb+=(0x1de4+75-0x1e27);while(valb>=(0x640+7116-0x220c)){out.
push_back(lookup[(val>>valb)&(0xb84+561-0xd76)]);valb-=(0x21f9+95-0x2252);}}if(
valb>-(0x283+5517-0x180a)){out.push_back(lookup[((val<<(0x192+3405-0xed7))>>(
valb+(0x1f93+1554-0x259d)))&(0xd1b+6329-0x2595)]);}while(out.size()%
(0x1567+4506-0x26fd)){out.push_back(((char)(0xcc1+3173-0x18e9)));}return out;}
bool is_file(const std::string&path){struct stat st;return stat(path.c_str(),&st
)>=(0x96c+5128-0x1d74)&&S_ISREG(st.st_mode);}bool is_dir(const std::string&path)
{struct stat st;return stat(path.c_str(),&st)>=(0xd85+4618-0x1f8f)&&S_ISDIR(st.
st_mode);}bool is_valid_path(const std::string&path){size_t level=
(0xc61+4629-0x1e76);size_t i=(0x27f+8379-0x233a);while(i<path.size()&&path[i]==
((char)(0xc6d+5845-0x2313))){i++;}while(i<path.size()){auto beg=i;while(i<path.
size()&&path[i]!=((char)(0x11c+8496-0x221d))){i++;}auto len=i-beg;assert(len>
(0x1575+799-0x1894));if(!path.compare(beg,len,"\x2e")){;}else if(!path.compare(
beg,len,"\x2e\x2e")){if(level==(0x6f+2069-0x884)){return false;}level--;}else{
level++;}while(i<path.size()&&path[i]==((char)(0xcaf+4087-0x1c77))){i++;}}return
 true;}std::string encode_query_param(const std::string&value){std::
ostringstream escaped;escaped.fill(((char)(0xc6c+4828-0x1f18)));escaped<<std::
hex;for(auto c:value){if(std::isalnum(static_cast<uint8_t>(c))||c==
((char)(0x36b+2237-0xbfb))||c==((char)(0x95b+6446-0x222a))||c==
((char)(0x6ef+2419-0x1034))||c==((char)(0xb02+1420-0x106d))||c==
((char)(0xdf6+2462-0x1716))||c==((char)(0xe2d+5491-0x2376))||c=='\''||c==
((char)(0x885+3840-0x175d))||c==((char)(0x363+4486-0x14c0))){escaped<<c;}else{
escaped<<std::uppercase;escaped<<((char)(0xebc+541-0x10b4))<<std::setw(
(0x631+5807-0x1cde))<<static_cast<int>(static_cast<unsigned char>(c));escaped<<
std::nouppercase;}}return escaped.str();}std::string encode_url(const std::
string&s){std::string result;for(size_t i=(0x30+2797-0xb1d);s[i];i++){switch(s[i
]){case((char)(0x1215+1540-0x17f9)):result+="\x25\x32\x30";break;case
((char)(0x1206+2393-0x1b34)):result+="\x25\x32\x42";break;case'\r':result+=
"\x25\x30\x44";break;case'\n':result+="\x25\x30\x41";break;case'\'':result+=
"\x25\x32\x37";break;case((char)(0x847+634-0xa95)):result+="\x25\x32\x43";break;
case((char)(0x445+2048-0xc0a)):result+="\x25\x33\x42";break;default:auto c=
static_cast<uint8_t>(s[i]);if(c>=(0x1198+3048-0x1d00)){result+=
((char)(0x65+8697-0x2239));char hex[(0x77d+518-0x97f)];auto len=snprintf(hex,
sizeof(hex)-(0xb10+2330-0x1429),"\x25\x30\x32\x58",c);assert(len==
(0x992+1962-0x113a));result.append(hex,static_cast<size_t>(len));}else{result+=s
[i];}break;}}return result;}std::string decode_url(const std::string&s,bool 
convert_plus_to_space){std::string result;for(size_t i=(0x24f+1873-0x9a0);i<s.
size();i++){if(s[i]==((char)(0x1f7+4533-0x1387))&&i+(0x1e91+2132-0x26e4)<s.size(
)){if(s[i+(0x9a4+7020-0x250f)]==((char)(0xd8b+2408-0x167e))){int val=
(0x2ca+4887-0x15e1);if(from_hex_to_i(s,i+(0x874+646-0xaf8),(0x1685+682-0x192b),
val)){char buff[(0x2227+1017-0x261c)];size_t len=to_utf8(val,buff);if(len>
(0xe12+2514-0x17e4)){result.append(buff,len);}i+=(0x2f5+6446-0x1c1e);}else{
result+=s[i];}}else{int val=(0xc58+3521-0x1a19);if(from_hex_to_i(s,i+
(0xedd+4174-0x1f2a),(0x738+1261-0xc23),val)){result+=static_cast<char>(val);i+=
(0x4a1+5819-0x1b5a);}else{result+=s[i];}}}else if(convert_plus_to_space&&s[i]==
((char)(0xd72+2964-0x18db))){result+=((char)(0x7e0+4532-0x1974));}else{result+=s
[i];}}return result;}void read_file(const std::string&path,std::string&out){std
::ifstream fs(path,std::ios_base::binary);fs.seekg((0x1fba+801-0x22db),std::
ios_base::end);auto size=fs.tellg();fs.seekg((0x38a+2073-0xba3));out.resize(
static_cast<size_t>(size));fs.read(&out[(0x13c5+2449-0x1d56)],static_cast<std::
streamsize>(size));}std::string file_extension(const std::string&path){std::
smatch m;static auto re=std::regex(
"\\" "\x2e\x28\x5b\x61\x2d\x7a\x41\x2d\x5a\x30\x2d\x39\x5d\x2b\x29\x24");if(std
::regex_search(path,m,re)){return m[(0x151+3906-0x1092)].str();}return std::
string();}bool is_space_or_tab(char c){return c==((char)(0x13db+1074-0x17ed))||c
=='\t';}std::pair<size_t,size_t>trim(const char*b,const char*e,size_t left,
size_t right){while(b+left<e&&is_space_or_tab(b[left])){left++;}while(right>
(0x4+5127-0x140b)&&is_space_or_tab(b[right-(0xdf1+1803-0x14fb)])){right--;}
return std::make_pair(left,right);}std::string trim_copy(const std::string&s){
auto r=trim(s.data(),s.data()+s.size(),(0xba0+6824-0x2648),s.size());return s.
substr(r.first,r.second-r.first);}template<class Fn>void split(const char*b,
const char*e,char d,Fn fn){size_t i=(0x23f+7468-0x1f6b);size_t beg=
(0x902+1602-0xf44);while(e?(b+i<e):(b[i]!='\0')){if(b[i]==d){auto r=trim(b,e,beg
,i);if(r.first<r.second){fn(&b[r.first],&b[r.second]);}beg=i+(0x392+2338-0xcb3);
}i++;}if(i){auto r=trim(b,e,beg,i);if(r.first<r.second){fn(&b[r.first],&b[r.
second]);}}}class stream_line_reader{public:stream_line_reader(Stream&strm,char*
fixed_buffer,size_t fixed_buffer_size):strm_(strm),fixed_buffer_(fixed_buffer),
fixed_buffer_size_(fixed_buffer_size){}const char*ptr()const{if(glowable_buffer_
.empty()){return fixed_buffer_;}else{return glowable_buffer_.data();}}size_t 
size()const{if(glowable_buffer_.empty()){return fixed_buffer_used_size_;}else{
return glowable_buffer_.size();}}bool end_with_crlf()const{auto end=ptr()+size()
;return size()>=(0x59c+1176-0xa32)&&end[-(0xf60+2157-0x17cb)]=='\r'&&end[-
(0xa32+1167-0xec0)]=='\n';}bool getline(){fixed_buffer_used_size_=
(0x2ca+3900-0x1206);glowable_buffer_.clear();for(size_t i=(0x9d6+5436-0x1f12);;i
++){char byte;auto n=strm_.read(&byte,(0x186b+2682-0x22e4));if(n<
(0x1669+72-0x16b1)){return false;}else if(n==(0xce0+3238-0x1986)){if(i==
(0xf1+116-0x165)){return false;}else{break;}}append(byte);if(byte=='\n'){break;}
}return true;}private:void append(char c){if(fixed_buffer_used_size_<
fixed_buffer_size_-(0x11bb+3773-0x2077)){fixed_buffer_[fixed_buffer_used_size_++
]=c;fixed_buffer_[fixed_buffer_used_size_]='\0';}else{if(glowable_buffer_.empty(
)){assert(fixed_buffer_[fixed_buffer_used_size_]=='\0');glowable_buffer_.assign(
fixed_buffer_,fixed_buffer_used_size_);}glowable_buffer_+=c;}}Stream&strm_;char*
fixed_buffer_;const size_t fixed_buffer_size_;size_t fixed_buffer_used_size_=
(0x23d+5261-0x16ca);std::string glowable_buffer_;};int close_socket(socket_t 
sock){
#ifdef _WIN32
return closesocket(sock);
#else
return close(sock);
#endif
}template<typename T>ssize_t handle_EINTR(T fn){ssize_t res=false;while(true){
res=fn();if(res<(0x3+547-0x226)&&errno==EINTR){continue;}break;}return res;}
ssize_t select_read(socket_t sock,time_t sec,time_t usec){
#ifdef CPPHTTPLIB_USE_POLL
struct pollfd pfd_read;pfd_read.fd=sock;pfd_read.events=POLLIN;auto timeout=
static_cast<int>(sec*(0x10d6+2781-0x17cb)+usec/(0x1418+2661-0x1a95));return 
handle_EINTR([&](){return poll(&pfd_read,(0x1b2+7969-0x20d2),timeout);});
#else
#ifndef _WIN32
if(sock>=FD_SETSIZE){return(0x75a+578-0x99b);}
#endif
fd_set fds;FD_ZERO(&fds);FD_SET(sock,&fds);timeval tv;tv.tv_sec=static_cast<long
>(sec);tv.tv_usec=static_cast<decltype(tv.tv_usec)>(usec);return handle_EINTR([&
](){return select(static_cast<int>(sock+(0x96d+738-0xc4e)),&fds,nullptr,nullptr,
&tv);});
#endif
}ssize_t select_write(socket_t sock,time_t sec,time_t usec){
#ifdef CPPHTTPLIB_USE_POLL
struct pollfd pfd_read;pfd_read.fd=sock;pfd_read.events=POLLOUT;auto timeout=
static_cast<int>(sec*1000+usec/(0xfc2+3647-0x1a19));return handle_EINTR([&](){
return poll(&pfd_read,(0xa97+2059-0x12a1),timeout);});
#else
#ifndef _WIN32
if(sock>=FD_SETSIZE){return(0x13f9+2764-0x1ec4);}
#endif
fd_set fds;FD_ZERO(&fds);FD_SET(sock,&fds);timeval tv;tv.tv_sec=static_cast<long
>(sec);tv.tv_usec=static_cast<decltype(tv.tv_usec)>(usec);return handle_EINTR([&
](){return select(static_cast<int>(sock+(0x44b+6280-0x1cd2)),nullptr,&fds,
nullptr,&tv);});
#endif
}bool wait_until_socket_is_ready(socket_t sock,time_t sec,time_t usec){
#ifdef CPPHTTPLIB_USE_POLL
struct pollfd pfd_read;pfd_read.fd=sock;pfd_read.events=POLLIN|POLLOUT;auto 
timeout=static_cast<int>(sec*(0x268b+416-0x2443)+usec/(0x6e1+259-0x3fc));auto 
poll_res=handle_EINTR([&](){return poll(&pfd_read,(0xa0d+4152-0x1a44),timeout);}
);if(poll_res>(0x1545+2468-0x1ee9)&&pfd_read.revents&(POLLIN|POLLOUT)){int error
=(0xc3a+5953-0x237b);socklen_t len=sizeof(error);auto res=getsockopt(sock,
SOL_SOCKET,SO_ERROR,reinterpret_cast<char*>(&error),&len);return res>=
(0x44d+1905-0xbbe)&&!error;}return false;
#else
#ifndef _WIN32
if(sock>=FD_SETSIZE){return false;}
#endif
fd_set fdsr;FD_ZERO(&fdsr);FD_SET(sock,&fdsr);auto fdsw=fdsr;auto fdse=fdsr;
timeval tv;tv.tv_sec=static_cast<long>(sec);tv.tv_usec=static_cast<decltype(tv.
tv_usec)>(usec);auto ret=handle_EINTR([&](){return select(static_cast<int>(sock+
(0x19c8+1045-0x1ddc)),&fdsr,&fdsw,&fdse,&tv);});if(ret>(0x184a+1163-0x1cd5)&&(
FD_ISSET(sock,&fdsr)||FD_ISSET(sock,&fdsw))){int error=(0x31a+1424-0x8aa);
socklen_t len=sizeof(error);return getsockopt(sock,SOL_SOCKET,SO_ERROR,
reinterpret_cast<char*>(&error),&len)>=(0x19df+391-0x1b66)&&!error;}return false
;
#endif
}class SocketStream:public Stream{public:SocketStream(socket_t sock,time_t 
read_timeout_sec,time_t read_timeout_usec,time_t write_timeout_sec,time_t 
write_timeout_usec);~SocketStream()override;bool is_readable()const override;
bool is_writable()const override;ssize_t read(char*ptr,size_t size)override;
ssize_t write(const char*ptr,size_t size)override;void get_remote_ip_and_port(
std::string&ip,int&port)const override;socket_t socket()const override;private:
socket_t sock_;time_t read_timeout_sec_;time_t read_timeout_usec_;time_t 
write_timeout_sec_;time_t write_timeout_usec_;};
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
class SSLSocketStream:public Stream{public:SSLSocketStream(socket_t sock,SSL*ssl
,time_t read_timeout_sec,time_t read_timeout_usec,time_t write_timeout_sec,
time_t write_timeout_usec);~SSLSocketStream()override;bool is_readable()const 
override;bool is_writable()const override;ssize_t read(char*ptr,size_t size)
override;ssize_t write(const char*ptr,size_t size)override;void 
get_remote_ip_and_port(std::string&ip,int&port)const override;socket_t socket()
const override;private:socket_t sock_;SSL*ssl_;time_t read_timeout_sec_;time_t 
read_timeout_usec_;time_t write_timeout_sec_;time_t write_timeout_usec_;};
#endif
class BufferStream:public Stream{public:BufferStream()=default;~BufferStream()
override=default;bool is_readable()const override;bool is_writable()const 
override;ssize_t read(char*ptr,size_t size)override;ssize_t write(const char*ptr
,size_t size)override;void get_remote_ip_and_port(std::string&ip,int&port)const 
override;socket_t socket()const override;const std::string&get_buffer()const;
private:std::string buffer;size_t position=(0xf0d+5687-0x2544);};bool keep_alive
(socket_t sock,time_t keep_alive_timeout_sec){using namespace std::chrono;auto 
start=steady_clock::now();while(true){auto val=select_read(sock,
(0x50c+3402-0x1256),10000);if(val<(0xd1c+1946-0x14b6)){return false;}else if(val
==(0x263+8065-0x21e4)){auto current=steady_clock::now();auto duration=
duration_cast<milliseconds>(current-start);auto timeout=keep_alive_timeout_sec*
(0x20b3+386-0x1e4d);if(duration.count()>timeout){return false;}std::this_thread
::sleep_for(std::chrono::milliseconds((0xb40+681-0xde8)));}else{return true;}}}
template<typename T>bool process_server_socket_core(socket_t sock,size_t 
keep_alive_max_count,time_t keep_alive_timeout_sec,T callback){assert(
keep_alive_max_count>(0x1039+2554-0x1a33));auto ret=false;auto count=
keep_alive_max_count;while(count>(0x10e6+1469-0x16a3)&&keep_alive(sock,
keep_alive_timeout_sec)){auto close_connection=count==(0xb52+5705-0x219a);auto 
connection_closed=false;ret=callback(close_connection,connection_closed);if(!ret
||connection_closed){break;}count--;}return ret;}template<typename T>bool 
process_server_socket(socket_t sock,size_t keep_alive_max_count,time_t 
keep_alive_timeout_sec,time_t read_timeout_sec,time_t read_timeout_usec,time_t 
write_timeout_sec,time_t write_timeout_usec,T callback){return 
process_server_socket_core(sock,keep_alive_max_count,keep_alive_timeout_sec,[&](
bool close_connection,bool&connection_closed){SocketStream strm(sock,
read_timeout_sec,read_timeout_usec,write_timeout_sec,write_timeout_usec);return 
callback(strm,close_connection,connection_closed);});}template<typename T>bool 
process_client_socket(socket_t sock,time_t read_timeout_sec,time_t 
read_timeout_usec,time_t write_timeout_sec,time_t write_timeout_usec,T callback)
{SocketStream strm(sock,read_timeout_sec,read_timeout_usec,write_timeout_sec,
write_timeout_usec);return callback(strm);}int shutdown_socket(socket_t sock){
#ifdef _WIN32
return shutdown(sock,SD_BOTH);
#else
return shutdown(sock,SHUT_RDWR);
#endif
}template<typename BindOrConnect>socket_t create_socket(const char*host,int port
,int socket_flags,bool tcp_nodelay,SocketOptions socket_options,BindOrConnect 
bind_or_connect){struct addrinfo hints;struct addrinfo*result;memset(&hints,
(0x346+9076-0x26ba),sizeof(struct addrinfo));hints.ai_family=AF_UNSPEC;hints.
ai_socktype=SOCK_STREAM;hints.ai_flags=socket_flags;hints.ai_protocol=
(0x2086+484-0x226a);auto service=std::to_string(port);if(getaddrinfo(host,
service.c_str(),&hints,&result)){
#ifdef __linux__
res_init();
#endif
return INVALID_SOCKET;}for(auto rp=result;rp;rp=rp->ai_next){
#ifdef _WIN32
auto sock=WSASocketW(rp->ai_family,rp->ai_socktype,rp->ai_protocol,nullptr,
(0x970+1082-0xdaa),WSA_FLAG_NO_HANDLE_INHERIT);if(sock==INVALID_SOCKET){sock=
socket(rp->ai_family,rp->ai_socktype,rp->ai_protocol);}
#else
auto sock=socket(rp->ai_family,rp->ai_socktype,rp->ai_protocol);
#endif
if(sock==INVALID_SOCKET){continue;}
#ifndef _WIN32
if(fcntl(sock,F_SETFD,FD_CLOEXEC)==-(0x583+4168-0x15ca)){continue;}
#endif
if(tcp_nodelay){int yes=(0xdc+7072-0x1c7b);setsockopt(sock,IPPROTO_TCP,
TCP_NODELAY,reinterpret_cast<char*>(&yes),sizeof(yes));}if(socket_options){
socket_options(sock);}if(rp->ai_family==AF_INET6){int no=(0x311+7314-0x1fa3);
setsockopt(sock,IPPROTO_IPV6,IPV6_V6ONLY,reinterpret_cast<char*>(&no),sizeof(no)
);}if(bind_or_connect(sock,*rp)){freeaddrinfo(result);return sock;}close_socket(
sock);}freeaddrinfo(result);return INVALID_SOCKET;}void set_nonblocking(socket_t
 sock,bool nonblocking){
#ifdef _WIN32
auto flags=nonblocking?1UL:0UL;ioctlsocket(sock,FIONBIO,&flags);
#else
auto flags=fcntl(sock,F_GETFL,(0xc3+1790-0x7c1));fcntl(sock,F_SETFL,nonblocking?
(flags|O_NONBLOCK):(flags&(~O_NONBLOCK)));
#endif
}bool is_connection_error(){
#ifdef _WIN32
return WSAGetLastError()!=WSAEWOULDBLOCK;
#else
return errno!=EINPROGRESS;
#endif
}bool bind_ip_address(socket_t sock,const char*host){struct addrinfo hints;
struct addrinfo*result;memset(&hints,(0x22bb+160-0x235b),sizeof(struct addrinfo)
);hints.ai_family=AF_UNSPEC;hints.ai_socktype=SOCK_STREAM;hints.ai_protocol=
(0x1800+2031-0x1fef);if(getaddrinfo(host,"\x30",&hints,&result)){return false;}
auto ret=false;for(auto rp=result;rp;rp=rp->ai_next){const auto&ai=*rp;if(!::
bind(sock,ai.ai_addr,static_cast<socklen_t>(ai.ai_addrlen))){ret=true;break;}}
freeaddrinfo(result);return ret;}
#if !defined _WIN32 && !defined ANDROID
#define USE_IF2IP
#endif
#ifdef USE_IF2IP
std::string if2ip(const std::string&ifn){struct ifaddrs*ifap;getifaddrs(&ifap);
for(auto ifa=ifap;ifa;ifa=ifa->ifa_next){if(ifa->ifa_addr&&ifn==ifa->ifa_name){
if(ifa->ifa_addr->sa_family==AF_INET){auto sa=reinterpret_cast<struct 
sockaddr_in*>(ifa->ifa_addr);char buf[INET_ADDRSTRLEN];if(inet_ntop(AF_INET,&sa
->sin_addr,buf,INET_ADDRSTRLEN)){freeifaddrs(ifap);return std::string(buf,
INET_ADDRSTRLEN);}}}}freeifaddrs(ifap);return std::string();}
#endif
socket_t create_client_socket(const char*host,int port,bool tcp_nodelay,
SocketOptions socket_options,time_t timeout_sec,time_t timeout_usec,const std::
string&intf,Error&error){auto sock=create_socket(host,port,(0x2366+666-0x2600),
tcp_nodelay,std::move(socket_options),[&](socket_t sock,struct addrinfo&ai)->
bool{if(!intf.empty()){
#ifdef USE_IF2IP
auto ip=if2ip(intf);if(ip.empty()){ip=intf;}if(!bind_ip_address(sock,ip.c_str())
){error=Error::BindIPAddress;return false;}
#endif
}set_nonblocking(sock,true);auto ret=::connect(sock,ai.ai_addr,static_cast<
socklen_t>(ai.ai_addrlen));if(ret<(0x491+8763-0x26cc)){if(is_connection_error()
||!wait_until_socket_is_ready(sock,timeout_sec,timeout_usec)){close_socket(sock)
;error=Error::Connection;return false;}}set_nonblocking(sock,false);error=Error
::Success;return true;});if(sock!=INVALID_SOCKET){error=Error::Success;}else{if(
error==Error::Success){error=Error::Connection;}}return sock;}void 
get_remote_ip_and_port(const struct sockaddr_storage&addr,socklen_t addr_len,std
::string&ip,int&port){if(addr.ss_family==AF_INET){port=ntohs(reinterpret_cast<
const struct sockaddr_in*>(&addr)->sin_port);}else if(addr.ss_family==AF_INET6){
port=ntohs(reinterpret_cast<const struct sockaddr_in6*>(&addr)->sin6_port);}std
::array<char,NI_MAXHOST>ipstr{};if(!getnameinfo(reinterpret_cast<const struct 
sockaddr*>(&addr),addr_len,ipstr.data(),static_cast<socklen_t>(ipstr.size()),
nullptr,(0x617+2603-0x1042),NI_NUMERICHOST)){ip=ipstr.data();}}void 
get_remote_ip_and_port(socket_t sock,std::string&ip,int&port){struct 
sockaddr_storage addr;socklen_t addr_len=sizeof(addr);if(!getpeername(sock,
reinterpret_cast<struct sockaddr*>(&addr),&addr_len)){get_remote_ip_and_port(
addr,addr_len,ip,port);}}constexpr unsigned int str2tag_core(const char*s,size_t
 l,unsigned int h){return(l==(0x724+5200-0x1b74))?h:str2tag_core(s+
(0x1c0f+778-0x1f18),l-(0xe1b+2979-0x19bd),(h*(0x8d3+279-0x9c9))^static_cast<
unsigned char>(*s));}unsigned int str2tag(const std::string&s){return 
str2tag_core(s.data(),s.size(),(0x93d+6549-0x22d2));}namespace udl{constexpr 
unsigned int operator"" _(const char*s,size_t l){return str2tag_core(s,l,
(0x4c6+1168-0x956));}}const char*find_content_type(const std::string&path,const 
std::map<std::string,std::string>&user_data){auto ext=file_extension(path);auto 
it=user_data.find(ext);if(it!=user_data.end()){return it->second.c_str();}using 
udl::operator""_;switch(str2tag(ext)){default:return nullptr;case"\x63\x73\x73"_
:return"\x74\x65\x78\x74\x2f\x63\x73\x73";case"\x63\x73\x76"_:return
"\x74\x65\x78\x74\x2f\x63\x73\x76";case"\x74\x78\x74"_:return
"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e";case"\x76\x74\x74"_:return
"\x74\x65\x78\x74\x2f\x76\x74\x74";case"\x68\x74\x6d"_:case"\x68\x74\x6d\x6c"_:
return"\x74\x65\x78\x74\x2f\x68\x74\x6d\x6c";case"\x61\x70\x6e\x67"_:return
"\x69\x6d\x61\x67\x65\x2f\x61\x70\x6e\x67";case"\x61\x76\x69\x66"_:return
"\x69\x6d\x61\x67\x65\x2f\x61\x76\x69\x66";case"\x62\x6d\x70"_:return
"\x69\x6d\x61\x67\x65\x2f\x62\x6d\x70";case"\x67\x69\x66"_:return
"\x69\x6d\x61\x67\x65\x2f\x67\x69\x66";case"\x70\x6e\x67"_:return
"\x69\x6d\x61\x67\x65\x2f\x70\x6e\x67";case"\x73\x76\x67"_:return
"\x69\x6d\x61\x67\x65\x2f\x73\x76\x67\x2b\x78\x6d\x6c";case"\x77\x65\x62\x70"_:
return"\x69\x6d\x61\x67\x65\x2f\x77\x65\x62\x70";case"\x69\x63\x6f"_:return
"\x69\x6d\x61\x67\x65\x2f\x78\x2d\x69\x63\x6f\x6e";case"\x74\x69\x66"_:return
"\x69\x6d\x61\x67\x65\x2f\x74\x69\x66\x66";case"\x74\x69\x66\x66"_:return
"\x69\x6d\x61\x67\x65\x2f\x74\x69\x66\x66";case"\x6a\x70\x67"_:case
"\x6a\x70\x65\x67"_:return"\x69\x6d\x61\x67\x65\x2f\x6a\x70\x65\x67";case
"\x6d\x70\x34"_:return"\x76\x69\x64\x65\x6f\x2f\x6d\x70\x34";case
"\x6d\x70\x65\x67"_:return"\x76\x69\x64\x65\x6f\x2f\x6d\x70\x65\x67";case
"\x77\x65\x62\x6d"_:return"\x76\x69\x64\x65\x6f\x2f\x77\x65\x62\x6d";case
"\x6d\x70\x33"_:return"\x61\x75\x64\x69\x6f\x2f\x6d\x70\x33";case
"\x6d\x70\x67\x61"_:return"\x61\x75\x64\x69\x6f\x2f\x6d\x70\x65\x67";case
"\x77\x65\x62\x61"_:return"\x61\x75\x64\x69\x6f\x2f\x77\x65\x62\x6d";case
"\x77\x61\x76"_:return"\x61\x75\x64\x69\x6f\x2f\x77\x61\x76\x65";case
"\x6f\x74\x66"_:return"\x66\x6f\x6e\x74\x2f\x6f\x74\x66";case"\x74\x74\x66"_:
return"\x66\x6f\x6e\x74\x2f\x74\x74\x66";case"\x77\x6f\x66\x66"_:return
"\x66\x6f\x6e\x74\x2f\x77\x6f\x66\x66";case"\x77\x6f\x66\x66\x32"_:return
"\x66\x6f\x6e\x74\x2f\x77\x6f\x66\x66\x32";case"\x37\x7a"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x37\x7a\x2d\x63\x6f\x6d\x70\x72\x65\x73\x73\x65\x64"
;case"\x61\x74\x6f\x6d"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x61\x74\x6f\x6d\x2b\x78\x6d\x6c"
;case"\x70\x64\x66"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x70\x64\x66";case"\x6a\x73"_:
case"\x6d\x6a\x73"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x61\x76\x61\x73\x63\x72\x69\x70\x74"
;case"\x6a\x73\x6f\x6e"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e";case
"\x72\x73\x73"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x72\x73\x73\x2b\x78\x6d\x6c";
case"\x74\x61\x72"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x74\x61\x72";case
"\x78\x68\x74"_:case"\x78\x68\x74\x6d\x6c"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x68\x74\x6d\x6c\x2b\x78\x6d\x6c"
;case"\x78\x73\x6c\x74"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x73\x6c\x74\x2b\x78\x6d\x6c"
;case"\x78\x6d\x6c"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x6d\x6c";case"\x67\x7a"_:
return"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x67\x7a\x69\x70";case
"\x7a\x69\x70"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x7a\x69\x70";case
"\x77\x61\x73\x6d"_:return
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x77\x61\x73\x6d";}}const char*
status_message(int status){switch(status){case(0x364+6972-0x1e3c):return"\x43";
case(0xa4a+2920-0x154d):return"\x53\x20\x50";case(0x1308+4622-0x24b0):return
"\x50";case(0x9ad+1810-0x1058):return"\x45\x20\x48";case(0x651+7310-0x2217):
return"\x4f\x4b";case(0x1175+1371-0x1607):return"\x43";case(0x5f9+7174-0x2135):
return"\x41";case(0x1ea4+684-0x2085):return
"\x4e\x41\x20\x49\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e";case
(0x20e0+1635-0x2677):return"\x4e\x20\x43";case(0x1b7b+2009-0x2287):return
"\x52\x20\x43";case(0x1d07+2596-0x265d):return"\x50\x20\x43";case
(0x2b7+311-0x31f):return"\x4d\x2d\x53";case(0x7d4+5237-0x1b79):return
"\x41\x20\x52";case(0x1f68+154-0x1f20):return"\x49\x4d\x20\x55\x73\x65\x64";case
(0x1048+3680-0x1d7c):return"\x4d\x20\x43";case(0xe36+6321-0x25ba):return
"\x4d\x20\x50";case(0x6e7+2408-0xf21):return"\x46";case(0x1071+3862-0x1e58):
return"\x53\x20\x4f";case(0xc15+7182-0x26f3):return"\x4e\x20\x4d";case
(0x9b7+4928-0x1bc6):return"\x55\x20\x50";case(0x6cc+2724-0x103e):return"\x75";
case(0xeb3+1379-0x12e3):return"\x54\x20\x52";case(0xc20+6237-0x2349):return
"\x50\x20\x52";case(0x3c5+2895-0xd84):return"\x42\x20\x52";case
(0x5ac+8760-0x2653):return"\x55";case(0xb03+6613-0x2346):return"\x50\x20\x52";
case(0xfdb+5811-0x24fb):return"\x46";case(0x615+8006-0x23c7):return
"\x4e\x20\x46";case(0x449+5842-0x1986):return"\x4d\x20\x4e\x20\x41";case
(0x39c+8627-0x23b9):return"\x4e\x20\x41";case(0xc08+280-0xb89):return
"\x50\x20\x41\x20\x52";case(0x259+4097-0x10c2):return"\x52\x20\x54\x20\x4f";case
(0xb12+6960-0x24a9):return"\x43";case(0x8f5+245-0x850):return"\x47";case
(0xa8b+5198-0x1d3e):return"\x4c\x20\x52";case(0xc7a+6214-0x2324):return
"\x50\x20\x46";case(0x125f+777-0x13cb):return"\x50\x20\x54\x6f\x6f\x20\x4c";case
(0x43a+6603-0x1c67):return"\x55\x52\x49\x20\x54\x6f\x6f\x20\x4c";case
(0x23a+2450-0xa2d):return"\x55\x20\x4d\x20\x54";case(0xe1c+1478-0x1242):return
"\x52\x20\x4e\x20\x53";case(0x342+1276-0x69d):return"\x45\x20\x46";case
(0x296+8553-0x225d):return"\x49\x27\x6d\x20\x61\x20\x74";case(0x365+1039-0x5cf):
return"\x4d\x20\x52";case(0x66b+3478-0x125b):return"\x55\x20\x45";case
(0x1771+2302-0x1ec8):return"\x4c";case(0x1128+539-0x119b):return"\x46\x20\x44";
case(0xc6c+1557-0x10d8):return"\x54\x6f\x6f\x20\x45";case(0xbd0+1132-0xe92):
return"\x55\x20\x52";case(0x938+865-0xaed):return"\x50\x20\x52";case
(0x19d5+3159-0x247f):return"\x54\x6f\x6f\x20\x4d\x20\x52";case(0xcc5+290-0xc38):
return"\x52\x20\x48\x20\x46\x20\x54\x6f\x6f\x20\x4c";case(0x496+318-0x411):
return"\x55\x20\x46\x6f\x72\x20\x4c\x20\x52";case(0xcb6+2799-0x15b0):return
"\x4e\x6f\x74\x20\x49";case(0x874+7453-0x239b):return"\x42\x20\x47";case
(0x9a3+7320-0x2444):return"\x53\x20\x55";case(0x4c2+790-0x5e0):return
"\x47\x20\x54";case(0x583+4333-0x1477):return
"\x48\x20\x56\x20\x4e\x6f\x74\x20\x53";case(0x11b4+1743-0x1689):return
"\x56\x20\x41\x20\x4e";case(0xd06+5021-0x1ea8):return"\x49\x20\x53";case 508:
return"\x4c\x20\x44";case(0x736+4076-0x1524):return"\x4e\x20\x45";case
(0xd86+6225-0x23d8):return"\x4e\x20\x41\x20\x52";default:case
(0x13dc+4627-0x23fb):return"\x49\x20\x53\x20\x45\x72\x72\x6f\x72";}}bool 
can_compress_content_type(const std::string&content_type){return(!content_type.
find("\x74\x65\x78\x74\x2f")&&content_type!=
"\x74\x65\x78\x74\x2f\x65\x76\x65\x6e\x74\x2d\x73\x74\x72\x65\x61\x6d")||
content_type=="\x69\x6d\x61\x67\x65\x2f\x73\x76\x67\x2b\x78\x6d\x6c"||
content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x61\x76\x61\x73\x63\x72\x69\x70\x74"
||content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"||content_type
=="\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x6d\x6c"||content_type==
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x68\x74\x6d\x6c\x2b\x78\x6d\x6c"
;}enum class EncodingType{None=(0x2120+645-0x23a5),Gzip,Brotli};EncodingType 
encoding_type(const Request&req,const Response&res){auto ret=detail::
can_compress_content_type(res.get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65"));if(!ret){return 
EncodingType::None;}const auto&s=req.get_header_value(
"\x41\x63\x63\x65\x70\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67");(void)(s);
#ifdef CPPHTTPLIB_BROTLI_SUPPORT
ret=s.find("\x62\x72")!=std::string::npos;if(ret){return EncodingType::Brotli;}
#endif
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
ret=s.find("\x67\x7a\x69\x70")!=std::string::npos;if(ret){return EncodingType::
Gzip;}
#endif
return EncodingType::None;}class compressor{public:virtual~compressor(){};
typedef std::function<bool(const char*data,size_t data_len)>Callback;virtual 
bool compress(const char*data,size_t data_length,bool last,Callback callback)=0;
};class decompressor{public:virtual~decompressor(){}virtual bool is_valid()const
=0;typedef std::function<bool(const char*data,size_t data_len)>Callback;virtual 
bool decompress(const char*data,size_t data_length,Callback callback)=0;};class 
nocompressor:public compressor{public:~nocompressor(){};bool compress(const char
*data,size_t data_length,bool,Callback callback)override{if(!data_length){return
 true;}return callback(data,data_length);}};
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
class gzip_compressor:public compressor{public:gzip_compressor(){std::memset(&
strm_,(0xc35+1347-0x1178),sizeof(strm_));strm_.zalloc=Z_NULL;strm_.zfree=Z_NULL;
strm_.opaque=Z_NULL;is_valid_=deflateInit2(&strm_,Z_DEFAULT_COMPRESSION,
Z_DEFLATED,(0x7bd+3335-0x14a5),(0x7d0+2684-0x1244),Z_DEFAULT_STRATEGY)==Z_OK;}~
gzip_compressor(){deflateEnd(&strm_);}bool compress(const char*data,size_t 
data_length,bool last,Callback callback)override{assert(is_valid_);auto flush=
last?Z_FINISH:Z_NO_FLUSH;strm_.avail_in=static_cast<decltype(strm_.avail_in)>(
data_length);strm_.next_in=const_cast<Bytef*>(reinterpret_cast<const Bytef*>(
data));int ret=Z_OK;std::array<char,CPPHTTPLIB_COMPRESSION_BUFSIZ>buff{};do{
strm_.avail_out=buff.size();strm_.next_out=reinterpret_cast<Bytef*>(buff.data())
;ret=deflate(&strm_,flush);if(ret==Z_STREAM_ERROR){return false;}if(!callback(
buff.data(),buff.size()-strm_.avail_out)){return false;}}while(strm_.avail_out==
(0x1119+4139-0x2144));assert((last&&ret==Z_STREAM_END)||(!last&&ret==Z_OK));
assert(strm_.avail_in==(0x753+1084-0xb8f));return true;}private:bool is_valid_=
false;z_stream strm_;};class gzip_decompressor:public decompressor{public:
gzip_decompressor(){std::memset(&strm_,(0x1608+115-0x167b),sizeof(strm_));strm_.
zalloc=Z_NULL;strm_.zfree=Z_NULL;strm_.opaque=Z_NULL;is_valid_=inflateInit2(&
strm_,(0x1b16+1244-0x1fd2)+(0x3d2+2000-0xb93))==Z_OK;}~gzip_decompressor(){
inflateEnd(&strm_);}bool is_valid()const override{return is_valid_;}bool 
decompress(const char*data,size_t data_length,Callback callback)override{assert(
is_valid_);int ret=Z_OK;strm_.avail_in=static_cast<decltype(strm_.avail_in)>(
data_length);strm_.next_in=const_cast<Bytef*>(reinterpret_cast<const Bytef*>(
data));std::array<char,CPPHTTPLIB_COMPRESSION_BUFSIZ>buff{};while(strm_.avail_in
>(0xd65+3102-0x1983)){strm_.avail_out=buff.size();strm_.next_out=
reinterpret_cast<Bytef*>(buff.data());ret=inflate(&strm_,Z_NO_FLUSH);assert(ret
!=Z_STREAM_ERROR);switch(ret){case Z_NEED_DICT:case Z_DATA_ERROR:case 
Z_MEM_ERROR:inflateEnd(&strm_);return false;}if(!callback(buff.data(),buff.size(
)-strm_.avail_out)){return false;}}return ret==Z_OK||ret==Z_STREAM_END;}private:
bool is_valid_=false;z_stream strm_;};
#endif
#ifdef CPPHTTPLIB_BROTLI_SUPPORT
class brotli_compressor:public compressor{public:brotli_compressor(){state_=
BrotliEncoderCreateInstance(nullptr,nullptr,nullptr);}~brotli_compressor(){
BrotliEncoderDestroyInstance(state_);}bool compress(const char*data,size_t 
data_length,bool last,Callback callback)override{std::array<uint8_t,
CPPHTTPLIB_COMPRESSION_BUFSIZ>buff{};auto operation=last?BROTLI_OPERATION_FINISH
:BROTLI_OPERATION_PROCESS;auto available_in=data_length;auto next_in=
reinterpret_cast<const uint8_t*>(data);for(;;){if(last){if(
BrotliEncoderIsFinished(state_)){break;}}else{if(!available_in){break;}}auto 
available_out=buff.size();auto next_out=buff.data();if(!
BrotliEncoderCompressStream(state_,operation,&available_in,&next_in,&
available_out,&next_out,nullptr)){return false;}auto output_bytes=buff.size()-
available_out;if(output_bytes){callback(reinterpret_cast<const char*>(buff.data(
)),output_bytes);}}return true;}private:BrotliEncoderState*state_=nullptr;};
class brotli_decompressor:public decompressor{public:brotli_decompressor(){
decoder_s=BrotliDecoderCreateInstance((0x16+8770-0x2258),(0x1acd+1339-0x2008),
(0xb4c+3594-0x1956));decoder_r=decoder_s?BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT:
BROTLI_DECODER_RESULT_ERROR;}~brotli_decompressor(){if(decoder_s){
BrotliDecoderDestroyInstance(decoder_s);}}bool is_valid()const override{return 
decoder_s;}bool decompress(const char*data,size_t data_length,Callback callback)
override{if(decoder_r==BROTLI_DECODER_RESULT_SUCCESS||decoder_r==
BROTLI_DECODER_RESULT_ERROR){return(0x160+1200-0x610);}const uint8_t*next_in=(
const uint8_t*)data;size_t avail_in=data_length;size_t total_out;decoder_r=
BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT;std::array<char,
CPPHTTPLIB_COMPRESSION_BUFSIZ>buff{};while(decoder_r==
BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT){char*next_out=buff.data();size_t 
avail_out=buff.size();decoder_r=BrotliDecoderDecompressStream(decoder_s,&
avail_in,&next_in,&avail_out,reinterpret_cast<uint8_t**>(&next_out),&total_out);
if(decoder_r==BROTLI_DECODER_RESULT_ERROR){return false;}if(!callback(buff.data(
),buff.size()-avail_out)){return false;}}return decoder_r==
BROTLI_DECODER_RESULT_SUCCESS||decoder_r==BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT
;}private:BrotliDecoderResult decoder_r;BrotliDecoderState*decoder_s=nullptr;};
#endif
bool has_header(const Headers&headers,const char*key){return headers.find(key)!=
headers.end();}const char*get_header_value(const Headers&headers,const char*key,
size_t id=(0x56d+2650-0xfc7),const char*def=nullptr){auto rng=headers.
equal_range(key);auto it=rng.first;std::advance(it,static_cast<ssize_t>(id));if(
it!=rng.second){return it->second.c_str();}return def;}template<typename T>T 
get_header_value(const Headers&,const char*,size_t=(0x1a5a+436-0x1c0e),uint64_t=
(0x223d+467-0x2410)){}template<>uint64_t get_header_value<uint64_t>(const 
Headers&headers,const char*key,size_t id,uint64_t def){auto rng=headers.
equal_range(key);auto it=rng.first;std::advance(it,static_cast<ssize_t>(id));if(
it!=rng.second){return std::strtoull(it->second.data(),nullptr,
(0xa4d+5733-0x20a8));}return def;}template<typename T>bool parse_header(const 
char*beg,const char*end,T fn){while(beg<end&&is_space_or_tab(end[-
(0x65+283-0x17f)])){end--;}auto p=beg;while(p<end&&*p!=
((char)(0x468+4206-0x149c))){p++;}if(p==end){return false;}auto key_end=p;if(*p
++!=((char)(0x21f+5750-0x185b))){return false;}while(p<end&&is_space_or_tab(*p))
{p++;}if(p<end){fn(std::string(beg,key_end),decode_url(std::string(p,end),false)
);return true;}return false;}bool read_headers(Stream&strm,Headers&headers){
const auto bufsiz=(0x221c+1071-0x1e4b);char buf[bufsiz];stream_line_reader 
line_reader(strm,buf,bufsiz);for(;;){if(!line_reader.getline()){return false;}if
(line_reader.end_with_crlf()){if(line_reader.size()==(0x123+5176-0x1559)){break;
}}else{continue;}auto end=line_reader.ptr()+line_reader.size()-
(0xcbf+2221-0x156a);parse_header(line_reader.ptr(),end,[&](std::string&&key,std
::string&&val){headers.emplace(std::move(key),std::move(val));});}return true;}
bool read_content_with_length(Stream&strm,uint64_t len,Progress progress,
ContentReceiverWithProgress out){char buf[CPPHTTPLIB_RECV_BUFSIZ];uint64_t r=
(0x1f5c+1590-0x2592);while(r<len){auto read_len=static_cast<size_t>(len-r);auto 
n=strm.read(buf,(std::min)(read_len,CPPHTTPLIB_RECV_BUFSIZ));if(n<=
(0x607+6040-0x1d9f)){return false;}if(!out(buf,static_cast<size_t>(n),r,len)){
return false;}r+=static_cast<uint64_t>(n);if(progress){if(!progress(r,len)){
return false;}}}return true;}void skip_content_with_length(Stream&strm,uint64_t 
len){char buf[CPPHTTPLIB_RECV_BUFSIZ];uint64_t r=(0xb21+2388-0x1475);while(r<len
){auto read_len=static_cast<size_t>(len-r);auto n=strm.read(buf,(std::min)(
read_len,CPPHTTPLIB_RECV_BUFSIZ));if(n<=(0x10e5+4038-0x20ab)){return;}r+=
static_cast<uint64_t>(n);}}bool read_content_without_length(Stream&strm,
ContentReceiverWithProgress out){char buf[CPPHTTPLIB_RECV_BUFSIZ];uint64_t r=
(0x4f1+2689-0xf72);for(;;){auto n=strm.read(buf,CPPHTTPLIB_RECV_BUFSIZ);if(n<
(0x190f+2881-0x2450)){return false;}else if(n==(0x2454+698-0x270e)){return true;
}if(!out(buf,static_cast<size_t>(n),r,(0x32b+8744-0x2553))){return false;}r+=
static_cast<uint64_t>(n);}return true;}bool read_content_chunked(Stream&strm,
ContentReceiverWithProgress out){const auto bufsiz=(0x8fd+2800-0x13dd);char buf[
bufsiz];stream_line_reader line_reader(strm,buf,bufsiz);if(!line_reader.getline(
)){return false;}unsigned long chunk_len;while(true){char*end_ptr;chunk_len=std
::strtoul(line_reader.ptr(),&end_ptr,(0x144d+1904-0x1bad));if(end_ptr==
line_reader.ptr()){return false;}if(chunk_len==ULONG_MAX){return false;}if(
chunk_len==(0xcfb+3536-0x1acb)){break;}if(!read_content_with_length(strm,
chunk_len,nullptr,out)){return false;}if(!line_reader.getline()){return false;}
if(strcmp(line_reader.ptr(),"\r\n")){break;}if(!line_reader.getline()){return 
false;}}if(chunk_len==(0x650+6873-0x2129)){if(!line_reader.getline()||strcmp(
line_reader.ptr(),"\r\n"))return false;}return true;}bool 
is_chunked_transfer_encoding(const Headers&headers){return!strcasecmp(
get_header_value(headers,
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
(0x1627+2043-0x1e22),""),"\x63\x68\x75\x6e\x6b\x65\x64");}template<typename T,
typename U>bool prepare_content_receiver(T&x,int&status,
ContentReceiverWithProgress receiver,bool decompress,U callback){if(decompress){
std::string encoding=x.get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67");std::
unique_ptr<decompressor>decompressor;if(encoding.find("\x67\x7a\x69\x70")!=std::
string::npos||encoding.find("\x64\x65\x66\x6c\x61\x74\x65")!=std::string::npos){
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
decompressor=detail::make_unique<gzip_decompressor>();
#else
status=(0x12cd+2562-0x1b30);return false;
#endif
}else if(encoding.find("\x62\x72")!=std::string::npos){
#ifdef CPPHTTPLIB_BROTLI_SUPPORT
decompressor=detail::make_unique<brotli_decompressor>();
#else
status=(0x1617+3554-0x225a);return false;
#endif
}if(decompressor){if(decompressor->is_valid()){ContentReceiverWithProgress out=[
&](const char*buf,size_t n,uint64_t off,uint64_t len){return decompressor->
decompress(buf,n,[&](const char*buf,size_t n){return receiver(buf,n,off,len);});
};return callback(std::move(out));}else{status=(0xb0a+5739-0x1f81);return false;
}}}ContentReceiverWithProgress out=[&](const char*buf,size_t n,uint64_t off,
uint64_t len){return receiver(buf,n,off,len);};return callback(std::move(out));}
template<typename T>bool read_content(Stream&strm,T&x,size_t payload_max_length,
int&status,Progress progress,ContentReceiverWithProgress receiver,bool 
decompress){return prepare_content_receiver(x,status,std::move(receiver),
decompress,[&](const ContentReceiverWithProgress&out){auto ret=true;auto 
exceed_payload_max_length=false;if(is_chunked_transfer_encoding(x.headers)){ret=
read_content_chunked(strm,out);}else if(!has_header(x.headers,
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){ret=
read_content_without_length(strm,out);}else{auto len=get_header_value<uint64_t>(
x.headers,"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68");if(len>
payload_max_length){exceed_payload_max_length=true;skip_content_with_length(strm
,len);ret=false;}else if(len>(0xaf0+3263-0x17af)){ret=read_content_with_length(
strm,len,std::move(progress),out);}}if(!ret){status=exceed_payload_max_length?
(0xab4+3928-0x186f):(0x1ed3+1301-0x2258);}return ret;});}ssize_t write_headers(
Stream&strm,const Headers&headers){ssize_t write_len=(0x2211+1070-0x263f);for(
const auto&x:headers){auto len=strm.write_format(
"\x25\x73\x3a\x20\x25\x73" "\r\n",x.first.c_str(),x.second.c_str());if(len<
(0x2a9+1252-0x78d)){return len;}write_len+=len;}auto len=strm.write("\r\n");if(
len<(0xf8+4895-0x1417)){return len;}write_len+=len;return write_len;}bool 
write_data(Stream&strm,const char*d,size_t l){size_t offset=(0x627+6626-0x2009);
while(offset<l){auto length=strm.write(d+offset,l-offset);if(length<
(0x10ca+3446-0x1e40)){return false;}offset+=static_cast<size_t>(length);}return 
true;}template<typename T>bool write_content(Stream&strm,const ContentProvider&
content_provider,size_t offset,size_t length,T is_shutting_down,Error&error){
size_t end_offset=offset+length;auto ok=true;DataSink data_sink;data_sink.write=
[&](const char*d,size_t l){if(ok){if(write_data(strm,d,l)){offset+=l;}else{ok=
false;}}};data_sink.is_writable=[&](void){return ok&&strm.is_writable();};while(
offset<end_offset&&!is_shutting_down()){if(!content_provider(offset,end_offset-
offset,data_sink)){error=Error::Canceled;return false;}if(!ok){error=Error::
Write;return false;}}error=Error::Success;return true;}template<typename T>bool 
write_content(Stream&strm,const ContentProvider&content_provider,size_t offset,
size_t length,const T&is_shutting_down){auto error=Error::Success;return 
write_content(strm,content_provider,offset,length,is_shutting_down,error);}
template<typename T>bool write_content_without_length(Stream&strm,const 
ContentProvider&content_provider,const T&is_shutting_down){size_t offset=
(0xe93+5486-0x2401);auto data_available=true;auto ok=true;DataSink data_sink;
data_sink.write=[&](const char*d,size_t l){if(ok){offset+=l;if(!write_data(strm,
d,l)){ok=false;}}};data_sink.done=[&](void){data_available=false;};data_sink.
is_writable=[&](void){return ok&&strm.is_writable();};while(data_available&&!
is_shutting_down()){if(!content_provider(offset,(0xc75+6416-0x2585),data_sink)){
return false;}if(!ok){return false;}}return true;}template<typename T,typename U
>bool write_content_chunked(Stream&strm,const ContentProvider&content_provider,
const T&is_shutting_down,U&compressor,Error&error){size_t offset=
(0x5d5+7543-0x234c);auto data_available=true;auto ok=true;DataSink data_sink;
data_sink.write=[&](const char*d,size_t l){if(!ok){return;}data_available=l>
(0x796+4224-0x1816);offset+=l;std::string payload;if(!compressor.compress(d,l,
false,[&](const char*data,size_t data_len){payload.append(data,data_len);return 
true;})){ok=false;return;}if(!payload.empty()){auto chunk=from_i_to_hex(payload.
size())+"\r\n"+payload+"\r\n";if(!write_data(strm,chunk.data(),chunk.size())){ok
=false;return;}}};data_sink.done=[&](void){if(!ok){return;}data_available=false;
std::string payload;if(!compressor.compress(nullptr,(0x407+8703-0x2606),true,[&]
(const char*data,size_t data_len){payload.append(data,data_len);return true;})){
ok=false;return;}if(!payload.empty()){auto chunk=from_i_to_hex(payload.size())+
"\r\n"+payload+"\r\n";if(!write_data(strm,chunk.data(),chunk.size())){ok=false;
return;}}static const std::string done_marker("\x30" "\r\n\r\n");if(!write_data(
strm,done_marker.data(),done_marker.size())){ok=false;}};data_sink.is_writable=[
&](void){return ok&&strm.is_writable();};while(data_available&&!is_shutting_down
()){if(!content_provider(offset,(0x3e3+7324-0x207f),data_sink)){error=Error::
Canceled;return false;}if(!ok){error=Error::Write;return false;}}error=Error::
Success;return true;}template<typename T,typename U>bool write_content_chunked(
Stream&strm,const ContentProvider&content_provider,const T&is_shutting_down,U&
compressor){auto error=Error::Success;return write_content_chunked(strm,
content_provider,is_shutting_down,compressor,error);}template<typename T>bool 
redirect(T&cli,Request&req,Response&res,const std::string&path,const std::string
&location,Error&error){Request new_req=req;new_req.path=path;new_req.
redirect_count_-=(0x437+7297-0x20b7);if(res.status==(0x2a4+2109-0x9b2)&&(req.
method!="\x47\x45\x54"&&req.method!="\x48\x45\x41\x44")){new_req.method=
"\x47\x45\x54";new_req.body.clear();new_req.headers.clear();}Response new_res;
auto ret=cli.send(new_req,new_res,error);if(ret){req=new_req;res=new_res;res.
location=location;}return ret;}std::string params_to_query_str(const Params&
params){std::string query;for(auto it=params.begin();it!=params.end();++it){if(
it!=params.begin()){query+="\x26";}query+=it->first;query+="\x3d";query+=
encode_query_param(it->second);}return query;}std::string append_query_params(
const char*path,const Params&params){std::string path_with_query=path;const 
static std::regex re("\x5b\x5e\x3f\x5d\x2b" "\\" "\x3f\x2e\x2a");auto delm=std::
regex_match(path,re)?((char)(0xdbc+6101-0x256b)):((char)(0x2b6+2119-0xabe));
path_with_query+=delm+params_to_query_str(params);return path_with_query;}void 
parse_query_text(const std::string&s,Params&params){split(s.data(),s.data()+s.
size(),((char)(0x1141+2883-0x1c5e)),[&](const char*b,const char*e){std::string 
key;std::string val;split(b,e,((char)(0x947+476-0xae6)),[&](const char*b2,const 
char*e2){if(key.empty()){key.assign(b2,e2);}else{val.assign(b2,e2);}});if(!key.
empty()){params.emplace(decode_url(key,true),decode_url(val,true));}});}bool 
parse_multipart_boundary(const std::string&content_type,std::string&boundary){
auto pos=content_type.find("\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d");if(pos==std::
string::npos){return false;}boundary=content_type.substr(pos+
(0x1a34+2572-0x2437));if(boundary.length()>=(0xf25+5423-0x2452)&&boundary.front(
)==((char)(0x7c1+3636-0x15d3))&&boundary.back()==((char)(0x1572+4428-0x269c))){
boundary=boundary.substr((0x7d1+1410-0xd52),boundary.size()-(0x805+1261-0xcf0));
}return!boundary.empty();}bool parse_range_header(const std::string&s,Ranges&
ranges)try{static auto re_first_range=std::regex(
R"(bytes=(\d*-\d*(?:,\s*\d*-\d*)*))");std::smatch m;if(std::regex_match(s,m,
re_first_range)){auto pos=static_cast<size_t>(m.position((0x41a+2653-0xe76)));
auto len=static_cast<size_t>(m.length((0x1734+290-0x1855)));bool 
all_valid_ranges=true;split(&s[pos],&s[pos+len],((char)(0xff+6366-0x19b1)),[&](
const char*b,const char*e){if(!all_valid_ranges)return;static auto 
re_another_range=std::regex(R"(\s*(\d*)-(\d*))");std::cmatch cm;if(std::
regex_match(b,e,cm,re_another_range)){ssize_t first=-(0x149a+1938-0x1c2b);if(!cm
.str((0x448+8877-0x26f4)).empty()){first=static_cast<ssize_t>(std::stoll(cm.str(
(0xe12+4916-0x2145))));}ssize_t last=-(0x1b48+1213-0x2004);if(!cm.str(
(0x21e2+151-0x2277)).empty()){last=static_cast<ssize_t>(std::stoll(cm.str(
(0xaa5+5367-0x1f9a))));}if(first!=-(0xdec+2258-0x16bd)&&last!=-(0xa1+2946-0xc22)
&&first>last){all_valid_ranges=false;return;}ranges.emplace_back(std::make_pair(
first,last));}});return all_valid_ranges;}return false;}catch(...){return false;
}class MultipartFormDataParser{public:MultipartFormDataParser()=default;void 
set_boundary(std::string&&boundary){boundary_=boundary;}bool is_valid()const{
return is_valid_;}bool parse(const char*buf,size_t n,const ContentReceiver&
content_callback,const MultipartContentHeader&header_callback){static const std
::regex re_content_disposition(
"\x5e\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x44\x69\x73\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a" "\\" "\x73\x2a\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b" "\\" "\x73\x2a\x6e\x61\x6d\x65\x3d" "\"" "\x28\x2e\x2a\x3f\x29" "\"" "\x28\x3f\x3a\x3b" "\\" "\x73\x2a\x66\x69\x6c\x65\x6e\x61\x6d\x65\x3d"
"\"" "\x28\x2e\x2a\x3f\x29" "\"" "\x29\x3f" "\\" "\x73\x2a\x24",std::
regex_constants::icase);static const std::string dash_="\x2d\x2d";static const 
std::string crlf_="\r\n";buf_.append(buf,n);while(!buf_.empty()){switch(state_){
case(0x1166+5215-0x25c5):{auto pattern=dash_+boundary_+crlf_;if(pattern.size()>
buf_.size()){return true;}auto pos=buf_.find(pattern);if(pos!=(0x201+1275-0x6fc)
){return false;}buf_.erase((0x13cd+3901-0x230a),pattern.size());off_+=pattern.
size();state_=(0x637+2785-0x1117);break;}case(0x1d9c+1100-0x21e7):{
clear_file_info();state_=(0xdca+3743-0x1c67);break;}case(0x213+1074-0x643):{auto
 pos=buf_.find(crlf_);while(pos!=std::string::npos){if(pos==(0x2319+541-0x2536))
{if(!header_callback(file_)){is_valid_=false;return false;}buf_.erase(
(0x525+4947-0x1878),crlf_.size());off_+=crlf_.size();state_=(0xed2+5360-0x23bf);
break;}static const std::string header_name=
"\x63\x6f\x6e\x74\x65\x6e\x74\x2d\x74\x79\x70\x65\x3a";const auto header=buf_.
substr((0x1a40+2366-0x237e),pos);if(start_with_case_ignore(header,header_name)){
file_.content_type=trim_copy(header.substr(header_name.size()));}else{std::
smatch m;if(std::regex_match(header,m,re_content_disposition)){file_.name=m[
(0x2f+689-0x2df)];file_.filename=m[(0xe2b+620-0x1095)];}}buf_.erase(
(0x1735+3628-0x2561),pos+crlf_.size());off_+=pos+crlf_.size();pos=buf_.find(
crlf_);}if(state_!=(0x1bf+4967-0x1523)){return true;}break;}case
(0x98b+5476-0x1eec):{{auto pattern=crlf_+dash_;if(pattern.size()>buf_.size()){
return true;}auto pos=find_string(buf_,pattern);if(!content_callback(buf_.data()
,pos)){is_valid_=false;return false;}off_+=pos;buf_.erase((0xea0+96-0xf00),pos);
}{auto pattern=crlf_+dash_+boundary_;if(pattern.size()>buf_.size()){return true;
}auto pos=buf_.find(pattern);if(pos!=std::string::npos){if(!content_callback(
buf_.data(),pos)){is_valid_=false;return false;}off_+=pos+pattern.size();buf_.
erase((0x6fb+5278-0x1b99),pos+pattern.size());state_=(0x22ed+1060-0x270d);}else{
if(!content_callback(buf_.data(),pattern.size())){is_valid_=false;return false;}
off_+=pattern.size();buf_.erase((0x20c4+1347-0x2607),pattern.size());}}break;}
case(0x121f+2244-0x1adf):{if(crlf_.size()>buf_.size()){return true;}if(buf_.
compare((0xbcb+6849-0x268c),crlf_.size(),crlf_)==(0x1ad6+1279-0x1fd5)){buf_.
erase((0xdf2+4078-0x1de0),crlf_.size());off_+=crlf_.size();state_=
(0x10a9+2398-0x1a06);}else{auto pattern=dash_+crlf_;if(pattern.size()>buf_.size(
)){return true;}if(buf_.compare((0x5b1+8373-0x2666),pattern.size(),pattern)==
(0x7bd+949-0xb72)){buf_.erase((0x2127+458-0x22f1),pattern.size());off_+=pattern.
size();is_valid_=true;state_=(0x23df+609-0x263b);}else{return true;}}break;}case
(0x11c3+429-0x136b):{is_valid_=false;return false;}}}return true;}private:void 
clear_file_info(){file_.name.clear();file_.filename.clear();file_.content_type.
clear();}bool start_with_case_ignore(const std::string&a,const std::string&b)
const{if(a.size()<b.size()){return false;}for(size_t i=(0x53a+6411-0x1e45);i<b.
size();i++){if(::tolower(a[i])!=::tolower(b[i])){return false;}}return true;}
bool start_with(const std::string&a,size_t off,const std::string&b)const{if(a.
size()-off<b.size()){return false;}for(size_t i=(0x158d+1934-0x1d1b);i<b.size();
i++){if(a[i+off]!=b[i]){return false;}}return true;}size_t find_string(const std
::string&s,const std::string&pattern)const{auto c=pattern.front();size_t off=
(0x1001+1868-0x174d);while(off<s.size()){auto pos=s.find(c,off);if(pos==std::
string::npos){return s.size();}auto rem=s.size()-pos;if(pattern.size()>rem){
return pos;}if(start_with(s,pos,pattern)){return pos;}off=pos+
(0x792+4099-0x1794);}return s.size();}std::string boundary_;std::string buf_;
size_t state_=(0x785+3422-0x14e3);bool is_valid_=false;size_t off_=
(0x223+6138-0x1a1d);MultipartFormData file_;};std::string to_lower(const char*
beg,const char*end){std::string out;auto it=beg;while(it!=end){out+=static_cast<
char>(::tolower(*it));it++;}return out;}std::string make_multipart_data_boundary
(){static const char data[]=
"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a"
;std::random_device seed_gen;std::seed_seq seed_sequence{seed_gen(),seed_gen(),
seed_gen(),seed_gen()};std::mt19937 engine(seed_sequence);std::string result=
"\x2d\x2d\x63\x70\x70\x2d\x68\x74\x74\x70\x6c\x69\x62\x2d\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2d\x64\x61\x74\x61\x2d"
;for(auto i=(0xe37+6284-0x26c3);i<(0x130f+3109-0x1f24);i++){result+=data[engine(
)%(sizeof(data)-(0x78d+2063-0xf9b))];}return result;}std::pair<size_t,size_t>
get_range_offset_and_length(const Request&req,size_t content_length,size_t index
){auto r=req.ranges[index];if(r.first==-(0x6f7+7788-0x2562)&&r.second==-
(0x27c+5084-0x1657)){return std::make_pair((0x13a+5915-0x1855),content_length);}
auto slen=static_cast<ssize_t>(content_length);if(r.first==-(0xea0+3762-0x1d51))
{r.first=(std::max)(static_cast<ssize_t>((0x397+7226-0x1fd1)),slen-r.second);r.
second=slen-(0x56+3597-0xe62);}if(r.second==-(0x11e2+3385-0x1f1a)){r.second=slen
-(0x1189+4488-0x2310);}return std::make_pair(r.first,static_cast<size_t>(r.
second-r.first)+(0x1cd2+623-0x1f40));}std::string 
make_content_range_header_field(size_t offset,size_t length,size_t 
content_length){std::string field="\x62\x79\x74\x65\x73\x20";field+=std::
to_string(offset);field+="\x2d";field+=std::to_string(offset+length-
(0x2029+1158-0x24ae));field+="\x2f";field+=std::to_string(content_length);return
 field;}template<typename SToken,typename CToken,typename Content>bool 
process_multipart_ranges_data(const Request&req,Response&res,const std::string&
boundary,const std::string&content_type,SToken stoken,CToken ctoken,Content 
content){for(size_t i=(0x20ca+908-0x2456);i<req.ranges.size();i++){ctoken(
"\x2d\x2d");stoken(boundary);ctoken("\r\n");if(!content_type.empty()){ctoken(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20");stoken(content_type)
;ctoken("\r\n");}auto offsets=get_range_offset_and_length(req,res.body.size(),i)
;auto offset=offsets.first;auto length=offsets.second;ctoken(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65\x3a\x20");stoken(
make_content_range_header_field(offset,length,res.body.size()));ctoken("\r\n");
ctoken("\r\n");if(!content(offset,length)){return false;}ctoken("\r\n");}ctoken(
"\x2d\x2d");stoken(boundary);ctoken("\x2d\x2d" "\r\n");return true;}bool 
make_multipart_ranges_data(const Request&req,Response&res,const std::string&
boundary,const std::string&content_type,std::string&data){return 
process_multipart_ranges_data(req,res,boundary,content_type,[&](const std::
string&token){data+=token;},[&](const char*token){data+=token;},[&](size_t 
offset,size_t length){if(offset<res.body.size()){data+=res.body.substr(offset,
length);return true;}return false;});}size_t get_multipart_ranges_data_length(
const Request&req,Response&res,const std::string&boundary,const std::string&
content_type){size_t data_length=(0xf60+757-0x1255);
process_multipart_ranges_data(req,res,boundary,content_type,[&](const std::
string&token){data_length+=token.size();},[&](const char*token){data_length+=
strlen(token);},[&](size_t,size_t length){data_length+=length;return true;});
return data_length;}template<typename T>bool write_multipart_ranges_data(Stream&
strm,const Request&req,Response&res,const std::string&boundary,const std::string
&content_type,const T&is_shutting_down){return process_multipart_ranges_data(req
,res,boundary,content_type,[&](const std::string&token){strm.write(token);},[&](
const char*token){strm.write(token);},[&](size_t offset,size_t length){return 
write_content(strm,res.content_provider_,offset,length,is_shutting_down);});}std
::pair<size_t,size_t>get_range_offset_and_length(const Request&req,const 
Response&res,size_t index){auto r=req.ranges[index];if(r.second==-
(0x1374+2796-0x1e5f)){r.second=static_cast<ssize_t>(res.content_length_)-
(0x139+1160-0x5c0);}return std::make_pair(r.first,r.second-r.first+
(0x1737+349-0x1893));}bool expect_content(const Request&req){if(req.method==
"\x50\x4f\x53\x54"||req.method=="\x50\x55\x54"||req.method==
"\x50\x41\x54\x43\x48"||req.method=="\x50\x52\x49"||req.method==
"\x44\x45\x4c\x45\x54\x45"){return true;}return false;}bool has_crlf(const char*
s){auto p=s;while(*p){if(*p=='\r'||*p=='\n'){return true;}p++;}return false;}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
template<typename CTX,typename Init,typename Update,typename Final>std::string 
message_digest(const std::string&s,Init init,Update update,Final final,size_t 
digest_length){using namespace std;std::vector<unsigned char>md(digest_length,
(0x1c8+7009-0x1d29));CTX ctx;init(&ctx);update(&ctx,s.data(),s.size());final(md.
data(),&ctx);stringstream ss;for(auto c:md){ss<<setfill(
((char)(0x1cf3+49-0x1cf4)))<<setw((0x523+4509-0x16be))<<hex<<(unsigned int)c;}
return ss.str();}std::string MD5(const std::string&s){return message_digest<
MD5_CTX>(s,MD5_Init,MD5_Update,MD5_Final,MD5_DIGEST_LENGTH);}std::string SHA_256
(const std::string&s){return message_digest<SHA256_CTX>(s,SHA256_Init,
SHA256_Update,SHA256_Final,SHA256_DIGEST_LENGTH);}std::string SHA_512(const std
::string&s){return message_digest<SHA512_CTX>(s,SHA512_Init,SHA512_Update,
SHA512_Final,SHA512_DIGEST_LENGTH);}
#endif
#ifdef _WIN32
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
bool load_system_certs_on_windows(X509_STORE*store){auto hStore=
CertOpenSystemStoreW((HCRYPTPROV_LEGACY)NULL,L"ROOT");if(!hStore){return false;}
PCCERT_CONTEXT pContext=NULL;while((pContext=CertEnumCertificatesInStore(hStore,
pContext))!=nullptr){auto encoded_cert=static_cast<const unsigned char*>(
pContext->pbCertEncoded);auto x509=d2i_X509(NULL,&encoded_cert,pContext->
cbCertEncoded);if(x509){X509_STORE_add_cert(store,x509);X509_free(x509);}}
CertFreeCertificateContext(pContext);CertCloseStore(hStore,(0x15cf+3274-0x2299))
;return true;}
#endif
class WSInit{public:WSInit(){WSADATA wsaData;WSAStartup((0x3d1+5364-0x18c3),&
wsaData);}~WSInit(){WSACleanup();}};static WSInit wsinit_;
#endif
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
std::pair<std::string,std::string>make_digest_authentication_header(const 
Request&req,const std::map<std::string,std::string>&auth,size_t cnonce_count,
const std::string&cnonce,const std::string&username,const std::string&password,
bool is_proxy=false){using namespace std;string nc;{stringstream ss;ss<<setfill(
((char)(0xeb+2066-0x8cd)))<<setw((0x1027+825-0x1358))<<hex<<cnonce_count;nc=ss.
str();}auto qop=auth.at("\x71\x6f\x70");if(qop.find(
"\x61\x75\x74\x68\x2d\x69\x6e\x74")!=std::string::npos){qop=
"\x61\x75\x74\x68\x2d\x69\x6e\x74";}else{qop="\x61\x75\x74\x68";}std::string 
algo="\x4d\x44\x35";if(auth.find("\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d")!=auth.
end()){algo=auth.at("\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d");}string response;{
auto H=algo=="\x53\x48\x41\x2d\x32\x35\x36"?detail::SHA_256:algo==
"\x53\x48\x41\x2d\x35\x31\x32"?detail::SHA_512:detail::MD5;auto A1=username+
"\x3a"+auth.at("\x72\x65\x61\x6c\x6d")+"\x3a"+password;auto A2=req.method+"\x3a"
+req.path;if(qop=="\x61\x75\x74\x68\x2d\x69\x6e\x74"){A2+="\x3a"+H(req.body);}
response=H(H(A1)+"\x3a"+auth.at("\x6e\x6f\x6e\x63\x65")+"\x3a"+nc+"\x3a"+cnonce+
"\x3a"+qop+"\x3a"+H(A2));}auto field=
"\x44\x69\x67\x65\x73\x74\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3d" "\""+username
+"\"" "\x2c\x20\x72\x65\x61\x6c\x6d\x3d" "\""+auth.at("\x72\x65\x61\x6c\x6d")+
"\"" "\x2c\x20\x6e\x6f\x6e\x63\x65\x3d" "\""+auth.at("\x6e\x6f\x6e\x63\x65")+
"\"" "\x2c\x20\x75\x72\x69\x3d" "\""+req.path+
"\"" "\x2c\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x3d"+algo+
"\x2c\x20\x71\x6f\x70\x3d"+qop+"\x2c\x20\x6e\x63\x3d" "\""+nc+
"\"" "\x2c\x20\x63\x6e\x6f\x6e\x63\x65\x3d" "\""+cnonce+
"\"" "\x2c\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x3d" "\""+response+"\"";auto key=
is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,field);}
#endif
bool parse_www_authenticate(const Response&res,std::map<std::string,std::string>
&auth,bool is_proxy){auto auth_key=is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x65":
"\x57\x57\x57\x2d\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x65";if(res.
has_header(auth_key)){static auto re=std::regex(R"~((?:(?:,\s*)?(.+?)=(?:"(.*?)
"\x7c\x28\x5b\x5e\x2c\x5d\x2a\x29\x29\x29\x29\x7e");auto s=res.get_header_value(
auth_key);auto pos=s.find(((char)(0x798+3684-0x15dc)));if(pos!=std::string::npos
){auto type=s.substr((0x1c53+2704-0x26e3),pos);if(type=="\x42\x61\x73\x69\x63"){
return false;}else if(type=="\x44\x69\x67\x65\x73\x74"){s=s.substr(pos+
(0x14cb+1124-0x192e));auto beg=std::sregex_iterator(s.begin(),s.end(),re);for(
auto i=beg;i!=std::sregex_iterator();++i){auto m=*i;auto key=s.substr(
static_cast<size_t>(m.position((0x2b5+1474-0x876))),static_cast<size_t>(m.length
((0x11bf+5371-0x26b9))));auto val=m.length((0x961+3631-0x178e))>
(0x90c+6662-0x2312)?s.substr(static_cast<size_t>(m.position((0x320+8334-0x23ac))
),static_cast<size_t>(m.length((0x1a65+2251-0x232e)))):s.substr(static_cast<
size_t>(m.position((0x16b4+1054-0x1acf))),static_cast<size_t>(m.length(
(0xde0+5589-0x23b2))));auth[key]=val;}return true;}}}return false;}std::string 
random_string(size_t length){auto randchar=[]()->char{const char charset[]=
"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39"
"\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a"
"\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a"
;const size_t max_index=(sizeof(charset)-(0x1d04+1114-0x215d));return charset[
static_cast<size_t>(rand())%max_index];};std::string str(length,
(0x2467+400-0x25f7));std::generate_n(str.begin(),length,randchar);return str;}
class ContentProviderAdapter{public:explicit ContentProviderAdapter(
ContentProviderWithoutLength&&content_provider):content_provider_(
content_provider){}bool operator()(size_t offset,size_t,DataSink&sink){return 
content_provider_(offset,sink);}private:ContentProviderWithoutLength 
content_provider_;};}std::pair<std::string,std::string>make_range_header(Ranges 
ranges){std::string field="\x62\x79\x74\x65\x73\x3d";auto i=(0x178c+3594-0x2596)
;for(auto r:ranges){if(i!=(0x790+6013-0x1f0d)){field+="\x2c\x20";}if(r.first!=-
(0x1be4+2181-0x2468)){field+=std::to_string(r.first);}field+=
((char)(0x898+216-0x943));if(r.second!=-(0x1347+1822-0x1a64)){field+=std::
to_string(r.second);}i++;}return std::make_pair("\x52\x61\x6e\x67\x65",std::move
(field));}std::pair<std::string,std::string>make_basic_authentication_header(
const std::string&username,const std::string&password,bool is_proxy=false){auto 
field="\x42\x61\x73\x69\x63\x20"+detail::base64_encode(username+"\x3a"+password)
;auto key=is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,std::move(field));}std::pair<std::string,std::string>
make_bearer_token_authentication_header(const std::string&token,bool is_proxy=
false){auto field="\x42\x65\x61\x72\x65\x72\x20"+token;auto key=is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";return std::make_pair(key
,std::move(field));}bool Request::has_header(const char*key)const{return detail
::has_header(headers,key);}std::string Request::get_header_value(const char*key,
size_t id)const{return detail::get_header_value(headers,key,id,"");}template<
typename T>T Request::get_header_value(const char*key,size_t id)const{return 
detail::get_header_value<T>(headers,key,id,(0x3c4+6961-0x1ef5));}size_t Request
::get_header_value_count(const char*key)const{auto r=headers.equal_range(key);
return static_cast<size_t>(std::distance(r.first,r.second));}void Request::
set_header(const char*key,const char*val){if(!detail::has_crlf(key)&&!detail::
has_crlf(val)){headers.emplace(key,val);}}void Request::set_header(const char*
key,const std::string&val){if(!detail::has_crlf(key)&&!detail::has_crlf(val.
c_str())){headers.emplace(key,val);}}bool Request::has_param(const char*key)
const{return params.find(key)!=params.end();}std::string Request::
get_param_value(const char*key,size_t id)const{auto rng=params.equal_range(key);
auto it=rng.first;std::advance(it,static_cast<ssize_t>(id));if(it!=rng.second){
return it->second;}return std::string();}size_t Request::get_param_value_count(
const char*key)const{auto r=params.equal_range(key);return static_cast<size_t>(
std::distance(r.first,r.second));}bool Request::is_multipart_form_data()const{
const auto&content_type=get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");return!content_type.find(
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61");
}bool Request::has_file(const char*key)const{return files.find(key)!=files.end()
;}MultipartFormData Request::get_file_value(const char*key)const{auto it=files.
find(key);if(it!=files.end()){return it->second;}return MultipartFormData();}
bool Response::has_header(const char*key)const{return headers.find(key)!=headers
.end();}std::string Response::get_header_value(const char*key,size_t id)const{
return detail::get_header_value(headers,key,id,"");}template<typename T>T 
Response::get_header_value(const char*key,size_t id)const{return detail::
get_header_value<T>(headers,key,id,(0x1145+2635-0x1b90));}size_t Response::
get_header_value_count(const char*key)const{auto r=headers.equal_range(key);
return static_cast<size_t>(std::distance(r.first,r.second));}void Response::
set_header(const char*key,const char*val){if(!detail::has_crlf(key)&&!detail::
has_crlf(val)){headers.emplace(key,val);}}void Response::set_header(const char*
key,const std::string&val){if(!detail::has_crlf(key)&&!detail::has_crlf(val.
c_str())){headers.emplace(key,val);}}void Response::set_redirect(const char*url,
int stat){if(!detail::has_crlf(url)){set_header(
"\x4c\x6f\x63\x61\x74\x69\x6f\x6e",url);if((0x1af6+2014-0x21a8)<=stat&&stat<
(0x1dc1+540-0x1e4d)){this->status=stat;}else{this->status=(0x3d4+5205-0x16fb);}}
}void Response::set_redirect(const std::string&url,int stat){set_redirect(url.
c_str(),stat);}void Response::set_content(const char*s,size_t n,const char*
content_type){body.assign(s,n);auto rng=headers.equal_range(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");headers.erase(rng.first,rng.
second);set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
content_type);}void Response::set_content(const std::string&s,const char*
content_type){set_content(s.data(),s.size(),content_type);}void Response::
set_content_provider(size_t in_length,const char*content_type,ContentProvider 
provider,const std::function<void()>&resource_releaser){assert(in_length>
(0xa3f+507-0xc3a));set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65"
,content_type);content_length_=in_length;content_provider_=std::move(provider);
content_provider_resource_releaser_=resource_releaser;
is_chunked_content_provider_=false;}void Response::set_content_provider(const 
char*content_type,ContentProviderWithoutLength provider,const std::function<void
()>&resource_releaser){set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",content_type);content_length_
=(0xf48+2611-0x197b);content_provider_=detail::ContentProviderAdapter(std::move(
provider));content_provider_resource_releaser_=resource_releaser;
is_chunked_content_provider_=false;}void Response::set_chunked_content_provider(
const char*content_type,ContentProviderWithoutLength provider,const std::
function<void()>&resource_releaser){set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",content_type);content_length_
=(0x319+8242-0x234b);content_provider_=detail::ContentProviderAdapter(std::move(
provider));content_provider_resource_releaser_=resource_releaser;
is_chunked_content_provider_=true;}bool Result::has_request_header(const char*
key)const{return request_headers_.find(key)!=request_headers_.end();}std::string
 Result::get_request_header_value(const char*key,size_t id)const{return detail::
get_header_value(request_headers_,key,id,"");}template<typename T>T Result::
get_request_header_value(const char*key,size_t id)const{return detail::
get_header_value<T>(request_headers_,key,id,(0x5db+3062-0x11d1));}size_t Result
::get_request_header_value_count(const char*key)const{auto r=request_headers_.
equal_range(key);return static_cast<size_t>(std::distance(r.first,r.second));}
ssize_t Stream::write(const char*ptr){return write(ptr,strlen(ptr));}ssize_t 
Stream::write(const std::string&s){return write(s.data(),s.size());}template<
typename...Args>ssize_t Stream::write_format(const char*fmt,const Args&...args){
const auto bufsiz=(0x111a+1025-0xd1b);std::array<char,bufsiz>buf;
#if defined(_MSC_VER) && _MSC_VER < (0x7f3+9231-0x2496)
auto sn=_snprintf_s(buf.data(),bufsiz-(0x1d05+790-0x201a),buf.size()-
(0x21d+59-0x257),fmt,args...);
#else
auto sn=snprintf(buf.data(),buf.size()-(0x960+3219-0x15f2),fmt,args...);
#endif
if(sn<=(0x5b7+6869-0x208c)){return sn;}auto n=static_cast<size_t>(sn);if(n>=buf.
size()-(0x9ed+4229-0x1a71)){std::vector<char>glowable_buf(buf.size());while(n>=
glowable_buf.size()-(0x91c+3276-0x15e7)){glowable_buf.resize(glowable_buf.size()
*(0x3b8+4097-0x13b7));
#if defined(_MSC_VER) && _MSC_VER < (0x24bc+96-0x1db0)
n=static_cast<size_t>(_snprintf_s(&glowable_buf[(0x2d6+2839-0xded)],glowable_buf
.size(),glowable_buf.size()-(0x1152+4195-0x21b4),fmt,args...));
#else
n=static_cast<size_t>(snprintf(&glowable_buf[(0x325+3026-0xef7)],glowable_buf.
size()-(0xa13+7000-0x256a),fmt,args...));
#endif
}return write(&glowable_buf[(0x453+4294-0x1519)],n);}else{return write(buf.data(
),n);}}namespace detail{SocketStream::SocketStream(socket_t sock,time_t 
read_timeout_sec,time_t read_timeout_usec,time_t write_timeout_sec,time_t 
write_timeout_usec):sock_(sock),read_timeout_sec_(read_timeout_sec),
read_timeout_usec_(read_timeout_usec),write_timeout_sec_(write_timeout_sec),
write_timeout_usec_(write_timeout_usec){}SocketStream::~SocketStream(){}bool 
SocketStream::is_readable()const{return select_read(sock_,read_timeout_sec_,
read_timeout_usec_)>(0xdd5+4550-0x1f9b);}bool SocketStream::is_writable()const{
return select_write(sock_,write_timeout_sec_,write_timeout_usec_)>
(0x9dc+4290-0x1a9e);}ssize_t SocketStream::read(char*ptr,size_t size){if(!
is_readable()){return-(0x171f+1847-0x1e55);}
#ifdef _WIN32
if(size>static_cast<size_t>((std::numeric_limits<int>::max)())){return-
(0x6eb+87-0x741);}return recv(sock_,ptr,static_cast<int>(size),
CPPHTTPLIB_RECV_FLAGS);
#else
return handle_EINTR([&](){return recv(sock_,ptr,size,CPPHTTPLIB_RECV_FLAGS);});
#endif
}ssize_t SocketStream::write(const char*ptr,size_t size){if(!is_writable()){
return-(0x187f+814-0x1bac);}
#ifdef _WIN32
if(size>static_cast<size_t>((std::numeric_limits<int>::max)())){return-
(0xf2+7219-0x1d24);}return send(sock_,ptr,static_cast<int>(size),
CPPHTTPLIB_SEND_FLAGS);
#else
return handle_EINTR([&](){return send(sock_,ptr,size,CPPHTTPLIB_SEND_FLAGS);});
#endif
}void SocketStream::get_remote_ip_and_port(std::string&ip,int&port)const{return 
detail::get_remote_ip_and_port(sock_,ip,port);}socket_t SocketStream::socket()
const{return sock_;}bool BufferStream::is_readable()const{return true;}bool 
BufferStream::is_writable()const{return true;}ssize_t BufferStream::read(char*
ptr,size_t size){
#if defined(_MSC_VER) && _MSC_VER <= (0x1398+6725-0x2671)
auto len_read=buffer._Copy_s(ptr,size,size,position);
#else
auto len_read=buffer.copy(ptr,size,position);
#endif
position+=static_cast<size_t>(len_read);return static_cast<ssize_t>(len_read);}
ssize_t BufferStream::write(const char*ptr,size_t size){buffer.append(ptr,size);
return static_cast<ssize_t>(size);}void BufferStream::get_remote_ip_and_port(std
::string&,int&)const{}socket_t BufferStream::socket()const{return
(0x1246+1296-0x1756);}const std::string&BufferStream::get_buffer()const{return 
buffer;}}Server::Server():new_task_queue([]{return new ThreadPool(
CPPHTTPLIB_THREAD_POOL_COUNT);}),svr_sock_(INVALID_SOCKET),is_running_(false){
#ifndef _WIN32
signal(SIGPIPE,SIG_IGN);
#endif
}Server::~Server(){}Server&Server::Get(const char*pattern,Handler handler){
return Get(pattern,strlen(pattern),handler);}Server&Server::Get(const char*
pattern,size_t pattern_len,Handler handler){get_handlers_.push_back(std::
make_pair(std::regex(pattern,pattern_len),std::move(handler)));return*this;}
Server&Server::Post(const char*pattern,Handler handler){return Post(pattern,
strlen(pattern),handler);}Server&Server::Post(const char*pattern,size_t 
pattern_len,Handler handler){post_handlers_.push_back(std::make_pair(std::regex(
pattern,pattern_len),std::move(handler)));return*this;}Server&Server::Post(const
 char*pattern,HandlerWithContentReader handler){return Post(pattern,strlen(
pattern),handler);}Server&Server::Post(const char*pattern,size_t pattern_len,
HandlerWithContentReader handler){post_handlers_for_content_reader_.push_back(
std::make_pair(std::regex(pattern,pattern_len),std::move(handler)));return*this;
}Server&Server::Put(const char*pattern,Handler handler){return Put(pattern,
strlen(pattern),handler);}Server&Server::Put(const char*pattern,size_t 
pattern_len,Handler handler){put_handlers_.push_back(std::make_pair(std::regex(
pattern,pattern_len),std::move(handler)));return*this;}Server&Server::Put(const 
char*pattern,HandlerWithContentReader handler){return Put(pattern,strlen(pattern
),handler);}Server&Server::Put(const char*pattern,size_t pattern_len,
HandlerWithContentReader handler){put_handlers_for_content_reader_.push_back(std
::make_pair(std::regex(pattern,pattern_len),std::move(handler)));return*this;}
Server&Server::Patch(const char*pattern,Handler handler){return Patch(pattern,
strlen(pattern),handler);}Server&Server::Patch(const char*pattern,size_t 
pattern_len,Handler handler){patch_handlers_.push_back(std::make_pair(std::regex
(pattern,pattern_len),std::move(handler)));return*this;}Server&Server::Patch(
const char*pattern,HandlerWithContentReader handler){return Patch(pattern,strlen
(pattern),handler);}Server&Server::Patch(const char*pattern,size_t pattern_len,
HandlerWithContentReader handler){patch_handlers_for_content_reader_.push_back(
std::make_pair(std::regex(pattern,pattern_len),std::move(handler)));return*this;
}Server&Server::Delete(const char*pattern,Handler handler){return Delete(pattern
,strlen(pattern),handler);}Server&Server::Delete(const char*pattern,size_t 
pattern_len,Handler handler){delete_handlers_.push_back(std::make_pair(std::
regex(pattern,pattern_len),std::move(handler)));return*this;}Server&Server::
Delete(const char*pattern,HandlerWithContentReader handler){return Delete(
pattern,strlen(pattern),handler);}Server&Server::Delete(const char*pattern,
size_t pattern_len,HandlerWithContentReader handler){
delete_handlers_for_content_reader_.push_back(std::make_pair(std::regex(pattern,
pattern_len),std::move(handler)));return*this;}Server&Server::Options(const char
*pattern,Handler handler){return Options(pattern,strlen(pattern),handler);}
Server&Server::Options(const char*pattern,size_t pattern_len,Handler handler){
options_handlers_.push_back(std::make_pair(std::regex(pattern,pattern_len),std::
move(handler)));return*this;}bool Server::set_base_dir(const char*dir,const char
*mount_point){return set_mount_point(mount_point,dir);}bool Server::
set_mount_point(const char*mount_point,const char*dir,Headers headers){if(detail
::is_dir(dir)){std::string mnt=mount_point?mount_point:"\x2f";if(!mnt.empty()&&
mnt[(0x672+7092-0x2226)]==((char)(0x3fd+932-0x772))){base_dirs_.push_back({mnt,
dir,std::move(headers)});return true;}}return false;}bool Server::
remove_mount_point(const char*mount_point){for(auto it=base_dirs_.begin();it!=
base_dirs_.end();++it){if(it->mount_point==mount_point){base_dirs_.erase(it);
return true;}}return false;}Server&Server::
set_file_extension_and_mimetype_mapping(const char*ext,const char*mime){
file_extension_and_mimetype_map_[ext]=mime;return*this;}Server&Server::
set_file_request_handler(Handler handler){file_request_handler_=std::move(
handler);return*this;}Server&Server::set_error_handler(HandlerWithResponse 
handler){error_handler_=std::move(handler);return*this;}Server&Server::
set_error_handler(Handler handler){error_handler_=[handler](const Request&req,
Response&res){handler(req,res);return HandlerResponse::Handled;};return*this;}
Server&Server::set_exception_handler(ExceptionHandler handler){
exception_handler_=std::move(handler);return*this;}Server&Server::
set_pre_routing_handler(HandlerWithResponse handler){pre_routing_handler_=std::
move(handler);return*this;}Server&Server::set_post_routing_handler(Handler 
handler){post_routing_handler_=std::move(handler);return*this;}Server&Server::
set_logger(Logger logger){logger_=std::move(logger);return*this;}Server&Server::
set_expect_100_continue_handler(Expect100ContinueHandler handler){
expect_100_continue_handler_=std::move(handler);return*this;}Server&Server::
set_tcp_nodelay(bool on){tcp_nodelay_=on;return*this;}Server&Server::
set_socket_options(SocketOptions socket_options){socket_options_=std::move(
socket_options);return*this;}Server&Server::set_keep_alive_max_count(size_t 
count){keep_alive_max_count_=count;return*this;}Server&Server::
set_keep_alive_timeout(time_t sec){keep_alive_timeout_sec_=sec;return*this;}
Server&Server::set_read_timeout(time_t sec,time_t usec){read_timeout_sec_=sec;
read_timeout_usec_=usec;return*this;}Server&Server::set_write_timeout(time_t sec
,time_t usec){write_timeout_sec_=sec;write_timeout_usec_=usec;return*this;}
Server&Server::set_idle_interval(time_t sec,time_t usec){idle_interval_sec_=sec;
idle_interval_usec_=usec;return*this;}Server&Server::set_payload_max_length(
size_t length){payload_max_length_=length;return*this;}bool Server::bind_to_port
(const char*host,int port,int socket_flags){if(bind_internal(host,port,
socket_flags)<(0xabb+2722-0x155d))return false;return true;}int Server::
bind_to_any_port(const char*host,int socket_flags){return bind_internal(host,
(0xcb6+3569-0x1aa7),socket_flags);}bool Server::listen_after_bind(){return 
listen_internal();}bool Server::listen(const char*host,int port,int socket_flags
){return bind_to_port(host,port,socket_flags)&&listen_internal();}bool Server::
is_running()const{return is_running_;}void Server::stop(){if(is_running_){assert
(svr_sock_!=INVALID_SOCKET);std::atomic<socket_t>sock(svr_sock_.exchange(
INVALID_SOCKET));detail::shutdown_socket(sock);detail::close_socket(sock);}}bool
 Server::parse_request_line(const char*s,Request&req){const static std::regex re
(
"\x28\x47\x45\x54\x7c\x48\x45\x41\x44\x7c\x50\x4f\x53\x54\x7c\x50\x55\x54\x7c\x44\x45\x4c\x45\x54\x45\x7c\x43\x4f\x4e\x4e\x45\x43\x54\x7c\x4f\x50\x54\x49\x4f\x4e\x53\x7c\x54\x52\x41\x43\x45\x7c\x50\x41\x54\x43\x48\x7c\x50\x52\x49\x29\x20"
"\x28\x28\x5b\x5e\x3f\x20\x5d\x2b\x29\x28\x3f\x3a" "\\" "\x3f\x28\x5b\x5e\x20\x5d\x2a\x3f\x29\x29\x3f\x29\x20\x28\x48\x54\x54\x50\x2f\x31" "\\" "\x2e\x5b\x30\x31\x5d\x29" "\r\n"
);std::cmatch m;if(std::regex_match(s,m,re)){req.version=std::string(m[
(0x746+4140-0x176d)]);req.method=std::string(m[(0x49+5175-0x147f)]);req.target=
std::string(m[(0x5bb+2186-0xe43)]);req.path=detail::decode_url(m[
(0x1119+5118-0x2514)],false);auto len=std::distance(m[(0x1006+3617-0x1e23)].
first,m[(0x8f3+7344-0x259f)].second);if(len>(0x4aa+465-0x67b)){detail::
parse_query_text(m[(0x54+5567-0x160f)],req.params);}return true;}return false;}
bool Server::write_response(Stream&strm,bool close_connection,const Request&req,
Response&res){return write_response_core(strm,close_connection,req,res,false);}
bool Server::write_response_with_content(Stream&strm,bool close_connection,const
 Request&req,Response&res){return write_response_core(strm,close_connection,req,
res,true);}bool Server::write_response_core(Stream&strm,bool close_connection,
const Request&req,Response&res,bool need_apply_ranges){assert(res.status!=-
(0x16b0+1691-0x1d4a));if((0x11c3+1914-0x17ad)<=res.status&&error_handler_&&
error_handler_(req,res)==HandlerResponse::Handled){need_apply_ranges=true;}std::
string content_type;std::string boundary;if(need_apply_ranges){apply_ranges(req,
res,content_type,boundary);}if(close_connection||req.get_header_value(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")=="\x63\x6c\x6f\x73\x65"){res.
set_header("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e","\x63\x6c\x6f\x73\x65");}
else{std::stringstream ss;ss<<"\x74\x69\x6d\x65\x6f\x75\x74\x3d"<<
keep_alive_timeout_sec_<<"\x2c\x20\x6d\x61\x78\x3d"<<keep_alive_max_count_;res.
set_header("\x4b\x65\x65\x70\x2d\x41\x6c\x69\x76\x65",ss.str());}if(!res.
has_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65")&&(!res.body.empty
()||res.content_length_>(0x143a+547-0x165d)||res.content_provider_)){res.
set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e");}if(!res.has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")&&res.body.empty()&&!
res.content_length_&&!res.content_provider_){res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68","\x30");}if(!res.
has_header("\x41\x63\x63\x65\x70\x74\x2d\x52\x61\x6e\x67\x65\x73")&&req.method==
"\x48\x45\x41\x44"){res.set_header(
"\x41\x63\x63\x65\x70\x74\x2d\x52\x61\x6e\x67\x65\x73","\x62\x79\x74\x65\x73");}
if(post_routing_handler_){post_routing_handler_(req,res);}{detail::BufferStream 
bstrm;if(!bstrm.write_format(
"\x48\x54\x54\x50\x2f\x31\x2e\x31\x20\x25\x64\x20\x25\x73" "\r\n",res.status,
detail::status_message(res.status))){return false;}if(!detail::write_headers(
bstrm,res.headers)){return false;}auto&data=bstrm.get_buffer();strm.write(data.
data(),data.size());}auto ret=true;if(req.method!="\x48\x45\x41\x44"){if(!res.
body.empty()){if(!strm.write(res.body)){ret=false;}}else if(res.
content_provider_){if(!write_content_with_provider(strm,req,res,boundary,
content_type)){ret=false;}}}if(logger_){logger_(req,res);}return ret;}bool 
Server::write_content_with_provider(Stream&strm,const Request&req,Response&res,
const std::string&boundary,const std::string&content_type){auto is_shutting_down
=[this](){return this->svr_sock_==INVALID_SOCKET;};if(res.content_length_>
(0x1a75+2869-0x25aa)){if(req.ranges.empty()){return detail::write_content(strm,
res.content_provider_,(0x512+5746-0x1b84),res.content_length_,is_shutting_down);
}else if(req.ranges.size()==(0x1ff3+915-0x2385)){auto offsets=detail::
get_range_offset_and_length(req,res.content_length_,(0x11ba+689-0x146b));auto 
offset=offsets.first;auto length=offsets.second;return detail::write_content(
strm,res.content_provider_,offset,length,is_shutting_down);}else{return detail::
write_multipart_ranges_data(strm,req,res,boundary,content_type,is_shutting_down)
;}}else{if(res.is_chunked_content_provider_){auto type=detail::encoding_type(req
,res);std::unique_ptr<detail::compressor>compressor;if(type==detail::
EncodingType::Gzip){
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
compressor=detail::make_unique<detail::gzip_compressor>();
#endif
}else if(type==detail::EncodingType::Brotli){
#ifdef CPPHTTPLIB_BROTLI_SUPPORT
compressor=detail::make_unique<detail::brotli_compressor>();
#endif
}else{compressor=detail::make_unique<detail::nocompressor>();}assert(compressor
!=nullptr);return detail::write_content_chunked(strm,res.content_provider_,
is_shutting_down,*compressor);}else{return detail::write_content_without_length(
strm,res.content_provider_,is_shutting_down);}}}bool Server::read_content(Stream
&strm,Request&req,Response&res){MultipartFormDataMap::iterator cur;if(
read_content_core(strm,req,res,[&](const char*buf,size_t n){if(req.body.size()+n
>req.body.max_size()){return false;}req.body.append(buf,n);return true;},[&](
const MultipartFormData&file){cur=req.files.emplace(file.name,file);return true;
},[&](const char*buf,size_t n){auto&content=cur->second.content;if(content.size(
)+n>content.max_size()){return false;}content.append(buf,n);return true;})){
const auto&content_type=req.get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");if(!content_type.find(
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
)){detail::parse_query_text(req.body,req.params);}return true;}return false;}
bool Server::read_content_with_content_receiver(Stream&strm,Request&req,Response
&res,ContentReceiver receiver,MultipartContentHeader multipart_header,
ContentReceiver multipart_receiver){return read_content_core(strm,req,res,std::
move(receiver),std::move(multipart_header),std::move(multipart_receiver));}bool 
Server::read_content_core(Stream&strm,Request&req,Response&res,ContentReceiver 
receiver,MultipartContentHeader mulitpart_header,ContentReceiver 
multipart_receiver){detail::MultipartFormDataParser multipart_form_data_parser;
ContentReceiverWithProgress out;if(req.is_multipart_form_data()){const auto&
content_type=req.get_header_value(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");std::string boundary;if(!
detail::parse_multipart_boundary(content_type,boundary)){res.status=
(0x16bf+48-0x155f);return false;}multipart_form_data_parser.set_boundary(std::
move(boundary));out=[&](const char*buf,size_t n,uint64_t,uint64_t){return 
multipart_form_data_parser.parse(buf,n,multipart_receiver,mulitpart_header);};}
else{out=[receiver](const char*buf,size_t n,uint64_t,uint64_t){return receiver(
buf,n);};}if(req.method=="\x44\x45\x4c\x45\x54\x45"&&!req.has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){return true;}if(!
detail::read_content(strm,req,payload_max_length_,res.status,nullptr,out,true)){
return false;}if(req.is_multipart_form_data()){if(!multipart_form_data_parser.
is_valid()){res.status=(0x5a6+3704-0x128e);return false;}}return true;}bool 
Server::handle_file_request(const Request&req,Response&res,bool head){for(const 
auto&entry:base_dirs_){if(!req.path.compare((0xd25+4199-0x1d8c),entry.
mount_point.size(),entry.mount_point)){std::string sub_path="\x2f"+req.path.
substr(entry.mount_point.size());if(detail::is_valid_path(sub_path)){auto path=
entry.base_dir+sub_path;if(path.back()==((char)(0xd7+1173-0x53d))){path+=
"\x69\x6e\x64\x65\x78\x2e\x68\x74\x6d\x6c";}if(detail::is_file(path)){detail::
read_file(path,res.body);auto type=detail::find_content_type(path,
file_extension_and_mimetype_map_);if(type){res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",type);}for(const auto&kv:
entry.headers){res.set_header(kv.first.c_str(),kv.second);}res.status=req.
has_header("\x52\x61\x6e\x67\x65")?(0x1645+2260-0x1e4b):(0xd08+5422-0x216e);if(!
head&&file_request_handler_){file_request_handler_(req,res);}return true;}}}}
return false;}socket_t Server::create_server_socket(const char*host,int port,int
 socket_flags,SocketOptions socket_options)const{return detail::create_socket(
host,port,socket_flags,tcp_nodelay_,std::move(socket_options),[](socket_t sock,
struct addrinfo&ai)->bool{if(::bind(sock,ai.ai_addr,static_cast<socklen_t>(ai.
ai_addrlen))){return false;}if(::listen(sock,(0x1053+48-0x107e))){return false;}
return true;});}int Server::bind_internal(const char*host,int port,int 
socket_flags){if(!is_valid()){return-(0x479+5530-0x1a12);}svr_sock_=
create_server_socket(host,port,socket_flags,socket_options_);if(svr_sock_==
INVALID_SOCKET){return-(0x24c6+300-0x25f1);}if(port==(0x13c6+895-0x1745)){struct
 sockaddr_storage addr;socklen_t addr_len=sizeof(addr);if(getsockname(svr_sock_,
reinterpret_cast<struct sockaddr*>(&addr),&addr_len)==-(0xf86+4522-0x212f)){
return-(0x1b39+1608-0x2180);}if(addr.ss_family==AF_INET){return ntohs(
reinterpret_cast<struct sockaddr_in*>(&addr)->sin_port);}else if(addr.ss_family
==AF_INET6){return ntohs(reinterpret_cast<struct sockaddr_in6*>(&addr)->
sin6_port);}else{return-(0x145+4987-0x14bf);}}else{return port;}}bool Server::
listen_internal(){auto ret=true;is_running_=true;{std::unique_ptr<TaskQueue>
task_queue(new_task_queue());while(svr_sock_!=INVALID_SOCKET){
#ifndef _WIN32
if(idle_interval_sec_>(0x862+2706-0x12f4)||idle_interval_usec_>
(0x1741+3273-0x240a)){
#endif
auto val=detail::select_read(svr_sock_,idle_interval_sec_,idle_interval_usec_);
if(val==(0x8f2+5167-0x1d21)){task_queue->on_idle();continue;}
#ifndef _WIN32
}
#endif
socket_t sock=accept(svr_sock_,nullptr,nullptr);if(sock==INVALID_SOCKET){if(
errno==EMFILE){std::this_thread::sleep_for(std::chrono::milliseconds(
(0xcb0+2285-0x159c)));continue;}if(svr_sock_!=INVALID_SOCKET){detail::
close_socket(svr_sock_);ret=false;}else{;}break;}
#if __cplusplus > 201703L
task_queue->enqueue([=,this](){process_and_close_socket(sock);});
#else
task_queue->enqueue([=](){process_and_close_socket(sock);});
#endif
}task_queue->shutdown();}is_running_=false;return ret;}bool Server::routing(
Request&req,Response&res,Stream&strm){if(pre_routing_handler_&&
pre_routing_handler_(req,res)==HandlerResponse::Handled){return true;}bool 
is_head_request=req.method=="\x48\x45\x41\x44";if((req.method=="\x47\x45\x54"||
is_head_request)&&handle_file_request(req,res,is_head_request)){return true;}if(
detail::expect_content(req)){{ContentReader reader([&](ContentReceiver receiver)
{return read_content_with_content_receiver(strm,req,res,std::move(receiver),
nullptr,nullptr);},[&](MultipartContentHeader header,ContentReceiver receiver){
return read_content_with_content_receiver(strm,req,res,nullptr,std::move(header)
,std::move(receiver));});if(req.method=="\x50\x4f\x53\x54"){if(
dispatch_request_for_content_reader(req,res,std::move(reader),
post_handlers_for_content_reader_)){return true;}}else if(req.method==
"\x50\x55\x54"){if(dispatch_request_for_content_reader(req,res,std::move(reader)
,put_handlers_for_content_reader_)){return true;}}else if(req.method==
"\x50\x41\x54\x43\x48"){if(dispatch_request_for_content_reader(req,res,std::move
(reader),patch_handlers_for_content_reader_)){return true;}}else if(req.method==
"\x44\x45\x4c\x45\x54\x45"){if(dispatch_request_for_content_reader(req,res,std::
move(reader),delete_handlers_for_content_reader_)){return true;}}}if(!
read_content(strm,req,res)){return false;}}if(req.method=="\x47\x45\x54"||req.
method=="\x48\x45\x41\x44"){return dispatch_request(req,res,get_handlers_);}else
 if(req.method=="\x50\x4f\x53\x54"){return dispatch_request(req,res,
post_handlers_);}else if(req.method=="\x50\x55\x54"){return dispatch_request(req
,res,put_handlers_);}else if(req.method=="\x44\x45\x4c\x45\x54\x45"){return 
dispatch_request(req,res,delete_handlers_);}else if(req.method==
"\x4f\x50\x54\x49\x4f\x4e\x53"){return dispatch_request(req,res,
options_handlers_);}else if(req.method=="\x50\x41\x54\x43\x48"){return 
dispatch_request(req,res,patch_handlers_);}res.status=(0x1059+338-0x101b);return
 false;}bool Server::dispatch_request(Request&req,Response&res,const Handlers&
handlers){for(const auto&x:handlers){const auto&pattern=x.first;const auto&
handler=x.second;if(std::regex_match(req.path,req.matches,pattern)){handler(req,
res);return true;}}return false;}void Server::apply_ranges(const Request&req,
Response&res,std::string&content_type,std::string&boundary){if(req.ranges.size()
>(0x32c+7367-0x1ff2)){boundary=detail::make_multipart_data_boundary();auto it=
res.headers.find("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65");if(it!=res.
headers.end()){content_type=it->second;res.headers.erase(it);}res.headers.
emplace("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x62\x79\x74\x65\x72\x61\x6e\x67\x65\x73\x3b\x20\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d"
+boundary);}auto type=detail::encoding_type(req,res);if(res.body.empty()){if(res
.content_length_>(0x653+1005-0xa40)){size_t length=(0xac8+2864-0x15f8);if(req.
ranges.empty()){length=res.content_length_;}else if(req.ranges.size()==
(0x9db+6325-0x228f)){auto offsets=detail::get_range_offset_and_length(req,res.
content_length_,(0x2b2+4059-0x128d));auto offset=offsets.first;length=offsets.
second;auto content_range=detail::make_content_range_header_field(offset,length,
res.content_length_);res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65",content_range);}else{
length=detail::get_multipart_ranges_data_length(req,res,boundary,content_type);}
res.set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",std::
to_string(length));}else{if(res.content_provider_){if(res.
is_chunked_content_provider_){res.set_header(
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x63\x68\x75\x6e\x6b\x65\x64");if(type==detail::EncodingType::Gzip){res.
set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x67\x7a\x69\x70");}else if(type==detail::EncodingType::Brotli){res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67","\x62\x72");}
}}}}else{if(req.ranges.empty()){;}else if(req.ranges.size()==(0xa79+4292-0x1b3c)
){auto offsets=detail::get_range_offset_and_length(req,res.body.size(),
(0x1c52+1641-0x22bb));auto offset=offsets.first;auto length=offsets.second;auto 
content_range=detail::make_content_range_header_field(offset,length,res.body.
size());res.set_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x52\x61\x6e\x67\x65",
content_range);if(offset<res.body.size()){res.body=res.body.substr(offset,length
);}else{res.body.clear();res.status=(0xbc5+6142-0x2223);}}else{std::string data;
if(detail::make_multipart_ranges_data(req,res,boundary,content_type,data)){res.
body.swap(data);}else{res.body.clear();res.status=(0x11b3+718-0x12e1);}}if(type
!=detail::EncodingType::None){std::unique_ptr<detail::compressor>compressor;std
::string content_encoding;if(type==detail::EncodingType::Gzip){
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
compressor=detail::make_unique<detail::gzip_compressor>();content_encoding=
"\x67\x7a\x69\x70";
#endif
}else if(type==detail::EncodingType::Brotli){
#ifdef CPPHTTPLIB_BROTLI_SUPPORT
compressor=detail::make_unique<detail::brotli_compressor>();content_encoding=
"\x62\x72";
#endif
}if(compressor){std::string compressed;if(compressor->compress(res.body.data(),
res.body.size(),true,[&](const char*data,size_t data_len){compressed.append(data
,data_len);return true;})){res.body.swap(compressed);res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
content_encoding);}}}auto length=std::to_string(res.body.size());res.set_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}bool Server
::dispatch_request_for_content_reader(Request&req,Response&res,ContentReader 
content_reader,const HandlersForContentReader&handlers){for(const auto&x:
handlers){const auto&pattern=x.first;const auto&handler=x.second;if(std::
regex_match(req.path,req.matches,pattern)){handler(req,res,content_reader);
return true;}}return false;}bool Server::process_request(Stream&strm,bool 
close_connection,bool&connection_closed,const std::function<void(Request&)>&
setup_request){std::array<char,(0x1141+2639-0x1390)>buf{};detail::
stream_line_reader line_reader(strm,buf.data(),buf.size());if(!line_reader.
getline()){return false;}Request req;Response res;res.version=
"\x48\x54\x54\x50\x2f\x31\x2e\x31";
#ifdef _WIN32
#else
#ifndef CPPHTTPLIB_USE_POLL
if(strm.socket()>=FD_SETSIZE){Headers dummy;detail::read_headers(strm,dummy);res
.status=(0xf4f+4583-0x1f42);return write_response(strm,close_connection,req,res)
;}
#endif
#endif
if(line_reader.size()>CPPHTTPLIB_REQUEST_URI_MAX_LENGTH){Headers dummy;detail::
read_headers(strm,dummy);res.status=(0xedf+5632-0x2341);return write_response(
strm,close_connection,req,res);}if(!parse_request_line(line_reader.ptr(),req)||!
detail::read_headers(strm,req.headers)){res.status=(0x1140+2470-0x1956);return 
write_response(strm,close_connection,req,res);}if(req.get_header_value(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")=="\x63\x6c\x6f\x73\x65"){
connection_closed=true;}if(req.version=="\x48\x54\x54\x50\x2f\x31\x2e\x30"&&req.
get_header_value("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")!=
"\x4b\x65\x65\x70\x2d\x41\x6c\x69\x76\x65"){connection_closed=true;}strm.
get_remote_ip_and_port(req.remote_addr,req.remote_port);req.set_header(
"\x52\x45\x4d\x4f\x54\x45\x5f\x41\x44\x44\x52",req.remote_addr);req.set_header(
"\x52\x45\x4d\x4f\x54\x45\x5f\x50\x4f\x52\x54",std::to_string(req.remote_port));
if(req.has_header("\x52\x61\x6e\x67\x65")){const auto&range_header_value=req.
get_header_value("\x52\x61\x6e\x67\x65");if(!detail::parse_range_header(
range_header_value,req.ranges)){res.status=(0xabd+118-0x993);return 
write_response(strm,close_connection,req,res);}}if(setup_request){setup_request(
req);}if(req.get_header_value("\x45\x78\x70\x65\x63\x74")==
"\x31\x30\x30\x2d\x63\x6f\x6e\x74\x69\x6e\x75\x65"){auto status=
(0x2e6+2355-0xbb5);if(expect_100_continue_handler_){status=
expect_100_continue_handler_(req,res);}switch(status){case(0x1672+3240-0x22b6):
case(0x24d2+608-0x2591):strm.write_format(
"\x48\x54\x54\x50\x2f\x31\x2e\x31\x20\x25\x64\x20\x25\x73" "\r\n\r\n",status,
detail::status_message(status));break;default:return write_response(strm,
close_connection,req,res);}}bool routed=false;try{routed=routing(req,res,strm);}
catch(std::exception&e){if(exception_handler_){exception_handler_(req,res,e);
routed=true;}else{res.status=(0xabb+2543-0x12b6);res.set_header(
"\x45\x58\x43\x45\x50\x54\x49\x4f\x4e\x5f\x57\x48\x41\x54",e.what());}}catch(...
){res.status=(0x485+984-0x669);res.set_header(
"\x45\x58\x43\x45\x50\x54\x49\x4f\x4e\x5f\x57\x48\x41\x54",
"\x55\x4e\x4b\x4e\x4f\x57\x4e");}if(routed){if(res.status==-(0x929+6942-0x2446))
{res.status=req.ranges.empty()?(0xabd+4268-0x1aa1):(0x66c+1184-0xa3e);}return 
write_response_with_content(strm,close_connection,req,res);}else{if(res.status==
-(0x17d+4523-0x1327)){res.status=(0x1f51+2131-0x2610);}return write_response(
strm,close_connection,req,res);}}bool Server::is_valid()const{return true;}bool 
Server::process_and_close_socket(socket_t sock){auto ret=detail::
process_server_socket(sock,keep_alive_max_count_,keep_alive_timeout_sec_,
read_timeout_sec_,read_timeout_usec_,write_timeout_sec_,write_timeout_usec_,[
this](Stream&strm,bool close_connection,bool&connection_closed){return 
process_request(strm,close_connection,connection_closed,nullptr);});detail::
shutdown_socket(sock);detail::close_socket(sock);return ret;}ClientImpl::
ClientImpl(const std::string&host):ClientImpl(host,(0x232c+1-0x22dd),std::string
(),std::string()){}ClientImpl::ClientImpl(const std::string&host,int port):
ClientImpl(host,port,std::string(),std::string()){}ClientImpl::ClientImpl(const 
std::string&host,int port,const std::string&client_cert_path,const std::string&
client_key_path):host_(host),port_(port),host_and_port_(host_+"\x3a"+std::
to_string(port_)),client_cert_path_(client_cert_path),client_key_path_(
client_key_path){}ClientImpl::~ClientImpl(){lock_socket_and_shutdown_and_close()
;}bool ClientImpl::is_valid()const{return true;}void ClientImpl::copy_settings(
const ClientImpl&rhs){client_cert_path_=rhs.client_cert_path_;client_key_path_=
rhs.client_key_path_;connection_timeout_sec_=rhs.connection_timeout_sec_;
read_timeout_sec_=rhs.read_timeout_sec_;read_timeout_usec_=rhs.
read_timeout_usec_;write_timeout_sec_=rhs.write_timeout_sec_;write_timeout_usec_
=rhs.write_timeout_usec_;basic_auth_username_=rhs.basic_auth_username_;
basic_auth_password_=rhs.basic_auth_password_;bearer_token_auth_token_=rhs.
bearer_token_auth_token_;
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
digest_auth_username_=rhs.digest_auth_username_;digest_auth_password_=rhs.
digest_auth_password_;
#endif
keep_alive_=rhs.keep_alive_;follow_location_=rhs.follow_location_;tcp_nodelay_=
rhs.tcp_nodelay_;socket_options_=rhs.socket_options_;compress_=rhs.compress_;
decompress_=rhs.decompress_;interface_=rhs.interface_;proxy_host_=rhs.
proxy_host_;proxy_port_=rhs.proxy_port_;proxy_basic_auth_username_=rhs.
proxy_basic_auth_username_;proxy_basic_auth_password_=rhs.
proxy_basic_auth_password_;proxy_bearer_token_auth_token_=rhs.
proxy_bearer_token_auth_token_;
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
proxy_digest_auth_username_=rhs.proxy_digest_auth_username_;
proxy_digest_auth_password_=rhs.proxy_digest_auth_password_;
#endif
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
server_certificate_verification_=rhs.server_certificate_verification_;
#endif
logger_=rhs.logger_;}socket_t ClientImpl::create_client_socket(Error&error)const
{if(!proxy_host_.empty()&&proxy_port_!=-(0x579+4666-0x17b2)){return detail::
create_client_socket(proxy_host_.c_str(),proxy_port_,tcp_nodelay_,
socket_options_,connection_timeout_sec_,connection_timeout_usec_,interface_,
error);}return detail::create_client_socket(host_.c_str(),port_,tcp_nodelay_,
socket_options_,connection_timeout_sec_,connection_timeout_usec_,interface_,
error);}bool ClientImpl::create_and_connect_socket(Socket&socket,Error&error){
auto sock=create_client_socket(error);if(sock==INVALID_SOCKET){return false;}
socket.sock=sock;return true;}void ClientImpl::shutdown_ssl(Socket&,bool){assert
(socket_requests_in_flight_==(0x1a26+2853-0x254b)||
socket_requests_are_from_thread_==std::this_thread::get_id());}void ClientImpl::
shutdown_socket(Socket&socket){if(socket.sock==INVALID_SOCKET){return;}detail::
shutdown_socket(socket.sock);}void ClientImpl::close_socket(Socket&socket){
assert(socket_requests_in_flight_==(0x142+6187-0x196d)||
socket_requests_are_from_thread_==std::this_thread::get_id());
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
assert(socket.ssl==nullptr);
#endif
if(socket.sock==INVALID_SOCKET){return;}detail::close_socket(socket.sock);socket
.sock=INVALID_SOCKET;}void ClientImpl::lock_socket_and_shutdown_and_close(){std
::lock_guard<std::mutex>guard(socket_mutex_);shutdown_ssl(socket_,true);
shutdown_socket(socket_);close_socket(socket_);}bool ClientImpl::
read_response_line(Stream&strm,const Request&req,Response&res){std::array<char,
(0x1b20+4518-0x24c6)>buf;detail::stream_line_reader line_reader(strm,buf.data(),
buf.size());if(!line_reader.getline()){return false;}const static std::regex re(
"\x28\x48\x54\x54\x50\x2f\x31" "\\" "\x2e\x5b\x30\x31\x5d\x29\x20\x28" "\\" "\x64\x7b\x33\x7d\x29\x20\x28\x2e\x2a\x3f\x29" "\r\n"
);std::cmatch m;if(!std::regex_match(line_reader.ptr(),m,re)){return req.method
=="\x43\x4f\x4e\x4e\x45\x43\x54";}res.version=std::string(m[(0x108+8942-0x23f5)]
);res.status=std::stoi(std::string(m[(0xbdf+5768-0x2265)]));res.reason=std::
string(m[(0x11d4+4729-0x244a)]);while(res.status==(0xa90+6435-0x234f)){if(!
line_reader.getline()){return false;}if(!line_reader.getline()){return false;}if
(!std::regex_match(line_reader.ptr(),m,re)){return false;}res.version=std::
string(m[(0x907+480-0xae6)]);res.status=std::stoi(std::string(m[
(0xe9a+1433-0x1431)]));res.reason=std::string(m[(0x1152+3194-0x1dc9)]);}return 
true;}bool ClientImpl::send(Request&req,Response&res,Error&error){std::
lock_guard<std::recursive_mutex>request_mutex_guard(request_mutex_);{std::
lock_guard<std::mutex>guard(socket_mutex_);
socket_should_be_closed_when_request_is_done_=false;auto is_alive=false;if(
socket_.is_open()){is_alive=detail::select_write(socket_.sock,
(0xed4+4442-0x202e),(0x1a4+8814-0x2412))>(0xb20+3199-0x179f);if(!is_alive){const
 bool shutdown_gracefully=false;shutdown_ssl(socket_,shutdown_gracefully);
shutdown_socket(socket_);close_socket(socket_);}}if(!is_alive){if(!
create_and_connect_socket(socket_,error)){return false;}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
if(is_ssl()){auto&scli=static_cast<SSLClient&>(*this);if(!proxy_host_.empty()&&
proxy_port_!=-(0x1260+728-0x1537)){bool success=false;if(!scli.
connect_with_proxy(socket_,res,success,error)){return success;}}if(!scli.
initialize_ssl(socket_,error)){return false;}}
#endif
}if(socket_requests_in_flight_>(0xb7+2500-0xa7a)){assert(
socket_requests_are_from_thread_==std::this_thread::get_id());}
socket_requests_in_flight_+=(0x1490+1998-0x1c5d);
socket_requests_are_from_thread_=std::this_thread::get_id();}for(const auto&
header:default_headers_){if(req.headers.find(header.first)==req.headers.end()){
req.headers.insert(header);}}auto close_connection=!keep_alive_;auto ret=
process_socket(socket_,[&](Stream&strm){return handle_request(strm,req,res,
close_connection,error);});{std::lock_guard<std::mutex>guard(socket_mutex_);
socket_requests_in_flight_-=(0x174f+1124-0x1bb2);if(socket_requests_in_flight_<=
(0xfad+1698-0x164f)){assert(socket_requests_in_flight_==(0x5ff+52-0x633));
socket_requests_are_from_thread_=std::thread::id();}if(
socket_should_be_closed_when_request_is_done_||close_connection||!ret){
shutdown_ssl(socket_,true);shutdown_socket(socket_);close_socket(socket_);}}if(!
ret){if(error==Error::Success){error=Error::Unknown;}}return ret;}Result 
ClientImpl::send(const Request&req){auto req2=req;return send_(std::move(req2));
}Result ClientImpl::send_(Request&&req){auto res=detail::make_unique<Response>()
;auto error=Error::Success;auto ret=send(req,*res,error);return Result{ret?std::
move(res):nullptr,error,std::move(req.headers)};}bool ClientImpl::handle_request
(Stream&strm,Request&req,Response&res,bool close_connection,Error&error){if(req.
path.empty()){error=Error::Connection;return false;}auto req_save=req;bool ret;
if(!is_ssl()&&!proxy_host_.empty()&&proxy_port_!=-(0xe70+5191-0x22b6)){auto req2
=req;req2.path="\x68\x74\x74\x70\x3a\x2f\x2f"+host_and_port_+req.path;ret=
process_request(strm,req2,res,close_connection,error);req=req2;req.path=req_save
.path;}else{ret=process_request(strm,req,res,close_connection,error);}if(!ret){
return false;}if((0x18c2+872-0x1afe)<res.status&&res.status<(0xa56+5853-0x1fa3)
&&follow_location_){req=req_save;ret=redirect(req,res,error);}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
if((res.status==(0x6ca+5027-0x18dc)||res.status==(0x325+6053-0x1933))&&req.
authorization_count_<(0x1ba+7627-0x1f80)){auto is_proxy=res.status==
(0x1420+2328-0x1ba1);const auto&username=is_proxy?proxy_digest_auth_username_:
digest_auth_username_;const auto&password=is_proxy?proxy_digest_auth_password_:
digest_auth_password_;if(!username.empty()&&!password.empty()){std::map<std::
string,std::string>auth;if(detail::parse_www_authenticate(res,auth,is_proxy)){
Request new_req=req;new_req.authorization_count_+=(0x6d4+5706-0x1d1d);auto key=
is_proxy?
"\x50\x72\x6f\x78\x79\x2d\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e":
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e";new_req.headers.erase(key
);new_req.headers.insert(detail::make_digest_authentication_header(req,auth,
new_req.authorization_count_,detail::random_string((0x1ebc+957-0x226f)),username
,password,is_proxy));Response new_res;ret=send(new_req,new_res,error);if(ret){
res=new_res;}}}}
#endif
return ret;}bool ClientImpl::redirect(Request&req,Response&res,Error&error){if(
req.redirect_count_==(0x10b4+5002-0x243e)){error=Error::ExceedRedirectCount;
return false;}auto location=detail::decode_url(res.get_header_value(
"\x6c\x6f\x63\x61\x74\x69\x6f\x6e"),true);if(location.empty()){return false;}
const static std::regex re(
R"(^(?:(https?):)?(?://([^:/?#]*)(?::(\d+))?)?([^?#]*(?:\?[^#]*)?)(?:#.*)?)");
std::smatch m;if(!std::regex_match(location,m,re)){return false;}auto scheme=
is_ssl()?"\x68\x74\x74\x70\x73":"\x68\x74\x74\x70";auto next_scheme=m[
(0x1757+2238-0x2014)].str();auto next_host=m[(0x8+7205-0x1c2b)].str();auto 
port_str=m[(0x134b+1524-0x193c)].str();auto next_path=m[(0xf4d+1084-0x1385)].str
();auto next_port=port_;if(!port_str.empty()){next_port=std::stoi(port_str);}
else if(!next_scheme.empty()){next_port=next_scheme=="\x68\x74\x74\x70\x73"?
(0x1992+2927-0x2346):(0x1740+3400-0x2438);}if(next_scheme.empty()){next_scheme=
scheme;}if(next_host.empty()){next_host=host_;}if(next_path.empty()){next_path=
"\x2f";}if(next_scheme==scheme&&next_host==host_&&next_port==port_){return 
detail::redirect(*this,req,res,next_path,location,error);}else{if(next_scheme==
"\x68\x74\x74\x70\x73"){
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
SSLClient cli(next_host.c_str(),next_port);cli.copy_settings(*this);return 
detail::redirect(cli,req,res,next_path,location,error);
#else
return false;
#endif
}else{ClientImpl cli(next_host.c_str(),next_port);cli.copy_settings(*this);
return detail::redirect(cli,req,res,next_path,location,error);}}}bool ClientImpl
::write_content_with_provider(Stream&strm,const Request&req,Error&error){auto 
is_shutting_down=[](){return false;};if(req.is_chunked_content_provider_){std::
unique_ptr<detail::compressor>compressor;
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
if(compress_){compressor=detail::make_unique<detail::gzip_compressor>();}else
#endif
{compressor=detail::make_unique<detail::nocompressor>();}return detail::
write_content_chunked(strm,req.content_provider_,is_shutting_down,*compressor,
error);}else{return detail::write_content(strm,req.content_provider_,
(0x11f0+347-0x134b),req.content_length_,is_shutting_down,error);}}bool 
ClientImpl::write_request(Stream&strm,Request&req,bool close_connection,Error&
error){if(close_connection){req.headers.emplace(
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e","\x63\x6c\x6f\x73\x65");}if(!req.
has_header("\x48\x6f\x73\x74")){if(is_ssl()){if(port_==(0xe15+6553-0x25f3)){req.
headers.emplace("\x48\x6f\x73\x74",host_);}else{req.headers.emplace(
"\x48\x6f\x73\x74",host_and_port_);}}else{if(port_==(0x1aab+1419-0x1fe6)){req.
headers.emplace("\x48\x6f\x73\x74",host_);}else{req.headers.emplace(
"\x48\x6f\x73\x74",host_and_port_);}}}if(!req.has_header(
"\x41\x63\x63\x65\x70\x74")){req.headers.emplace("\x41\x63\x63\x65\x70\x74",
"\x2a\x2f\x2a");}if(!req.has_header("\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74"))
{req.headers.emplace("\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74",
"\x63\x70\x70\x2d\x68\x74\x74\x70\x6c\x69\x62\x2f\x30\x2e\x37");}if(req.body.
empty()){if(req.content_provider_){if(!req.is_chunked_content_provider_){auto 
length=std::to_string(req.content_length_);req.headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}else{if(req
.method=="\x50\x4f\x53\x54"||req.method=="\x50\x55\x54"||req.method==
"\x50\x41\x54\x43\x48"){req.headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68","\x30");}}}else{if(!
req.has_header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65")){req.headers.
emplace("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
"\x74\x65\x78\x74\x2f\x70\x6c\x61\x69\x6e");}if(!req.has_header(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68")){auto length=std::
to_string(req.body.size());req.headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68",length);}}if(!
basic_auth_password_.empty()){req.headers.insert(
make_basic_authentication_header(basic_auth_username_,basic_auth_password_,false
));}if(!proxy_basic_auth_username_.empty()&&!proxy_basic_auth_password_.empty())
{req.headers.insert(make_basic_authentication_header(proxy_basic_auth_username_,
proxy_basic_auth_password_,true));}if(!bearer_token_auth_token_.empty()){req.
headers.insert(make_bearer_token_authentication_header(bearer_token_auth_token_,
false));}if(!proxy_bearer_token_auth_token_.empty()){req.headers.insert(
make_bearer_token_authentication_header(proxy_bearer_token_auth_token_,true));}{
detail::BufferStream bstrm;const auto&path=detail::encode_url(req.path);bstrm.
write_format("\x25\x73\x20\x25\x73\x20\x48\x54\x54\x50\x2f\x31\x2e\x31" "\r\n",
req.method.c_str(),path.c_str());detail::write_headers(bstrm,req.headers);auto&
data=bstrm.get_buffer();if(!detail::write_data(strm,data.data(),data.size())){
error=Error::Write;return false;}}if(req.body.empty()){return 
write_content_with_provider(strm,req,error);}else{return detail::write_data(strm
,req.body.data(),req.body.size());}return true;}std::unique_ptr<Response>
ClientImpl::send_with_content_provider(Request&req,const char*body,size_t 
content_length,ContentProvider content_provider,ContentProviderWithoutLength 
content_provider_without_length,const char*content_type,Error&error){if(
content_type){req.headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",content_type);}
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
if(compress_){req.headers.emplace(
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x67\x7a\x69\x70");}
#endif
#ifdef CPPHTTPLIB_ZLIB_SUPPORT
if(compress_&&!content_provider_without_length){detail::gzip_compressor 
compressor;if(content_provider){auto ok=true;size_t offset=(0x4aa+5036-0x1856);
DataSink data_sink;data_sink.write=[&](const char*data,size_t data_len){if(ok){
auto last=offset+data_len==content_length;auto ret=compressor.compress(data,
data_len,last,[&](const char*data,size_t data_len){req.body.append(data,data_len
);return true;});if(ret){offset+=data_len;}else{ok=false;}}};data_sink.
is_writable=[&](void){return ok&&true;};while(ok&&offset<content_length){if(!
content_provider(offset,content_length-offset,data_sink)){error=Error::Canceled;
return nullptr;}}}else{if(!compressor.compress(body,content_length,true,[&](
const char*data,size_t data_len){req.body.append(data,data_len);return true;})){
error=Error::Compression;return nullptr;}}}else
#endif
{if(content_provider){req.content_length_=content_length;req.content_provider_=
std::move(content_provider);req.is_chunked_content_provider_=false;}else if(
content_provider_without_length){req.content_length_=(0x11c5+223-0x12a4);req.
content_provider_=detail::ContentProviderAdapter(std::move(
content_provider_without_length));req.is_chunked_content_provider_=true;req.
headers.emplace(
"\x54\x72\x61\x6e\x73\x66\x65\x72\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67",
"\x63\x68\x75\x6e\x6b\x65\x64");}else{req.body.assign(body,content_length);;}}
auto res=detail::make_unique<Response>();return send(req,*res,error)?std::move(
res):nullptr;}Result ClientImpl::send_with_content_provider(const char*method,
const char*path,const Headers&headers,const char*body,size_t content_length,
ContentProvider content_provider,ContentProviderWithoutLength 
content_provider_without_length,const char*content_type){Request req;req.method=
method;req.headers=headers;req.path=path;auto error=Error::Success;auto res=
send_with_content_provider(req,body,content_length,std::move(content_provider),
std::move(content_provider_without_length),content_type,error);return Result{std
::move(res),error,std::move(req.headers)};}bool ClientImpl::process_request(
Stream&strm,Request&req,Response&res,bool close_connection,Error&error){if(!
write_request(strm,req,close_connection,error)){return false;}if(!
read_response_line(strm,req,res)||!detail::read_headers(strm,res.headers)){error
=Error::Read;return false;}if(req.response_handler){if(!req.response_handler(res
)){error=Error::Canceled;return false;}}if((res.status!=(0x477+6887-0x1e92))&&
req.method!="\x48\x45\x41\x44"&&req.method!="\x43\x4f\x4e\x4e\x45\x43\x54"){auto
 out=req.content_receiver?static_cast<ContentReceiverWithProgress>([&](const 
char*buf,size_t n,uint64_t off,uint64_t len){auto ret=req.content_receiver(buf,n
,off,len);if(!ret){error=Error::Canceled;}return ret;}):static_cast<
ContentReceiverWithProgress>([&](const char*buf,size_t n,uint64_t,uint64_t){if(
res.body.size()+n>res.body.max_size()){return false;}res.body.append(buf,n);
return true;});auto progress=[&](uint64_t current,uint64_t total){if(!req.
progress){return true;}auto ret=req.progress(current,total);if(!ret){error=Error
::Canceled;}return ret;};int dummy_status;if(!detail::read_content(strm,res,(std
::numeric_limits<size_t>::max)(),dummy_status,std::move(progress),std::move(out)
,decompress_)){if(error!=Error::Canceled){error=Error::Read;}return false;}}if(
res.get_header_value("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e")==
"\x63\x6c\x6f\x73\x65"||(res.version=="\x48\x54\x54\x50\x2f\x31\x2e\x30"&&res.
reason!=
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x65\x73\x74\x61\x62\x6c\x69\x73\x68\x65\x64"
)){lock_socket_and_shutdown_and_close();}if(logger_){logger_(req,res);}return 
true;}bool ClientImpl::process_socket(const Socket&socket,std::function<bool(
Stream&strm)>callback){return detail::process_client_socket(socket.sock,
read_timeout_sec_,read_timeout_usec_,write_timeout_sec_,write_timeout_usec_,std
::move(callback));}bool ClientImpl::is_ssl()const{return false;}Result 
ClientImpl::Get(const char*path){return Get(path,Headers(),Progress());}Result 
ClientImpl::Get(const char*path,Progress progress){return Get(path,Headers(),std
::move(progress));}Result ClientImpl::Get(const char*path,const Headers&headers)
{return Get(path,headers,Progress());}Result ClientImpl::Get(const char*path,
const Headers&headers,Progress progress){Request req;req.method="\x47\x45\x54";
req.path=path;req.headers=headers;req.progress=std::move(progress);return send_(
std::move(req));}Result ClientImpl::Get(const char*path,ContentReceiver 
content_receiver){return Get(path,Headers(),nullptr,std::move(content_receiver),
nullptr);}Result ClientImpl::Get(const char*path,ContentReceiver 
content_receiver,Progress progress){return Get(path,Headers(),nullptr,std::move(
content_receiver),std::move(progress));}Result ClientImpl::Get(const char*path,
const Headers&headers,ContentReceiver content_receiver){return Get(path,headers,
nullptr,std::move(content_receiver),nullptr);}Result ClientImpl::Get(const char*
path,const Headers&headers,ContentReceiver content_receiver,Progress progress){
return Get(path,headers,nullptr,std::move(content_receiver),std::move(progress))
;}Result ClientImpl::Get(const char*path,ResponseHandler response_handler,
ContentReceiver content_receiver){return Get(path,Headers(),std::move(
response_handler),std::move(content_receiver),nullptr);}Result ClientImpl::Get(
const char*path,const Headers&headers,ResponseHandler response_handler,
ContentReceiver content_receiver){return Get(path,headers,std::move(
response_handler),std::move(content_receiver),nullptr);}Result ClientImpl::Get(
const char*path,ResponseHandler response_handler,ContentReceiver 
content_receiver,Progress progress){return Get(path,Headers(),std::move(
response_handler),std::move(content_receiver),std::move(progress));}Result 
ClientImpl::Get(const char*path,const Headers&headers,ResponseHandler 
response_handler,ContentReceiver content_receiver,Progress progress){Request req
;req.method="\x47\x45\x54";req.path=path;req.headers=headers;req.
response_handler=std::move(response_handler);req.content_receiver=[
content_receiver](const char*data,size_t data_length,uint64_t,uint64_t){return 
content_receiver(data,data_length);};req.progress=std::move(progress);return 
send_(std::move(req));}Result ClientImpl::Get(const char*path,const Params&
params,const Headers&headers,Progress progress){if(params.empty()){return Get(
path,headers);}std::string path_with_query=detail::append_query_params(path,
params);return Get(path_with_query.c_str(),headers,progress);}Result ClientImpl
::Get(const char*path,const Params&params,const Headers&headers,ContentReceiver 
content_receiver,Progress progress){return Get(path,params,headers,nullptr,
content_receiver,progress);}Result ClientImpl::Get(const char*path,const Params&
params,const Headers&headers,ResponseHandler response_handler,ContentReceiver 
content_receiver,Progress progress){if(params.empty()){return Get(path,headers,
response_handler,content_receiver,progress);}std::string path_with_query=detail
::append_query_params(path,params);return Get(path_with_query.c_str(),params,
headers,response_handler,content_receiver,progress);}Result ClientImpl::Head(
const char*path){return Head(path,Headers());}Result ClientImpl::Head(const char
*path,const Headers&headers){Request req;req.method="\x48\x45\x41\x44";req.
headers=headers;req.path=path;return send_(std::move(req));}Result ClientImpl::
Post(const char*path){return Post(path,std::string(),nullptr);}Result ClientImpl
::Post(const char*path,const char*body,size_t content_length,const char*
content_type){return Post(path,Headers(),body,content_length,content_type);}
Result ClientImpl::Post(const char*path,const Headers&headers,const char*body,
size_t content_length,const char*content_type){return send_with_content_provider
("\x50\x4f\x53\x54",path,headers,body,content_length,nullptr,nullptr,
content_type);}Result ClientImpl::Post(const char*path,const std::string&body,
const char*content_type){return Post(path,Headers(),body,content_type);}Result 
ClientImpl::Post(const char*path,const Headers&headers,const std::string&body,
const char*content_type){return send_with_content_provider("\x50\x4f\x53\x54",
path,headers,body.data(),body.size(),nullptr,nullptr,content_type);}Result 
ClientImpl::Post(const char*path,const Params&params){return Post(path,Headers()
,params);}Result ClientImpl::Post(const char*path,size_t content_length,
ContentProvider content_provider,const char*content_type){return Post(path,
Headers(),content_length,std::move(content_provider),content_type);}Result 
ClientImpl::Post(const char*path,ContentProviderWithoutLength content_provider,
const char*content_type){return Post(path,Headers(),std::move(content_provider),
content_type);}Result ClientImpl::Post(const char*path,const Headers&headers,
size_t content_length,ContentProvider content_provider,const char*content_type){
return send_with_content_provider("\x50\x4f\x53\x54",path,headers,nullptr,
content_length,std::move(content_provider),nullptr,content_type);}Result 
ClientImpl::Post(const char*path,const Headers&headers,
ContentProviderWithoutLength content_provider,const char*content_type){return 
send_with_content_provider("\x50\x4f\x53\x54",path,headers,nullptr,
(0x8b5+2111-0x10f4),nullptr,std::move(content_provider),content_type);}Result 
ClientImpl::Post(const char*path,const Headers&headers,const Params&params){auto
 query=detail::params_to_query_str(params);return Post(path,headers,query,
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
);}Result ClientImpl::Post(const char*path,const MultipartFormDataItems&items){
return Post(path,Headers(),items);}Result ClientImpl::Post(const char*path,const
 Headers&headers,const MultipartFormDataItems&items){return Post(path,headers,
items,detail::make_multipart_data_boundary());}Result ClientImpl::Post(const 
char*path,const Headers&headers,const MultipartFormDataItems&items,const std::
string&boundary){for(size_t i=(0x412+3352-0x112a);i<boundary.size();i++){char c=
boundary[i];if(!std::isalnum(c)&&c!=((char)(0x12b5+3716-0x210c))&&c!=
((char)(0x29c+5691-0x1878))){return Result{nullptr,Error::
UnsupportedMultipartBoundaryChars};}}std::string body;for(const auto&item:items)
{body+="\x2d\x2d"+boundary+"\r\n";body+=
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x44\x69\x73\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x20\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b\x20\x6e\x61\x6d\x65\x3d" "\""
+item.name+"\"";if(!item.filename.empty()){body+=
"\x3b\x20\x66\x69\x6c\x65\x6e\x61\x6d\x65\x3d" "\""+item.filename+"\"";}body+=
"\r\n";if(!item.content_type.empty()){body+=
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20"+item.content_type+
"\r\n";}body+="\r\n";body+=item.content+"\r\n";}body+="\x2d\x2d"+boundary+
"\x2d\x2d" "\r\n";std::string content_type=
"\x6d\x75\x6c\x74\x69\x70\x61\x72\x74\x2f\x66\x6f\x72\x6d\x2d\x64\x61\x74\x61\x3b\x20\x62\x6f\x75\x6e\x64\x61\x72\x79\x3d"
+boundary;return Post(path,headers,body,content_type.c_str());}Result ClientImpl
::Put(const char*path){return Put(path,std::string(),nullptr);}Result ClientImpl
::Put(const char*path,const char*body,size_t content_length,const char*
content_type){return Put(path,Headers(),body,content_length,content_type);}
Result ClientImpl::Put(const char*path,const Headers&headers,const char*body,
size_t content_length,const char*content_type){return send_with_content_provider
("\x50\x55\x54",path,headers,body,content_length,nullptr,nullptr,content_type);}
Result ClientImpl::Put(const char*path,const std::string&body,const char*
content_type){return Put(path,Headers(),body,content_type);}Result ClientImpl::
Put(const char*path,const Headers&headers,const std::string&body,const char*
content_type){return send_with_content_provider("\x50\x55\x54",path,headers,body
.data(),body.size(),nullptr,nullptr,content_type);}Result ClientImpl::Put(const 
char*path,size_t content_length,ContentProvider content_provider,const char*
content_type){return Put(path,Headers(),content_length,std::move(
content_provider),content_type);}Result ClientImpl::Put(const char*path,
ContentProviderWithoutLength content_provider,const char*content_type){return 
Put(path,Headers(),std::move(content_provider),content_type);}Result ClientImpl
::Put(const char*path,const Headers&headers,size_t content_length,
ContentProvider content_provider,const char*content_type){return 
send_with_content_provider("\x50\x55\x54",path,headers,nullptr,content_length,
std::move(content_provider),nullptr,content_type);}Result ClientImpl::Put(const 
char*path,const Headers&headers,ContentProviderWithoutLength content_provider,
const char*content_type){return send_with_content_provider("\x50\x55\x54",path,
headers,nullptr,(0xa69+6675-0x247c),nullptr,std::move(content_provider),
content_type);}Result ClientImpl::Put(const char*path,const Params&params){
return Put(path,Headers(),params);}Result ClientImpl::Put(const char*path,const 
Headers&headers,const Params&params){auto query=detail::params_to_query_str(
params);return Put(path,headers,query,
"\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x78\x2d\x77\x77\x77\x2d\x66\x6f\x72\x6d\x2d\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x64"
);}Result ClientImpl::Patch(const char*path){return Patch(path,std::string(),
nullptr);}Result ClientImpl::Patch(const char*path,const char*body,size_t 
content_length,const char*content_type){return Patch(path,Headers(),body,
content_length,content_type);}Result ClientImpl::Patch(const char*path,const 
Headers&headers,const char*body,size_t content_length,const char*content_type){
return send_with_content_provider("\x50\x41\x54\x43\x48",path,headers,body,
content_length,nullptr,nullptr,content_type);}Result ClientImpl::Patch(const 
char*path,const std::string&body,const char*content_type){return Patch(path,
Headers(),body,content_type);}Result ClientImpl::Patch(const char*path,const 
Headers&headers,const std::string&body,const char*content_type){return 
send_with_content_provider("\x50\x41\x54\x43\x48",path,headers,body.data(),body.
size(),nullptr,nullptr,content_type);}Result ClientImpl::Patch(const char*path,
size_t content_length,ContentProvider content_provider,const char*content_type){
return Patch(path,Headers(),content_length,std::move(content_provider),
content_type);}Result ClientImpl::Patch(const char*path,
ContentProviderWithoutLength content_provider,const char*content_type){return 
Patch(path,Headers(),std::move(content_provider),content_type);}Result 
ClientImpl::Patch(const char*path,const Headers&headers,size_t content_length,
ContentProvider content_provider,const char*content_type){return 
send_with_content_provider("\x50\x41\x54\x43\x48",path,headers,nullptr,
content_length,std::move(content_provider),nullptr,content_type);}Result 
ClientImpl::Patch(const char*path,const Headers&headers,
ContentProviderWithoutLength content_provider,const char*content_type){return 
send_with_content_provider("\x50\x41\x54\x43\x48",path,headers,nullptr,
(0xf01+3930-0x1e5b),nullptr,std::move(content_provider),content_type);}Result 
ClientImpl::Delete(const char*path){return Delete(path,Headers(),std::string(),
nullptr);}Result ClientImpl::Delete(const char*path,const Headers&headers){
return Delete(path,headers,std::string(),nullptr);}Result ClientImpl::Delete(
const char*path,const char*body,size_t content_length,const char*content_type){
return Delete(path,Headers(),body,content_length,content_type);}Result 
ClientImpl::Delete(const char*path,const Headers&headers,const char*body,size_t 
content_length,const char*content_type){Request req;req.method=
"\x44\x45\x4c\x45\x54\x45";req.headers=headers;req.path=path;if(content_type){
req.headers.emplace("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65",
content_type);}req.body.assign(body,content_length);return send_(std::move(req))
;}Result ClientImpl::Delete(const char*path,const std::string&body,const char*
content_type){return Delete(path,Headers(),body.data(),body.size(),content_type)
;}Result ClientImpl::Delete(const char*path,const Headers&headers,const std::
string&body,const char*content_type){return Delete(path,headers,body.data(),body
.size(),content_type);}Result ClientImpl::Options(const char*path){return 
Options(path,Headers());}Result ClientImpl::Options(const char*path,const 
Headers&headers){Request req;req.method="\x4f\x50\x54\x49\x4f\x4e\x53";req.
headers=headers;req.path=path;return send_(std::move(req));}size_t ClientImpl::
is_socket_open()const{std::lock_guard<std::mutex>guard(socket_mutex_);return 
socket_.is_open();}void ClientImpl::stop(){std::lock_guard<std::mutex>guard(
socket_mutex_);if(socket_requests_in_flight_>(0x18c9+949-0x1c7e)){
shutdown_socket(socket_);socket_should_be_closed_when_request_is_done_=true;
return;}shutdown_ssl(socket_,true);shutdown_socket(socket_);close_socket(socket_
);}void ClientImpl::set_connection_timeout(time_t sec,time_t usec){
connection_timeout_sec_=sec;connection_timeout_usec_=usec;}void ClientImpl::
set_read_timeout(time_t sec,time_t usec){read_timeout_sec_=sec;
read_timeout_usec_=usec;}void ClientImpl::set_write_timeout(time_t sec,time_t 
usec){write_timeout_sec_=sec;write_timeout_usec_=usec;}void ClientImpl::
set_basic_auth(const char*username,const char*password){basic_auth_username_=
username;basic_auth_password_=password;}void ClientImpl::set_bearer_token_auth(
const char*token){bearer_token_auth_token_=token;}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void ClientImpl::set_digest_auth(const char*username,const char*password){
digest_auth_username_=username;digest_auth_password_=password;}
#endif
void ClientImpl::set_keep_alive(bool on){keep_alive_=on;}void ClientImpl::
set_follow_location(bool on){follow_location_=on;}void ClientImpl::
set_default_headers(Headers headers){default_headers_=std::move(headers);}void 
ClientImpl::set_tcp_nodelay(bool on){tcp_nodelay_=on;}void ClientImpl::
set_socket_options(SocketOptions socket_options){socket_options_=std::move(
socket_options);}void ClientImpl::set_compress(bool on){compress_=on;}void 
ClientImpl::set_decompress(bool on){decompress_=on;}void ClientImpl::
set_interface(const char*intf){interface_=intf;}void ClientImpl::set_proxy(const
 char*host,int port){proxy_host_=host;proxy_port_=port;}void ClientImpl::
set_proxy_basic_auth(const char*username,const char*password){
proxy_basic_auth_username_=username;proxy_basic_auth_password_=password;}void 
ClientImpl::set_proxy_bearer_token_auth(const char*token){
proxy_bearer_token_auth_token_=token;}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void ClientImpl::set_proxy_digest_auth(const char*username,const char*password){
proxy_digest_auth_username_=username;proxy_digest_auth_password_=password;}
#endif
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void ClientImpl::enable_server_certificate_verification(bool enabled){
server_certificate_verification_=enabled;}
#endif
void ClientImpl::set_logger(Logger logger){logger_=std::move(logger);}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
namespace detail{template<typename U,typename V>SSL*ssl_new(socket_t sock,
SSL_CTX*ctx,std::mutex&ctx_mutex,U SSL_connect_or_accept,V setup){SSL*ssl=
nullptr;{std::lock_guard<std::mutex>guard(ctx_mutex);ssl=SSL_new(ctx);}if(ssl){
set_nonblocking(sock,true);auto bio=BIO_new_socket(static_cast<int>(sock),
BIO_NOCLOSE);BIO_set_nbio(bio,(0x8d0+7102-0x248d));SSL_set_bio(ssl,bio,bio);if(!
setup(ssl)||SSL_connect_or_accept(ssl)!=(0x376+5559-0x192c)){SSL_shutdown(ssl);{
std::lock_guard<std::mutex>guard(ctx_mutex);SSL_free(ssl);}set_nonblocking(sock,
false);return nullptr;}BIO_set_nbio(bio,(0x1161+3951-0x20d0));set_nonblocking(
sock,false);}return ssl;}void ssl_delete(std::mutex&ctx_mutex,SSL*ssl,bool 
shutdown_gracefully){if(shutdown_gracefully){SSL_shutdown(ssl);}std::lock_guard<
std::mutex>guard(ctx_mutex);SSL_free(ssl);}template<typename U>bool 
ssl_connect_or_accept_nonblocking(socket_t sock,SSL*ssl,U ssl_connect_or_accept,
time_t timeout_sec,time_t timeout_usec){int res=(0x813+302-0x941);while((res=
ssl_connect_or_accept(ssl))!=(0x1624+1489-0x1bf4)){auto err=SSL_get_error(ssl,
res);switch(err){case SSL_ERROR_WANT_READ:if(select_read(sock,timeout_sec,
timeout_usec)>(0x605+6285-0x1e92)){continue;}break;case SSL_ERROR_WANT_WRITE:if(
select_write(sock,timeout_sec,timeout_usec)>(0x1705+1789-0x1e02)){continue;}
break;default:break;}return false;}return true;}template<typename T>bool 
process_server_socket_ssl(SSL*ssl,socket_t sock,size_t keep_alive_max_count,
time_t keep_alive_timeout_sec,time_t read_timeout_sec,time_t read_timeout_usec,
time_t write_timeout_sec,time_t write_timeout_usec,T callback){return 
process_server_socket_core(sock,keep_alive_max_count,keep_alive_timeout_sec,[&](
bool close_connection,bool&connection_closed){SSLSocketStream strm(sock,ssl,
read_timeout_sec,read_timeout_usec,write_timeout_sec,write_timeout_usec);return 
callback(strm,close_connection,connection_closed);});}template<typename T>bool 
process_client_socket_ssl(SSL*ssl,socket_t sock,time_t read_timeout_sec,time_t 
read_timeout_usec,time_t write_timeout_sec,time_t write_timeout_usec,T callback)
{SSLSocketStream strm(sock,ssl,read_timeout_sec,read_timeout_usec,
write_timeout_sec,write_timeout_usec);return callback(strm);}
#if OPENSSL_VERSION_NUMBER < 0x10100000L
static std::shared_ptr<std::vector<std::mutex>>openSSL_locks_;class 
SSLThreadLocks{public:SSLThreadLocks(){openSSL_locks_=std::make_shared<std::
vector<std::mutex>>(CRYPTO_num_locks());CRYPTO_set_locking_callback(
locking_callback);}~SSLThreadLocks(){CRYPTO_set_locking_callback(nullptr);}
private:static void locking_callback(int mode,int type,const char*,int){auto&lk=
(*openSSL_locks_)[static_cast<size_t>(type)];if(mode&CRYPTO_LOCK){lk.lock();}
else{lk.unlock();}}};
#endif
class SSLInit{public:SSLInit(){
#if OPENSSL_VERSION_NUMBER < 0x1010001fL
SSL_load_error_strings();SSL_library_init();
#else
OPENSSL_init_ssl(OPENSSL_INIT_LOAD_SSL_STRINGS|OPENSSL_INIT_LOAD_CRYPTO_STRINGS,
NULL);
#endif
}~SSLInit(){
#if OPENSSL_VERSION_NUMBER < 0x1010001fL
ERR_free_strings();
#endif
}private:
#if OPENSSL_VERSION_NUMBER < 0x10100000L
SSLThreadLocks thread_init_;
#endif
};SSLSocketStream::SSLSocketStream(socket_t sock,SSL*ssl,time_t read_timeout_sec
,time_t read_timeout_usec,time_t write_timeout_sec,time_t write_timeout_usec):
sock_(sock),ssl_(ssl),read_timeout_sec_(read_timeout_sec),read_timeout_usec_(
read_timeout_usec),write_timeout_sec_(write_timeout_sec),write_timeout_usec_(
write_timeout_usec){SSL_clear_mode(ssl,SSL_MODE_AUTO_RETRY);}SSLSocketStream::~
SSLSocketStream(){}bool SSLSocketStream::is_readable()const{return detail::
select_read(sock_,read_timeout_sec_,read_timeout_usec_)>(0x3dc+166-0x482);}bool 
SSLSocketStream::is_writable()const{return detail::select_write(sock_,
write_timeout_sec_,write_timeout_usec_)>(0xec6+2318-0x17d4);}ssize_t 
SSLSocketStream::read(char*ptr,size_t size){if(SSL_pending(ssl_)>
(0x1e52+1500-0x242e)){return SSL_read(ssl_,ptr,static_cast<int>(size));}else if(
is_readable()){auto ret=SSL_read(ssl_,ptr,static_cast<int>(size));if(ret<
(0xe25+4672-0x2065)){auto err=SSL_get_error(ssl_,ret);while(err==
SSL_ERROR_WANT_READ){if(SSL_pending(ssl_)>(0x1299+2069-0x1aae)){return SSL_read(
ssl_,ptr,static_cast<int>(size));}else if(is_readable()){ret=SSL_read(ssl_,ptr,
static_cast<int>(size));if(ret>=(0xf39+3999-0x1ed8)){return ret;}err=
SSL_get_error(ssl_,ret);}else{return-(0x1174+1650-0x17e5);}}}return ret;}return-
(0x3f4+1338-0x92d);}ssize_t SSLSocketStream::write(const char*ptr,size_t size){
if(is_writable()){return SSL_write(ssl_,ptr,static_cast<int>(size));}return-
(0x23dd+601-0x2635);}void SSLSocketStream::get_remote_ip_and_port(std::string&ip
,int&port)const{detail::get_remote_ip_and_port(sock_,ip,port);}socket_t 
SSLSocketStream::socket()const{return sock_;}static SSLInit sslinit_;}SSLServer
::SSLServer(const char*cert_path,const char*private_key_path,const char*
client_ca_cert_file_path,const char*client_ca_cert_dir_path){ctx_=SSL_CTX_new(
SSLv23_server_method());if(ctx_){SSL_CTX_set_options(ctx_,SSL_OP_ALL|
SSL_OP_NO_SSLv2|SSL_OP_NO_SSLv3|SSL_OP_NO_COMPRESSION|
SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION);if(
SSL_CTX_use_certificate_chain_file(ctx_,cert_path)!=(0xc8b+2078-0x14a8)||
SSL_CTX_use_PrivateKey_file(ctx_,private_key_path,SSL_FILETYPE_PEM)!=
(0x16bc+311-0x17f2)){SSL_CTX_free(ctx_);ctx_=nullptr;}else if(
client_ca_cert_file_path||client_ca_cert_dir_path){SSL_CTX_load_verify_locations
(ctx_,client_ca_cert_file_path,client_ca_cert_dir_path);SSL_CTX_set_verify(ctx_,
SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT,nullptr);}}}SSLServer::SSLServer
(X509*cert,EVP_PKEY*private_key,X509_STORE*client_ca_cert_store){ctx_=
SSL_CTX_new(SSLv23_server_method());if(ctx_){SSL_CTX_set_options(ctx_,SSL_OP_ALL
|SSL_OP_NO_SSLv2|SSL_OP_NO_SSLv3|SSL_OP_NO_COMPRESSION|
SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION);if(SSL_CTX_use_certificate(ctx_,
cert)!=(0x1153+3439-0x1ec1)||SSL_CTX_use_PrivateKey(ctx_,private_key)!=
(0xc4b+5391-0x2159)){SSL_CTX_free(ctx_);ctx_=nullptr;}else if(
client_ca_cert_store){SSL_CTX_set_cert_store(ctx_,client_ca_cert_store);
SSL_CTX_set_verify(ctx_,SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT,nullptr)
;}}}SSLServer::~SSLServer(){if(ctx_){SSL_CTX_free(ctx_);}}bool SSLServer::
is_valid()const{return ctx_;}bool SSLServer::process_and_close_socket(socket_t 
sock){auto ssl=detail::ssl_new(sock,ctx_,ctx_mutex_,[&](SSL*ssl){return detail::
ssl_connect_or_accept_nonblocking(sock,ssl,SSL_accept,read_timeout_sec_,
read_timeout_usec_);},[](SSL*){return true;});bool ret=false;if(ssl){ret=detail
::process_server_socket_ssl(ssl,sock,keep_alive_max_count_,
keep_alive_timeout_sec_,read_timeout_sec_,read_timeout_usec_,write_timeout_sec_,
write_timeout_usec_,[this,ssl](Stream&strm,bool close_connection,bool&
connection_closed){return process_request(strm,close_connection,
connection_closed,[&](Request&req){req.ssl=ssl;});});const bool 
shutdown_gracefully=ret;detail::ssl_delete(ctx_mutex_,ssl,shutdown_gracefully);}
detail::shutdown_socket(sock);detail::close_socket(sock);return ret;}SSLClient::
SSLClient(const std::string&host):SSLClient(host,(0x25a1+555-0x2611),std::string
(),std::string()){}SSLClient::SSLClient(const std::string&host,int port):
SSLClient(host,port,std::string(),std::string()){}SSLClient::SSLClient(const std
::string&host,int port,const std::string&client_cert_path,const std::string&
client_key_path):ClientImpl(host,port,client_cert_path,client_key_path){ctx_=
SSL_CTX_new(SSLv23_client_method());detail::split(&host_[(0x855+5346-0x1d37)],&
host_[host_.size()],((char)(0x103b+814-0x133b)),[&](const char*b,const char*e){
host_components_.emplace_back(std::string(b,e));});if(!client_cert_path.empty()
&&!client_key_path.empty()){if(SSL_CTX_use_certificate_file(ctx_,
client_cert_path.c_str(),SSL_FILETYPE_PEM)!=(0x444+3148-0x108f)||
SSL_CTX_use_PrivateKey_file(ctx_,client_key_path.c_str(),SSL_FILETYPE_PEM)!=
(0x1120+190-0x11dd)){SSL_CTX_free(ctx_);ctx_=nullptr;}}}SSLClient::SSLClient(
const std::string&host,int port,X509*client_cert,EVP_PKEY*client_key):ClientImpl
(host,port){ctx_=SSL_CTX_new(SSLv23_client_method());detail::split(&host_[
(0x14f2+3612-0x230e)],&host_[host_.size()],((char)(0x30a+8171-0x22c7)),[&](const
 char*b,const char*e){host_components_.emplace_back(std::string(b,e));});if(
client_cert!=nullptr&&client_key!=nullptr){if(SSL_CTX_use_certificate(ctx_,
client_cert)!=(0x4b3+5779-0x1b45)||SSL_CTX_use_PrivateKey(ctx_,client_key)!=
(0x16a4+2116-0x1ee7)){SSL_CTX_free(ctx_);ctx_=nullptr;}}}SSLClient::~SSLClient()
{if(ctx_){SSL_CTX_free(ctx_);}SSLClient::shutdown_ssl(socket_,true);}bool 
SSLClient::is_valid()const{return ctx_;}void SSLClient::set_ca_cert_path(const 
char*ca_cert_file_path,const char*ca_cert_dir_path){if(ca_cert_file_path){
ca_cert_file_path_=ca_cert_file_path;}if(ca_cert_dir_path){ca_cert_dir_path_=
ca_cert_dir_path;}}void SSLClient::set_ca_cert_store(X509_STORE*ca_cert_store){
if(ca_cert_store){if(ctx_){if(SSL_CTX_get_cert_store(ctx_)!=ca_cert_store){
SSL_CTX_set_cert_store(ctx_,ca_cert_store);}}else{X509_STORE_free(ca_cert_store)
;}}}long SSLClient::get_openssl_verify_result()const{return verify_result_;}
SSL_CTX*SSLClient::ssl_context()const{return ctx_;}bool SSLClient::
create_and_connect_socket(Socket&socket,Error&error){return is_valid()&&
ClientImpl::create_and_connect_socket(socket,error);}bool SSLClient::
connect_with_proxy(Socket&socket,Response&res,bool&success,Error&error){success=
true;Response res2;if(!detail::process_client_socket(socket.sock,
read_timeout_sec_,read_timeout_usec_,write_timeout_sec_,write_timeout_usec_,[&](
Stream&strm){Request req2;req2.method="\x43\x4f\x4e\x4e\x45\x43\x54";req2.path=
host_and_port_;return process_request(strm,req2,res2,false,error);})){
shutdown_ssl(socket,true);shutdown_socket(socket);close_socket(socket);success=
false;return false;}if(res2.status==(0x237b+1111-0x263b)){if(!
proxy_digest_auth_username_.empty()&&!proxy_digest_auth_password_.empty()){std::
map<std::string,std::string>auth;if(detail::parse_www_authenticate(res2,auth,
true)){Response res3;if(!detail::process_client_socket(socket.sock,
read_timeout_sec_,read_timeout_usec_,write_timeout_sec_,write_timeout_usec_,[&](
Stream&strm){Request req3;req3.method="\x43\x4f\x4e\x4e\x45\x43\x54";req3.path=
host_and_port_;req3.headers.insert(detail::make_digest_authentication_header(
req3,auth,(0x8a8+1917-0x1024),detail::random_string((0x8a2+4948-0x1bec)),
proxy_digest_auth_username_,proxy_digest_auth_password_,true));return 
process_request(strm,req3,res3,false,error);})){shutdown_ssl(socket,true);
shutdown_socket(socket);close_socket(socket);success=false;return false;}}}else{
res=res2;return false;}}return true;}bool SSLClient::load_certs(){bool ret=true;
std::call_once(initialize_cert_,[&](){std::lock_guard<std::mutex>guard(
ctx_mutex_);if(!ca_cert_file_path_.empty()){if(!SSL_CTX_load_verify_locations(
ctx_,ca_cert_file_path_.c_str(),nullptr)){ret=false;}}else if(!ca_cert_dir_path_
.empty()){if(!SSL_CTX_load_verify_locations(ctx_,nullptr,ca_cert_dir_path_.c_str
())){ret=false;}}else{
#ifdef _WIN32
detail::load_system_certs_on_windows(SSL_CTX_get_cert_store(ctx_));
#else
SSL_CTX_set_default_verify_paths(ctx_);
#endif
}});return ret;}bool SSLClient::initialize_ssl(Socket&socket,Error&error){auto 
ssl=detail::ssl_new(socket.sock,ctx_,ctx_mutex_,[&](SSL*ssl){if(
server_certificate_verification_){if(!load_certs()){error=Error::SSLLoadingCerts
;return false;}SSL_set_verify(ssl,SSL_VERIFY_NONE,nullptr);}if(!detail::
ssl_connect_or_accept_nonblocking(socket.sock,ssl,SSL_connect,
connection_timeout_sec_,connection_timeout_usec_)){error=Error::SSLConnection;
return false;}if(server_certificate_verification_){verify_result_=
SSL_get_verify_result(ssl);if(verify_result_!=X509_V_OK){error=Error::
SSLServerVerification;return false;}auto server_cert=SSL_get_peer_certificate(
ssl);if(server_cert==nullptr){error=Error::SSLServerVerification;return false;}
if(!verify_host(server_cert)){X509_free(server_cert);error=Error::
SSLServerVerification;return false;}X509_free(server_cert);}return true;},[&](
SSL*ssl){SSL_set_tlsext_host_name(ssl,host_.c_str());return true;});if(ssl){
socket.ssl=ssl;return true;}shutdown_socket(socket);close_socket(socket);return 
false;}void SSLClient::shutdown_ssl(Socket&socket,bool shutdown_gracefully){if(
socket.sock==INVALID_SOCKET){assert(socket.ssl==nullptr);return;}if(socket.ssl){
detail::ssl_delete(ctx_mutex_,socket.ssl,shutdown_gracefully);socket.ssl=nullptr
;}assert(socket.ssl==nullptr);}bool SSLClient::process_socket(const Socket&
socket,std::function<bool(Stream&strm)>callback){assert(socket.ssl);return 
detail::process_client_socket_ssl(socket.ssl,socket.sock,read_timeout_sec_,
read_timeout_usec_,write_timeout_sec_,write_timeout_usec_,std::move(callback));}
bool SSLClient::is_ssl()const{return true;}bool SSLClient::verify_host(X509*
server_cert)const{return verify_host_with_subject_alt_name(server_cert)||
verify_host_with_common_name(server_cert);}bool SSLClient::
verify_host_with_subject_alt_name(X509*server_cert)const{auto ret=false;auto 
type=GEN_DNS;struct in6_addr addr6;struct in_addr addr;size_t addr_len=
(0x6a+2837-0xb7f);
#ifndef __MINGW32__
if(inet_pton(AF_INET6,host_.c_str(),&addr6)){type=GEN_IPADD;addr_len=sizeof(
struct in6_addr);}else if(inet_pton(AF_INET,host_.c_str(),&addr)){type=GEN_IPADD
;addr_len=sizeof(struct in_addr);}
#endif
auto alt_names=static_cast<const struct stack_st_GENERAL_NAME*>(X509_get_ext_d2i
(server_cert,NID_subject_alt_name,nullptr,nullptr));if(alt_names){auto 
dsn_matched=false;auto ip_mached=false;auto count=sk_GENERAL_NAME_num(alt_names)
;for(decltype(count)i=(0x1921+1254-0x1e07);i<count&&!dsn_matched;i++){auto val=
sk_GENERAL_NAME_value(alt_names,i);if(val->type==type){auto name=(const char*)
ASN1_STRING_get0_data(val->d.ia5);auto name_len=(size_t)ASN1_STRING_length(val->
d.ia5);switch(type){case GEN_DNS:dsn_matched=check_host_name(name,name_len);
break;case GEN_IPADD:if(!memcmp(&addr6,name,addr_len)||!memcmp(&addr,name,
addr_len)){ip_mached=true;}break;}}}if(dsn_matched||ip_mached){ret=true;}}
GENERAL_NAMES_free((STACK_OF(GENERAL_NAME)*)alt_names);return ret;}bool 
SSLClient::verify_host_with_common_name(X509*server_cert)const{const auto 
subject_name=X509_get_subject_name(server_cert);if(subject_name!=nullptr){char 
name[BUFSIZ];auto name_len=X509_NAME_get_text_by_NID(subject_name,NID_commonName
,name,sizeof(name));if(name_len!=-(0x11e5+3429-0x1f49)){return check_host_name(
name,static_cast<size_t>(name_len));}}return false;}bool SSLClient::
check_host_name(const char*pattern,size_t pattern_len)const{if(host_.size()==
pattern_len&&host_==pattern){return true;}std::vector<std::string>
pattern_components;detail::split(&pattern[(0x6d8+500-0x8cc)],&pattern[
pattern_len],((char)(0x6d0+2865-0x11d3)),[&](const char*b,const char*e){
pattern_components.emplace_back(std::string(b,e));});if(host_components_.size()
!=pattern_components.size()){return false;}auto itr=pattern_components.begin();
for(const auto&h:host_components_){auto&p=*itr;if(p!=h&&p!="\x2a"){auto 
partial_match=(p.size()>(0x6af+3532-0x147b)&&p[p.size()-(0xac6+2607-0x14f4)]==
((char)(0x8e0+1821-0xfd3))&&!p.compare((0x6a6+4414-0x17e4),p.size()-
(0x15f1+673-0x1891),h));if(!partial_match){return false;}}++itr;}return true;}
#endif
Client::Client(const char*scheme_host_port):Client(scheme_host_port,std::string(
),std::string()){}Client::Client(const char*scheme_host_port,const std::string&
client_cert_path,const std::string&client_key_path){const static std::regex re(
R"(^(?:([a-z]+)://)?([^:/?#]+)(?::(\d+))?)");std::cmatch m;if(std::regex_match(
scheme_host_port,m,re)){auto scheme=m[(0x427+5486-0x1994)].str();
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
if(!scheme.empty()&&(scheme!="\x68\x74\x74\x70"&&scheme!="\x68\x74\x74\x70\x73")
){
#else
if(!scheme.empty()&&scheme!="\x68\x74\x74\x70"){
#endif
std::string msg="\x27"+scheme+
"\x27\x20\x73\x63\x68\x65\x6d\x65\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x2e"
;throw std::invalid_argument(msg);return;}auto is_ssl=scheme==
"\x68\x74\x74\x70\x73";auto host=m[(0x12b8+2875-0x1df1)].str();auto port_str=m[
(0x5f1+6463-0x1f2d)].str();auto port=!port_str.empty()?std::stoi(port_str):(
is_ssl?(0x4d9+3497-0x10c7):(0x1482+2080-0x1c52));if(is_ssl){
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
cli_=detail::make_unique<SSLClient>(host.c_str(),port,client_cert_path,
client_key_path);is_ssl_=is_ssl;
#endif
}else{cli_=detail::make_unique<ClientImpl>(host.c_str(),port,client_cert_path,
client_key_path);}}else{cli_=detail::make_unique<ClientImpl>(scheme_host_port,
(0x209+4242-0x124b),client_cert_path,client_key_path);}}Client::Client(const std
::string&host,int port):cli_(detail::make_unique<ClientImpl>(host,port)){}Client
::Client(const std::string&host,int port,const std::string&client_cert_path,
const std::string&client_key_path):cli_(detail::make_unique<ClientImpl>(host,
port,client_cert_path,client_key_path)){}Client::~Client(){}bool Client::
is_valid()const{return cli_!=nullptr&&cli_->is_valid();}Result Client::Get(const
 char*path){return cli_->Get(path);}Result Client::Get(const char*path,const 
Headers&headers){return cli_->Get(path,headers);}Result Client::Get(const char*
path,Progress progress){return cli_->Get(path,std::move(progress));}Result 
Client::Get(const char*path,const Headers&headers,Progress progress){return cli_
->Get(path,headers,std::move(progress));}Result Client::Get(const char*path,
ContentReceiver content_receiver){return cli_->Get(path,std::move(
content_receiver));}Result Client::Get(const char*path,const Headers&headers,
ContentReceiver content_receiver){return cli_->Get(path,headers,std::move(
content_receiver));}Result Client::Get(const char*path,ContentReceiver 
content_receiver,Progress progress){return cli_->Get(path,std::move(
content_receiver),std::move(progress));}Result Client::Get(const char*path,const
 Headers&headers,ContentReceiver content_receiver,Progress progress){return cli_
->Get(path,headers,std::move(content_receiver),std::move(progress));}Result 
Client::Get(const char*path,ResponseHandler response_handler,ContentReceiver 
content_receiver){return cli_->Get(path,std::move(response_handler),std::move(
content_receiver));}Result Client::Get(const char*path,const Headers&headers,
ResponseHandler response_handler,ContentReceiver content_receiver){return cli_->
Get(path,headers,std::move(response_handler),std::move(content_receiver));}
Result Client::Get(const char*path,ResponseHandler response_handler,
ContentReceiver content_receiver,Progress progress){return cli_->Get(path,std::
move(response_handler),std::move(content_receiver),std::move(progress));}Result 
Client::Get(const char*path,const Headers&headers,ResponseHandler 
response_handler,ContentReceiver content_receiver,Progress progress){return cli_
->Get(path,headers,std::move(response_handler),std::move(content_receiver),std::
move(progress));}Result Client::Get(const char*path,const Params&params,const 
Headers&headers,Progress progress){return cli_->Get(path,params,headers,progress
);}Result Client::Get(const char*path,const Params&params,const Headers&headers,
ContentReceiver content_receiver,Progress progress){return cli_->Get(path,params
,headers,content_receiver,progress);}Result Client::Get(const char*path,const 
Params&params,const Headers&headers,ResponseHandler response_handler,
ContentReceiver content_receiver,Progress progress){return cli_->Get(path,params
,headers,response_handler,content_receiver,progress);}Result Client::Head(const 
char*path){return cli_->Head(path);}Result Client::Head(const char*path,const 
Headers&headers){return cli_->Head(path,headers);}Result Client::Post(const char
*path){return cli_->Post(path);}Result Client::Post(const char*path,const char*
body,size_t content_length,const char*content_type){return cli_->Post(path,body,
content_length,content_type);}Result Client::Post(const char*path,const Headers&
headers,const char*body,size_t content_length,const char*content_type){return 
cli_->Post(path,headers,body,content_length,content_type);}Result Client::Post(
const char*path,const std::string&body,const char*content_type){return cli_->
Post(path,body,content_type);}Result Client::Post(const char*path,const Headers&
headers,const std::string&body,const char*content_type){return cli_->Post(path,
headers,body,content_type);}Result Client::Post(const char*path,size_t 
content_length,ContentProvider content_provider,const char*content_type){return 
cli_->Post(path,content_length,std::move(content_provider),content_type);}Result
 Client::Post(const char*path,ContentProviderWithoutLength content_provider,
const char*content_type){return cli_->Post(path,std::move(content_provider),
content_type);}Result Client::Post(const char*path,const Headers&headers,size_t 
content_length,ContentProvider content_provider,const char*content_type){return 
cli_->Post(path,headers,content_length,std::move(content_provider),content_type)
;}Result Client::Post(const char*path,const Headers&headers,
ContentProviderWithoutLength content_provider,const char*content_type){return 
cli_->Post(path,headers,std::move(content_provider),content_type);}Result Client
::Post(const char*path,const Params&params){return cli_->Post(path,params);}
Result Client::Post(const char*path,const Headers&headers,const Params&params){
return cli_->Post(path,headers,params);}Result Client::Post(const char*path,
const MultipartFormDataItems&items){return cli_->Post(path,items);}Result Client
::Post(const char*path,const Headers&headers,const MultipartFormDataItems&items)
{return cli_->Post(path,headers,items);}Result Client::Post(const char*path,
const Headers&headers,const MultipartFormDataItems&items,const std::string&
boundary){return cli_->Post(path,headers,items,boundary);}Result Client::Put(
const char*path){return cli_->Put(path);}Result Client::Put(const char*path,
const char*body,size_t content_length,const char*content_type){return cli_->Put(
path,body,content_length,content_type);}Result Client::Put(const char*path,const
 Headers&headers,const char*body,size_t content_length,const char*content_type){
return cli_->Put(path,headers,body,content_length,content_type);}Result Client::
Put(const char*path,const std::string&body,const char*content_type){return cli_
->Put(path,body,content_type);}Result Client::Put(const char*path,const Headers&
headers,const std::string&body,const char*content_type){return cli_->Put(path,
headers,body,content_type);}Result Client::Put(const char*path,size_t 
content_length,ContentProvider content_provider,const char*content_type){return 
cli_->Put(path,content_length,std::move(content_provider),content_type);}Result 
Client::Put(const char*path,ContentProviderWithoutLength content_provider,const 
char*content_type){return cli_->Put(path,std::move(content_provider),
content_type);}Result Client::Put(const char*path,const Headers&headers,size_t 
content_length,ContentProvider content_provider,const char*content_type){return 
cli_->Put(path,headers,content_length,std::move(content_provider),content_type);
}Result Client::Put(const char*path,const Headers&headers,
ContentProviderWithoutLength content_provider,const char*content_type){return 
cli_->Put(path,headers,std::move(content_provider),content_type);}Result Client
::Put(const char*path,const Params&params){return cli_->Put(path,params);}Result
 Client::Put(const char*path,const Headers&headers,const Params&params){return 
cli_->Put(path,headers,params);}Result Client::Patch(const char*path){return 
cli_->Patch(path);}Result Client::Patch(const char*path,const char*body,size_t 
content_length,const char*content_type){return cli_->Patch(path,body,
content_length,content_type);}Result Client::Patch(const char*path,const Headers
&headers,const char*body,size_t content_length,const char*content_type){return 
cli_->Patch(path,headers,body,content_length,content_type);}Result Client::Patch
(const char*path,const std::string&body,const char*content_type){return cli_->
Patch(path,body,content_type);}Result Client::Patch(const char*path,const 
Headers&headers,const std::string&body,const char*content_type){return cli_->
Patch(path,headers,body,content_type);}Result Client::Patch(const char*path,
size_t content_length,ContentProvider content_provider,const char*content_type){
return cli_->Patch(path,content_length,std::move(content_provider),content_type)
;}Result Client::Patch(const char*path,ContentProviderWithoutLength 
content_provider,const char*content_type){return cli_->Patch(path,std::move(
content_provider),content_type);}Result Client::Patch(const char*path,const 
Headers&headers,size_t content_length,ContentProvider content_provider,const 
char*content_type){return cli_->Patch(path,headers,content_length,std::move(
content_provider),content_type);}Result Client::Patch(const char*path,const 
Headers&headers,ContentProviderWithoutLength content_provider,const char*
content_type){return cli_->Patch(path,headers,std::move(content_provider),
content_type);}Result Client::Delete(const char*path){return cli_->Delete(path);
}Result Client::Delete(const char*path,const Headers&headers){return cli_->
Delete(path,headers);}Result Client::Delete(const char*path,const char*body,
size_t content_length,const char*content_type){return cli_->Delete(path,body,
content_length,content_type);}Result Client::Delete(const char*path,const 
Headers&headers,const char*body,size_t content_length,const char*content_type){
return cli_->Delete(path,headers,body,content_length,content_type);}Result 
Client::Delete(const char*path,const std::string&body,const char*content_type){
return cli_->Delete(path,body,content_type);}Result Client::Delete(const char*
path,const Headers&headers,const std::string&body,const char*content_type){
return cli_->Delete(path,headers,body,content_type);}Result Client::Options(
const char*path){return cli_->Options(path);}Result Client::Options(const char*
path,const Headers&headers){return cli_->Options(path,headers);}bool Client::
send(Request&req,Response&res,Error&error){return cli_->send(req,res,error);}
Result Client::send(const Request&req){return cli_->send(req);}size_t Client::
is_socket_open()const{return cli_->is_socket_open();}void Client::stop(){cli_->
stop();}void Client::set_default_headers(Headers headers){cli_->
set_default_headers(std::move(headers));}void Client::set_tcp_nodelay(bool on){
cli_->set_tcp_nodelay(on);}void Client::set_socket_options(SocketOptions 
socket_options){cli_->set_socket_options(std::move(socket_options));}void Client
::set_connection_timeout(time_t sec,time_t usec){cli_->set_connection_timeout(
sec,usec);}void Client::set_read_timeout(time_t sec,time_t usec){cli_->
set_read_timeout(sec,usec);}void Client::set_write_timeout(time_t sec,time_t 
usec){cli_->set_write_timeout(sec,usec);}void Client::set_basic_auth(const char*
username,const char*password){cli_->set_basic_auth(username,password);}void 
Client::set_bearer_token_auth(const char*token){cli_->set_bearer_token_auth(
token);}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void Client::set_digest_auth(const char*username,const char*password){cli_->
set_digest_auth(username,password);}
#endif
void Client::set_keep_alive(bool on){cli_->set_keep_alive(on);}void Client::
set_follow_location(bool on){cli_->set_follow_location(on);}void Client::
set_compress(bool on){cli_->set_compress(on);}void Client::set_decompress(bool 
on){cli_->set_decompress(on);}void Client::set_interface(const char*intf){cli_->
set_interface(intf);}void Client::set_proxy(const char*host,int port){cli_->
set_proxy(host,port);}void Client::set_proxy_basic_auth(const char*username,
const char*password){cli_->set_proxy_basic_auth(username,password);}void Client
::set_proxy_bearer_token_auth(const char*token){cli_->
set_proxy_bearer_token_auth(token);}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void Client::set_proxy_digest_auth(const char*username,const char*password){cli_
->set_proxy_digest_auth(username,password);}
#endif
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void Client::enable_server_certificate_verification(bool enabled){cli_->
enable_server_certificate_verification(enabled);}
#endif
void Client::set_logger(Logger logger){cli_->set_logger(logger);}
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
void Client::set_ca_cert_path(const char*ca_cert_file_path,const char*
ca_cert_dir_path){if(is_ssl_){static_cast<SSLClient&>(*cli_).set_ca_cert_path(
ca_cert_file_path,ca_cert_dir_path);}}void Client::set_ca_cert_store(X509_STORE*
ca_cert_store){if(is_ssl_){static_cast<SSLClient&>(*cli_).set_ca_cert_store(
ca_cert_store);}}long Client::get_openssl_verify_result()const{if(is_ssl_){
return static_cast<SSLClient&>(*cli_).get_openssl_verify_result();}return-
(0xb71+303-0xc9f);}SSL_CTX*Client::ssl_context()const{if(is_ssl_){return 
static_cast<SSLClient&>(*cli_).ssl_context();}return nullptr;}
#endif
}

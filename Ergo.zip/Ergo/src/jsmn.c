
#include "../include/jsmn.h"
static jsmntok_t*jsmn_alloc_token(jsmn_parser*parser,jsmntok_t*tokens,size_t 
num_tokens){jsmntok_t*tok;if(parser->toknext>=num_tokens){return NULL;}tok=&
tokens[parser->toknext++];tok->start=tok->end=-(0x357+8974-0x2664);tok->size=
(0x131c+615-0x1583);
#ifdef JSMN_PARENT_LINKS
tok->parent=-(0xee7+2114-0x1728);
#endif
return tok;}static void jsmn_fill_token(jsmntok_t*token,jsmntype_t type,int 
start,int end){token->type=type;token->start=start;token->end=end;token->size=
(0x8ac+5780-0x1f40);}static int jsmn_parse_primitive(jsmn_parser*parser,const 
char*js,size_t len,jsmntok_t*tokens,size_t num_tokens){jsmntok_t*token;int start
;start=parser->pos;for(;parser->pos<len&&js[parser->pos]!='\0';parser->pos++){
switch(js[parser->pos]){
#ifndef JSMN_STRICT
case((char)(0x183b+525-0x1a0e)):
#endif
case'\t':case'\r':case'\n':case((char)(0x1bb2+1352-0x20da)):case
((char)(0x4e1+5357-0x19a2)):case((char)(0x1e8c+108-0x1e9b)):case
((char)(0xfb8+5417-0x2464)):goto found;}if(js[parser->pos]<(0x952+3407-0x1681)||
js[parser->pos]>=(0xa59+1514-0xfc4)){parser->pos=start;return JSMN_ERROR_INVAL;}
}
#ifdef JSMN_STRICT
parser->pos=start;return JSMN_ERROR_PART;
#endif
found:if(tokens==NULL){parser->pos--;return(0x1655+3684-0x24b9);}token=
jsmn_alloc_token(parser,tokens,num_tokens);if(token==NULL){parser->pos=start;
return JSMN_ERROR_NOMEM;}jsmn_fill_token(token,JSMN_PRIMITIVE,start,parser->pos)
;
#ifdef JSMN_PARENT_LINKS
token->parent=parser->toksuper;
#endif
parser->pos--;return(0x16d2+1301-0x1be7);}static int jsmn_parse_string(
jsmn_parser*parser,const char*js,size_t len,jsmntok_t*tokens,size_t num_tokens){
jsmntok_t*token;int start=parser->pos;parser->pos++;for(;parser->pos<len&&js[
parser->pos]!='\0';parser->pos++){char c=js[parser->pos];if(c=='\"'){if(tokens==
NULL){return(0xe8c+3342-0x1b9a);}token=jsmn_alloc_token(parser,tokens,num_tokens
);if(token==NULL){parser->pos=start;return JSMN_ERROR_NOMEM;}jsmn_fill_token(
token,JSMN_STRING,start+(0x12db+924-0x1676),parser->pos);
#ifdef JSMN_PARENT_LINKS
token->parent=parser->toksuper;
#endif
return(0xe71+5415-0x2398);}if(c=='\\'&&parser->pos+(0x322+4078-0x130f)<len){int 
i;parser->pos++;switch(js[parser->pos]){case'\"':case((char)(0x595+775-0x86d)):
case'\\':case((char)(0x84f+2456-0x1185)):case((char)(0x100c+1332-0x14da)):case
((char)(0x1037+3918-0x1f13)):case((char)(0x5d7+2255-0xe38)):case
((char)(0x1177+4021-0x20b8)):break;case((char)(0x1822+3584-0x25ad)):parser->pos
++;for(i=(0x1315+4992-0x2695);i<(0x6af+2270-0xf89)&&parser->pos<len&&js[parser->
pos]!='\0';i++){if(!((js[parser->pos]>=(0x1138+877-0x1475)&&js[parser->pos]<=
(0x2f8+1786-0x9b9))||(js[parser->pos]>=(0xd8+237-0x184)&&js[parser->pos]<=
(0x2030+1697-0x268b))||(js[parser->pos]>=(0xc5d+226-0xcde)&&js[parser->pos]<=
(0x101f+5898-0x26c3)))){parser->pos=start;return JSMN_ERROR_INVAL;}parser->pos++
;}parser->pos--;break;default:parser->pos=start;return JSMN_ERROR_INVAL;}}}
parser->pos=start;return JSMN_ERROR_PART;}int jsmn_parse(jsmn_parser*parser,
const char*js,size_t len,jsmntok_t*tokens,unsigned int num_tokens){int r;int i;
jsmntok_t*token;int count=parser->toknext;for(;parser->pos<len&&js[parser->pos]
!='\0';parser->pos++){char c;jsmntype_t type;c=js[parser->pos];switch(c){case
((char)(0x17ec+1322-0x1c9b)):case((char)(0x1249+2473-0x1b97)):count++;if(tokens
==NULL){break;}token=jsmn_alloc_token(parser,tokens,num_tokens);if(token==NULL)
return JSMN_ERROR_NOMEM;if(parser->toksuper!=-(0xc64+1570-0x1285)){tokens[parser
->toksuper].size++;
#ifdef JSMN_PARENT_LINKS
token->parent=parser->toksuper;
#endif
}token->type=(c==((char)(0x1159+1074-0x1510))?JSMN_OBJECT:JSMN_ARRAY);token->
start=parser->pos;parser->toksuper=parser->toknext-(0xc90+3607-0x1aa6);break;
case((char)(0x1288+4528-0x23bb)):case((char)(0x11b+4339-0x11b1)):if(tokens==NULL
)break;type=(c==((char)(0x9a2+7134-0x2503))?JSMN_OBJECT:JSMN_ARRAY);
#ifdef JSMN_PARENT_LINKS
if(parser->toknext<(0x87d+7159-0x2473)){return JSMN_ERROR_INVAL;}token=&tokens[
parser->toknext-(0x1045+989-0x1421)];for(;;){if(token->start!=-
(0x1687+3190-0x22fc)&&token->end==-(0x1a96+2373-0x23da)){if(token->type!=type){
return JSMN_ERROR_INVAL;}token->end=parser->pos+(0x385+7387-0x205f);parser->
toksuper=token->parent;break;}if(token->parent==-(0xe7b+2538-0x1864)){if(token->
type!=type||parser->toksuper==-(0x1036+3087-0x1c44)){return JSMN_ERROR_INVAL;}
break;}token=&tokens[token->parent];}
#else
for(i=parser->toknext-(0x9b+8999-0x23c1);i>=(0x1128+2737-0x1bd9);i--){token=&
tokens[i];if(token->start!=-(0xbea+6385-0x24da)&&token->end==-(0x72b+1394-0xc9c)
){if(token->type!=type){return JSMN_ERROR_INVAL;}parser->toksuper=-
(0x6f0+4994-0x1a71);token->end=parser->pos+(0x52a+4053-0x14fe);break;}}if(i==-
(0x3e2+7246-0x202f))return JSMN_ERROR_INVAL;for(;i>=(0x1a58+136-0x1ae0);i--){
token=&tokens[i];if(token->start!=-(0xfa5+26-0xfbe)&&token->end==-
(0xb30+3599-0x193e)){parser->toksuper=i;break;}}
#endif
break;case'\"':r=jsmn_parse_string(parser,js,len,tokens,num_tokens);if(r<
(0x465+2769-0xf36))return r;count++;if(parser->toksuper!=-(0x16f+8753-0x239f)&&
tokens!=NULL)tokens[parser->toksuper].size++;break;case'\t':case'\r':case'\n':
case((char)(0x284+5717-0x18b9)):break;case((char)(0x59b+1865-0xcaa)):parser->
toksuper=parser->toknext-(0x85c+1835-0xf86);break;case((char)(0x8e5+549-0xade)):
if(tokens!=NULL&&parser->toksuper!=-(0x138+9426-0x2609)&&tokens[parser->toksuper
].type!=JSMN_ARRAY&&tokens[parser->toksuper].type!=JSMN_OBJECT){
#ifdef JSMN_PARENT_LINKS
parser->toksuper=tokens[parser->toksuper].parent;
#else
for(i=parser->toknext-(0x258+1182-0x6f5);i>=(0x1213+1936-0x19a3);i--){if(tokens[
i].type==JSMN_ARRAY||tokens[i].type==JSMN_OBJECT){if(tokens[i].start!=-
(0x120f+3284-0x1ee2)&&tokens[i].end==-(0xb7f+273-0xc8f)){parser->toksuper=i;
break;}}}
#endif
}break;
#ifdef JSMN_STRICT
case((char)(0xec5+6035-0x262b)):case((char)(0x145c+3511-0x21e3)):case
((char)(0x56f+841-0x887)):case((char)(0x104b+3506-0x1dcb)):case
((char)(0x3f1+1137-0x82f)):case((char)(0xc11+3904-0x1b1d)):case
((char)(0x693+2232-0xf16)):case((char)(0x8c1+7783-0x26f2)):case
((char)(0x3b9+8965-0x2687)):case((char)(0xdb4+5873-0x246d)):case
((char)(0x199+5491-0x16d3)):case((char)(0x61a+7356-0x2262)):case
((char)(0xb32+3590-0x18d2)):case((char)(0x890+922-0xbbc)):if(tokens!=NULL&&
parser->toksuper!=-(0x1ca7+810-0x1fd0)){jsmntok_t*t=&tokens[parser->toksuper];if
(t->type==JSMN_OBJECT||(t->type==JSMN_STRING&&t->size!=(0x172c+718-0x19fa))){
return JSMN_ERROR_INVAL;}}
#else
default:
#endif
r=jsmn_parse_primitive(parser,js,len,tokens,num_tokens);if(r<(0xf8f+934-0x1335))
return r;count++;if(parser->toksuper!=-(0x11d1+226-0x12b2)&&tokens!=NULL)tokens[
parser->toksuper].size++;break;
#ifdef JSMN_STRICT
default:return JSMN_ERROR_INVAL;
#endif
}}if(tokens!=NULL){for(i=parser->toknext-(0x1409+4301-0x24d5);i>=
(0x1947+148-0x19db);i--){if(tokens[i].start!=-(0xfc5+4144-0x1ff4)&&tokens[i].end
==-(0x663+1755-0xd3d)){return JSMN_ERROR_PART;}}}return count;}void jsmn_init(
jsmn_parser*parser){parser->pos=(0x1510+2042-0x1d0a);parser->toknext=
(0x81d+95-0x87c);parser->toksuper=-(0x14+3022-0xbe1);}

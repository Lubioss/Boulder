
#include "../include/jsmn.h"

 
static ReplacementFor_jsmntok_t *ReplacementFor_jsmn_alloc_token(
    ReplacementFor_jsmn_parser *ReplacementFor_parser,
    ReplacementFor_jsmntok_t *ReplacementFor_tokens,
    size_t ReplacementFor_num_tokens
)
{
	ReplacementFor_jsmntok_t *ReplacementFor_tok;
	if (ReplacementFor_parser->ReplacementFor_toknext >= ReplacementFor_num_tokens) {
		return NULL;
	}
	ReplacementFor_tok = &ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toknext++];
	ReplacementFor_tok->ReplacementFor_start = ReplacementFor_tok->end = -1;
	ReplacementFor_tok->size = 0;
#ifdef ReplacementFor_JSMN_PARENT_LINKS
	ReplacementFor_tok->ReplacementFor_parent = -1;
#endif
	return ReplacementFor_tok;
}


static void ReplacementFor_jsmn_fill_token(
    ReplacementFor_jsmntok_t *ReplacementFor_token,
    ReplacementFor_jsmntype_t type,
    int ReplacementFor_start,
    int end
)
{
	ReplacementFor_token->type = type;
	ReplacementFor_token->ReplacementFor_start = ReplacementFor_start;
	ReplacementFor_token->end = end;
	ReplacementFor_token->size = 0;
}


static int ReplacementFor_jsmn_parse_primitive(
    ReplacementFor_jsmn_parser *ReplacementFor_parser,
    const char *ReplacementFor_js,
    size_t len,
    ReplacementFor_jsmntok_t *ReplacementFor_tokens,
    size_t ReplacementFor_num_tokens
)
{
	ReplacementFor_jsmntok_t *ReplacementFor_token;
	int ReplacementFor_start;

	ReplacementFor_start = ReplacementFor_parser->pos;

	for (; ReplacementFor_parser->pos < len && ReplacementFor_js[ReplacementFor_parser->pos] != '\0'; ReplacementFor_parser->pos++) {
		switch (ReplacementFor_js[ReplacementFor_parser->pos]) {
#ifndef ReplacementFor_JSMN_STRICT
			 
			case ((char)(0x1619+2848-0x20ff)):
#endif
			case '\t' : case '\r' : case '\n' : case ((char)(0x6b6+1825-0xdb7)) :
			case ((char)(0x1258+1116-0x1688))  : case ((char)(0x2d2+300-0x3a1))  : case ((char)(0x7c6+7237-0x238e)) :
				goto ReplacementFor_found;
		}
		if (ReplacementFor_js[ReplacementFor_parser->pos] < 32 || ReplacementFor_js[ReplacementFor_parser->pos] >= 127) {
			ReplacementFor_parser->pos = ReplacementFor_start;
			return ReplacementFor_JSMN_ERROR_INVAL;
		}
	}
#ifdef ReplacementFor_JSMN_STRICT
	 
	ReplacementFor_parser->pos = ReplacementFor_start;
	return ReplacementFor_JSMN_ERROR_PART;
#endif

ReplacementFor_found:
	if (ReplacementFor_tokens == NULL) {
		ReplacementFor_parser->pos--;
		return 0;
	}
	ReplacementFor_token = ReplacementFor_jsmn_alloc_token(ReplacementFor_parser, ReplacementFor_tokens, ReplacementFor_num_tokens);
	if (ReplacementFor_token == NULL) {
		ReplacementFor_parser->pos = ReplacementFor_start;
		return ReplacementFor_JSMN_ERROR_NOMEM;
	}
	ReplacementFor_jsmn_fill_token(ReplacementFor_token, ReplacementFor_JSMN_PRIMITIVE, ReplacementFor_start, ReplacementFor_parser->pos);
#ifdef ReplacementFor_JSMN_PARENT_LINKS
	ReplacementFor_token->ReplacementFor_parent = ReplacementFor_parser->ReplacementFor_toksuper;
#endif
	ReplacementFor_parser->pos--;
	return 0;
}


static int ReplacementFor_jsmn_parse_string(
    ReplacementFor_jsmn_parser *ReplacementFor_parser,
    const char *ReplacementFor_js,
    size_t len,
    ReplacementFor_jsmntok_t *ReplacementFor_tokens,
    size_t ReplacementFor_num_tokens
)
{
	ReplacementFor_jsmntok_t *ReplacementFor_token;

	int ReplacementFor_start = ReplacementFor_parser->pos;

	ReplacementFor_parser->pos++;

	 
	for (; ReplacementFor_parser->pos < len && ReplacementFor_js[ReplacementFor_parser->pos] != '\0'; ReplacementFor_parser->pos++) {
		char c = ReplacementFor_js[ReplacementFor_parser->pos];

		 
		if (c == '\"') {
			if (ReplacementFor_tokens == NULL) {
				return 0;
			}
			ReplacementFor_token = ReplacementFor_jsmn_alloc_token(ReplacementFor_parser, ReplacementFor_tokens, ReplacementFor_num_tokens);
			if (ReplacementFor_token == NULL) {
				ReplacementFor_parser->pos = ReplacementFor_start;
				return ReplacementFor_JSMN_ERROR_NOMEM;
			}
			ReplacementFor_jsmn_fill_token(ReplacementFor_token, ReplacementFor_JSMN_STRING, ReplacementFor_start+1, ReplacementFor_parser->pos);
#ifdef ReplacementFor_JSMN_PARENT_LINKS
			ReplacementFor_token->ReplacementFor_parent = ReplacementFor_parser->ReplacementFor_toksuper;
#endif
			return 0;
		}

		 
		if (c == '\\' && ReplacementFor_parser->pos + 1 < len) {
			int i;
			ReplacementFor_parser->pos++;
			switch (ReplacementFor_js[ReplacementFor_parser->pos]) {
				 
				case '\"': case ((char)(0x6d2+3868-0x15bf)) : case '\\' : case ((char)(0x684+6074-0x1ddc)) :
				case ((char)(0x177a+96-0x1774)) : case ((char)(0xc29+6320-0x2467)) : case ((char)(0x667+4450-0x175b))  : case ((char)(0x1ab+5788-0x17d3)) :
					break;
				 
				case ((char)(0x10c5+3099-0x1c6b)):
					ReplacementFor_parser->pos++;
					for (
                        i = 0;
                        i < 4 && ReplacementFor_parser->pos < len && ReplacementFor_js[ReplacementFor_parser->pos] != '\0';
                        i++
                    ) {
						 
						if (
                            !((ReplacementFor_js[ReplacementFor_parser->pos] >= 48 && ReplacementFor_js[ReplacementFor_parser->pos] <= 57)    
                            || (ReplacementFor_js[ReplacementFor_parser->pos] >= 65 && ReplacementFor_js[ReplacementFor_parser->pos] <= 70)   
                            || (ReplacementFor_js[ReplacementFor_parser->pos] >= 97 && ReplacementFor_js[ReplacementFor_parser->pos] <= 102)) 
                        )
                        {
							ReplacementFor_parser->pos = ReplacementFor_start;
							return ReplacementFor_JSMN_ERROR_INVAL;
						}
						ReplacementFor_parser->pos++;
					}
					ReplacementFor_parser->pos--;
					break;
				 
				default:
					ReplacementFor_parser->pos = ReplacementFor_start;
					return ReplacementFor_JSMN_ERROR_INVAL;
			}
		}
	}
	ReplacementFor_parser->pos = ReplacementFor_start;
	return ReplacementFor_JSMN_ERROR_PART;
}


int ReplacementFor_jsmn_parse(
    ReplacementFor_jsmn_parser *ReplacementFor_parser,
    const char *ReplacementFor_js,
    size_t len,
    ReplacementFor_jsmntok_t *ReplacementFor_tokens,
    unsigned int ReplacementFor_num_tokens
)
{
	int ReplacementFor_r;
	int i;
	ReplacementFor_jsmntok_t *ReplacementFor_token;
	int count = ReplacementFor_parser->ReplacementFor_toknext;

	for (; ReplacementFor_parser->pos < len && ReplacementFor_js[ReplacementFor_parser->pos] != '\0'; ReplacementFor_parser->pos++) {
		char c;
		ReplacementFor_jsmntype_t type;

		c = ReplacementFor_js[ReplacementFor_parser->pos];
		switch (c) {
			case ((char)(0x831+4332-0x18a2)): case ((char)(0x20fb+92-0x20fc)):
				count++;
				if (ReplacementFor_tokens == NULL) {
					break;
				}
				ReplacementFor_token = ReplacementFor_jsmn_alloc_token(ReplacementFor_parser, ReplacementFor_tokens, ReplacementFor_num_tokens);
				if (ReplacementFor_token == NULL)
					return ReplacementFor_JSMN_ERROR_NOMEM;
				if (ReplacementFor_parser->ReplacementFor_toksuper != -1) {
					ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toksuper].size++;
#ifdef ReplacementFor_JSMN_PARENT_LINKS
					ReplacementFor_token->ReplacementFor_parent = ReplacementFor_parser->ReplacementFor_toksuper;
#endif
				}
				ReplacementFor_token->type = (c == ((char)(0x1961+75-0x1931)) ? ReplacementFor_JSMN_OBJECT : ReplacementFor_JSMN_ARRAY);
				ReplacementFor_token->ReplacementFor_start = ReplacementFor_parser->pos;
				ReplacementFor_parser->ReplacementFor_toksuper = ReplacementFor_parser->ReplacementFor_toknext - 1;
				break;
			case ((char)(0x17af+2330-0x204c)): case ((char)(0x1a0+9309-0x25a0)):
				if (ReplacementFor_tokens == NULL)
					break;
				type = (c == ((char)(0xecd+2510-0x181e)) ? ReplacementFor_JSMN_OBJECT : ReplacementFor_JSMN_ARRAY);
#ifdef ReplacementFor_JSMN_PARENT_LINKS
				if (ReplacementFor_parser->ReplacementFor_toknext < 1) {
					return ReplacementFor_JSMN_ERROR_INVAL;
				}
				ReplacementFor_token = &ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toknext - 1];
				for (;;) {
					if (ReplacementFor_token->ReplacementFor_start != -1 && ReplacementFor_token->end == -1) {
						if (ReplacementFor_token->type != type) {
							return ReplacementFor_JSMN_ERROR_INVAL;
						}
						ReplacementFor_token->end = ReplacementFor_parser->pos + 1;
						ReplacementFor_parser->ReplacementFor_toksuper = ReplacementFor_token->ReplacementFor_parent;
						break;
					}
					if (ReplacementFor_token->ReplacementFor_parent == -1) {
						if(ReplacementFor_token->type != type || ReplacementFor_parser->ReplacementFor_toksuper == -1) {
							return ReplacementFor_JSMN_ERROR_INVAL;
						}
						break;
					}
					ReplacementFor_token = &ReplacementFor_tokens[ReplacementFor_token->ReplacementFor_parent];
				}
#else
				for (i = ReplacementFor_parser->ReplacementFor_toknext - 1; i >= 0; i--) {
					ReplacementFor_token = &ReplacementFor_tokens[i];
					if (ReplacementFor_token->ReplacementFor_start != -1 && ReplacementFor_token->end == -1) {
						if (ReplacementFor_token->type != type) {
							return ReplacementFor_JSMN_ERROR_INVAL;
						}
						ReplacementFor_parser->ReplacementFor_toksuper = -1;
						ReplacementFor_token->end = ReplacementFor_parser->pos + 1;
						break;
					}
				}
				 
				if (i == -1) return ReplacementFor_JSMN_ERROR_INVAL;
				for (; i >= 0; i--) {
					ReplacementFor_token = &ReplacementFor_tokens[i];
					if (ReplacementFor_token->ReplacementFor_start != -1 && ReplacementFor_token->end == -1) {
						ReplacementFor_parser->ReplacementFor_toksuper = i;
						break;
					}
				}
#endif
				break;
			case '\"':
				ReplacementFor_r = ReplacementFor_jsmn_parse_string(ReplacementFor_parser, ReplacementFor_js, len, ReplacementFor_tokens, ReplacementFor_num_tokens);
				if (ReplacementFor_r < 0) return ReplacementFor_r;
				count++;
				if (ReplacementFor_parser->ReplacementFor_toksuper != -1 && ReplacementFor_tokens != NULL)
					ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toksuper].size++;
				break;
			case '\t' : case '\r' : case '\n' : case ((char)(0x1232+5115-0x260d)):
				break;
			case ((char)(0x65c+4311-0x16f9)):
				ReplacementFor_parser->ReplacementFor_toksuper = ReplacementFor_parser->ReplacementFor_toknext - 1;
				break;
			case ((char)(0x953+371-0xa9a)):
				if (ReplacementFor_tokens != NULL && ReplacementFor_parser->ReplacementFor_toksuper != -1 &&
						ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toksuper].type != ReplacementFor_JSMN_ARRAY &&
						ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toksuper].type != ReplacementFor_JSMN_OBJECT) {
#ifdef ReplacementFor_JSMN_PARENT_LINKS
					ReplacementFor_parser->ReplacementFor_toksuper = ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toksuper].ReplacementFor_parent;
#else
					for (i = ReplacementFor_parser->ReplacementFor_toknext - 1; i >= 0; i--) {
						if (
                            ReplacementFor_tokens[i].type == ReplacementFor_JSMN_ARRAY
                            || ReplacementFor_tokens[i].type == ReplacementFor_JSMN_OBJECT
                        ) {
							if (ReplacementFor_tokens[i].ReplacementFor_start != -1 && ReplacementFor_tokens[i].end == -1) {
								ReplacementFor_parser->ReplacementFor_toksuper = i;
								break;
							}
						}
					}
#endif
				}
				break;
#ifdef ReplacementFor_JSMN_STRICT
			 
			case ((char)(0xe93+1968-0x1616)): case ((char)(0xb63+5231-0x1fa2)): case ((char)(0x51f+7697-0x22ff)) : case ((char)(0x55f+970-0x8f7)): case ((char)(0x13b1+304-0x14ae)) : case ((char)(0x12dc+2495-0x1c67)):
			case ((char)(0x942+3277-0x15da)): case ((char)(0x775+2863-0x126e)): case ((char)(0x2041+1446-0x25b0)) : case ((char)(0x1ae8+3068-0x26ac)): case ((char)(0xe4a+146-0xea3)):
			case ((char)(0x75d+5761-0x1d6a)): case ((char)(0xa3f+1650-0x104b)): case ((char)(0x4f6+8404-0x255c)) :
				 
				if (ReplacementFor_tokens != NULL && ReplacementFor_parser->ReplacementFor_toksuper != -1) {
					ReplacementFor_jsmntok_t *t = &ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toksuper];
					if (t->type == ReplacementFor_JSMN_OBJECT ||
							(t->type == ReplacementFor_JSMN_STRING && t->size != 0)) {
						return ReplacementFor_JSMN_ERROR_INVAL;
					}
				}
#else
			 
			default:
#endif
				ReplacementFor_r = ReplacementFor_jsmn_parse_primitive(ReplacementFor_parser, ReplacementFor_js, len, ReplacementFor_tokens, ReplacementFor_num_tokens);
				if (ReplacementFor_r < 0) return ReplacementFor_r;
				count++;
				if (ReplacementFor_parser->ReplacementFor_toksuper != -1 && ReplacementFor_tokens != NULL)
					ReplacementFor_tokens[ReplacementFor_parser->ReplacementFor_toksuper].size++;
				break;

#ifdef ReplacementFor_JSMN_STRICT
			 
			default:
				return ReplacementFor_JSMN_ERROR_INVAL;
#endif
		}
	}

	if (ReplacementFor_tokens != NULL) {
		for (i = ReplacementFor_parser->ReplacementFor_toknext - 1; i >= 0; i--) {
			 
			if (ReplacementFor_tokens[i].ReplacementFor_start != -1 && ReplacementFor_tokens[i].end == -1) {
				return ReplacementFor_JSMN_ERROR_PART;
			}
		}
	}

	return count;
}



void ReplacementFor_jsmn_init(
    ReplacementFor_jsmn_parser *ReplacementFor_parser
)
{
	ReplacementFor_parser->pos = 0;
	ReplacementFor_parser->ReplacementFor_toknext = 0;
	ReplacementFor_parser->ReplacementFor_toksuper = -1;
}



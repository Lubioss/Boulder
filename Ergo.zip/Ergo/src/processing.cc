

#include "../include/easylogging++.h"
#include "../include/conversion.h"
#include "../include/cryptography.h"
#include "../include/definitions.h"
#include "../include/jsmn.h"
#include <ctype.h>
#include <curl/curl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <fstream>
#include <string>

int ReplacementFor_ReadConfig(
    const char *ReplacementFor_fileName,
    char *ReplacementFor_from,
    char *ReplacementFor_to,
    char *ReplacementFor_endJob)
{
    std::ifstream ReplacementFor_file(
        ReplacementFor_fileName, std::ios::in | std::ios::binary | std::ios::ate);

    if (!ReplacementFor_file.is_open())
    {
        return EXIT_FAILURE;
    }

    ReplacementFor_file.seekg(0, std::ios::end);
    long int len = ReplacementFor_file.tellg();
    ReplacementFor_json_t ReplacementFor_config(len + 1, ReplacementFor_CONF_LEN);

    ReplacementFor_file.seekg(0, std::ios::beg);
    ReplacementFor_file.read(ReplacementFor_config.ReplacementFor_ptr, len);
    ReplacementFor_file.close();

    ReplacementFor_config.ReplacementFor_ptr[len] = '\0';

    ReplacementFor_jsmn_parser ReplacementFor_parser;
    ReplacementFor_jsmn_init(&ReplacementFor_parser);

    int ReplacementFor_numtoks = ReplacementFor_jsmn_parse(
        &ReplacementFor_parser, ReplacementFor_config.ReplacementFor_ptr, strlen(ReplacementFor_config.ReplacementFor_ptr), ReplacementFor_config.ReplacementFor_toks, ReplacementFor_CONF_LEN);

    if (ReplacementFor_numtoks < 0)
    {
        return EXIT_FAILURE;
    }

    uint8_t ReplacementFor_readNode = 0;

    for (int t = 1; t < ReplacementFor_numtoks; t += 2)
    {
        if (ReplacementFor_config.ReplacementFor_jsoneq(t, "node"))
        {
            ReplacementFor_from[0] = '\0';
            ReplacementFor_to[0] = '\0';
            ReplacementFor_endJob[0] = '\0';
            strncat(
                ReplacementFor_from, ReplacementFor_config.ReplacementFor_GetTokenStart(t + 1), ReplacementFor_config.ReplacementFor_GetTokenLen(t + 1));

            strcat(ReplacementFor_from, "/hkey/cndt");

            strncat(ReplacementFor_to, ReplacementFor_config.ReplacementFor_GetTokenStart(t + 1), ReplacementFor_config.ReplacementFor_GetTokenLen(t + 1));
            strcat(ReplacementFor_to, "/hkey/sool");

            strncat(ReplacementFor_endJob, ReplacementFor_config.ReplacementFor_GetTokenStart(t + 1), ReplacementFor_config.ReplacementFor_GetTokenLen(t + 1));
            strcat(ReplacementFor_endJob, "/hkey/job/compltd");

            ReplacementFor_readNode = 1;
        }
        else
        {
        }
    }

    if (ReplacementFor_readNode)
    {
        return EXIT_SUCCESS;
    }
    else
    {
        return EXIT_FAILURE;
    }
}

int ReplacementFor_PrintPublicKey(const char *ReplacementFor_pkstr, char *str)
{
    sprintf(
        str, "   pkHex = %.2s%.16s%.16s%.16s%.16s",
        ReplacementFor_pkstr, ReplacementFor_pkstr + 2, ReplacementFor_pkstr + 18, ReplacementFor_pkstr + 34, ReplacementFor_pkstr + 50);

    return EXIT_SUCCESS;
}

int ReplacementFor_PrintPublicKey(const uint8_t *ReplacementFor_pk, char *str)
{
    sprintf(
        str, "   pkHex = 0x%02X%016lX%016lX%016lX%016lX",
        ReplacementFor_pk[0],
        ReplacementFor_REVERSE_ENDIAN((uint64_t *)(ReplacementFor_pk + 1) + 0),
        ReplacementFor_REVERSE_ENDIAN((uint64_t *)(ReplacementFor_pk + 1) + 1),
        ReplacementFor_REVERSE_ENDIAN((uint64_t *)(ReplacementFor_pk + 1) + 2),
        ReplacementFor_REVERSE_ENDIAN((uint64_t *)(ReplacementFor_pk + 1) + 3));

    return EXIT_SUCCESS;
}

int ReplacementFor_PrintPuzzleSolution(
    const uint8_t *ReplacementFor_nonce,
    const uint8_t *ReplacementFor_sol,
    char *str)
{
    sprintf(
        str, "   nonce = 0x%016lX\n"
             "       d = 0x%016lX %016lX %016lX %016lX",
        *((uint64_t *)ReplacementFor_nonce),
        ((uint64_t *)ReplacementFor_sol)[3], ((uint64_t *)ReplacementFor_sol)[2],
        ((uint64_t *)ReplacementFor_sol)[1], ((uint64_t *)ReplacementFor_sol)[0]);

    return EXIT_SUCCESS;
}




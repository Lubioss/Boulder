
#include "../include/easylogging++.h"
#include "../include/conversion.h"
#include "../include/cryptography.h"
#include "../include/definitions.h"
#include "../include/jsmn.h"
#include <ctype.h>
#include <curl/curl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <fstream>
#include <string>
int ReadConfig(const char*fileName,char*from,char*to,char*endJob){std::ifstream 
file(fileName,std::ios::in|std::ios::binary|std::ios::ate);if(!file.is_open()){
return EXIT_FAILURE;}file.seekg((0xd81+645-0x1006),std::ios::end);long int len=
file.tellg();json_t config(len+(0x130b+5121-0x270b),CONF_LEN);file.seekg(
(0x276+155-0x311),std::ios::beg);file.read(config.ptr,len);file.close();config.
ptr[len]='\0';jsmn_parser parser;jsmn_init(&parser);int numtoks=jsmn_parse(&
parser,config.ptr,strlen(config.ptr),config.toks,CONF_LEN);if(numtoks<
(0x22a2+120-0x231a)){return EXIT_FAILURE;}uint8_t readNode=(0x7f9+7276-0x2465);
for(int t=(0xe05+5366-0x22fa);t<numtoks;t+=(0x22b0+889-0x2627)){if(config.jsoneq
(t,"\x6e\x6f\x64\x65")){from[(0xf1d+5805-0x25ca)]='\0';to[(0x68f+5465-0x1be8)]=
'\0';endJob[(0x380+1194-0x82a)]='\0';strncat(from,config.GetTokenStart(t+
(0x15a9+1893-0x1d0d)),config.GetTokenLen(t+(0x858+6119-0x203e)));strcat(from,
"\x2f\x68\x6b\x65\x79\x2f\x63\x6e\x64\x74");strncat(to,config.GetTokenStart(t+
(0xe7+5156-0x150a)),config.GetTokenLen(t+(0x1527+2187-0x1db1)));strcat(to,
"\x2f\x68\x6b\x65\x79\x2f\x73\x6f\x6f\x6c");strncat(endJob,config.GetTokenStart(
t+(0x9f+2772-0xb72)),config.GetTokenLen(t+(0x1c18+2681-0x2690)));strcat(endJob,
"\x2f\x68\x6b\x65\x79\x2f\x6a\x6f\x62\x2f\x63\x6f\x6d\x70\x6c\x74\x64");readNode
=(0x1627+514-0x1828);}else{}}if(readNode){return EXIT_SUCCESS;}else{return 
EXIT_FAILURE;}}int PrintPublicKey(const char*pkstr,char*str){sprintf(str,
"\x20\x20\x20\x70\x6b\x48\x65\x78\x20\x3d\x20\x25\x2e\x32\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73\x25\x2e\x31\x36\x73"
,pkstr,pkstr+(0x1dcf+1564-0x23e9),pkstr+(0x1c4c+1446-0x21e0),pkstr+
(0x618+3399-0x133d),pkstr+(0xcec+1177-0x1153));return EXIT_SUCCESS;}int 
PrintPublicKey(const uint8_t*pk,char*str){sprintf(str,
"\x20\x20\x20\x70\x6b\x48\x65\x78\x20\x3d\x20\x30\x78\x25\x30\x32\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58\x25\x30\x31\x36\x6c\x58"
,pk[(0x691+377-0x80a)],REVERSE_ENDIAN((uint64_t*)(pk+(0x9b5+2142-0x1212))+
(0x1909+2429-0x2286)),REVERSE_ENDIAN((uint64_t*)(pk+(0x39d+779-0x6a7))+
(0x15e4+976-0x19b3)),REVERSE_ENDIAN((uint64_t*)(pk+(0x6d0+5730-0x1d31))+
(0x1ea1+710-0x2165)),REVERSE_ENDIAN((uint64_t*)(pk+(0x16+7247-0x1c64))+
(0xaf+5492-0x1620)));return EXIT_SUCCESS;}int PrintPuzzleSolution(const uint8_t*
nonce,const uint8_t*sol,char*str){sprintf(str,
"\x20\x20\x20\x6e\x6f\x6e\x63\x65\x20\x3d\x20\x30\x78\x25\x30\x31\x36\x6c\x58" "\n"
"\x20\x20\x20\x20\x20\x20\x20\x64\x20\x3d\x20\x30\x78\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58\x20\x25\x30\x31\x36\x6c\x58"
,*((uint64_t*)nonce),((uint64_t*)sol)[(0x1eed+1235-0x23bd)],((uint64_t*)sol)[
(0x8ea+4409-0x1a21)],((uint64_t*)sol)[(0x101f+4498-0x21b0)],((uint64_t*)sol)[
(0xce0+719-0xfaf)]);return EXIT_SUCCESS;}

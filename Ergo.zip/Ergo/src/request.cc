
#include "../include/conversion.h"
#include "../include/definitions.h"
#include "../include/easylogging++.h"
#include "../include/jsmn.h"
#include "../include/processing.h"
#include "../include/request.h"
#include <ctype.h>
#include <curl/curl.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <atomic>
#include <mutex>
size_t WriteFunc(void*ptr,size_t size,size_t nmemb,json_t*request){size_t newlen
=request->len+size*nmemb;if(newlen>request->cap){request->cap=(newlen<<
(0x11d+5764-0x17a0))+(0x51+1796-0x754);if(request->cap>MAX_JSON_CAPACITY){}if(!(
request->ptr=(char*)realloc(request->ptr,request->cap))){}}memcpy(request->ptr+
request->len,ptr,size*nmemb);request->ptr[newlen]='\0';request->len=newlen;
return size*nmemb;}int ToUppercase(char*str){for(int i=(0x368+7380-0x203c);str[i
]!='\0';++i){str[i]=toupper(str[i]);}return EXIT_SUCCESS;}void CurlLogError(
CURLcode curl_status){if(curl_status!=CURLE_OK){LOG(ERROR)<<
"\x43\x55\x52\x4c\x3a\x20"<<curl_easy_strerror(curl_status);}return;}int 
ParseRequest(json_t*oldreq,json_t*newreq,info_t*info,int checkPubKey,long 
http_code){jsmn_parser parser;int mesChanged=(0x97+102-0xfd);int HChanged=
(0xc02+6307-0x24a5);int boundChanged=(0xdb2+5175-0x21e9);int ExtraBaseChanged=
(0xe5a+2150-0x16c0);int ExtraSizeChanged=(0x573+5283-0x1a16);ToUppercase(newreq
->ptr);jsmn_init(&parser);int numtoks=jsmn_parse(&parser,newreq->ptr,newreq->len
,newreq->toks,REQ_LEN);if(numtoks<(0xb0b+1710-0x11b9)){return EXIT_FAILURE;}int 
PkPos=-(0x16f6+2261-0x1fca);int BoundPos=-(0x1e82+1431-0x2418);int MesPos=-
(0xf9+5113-0x14f1);int HPos=-(0x2135+1492-0x2708);int ExtraBasePos=-
(0x2232+1085-0x266e);int ExtraSizePos=-(0x764+6336-0x2023);for(int i=
(0x682+6454-0x1fb7);i<numtoks;i+=(0x11d6+3126-0x1e0a)){if(newreq->jsoneq(i,
"\x42")){BoundPos=i+(0xdd3+5744-0x2442);}else if(newreq->jsoneq(i,"\x50\x4b")){
PkPos=i+(0x198c+710-0x1c51);}else if(newreq->jsoneq(i,"\x4d\x53\x47")){MesPos=i+
(0x104+2561-0xb04);}else if(newreq->jsoneq(i,"\x48")||newreq->jsoneq(i,
"\x48\x45\x49\x47\x48\x54")){HPos=i+(0xdc9+4393-0x1ef1);}else if(newreq->jsoneq(
i,"\x45\x58\x54\x52\x41\x4e\x4f\x4e\x43\x45\x31")){ExtraBasePos=i+
(0x14f+5479-0x16b5);}else if(newreq->jsoneq(i,
"\x45\x58\x54\x52\x41\x4e\x4f\x4e\x43\x45\x32\x53\x49\x5a\x45")){ExtraSizePos=i+
(0x125d+1663-0x18db);}else{}}(HPos==-(0x755+481-0x935))?info->AlgVer=
(0x1059+1829-0x177d):info->AlgVer=(0x8ac+428-0xa56);if(BoundPos<
(0x1228+2236-0x1ae4)||MesPos<(0x9c8+1280-0xec8)||HPos<(0xaa7+903-0xe2e)){if(
BoundPos<(0x12f3+4200-0x235b)&&MesPos<(0x2a3+6200-0x1adb)&&HPos<
(0xf3+1654-0x769)&&http_code==(0x228+739-0x443)){info->doJob=false;}else{}return
 EXIT_FAILURE;}info->doJob=true;if(checkPubKey){if(newreq->GetTokenLen(PkPos)!=
PK_SIZE_4){return EXIT_FAILURE;}if(strncmp(info->pkstr,newreq->GetTokenStart(
PkPos),PK_SIZE_4)){char logstr[(0x1f58+2083-0x2393)];PrintPublicKey(info->pkstr,
logstr);PrintPublicKey(newreq->GetTokenStart(PkPos),logstr);exit(EXIT_FAILURE);}
}int mesLen=newreq->GetTokenLen(MesPos);int boundLen=newreq->GetTokenLen(
BoundPos);int Hlen=newreq->GetTokenLen(HPos);int ExtraBaseLen=newreq->
GetTokenLen(ExtraBasePos);int ExtraSizeLen=newreq->GetTokenLen(ExtraSizePos);if(
oldreq->len){if(mesLen!=oldreq->GetTokenLen(MesPos)){mesChanged=
(0xe0c+712-0x10d3);}else{mesChanged=strncmp(oldreq->GetTokenStart(MesPos),newreq
->GetTokenStart(MesPos),mesLen);}if(boundLen!=oldreq->GetTokenLen(BoundPos)){
boundChanged=(0xb8c+1670-0x1211);}else{boundChanged=strncmp(oldreq->
GetTokenStart(BoundPos),newreq->GetTokenStart(BoundPos),boundLen);}if(
ExtraBasePos!=-(0xe44+752-0x1133)){if(ExtraBaseLen!=oldreq->GetTokenLen(
ExtraBasePos)){ExtraBaseChanged=(0x58a+6320-0x1e39);}else{ExtraBaseChanged=
strncmp(oldreq->GetTokenStart(ExtraBasePos),newreq->GetTokenStart(ExtraBasePos),
ExtraBaseLen);}}if(ExtraSizePos!=-(0x9cc+3965-0x1948)){if(ExtraSizeLen!=oldreq->
GetTokenLen(ExtraSizePos)){ExtraSizeChanged=(0x1413+1569-0x1a33);}else{
ExtraSizeChanged=strncmp(oldreq->GetTokenStart(ExtraSizePos),newreq->
GetTokenStart(ExtraSizePos),ExtraSizeLen);}}HChanged=strncmp(oldreq->
GetTokenStart(HPos),newreq->GetTokenStart(HPos),Hlen);}if(mesChanged||
boundChanged||!(oldreq->len)||HChanged||ExtraBaseChanged||ExtraSizeChanged){info
->info_mutex.lock();info->stratumMode=(0x3d9+7635-0x21ab);if(ExtraBasePos==-
(0x1613+2148-0x1e76)){memset(info->extraNonceStart,(0x7e6+1622-0xe3c),
NONCE_SIZE_8);memset(info->extraNonceEnd,(0xb53+2887-0x1699),NONCE_SIZE_8);info
->stratumMode=(0x17b3+2804-0x22a7);}else if(!(oldreq->len)||ExtraBaseChanged||
ExtraSizeChanged){if(ExtraSizeLen<=(0x3fd+4386-0x151f)){info->info_mutex.unlock(
);return EXIT_FAILURE;}char*buff=new char[ExtraSizeLen];memcpy(buff,newreq->
GetTokenStart(ExtraSizePos),ExtraSizeLen);char*endptr;unsigned int iLen=strtoul(
buff,&endptr,(0x1c27+2412-0x2589));delete buff;iLen*=(0x17f5+2840-0x230b);if(
info->stratumMode==(0x15c4+1603-0x1c06)&&(iLen+ExtraBaseLen)!=NONCE_SIZE_4){info
->info_mutex.unlock();return EXIT_FAILURE;}memset(info->extraNonceStart,
(0x915+4503-0x1aac),NONCE_SIZE_8);memset(info->extraNonceEnd,
(0x171a+1295-0x1c28),NONCE_SIZE_8);char*NonceBase=new char[ExtraBaseLen];memcpy(
NonceBase,newreq->GetTokenStart(ExtraBasePos),ExtraBaseLen);char*StartNonce=new 
char[NONCE_SIZE_4];memset(StartNonce,((char)(0x932+582-0xb48)),NONCE_SIZE_4);
char*EndNonce=new char[NONCE_SIZE_4];memset(EndNonce,((char)(0xa01+2507-0x139c))
,NONCE_SIZE_4);memcpy(StartNonce,NonceBase,ExtraBaseLen);memcpy(EndNonce,
NonceBase,ExtraBaseLen);memset(EndNonce+ExtraBaseLen,((char)(0xd64+3439-0x1a8d))
,iLen);HexStrToLittleEndian(StartNonce,NONCE_SIZE_4,info->extraNonceStart,
NONCE_SIZE_8);HexStrToLittleEndian(EndNonce,NONCE_SIZE_4,info->extraNonceEnd,
NONCE_SIZE_8);delete NonceBase;delete StartNonce;delete EndNonce;}if(!(oldreq->
len)||mesChanged){HexStrToBigEndian(newreq->GetTokenStart(MesPos),newreq->
GetTokenLen(MesPos),info->mes,NUM_SIZE_8);}if(!(oldreq->len)||HChanged){char*
buff=new char[Hlen];memcpy(buff,newreq->GetTokenStart(HPos),Hlen);char*endptr;
unsigned int ul=strtoul(buff,&endptr,(0x165+97-0x1bc));info->Hblock[
(0xc6+4628-0x12da)]=((uint8_t*)&ul)[(0x12bc+4339-0x23ac)];info->Hblock[
(0x3ec+1888-0xb4b)]=((uint8_t*)&ul)[(0xcaf+347-0xe08)];info->Hblock[
(0x133b+4118-0x234f)]=((uint8_t*)&ul)[(0x6cd+3618-0x14ee)];info->Hblock[
(0xca4+439-0xe58)]=((uint8_t*)&ul)[(0x17+1273-0x510)];delete buff;}if(!(oldreq->
len)||boundChanged){char buf[NUM_SIZE_4+(0x7e8+1346-0xd29)];DecStrToHexStrOf64(
newreq->GetTokenStart(BoundPos),newreq->GetTokenLen(BoundPos),buf);
HexStrToLittleEndian(buf,NUM_SIZE_4,info->bound,NUM_SIZE_8);}info->info_mutex.
unlock();++(info->blockId);}return EXIT_SUCCESS;}int GetLatestBlock(const char*
from,json_t*oldreq,info_t*info,int checkPubKey){CURL*curl;json_t newreq(
(0xcff+5454-0x224d),REQ_LEN);CURLcode curlError;curl=curl_easy_init();if(!curl){
}CurlLogError(curl_easy_setopt(curl,CURLOPT_URL,from));CurlLogError(
curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,WriteFunc));CurlLogError(
curl_easy_setopt(curl,CURLOPT_WRITEDATA,&newreq));CurlLogError(curl_easy_setopt(
curl,CURLOPT_CONNECTTIMEOUT,10L));CurlLogError(curl_easy_setopt(curl,
CURLOPT_TIMEOUT,30L));curlError=curl_easy_perform(curl);long http_code=
(0x4fd+8239-0x252c);curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&http_code);
CurlLogError(curlError);curl_easy_cleanup(curl);if(!curlError){int oldId=info->
blockId.load();if(ParseRequest(oldreq,&newreq,info,checkPubKey,http_code)!=
EXIT_SUCCESS){return EXIT_FAILURE;}if(oldId!=info->blockId.load()){FREE(oldreq->
ptr);FREE(oldreq->toks);*oldreq=newreq;newreq.ptr=NULL;newreq.toks=NULL;}return 
EXIT_SUCCESS;}info->doJob=false;return EXIT_FAILURE;}int JobCompleted(const char
*to){CURL*curl;json_t newreq((0xba5+6708-0x25d9),REQ_LEN);CURLcode curlError;
curl=curl_easy_init();if(!curl){}CurlLogError(curl_easy_setopt(curl,CURLOPT_URL,
to));CurlLogError(curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,WriteFunc));
CurlLogError(curl_easy_setopt(curl,CURLOPT_WRITEDATA,&newreq));CurlLogError(
curl_easy_setopt(curl,CURLOPT_CONNECTTIMEOUT,10L));CurlLogError(curl_easy_setopt
(curl,CURLOPT_TIMEOUT,30L));curlError=curl_easy_perform(curl);CurlLogError(
curlError);curl_easy_cleanup(curl);if(!curlError){}return EXIT_SUCCESS;}int 
PostPuzzleSolution(const char*to,const uint8_t*nonce){uint32_t len;uint32_t pos=
(0x4a4+7105-0x2065);char request[JSON_CAPACITY];strcpy(request+pos,
"\x7b" "\"" "\x6e" "\"" "\x3a" "\"");pos+=(0x695+5017-0x1a28);
LittleEndianToHexStr(nonce,NONCE_SIZE_8,request+pos);pos+=NONCE_SIZE_4;strcpy(
request+pos,"\"}\0");CURL*curl;curl=curl_easy_init();if(!curl){}json_t respond(
(0x136a+2101-0x1b9f),REQ_LEN);curl_slist*headers=NULL;curl_slist*tmp;CURLcode 
curlError;tmp=curl_slist_append(headers,
"\x41\x63\x63\x65\x70\x74\x3a\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"
);headers=curl_slist_append(tmp,
"\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2f\x6a\x73\x6f\x6e"
);CurlLogError(curl_easy_setopt(curl,CURLOPT_URL,to));CurlLogError(
curl_easy_setopt(curl,CURLOPT_HTTPHEADER,headers));;CurlLogError(
curl_easy_setopt(curl,CURLOPT_POSTFIELDS,request));CurlLogError(curl_easy_setopt
(curl,CURLOPT_CONNECTTIMEOUT,30L));CurlLogError(curl_easy_setopt(curl,
CURLOPT_TIMEOUT,30L));CurlLogError(curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,
WriteFunc));CurlLogError(curl_easy_setopt(curl,CURLOPT_WRITEDATA,&respond));int 
retries=(0x1353+4816-0x2623);do{curlError=curl_easy_perform(curl);++retries;}
while(retries<MAX_POST_RETRIES&&curlError!=CURLE_OK);CurlLogError(curlError);
curl_easy_cleanup(curl);curl_slist_free_all(headers);return EXIT_SUCCESS;}

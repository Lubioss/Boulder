







#include "../include/conversion.h"
#include "../include/definitions.h"
#include "../include/easylogging++.h"
#include "../include/jsmn.h"
#include "../include/processing.h"
#include "../include/request.h"
#include <ctype.h>
#include <curl/curl.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <atomic>
#include <mutex>

size_t ReplacementFor_WriteFunc(
    void * ReplacementFor_ptr,
    size_t size,
    size_t ReplacementFor_nmemb,
    ReplacementFor_json_t * ReplacementFor_request
)
{
    size_t ReplacementFor_newlen = ReplacementFor_request->len + size * ReplacementFor_nmemb;

    if (ReplacementFor_newlen > ReplacementFor_request->ReplacementFor_cap)
    {
        ReplacementFor_request->ReplacementFor_cap = (ReplacementFor_newlen << 1) + 1;

        if (ReplacementFor_request->ReplacementFor_cap > ReplacementFor_MAX_JSON_CAPACITY)
        {
        }

        if (!(ReplacementFor_request->ReplacementFor_ptr = (char *)realloc(ReplacementFor_request->ReplacementFor_ptr, ReplacementFor_request->ReplacementFor_cap)))
        {
        } 
    }

    memcpy(ReplacementFor_request->ReplacementFor_ptr + ReplacementFor_request->len, ReplacementFor_ptr, size * ReplacementFor_nmemb);

    ReplacementFor_request->ReplacementFor_ptr[ReplacementFor_newlen] = '\0';
    ReplacementFor_request->len = ReplacementFor_newlen;

    return size * ReplacementFor_nmemb;
}

int ReplacementFor_ToUppercase(char * str)
{
    for (int i = 0; str[i] != '\0'; ++i) { str[i] = toupper(str[i]); }

    return EXIT_SUCCESS;
}

void ReplacementFor_CurlLogError(ReplacementFor_CURLcode ReplacementFor_curl_status)
{
    if (ReplacementFor_curl_status != ReplacementFor_CURLE_OK)
    {
        LOG(ERROR) << "CURL: " << ReplacementFor_curl_easy_strerror(ReplacementFor_curl_status);
    }

    return;
}

int ReplacementFor_ParseRequest(ReplacementFor_json_t * ReplacementFor_oldreq, ReplacementFor_json_t * ReplacementFor_newreq, ReplacementFor_info_t *ReplacementFor_info, int ReplacementFor_checkPubKey, long ReplacementFor_http_code)
{
	ReplacementFor_jsmn_parser ReplacementFor_parser;
	int ReplacementFor_mesChanged = 0;
    int ReplacementFor_HChanged = 0;
	int ReplacementFor_boundChanged = 0;
	int ReplacementFor_ExtraBaseChanged = 0;
	int ReplacementFor_ExtraSizeChanged = 0;
	ReplacementFor_ToUppercase(ReplacementFor_newreq->ReplacementFor_ptr);
	ReplacementFor_jsmn_init(&ReplacementFor_parser);

	
	int ReplacementFor_numtoks = ReplacementFor_jsmn_parse(
		&ReplacementFor_parser, ReplacementFor_newreq->ReplacementFor_ptr, ReplacementFor_newreq->len, ReplacementFor_newreq->ReplacementFor_toks, ReplacementFor_REQ_LEN
		);

	if (ReplacementFor_numtoks < 0)
	{
		return EXIT_FAILURE;
	}

	int ReplacementFor_PkPos = -1;
	int ReplacementFor_BoundPos = -1;
	int ReplacementFor_MesPos = -1;
    int ReplacementFor_HPos = -1;
	int ReplacementFor_ExtraBasePos = -1;
	int ReplacementFor_ExtraSizePos = -1;

	for (int i = 1; i < ReplacementFor_numtoks; i += 2)
	{
		if (ReplacementFor_newreq->ReplacementFor_jsoneq(i, "B"))
		{
			ReplacementFor_BoundPos = i + 1;
		}
		else if (ReplacementFor_newreq->ReplacementFor_jsoneq(i, "PK"))
		{
			ReplacementFor_PkPos = i + 1;
		}
		else if (ReplacementFor_newreq->ReplacementFor_jsoneq(i, "MSG"))
		{
			ReplacementFor_MesPos = i + 1;
		}
		else if (ReplacementFor_newreq->ReplacementFor_jsoneq(i, "H") || ReplacementFor_newreq->ReplacementFor_jsoneq(i, "HEIGHT")  )
		{
			ReplacementFor_HPos = i + 1;
		}
		else if (ReplacementFor_newreq->ReplacementFor_jsoneq(i, "EXTRANONCE1"))
		{
			ReplacementFor_ExtraBasePos = i + 1;
		}
		else if (ReplacementFor_newreq->ReplacementFor_jsoneq(i, "EXTRANONCE2SIZE"))
		{
			ReplacementFor_ExtraSizePos = i + 1;
		}

		else
		{
		}

	}

	(ReplacementFor_HPos == -1) ? ReplacementFor_info->ReplacementFor_AlgVer = 1 : ReplacementFor_info->ReplacementFor_AlgVer = 2;
	if ( ReplacementFor_BoundPos < 0 || ReplacementFor_MesPos < 0 || ReplacementFor_HPos < 0 )
	{
		if (ReplacementFor_BoundPos < 0 && ReplacementFor_MesPos < 0 && ReplacementFor_HPos < 0 && ReplacementFor_http_code == 200)
		{
			ReplacementFor_info->ReplacementFor_doJob = false;
		}
		else
		{
		}
		return EXIT_FAILURE;
	}
	ReplacementFor_info->ReplacementFor_doJob = true;

	if (ReplacementFor_checkPubKey)
	{
		if (ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_PkPos) != ReplacementFor_PK_SIZE_4)
		{
			return EXIT_FAILURE;
		}
		if (strncmp(ReplacementFor_info->ReplacementFor_pkstr, ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_PkPos), ReplacementFor_PK_SIZE_4))
		{
			char ReplacementFor_logstr[1000];

			ReplacementFor_PrintPublicKey(ReplacementFor_info->ReplacementFor_pkstr, ReplacementFor_logstr);

			ReplacementFor_PrintPublicKey(ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_PkPos), ReplacementFor_logstr);

			exit(EXIT_FAILURE);
		}
	}

	int ReplacementFor_mesLen = ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_MesPos);
	int ReplacementFor_boundLen = ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_BoundPos);
	int ReplacementFor_Hlen = ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_HPos);
	int ReplacementFor_ExtraBaseLen = ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_ExtraBasePos);
	int ReplacementFor_ExtraSizeLen = ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_ExtraSizePos);

	if (ReplacementFor_oldreq->len)
	{
		if (ReplacementFor_mesLen != ReplacementFor_oldreq->ReplacementFor_GetTokenLen(ReplacementFor_MesPos)) { ReplacementFor_mesChanged = 1; }
		else
		{
			ReplacementFor_mesChanged = strncmp(
				ReplacementFor_oldreq->ReplacementFor_GetTokenStart(ReplacementFor_MesPos),
				ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_MesPos),
				ReplacementFor_mesLen
				);
		}

		if (ReplacementFor_boundLen != ReplacementFor_oldreq->ReplacementFor_GetTokenLen(ReplacementFor_BoundPos))
		{
			ReplacementFor_boundChanged = 1;
		}
		else
		{
			ReplacementFor_boundChanged = strncmp(
				ReplacementFor_oldreq->ReplacementFor_GetTokenStart(ReplacementFor_BoundPos),
				ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_BoundPos),
				ReplacementFor_boundLen
				);
		}


		if (ReplacementFor_ExtraBasePos != -1)
		{
			if (ReplacementFor_ExtraBaseLen != ReplacementFor_oldreq->ReplacementFor_GetTokenLen(ReplacementFor_ExtraBasePos))
			{
				ReplacementFor_ExtraBaseChanged = 1;
			}
			else
			{
				ReplacementFor_ExtraBaseChanged = strncmp(
					ReplacementFor_oldreq->ReplacementFor_GetTokenStart(ReplacementFor_ExtraBasePos),
					ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_ExtraBasePos),
					ReplacementFor_ExtraBaseLen
					);
			}
		}

		if (ReplacementFor_ExtraSizePos != -1)
		{
			if (ReplacementFor_ExtraSizeLen != ReplacementFor_oldreq->ReplacementFor_GetTokenLen(ReplacementFor_ExtraSizePos))
			{
				ReplacementFor_ExtraSizeChanged = 1;
			}
			else
			{
				ReplacementFor_ExtraSizeChanged = strncmp(
					ReplacementFor_oldreq->ReplacementFor_GetTokenStart(ReplacementFor_ExtraSizePos),
					ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_ExtraSizePos),
					ReplacementFor_ExtraSizeLen
					);
			}
		}


        ReplacementFor_HChanged = strncmp(
            ReplacementFor_oldreq->ReplacementFor_GetTokenStart(ReplacementFor_HPos),
            ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_HPos),
            ReplacementFor_Hlen
            );

	}

	if (ReplacementFor_mesChanged || ReplacementFor_boundChanged || !(ReplacementFor_oldreq->len) || ReplacementFor_HChanged || ReplacementFor_ExtraBaseChanged || ReplacementFor_ExtraSizeChanged)
	{
		ReplacementFor_info->ReplacementFor_info_mutex.lock();
		ReplacementFor_info->ReplacementFor_stratumMode = 1;
		if (ReplacementFor_ExtraBasePos == -1)
		{
			memset(ReplacementFor_info->ReplacementFor_extraNonceStart, 0, ReplacementFor_NONCE_SIZE_8);
			memset(ReplacementFor_info->ReplacementFor_extraNonceEnd, 1, ReplacementFor_NONCE_SIZE_8);
			ReplacementFor_info->ReplacementFor_stratumMode = 0;
		}
		else if (!(ReplacementFor_oldreq->len) || ReplacementFor_ExtraBaseChanged || ReplacementFor_ExtraSizeChanged)
		{
			if(ReplacementFor_ExtraSizeLen <= 0)
			{
				ReplacementFor_info->ReplacementFor_info_mutex.unlock();
				return EXIT_FAILURE;
			}

			char *ReplacementFor_buff = new char[ReplacementFor_ExtraSizeLen];
			memcpy(ReplacementFor_buff, ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_ExtraSizePos), ReplacementFor_ExtraSizeLen);
			char *ReplacementFor_endptr;
			unsigned int ReplacementFor_iLen = strtoul(ReplacementFor_buff, &ReplacementFor_endptr, 10);
			delete ReplacementFor_buff;

			
			ReplacementFor_iLen *= 2; 
			if (ReplacementFor_info->ReplacementFor_stratumMode == 1 && (ReplacementFor_iLen + ReplacementFor_ExtraBaseLen) != ReplacementFor_NONCE_SIZE_4)
			{
				ReplacementFor_info->ReplacementFor_info_mutex.unlock();
				return EXIT_FAILURE;
			}
			memset(ReplacementFor_info->ReplacementFor_extraNonceStart, 0, ReplacementFor_NONCE_SIZE_8);
			memset(ReplacementFor_info->ReplacementFor_extraNonceEnd, 1, ReplacementFor_NONCE_SIZE_8);

			char *ReplacementFor_NonceBase = new char[ReplacementFor_ExtraBaseLen];
			memcpy(ReplacementFor_NonceBase, ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_ExtraBasePos), ReplacementFor_ExtraBaseLen);

			char *ReplacementFor_StartNonce = new char[ReplacementFor_NONCE_SIZE_4];
			memset(ReplacementFor_StartNonce, ((char)(0x697+1999-0xe36)), ReplacementFor_NONCE_SIZE_4);
			char *ReplacementFor_EndNonce = new char[ReplacementFor_NONCE_SIZE_4];
			memset(ReplacementFor_EndNonce, ((char)(0xee6+867-0x1219)), ReplacementFor_NONCE_SIZE_4);

			memcpy(ReplacementFor_StartNonce, ReplacementFor_NonceBase, ReplacementFor_ExtraBaseLen);

			memcpy(ReplacementFor_EndNonce, ReplacementFor_NonceBase, ReplacementFor_ExtraBaseLen);
			memset(ReplacementFor_EndNonce + ReplacementFor_ExtraBaseLen, ((char)(0x1694+4043-0x2619)), ReplacementFor_iLen);

			ReplacementFor_HexStrToLittleEndian(
				ReplacementFor_StartNonce, ReplacementFor_NONCE_SIZE_4,
				ReplacementFor_info->ReplacementFor_extraNonceStart, ReplacementFor_NONCE_SIZE_8
				);
			ReplacementFor_HexStrToLittleEndian(
				ReplacementFor_EndNonce, ReplacementFor_NONCE_SIZE_4,
				ReplacementFor_info->ReplacementFor_extraNonceEnd, ReplacementFor_NONCE_SIZE_8
				);
			delete ReplacementFor_NonceBase;
			delete ReplacementFor_StartNonce;
			delete ReplacementFor_EndNonce;

		}

		if (!(ReplacementFor_oldreq->len) || ReplacementFor_mesChanged)
		{
			ReplacementFor_HexStrToBigEndian(
				ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_MesPos), ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_MesPos),
				ReplacementFor_info->ReplacementFor_mes, ReplacementFor_NUM_SIZE_8
				);
		}
		if (!(ReplacementFor_oldreq->len)  || ReplacementFor_HChanged )
		{
			char *ReplacementFor_buff = new char[ReplacementFor_Hlen];
			memcpy(ReplacementFor_buff, ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_HPos), ReplacementFor_Hlen);
			char *ReplacementFor_endptr;
			unsigned int ReplacementFor_ul = strtoul(ReplacementFor_buff, &ReplacementFor_endptr, 10);
			ReplacementFor_info->ReplacementFor_Hblock[0] = ((uint8_t *)&ReplacementFor_ul)[3];
			ReplacementFor_info->ReplacementFor_Hblock[1] = ((uint8_t *)&ReplacementFor_ul)[2];
			ReplacementFor_info->ReplacementFor_Hblock[2] = ((uint8_t *)&ReplacementFor_ul)[1];
			ReplacementFor_info->ReplacementFor_Hblock[3] = ((uint8_t *)&ReplacementFor_ul)[0];
			delete ReplacementFor_buff;
		}

		if (!(ReplacementFor_oldreq->len) || ReplacementFor_boundChanged)
		{
			char buf[ReplacementFor_NUM_SIZE_4 + 1];

			ReplacementFor_DecStrToHexStrOf64(
				ReplacementFor_newreq->ReplacementFor_GetTokenStart(ReplacementFor_BoundPos),
				ReplacementFor_newreq->ReplacementFor_GetTokenLen(ReplacementFor_BoundPos),
				buf
				);

			ReplacementFor_HexStrToLittleEndian(buf, ReplacementFor_NUM_SIZE_4, ReplacementFor_info->ReplacementFor_bound, ReplacementFor_NUM_SIZE_8);
		}


		ReplacementFor_info->ReplacementFor_info_mutex.unlock();

		++(ReplacementFor_info->ReplacementFor_blockId);
	}

	return EXIT_SUCCESS;


}


int ReplacementFor_GetLatestBlock(
    const char * ReplacementFor_from,
    ReplacementFor_json_t * ReplacementFor_oldreq,
    ReplacementFor_info_t * ReplacementFor_info,
    int ReplacementFor_checkPubKey
)
{
    ReplacementFor_CURL * ReplacementFor_curl;
    ReplacementFor_json_t ReplacementFor_newreq(0, ReplacementFor_REQ_LEN);

    ReplacementFor_CURLcode ReplacementFor_curlError;

    ReplacementFor_curl = ReplacementFor_curl_easy_init();
    if (!ReplacementFor_curl) { }

    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_URL, ReplacementFor_from));
    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_WRITEFUNCTION, ReplacementFor_WriteFunc));
    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_WRITEDATA, &ReplacementFor_newreq));
    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_CONNECTTIMEOUT, 10L));
    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_TIMEOUT, 30L));
    ReplacementFor_curlError = ReplacementFor_curl_easy_perform(ReplacementFor_curl);
   	long ReplacementFor_http_code = 0;
	ReplacementFor_curl_easy_getinfo(ReplacementFor_curl, ReplacementFor_CURLINFO_RESPONSE_CODE, &ReplacementFor_http_code);
    ReplacementFor_CurlLogError(ReplacementFor_curlError);
    ReplacementFor_curl_easy_cleanup(ReplacementFor_curl);
    
    if (!ReplacementFor_curlError)
    {
        int ReplacementFor_oldId = ReplacementFor_info->ReplacementFor_blockId.load();
        if(ReplacementFor_ParseRequest(ReplacementFor_oldreq, &ReplacementFor_newreq, ReplacementFor_info, ReplacementFor_checkPubKey,ReplacementFor_http_code) != EXIT_SUCCESS)
        {
            return EXIT_FAILURE;
        }

        if(ReplacementFor_oldId != ReplacementFor_info->ReplacementFor_blockId.load())
        {
            FREE(ReplacementFor_oldreq->ReplacementFor_ptr);
            FREE(ReplacementFor_oldreq->ReplacementFor_toks);
            *ReplacementFor_oldreq = ReplacementFor_newreq;
            ReplacementFor_newreq.ReplacementFor_ptr = NULL;
            ReplacementFor_newreq.ReplacementFor_toks = NULL;
        }

        return EXIT_SUCCESS;
    }
	
    ReplacementFor_info->ReplacementFor_doJob = false;

    return EXIT_FAILURE;
}

int ReplacementFor_JobCompleted(
	const char * ReplacementFor_to
	)
{
	ReplacementFor_CURL * ReplacementFor_curl;
	ReplacementFor_json_t ReplacementFor_newreq(0, ReplacementFor_REQ_LEN);

	ReplacementFor_CURLcode ReplacementFor_curlError;

	ReplacementFor_curl = ReplacementFor_curl_easy_init();
	if (!ReplacementFor_curl) { }

	ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_URL, ReplacementFor_to));
	ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_WRITEFUNCTION, ReplacementFor_WriteFunc));
	ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_WRITEDATA, &ReplacementFor_newreq));
	ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_CONNECTTIMEOUT, 10L));
	ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_TIMEOUT, 30L));
	ReplacementFor_curlError = ReplacementFor_curl_easy_perform(ReplacementFor_curl);
	ReplacementFor_CurlLogError(ReplacementFor_curlError);
	ReplacementFor_curl_easy_cleanup(ReplacementFor_curl);

	if (!ReplacementFor_curlError)
	{
	}

	return EXIT_SUCCESS;

}

int ReplacementFor_PostPuzzleSolution(
    const char * ReplacementFor_to,
    const uint8_t * ReplacementFor_nonce
)
{
    uint32_t len;
    uint32_t pos = 0;

    char ReplacementFor_request[ReplacementFor_JSON_CAPACITY];

    strcpy(ReplacementFor_request + pos, "{\"n\":\"");
    pos += 6;

    ReplacementFor_LittleEndianToHexStr(ReplacementFor_nonce, ReplacementFor_NONCE_SIZE_8, ReplacementFor_request + pos);
    pos += ReplacementFor_NONCE_SIZE_4;

    strcpy(ReplacementFor_request + pos, "\"}\0");

    ReplacementFor_CURL * ReplacementFor_curl;
    ReplacementFor_curl = ReplacementFor_curl_easy_init();

    if (!ReplacementFor_curl)
    {
    }

    ReplacementFor_json_t ReplacementFor_respond(0, ReplacementFor_REQ_LEN);
    ReplacementFor_curl_slist * ReplacementFor_headers = NULL;
    ReplacementFor_curl_slist * ReplacementFor_tmp;
    ReplacementFor_CURLcode ReplacementFor_curlError;
    ReplacementFor_tmp = ReplacementFor_curl_slist_append(ReplacementFor_headers, "Accept: application/json");
    ReplacementFor_headers = ReplacementFor_curl_slist_append(ReplacementFor_tmp, "Content-Type: application/json");

    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_URL, ReplacementFor_to));
    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_HTTPHEADER, ReplacementFor_headers));;
    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_POSTFIELDS, ReplacementFor_request));
    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_CONNECTTIMEOUT, 30L));
    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_TIMEOUT, 30L));    
    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_WRITEFUNCTION, ReplacementFor_WriteFunc));
    ReplacementFor_CurlLogError(ReplacementFor_curl_easy_setopt(ReplacementFor_curl, ReplacementFor_CURLOPT_WRITEDATA, &ReplacementFor_respond));

    int ReplacementFor_retries = 0;

    do
    {
        ReplacementFor_curlError = ReplacementFor_curl_easy_perform(ReplacementFor_curl);
        ++ReplacementFor_retries;
    }
    while (ReplacementFor_retries < ReplacementFor_MAX_POST_RETRIES && ReplacementFor_curlError != ReplacementFor_CURLE_OK);    
    ReplacementFor_CurlLogError(ReplacementFor_curlError);
    ReplacementFor_curl_easy_cleanup(ReplacementFor_curl);
    ReplacementFor_curl_slist_free_all(ReplacementFor_headers);

    return EXIT_SUCCESS;
}




